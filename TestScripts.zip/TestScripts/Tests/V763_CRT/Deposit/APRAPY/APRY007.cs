using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using NUnit.Framework;
using Profile7Automation.ObjectFactory.WebCSR.Pages;


namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.APRAPY
{
    [TestFixture]
    public class APRY007 : TestBase
    {

        [Test]
        [Property("TestDescription", "APY Calculation for deposit account is created using an interest index.")]
        public void APRY07()
        {

            string sGLOBAL_USERID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string sGLOBAL_PASSWORD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            const string AnnualPercentageYield = "10.32";
            const string GLOBAL_BL_SPLIT_DP_SPLIT011_CD_PRODUCT_STEP1 = "CD PROD ONE 643";

            Report.Step("Login to the Profile WebCSR.");
            Application.WebCSR.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));
            string systemdate = Application.WebCSR.GetApplicationDate();

            Report.Step("Create a new Create Personal Customer with all required fields.");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Create a certificate of deposit account<ACCNUM_APRY007> with the Currency: USD using the copied product type Customer <CIF1>.");
            string[] CD_DEPOIST_ACCOUNT_DETAILS = new string[11];
            CD_DEPOIST_ACCOUNT_DETAILS[0] = Data.Get("GLOBAL_BLANK_OR_NULL");
            CD_DEPOIST_ACCOUNT_DETAILS[1] = Data.Get("GLOBAL_BLANK_OR_NULL");
            CD_DEPOIST_ACCOUNT_DETAILS[2] = Data.Get("GLOBAL_AMOUNT_DEPOSITED_1K");
            CD_DEPOIST_ACCOUNT_DETAILS[3] = Data.Get("GLOBAL_CURRENCY_CODE_USD");
            CD_DEPOIST_ACCOUNT_DETAILS[6] = "1Y";
            CD_DEPOIST_ACCOUNT_DETAILS[7] = Data.Get("GLOBAL_AMOUNT_DEPOSITED_1K");
            string ACCNUM_APRY007 = Application.WebCSR.CreateAccount(Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"), Data.Get("GLOBAL_RELATION_SINGLE"), GLOBAL_BL_SPLIT_DP_SPLIT011_CD_PRODUCT_STEP1, CIF1, CD_DEPOIST_ACCOUNT_DETAILS);

            Report.Step("Verify Annual Percentage Yield is calculated when a deposit account is created using an interest index.");
            Application.WebCSR.GetAccount(ACCNUM_APRY007);
            Application.WebCSR.ClickTabInDepositAccountOverviewPage("Account Summary");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkRateDetermination);
            string OutPutValue = Application.WebCSR.GetCellValueByLabel("Annual Yield:");
            double finalValue2 = Math.Round(double.Parse(OutPutValue), 2);
            string AnnualYield = finalValue2.ToString();
            Application.WebCSR.comparestringvalues(AnnualPercentageYield, AnnualYield);

            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();

        }
    }
}
