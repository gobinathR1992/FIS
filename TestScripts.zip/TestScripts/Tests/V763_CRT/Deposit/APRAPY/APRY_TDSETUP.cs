using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.APRAPY
{

    [TestFixture]
    public class APR_TDSETUP : TestBase
    {

        [Test]
        [Property("TestDescription", "Creation of setup / installation for APR/APY")]
        public void APRY_TDSETUP()
        {
            string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string PWD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;

            Report.Step("Login to WebCSR Application.");
            Application.WebCSR.Login(UID, PWD, Data.Get("GLOBAL_BRANCH_CODE"));
            string System_Date = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN365 = Application.WebCSR.CalculateNewDate(System_Date, "d", -365);

            Report.Step("Create a new Personal Customer <CUSTNUM1> by entering all mandatory field values (Profile WebCSR| Basic Services| Create Personal Customer).");
            string CUSTNUM1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Logout from Profile WebCSR application.");
            Application.WebCSR.LogOutofWebCSR();

            Report.Step("Login to WebAdmin Application.");
            Application.WebAdmin.LogintoWebAdmin(UID, PWD);

            Report.Step("Copy a Consumer Loan Product Type <CONLOANPROD> from Standatd Product Type (Product Factory| Products).");
            string sPROD_NAME = "Installment Loan";
            string CONLOANPROD = Application.WebAdmin.enter_copy_product_definition_details(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_CONSUMER_LOAN"), Data.Get("GLOBAL_STAND_ADMINPROD_DESC_500"), sPROD_NAME, false);

            Report.Step("Access the newly copied product <CONLOANPROD> and Navigate to General Page and Set Description : Consumer Loan - APR/APY and Start Date: System Date - 365 Days.");
            List<string> ProdDetails = new List<string>();
            ProdDetails.Add(WebAdminProductsGeneralPage.txt_General_Information_Description_Field + "|field|Consumer Loan - APR/APY");
            ProdDetails.Add(WebAdminProductsGeneralPage.txt_General_Information_Start_Date_Field + "|field|" + SYSTEMDATEMIN365);
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(ProdDetails, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            Report.Step("Navigate to Interest Calculation Page by selecting Interest tab | Calculations subtab.");
            Application.WebAdmin.ClickonTabinProductPage("Interest");

            Report.Step("Update - Annual Percentage Rate Calculation Method (PRODDFTL.APRMTHD):  1 – U.S. Regulatory Calculation Method");
            List<string> ProdDetails1 = new List<string>();
            ProdDetails1.Add(LoanInterestCalculationPage.drpCalculationAnnualPercentageRateCalculationMethod + "|dropdown|U.S. Regulatory Calculation Method");
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(ProdDetails1, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            Report.Step("Navigate to Payment Calculation Page by selecting Payment Calculation tab | Calculation Options subtab.");
            Application.WebAdmin.ClickonTabinProductPage("Payment Calculation");

            Report.Step("Update - Interest Determination Point: Calculated at Billing; Full Period to First Payment: OFF.");
            List<string> ProdDetails2 = new List<string>();
            ProdDetails2.Add(PaymentCalculationOptionsPage.drpCalculationOptionsInterestDeterminationPoint + "|dropdown|Calculated at Billing");
            ProdDetails2.Add(PaymentCalculationOptionsPage.chkCalculationOptionsFullPeriodtoFirstPayment + "|checkbox|off");
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(ProdDetails2, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            Report.Step("Logout WebAdmin Application.");
            Application.WebAdmin.LogOutofWebAdmin();

            Data.Store("CUSTNUM1",CUSTNUM1);
            Data.Store("CONLOANPROD",CONLOANPROD);
            Data.Store("CopyProductName",sPROD_NAME);
        }
    }
}

