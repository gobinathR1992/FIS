using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using NUnit.Framework;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebCSR.Pages;


namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.APRAPY
{
    [TestFixture]
    public class APRY010 : TestBase
    {

        [Test]
        [Property("TestDescription", "APY Calculation for deposit accounts opened with a stated maturity greater than one year.")]
        public void APRY10()
        {

            string sGLOBAL_USERID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string sGLOBAL_PASSWORD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            string sCustomerNumber = null;

            // Step 1.0: Login to the Profile WebCSR.
            Report.Step("Login to the Profile WebCSR.");
            Application.WebCSR.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));

            double Percentage = Application.WebCSR.CalculateAnnualPercentageYield(0.1, "CUSTOM;2");
            double finalValue1 = Math.Round(Percentage, 2);
            string AnnualYield1 = finalValue1.ToString();
           
            //Step 2.0: Create a new Create Personal Customer with all required fields.
            Report.Step("Create a new Create Personal Customer with all required fields.");
            sCustomerNumber = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            //Step 3.0: Create a Certificate of Deposit Account using the standard Demand Deposits Product Type - 350.
            Report.Step("Create a Certificate of Deposit Account using the standard Demand Deposits Product Type - 350.");
            string[] CD_DEPOIST_ACCOUNT_DETAILS = new string[11];
            CD_DEPOIST_ACCOUNT_DETAILS[0] = Data.Get("GLOBAL_BLANK_OR_NULL");
            CD_DEPOIST_ACCOUNT_DETAILS[1] = Data.Get("GLOBAL_BLANK_OR_NULL");
            CD_DEPOIST_ACCOUNT_DETAILS[2] = Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K");
            CD_DEPOIST_ACCOUNT_DETAILS[3] = Data.Get("GLOBAL_CURRENCY_CODE_USD");
            CD_DEPOIST_ACCOUNT_DETAILS[6] = "2Y";
            string CDACCT = Application.WebCSR.CreateAccount(Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"), Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_350"), sCustomerNumber, CD_DEPOIST_ACCOUNT_DETAILS);

            //Step 4.0: Bring Certificate of deposit account <CDACCNUM> into session and navigate to Account Summary page.
            Report.Step("Bring Certificate of deposit account <CDACCNUM> into session and navigate to Account Summary page");
            Application.WebCSR.GetAccount(CDACCT);
            
            // Step 5.0: Navigate to Term Accounts - Maturity page. Set - Term: 2Y, Principal Maturity Option: Pay by Check.
            Report.Step("Navigate to Term Accounts - Maturity page. Set - Term: 2Y, Principal Maturity Option: Pay by Check.");
            Application.WebCSR.ClickTabInDepositAccountOverviewPage("Account Summary");
            Application.WebCSR.ClickTabInAccountInformationPage("Term Accounts");
            List<string> values1 = new List<string>();
            string PrincipalMaturityOption = "1 - Pay by Check";
            string MaturityTerm = "2Y";
            values1.Add(AccountInformationPage.txtMaturityInformationAccountTerm + "|field|" + MaturityTerm);
            values1.Add(AccountInformationPage.drpRenewalInformationPrincipalMaturityOption + "|dropdown|" + PrincipalMaturityOption);
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values1, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 6.0: Navigate to Interest Accrual Page. Set - Accrual Base: Ledger Balance, Accrual Method: Actual / Actual (31/365,6), Compouding frequency: 6MAE.
            Report.Step("Navigate to Interest Accrual Page. Set - Accrual Base: Ledger Balance, Accrual Method: Actual / Actual (31/365,6), Compouding frequency: 6MAE.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest");
            Application.WebCSR.SetFrequencyFromFrequencyCalculator(DepositInterestAccrualPage.imgCompoundingFrequencyCalculator,"6");
            List<string> values2 = new List<string>();
            values2.Add(AccountInformationPage.drpCalculationOptionsAccrualBase + "|dropdown|" + Data.Get("GLOBAL_ACCRUAL_BASE_1"));
            values2.Add(AccountInformationPage.drpCalculationOptionsAccrualMethod + "|dropdown|11 - Actual/Actual (31/365,6)");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values2, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 7.0:Navigate to Interest Rate Determination Page. Set - Interest Rate: 10.00.
            Report.Step("Navigate to Interest Rate Determination Page. Set - Interest Rate: 10.00.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkRateDetermination);
            List<string> values3 = new List<string>();
            string GLOBAL_VALUE_10 = "10";
            values3.Add(AccountInformationPage.txtRateDeterminationInterestRate + "|field|" + GLOBAL_VALUE_10);
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values3, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 8.0:Navigate to Interest Payment Page. Set - Disbursement Option: Pay By Check, Check Frequency: 1MAE, Positive Interest Posting Frequency: 1MAE.
            Report.Step("Navigate to Interest Payment Page. Set - Disbursement Option: Pay By Check, Check Frequency: 1MAE, Positive Interest Posting Frequency: 1MAE.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkPayment);
            List<string> values4 = new List<string>();
            string DisbursementOption = "1 - Pay By Check";
            values4.Add(AccountInformationPage.drpDisbursementOption + "|dropdown|" + DisbursementOption);
            Application.WebCSR.EnterValuesInWebCSRSpecifiedPage(values4);
            Application.WebCSR.SetFrequencyFromFrequencyCalculator(DepositPaymentPage.imgDisbursementCheckFrequencyCalculator,"1");
            Application.WebCSR.SetFrequencyFromFrequencyCalculator(DepositPaymentPage.imgPositiveInterestPostingFrequencyCalculator,"1");
            Application.WebCSR.ClickonSubmitButton();
            Application.WebCSR.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 9.0: Navigate to Interest Rate Determination page.
            Report.Step("Navigate to the Rate Determination page.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkRateDetermination);
            
            //Step 10.0: Expected Result: R31: Verify that Annual Percentage Yield is calculated and displayed correctly.
            Report.Step("Verify that Annual Percentage Yield is calculated and displayed correctly.");
            string OutPutValue = Application.WebCSR.GetCellValueByLabel("Annual Yield:");
            double finalValue2 = Math.Round(double.Parse(OutPutValue), 2);
            string AnnualYield2 = finalValue2.ToString();
            Application.WebCSR.comparestringvalues(AnnualYield1, AnnualYield2);

            // Step 11.0: Log out of Profile WebCSR and close the browser.
            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();

        }
    }
}