using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using NUnit.Framework;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebCSR.Pages;


namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.APRAPY
{
    [TestFixture]
    public class APRY006 : TestBase
    {

        [Test]
        [Property("TestDescription", "APY Calculation for fixed rated deposit account.")]
        public void APRY06()
        {

            string sGLOBAL_USERID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string sGLOBAL_PASSWORD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;

            // Step 1.0: Login to the Profile WebCSR.
            Report.Step("Login to the Profile WebCSR.");
            Application.WebCSR.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));

            double Percentage = Application.WebCSR.CalculateAnnualPercentageYield(0.1, Data.Get("GLOBAL_FREQUENCY_1DA"));
            double finalValue1 = Math.Round(Percentage, 2);
            string annualyield1 = finalValue1.ToString();

            double Percentage1 = Application.WebCSR.CalculateAnnualPercentageYield(0.12, Data.Get("GLOBAL_FREQUENCY_1DA"));
            double finalValue = Math.Round(Percentage1, 2);
            string annualyield2 = finalValue.ToString();

            // Step 2.0: Create a new Create Personal Customer with all required fields.
            Report.Step("Create a new Create Personal Customer with all required fields.");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            // Step 3.0: Create a Certificate of Deposit Account using the standard Demand Deposits Product Type - 350.
            Report.Step("Create a Certificate of Deposit Account using the standard Demand Deposits Product Type - 350.");
            string[] CD_DEPOIST_ACCOUNT_DETAILS = new string[11];
            CD_DEPOIST_ACCOUNT_DETAILS[6] = "1Y";
            string ACCNUM1 = Application.WebCSR.CreateAccount(Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"), Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_350"), CIF1, CD_DEPOIST_ACCOUNT_DETAILS);

            //Step 4.0: Bring Certificate of deposit account <CDACCNUM> into session and navigate to Account Summary page.
            Report.Step("Bring Certificate of deposit account <CDACCNUM> into session and navigate to Account Summary page");
            Application.WebCSR.GetAccount(ACCNUM1);

            // Step 5.0: Navigate to Deposit Rate Determination Page by selecting Interest Rate tab | Rate Determination Link. Set - Interest Rate : 10.
            Report.Step("Navigate to Deposit Rate Determination Page by selecting Interest Rate tab | Rate Determination Link. Set - Interest Rate : 10.");
            Application.WebCSR.ClickTabInDepositAccountOverviewPage("Account Summary");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkRateDetermination);
            List<string> values1 = new List<string>();
            values1.Add(DepositRateDeterminationPage.txtRateDeterminationInterestRate + "|field|10");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values1, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 6.0: Navigate to Deposit Interest Accrual Page by selecting Accrual link. Set - Accrual Base: Ledger Balance; Accrual Method: Actual / Actual (31/365,6); Compounding Frequency: 1DA.
            Report.Step("Navigate to Deposit Interest Accrual Page by selecting Accrual link. Set - Accrual Base: Ledger Balance; Accrual Method: Actual / Actual (31/365,6); Compounding Frequency: 1DA.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkAccrual);
            List<string> values2 = new List<string>();
            values2.Add(AccountInformationPage.drpCalculationOptionsAccrualBase + "|dropdown|" + Data.Get("GLOBAL_ACCRUAL_BASE_1"));
            values2.Add(AccountInformationPage.drpCalculationOptionsAccrualMethod + "|dropdown|11 - Actual/Actual (31/365,6)");
            values2.Add(AccountInformationPage.txtCalculationOptionsCompoundingFrequency + "|field|" + Data.Get("GLOBAL_FREQUENCY_6MAE"));
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values2, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 7.0:Navigate to Deposit Rate Determination Page by selecting Interest tab | Rate Determination link.4
            Report.Step("Navigate to Deposit Rate Determination Page by selecting Interest tab | Rate Determination link.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkRateDetermination);

            //Step 8.0:Verify that Annual Yield is calculated and displayed correctly.
            Report.Step("Verify that Annual Yield is calculated and displayed correctly.");
            string OutPutValue = Application.WebCSR.GetCellValueByLabel("Annual Yield:");
            double finalValue2 = Math.Round(double.Parse(OutPutValue), 2);
            string AnnualYield3 = finalValue2.ToString();
            Application.WebCSR.comparestringvalues(annualyield1, AnnualYield3);

            // Step 9.0: Set - Interest Rate: 12 for Certificate of Deposit Account <ACCNUM1> on Rate Determination Page.
            Report.Step("Set - Interest Rate: 12 for Certificate of Deposit Account <ACCNUM1> on Rate Determination Page.");
            List<string> values3 = new List<string>();
            values3.Add(DepositRateDeterminationPage.txtRateDeterminationInterestRate + "|field|12");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values3, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 10.0:Verify that Annual Yield is calculated and displayed correctly.
            Report.Step("Verify that Annual Yield is calculated and displayed correctly.");
            string OutPutValue1 = Application.WebCSR.GetCellValueByLabel("Annual Yield:");
            double finalValue3 = Math.Round(double.Parse(OutPutValue1), 2);
            string AnnualYield4 = finalValue3.ToString();
            Application.WebCSR.comparestringvalues(annualyield1, AnnualYield4);

            // Step 11.0: Log out of Profile WebCSR and close the browser.
            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();
        }
    }
}