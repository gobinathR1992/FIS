using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using NUnit.Framework;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebCSR.Pages;


namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.APRAPY
{
    [TestFixture]
    public class APRY004 : TestBase
    {

        [Test]
        [Property("TestDescription", "APR Calculation for calculation method 2- Netherlands Regulatory Calculation Method for closed ended loan account.")]
        public void APRY04()
        {

            string sGLOBAL_USERID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string sGLOBAL_PASSWORD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            string LNProdNumber = Data.Fetch("APRY_BLSETUP_TSR1", "LNProdNumber");
            string LNProdName = Data.Fetch("APRY_BLSETUP_TSR1", "LNProdName");

            // Step 1.0: Login to the Profile WebCSR.
            Report.Step("Login to the Profile WebCSR.");
            Application.WebCSR.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));

            // Step 2.0: Create a new Create Personal Customer with all required fields.
            Report.Step("Create a new Create Personal Customer with all required fields.");
            string CUSTNUM1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            string GLOBAL_SYSTEM_DATE = Application.WebCSR.GetApplicationDate();

            // Step 3.0: Create a Consumer Loan account.
            Report.Step("Create a Consumer Loan account.");
            string[] LOANACCOUNT_INFORMATION_DETAILS = new string[11];
            LOANACCOUNT_INFORMATION_DETAILS[0] = "";
            LOANACCOUNT_INFORMATION_DETAILS[1] = "10000";
            LOANACCOUNT_INFORMATION_DETAILS[2] = "3Y";
            LOANACCOUNT_INFORMATION_DETAILS[3] = Data.Get("GLOBAL_CURRENCY_CODE_USD");
            LOANACCOUNT_INFORMATION_DETAILS[4] = GLOBAL_SYSTEM_DATE;
            LOANACCOUNT_INFORMATION_DETAILS[5] = "1MAE";
            LOANACCOUNT_INFORMATION_DETAILS[6] = "";
            LOANACCOUNT_INFORMATION_DETAILS[7] = "0 - Unsecured";
            string ACCNUM1 = Application.WebCSR.CreateAccount(Data.Get("GLOBAL_LOAN_ACCOUNTCLASS"), Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), LNProdName, CUSTNUM1, LOANACCOUNT_INFORMATION_DETAILS);

            //Step 4.0: Bring account <ACCNUM1> into session and navigate to Account Summary page.
            Report.Step("Bring account <ACCNUM1> into session and navigate to Account Summary page.");
            Application.WebCSR.GetAccount(ACCNUM1);

            // Step 5.0: Navigate to Loan Rate Determination Page by selecting Interest Rate tab | Rate Determination Link. Set - Interest Rate : 10.
            Report.Step("Navigate to Loan Rate Determination Page by selecting Interest Rate tab | Rate Determination Link. Set - Interest Rate : 10.");
            Application.WebCSR.ClickTabInDepositAccountOverviewPage("Account Summary");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkRateDetermination);
            List<string> values1 = new List<string>();
            values1.Add(LoanRateDeterminationPage.txtInterestRate + "|field|10");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values1, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 6.0: Verify the Interest Rate in Annual Disclosure Rate Field in Loan Rate Determination Page.
            Report.Step(" Verify the Interest Rate in Annual Disclosure Rate Field in Loan Rate Determination Page.");
            string rate1 = "10.47131";
            string rate2 = Application.WebCSR.GetValueFromSpecifiedPage(LoanRateDeterminationPage.txtInterestRatesAnnualDisclosureRate, "field");
            Application.WebCSR.comparestringvalues(rate1, rate2);

            // Step 7.0: update Interest Rate to 15 in in Loan Rate Determination Page.
            Report.Step("update Interest Rate to 15 in in Loan Rate Determination Page.");
            List<string> values2 = new List<string>();
            values2.Add(LoanRateDeterminationPage.txtInterestRate + "|field|15");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values2, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 8.0: Verify the Interest Rate in Annual Disclosure Rate Field in Loan Rate Determination Page.
            Report.Step(" Verify the Interest Rate in Annual Disclosure Rate Field in Loan Rate Determination Page.");
            string rate3 = "16.07545";
            string rate4 = Application.WebCSR.GetValueFromSpecifiedPage(LoanRateDeterminationPage.txtInterestRatesAnnualDisclosureRate, "field");
            Application.WebCSR.comparestringvalues(rate3, rate4);

            // Step 9.0: Navigate to Loan Calculation Options Page by selecting Interest Rate tab | Calculation Options Link. Set - Interest Calculation Period Frequency : 1QAE.
            Report.Step("Navigate to Loan Calculation Options Page by selecting Interest Rate tab | Calculation Options Link. Set - Interest Calculation Period Frequency : 1QAE.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkCalculationOptions);
            List<string> values3 = new List<string>();
            values3.Add(LoanCalculationOptionsPage.txtDailyCalculationOptionsInterestCalculationPeriodFrequency + "|field|1QAE");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values3, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 10.0: Verify the Interest Rate in Annual Disclosure Rate Field in Loan Rate Determination Page.
            Report.Step(" Verify the Interest Rate in Annual Disclosure Rate Field in Loan Rate Determination Page.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkRateDetermination);
            string rate5 = "15.86504";
            string rate6 = Application.WebCSR.GetValueFromSpecifiedPage(LoanRateDeterminationPage.txtInterestRatesAnnualDisclosureRate, "field");
            Application.WebCSR.comparestringvalues(rate5, rate6);

            // Step 11.0: update Interest Rate to 12 in in Loan Rate Determination Page.
            Report.Step("update Interest Rate to 12 in in Loan Rate Determination Page.");
            List<string> values4 = new List<string>();
            values4.Add(LoanRateDeterminationPage.txtInterestRate + "|field|12");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values4, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            // Step 12.0: Navigate to Loan Calculation Options Page by selecting Interest Rate tab | Calculation Options Link. Set - Interest Calculation Period Frequency : 1WA.
            Report.Step("Navigate to Loan Calculation Options Page by selecting Interest Rate tab | Calculation Options Link. Set - Interest Calculation Period Frequency : 1WA.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkCalculationOptions);
            List<string> values5 = new List<string>();
            values5.Add(LoanCalculationOptionsPage.txtDailyCalculationOptionsInterestCalculationPeriodFrequency + "|field|1WA");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values5, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 13.0: Verify the Interest Rate in Annual Disclosure Rate Field in Loan Rate Determination Page.
            Report.Step(" Verify the Interest Rate in Annual Disclosure Rate Field in Loan Rate Determination Page.");
            Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkRateDetermination);
            string rate7 = "12.73410";
            string rate8 = Application.WebCSR.GetValueFromSpecifiedPage(LoanRateDeterminationPage.txtInterestRatesAnnualDisclosureRate, "field");
            Application.WebCSR.comparestringvalues(rate7, rate8);
            
            // Step 11.0: Log out of Profile WebCSR and close the browser.
            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();
        }
    }
}