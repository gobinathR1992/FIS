using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using NUnit.Framework;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;


namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.APRAPY
{
    [TestFixture]
    public class APRY016 : TestBase
    {

        [Test]
        [Property("TestDescription", "APR calculated based on the Total Amount Financed when Origination Fees are defined on the loan account.")]
        public void APRY16()
        {

            string sGLOBAL_USERID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string sGLOBAL_PASSWORD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            string sCustomerNumber = null;
            string GLOBAL_SYSTEM_DATE = null;

            // Step 1.0: Login to the Profile WebCSR.
            Report.Step("Login to the Profile WebCSR.");
            Application.WebCSR.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));

            // Step 2.0: Create a new Create Personal Customer with all required fields.
            Report.Step("Create a new Create Personal Customer with all required fields.");
            sCustomerNumber = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            GLOBAL_SYSTEM_DATE = WebAdminPageFactory.WebAdminMasterPage.GetAppDate();

            // Step 2.1: Create a Consumer Loan account with all required fields.
            Report.Step("Create a Consumer Loan account with all required fields.");
            string[] LN_ACCOUNT_DETAILS = new string[8];
            LN_ACCOUNT_DETAILS[0] = "Consumer Loan";
            LN_ACCOUNT_DETAILS[1] = Data.Get("GLOBAL_AMOUNT_REQUESTED_5K");
            LN_ACCOUNT_DETAILS[2] = Data.Get("GLOBAL_ACCOUNT_TERM_2Y");
            LN_ACCOUNT_DETAILS[3] = Data.Get("GLOBAL_CURRENCY_CODE_USD");
            LN_ACCOUNT_DETAILS[4] = GLOBAL_SYSTEM_DATE;
            LN_ACCOUNT_DETAILS[5] = Data.Get("GLOBAL_FREQUENCY");
            LN_ACCOUNT_DETAILS[6] = "";
            LN_ACCOUNT_DETAILS[7] = Data.Get("GLOBAL_COLLATERAL_TAB_VALUE");
            string ACCNUM1 = Application.WebCSR.CreateAccount(Data.Get("GLOBAL_LOAN_ACCOUNTCLASS"), Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"), sCustomerNumber, LN_ACCOUNT_DETAILS);

            //Step 2.2: Access the consumer loan account <LNACCT> and navigate to the Payment Detail page (Payment | Payment Details) and note the Total Number of Payments field value.
            Report.Step("Access the consumer loan account <LNACCT> and navigate to the Payment Detail page (Payment | Payment Details) and note the Total Number of Payments field value.");
            Application.WebCSR.GetAccount(ACCNUM1);
            Application.WebCSR.ClickTabInDepositAccountOverviewPage("Account Summary");
            Application.WebCSR.ClickTabInAccountInformationPage("Payment",AccountInformationPage.lnkPaymentDetail);
            string Term = Application.WebCSR.GetValueFromSpecifiedPage(AccountInformationPage.txtPaymentsDueTotalNumberofPayments,"field");

           //Step 2.3: Navigate to Loan Rate Determination page by selecting Interest tab | Rate Determination Link
           Report.Step("Navigate to Loan Rate Determination page by selecting Interest tab | Rate Determination Link");
           Application.WebCSR.ClickTabInAccountInformationPage("Interest",AccountInformationPage.lnkRateDetermination);

           //Step 2.4: Verify that Annual Disclosure Rate is calculated correctly.
           Report.Step("Verify that Annual Disclosure Rate is calculated correctly.");
           



        }
    }
}