using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.DepositFees
{

    [TestFixture]
    public class DepositFees066 : TestBase
    {

        [Test]
        [Property("TestDescription", "Creation of  Event fee ADD and EDIT to the  fee plan FEE.")]
        public void DepositFees66()
        {
            const string SERVBALANCECOMPUTATION = "Average Collected Balance";
            const string SERVBASEFEEAMOUNT = "100";
            const string SUCCESSMSG = "The effective date for the service fee plan has been created.";
            const string SERPLANFEEEVENT = "AVL - Available Balance";
            const string PLANFEEFIXEDAMOUNT = "50";
            const string PLANFEEFIXEDAMOUNTUPDATE = "100";
            const string SERPLANFEESCHEDULE = "Commitment Fee";
            const string SUCCESSMSGFEEPLAN = "The fees for the service fee plan have been created.";
            const string SUCCESSMSGFEEPLAN_UPDATE = "The fees for the service fee plan have been updated.";
            const string PLANFEEMODIFYMSG = "Please select a plan fee to modify.";
            const string FAILUREERRORMSG = "Usage credit plans only assess on analysis (charge option 2)";
            const string FEEREQUIREDERRORMSG = "The Fixed Amount, Fee Schedule, or Fee Table is required.";
            const string FEEONEERRORMSG = "Only one of the Fixed Amount, Fee Schedule, or Fee Table fields should be populated.";

            string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string PWD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;

            Report.Step("Login to WebAdmin Application.");
            Application.WebAdmin.LogintoWebAdmin(UID, PWD);
            string systemdate = Application.WebAdmin.GetApplicationDate();
            string SYSDATE_PLUS10 = Application.WebAdmin.CalculateNewDate(systemdate, "d", 10);

            Report.Step("Add Service fee plan with SystemDatePlus10.");
            Application.WebAdmin.ClickTableconfigurationLink();
            Application.WebAdmin.SelecttheLink(AdministrationCenterPage.TableConfigServiceFeePlansLink);
            Application.WebAdmin.ClickonAddButton();

            Report.Step("Add Service Fee Plan TYPE1 - Credit Plan-Usage Credits with SystemDatePlus10  Add page");
            string SRVN = Application.WebCSR.GetAlphaNumericString(3);
            string SERVEFEEPLANCP = "SR" + SRVN;
            List<string> values1 = new List<string>();
            values1.Add(PlanParametersPage.txtSericeFeePlan + "|field|" + SERVEFEEPLANCP);
            values1.Add(PlanParametersPage.txtEffectiveDate + "|field|" + SYSDATE_PLUS10);
            values1.Add(PlanParametersPage.txtPlanDescription + "|field|" + SERVEFEEPLANCP);
            values1.Add(PlanParametersPage.drpPlanType + "|dropdown|" + Data.Get("GLOBAL_PLAN_FEE_PLAN_TYPE1"));
            values1.Add(PlanParametersPage.drpBalanceUsedFeeComputation + "|dropdown|" + SERVBALANCECOMPUTATION);
            values1.Add(PlanParametersPage.txtBaseFeeAmount + "|field|" + SERVBASEFEEAMOUNT);
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(values1, SUCCESSMSG);

            Report.Step("Get the service fee plan type created above");
            Application.WebAdmin.SelecttheRadioButtoninTable(ServiceFeePlanEffectDateListPage.tblActionServiceFeePlanEffectiveDateList, SYSDATE_PLUS10);
            Application.WebAdmin.ClickonEditButton();

            Report.Step("Add Plan Fee");
            Application.WebAdmin.ClickonTabinProductPage("Fees");
            Application.WebAdmin.ClickonAddButton();

            Report.Step("Add Event fee to the  fee plan FEE");
            List<string> values2 = new List<string>();
            values2.Add(PlanFeesPage.drpCategory + "|dropdown|" + Data.Get("GLOBAL_PLAN_FEE_CATEGORY_EVENT"));
            Application.WebAdmin.EnterValuesInWebAdminSpecifiedPage(values2);
            List<string> values3 = new List<string>();
            values3.Add(PlanFeesPage.drpEvent + "|dropdown|" + SERPLANFEEEVENT);
            values3.Add(PlanFeesPage.drpChargeOption + "|dropdown|" + Data.Get("GLOBAL_PLAN_FEE_CHARGE_OPTION_2"));
            values3.Add(PlanFeesPage.txtFixedAmount + "|field|" + PLANFEEFIXEDAMOUNT);
            Application.WebAdmin.EnterValuesInWebAdminSpecifiedPage(values3);

            Report.Step("Verify the Maximum Daily Amount is only available if the Charge Option is set to Direct Charge at Time of Service while creating event plan fee");
            Application.WebAdmin.CheckObjectEnabledTrue(PlanFeesPage.txtMaximumDialyAmount);
            Application.WebAdmin.ClickOnObject(WebAdminMasterPage.SubmitButton);

            Report.Step("Event  fees thorws  'Usage credit plans only assess on analysis (charge option 2) while creating a miscellaneous transaction plan fee.");
            Application.WebAdmin.CheckSuccessMessage(FAILUREERRORMSG);
            Application.WebAdmin.ClickonCancelButton();
            string sRefValues = "Type;" + SERPLANFEEEVENT;
            Application.WebAdmin.CheckSpecifiedDataNotAvailableInTable(PlanFeesPage.tblPlanFeesHeader, PlanFeesPage.tblPlanFeesAction, sRefValues);
            Application.WebAdmin.ClickonAddButton();

            Report.Step("R102 -  If the user selects Event (FEECAT=2) from the Category dropdown on the Add Plan Fees page, then the event fields will be displayed on the add page.");
            List<string> values4 = new List<string>();
            values4.Add(PlanFeesPage.drpCategory + "|dropdown|" + Data.Get("GLOBAL_PLAN_FEE_CATEGORY_EVENT"));
            values4.Add(PlanFeesPage.drpEvent + "|dropdown|" + SERPLANFEEEVENT);
            values4.Add(PlanFeesPage.drpChargeOption + "|dropdown|" + Data.Get("GLOBAL_PLAN_FEE_CHARGE_OPTION_1"));
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(values4, FEEREQUIREDERRORMSG);

            Report.Step("R31-  If none of these fields are populated, then the following error message is returned: 'Any one of the fields Fixed Amount or Fee Schedule or Fee Table is required' while creating event plan fee.");
            List<string> values5 = new List<string>();
            values5.Add(PlanFeesPage.txtFixedAmount + "|field|" + PLANFEEFIXEDAMOUNT);
            values5.Add(PlanFeesPage.drpFeeSchedule + "|dropdown|" + SERPLANFEESCHEDULE);
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(values5, FEEONEERRORMSG);
            Application.WebAdmin.ClickonCancelButton();

            Report.Step("R33 -  Verify the message ‘‘The fees for the service fee plan have been created’ is displayed");
            Application.WebAdmin.ClickonAddButton();
            List<string> values6 = new List<string>();
            values6.Add(PlanFeesPage.drpCategory + "|dropdown|" + Data.Get("GLOBAL_PLAN_FEE_CATEGORY_EVENT"));
            values6.Add(PlanFeesPage.drpEvent + "|dropdown|" + SERPLANFEEEVENT);
            values6.Add(PlanFeesPage.drpChargeOption + "|dropdown|" + Data.Get("GLOBAL_PLAN_FEE_CHARGE_OPTION_1"));
            values6.Add(PlanFeesPage.txtFixedAmount + "|field|" + PLANFEEFIXEDAMOUNT);
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(values6, SUCCESSMSGFEEPLAN);

            Report.Step("Verify the user clicks the Edit button without selecting an existing Plan Fee, then the message ‘Please select a plan fee to view the queries’ is displayed");
            Application.WebAdmin.ClickonTabinProductPage("Parameters");
            Application.WebAdmin.ClickonTabinProductPage("Fees");
            Application.WebAdmin.ClickonEditButton();
            Application.WebAdmin.ActionOnPopButton(true, PLANFEEMODIFYMSG);

            Report.Step("Select the Event fee plan type to modify");
            Application.WebAdmin.SelecttheRadioButtoninTable(PlanFeesPage.tblPlanFeesAction, SERPLANFEEEVENT);
            Application.WebAdmin.ClickonEditButton();

            Report.Step("Modify the  Event fee with charge option other than Assess at End of Fee Period option");
            List<string> values7 = new List<string>();
            values7.Add(PlanFeesPage.drpChargeOption + "|dropdown|" + Data.Get("GLOBAL_PLAN_FEE_CHARGE_OPTION_2"));
            values7.Add(PlanFeesPage.txtFixedAmount + "|field|" + PLANFEEFIXEDAMOUNTUPDATE);
            Application.WebAdmin.EnterValuesInWebAdminSpecifiedPage(values7);

            Report.Step("Verify the Maximum Daily Amount is only available if the Charge Option is set to Direct Charge at Time of Service while modifying event plan fee.");
            Application.WebAdmin.CheckObjectEnabledTrue(PlanFeesPage.txtMaximumDialyAmount);
            Application.WebAdmin.ClickOnObject(WebAdminMasterPage.SubmitButton);

            Report.Step("Event  fees thorws  'Usage credit plans only assess on analysis (charge option 2) while modifying plan fee.");
            Application.WebAdmin.CheckSuccessMessage(FAILUREERRORMSG);
            Application.WebAdmin.ClickonCancelButton();

            Report.Step("Verify an event plan fee is not modified and it returns to Plan Fees List page after clicking on Cancel button");
            Application.WebAdmin.ClickonTabinProductPage("Parameters");
            Application.WebAdmin.ClickonTabinProductPage("Fees");
            Application.WebAdmin.CheckSpecifiedDataAvailableInTable(PlanFeesPage.tblPlanFeesHeader, PlanFeesPage.tblPlanFeesAction, sRefValues);
            Application.WebAdmin.SelecttheRadioButtoninTable(PlanFeesPage.tblPlanFeesAction, SERPLANFEEEVENT);
            Application.WebAdmin.ClickonEditButton();

            Report.Step("Modifying Event fee  again");
            List<string> values8 = new List<string>();
            values8.Add(PlanFeesPage.drpChargeOption + "|dropdown|" + Data.Get("GLOBAL_PLAN_FEE_CHARGE_OPTION_1"));
            values8.Add(PlanFeesPage.txtFixedAmount + "|field|");
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(values8, FEEREQUIREDERRORMSG);

            Report.Step("If more than one of the following fields are populated: Fixed Amount, Fee Schedule, Fee Table; then an error message is returned when selecting the Submit button: 'Only one of the fields Fixed Amount or Fee Schedule or Fee Table should be populated' while modifying event plan fee");
            List<string> values9 = new List<string>();
            values9.Add(PlanFeesPage.txtFixedAmount + "|field|" + PLANFEEFIXEDAMOUNTUPDATE);
            values9.Add(PlanFeesPage.drpFeeSchedule + "|dropdown|" + SERPLANFEESCHEDULE);
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(values9, FEEONEERRORMSG);

            Report.Step("Verify the message ‘'‘The fees for the service fee plan has been updated’  is displayed ");
            List<string> values10 = new List<string>();
            values10.Add(PlanFeesPage.txtFixedAmount + "|field|" + PLANFEEFIXEDAMOUNTUPDATE);
            values10.Add(PlanFeesPage.drpFeeSchedule + "|dropdown|" + Data.Get("GLOBAL_BLANK_OR_NULL"));
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(values10, SUCCESSMSGFEEPLAN_UPDATE);

            Report.Step("Logout from the Profile WebAdmin.");
            Application.WebAdmin.LogOutofWebAdmin();

        }
    }
}


