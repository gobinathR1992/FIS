using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.DepositFees
{

    [TestFixture]
    public class DepositFees066_TDSETUP : TestBase
    {

        [Test]
        [Property("TestDescription", "Creation of  service fee plan.")]
        public void DepositFees066TDSETUP()
        {
            string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string PWD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;

            const string SERVBALANCECOMPUTATION = "Average Collected Balance";
            const string SERVBASEFEEAMOUNT = "50";
            

            Report.Step("Login to WebAdmin Application.");
            Application.WebAdmin.LogintoWebAdmin(UID, PWD);
            string systemdate = Application.WebAdmin.GetApplicationDate();
            string SYSDATE_PLUS10 = Application.WebAdmin.CalculateNewDate(systemdate, "d", 10);

            Report.Step("Create New Service Fee Plan <SRV001>. with effective date: System date ,Plan Type :Debit Plan - Service Fees ,Plan description: OD Service Fee ,Balance Used For Fee Computation: Not applicable ,Base Fee Amount:100 (Table Configuration| Service Fee plans|Add.");
            List<string> lstservicedetails = new List<string>();
            int SRVN = Application.WebAdmin.RandomNumber(1000,10000);
            string SERVEFEEPLANDESC  = "SR"+SRVN;
            lstservicedetails.Add(PlanParametersPage.txtSericeFeePlan + "|field|");
            lstservicedetails.Add(PlanParametersPage.txtEffectiveDate + "|field|" + SYSDATE_PLUS10);
            lstservicedetails.Add(PlanParametersPage.txtPlanDescription + "|field|" + SERVEFEEPLANDESC);
            lstservicedetails.Add(PlanParametersPage.drpPlanType + "|dropdown|"+Data.Get("GLOBAL_PLAN_FEE_PLAN_TYPE1"));
            lstservicedetails.Add(PlanParametersPage.drpBalanceUsedFeeComputation + "|dropdown|"+SERVBALANCECOMPUTATION);
            lstservicedetails.Add(PlanParametersPage.txtBaseFeeAmount + "|field|"+SERVBASEFEEAMOUNT);
            string SERVEFEEPLANCP = Application.WebAdmin.CreateServiceFeePlan(lstservicedetails);

            Report.Step("Store service fee plan");
            Data.Store("SERVEFEEPLANCP", SERVEFEEPLANCP);

            Report.Step("Reload Webadmin and WebCSR applications");

            Report.Step("Logout from the Profile WebAdmin.");
            Application.WebAdmin.LogOutofWebAdmin();


        }
    }
}


