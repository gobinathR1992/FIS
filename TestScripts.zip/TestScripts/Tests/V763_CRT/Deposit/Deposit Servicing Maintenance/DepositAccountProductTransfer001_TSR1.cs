using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using Profile7Automation.ObjectFactory.WebCSR;
using GTS_OSAF.CoreLibs;


namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.DespositAccountProductTransfer
{

    [TestFixture]
    public class DespositAccountProductTransfer001_TSR1 : TestBase
    {

        [Test]
        [Property("TestDescription", " Verify a deposit account can be transfered from one product type to another product type in the same group and denominated in the same currency.")]
        public void DespositAccountProductTransfer01_TSR1()
        {

            string DDPROD_NUM1 = Data.Fetch("DepositProductNum", "DDPROD_NUM1");
            string DDPROD_NUM2 = Data.Fetch("DepositProductNum", "DDPROD_NUM2");
            string DDPROD_NAME1 = Data.Fetch("DepositProductName", "DDPROD_NAME1");
            string DDPROD_NAME2 = Data.Fetch("DepositProductName", "DDPROD_NAME2");

	        string To_Nickname="Checking Product B";
            string TRANSACTION_RESTRICTION_6="Restrict Both Debits and Credits Outside the Grace Period";

            string sGLOBAL_USERID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string sGLOBAL_PASSWORD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;

            // Step 1.0: Login to the Profile WebAdmin.
            Report.Step("Login to the Profile WebCSR.");
            Application.WebCSR.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));
            string SystemdateMinus365Days = Application.WebCSR.CalculateBackOrFutureDateFromApplication("AdministrationCenterTable","d",-365);

            // Step 2.0: Create a new Create Personal Customer with all required fields.
            Report.Step("Create a new Create Personal Customer with all required fields.");
            string sCustomerNumber = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            // Step 3.0: Create a DDA account <DDAACCN1> using copied DDA product type <DDPROD_NUM1> for the customer <CIF> with following inputs: Opening Date: System Date; Opening Deposit: 10000.00; Currency Code: United States Dollars; Funding Account: Null (Basic Services |Create Account).
            Report.Step("Create a DDA account <DDAACCN1> using copied DDA product type <DDPROD_NUM1> for the customer <CIF> with following inputs: Opening Date: System Date; Opening Deposit: 10000.00; Currency Code: United States Dollars; Funding Account: Null (Basic Services |Create Account).");
            string[] DDA_DEPOIST_ACCOUNT_DETAILS = new string[11];
            DDA_DEPOIST_ACCOUNT_DETAILS[0] = Data.Get("GLOBAL_BLANK_OR_NULL");
            DDA_DEPOIST_ACCOUNT_DETAILS[1] = Data.Get("GLOBAL_BLANK_OR_NULL");
            DDA_DEPOIST_ACCOUNT_DETAILS[2] = Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K");
            DDA_DEPOIST_ACCOUNT_DETAILS[3] = Data.Get("GLOBAL_CURRENCY_CODE_USD");
            string DDAACCN1 = Application.WebCSR.CreateAccount(Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"), Data.Get("GLOBAL_RELATION_SINGLE"), DDPROD_NAME1, sCustomerNumber, DDA_DEPOIST_ACCOUNT_DETAILS);

            // Step 4.0: Navigate to the Deposit Product Transfer page and select the From And To Accounts in Dropdown.
            Report.Step("Navigate to the Deposit Product Transfer page and select the From And To Accounts in Dropdown.");
            Application.WebCSR.ActionsinDepositProductTransferPage(DDPROD_NAME1,DDAACCN1);
            Application.WebCSR.ActionsinDepositProductTransferPage(DDPROD_NAME2,null,DDPROD_NUM2);
            Application.WebCSR.ClickonContinueButton();
            Application.WebCSR.ClickonContinueButton();
            Application.WebCSR.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 5.0:  Navigate to the Account Overview page of Savings account <SAVACCT> (Search for the customer <CIF1> on the Customer Search page | Select Account List from go to drop-down and click Submit | Select the link for account <SAVACCT> on the Account List page
            Report.Step("Navigate to the Account Overview page of Savings account <SAVACCT> (Search for the customer <CIF1> on the Customer Search page | Select Account List from go to drop-down and click Submit | Select the link for account <SAVACCT> on the Account List page.");
            Application.WebCSR.GetAccount(DDAACCN1);
            
            // Step 6.0: Navigate to the FDIC 370 page (Account Information | General).
            Report.Step("Navigate to the FDIC 370 page (Account Information | General.");
            Application.WebCSR.ClickTabInDepositAccountOverviewPage("Account Summary");

            // Step 7.0: Expected Result (R50): Verify that a deposit account <DDAACCN1> is transferred from one product type <DDPROD_NUM1> to another product type <DDPROD_NUM2> in the same group and denominated in the same currency.
            Report.Step("Expected Result (R50): Verify that a deposit account <DDAACCN1> is transferred from one product type <DDPROD_NUM1> to another product type <DDPROD_NUM2> in the same group and denominated in the same currency.");
            Application.WebCSR.CheckExpectedValueinEditField(DepositAccountInformationPage.txtAccountInformationName, To_Nickname);

            // Step 8.0: Expected Result (R50): Verify that a deposit account <DDAACCN1> is transferred from one product type <DDPROD_NUM1> to another product type <DDPROD_NUM2> in the same group and denominated in the same currency.
            Report.Step("Expected Result (R50): Verify that a deposit account <DDAACCN1> is transferred from one product type <DDPROD_NUM1> to another product type <DDPROD_NUM2> in the same group and denominated in the same currency.");
            Application.WebCSR.CheckExpectedValueinEditField(DepositAccountInformationPage.txtAccountInformationName, To_Nickname);

            // Step 9.0: Navigate to the Transaction processing Page (Account Information | Transaction processing).
            Report.Step("Navigate to the Transaction processing Page (Account Information | Transaction processing.");
            Application.WebCSR.ClickTabInAccountInformationPage("Transaction processing");
  
            // Step 10.0: Verify the Minimum Balance, Maximum Balance and Transaction Restriction in Transaction processing Page.
            Report.Step("Verify the Minimum Balance, Maximum Balance and Transaction Restriction in Transaction processing Page.");
            Application.WebCSR.CheckExpectedValueinEditField(DepositTransactionProcessingGeneralPage.txtTransactionRestrictionsMinimumBalance, Data.Get("GLOBAL_VALUE_200"));
            Application.WebCSR.CheckExpectedValueinEditField(DepositTransactionProcessingGeneralPage.txtTransactionRestrictionsMaximumBalance, Data.Get("GLOBAL_TRANSACTION_AMOUNT_900"));
            Application.WebCSR.CheckExpectedValueinDropdown(DepositTransactionProcessingGeneralPage.drpTransactionRestrictionsProcessRestriction, TRANSACTION_RESTRICTION_6);

            //Step 11.0:Logout to WebCSR Application.
            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();

        }
    }
}