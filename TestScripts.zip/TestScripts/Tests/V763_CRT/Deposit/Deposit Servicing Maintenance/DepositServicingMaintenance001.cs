using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using NUnit.Framework;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using Profile7Automation.ObjectFactory.WebCSR;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.DepositServicingMaintenance
{
    [TestFixture]
    public class DepositServicingMaintenance001 : TestBase
    {

        [Test]
        [Property("TestDescription", "Adding, Modifying and Deleting Account Details.")]
        public void DepositServicingMaintenance01()
        {
           string testersname = "CHANDRA";
           string customercode1 = "0 - Rate Code Zero";
           string customercode2 = "2 - Preferred Customer";
           string companycode1 = "FIS - Fidelity Information Services";
           string companycode2 = "SCA - Sanchez Computer Associates";
           string attentionmessage1 = "Next Inquiry Postponed";
           string attentionmessage2 = "Write Message";
           string costcenter1 = "0 - BACK OFFICE COST CENTER";
           string branchname1 = "0 - BACK OFFICE 0";
           string accountstatusInactive = "1 - Inactive";
           string accountstatusclosed = "4 - Closed";
           string accountsttausactive = "0 - Active";
           string closedreason = "2 - Moving";
           //string blank = "#0";
           string warning = "Unable to close - balance = 10000";

            string sGLOBAL_USERID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string sGLOBAL_PASSWORD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            string sCustomerNumber = null;

            // Step 1.0: Login to the Profile WebCSR.
            Report.Step("Login to the Profile WebCSR.");
            Application.WebCSR.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));
            string System_Date = WebCSRPageFactory.WebCSRMasterPage.GetApplicationDate();

            // Step 2.0: Create a new Create Personal Customer with all required fields.
            Report.Step("Create a new Create Personal Customer with all required fields.");
            sCustomerNumber = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            // Step 3.0: Create a Savings account <SAVAccnum> using the standard Savings product type <Statement Savings 300> for the Personal customer <CIF1> with following values: Name: SAV; Opening Date: <System Date>; Opening Deposit: USD 100; Currency: USD (Profile WebCSR | Basic Services | Create account).
            Report.Step("Create a Savings account <SAVAccnum> using the standard Savings product type <Statement Savings 300> for the Personal customer <CIF1> with following values: Name: SAV; Opening Date: <System Date>; Opening Deposit: USD 100; Currency: USD (Profile WebCSR | Basic Services | Create account).");
            string[] SAV_DEPOIST_ACCOUNT_DETAILS = new string[11];
            SAV_DEPOIST_ACCOUNT_DETAILS[0] = Data.Get("GLOBAL_BLANK_OR_NULL");
            SAV_DEPOIST_ACCOUNT_DETAILS[1] = Data.Get("GLOBAL_BLANK_OR_NULL");
            SAV_DEPOIST_ACCOUNT_DETAILS[2] = Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K");
            SAV_DEPOIST_ACCOUNT_DETAILS[3] = Data.Get("GLOBAL_CURRENCY_CODE_USD");
            string SAVACCT = Application.WebCSR.CreateAccount(Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"), Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), sCustomerNumber, SAV_DEPOIST_ACCOUNT_DETAILS);

            // Step 4.0: Log out of Profile WebCSR and close the browser.
            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();

            // Step 5.0: Login to PD TELLER Application.
            Report.Step("Login to PD TELLER Application.");
            Application.Teller.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));

            // Step 6.0: Post a Deposit transaction to the Savings Account <SAVACCT_ERCR001> for 10,000.00 using Transaction Code SD (Savings Deposit). Offset the transaction using Transaction Code CI.
            Report.Step("Post a Deposit transaction to the Savings Account <SAVACCT_ERCR001> for 10,000.00 using Transaction Code SD (Savings Deposit). Offset the transaction using Transaction Code CI.");
            string[]  ActionEntriesArr1 = new string [7];
            ActionEntriesArr1 [0] = SAVACCT;
            ActionEntriesArr1 [1] = Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K");
            ActionEntriesArr1 [3] = Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K");
            Application.Teller.enter_teller_deposit_details(System_Date, ActionEntriesArr1);

            // Step 7.0: Post the Teller Details.
            Report.Step("Post the Teller Details.");
            Application.Teller.post_teller_details("NO");

            // Step 8.0: Login to the Profile WebCSR.
            Report.Step("Login to the Profile WebCSR.");
            Application.WebCSR.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));

            //Step 9.0:  Navigate to the Account Overview page of Savings account <SAVACCT> (Search for the customer <CIF1> on the Customer Search page | Select Account List from go to drop-down and click Submit | Select the link for account <SAVACCT> on the Account List page
            Report.Step("Navigate to the Account Overview page of Savings account <SAVACCT> (Search for the customer <CIF1> on the Customer Search page | Select Account List from go to drop-down and click Submit | Select the link for account <SAVACCT> on the Account List page.");
            Application.WebCSR.GetAccount(SAVACCT);
            
            // Step 10.0: Navigate to the Title/Address page (Account Information | Title/Address).
            Report.Step("Navigate to the Title/Address page (Account Information | Title/Address).");
            Application.WebCSR.ClickTabInDepositAccountOverviewPage("Account Summary");
            Application.WebCSR.ClickTabInAccountInformationPage("Title/Address");

            //Step 11.0: Update the Account Title 1, Title 2, title 3 and Title 4 fields to Tester name and update the address details.
            Report.Step("Update the Account Title 1, Title 2, title 3 and Title 4 fields to Tester name and update the address details.");
            List<string> TitleDetails = new List<string>();
            TitleDetails.Add(DepositTitleAddressPage.txtAccountTitle1 + "|field|" + testersname);
            TitleDetails.Add(DepositTitleAddressPage.txtAccountTitle2 + "|field|" + testersname);
            TitleDetails.Add(DepositTitleAddressPage.txtAccountTitle3 + "|field|" + testersname);
            TitleDetails.Add(DepositTitleAddressPage.txtAccountTitle4 + "|field|" + testersname);
            TitleDetails.Add(DepositTitleAddressPage.txtTitleAddressMailingAddressAddress1 + "|field|" + testersname);
            TitleDetails.Add(DepositTitleAddressPage.txtTitleAddressMailingAddressCity + "|field|" + Data.Get("GLOBAL_ADDLINE2"));
            TitleDetails.Add(DepositTitleAddressPage.drpTitleAddressMailingAddressCountry + "|dropdown|" + Data.Get("GLOBAL_ADDCOUNTRY"));
            TitleDetails.Add(DepositTitleAddressPage.drpTitleAddressMailingAddressState + "|dropdown|" + Data.Get("GLOBAL_ADDSTATE"));
            TitleDetails.Add(DepositTitleAddressPage.txtTitleAddressMailingAddressZipCode + "|field|" + Data.Get("GLOBAL_ADDZIP"));

            //Step 12.0: Expected Result (TC 08): Verify that the message “The information has been updated" appears.
            Report.Step("Expected Result (TC 08): Verify that the message “The information has been updated");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(TitleDetails, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            // Step 13.0: Navigate to the Title/Address page (Account Information | Title/Address).
            Report.Step("Navigate to the Title/Address page (Account Information | Title/Address).");
            Application.WebCSR.ClickTabInAccountInformationPage("General");

            //Step 14.0:Update the Company Code as <FIS - Fidelity Information services>, Customer code as <2 - Preferred Customer> and Attention message as <Next Inquiry Postponed>
            Report.Step("Update the Company Code as <FIS - Fidelity Information services>, Customer code as <2 - Preferred Customer> and Attention message as <Next Inquiry Postponed>");
            List<string> GenDetails = new List<string>();
            GenDetails.Add(DepositAccountInformationPage.txtAttention + "|field|" + attentionmessage1);
            GenDetails.Add(DepositAccountInformationPage.drpCompanyCode + "|dropdown|" + companycode1);
            GenDetails.Add(DepositAccountInformationPage.drpCustomerCode + "|dropdown|" + customercode2);

            //Step 15.0: Expected Result (TC 08): Verify that the message “The information has been updated" appears.
            Report.Step("Expected Result (TC 08): Verify that the message “The information has been updated");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(GenDetails, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 16.0:Verify the Company Code and Customer Codes are Added.
            Report.Step("Verify the Company Code and Customer Codes are Added.");
            Application.WebCSR.CheckExpectedValueinDropdown(DepositAccountInformationPage.drpCompanyCode, companycode1);
            Application.WebCSR.CheckExpectedValueinDropdown(DepositAccountInformationPage.drpCustomerCode, customercode2);

            //Step 17.0:Verify the Attention Message is Added.
            Report.Step("Verify the Attention Message is Added.");
            Application.WebCSR.CheckExpectedValueinEditField(DepositAccountInformationPage.txtAttention,attentionmessage1);

            // Step 18.0: Navigate to the Title/Address page (Account Information | Title/Address).
            Report.Step("Navigate to the Title/Address page (Account Information | Title/Address).");
            Application.WebCSR.ClickTabInAccountInformationPage("Title/Address");
            
            //Step 19.0:Verify the Account Title1, Title2, Title3 and Title4 are Added.
            Report.Step("Verify the Account Title1, Title2, Title3 and Title4 are Added.");
            Application.WebCSR.CheckExpectedValueinEditField(DepositTitleAddressPage.txtAccountTitle1,testersname);
            Application.WebCSR.CheckExpectedValueinEditField(DepositTitleAddressPage.txtAccountTitle2,testersname);
            Application.WebCSR.CheckExpectedValueinEditField(DepositTitleAddressPage.txtAccountTitle3,testersname);
            Application.WebCSR.CheckExpectedValueinEditField(DepositTitleAddressPage.txtAccountTitle4,testersname);

            //Step 20.0: Update the Account Title 2, title 3 and Title 4 fields to NULL.
            Report.Step("Update the Account Title 2, title 3 and Title 4 fields to NULL.");
            List<string> TitleDetails1 = new List<string>();
            TitleDetails1.Add(DepositTitleAddressPage.txtAccountTitle2 + "|field|" + "");
            TitleDetails1.Add(DepositTitleAddressPage.txtAccountTitle3 + "|field|" + "");
            TitleDetails1.Add(DepositTitleAddressPage.txtAccountTitle4 + "|field|" + "");

            //Step 21.0: Expected Result (TC 08): Verify that the message “The information has been updated" appears.
            Report.Step("Expected Result (TC 08): Verify that the message “The information has been updated");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(TitleDetails1, Data.Get("GLOBAL_INFORMATION_UPDATED"));
            
            // Step 22.0: Navigate to the Title/Address page (Account Information | General).
            Report.Step("Navigate to the Title/Address page (Account Information | General.");
            Application.WebCSR.ClickTabInAccountInformationPage("General");

            //Step 23.0:Update the Cost Center as <0 - BACK OFFICE COST CENTER>, Branch as <0 - BACK OFFICE 0>, Company code as <SCA - Sanchez Computer Associates>, Customer code as <1 – Regular Customer> and attention message as <Write Message>
            Report.Step("Update the Cost Center as <0 - BACK OFFICE COST CENTER>, Branch as <0 - BACK OFFICE 0>, Company code as <SCA - Sanchez Computer Associates>, Customer code as <1 – Regular Customer> and attention message as <Write Message>");
            List<string> GenDetails1 = new List<string>();
            GenDetails1.Add(DepositAccountInformationPage.txtAttention + "|field|" + attentionmessage2);
            GenDetails1.Add(DepositAccountInformationPage.drpCompanyCode + "|dropdown|" + companycode2);
            GenDetails1.Add(DepositAccountInformationPage.drpCustomerCode + "|dropdown|" + customercode1);
            GenDetails1.Add(DepositAccountInformationPage.drpCostcenter + "|dropdown|" + costcenter1);
            GenDetails1.Add(DepositAccountInformationPage.drpBranch + "|dropdown|" + branchname1);

            //Step 24.0: Expected Result (TC 08): Verify that the message “The information has been updated" appears.
            Report.Step("Expected Result (TC 08): Verify that the message “The information has been updated");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(GenDetails1, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 25.0: Navigate to the Account Activity page and update the Account status to <Inactive>
            Report.Step("Navigate to the Account Activity page and update the Account status to <Inactive>");
            Application.WebCSR.ClickTabInAccountInformationPage("General", DepositAccountInformationPage.lnkAccountActivity);
            List<string> GenDetails2 = new List<string>();
            GenDetails2.Add(AccountActivityPage.drpAccountStatus + "|dropdown|" + accountstatusInactive);
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(GenDetails2, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 26.0:Verify the Cost Center, Branch Code, Company Code, Customer code and Attention messages are Modified.
            Report.Step("Verify the Cost Center, Branch Code, Company Code, Customer code and Attention messages are Modified.");
            Application.WebCSR.ClickTabInAccountInformationPage("General", DepositAccountInformationPage.lnkGeneral);
            Application.WebCSR.CheckExpectedValueinDropdown(DepositAccountInformationPage.drpCompanyCode, companycode2);
            Application.WebCSR.CheckExpectedValueinDropdown(DepositAccountInformationPage.drpCustomerCode, customercode1);
            Application.WebCSR.CheckExpectedValueinDropdown(DepositAccountInformationPage.drpCostcenter, costcenter1);
            Application.WebCSR.CheckExpectedValueinDropdown(DepositAccountInformationPage.drpBranch, branchname1);
            Application.WebCSR.CheckExpectedValueinEditField(DepositAccountInformationPage.txtAttention,attentionmessage2);

            //Step 27.0: Verify the Account Status as <InActive> and Account Activity Page.
            Report.Step("Verify the Account Status as <InActive> and Account Activity Page.");
            Application.WebCSR.ClickTabInAccountInformationPage("General", DepositAccountInformationPage.lnkAccountActivity);
            Application.WebCSR.CheckExpectedValueinDropdown(AccountActivityPage.drpAccountStatus, accountstatusInactive);
            
            //Step 28.0:Verify the Date Closed Field is Protected.
            Report.Step("Verify the Date Closed Field is Protected.");
            string OutPutValue1 = Application.WebCSR.GetCellValueByLabel("Date Closed:");
            Application.WebCSR.comparestringvalues(Data.Get("GLOBAL_BLANK_OR_NULL"), OutPutValue1);

            // Step 29.0: Navigate to the Title/Address page (Account Information | Title/Address).
            Report.Step("Navigate to the Title/Address page (Account Information | Title/Address).");
            Application.WebCSR.ClickTabInAccountInformationPage("Title/Address");

            //Step 30.0: Verify the Account Title2, Title3, Titl4 as Modified to NULL.
            Report.Step("Verify the Account Title2, Title3, Titl4 as Modified to NULL.");
            Application.WebCSR.CheckExpectedValueinEditField(DepositTitleAddressPage.txtAccountTitle2,"");
            Application.WebCSR.CheckExpectedValueinEditField(DepositTitleAddressPage.txtAccountTitle3,"");
            Application.WebCSR.CheckExpectedValueinEditField(DepositTitleAddressPage.txtAccountTitle4,"");

            // Step 31.0: Navigate to the Title/Address page (Account Information | General).
            Report.Step("Navigate to the Title/Address page (Account Information | General.");
            Application.WebCSR.ClickTabInAccountInformationPage("General");

            //Step 32.0:Select the Company Code, Customer Code drop downs as <Blank> and update the Attention message as <NULL> in Account Information page.
            Report.Step("Select the Company Code, Customer Code drop downs as <Blank> and update the Attention message as <NULL> in Account Information page.");
            List<string> GenDetails3 = new List<string>();
            GenDetails3.Add(DepositAccountInformationPage.txtAttention + "|field|" + "");
            GenDetails3.Add(DepositAccountInformationPage.drpCompanyCode + "|dropdown|" + "");
            GenDetails3.Add(DepositAccountInformationPage.drpCustomerCode + "|dropdown|" + "");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(GenDetails3, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            // Step 33.0: Verify Attention message is deleted. 
            Report.Step("Verify Attention message is deleted.");
            Application.WebCSR.Checkeditblanktrue(DepositAccountInformationPage.txtAttention);

            //Step 34.0: Navigate to the Account Activity page and update the Account status to <Closed>
            Report.Step("Navigate to the Account Activity page and update the Account status to <Closed>");
            Application.WebCSR.ClickTabInAccountInformationPage("General", DepositAccountInformationPage.lnkAccountActivity);
            List<string> GenDetails4 = new List<string>();
            GenDetails4.Add(AccountActivityPage.drpAccountStatus + "|dropdown|" + accountstatusclosed);
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(GenDetails4, warning);

            //Step 35.0: Navigate to the Account Activity page and update the Account status to <Active>
            Report.Step("Navigate to the Account Activity page and update the Account status to <Closed>");
            List<string> GenDetails5 = new List<string>();
            GenDetails5.Add(AccountActivityPage.drpAccountStatus + "|dropdown|" + accountsttausactive);
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(GenDetails5, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            // Step 36.0: Log out of Profile WebCSR and close the browser.
            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();

            // Step 37.0: Post a Debit transaction to the Savings Account <SAVACCT_ERCR001> for Amount: 2,000.00.
            Report.Step("Post a Debit transaction to the Savings Account <SAVACCT_ERCR001> for Amount: 2,000.00");
            string[]  ActionEntriesArr7 = new string [7];
            ActionEntriesArr7[0] = SAVACCT;                        
            ActionEntriesArr7[1] = Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K");
            ActionEntriesArr7[2] = Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K");
            Application.Teller.enter_teller_withdraw_details(System_Date, ActionEntriesArr7);

            // Step 38.0: Post the Teller Details.
            Report.Step("Post the Teller Details.");
            Application.Teller.post_teller_details(Data.Get("GLOBAL_OVERRIDE_NO"));

            // Step 39.0: Login to the Profile WebCSR.
            Report.Step("Login to the Profile WebCSR.");
            Application.WebCSR.Login(sGLOBAL_USERID, sGLOBAL_PASSWORD, Data.Get("GLOBAL_BRANCH"));

            //Step 40.0:  Navigate to the Account Overview page of Savings account <SAVACCT> (Search for the customer <CIF1> on the Customer Search page | Select Account List from go to drop-down and click Submit | Select the link for account <SAVACCT> on the Account List page
            Report.Step("Navigate to the Account Overview page of Savings account <SAVACCT> (Search for the customer <CIF1> on the Customer Search page | Select Account List from go to drop-down and click Submit | Select the link for account <SAVACCT> on the Account List page.");
            Application.WebCSR.GetAccount(SAVACCT);
            Application.WebCSR.ClickTabInDepositAccountOverviewPage("Account Summary");
            Application.WebCSR.ClickTabInAccountInformationPage("General", DepositAccountInformationPage.lnkAccountActivity);

            //Step 41.0: Navigate to the Account Activity page and update the Account status to <Active>
            Report.Step("Navigate to the Account Activity page and update the Account status to <Closed>");
            List<string> GenDetails6 = new List<string>();
            GenDetails6.Add(AccountActivityPage.drpAccountStatus + "|dropdown|" + accountstatusclosed);
            GenDetails6.Add(AccountActivityPage.drpCloseoutReason + "|dropdown|" + closedreason);
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(GenDetails6, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 42.0: Verify Closeout Reason is modified.
            Report.Step("Verify Closeout Reason is modified.");
            Application.WebCSR.CheckExpectedValueinDropdown(AccountActivityPage.drpCloseoutReason, closedreason);

            //Step 43.0: Verify Closeout Reason is Deleted.
            Report.Step("Verify Closeout Reason is Deleted.");
            List<string> GenDetails7 = new List<string>();
            GenDetails7.Add(AccountActivityPage.drpCloseoutReason + "|dropdown|" + "");
            Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(GenDetails7, Data.Get("GLOBAL_INFORMATION_UPDATED"));
            Application.WebCSR.CheckExpectedValueinDropdown(AccountActivityPage.drpCloseoutReason, "");

            // Step 44.0: Log out of Profile WebCSR and close the browser.
            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();

        }
    }
}

