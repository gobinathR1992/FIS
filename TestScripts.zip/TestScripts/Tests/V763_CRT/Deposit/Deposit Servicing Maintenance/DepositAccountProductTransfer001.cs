using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.TestScripts.Tests.V763_CRT.Deposit.DespositAccountProductTransfer
{

    [TestFixture]
    public class DespositAccountProductTransfer001 : TestBase
    {

        [Test]
        [Property("TestDescription", " Verify a deposit account can be transfered from one product type to another product type in the same group and denominated in the same currency.")]
        public void DespositAccountProductTransfer01()
        {
            string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string PWD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;

            string From_Nickname="Checking Product A";
	        string To_Nickname="Checking Product B";
            string TRANSACTION_RESTRICTION_6="Restrict Both Debits and Credits Outside the Grace Period";
	        string TRANSACTION_RESTRICTION_7="Restrict All Debits After the Initial Debit";

            //Step 1.0:Login to WebAdmin Application.
            Report.Step("Login to WebAdmin Application.");
            Application.WebAdmin.LogintoWebAdmin(UID, PWD);
            string SystemdateMinus365Days = Application.WebCSR.CalculateBackOrFutureDateFromApplication("AdministrationCenterTable","d",-365);

            //Step 2.0:"In WebAdmin, copy 2 DDA products <DDPROD_NUM1> and <DDPROD_NUM2> of type 400 of same group and denominated in the same currency:USD. (Product Factory | Products | Product Class:D - Deposit Accounts; Product Group:DDA - Demand Deposits.
            Report.Step("In WebAdmin, copy 2 DDA products <DDPROD_NUM1> and <DDPROD_NUM2> of type 400 of same group and denominated in the same currency:USD. (Product Factory | Products | Product Class:D - Deposit Accounts; Product Group:DDA - Demand Deposits.");
            string DDPROD_NAME1= "DDA";
	        string DDPROD_NAME2= "DDA";
            string DDPROD_NUM1  = Application.WebAdmin.enter_copy_product_definition_details(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), Data.Get("GLOBAL_STAND_ADMINPROD_DESC_400"), DDPROD_NAME1, false);
            string DDPROD_NUM2  = Application.WebAdmin.enter_copy_product_definition_details(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), Data.Get("GLOBAL_STAND_ADMINPROD_DESC_400"), DDPROD_NAME2, false);

            // Step 3.0: Navigate to the Deposit Product - General tab by editing the copied product <DDPROD_NUM1> and set Nickname: Checking Product A (Product Factory | Products | <DDPROD_NUM1>).
            Report.Step("Navigate to the Deposit Product - General tab by editing the copied product <DDPROD_NUM1> and set Nickname: Checking Product A (Product Factory | Products | <DDPROD_NUM1>).");
            Application.WebAdmin.GetProduct(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), DDPROD_NUM1);
            List<string> ProdDetails = new List<string>();
            ProdDetails.Add(WebAdminProductsGeneralPage.txtGeneralInformationNickNameField + "|field|" + From_Nickname);
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(ProdDetails, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            // Step 4.0: Select the Transaction Processing tab and set Minimum Balance: 500; Maximum Balance: 10000; Process Restriction:7 - Restrict All Debits After the Initial Debit.).
            Report.Step("Select the Transaction Processing tab and set Minimum Balance: 500; Maximum Balance: 10000; Process Restriction:7 - Restrict All Debits After the Initial Debit.");
            Application.WebAdmin.ClickonTabinProductPage("Transaction Processing");
            List<string> ProdDetails2 = new List<string>();
            ProdDetails2.Add(WebAdminProductsTransactionProcessingPage.ckbTransactionAcceptancePositivePayArsEligible + "|CHECKBOX|" + "OFF");
            ProdDetails2.Add(WebAdminProductsTransactionProcessingPage.txtTransactionRestrictionsMinimumBalance + "|field|" + Data.Get("GLOBAL_VALUE_500"));
            ProdDetails2.Add(WebAdminProductsTransactionProcessingPage.txtTransactionRestrictionsMaximimBalance + "|field|" + Data.Get("GLOBAL_TRANSACTION_AMOUNT_1000"));
            ProdDetails2.Add(WebAdminProductsTransactionProcessingPage.drpTransactionRestrictionsProcessRestriction + "|dropdown|" + TRANSACTION_RESTRICTION_7);
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(ProdDetails2, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            // Step 5.0: Navigate to the Deposit Product - General tab by editing the copied product <DDPROD_NUM2> and set Nickname: Checking Product B (Product Factory | Products | <DDPROD_NUM2>).
            Report.Step("Navigate to the Deposit Product - General tab by editing the copied product <DDPROD_NUM2> and set Nickname: Checking Product B (Product Factory | Products | <DDPROD_NUM2>");
            Application.WebAdmin.GetProduct(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), DDPROD_NUM2);
            List<string> ProdDetail3 = new List<string>();
            ProdDetail3.Add(WebAdminProductsGeneralPage.txtGeneralInformationNickNameField + "|field|" + To_Nickname);
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(ProdDetail3, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            // Step 6.0: Select the Transaction Processing tab, and set Minimum Balance: 200; Maximum Balance: 90000; Process Restriction:6 - Restrict Both Debits and Credits Outside the Grace Period.).
            Report.Step("Select the Transaction Processing tab, and set Minimum Balance: 200; Maximum Balance: 90000; Process Restriction:6 - Restrict Both Debits and Credits Outside the Grace Period.");
            Application.WebAdmin.ClickonTabinProductPage("Transaction Processing");
            List<string> ProdDetails4 = new List<string>();
            ProdDetails4.Add(WebAdminProductsTransactionProcessingPage.ckbTransactionAcceptancePositivePayArsEligible + "|CHECKBOX|" + "OFF");
            ProdDetails4.Add(WebAdminProductsTransactionProcessingPage.txtTransactionRestrictionsMinimumBalance + "|field|" + Data.Get("GLOBAL_VALUE_200"));
            ProdDetails4.Add(WebAdminProductsTransactionProcessingPage.txtTransactionRestrictionsMaximimBalance + "|field|" + Data.Get("GLOBAL_TRANSACTION_AMOUNT_900"));
            ProdDetails4.Add(WebAdminProductsTransactionProcessingPage.drpTransactionRestrictionsProcessRestriction + "|dropdown|" + TRANSACTION_RESTRICTION_6);
            Application.WebAdmin.UpdateInformationInWebAdminSpecifiedPage(ProdDetails4, Data.Get("GLOBAL_INFORMATION_UPDATED"));

            //Step 7.0:Logout to WebAdmin Application.
            Report.Step("Logout WebAdmin Application.");
            Application.WebAdmin.LogOutofWebAdmin();

            //Step 8.0:Store the Data in Data sheet
            Report.Step("Store the Data in Data sheet");
            Data.Store("DepositProductNum",DDPROD_NUM1);
            Data.Store("DepositProductNum",DDPROD_NUM2);
            Data.Store("DepositProductName",DDPROD_NAME1);
            Data.Store("DepositProductName",DDPROD_NAME2);

        }
    }
}