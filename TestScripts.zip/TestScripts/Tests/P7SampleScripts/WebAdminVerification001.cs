using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.TestScripts.Tests.P7SampleScripts
{

    [TestFixture]
    public class WebAdminVerification: TestBase
    {

        [Test]
        [Property("TestDescription", "To Verify integration of Business Function in WebAdmin")]
        public void WebAdminVerification001()
        {
            WebApplication appHandle;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            Report.Step("Login to WebAdmin Application.");
            Application.WebAdmin.LogintoWebAdmin("1", "xxx");
            string System_Date = WebAdminPageFactory.WebAdminMasterPage.GetAppDate();
            string sysplusone = appHandle.CalculateNewDate(System_Date, "d", 1);

            Report.Step("Add a Relationship code.");
            List<string> RelationshipDetails = new List<string>();
            RelationshipDetails.Add(RelationshipCodePage.txtRelationshipCode + "|field|");
            RelationshipDetails.Add(RelationshipCodePage.txtRelationshipCodeDescription + "|field|RcodeDesc");
            string ColName = "Row No;Description;Maximum cif;minimum cif;Fdic Relationship code;customer type;customer sub-type;customer product;Suffix;SS;Primary Owner;Bureau Report Relation;Direct Liability;SignatureCard";
            List<string> RoleDetails = new List<string>();
            RoleDetails.Add("1;test1;2;1;;PERSON - Personal;INDV - Individual;0 - Personal;suftes;on;off;on;on;on");
            RoleDetails.Add("2;test1;1;1;;PERSON - Personal;INDV - Individual;0 - Personal;;on;on;on;off;on");
            string Rcod = Application.WebAdmin.AddRelationshipCode(Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"), RelationshipDetails, ColName, RoleDetails);

            Report.Step("Modify above Relationship code.");
            List<string> RelationshipDetails1 = new List<string>();
            RelationshipDetails1.Add(RelationshipCodePage.txtRelationshipCodeDescription + "|field|RcodeDesc1");
            RelationshipDetails1.Add(RelationshipCodePage.txtLegalTitleDescription + "|field|LegaDesc1");
            List<string> RoleDetails1 = new List<string>();
            RoleDetails1.Add("1;test2;2;1;;PERSON - Personal;INDV - Individual;0 - Personal;suftes;on;off;on;on;off");
            RoleDetails1.Add("2;test1;1;1;;PERSON - Personal;INDV - Individual;0 - Personal;;on;on;on;off;off");
            Application.WebAdmin.ModifyRelationshipCode(Rcod, RelationshipDetails1, ColName, RoleDetails1);

            Report.Step("Create a Service Fee Plan.");
            List<string> lstservicedetails = new List<string>();
            lstservicedetails.Add(PlanParametersPage.txtSericeFeePlan + "|field|");
            lstservicedetails.Add(PlanParametersPage.txtEffectiveDate + "|field|" + System_Date);
            lstservicedetails.Add(PlanParametersPage.txtPlanDescription + "|field|Desc");
            lstservicedetails.Add(PlanParametersPage.drpPlanType + "|dropdown|Credit Plan - Usage Credits");
            lstservicedetails.Add(PlanParametersPage.drpBalanceUsedFeeComputation + "|dropdown|Not Applicable");
            lstservicedetails.Add(PlanParametersPage.txtBaseFeeAmount + "|field|100");
            string Splan = Application.WebAdmin.CreateServiceFeePlan(lstservicedetails);

            Report.Step("Copy above Service Fee Plan.");
            string SCplan = Application.WebAdmin.CopyServiceFeePlan(Splan, System_Date, sysplusone);

            Report.Step("Navigate to Copied Service Fee Plan Effective Date List Page.");
            Application.WebAdmin.NavigateToServiceFeePlanEffectiveDateListPage(SCplan);

            Report.Step("Copy transaction code.");
            string Tcod = Application.WebAdmin.CopyTransactionCode("D - Deposit", "SAV - Savings", "sd");

            Report.Step("Authorize above Copied transaction code.");
            Application.WebAdmin.AuthorizeTransactionCode("D - Deposit", Tcod, "SCA;on;on;on", "SAV - Savings");
            Application.WebAdmin.AuthorizeTransactionCode("D - Deposit", Tcod, "MGR;on;off;on", "SAV - Savings");

            Report.Step("Modified above Copied transaction code.");
            List<string> lstPOFlddetails = new List<string>();
            lstPOFlddetails.Add(ProcessingOptionsPage.txtCustomerActivityOptionsStatementDesc + "|field|CD Increase W/H Prior Yr");
            lstPOFlddetails.Add(ProcessingOptionsPage.cbkCustomerActivityOptionsSkipReversalsWithinBillingPeriod + "|checkbox|on");
            lstPOFlddetails.Add(ProcessingOptionsPage.cbkCustomerActivityOptionsSkipStatementPrint + "|checkbox|off");
            lstPOFlddetails.Add(ProcessingOptionsPage.drpCustomerActivityOptionsStatementExtractDetailCategory + "|dropdown|ADVANCES");
            lstPOFlddetails.Add(ProcessingOptionsPage.drpCustomerActivityOptionsStatementPrintOption + "|dropdown|No Fields");
            Application.WebAdmin.ModifyTransactionCode("D - Deposit", Tcod, lstPOFlddetails);

            Report.Step("Create a Intrest Index.");
            string Idex = Application.WebAdmin.CreateInterestIndex("0 - Basis Index");

            Report.Step("Delete the rates of Intrest Index - 'D1a05' by Effective date .");
            Application.WebAdmin.DeleteRatesOfIndexByEffectiveDate("D1a05", "02/02/2015");

            Report.Step("Modify the Rates of Rate Schedule of 'P7Test'.");
            List<string> lstAddIndxdetails = new List<string>();
            lstAddIndxdetails.Add("10;3.75000");
            lstAddIndxdetails.Add("20;4.85000");
            lstAddIndxdetails.Add("30;5.00000");
            lstAddIndxdetails.Add("345;5.85000;Add");
            Application.WebAdmin.ModifyRatesOfRateSchedule("P7Test", "02/02/2015", "1000.00", lstAddIndxdetails);

            Report.Step("Get Rate Schedule - 'P7Test'.");
            Application.WebAdmin.GetRateSchedule("P7Test");

            Report.Step("Delete Rate Schedule - 'P7Test'.");
            Application.WebAdmin.DeleteRateSchedule("P7Test");

            Report.Step("Logout WebAdmin Application.");
            Application.WebAdmin.LogOutofWebAdmin();
        }
    }
}

