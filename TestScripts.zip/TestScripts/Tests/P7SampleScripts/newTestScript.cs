using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;


namespace Profile7Automation.TestScripts.Tests.P7SampleScripts
{
    [TestFixture]
    public class newTestScript
    {
        IWebDriver driver;
        
        [Test]
      //  [Property(TestType.TestBased, "")]
//        [Property("TestDescription", "This is TestBased sample test")]
        public void Set123()
        {
            driver=new ChromeDriver();
        
            
        }

        [Test]
        public void cleanup()
        {
            driver.Quit();
        }
    }
}