/*
Objective: PROFILE-27876: Amortisation Schedule.
Author: Sankarnarayan Suresh
Creation Date: 07/22/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/

using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.Profile_V765.SystemA
{
    [TestFixture]
    public class PROFILEAMORT_ACCOUNTPROJECTIONS : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PROFILE-27876 - Projected Activity")]
        public void pROFILEAMORT_ACCOUNTPROJECTIONS()
        {
            Report.Step("Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
 
            Report.Step("Create a new personal customer <CustNo> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CustNo = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Create a Commercial Loan Account using standard Product Type (Customer| Service| Account| Add New Account).Set Frequency as 1MA(Day) .");
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string DayOfApplicationDate = appHandle.GetDateParameters(ApplicationDate)[1];
            string COMMACCNUM = Application.WebCSR.Create_Account(CustNo, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("Commercial Loan 800"), "", 1, Data.Get("Account Name") + "|COMMACCNUM;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Payment Frequency") + "|1MA" + DayOfApplicationDate);

            Report.Step("Get  the Commercial Loan Account COMMACCNUM. Set the Interest Rate   (LN.IRN):  10");
            Application.WebCSR.UpdateInterestRatesInLoanRateDeterminationPage(COMMACCNUM, Data.Get("GLOBAL_INTEREST_RATE_10"));

            Report.Step("Set the Payment Term (LN.PTRM):  1Y");
            Application.WebCSR.UpdateLoanMaturityInLoanMaturityPayOffPage(COMMACCNUM, Data.Get("1Y"));

            Report.Step("Set Payment Calculation Method (LN.PCM):  2N - Accrued Interest, Fixed Principal No On-Line B in Payment Calculation Tab");
            string CalcMethod = Data.Get("2N - Accrued Interest. Fixed Principal No On-Line B");
            Application.WebCSR.UpdateLoanPaymentCalculationMethod(COMMACCNUM, CalcMethod.Replace(".", ","));

            Report.Step("Click on Loan Account Services Projected Activity Link. Select Account as <COMMACCNUM> . Enter Projected Through Date as SYSTEMDATEPLUS1 .");
            string SYSTEMDATE = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEPLUS1Y = appHandle.CalculateNewDate(SYSTEMDATE, "Y", 1);
            Application.WebCSR.GenerateLoanAccountServicesProjectedActivityData(COMMACCNUM, SYSTEMDATEPLUS1Y);

            Report.Step("Verify Projected Activity Details as - Beginning Date : SYSTEMDATE , Ending Date : SYSTEMDATEPLUS1 , Account Number : COMMACCNUM , Disbursement Date : SYSTEMDATE , Maturity Date : SYSTEMDATEPLUS1 , Interest Rate : 10 , Amount Requested : 1,000 , Account Term : 1Y .");
            Application.WebCSR.VerifyProjectedActivityDetailsByLabelnameLabelValue(Data.Get("Beginning Date") + "|" + SYSTEMDATE + ";" + Data.Get("Ending Date") + "|" + SYSTEMDATEPLUS1Y + ";" + Data.Get("Account Number") + "|" + COMMACCNUM + ";" + Data.Get("Disbursement Date") + "|" + SYSTEMDATE + ";" + Data.Get("Maturity Date") + "|" + SYSTEMDATEPLUS1Y + ";" + Data.Get("Interest Rate") + "|10" + ";" + Data.Get("Amount Requested") + "|1000" + ";" + Data.Get("Account Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y"));
            Application.WebCSR.VerifyBorrowerTotalInProjectedActivityDetails();

            Report.Step("Verify Loan disbursement date,  amount, Payoff - Close Account , Amount in Projected activity table.");
            Application.WebCSR.VerifyProjectedActivityTableDetails(Data.Get("Payoff - Close Account") + ";" + SYSTEMDATEPLUS1Y + ";" + "1,000.00");
            Application.WebCSR.VerifyProjectedActivityTableDetails(Data.Get("Disbursement") + ";" + "1,000.00" + ";" + SYSTEMDATE);

            Report.Step("Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }

    }
}