/*
Objective: PROFILE-27876: Amortisation Schedule.
Author: Sankarnarayan Suresh
Creation Date: 07/22/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/

using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;


namespace Profile7Automation.TestScripts.Tests.Profile_V765.SystemA
{
    [TestFixture]
    public class PROFILEAMORT : TestBase
    {

        [Test]
        [Property("TestDescription", "PROFILE-27876: Amortisation Schedule.")]
        public void pROFILEAMORT()
        {

            Report.Step("Login to WebAdmin Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string systemdate = Application.WebAdmin.GetApplicationDate();
            string systemdatemintenyear = Application.WebAdmin.CalculateNewDate(systemdate, "Y", -10);

            Report.Step("Copy product using Standard Product < 500 – Consumer Loans > to ‘CONLN1’ product (Product Factory | Products).");
            string CONLN1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_CONSUMER_LOAN"), Data.Get("GLOBAL_STD_PROD_NUM_500"), true);

            Report.Step("Copy product using Standard Product < 500 – Consumer Loans > to ‘CONLN2’ product (Product Factory | Products).");
            string CONLN2 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_CONSUMER_LOAN"), Data.Get("GLOBAL_STD_PROD_NUM_500"), true);

            Report.Step("Set Full Period to First Payment value to False for the Product CONLN2 and click Submit");
            Application.WebAdmin.UpdateLoanCalculationOptionsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_CONSUMER_LOAN"), CONLN2, false, false);

            Report.Step("Log Off webadmin application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   

            Report.Step("Recycle Tomcat Servers and then execute the test script PROFILEAMORT_TSR1");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Store the Payment Due Action Grid details.");
            Data.Store("CONLN1", CONLN1);
            Data.Store("CONLN2", CONLN2);

        }
    }
}
