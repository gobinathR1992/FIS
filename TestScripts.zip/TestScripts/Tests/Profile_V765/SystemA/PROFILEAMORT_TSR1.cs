/*
Objective: PROFILE-27876: Amortisation Schedule.
Author: Sankarnarayan Suresh
Creation Date: 07/22/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/

using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.Profile_V765.SystemA
{
    [TestFixture]
    public class PROFILEAMORT_TSR1 : TestBase
    {
        WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property("TestDescription"," PROFILE-27876: Amortisation Schedule")]
        [Property (TestType.TestBased,"")]
        public void pROFILEAMORTTSR1() 
        {
            string CONLN1= Data.Fetch("pROFILEAMORT", "CONLN1");
            string CONLN2= Data.Fetch("pROFILEAMORT", "CONLN2");
            
            Report.Step("Login to Profile WebCSR");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string appdate=Application.WebCSR.GetApplicationDate();
            
            Report.Step("In Profile WebCSR create a Personal Customer CUSTNUM1 Profile Direct Web CSR| Basic Services| Create Personal Customer.");
            string CUSTNUM1  = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
         
            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM1 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM1 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|3Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MA1");
            string ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",3);
            string ApplicationDate2=appHandle.GetMonthLastDate(ApplicationDate1);
            string ApplicationDate3=Application.WebCSR.CalculateNewDate(ApplicationDate2,"d",1);

            Report.Step("Verify the Maturity Date for ACCNUM1 is set to 06/01/2023");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM1, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM2 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM2 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|3Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MA1");
            string SYSTEMDATEPLUS36M = appHandle.CalculateNewDate(appdate, "M", 36);
            string[] dateval=SYSTEMDATEPLUS36M.Split('/');
            string maturitydate=dateval[0]+"/01/"+dateval[2];
            maturitydate=dateval[0]+"/01/"+dateval[2];

            Report.Step("Verify the Maturity Date for ACCNUM2 is set to 05/01/2023.");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM2, "Maturity Date" + "|" + maturitydate);
                                   
            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM3 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM3 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|3Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MA18");
            string tyear = appHandle.GetDateParameters(ApplicationDate1)[2];
            string tmonth = appHandle.GetDateParameters(ApplicationDate1)[0];
            string newDate = tmonth +"/"+ "18" +"/" + tyear;
            
            Report.Step("Verify the Maturity Date for ACCNUM3 is set to 05/18/2023.");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM3, "Maturity Date" + "|" + newDate);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM4 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM4 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|3Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MA18");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",3);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-1);
            tyear = appHandle.GetDateParameters(ApplicationDate2)[2];
            tmonth = appHandle.GetDateParameters(ApplicationDate2)[0];
            newDate = tmonth +"/"+ "18" +"/" + tyear;

            Report.Step("Verify the Maturity Date for ACCNUM4 is set to 04/18/2023.");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM4, "Maturity Date" + "|" + newDate);
            
            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM5 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM5 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|2Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MA31");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",2);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",0);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM5 is set to 05/31/2022");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM5, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM6 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM6 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|2Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MA31");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",2);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-1);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM6 is set to 04/30/2022");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM6, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM7 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM7 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|30M;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1QA30");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"m",30);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",2);
	        tyear = appHandle.GetDateParameters(ApplicationDate2)[2];
            tmonth = appHandle.GetDateParameters(ApplicationDate2)[0];
            newDate = tmonth +"/"+ "30" +"/" + tyear;            

            Report.Step("Verify the Maturity Date for ACCNUM7 is set to 01/30/2023");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM7, "Maturity Date" + "|" + newDate);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM8 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM8 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|30M;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1QA30");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"m",30);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-1);
	        tyear = appHandle.GetDateParameters(ApplicationDate2)[2];
            tmonth = appHandle.GetDateParameters(ApplicationDate2)[0];
            newDate = tmonth +"/"+ "30" +"/" + tyear;

            Report.Step("Verify the Maturity Date for ACCNUM8 is set to 10/30/2022");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM8, "Maturity Date" + "|" + newDate);

            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM9 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM9 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|4Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1QA31");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",4);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",2);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM9 is set to 07/31/2024");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM9, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM10 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM10 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|4Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1QA31");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",4);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-1);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM10 is set to 04/30/2024");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM10, "Maturity Date" + "|" + ApplicationDate3);
            
            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM11 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM11 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|5Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1YA31");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",5);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",0);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM11 is set to 05/31/2025");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM11, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM12 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM12 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|5Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1YA31");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",5);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-1);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM12 is set to 04/30/2025");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM12, "Maturity Date" + "|" + ApplicationDate3);
            
            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM13 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM13 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|5Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1YAE");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",5);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",0);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM13 is set to 05/31/2025");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM13, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Create a Consumer Loan account ACCNUM14 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM14 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|5Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1YAE");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",5);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-1);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM14 is set to 04/30/2025");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM14, "Maturity Date" + "|" + ApplicationDate3);
            
            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM15 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM15 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|34M;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MAE");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",2);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",10);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM15 is set to 03/31/2023");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM15, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM16 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM16 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|34M;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MAE");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",2);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",9);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM16 is set to 02/28/2023");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM16, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM17 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM17 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|11M;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MAE");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",1);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-1);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM17 is set to 04/30/2021");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM17, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM18 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM18 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|11M;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MAE");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",1);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-2);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM18 is set to 03/31/2021");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM18, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM19 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM19 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|2Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|SA23-29");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",2);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",0);
            tyear = appHandle.GetDateParameters(ApplicationDate2)[2];
            tmonth = appHandle.GetDateParameters(ApplicationDate2)[0];
            newDate = tmonth +"/"+ "23" +"/" + tyear;

            Report.Step("Verify the Maturity Date for ACCNUM19 is set to 05/23/2022.");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM19, "Maturity Date" + "|" + newDate);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM20 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM20 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|2Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|SA23-29");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",2);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-1);
            tyear = appHandle.GetDateParameters(ApplicationDate2)[2];
            tmonth = appHandle.GetDateParameters(ApplicationDate2)[0];
            newDate = tmonth +"/"+ "29" +"/" + tyear;

            Report.Step("Verify the Maturity Date for ACCNUM20 is set to 04/29/2022.");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM20, "Maturity Date" + "|" + newDate);

			Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM21 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM21 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|2Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|SA17-20");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",2);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",0);
            tyear = appHandle.GetDateParameters(ApplicationDate2)[2];
            tmonth = appHandle.GetDateParameters(ApplicationDate2)[0];
            newDate = tmonth +"/"+ "17" +"/" + tyear;

            Report.Step("Verify the Maturity Date for ACCNUM21 is set to 04/17/2022.");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM21, "Maturity Date" + "|" + newDate);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM22 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM22 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|2Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|SA17-20");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",2);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",-1);
            tyear = appHandle.GetDateParameters(ApplicationDate2)[2];
            tmonth = appHandle.GetDateParameters(ApplicationDate2)[0];
            newDate = tmonth +"/"+ "20" +"/" + tyear;

            Report.Step("Verify the Maturity Date for ACCNUM22 is set to 04/20/2022.");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM22, "Maturity Date" + "|" + newDate);

            Report.Step("Product-4998 - Full Period to First Payment-FPF is set to True");
            Report.Step("Create a Consumer Loan account ACCNUM23 using copied Loan product type CONLN1 and customer CUSTNUM1.");
            string ACCNUM23 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN1,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|45M;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MAE");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",3);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",9);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM23 is set to 02/29/2024");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM23, "Maturity Date" + "|" + ApplicationDate3);

            Report.Step("Product-2291 - Full Period to First Payment-FPF is set to False");
            Report.Step("Create a Consumer Loan account ACCNUM24 using copied Loan product type CONLN2 and customer CUSTNUM1.");
            string ACCNUM24 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONLN2,"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|45M;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|1MAE");
            ApplicationDate1=Application.WebCSR.CalculateNewDate(appdate,"y",3);
            ApplicationDate2=Application.WebCSR.CalculateNewDate(ApplicationDate1,"m",8);
            ApplicationDate3=appHandle.GetMonthLastDate(ApplicationDate2);

            Report.Step("Verify the Maturity Date for ACCNUM24 is set to 01/31/2024");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(ACCNUM24, "Maturity Date" + "|" + ApplicationDate3);
                 
            Report.Step("Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR")); 
        }
    }
}    