/*
Objective: Verify that the POSACR/NEGACRNEGINTRATE values are rounoff in Transaction comment.
Author: Rama Sanjeevi
Creation Date: 08/16/2020
Modified By: 
Modified Date:  
Modification Reason 1: 
Modified By:
Modification Date:
Modification Reason 2:
*/

using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;

namespace Profile7Automation.TestScripts.Tests.Deposit
{
     [TestFixture]
    public class BCHRollver_TDSETUP:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the POSACR/NEGACRNEGINTRATE values are rounoff in Transaction comment.")]
        public void BCHRollver_TDsetup()
        {
            Report.Step("Step 1.0: Login to Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
			string ApplicationDate = WebAdminPageFactory.WebAdminMasterPage.GetAppDate();
			string systemdateminus4 = Application.WebAdmin.CalculateNewDate(ApplicationDate, "d", -4);
			
		    Report.Step("Step 2.0: In WebAdmin, create a New Index CUMINDX1 of type: 1 - Tiered Index, Tiered Index Type: C - Cumulative. (Table Configuration | Interest Indexes | Add).");
            string CUMINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("C - Cumulative"));
            
			Report.Step(" Step 3.0:Add interest rates to Basis index newInd.");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX1,systemdateminus4,"","","",Data.Get("-99999999.0")+"|"+Data.Get("GLOBAL_VALUE_MINUS_10")+";"+Data.Get("GLOBAL_VALUE_MINUS_10000")+"|"+Data.Get("GLOBAL_VALUE_MINUS_5")+";"+Data.Get("GLOBAL_VALUE_ZERO")+"|"+Data.Get("GLOBAL_VALUE_MINUS_1")+";"+Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")+"|"+Data.Get("GLOBAL_VALUE_MINUS_3"));
	        
			Report.Step("Step 4: Logout from WebAdmin Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
			
			Report.Step("Step 5: Reload WebAdmin Application");
			Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            
			Report.Step("Step 6: Login to Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
			
			Report.Step("Step 7: In Profile WebAdmin, copy a Certificate of Deposit Product Type <CD_PRD> (Product Factory | Products | Copy Product.");
            string CD_PRD = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),Data.Get("GLOBAL_STAND_ADMINPROD_DESC_350"),true);

            Report.Step("Step 4: Navigate to the Interest tab and  update the following: a) Accrual Base: Ledger Balance; b) Accrual Method: Actual/Actual 31/365,6, c) Minimum Balance To Accrue: NULL and click Submit. ");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("D - Deposit Accounts"), Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CD_PRD, Data.Get("Ledger Balance"),appHandle.ReplaceString(Data.Get("Actual/Actual      (31/365$6)"),"$",","),Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 5: Navigate to the Interest |Posting Options page, update Disbursement Option: Remain on Depoist; Posting Frequency: 2DA and click Submit.");
            Application.WebAdmin.UpdateInterestPostingOptionsDetails(Data.Get("D - Deposit Accounts"), Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CD_PRD, Data.Get("Remain On Deposit"), Data.Get("2DA"), Data.Get("GLOBAL_INFORMATION_UPDATED"));
	        
            Report.Step("Step 8.0: Navigate to the Rate Determination link and update the Adjustable rate index as <Index> ad Click Submit. ");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CD_PRD, "", CUMINDX1, "", Data.Get("GLOBAL_BLANK_OR_NULL"), Data.Get("GLOBAL_BLANK_OR_NULL"));
            
			Report.Step("Step 15.0: Navigate to Interest Tab , select Negative Interest Link and select NegativeInterestAccrualOption:<Positive and Negative Accrued Separately>,select NegativeInterestPostingOption:<Post Int/Div Accrued on Positive Bal and Neg Bal Separately>,set NegativeInterestPostingFrequency:<1MAE>,select NegativeInterestMinimumNegativeInterestChargeOption:<Post all Negative Accrued Interest>, select NegativeInterestNegativeAccountBalanceOption:<Account balance may be negative; do not track residual interest> in DepositNegativeInterestPage and select Submit .");
            Application.WebAdmin.UpdateDetailsInDepositInterestNegativeInterestPage(Data.Get("D - Deposit Accounts"), Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CD_PRD, true, Data.Get("Positive and Negative Accrued Separately"), Data.Get("Post Int/Div Accrued on Positive Bal and Neg Bal Separately"), Data.Get("2DA"),true, "","","","");

            Data.Store("CD_PRD",CD_PRD); 

            Report.Step("Step 9.0: Logout from WebAdmin Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
          
          


        }       
    }
    
}