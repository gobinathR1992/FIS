/*
Objective: Verify that the POSACR/NEGACRNEGINTRATE values are rounoff in Transaction comment.
Author: Rama Sanjeevi
Creation Date: 08/12/2020
Modified By: 
Modified Date:  
Modification Reason 1: 
Modified By:
Modification Date:
Modification Reason 2:
*/

using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;
using System;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.Deposit
{

    [TestFixture]
    public class BCHRollover001 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property("TestDescription", " Verify that the POSACR/NEGACRNEGINTRATE values are rounoff in Transaction comment.")]
        [Property(TestType.TestBased, "")]
        public void BCHRollOver001()
        {
            string CD_PRD = Data.Fetch("BCHRollver_TDSetup", "CD_PRD");
		

            Report.Step("Step 1: Login to Profile WebCSR Application");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
			string systemdateminus5D = Application.WebCSR.CalculateNewDate(ApplicationDate, "d", -5);
            string systemdateminus6D = Application.WebCSR.CalculateNewDate(ApplicationDate, "d", -6);
			
            Report.Step("Step 2: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3: Create a CD account <CDACCOUNT1> using the copied CD product <CD_PRD> for the personal customer <CIF1> with the following inputs: Name: CD; System Date: <T-6>, Opening Deposit: 2000; Currency: USD;  Account Term: 6D (Basic Services | Create account).");
            string CDACCOUNT1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), CD_PRD, "", 1, Data.Get("Account Name") + "|CDACCTNUM;" + Data.Get("Opening Date")+ "|" + systemdateminus6D +";"+ Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_100") + ";" + Data.Get("Term") + "|6D");

            Report.Step("Step 4: Create a CD account <CDACCOUNT2> using the copied CD product <CD_PRD> for the personal customer <CIF1> with the following inputs: Name: CD; System Date: <T-6>, Opening Deposit: 2000; Currency: USD;  Account Term: 6D (Basic Services | Create account).");
            string CDACCOUNT2 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), CD_PRD, "", 1, Data.Get("Account Name") + "|CDACCTNUM;" + Data.Get("Opening Date")+ "|" + systemdateminus6D +";"+ Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_100") + ";" + Data.Get("Term") + "|6D");

            Report.Step("Step 5: Logoff from profile WebCSR application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
			
			Report.Step("Step 6: Login to Profile Teller.");
            Application.Teller.login_specified_application(Data.Get("GLOBAL_APPLICATION_TELLER"));

			Report.Step("Step 7: Post a Withdrawal transaction of 10,000 to the deposit account <CDACCOUNT1> with the currency as USD on System Date-5 days.");
			Application.Teller.WithdrawFunds(CDACCOUNT1,Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K"),systemdateminus5D,"",true);

            Report.Step("Step 8 : Post a deposit transaction of 10,000.00 to the certificate deposit account <CDACCOUNT2> on System Date-5 days using transaction code CD (CD Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(CDACCOUNT2, Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K"),systemdateminus5D,"",true);
			
			Report.Step("Step 9: Post a current dated deposit transaction of 20,000.00 to the certificate deposit account <CDACCOUNT1> using transaction code CD (CD Deposit). Offset the transaction using transaction code CI (Cash In)");
            Application.Teller.DepositFunds(CDACCOUNT1, Data.Get("GLOBAL_AMOUNT_REQUESTED_20K"));
			
		    Report.Step("Step 10: Post a current dated deposit transaction of 10,000.00 to the certificate deposit account using transaction code CD (CD Deposit). Offset the transaction using transaction code CI (Cash In)");
            Application.Teller.DepositFunds(CDACCOUNT2, Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K"));

            Report.Step("Step 11: Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));
			
            Report.Step("Step 12: Run one Day End and Execute BCHRollOver001_DP1.");  	
			
			Data.Store("CIF1",CIF1); 
			Data.Store("CDACCOUNT1",CDACCOUNT1); 
			Data.Store("CDACCOUNT2",CDACCOUNT2); 
			
        }
    }
}

