/*
Objective: Verify that the POSACR/NEGACRNEGINTRATE values are rounoff in Transaction comment."
Author: Rama Sanjeevi
Creation Date: 08/12/2020
Modified By: 
Modified Date:  
Modification Reason 1: 
Modified By:
Modification Date:
Modification Reason 2:
*/

using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;
using System;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.Deposit
{

    [TestFixture]
    public class BCHRollover001_DP1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property("TestDescription", "Verify that the POSACR/NEGACRNEGINTRATE values are rounoff in Transaction comment.")]
        [Property(TestType.TestBased, "")]
        public void BCHrollover001_DP1()
        {
           
            Report.Step("Step 1: Login to Profile WebCSR Application");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

     		string CDACCOUNT1 = Data.Fetch("BCHRollover001", "CDACCOUNT1");
            string CDACCOUNT2 = Data.Fetch("BCHRollover001", "CDACCOUNT2");

            Report.Step("Step 2: Verify an entry is recorded in account History detail page of newly created mortgage Loan Account.");
            Application.WebCSR.VerifyDataInAccountHistoryDetailsPopUp(CDACCOUNT1,"CD Decrease Int Paid","Transaction Comment:|NEGACRNEGINTRATE:.82");
          
            Report.Step("Step 3: Verify an entry is recorded in account History detail page of newly created mortgage Loan Account.");
            Application.WebCSR.VerifyDataInAccountHistoryDetailsPopUp(CDACCOUNT2,"CD Decrease Int Paid","Transaction Comment:|POSACR:19.18");
            
		    Report.Step("Step 4: Logoff from profile WebCSR application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
		   	
			
		}
		
	}
}
	