/*
Objective: Verify that the Basis Interest Index is saved sucessfully for Loan Account Effective dated Rate change."
Author: Rama Sanjeevi
Creation Date: 08/25/2020
Modified By: 
Modified Date:  
Modification Reason 1: 
Modified By:
Modification Date:
Modification Reason 2:
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using System;
using System.Threading;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.BusinessFunctions.Applications;
using Profile7Automation.Libraries.Util;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.LoanServicing
{
     [TestFixture]
    public class LoanEFDRateChange001_TSR:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the Basis Interest Index is saved sucessfully for Loan Account Effective dated Rate change.")]
        public void LoanEFDRatechange001_TSR()
        {

			string Index = Data.Fetch("LoanEFDRatechange001", "Index");

            Report.Step("Step 1: Login to Profile WebCSR Application");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
			string systemdateminus5D = Application.WebCSR.CalculateNewDate(ApplicationDate, "d", -5);
			
            Report.Step("Step 2: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Create an Installment Loan Account <LN_ACCT> using standard loan product <Installment Loan 500 > for the above customer <CIF1> with the following details: Term: <1Y>, Payment Frequency: <1MAE>, Amount: <10000 USD>.");
            string LN_ACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"), "", 1, Data.Get("Account Name") + "|" + "InstLoan;" + Data.Get("Disbursement Date") + "|" + systemdateminus5D + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_5K") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE"));
      
            Report.Step("Navigate to the EFD Rate Change page (Loan Account Services | EFD Rate Change).");   
            Report.Step("Enter Account: <LN_ACCT> Effective Date: <T-5>, Interest Index: <BSINDX>, Interest Change Frequency: <1MAE>, Rate Change Method: <2 - Current Index + Offset>. Click Submit.");
			Report.Step("Verify that the message 'The information has been updated.' is displayed.");
            Application.WebCSR.EnterLoanAccountServicesEFDRateChangePageOptions("InstLoan - " +LN_ACCT+"-USD",systemdateminus5D, Index+" - "+Index, Data.Get("1MAE"),Data.Get("GLOBAL_RATE_CHANGE_METHOD"),Data.Get("The information has been updated."));
			
            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();
			
        }       
       
    }
    
}