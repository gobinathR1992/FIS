/*
Objective: Verify that the Basis Interest Index is saved sucessfully for Loan Account Effective dated Rate change."
Author: Rama Sanjeevi
Creation Date: 08/25/2020
Modified By: 
Modified Date:  
Modification Reason 1: 
Modified By:
Modification Date:
Modification Reason 2:
*/

using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.LoanServicing
{
    
    [TestFixture]
    public class LoanEFDRateChange001:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the Basis Interest Index is saved sucessfully for Loan Account Effective dated Rate change.")]
        public void LoanEFDRatechange001()
        {
            Report.Step("Step 1.0: Login to Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
		    string ApplicationDate = Application.WebCSR.GetApplicationDate();
			string systemdateminus5D = Application.WebCSR.CalculateNewDate(ApplicationDate, "d", -5);

            Report.Step("Step 2.0: Create an Interest Index type for Basis index.");
            string Index = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("0 - Basis Index"));
            
            Report.Step("Step 3.0: Add Interest rates to Basis index.");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("0 - Basis Index"),Index,systemdateminus5D,Data.Get("GLOBAL_INTEREST_RATE_10"));

           Report.Step("Log out of Profile WebAdmin and close the browser.");
           Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 4.0 Reload Tomcat Server.");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Data.Store("Index", Index);
            
        }
           
    }
}