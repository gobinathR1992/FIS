/*
Objective: Verify that the new field ‘Customer Short Name’ is added to the Title/Address page in Profile WebCSR for both customer Deposit and Loan accounts (Account Information | Title/Address Tab).
           Verify that the Customer Short Name is editable, and the input to it is saved successfully.
Author: Rama Sanjeevi
Creation Date: 08/25/2020
Modified By: 
Modified Date:  
Modification Reason 1: 
Modified By:
Modification Date:
Modification Reason 2:
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using System;
using System.Threading;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.BusinessFunctions.Applications;
using Profile7Automation.Libraries.Util;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.LoanServicing
{
     [TestFixture]
    public class CustomerShortName001:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the new field ‘Customer Short Name’ is added to the Title/Address page in Profile WebCSR for both customer Deposit and Loan accounts (Account Information | Title/Address Tab). \n Verify that the Customer Short Name is editable, and the input to it is saved successfully.")]
        public void CustomerShortname001()
        {
            Report.Step("Step 1: Login to Profile WebCSR Application");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
			string systemdateminus5D = Application.WebCSR.CalculateNewDate(ApplicationDate, "d", -5);
            string sUserLastName = StartupConfiguration.EnvironmentDetails.UserLastName;
			
            Report.Step("Step 2: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            
            Report.Step("Step 3: Create Savings Account<SAVACC1> using Savings product type <300> with  for the Personal customer <CIF1> (Basic Services| Create Account.");
            string SAVACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), "", 1, Data.Get("Account Name") + "|SAVACC1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"));

            Report.Step("Step 4: Create an Installment Loan Account <LN_ACCT> using standard loan product <Installment Loan 500 > for the above customer <CIF1> with the following details: Term: <1Y>, Payment Frequency: <1MAE>, Amount: <10000 USD>.");
            string LN_ACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"), "", 1, Data.Get("Account Name") + "|" + "InstLoan;" + Data.Get("Disbursement Date") + "|" + systemdateminus5D + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_5K") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE"));
    
            Report.Step("Step 5: Verify that the new field ‘Customer Short Name’ is added to the Title/Address page in Profile WebCSR for the customer Loan account (Account Information | Title/Address Tab).");   
            Report.Step("Step 6: Verify that the Customer Short Name is editable, and the changes done to it are saved successfully.");
			Report.Step("Step 7: Verify that the message 'The information has been updated.' is displayed.");
            Application.WebCSR.VerifyCustomerShortNameUpdatedonLoanAccountTitleAddressPage(LN_ACCT,Data.Get("Customer Short Name"),sUserLastName,Data.Get("GLOBAL_INFORMATION_UPDATED"));
			
            Report.Step("Step 8: Verify that the new field ‘Customer Short Name’ is added to the Title/Address page in Profile WebCSR for the customer Deposit account (Account Information | Title/Address Tab).");   
            Report.Step("Step 9: Verify that the Customer Short Name is editable, and the changes done to it are saved successfully.");
			Report.Step("Step 10: Verify that the message 'The information has been updated.' is displayed.");
            Application.WebCSR.VerifyCustomerShortNameUpdatedonDepositAccountTitleAddressPage(SAVACCT,Data.Get("Customer Short Name"),sUserLastName,Data.Get("GLOBAL_INFORMATION_UPDATED"));
			
            Report.Step("Log out of Profile WebCSR and close the browser.");
            Application.WebCSR.LogOutofWebCSR();
			
        }       
       
    }
    
}