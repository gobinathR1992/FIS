/*
Objective: PROFILE-28071 - Verify that the Amortization Term is displayed correct value on Loan calculator Page.
Author: Rama Sanjeevi
Creation Date: 08/10/2020
Modified By: 
Modified Date:  
Modification Reason 1: 
Modified By:
Modification Date:
Modification Reason 2:
*/

using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.Utilities
{
     [TestFixture]
    public class LoanCalculator001:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the Amortization Term is displayed correct value on Loan calculator Page.")]
        public void Loancalculator001()
        {
            string LN_TERM="23M";
            Report.Step(" Login to Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate=Application.WebCSR.GetApplicationDate();

            Report.Step(" Navigate to Loan Calculator page (Utilities | Loan Calculator)");
            Report.Step(" Enter Type: Mortgage Loan Type 700, Disbursement Date: T, Payment Frequency: 1MA4, Loan Amount: 250K, Interest Rate: 20%, Payment: 14K. Click Submit.");
            Application.WebCSR.EnterLoanAccountServicesLoanCalculatorPageOptions (Data.Get("700")+" - "+Data.Get("GLOBAL_STAND_CSRPROD_DESC_700"),ApplicationDate,Data.Get("GLOBAL_FREQUENCY_1MA4"),"",Data.Get("GLOBAL_AMOUNT_250K"),Data.Get("GLOBAL_INTEREST_RATE_20"),Data.Get("GLOBAL_AMOUNT_14K")); 
			
            Report.Step(" Verify that the Amortization Term is displayed correct value <23M>.");
            Application.WebCSR.VerifyLoanCalculatorAmortizationTerm(LN_TERM);
			
            Report.Step("Logoff from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
           
        
        }       
    }
    
}