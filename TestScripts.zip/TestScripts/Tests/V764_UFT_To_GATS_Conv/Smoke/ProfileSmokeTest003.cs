using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.Smoke
{

    [TestFixture]
    public class profileSmokeTest003 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string  UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        [Test]
        [Property("TestDescription", " Verify the following: (i)Create and modify a Personal Customer, check the History and verify there are no integrities on the personal customer account and access all tabs.\n (ii) Create and modify a Corporate Customer, check the History and verify there are no integrities on the corporate customer account")]
        public void ProfileSmokeTest003()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate1 = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN5Y = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", -5);
            string SYSTEMDATEMIN30Y = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", -30);
            string SYSTEMDATEPLUS5Y = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", 5);
            
            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            string Name = Application.WebCSR.GetCustomerNameByCustomerNumber(CIF1);

          Report.Step("Step 3.0: Navigate to customer information page.");
            Application.WebCSR.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));

         Report.Step("Step 4.0: Navigate to customer History  and Expected Result: R1: Verify an entry is recorded in the Customer History (history details) for newly created Personal customer.");
          Application.WebCSR.ValidateCustomerHistoryDetailsInPopupWindow(Data.Get("SET UP NEW CIF"),"Customer Number|"+CIF1);

            Report.Step("Step 5.0:Get the personal customer created above by giving the Customer Number in the search criteria.");
            Application.WebCSR.GetCustomer(CIF1);

            Report.Step("Step 6.0: Verify Customer Page | GoTo dropdown : Select 'Customer Information' item and select Submit button.");
            Application.WebCSR.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));

            Report.Step("Step 7.0: Select Identity Tab | Click on Identification Link.Select 'Passport' Radio button, Set Number (CIF.PASNUM):  <12342234>, Set Country Of Issue (CIF.PCI):  INDIA.,Set Issue Date:  System Date - 5Years.,Set Exp Date (CIF.PED):  System Date + 5Years.,Click on Submit Button.");
            Report.Step("Step 8.0: Expected Result:	R2:	Verify user is able to successfully update the identification information of the personal customer.");
            string sPassportNumber = appHandle.CreateRamdomData(FieldType.NUMERIC, 111111, 999999, 6) + "";
            Application.WebCSR.UpdateCustomerIdentificationDetails(sPassportNumber,SYSTEMDATEMIN5Y,SYSTEMDATEPLUS5Y);

            Report.Step("Step 9.0: Banking Center Page --> Select Customer Services Link --> Customer Information Link and  Select Identity Tab --> Click on Identification Link");
            Report.Step("Step 10.0: Expected Result:R2:	Verify user is able to successfully update the identification information of the personal customer");
            Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"Identity","Number|"+sPassportNumber+";Country of Issue|"+Data.Get("GLOBAL_ADDCOUNTRY")+";Issue Date|"+SYSTEMDATEMIN5Y+";Expiration Date|"+SYSTEMDATEPLUS5Y,"Identification");

            Report.Step("Step 11.0: Change the Middle name of the personal customer and submit the details.");
            Application.WebCSR.UpdateCustomerName("Testing");
            
            Report.Step("Step 12.0:Expected Result: R3: Verify an entry is recorded in the Customer History (history details) for the changes made to the Personal customer information.");
            Report.Step("Step 13.0:In 2019 IT4-CY1 build, History Detail window has replaced with the new dialog window");
            string NewName = Application.WebCSR.GetCustomerNameByCustomerNumber(CIF1);
            Application.WebCSR.ValidateCustomerHistoryDetailsInPopupWindow(Data.Get("Customer Name"),"Customer Number|"+CIF1 +";Description|Customer Name;Data Item|CIF.NAM;Old Value|" +Name+";New Value|"+ NewName+";User ID|"+UID);

            Report.Step("Step 14.0:Expected Result: R4: Verify user is able to access all the tabs for the personal customer.");
            Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"Security","Security Information");
            //Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"Identity","Protection");
            Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"Name","Personal Information");
            Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"Address","Address Change");
            Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"Seasonal Address","Seasonal Mailing Address");
            Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"Credit/Financial","Reclassification Override");
            //Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"Affiliation","Affiliation");
            Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"CTR Exempt Designation","Exemption Information");
            //Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"Agreements","Agreements");
            Application.WebCSR.VerifyValuesByLabelNameLabelValueInCustomerInformationPage(CIF1,"General","Personal Information");

            Report.Step("Step 15.0: Expected Result: R5: Verify the message 'Account passes integrity verification without error' is displayed after clicking on Customer Verification Link for the Personal customer.");
            Application.WebCSR.VerifyCustomerVerificationIntegrity();

            Report.Step("Step 16.0: Logoff from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 17.0: Login to Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 18.0: In Profile WebCSR, Create a new Corporate Customer. (WebCSR | Basic services | Create corporate customer).");
            string CORPORATECUSTOMER1 = Application.WebCSR.createcorporatecustomer(Data.Get("GLOBAL_CORPORATE_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 19.0: Go to Customer History Page | Click on SET UP NEW CIF link.");
            Report.Step("Step 20.0: Expected Result: R8: Verify an entry is recorded in the Customer History (history details) of newly created Corporate customer.");
            Report.Step("Step 21.0: In 2019 IT4-CY1 build, History Detail window has replaced with the new dialog window.");
            Application.WebCSR.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Application.WebCSR.ValidateCustomerHistoryDetailsInPopupWindow(Data.Get("SET UP NEW CIF"),"Customer Number|"+CORPORATECUSTOMER1);

            Report.Step("Step 22.0: Banking Center Page --> Select Customer Services Link --> Statement Groups Link, Click on Add Button, Set Frequency (MBGRP.SFRE):  1QAE. and Select Submit button.");
            Report.Step("Step 23.0: Expected Result: R9: Verify The statement group has been created message.");
            Application.WebCSR.CreateStatementGroupPage(Data.Get("GLOBAL_FREQUENCY_1QAE"), ApplicationDate1,"", false, false);

            Report.Step("Step 24.0: Get the Corporate Customer and Modify the City value for the Corporate Customer.");
            Application.WebCSR.UpdateAddressInCustomerInformationPage(CORPORATECUSTOMER1,Data.Get("JAXSONVILLE"));

            Report.Step("Step 25.0: Go to Customer History Page by selecting History link under Customer Services main link.");
            Report.Step("Step 26.0: Verify an entry is recorded in the Customer History for the modifications done for the Corporate Customer information.");
            Report.Step("Step 27.0:In 2019 IT4-CY1 build, History Detail window has replaced with the new dialog window.");
            Application.WebCSR.ValidateCustomerHistoryDetailsInPopupWindow(Data.Get("City-Permanent Address"),"Customer Number|"+CORPORATECUSTOMER1 +";Posting Date|" +ApplicationDate1+";New Value|JAXSONVILLE");

            Report.Step("Step 28.0: Expected Result:R10: Verify the message 'Account passes integrity verification without error' is displayed after clicking on Customer Verification Link for the Corporate customer.");
            Application.WebCSR.VerifyCustomerVerificationIntegrity();
            
            Report.Step(" Step 29.0: Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }

    }
}
