using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.Smoke
{

    [TestFixture]
    public class CreatePersonalCustomer : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string  UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        [Test]
        [Property("TestDescription", " Verify the following: (i)Create and modify a Personal Customer, check the History and verify there are no integrities on the personal customer account and access all tabs.\n (ii) Create and modify a Corporate Customer, check the History and verify there are no integrities on the corporate customer account")]
        public void CreatePersonalCustomerMethod()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            // string ApplicationDate1 = Application.WebCSR.GetApplicationDate();
             //string SYSTEMDATEMIN5Y = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", -5);
            // string SYSTEMDATEMIN30Y = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", -30);
             //string SYSTEMDATEPLUS5Y = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", 5);
            
            Report.Step("Step 2.0: Create Personal Customer");
            Application.WebCSR.CreatePersonalCustomer();
            // Report.Step("Step 2.0: Search a Customer using Customer Number");
            // // Application.WebCSR.CustomerSearch("4","customer");
            // Application.WebCSR.searchByCustomerId("customer", "4");

            // Report.Step(" Step 3.0: Logging off from the application");
            // Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}
