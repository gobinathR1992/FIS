using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{

    [TestFixture]
    public class profileSmokeTest001 : TestBase
    {
        [Test]
        [Property("TestDescription", "PRFSMK001: (i) Create a new user id, change the password at first login and modify the user details.\n (ii) View and maintain (access) the User class in Profile Direct")]
        public void ProfileSmokeTest001()
        {
            Report.Step("Step 1.0: Login to Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0: Create a User in WebAdmin.");
            string UserID = Application.WebAdmin.Create_User(Data.Get("ZSCA"));

            Report.Step("Step 3.0: Logout from WebAdmin application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 4.0 : Invoke Profile WebAdmin.");
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 5.0 :Login to WebAdmin application by using new user credentials and Change the Password for newly created user.");
            Application.WebAdmin.LoginWebAdminWithNewUserCredential(UserID);

            Report.Step("Step 6.0: Logout from WebAdmin application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 7.0: Store the UserID to use it in ProfileSmokeTest001_TSR1 script.");
            Data.Store("UserID", UserID);
        }

    }
}

