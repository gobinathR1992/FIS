using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest013 : TestBase
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property("TestDescription","Add and Maintain Packages to the channel")]
      
        public void ProfileSmokeTest013()
        {
            Report.Step("Step 1.0:Login into Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            string SYSTEMDATEMIN1Y = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", -1);
            string SYSTEMDATEPLUS2Y = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", 2);

            Report.Step("Step 2.0: Create a Package");
            string packageNAme = Application.WebAdmin.Create_Package();

            Report.Step("Step 3.0: Create a Package product group with no of products required  as 2 using Profile Host Application.");

            Report.Step("Step 4.0: Logout from WebAdmin application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
                
        }


    }
}

