using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest006:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify ability to post backdated transactions to loan, deposit accounts and validate account history.")]
        public void ProfileSmokeTest006()
        {
            Report.Step("Step 1.0: Login to Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string ApplicationDate1 = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN2D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -2);
            
            Report.Step("Step 2.0: Create a new customer with all required fields.");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create the Consumer Loan account with Amount:10000; Term:2Y; Currency: USD; Date: T-2 and Frequency: 1MAE.");
            string CONLNACCNUM1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"),Data.Get("GLOBAL_STAND_CSRPROD_DESC_500") , "", 1, Data.Get("Account Name") + "|CONACCNUM1;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" +Data.Get("Term") + "|2Y;" + Data.Get("Disbursement Date") + "|" +  SYSTEMDATEMIN2D +  ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE"));

            Report.Step("Step 4.0: Create the Mortgage Loan account with Amount:10000; Term:2Y ; Currency: USD ; Date: T-2 and Frequency: 1MAE.");
            string MTGACCNUM = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_700"), "", 1, Data.Get("Account Name") + "|MTGACCNUM;" +  Data.Get("Disbursement Date") + "|" + SYSTEMDATEMIN2D + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|2Y;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE"));
            
            Report.Step("Step 5.0: Create the Demand Deposit account with Amount:1000; Currency: USD and Date: T-2.");
            string DDACCNUM1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_400"), "", 1, Data.Get("Account Name") + "|DDAACCNUM1;" + Data.Get("Opening Date") + "|" + SYSTEMDATEMIN2D + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"));

            Report.Step("Step 6.0: Create the Savings account with Amount:1000; Currency: USD and Date: T-2.");
            string SAVACC = Application.WebCSR.Create_Account(CIF1,Data.Get("GLOBAL_RELATION_SINGLE"),Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), "", 1, Data.Get("Account Name") + "|" + "SAVACC" + ";" + Data.Get("Opening Date")+ "|" + SYSTEMDATEMIN2D + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"));

            Report.Step("Step 7.0: Create the Certificate of Deposit account with Amount:1000; Currency: USD; Date: T-2 and Term:2Y.");
            string CDACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_350"), "", 1, Data.Get("Account Name") + "|CDACCTNUM;" + Data.Get("Opening Date")+ "|" + SYSTEMDATEMIN2D + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_1K") + ";" + Data.Get("Term") + "|2Y");

            Report.Step("Step 8.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0: Login to PDTELLER application.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 10.0: Post a Disbursement to the Consumer loan account created above.");
            Application.Teller.LoanDisbursement(CONLNACCNUM1, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"),SYSTEMDATEMIN2D);

            Report.Step("Step 11.0: Post a Disbursement to the Mortgage Loan account created");
            Application.Teller.LoanDisbursement(MTGACCNUM, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"),SYSTEMDATEMIN2D);

            Report.Step("Step 12.0: Post a Deposit transaction for the Demand Deposit Account created.");
            Application.Teller.DepositFunds(DDACCNUM1,Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"),SYSTEMDATEMIN2D);

            Report.Step("Step 13.0: Post a Deposit transaction for the Savings account created.");
            Application.Teller.DepositFunds(SAVACC,Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"),SYSTEMDATEMIN2D);

            Report.Step("Step 14.0: Post a Deposit transaction for the Certificate of Deposit Account created.");
            Application.Teller.DepositFunds(CDACCT,Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"),SYSTEMDATEMIN2D);

            Report.Step("Step 15.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");

            Report.Step("Step 16.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 17.0: Verify the account history in WebCSR for the Consumer loan account details created.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CONLNACCNUM1, SYSTEMDATEMIN2D + ";DISBURSEMENT"); 

            Report.Step("Step 18.0: Verify the account history in Web CSR for the Mortgage loan account details created.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(MTGACCNUM, ApplicationDate1 + ";DISBURSEMENT"); 

            Report.Step("Step 19.0: Verify the account history in WebCSR for the Demand Deposit account details created in above step. ");
            Application.WebCSR.VerifyDataInAccountHistoryTable(DDACCNUM1, SYSTEMDATEMIN2D + ";DEPOSIT"); 

            Report.Step("Step 20.0: Verify the account history in WebCSR for Savings account  created.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(SAVACC, SYSTEMDATEMIN2D + ";DEPOSIT"); 

            Report.Step("Step 21.0: Verify the account history  in WebCSR for the Certificate of Deposit account.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CDACCT, SYSTEMDATEMIN2D + ";DEPOSIT"); 

            Report.Step("Step 22.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }        
    }
}