using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;
using System;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class ProfileSmokeTest001_tsr1 : TestBase
    {
        [Test]
        [Property("TestDescription", "PRFSMK001: (i) Create a new user id, change the password at first login and modify the user details.\n (ii) View and maintain (access) the User class in Profile Direct")]
        public void ProfileSmokeTest001_TSR1()
        {            

            string UserID = Data.Fetch("ProfileSmokeTest001", "UserID");
            Report.Info("UserID created in ProfileSmokeTest001 is fetched as :" + UserID);

            Report.Step("Step 1.0: Login to Profile WebAdmin with Newly created user credentials.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 2.0 :Create user by using UserID " + UserID + " and Expected Result (R23):  Verify the message “Record already exists” is returned. Create a New UserID and Verify the success message 'The user has been created' is returned");
            string NewUserId = Application.WebAdmin.CreateUserIDWithExistingUserID(UserID,Data.Get("ZSCA"));

            Report.Step("Step 3.0 : Select " + NewUserId + " from users list , Click on Edit Button.Expected Result (R25):  Verify the user can be viewed and the Current Status is 1 – Active. ");
            Application.WebAdmin.VerifyValueByLabelNameLabelValueInWebAdmin(NewUserId,"Status:|Active");                       

            Report.Step("Step 4.0 :Modify the  Branch Code (SCAU.BRCD):  0 – Back Office and Click on Submit Button.Verify that the userid has been modified");
            Application.WebAdmin.SelectUserModifyUserDetails(NewUserId);
            
            Report.Step("Step 5.0:  In the User List Page: <Select the newly created user>.and Expected Result (R24):  Verify the user has been modified with the change to the Branch Code of 0 – Back Office .");
            Application.WebAdmin.NavigatetoUserClassPage();
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInWebAdminUserPage(NewUserId,"Branch Code|0 - BACK OFFICE 0");           

            Report.Step("Create and Verify the Userclass can be viewed via PD WebAdmin and Attempt  to Modify Userclass from WebAdmin ");
            Report.Step("Step 6.0: Select Userclass Maintenance Link| Userclass Maintenance Tab to select the User Class(ZSCA) to be modified and Expected Result (R11): Verify the Userclass can be viewed via PD WebAdmin.");
            Report.Step("Step 7.0: Modify the userclass to update the Overall Cash Maximum (SCAUO.OACMAX): 1,000,000.00. by selecting  Userclasses Tab | Select as Userclass: ZSCA and Click on Submit Button.");
            Application.WebAdmin.UpdateDataInUserClassMaintenance(Data.Get("ZSCA"),"Overall Cash Maximum:|1000000.00");

            Report.Step("Expected Result (R12): Verify the Userclass has been updated with the changes to the Overall Cash Maximum of 1,000,000.00.");
            Application.WebAdmin.NavigatetoUserClassMaintenancePage();
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInWebAdminUserPage(Data.Get("ZSCA"),"Overall Cash Maximum|1000000.00");

            Report.Step("Create a user with ZSCA2 user class and verify for change password ");
            Report.Step("Step 8.0: Create a new User with ZSCA2 User Class. ");
            string UserID2 = Application.WebAdmin.Create_User(Data.Get("ZSCA2"));
            
            Report.Step("Step 9.0: Logout of Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 10.0: Invoke Profile WebAdmin.");
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 11.0: Login to Profile WebAdmin with the new user created Expected Result (R64, R65 and R77):  Verify the message, 'Your password has expired. You must choose a new password before you can proceed' is returned.");
            Report.Step("Step 12.0: Expected Result (R64 and R77): Verify Change the Password for newly created user.");
            Application.WebAdmin.LoginWebAdminWithNewUserCredential(UserID2);

            Report.Step("Step 13.0: Logout of Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));    

            Report.Step("Step 14.0: Login to Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));        

            Report.Step("Step 15.0: Copy UserClass from SCA useclass and Copy UserClass permission from SCA to newly created Userclass.");
            Application.WebAdmin.NavigatetoUserClassMaintenancePage();
            string NewUserId2 = Application.WebAdmin.CreateNewUserClassByCopy(Data.Get("NameSCA"));
            Application.WebAdmin.EnterDetailsForUserClassPermission(Data.Get("NameSCA"),NewUserId2);

            Report.Step("Step 9.0: Logout of Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
     
        }
    }
}