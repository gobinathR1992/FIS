using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest014_TSR1:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Funds Transfer between the Deposit accounts and Deposit to Loan Accounts. (One Time & Frequency)")]
        public void ProfileSmokeTest014_TSR1()
        {
            string CONPRODNUM1 = Data.Fetch("ProfileSmokeTest014","CONPRODNUM1");
            
            Report.Step("Step 1.0: Login to Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate1 = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMINUS90D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -90);
            string SYSTEMDATEMINUS30D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -30);
            string PaymentFreDate = appHandle.CalculateNewDate(SYSTEMDATEMINUS90D, "D", 10);

            Report.Step("Step 2.0: Create a new customer with all required fields.");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create a (T-90) backdated Demand Deposits Account <DEPACCNUM1> using the standard product type - 400 and Amount as 10K.");
            string DDACCNUM1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_400"), "", 1, Data.Get("Account Name") + "|DDAACCNUM1;" + Data.Get("Opening Date") + "|" + SYSTEMDATEMINUS90D + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"));

            Report.Step("Step 4.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Login to PDTELLER application.");
            Application.Teller.login_specified_application("Teller");

            Report.Step(" Step 6.0: Post a (T-90) effective dated Deposit transaction for the newly created account <DEPACCNUM1>.");
            Application.Teller.DepositFunds(DDACCNUM1,Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"),SYSTEMDATEMINUS90D);

            Report.Step("Step 8.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0: Create a (T-90) backdated LN account using the new product created, Amouont as 10K, Term 1Y and set payment Frequency as 10DA.");
            string LNACCNUM1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), CONPRODNUM1, "", 1, Data.Get("Account Name") + "|CONACCNUM1;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" +Data.Get("Term") + "|1Y;" + Data.Get("Disbursement Date") + "|" +  SYSTEMDATEMINUS90D +  ";" + Data.Get("Payment Frequency") + "|" + Data.Get("10DA"));

            Report.Step("Step 10.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 11.0: Post a (T-90) effective dated Loan Disbursement transaction using LD transaction code for the above account created in step 3 <LNACCNUM1>.");
            Application.Teller.LoanDisbursement(LNACCNUM1, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"),SYSTEMDATEMINUS90D);
            
            Report.Step("Step 12.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");

            Report.Step("Step 13.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 14.0: Get the Demand Deposits Account <DEPACCNUM1> and navigate to Transfer Funds page.On Transfer Funds page, set From Account as <DEPACCNUM1> and To Account as <LNACCNUM1>,Effective Date (EFTPAY.EFD): System Date,Amount (EFTPAY.AMOUNT):  100.00 and Click on Submit.");
            Application.WebCSR.TransferFund(DDACCNUM1,LNACCNUM1,Data.Get("GLOBAL_AMOUNT_100"),ApplicationDate1);

            Report.Step("Step 15.0:Get the Demand Deposits Account <DEPACCNUM1> and navigate to Account History page and get the Payment Amount <PaymentAmt1>.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(DDACCNUM1, ApplicationDate1 + ";" + Data.Get("GLOBAL_AMOUNT_100")); 
            
            Report.Step("Step 16.0: Get the Consumer Loan account <LNACCNUM1> and navigate to Account History page.Verify that the Date: GLOBAL_SYSTEM_DATE and Credits: <PaymentAmt1> is displayed in Account History Table.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(LNACCNUM1, ApplicationDate1 + ";Payment for "+PaymentFreDate +";"+Data.Get("GLOBAL_AMOUNT_100")); 

            Report.Step("Step 10.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));   

            Data.Store("DDACCNUM1",DDACCNUM1);        
            Data.Store("LNACCNUM1",LNACCNUM1);
        }              
    }
}