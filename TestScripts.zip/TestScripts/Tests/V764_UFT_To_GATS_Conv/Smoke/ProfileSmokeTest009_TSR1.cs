using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest009_TSR1 : TestBase
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string PWD=StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
        [Test]
        [Property("TestDescription", "Verify Transactions posted to LN, RC and MTG groups can be error-corrected.")]
        public void ProfileSmokeTest009_TSR1()
        {            
           
            string MTGPRODNUM1 = Data.Fetch("ProfileSmokeTest009","MTGPRODNUM1");
            string UserID = Data.Fetch("ProfileSmokeTest009","UserID");

            Report.Step("Step 1.0: Login to Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate1 = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN30D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -30);
            
            Report.Step("Step 2.0: Create a new customer with all required fields.");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create a Consumer loan account.");
            string CONLNACCNUM1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"),Data.Get("GLOBAL_STAND_CSRPROD_DESC_500") , "", 1, Data.Get("Account Name") + "|CONACCNUM1;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_5K") + ";" + Data.Get("Term") + "|3M;" + Data.Get("Disbursement Date") + "|" +  SYSTEMDATEMIN30D +  ";" + Data.Get("Payment Frequency") + "|" + Data.Get("15DA")+";" +Data.Get("Collateral Type") + "|" + Data.Get("GLOBAL_COLLATERAL_TAB_VALUE"));

            Report.Step("Step 4.0: Create a Revolving Credit loan account");
            string RCLNACC = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_600"), "", 1, Data.Get("Account Name") + "|RCLNACC;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_5K") + ";" + Data.Get("Term") + "|2Y;" + Data.Get("Disbursement Date") + "|" +  SYSTEMDATEMIN30D +  ";" + Data.Get("Payment Frequency") + "|" + Data.Get("15DA")+";" +Data.Get("Collateral Type") + "|" + Data.Get("GLOBAL_COLLATERAL_TAB_VALUE"));

            Report.Step("Step 5.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 6.0: Login to PDTELLER application.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 7.0: Post a Loan Disbursement to the consumer loan account using transaction code LD (LD - Disbursement). Offset the transaction using transaction code CO.");
            Application.Teller.LoanDisbursement(CONLNACCNUM1, Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"),SYSTEMDATEMIN30D);

            Report.Step("Step 8.0: Using Teller application post the Credit transaction to the consumer loan account created.");
            string PMTLN = Profile7CommonLibrary.ExtractDataFromDataBase("Select PMT FROM LN WHERE CID ='"+CONLNACCNUM1+"'","PMT");
            Application.Teller.LoanPayment(CONLNACCNUM1, PMTLN);

            Report.Step("Step 9.0: Post a Loan Disbursement to the Revolving Credit loan account using transaction code RP (RP - Disbursement). Offset the transaction using transaction code CO.");
            Application.Teller.LoanDisbursement(RCLNACC, Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"),SYSTEMDATEMIN30D);

            Report.Step("Step 10.0: Using Teller application post the Credit transaction to the Revolving Credit Loan account created");
            string PMTRC = Profile7CommonLibrary.ExtractDataFromDataBase("Select PMT FROM LN WHERE CID ='"+RCLNACC+"'","PMT");
            Application.Teller.LoanPayment(RCLNACC, PMTRC);

            Report.Step("Step 11.0: Login to Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 12.0:Get the Consumer Loan Account and Expected Result:  On Payment Detail page, Verify that Date of Last Payment Transaction is displayed as SYSTEM DATE (Loan Account Overview | Account Summary | General | Payment Tab | Payment Detail sub-link). ");
            Application.WebCSR.LoadAccountSummaryPage(CONLNACCNUM1);
            Application.WebCSR.navigate_to_payment_detail_page();
            Application.WebCSR.VerifylabelValueByLabelName("Date of Last Payment Transaction:|"+ ApplicationDate1);

            Report.Step("Step 13.0: Get the Consumer Loan Account and  Verify that the Account History table shows the entry for the Error correction with following details - Date: SystemDate and Credits:<PAYMENTAMOUNT>.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CONLNACCNUM1, ApplicationDate1 + ";" +PMTLN); 

            Report.Step("Step 14.0: Get Revolving Credit Loan Account and Expected Result:  Verify, via the Revolving Credit Loan Account History, General and the Payments tab the following: Number of Payment Satisfied (LN.CNTCR) = 1 and Date of Last Payment Transaction (LN.LPDT) = System Date.");
            Application.WebCSR.LoadAccountSummaryPage(RCLNACC);
            Application.WebCSR.navigate_to_payment_detail_page();
            Application.WebCSR.VerifylabelValueByLabelName("Date of Last Payment Transaction:|"+ ApplicationDate1);

            Report.Step("Step 15.0: Get Revolving Credit Loan Account and Verify that the Account History table shows the entry for the Error correction with following details - Date: SystemDate and Credits:<PAYMENTAMOUNT1>.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(RCLNACC, ApplicationDate1 + ";" + PMTRC);

            Report.Step("Step 16.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 17.0: Error correction-LN:Error Correct the transaction posted for Consumer Loan Account for Amount: <PAYMENTAMOUNT>.");
            Application.Teller.ErrorCorrectionTellerTransaction("LP|"+CONLNACCNUM1+"|USD|"+PMTLN);

            Report.Step("Step 18.0: Error correction-RC:Error Correct the transaction posted for Revolving Credit Loan Account for Amount: <PAYMENTAMOUNT1>.");
            Application.Teller.ErrorCorrectionTellerTransaction("RP|"+RCLNACC+"|USD|"+PMTRC);

            Report.Step("Step 19.0:CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 20.0: Get Consumer Loan Account and Expected Result: On Payment Detail page, Verify that Date of Last Payment Transaction (LN.LPDT) = null and Number of Payments Satisfied (LN.CNTCR) = 0.");
            Application.WebCSR.LoadAccountSummaryPage(CONLNACCNUM1);
            Application.WebCSR.navigate_to_payment_detail_page();
            Application.WebCSR.VerifylabelValueByLabelName("Date of Last Payment Transaction:|"+ "" + ";Number of Payments Satisfied:|" + "0");

            Report.Step("Step 21.0: Get Consumer Loan Account and Expected Result: Verify that the Account History table shows the entry for the Error correction with following details - Date: SystemDate and Credits:<-PAYMENTAMOUNT>.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CONLNACCNUM1, ApplicationDate1 + ";-"+PMTLN); 

            Report.Step("Step 22.0: Get the Revolving Credit Loan Account  and Expected Result: On Payment Detail page, Verify that Date of Last Payment Transaction (LN.LPDT) = null and Number of Payments Satisfied (LN.CNTCR) = 0.");
            Application.WebCSR.LoadAccountSummaryPage(RCLNACC);
            Application.WebCSR.navigate_to_payment_detail_page();
            Application.WebCSR.VerifylabelValueByLabelName("Date of Last Payment Transaction:|"+ "" + ";Number of Payments Satisfied:|" + "0");

            Report.Step("Step 23.0:Get the Revolving Credit Loan Account and Expected Result: Verify that the Account History table shows the entry for the Error correction with following details - Date: SystemDate and Credits:<-PAYMENTAMOUNT1>.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(RCLNACC, ApplicationDate1 + ";-"+PMTRC); 

            Report.Step("Step 24.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 25.0: Posting disbursment-LN:Post a disbursement to the consumer loan account using transaction code LD (LD - Disbursement). Offset the transaction using transaction code CO");
            Application.Teller.LoanDisbursement(CONLNACCNUM1, Data.Get("GLOBAL_AMOUNT_REQUESTED_400"));

            Report.Step("Step 26.0: Posting disbursment-RC: Post a disbursement to the Revolving Credit loan account using transaction code RA (RA - Disbursement). Offset the transaction using transaction code CO.");
            Application.Teller.LoanDisbursement(RCLNACC, Data.Get("GLOBAL_AMOUNT_REQUESTED_400"),"",true);

            Report.Step("Step 27.0: Login to the Profile WebCSR. 'CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Verification Of LN");
            Report.Step("Step 28.0: Get the Consumer Loan Account. and Expected Result: On Loan General page, verify that Ledger Balance (ACN.BAL) = 5,400.00 and Computed Balance (LN.BALCMP) = 5,400.00");
            Application.WebCSR.LoadAccountSummaryPage(CONLNACCNUM1);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_5400")) + ";Computed Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_5400")));
            
            Report.Step("Step 29.0:Expected Result:  Verify, Balance for Accrual Calculations: 5,400.00 on Loan Calculation Options page.");
            Application.WebCSR.NavigateToInterestCalculationpage();
            Application.WebCSR.VerifylabelValueByLabelName("Accrual Calculation Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_5400")));

            Report.Step("Step 30.0: Get the Consumer Loan Account and Expected Result: Verify that the Account History table shows the entry for the following details - Date: SystemDate and Description:DISBURSEMENT.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CONLNACCNUM1, ApplicationDate1 + ";DISBURSEMENT"); 

            Report.Step("Verification-RC");
            Report.Step("Step 31.0: Get the Revolving Credit Loan Account and Expected Result: On Loan General page, verify that Ledger Balance (ACN.BAL) = 5,441.10 and Computed Balance (LN.BALCMP) = 5,441.10.");
            Application.WebCSR.LoadAccountSummaryPage(RCLNACC);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("5441.10")) + ";Computed Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("5441.10")));

            Report.Step("Step 32.0: Expected Result:  Verify,  Balance for Accrual Calculations: 5,400.00 on Loan Calculation Options page.");
            Application.WebCSR.NavigateToInterestCalculationpage();
            Application.WebCSR.VerifylabelValueByLabelName("Accrual Calculation Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("5441.10")));

            Report.Step("Step 33.0: Get the Revolving Credit Loan Account and Expected Result: Verify that the Account History table shows the entry for the following details - Date: SystemDate, Description:DISBURSEMENT, Debits: 400.00 and Balance:5,441.10.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(RCLNACC, ApplicationDate1 + ";DISBURSEMENT" + ";400.00" + ";"+Data.Get("5441.10")); 

            Report.Step("Step 34.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            
            Report.Step("Step 35.0: Error Correct the transaction posted for Consumer Loan Account for Amount: <GLOBAL_AMOUNT_REQUESTED_400>.");
            Application.Teller.ErrorCorrectionTellerTransaction("LD|"+CONLNACCNUM1+"|USD|400.00");

            Report.Step("Step 36.0:Error Correct the transaction posted for Revolving Credit Loan Account for Amount: <GLOBAL_AMOUNT_REQUESTED_400>.");
            Application.Teller.ErrorCorrectionTellerTransaction("RA|"+RCLNACC+"|USD|400.00");

            Report.Step("Step 37.0: Login to the Profile WebCSR. 'CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 38.0: Get the Consumer Loan Account and Expected Result: On Loan General page, verify that Ledger Balance (ACN.BAL) = 5,000.00 and Computed Balance (LN.BALCMP) = 5,000.00");
            Application.WebCSR.LoadAccountSummaryPage(CONLNACCNUM1);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_5K")) + ";Computed Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_5K")));

            Report.Step("Step 39.0: Expected Result: On Loan Calculation Options page, verify that Accrual Calculation Balance (LN.BALINT) = 5,000.00");
            Application.WebCSR.NavigateToInterestCalculationpage();
            Application.WebCSR.VerifylabelValueByLabelName("Accrual Calculation Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_5K")));

            Report.Step("Step 40.0: Get the Consumer Loan Account and Expected Result: Verify that the Account History table shows the entry for the following details - Date: SystemDate, Debits: -400.00 and Balance: 5000.00");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CONLNACCNUM1, ApplicationDate1 + ";DISBURSEMENT (Error Corrected);-400.00;" +Data.Get("GLOBAL_AMOUNT_REQUESTED_5K")); 

            Report.Step("Verification-RC");
            Report.Step("Step 41.0: Get the Revolving Credit Loan Account  and Expected Result: On Loan General page, verify that Ledger Balance (ACN.BAL) = 5,0410.10 and Computed Balance (LN.BALCMP) = 5,041.10");
            Application.WebCSR.LoadAccountSummaryPage(CONLNACCNUM1);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Data.Get("5041.10") + ";Computed Balance:|" +  Data.Get("5041.10"));

            Report.Step("Step 42.0: Expected Result: On Loan Calculation Options page, verify that Accrual Calculation Balance (LN.BALINT) = 5,041.10");
            Application.WebCSR.NavigateToInterestCalculationpage();
            Application.WebCSR.VerifylabelValueByLabelName("Accrual Calculation Balance:|"+ Data.Get("5041.10"));

            Report.Step("Step 43.0: Get the Revolving Credit Loan Account Expected Result: Verify that the Account History table shows the entry for the following details - Date: SystemDate, Description:DISBURSEMENT (Error Corrected) and Balance: 5,041.10.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(RCLNACC, ApplicationDate1 + ";DISBURSEMENT (Error Corrected);-400.00;" +Data.Get("5041.10")); 

            Report.Step("Step 44.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));    

            Report.Step("Step 45.0: Error correction-LN:Expected Result: Verify, System returns error message “Transaction already error-corrected”.");
            Application.Teller.ErrorCorrectionTellerTransaction("LD|"+CONLNACCNUM1+"|USD|400.00");

            Report.Step("Step 46.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");     

            Report.Step("MORTGAGE Loan -Errorcorrection Checking- in different braches");
            Report.Step("Step 47.0: Login to the Profile WebCSR. 'CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 48.0: Create a Mortgage Loan Account using the newly created Mortgage Loan Product <PROD_NAME>.");
            string MTGACCNUM = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), MTGPRODNUM1, "", 1, Data.Get("Account Name") + "|MTGACCNUM;" +  Data.Get("Disbursement Date") + "|" + SYSTEMDATEMIN30D + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|15Y;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE")+";" +Data.Get("Collateral Type") + "|" + Data.Get("GLOBAL_COLLATERAL_TAB_VALUE"));

            Report.Step("Step 49.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 50.0: Login to PD TELLER Application using the newly created created User credentials.");
            Application.Teller.Login(UserID,PWD,Data.Get("GLOBAL_BRANCH"));

            Report.Step("Step 51.0: Posting of MTG:Post a disbursement to the Mortgage Loan Account <MTGACCT_ERCR026> for USD 10,000.00 on system date - 30 using Transaction Code MD (MD - Disbursement). Offset the transaction using Transaction Code CO.");
            Application.Teller.LoanDisbursement(MTGACCNUM, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"),SYSTEMDATEMIN30D);

            Report.Step("Step 52.0:On Teller application, post the Credit transactions to the MTG account created.");
            string PMTMTG = Profile7CommonLibrary.ExtractDataFromDataBase("Select PMT FROM LN WHERE CID ='"+CONLNACCNUM1+"'","PMT");
            Application.Teller.LoanPayment(MTGACCNUM, PMTMTG);

            Report.Step("Step 53.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");  

            Report.Step("Step 54.0: Login to PDTELLER application.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 55: Error correction -MTG :Expected Result (R-40): Verify that the transaction posted for Amount: <GLOBAL_PMT_AMOUNT> can not be error-corrected.");
            Application.Teller.ErrorCorrectionTellerTransaction("MP|"+MTGACCNUM+"|USD|"+PMTMTG);

            Report.Step("Step 56.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");  

            Report.Step("Step 57.0: Open PD TELLER Application  User ID:  User ID created in Step 1 <CUST_NUM>. & Branch:  Different Branch ID other than 0 – Back Office.");
            Application.Teller.Login(UserID,PWD,"GLOBAL_BRANCH_CODE2");

            Report.Step("Step 58.0: Errorcorrection for MTG:Expected Result (R-41):  Verify that the transaction posted for Amount: <GLOBAL_PMT_AMOUNT> can not be error-corrected.");
            Application.Teller.ErrorCorrectionTellerTransaction("MP|"+MTGACCNUM+"|USD|"+PMTMTG);

            Report.Step("Step 59.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");  

            Report.Step("Step 60.0: Login to PDTELLER application.");
            Application.Teller.Login(UserID,PWD,Data.Get("GLOBAL_BRANCH"));

            Report.Step("Step 61.0:Errorcorrection for MTG:Error Correct the transaction posted for Consumer Loan Account for Amount: <GLOBAL_PMT_AMOUNT>.");
            Application.Teller.ErrorCorrectionTellerTransaction("MP|"+MTGACCNUM+"|USD|"+PMTMTG);

            Report.Step("Step 62.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");  

            Report.Step("Step 63.0: Login to the Profile WebCSR. 'CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 64.0: Get the Mortgage Loan Account and Expected Result (R16, R40, R41, and R37):  Verify the following: Verify that the Account History table shows the entry for the following details - Date: SystemDate and Credits:<-GLOBAL_PMT_AMOUNT>.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(MTGACCNUM, ApplicationDate1 + ";-"+PMTMTG); 

            Report.Step("Step 65.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));     

            Report.Step("Step 66.0: Login to PDTELLER application.");
            Application.Teller.Login(UserID,PWD,Data.Get("GLOBAL_BRANCH"));

            Report.Step("Step 67.0: Error correction:Error Correct the transaction posted for Consumer Loan Account for Amount: <GLOBAL_AMOUNT_10K>.");
            Application.Teller.ErrorCorrectionTellerTransaction("MD|"+MTGACCNUM+"|USD|10000.00");

            Report.Step("Step 68.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");  

            Report.Step("Step 69.0: Login to the Profile WebCSR. 'CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 70.0: Get the Mortgage Loan Account Expected Result (R11, R22, R40, R41, and R37):  Verify the following: Verify that the Account History table shows the entry for the following details - Date: SystemDate, Debits:-10,000.00 and Description: DISBURSEMENT (Error Corrected).");
            Application.WebCSR.VerifyDataInAccountHistoryTable(MTGACCNUM, ApplicationDate1 + ";DISBURSEMENT (Error Corrected)" +";" + "-10000.00"); 

            Report.Step("Step 71.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));     

            Report.Step("Step 72.0: End of the Test Script  : SNTY030_ERCR026.");

        }
    }
}

