using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest014:TestBase
    { 
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Funds Transfer between the Deposit accounts and Deposit to Loan Accounts. (One Time & Frequency)")]
        public void ProfileSmokeTest014()
        {
            Report.Step("Step 1.0:Login into Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 2.0: Copy a Consumer Loan product <CONPRODNUM1> using the standard Consumer Loan product type - 500 using the naming convention.");
            string CONPRODNUM1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_CONSUMER_LOAN"),Data.Get("GLOBAL_STD_PROD_NUM_500"),true); 

            Report.Step("Step 3.0: Get the newly created Consumer Loan product <CONPRODNUM1> created in Step 2.0.");
            Application.WebAdmin.GetProduct(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_CONSUMER_LOAN"),CONPRODNUM1);

            Report.Step("Step 4.0: Log out of Profile WebAdmin");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 5.0 Reload Tomcat Server. ");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 6.0: Store the account number in Dayend data sheet.");
            Data.Store("CONPRODNUM1",CONPRODNUM1);

            
        }

        
       
    }
}