using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest008 : TestBase
    {
        static WindowsApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        [Test]
        [Property("TestDescription", "TRANSACTION POSTED TO DEPOSIT CLASS, SAV GROUP ,DDA GROUP,RC GROUP  CAN BE ERROR-CORRECTED.")]
        public void ProfileSmokeTest008()
        {

            Report.Step("Step 1.0: Login to Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate1 = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEPLUS1D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 1);

            Report.Step("Step 2.0: Create a new customer with all required fields.");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create a Savings account using the standard Savings Product Type -300.");
            string SAVACC = Application.WebCSR.Create_Account(CIF1,Data.Get("GLOBAL_RELATION_SINGLE"),Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), "", 1, Data.Get("Account Name") + "|" + "SAVACC" + ";" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"));

            Report.Step("Step 4.0: Create a  DDA  account using the standard DDA Product Type - 400.");
            string DDACCNUM1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_400"), "", 1, Data.Get("Account Name") + "|DDAACCNUM1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"));
            
            Report.Step("Step 5.0: Create a Certificate of Deposit account using standard CD Product Type - 350.");
            string CDACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_350"), "", 1, Data.Get("Account Name") + "|CDACCTNUM;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_1K") + ";" + Data.Get("Term") + "|2D");

            Report.Step("Step 6.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 7.0: Login to PDTELLER application.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("SD  POSTING");
            Report.Step("Step 8.0: Post a Deposit transaction to the savings account for 10,000.00 using transaction code SD (Savings Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(SAVACC,Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"));

            Report.Step("Step 9.0: Post another Deposit transaction of amount 5000.00 to the savings account.");
            Application.Teller.DepositFunds(SAVACC,Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"));

            Report.Step("DDA posting");
            Report.Step("Step 10.0: Post a Deposit transaction to the Demand Deposit Account for 10,000.00 using transaction code DD (Demand Deposit). Offset the transaction using transaction code CI.Post a Deposit transaction to the Demand Deposit Account for 10,000.00 using transaction code DD (Demand Deposit). Offset the transaction using transaction code CI.");
            Application.Teller.DepositFunds(DDACCNUM1,Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"));

            Report.Step("Step 11.0: Post another Deposit transaction of amount 5000.00 to the Demand Deposit account.");
            Application.Teller.DepositFunds(DDACCNUM1,Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"));

            Report.Step("Step 12.0: Expected Result (R45): Verify when error-correcting a transaction the system uses the same offset transaction, which was used when the transaction was originally posted, to offset the error-correct. The amounts appear in Red color.");
            Application.Teller.ErrorCorrectionTellerTransaction("DD|"+DDACCNUM1+"|USD|5000.00");

            Report.Step("CD Posting ");
            Report.Step("Step 13.0: Post a Deposit transaction to the Certificate of Deposit Account for 10,000.00 using transaction code CD (CD Deposit). Offset the transaction using transaction code CI.");
            Application.Teller.DepositFunds(CDACCT,Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"));

            Report.Step("Step 14.0: Post another Deposit transaction of amount 5000 to the certificate of deposit  account from setup (Step 1). ");
            Application.Teller.DepositFunds(CDACCT,Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"));

            Report.Step("Step 15.0: Login to WebCSR Application.'CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Verification of SD POSTING");
            Report.Step("Step 16.0: Get Saving Account and Expected Result:  Verify, via the deposit account history, the Balance tab and the Account Processing tab the following:");
            Report.Step("Step 17.0: Deposit Account history shows the entry for the SD transaction posted to Account.  & Ledger Balance (DEP.BAL) = 15,000.00, Available Balance (DEP.AVLBAL) = 15,000.00 and Collected Balance (DEP.BALCOL) = 15,000.00");
            Application.WebCSR.LoadAccountSummaryPage(SAVACC);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_15K")) + ";Collected Balance|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_15K"))  + ";Available Balance|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_15K")));
            
            Report.Step("Step 18.0: Select Transaction Processing Tab and Verify Last Credit Amount (DEP.AMTLC) = 5,000.00 & Last Credit Date (DEP.DTLC) = System Date (Date of the transaction posted).");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
            Application.WebCSR.VerifylabelValueByLabelName("Last Credit Amount:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_5K")) + ";Date of Last Credit:|" + ApplicationDate1 );

            Report.Step("Verification of DDA posting");
            Report.Step("Step 19.0: Get Saving Account and Expected Result (R46, R48, R49, R50): Verify, via the deposit account history, the Balance tab and the Account Processing tab the following:");
            Application.WebCSR.LoadAccountSummaryPage(DDACCNUM1);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Collected Balance|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"))  + ";Available Balance|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")));
                        
            Report.Step("Step 20.0: Select Transaction Processing Tab and Last Credit Amount (DEP.AMTLC) = 10,000.00 & Last Credit Date (DEP.DTLC) = System Date (Date of the original transaction).");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
            Application.WebCSR.VerifylabelValueByLabelName("Last Credit Amount:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Date of Last Credit:|" + ApplicationDate1 );

            Report.Step("verification of CDposting");
            Report.Step("Step 21.0: Get CD Account and Expected Result: Verify, via the deposit account history, the Balance tab and the Account Processing tab the following : ");
            Application.WebCSR.LoadAccountSummaryPage(CDACCT);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_15K")) + ";Collected Balance|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_15K"))  + ";Available Balance|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_15K")));
            
            Report.Step("Step 22.0: Select Transaction Processing Tab and Last Credit Amount (DEP.AMTLC) = 5,000.00 & Last Credit Date (DEP.DTLC) = System Date (Date of the original transaction).");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
            Application.WebCSR.VerifylabelValueByLabelName("Last Credit Amount:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_5K")) + ";Date of Last Credit:|" + ApplicationDate1 );

            Report.Step("Step 23.0: Get CD Account and Deposit Account history shows the entry for the CD transaction posted to Account.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CDACCT, ApplicationDate1 + ";DEPOSIT;"+Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"))); 

            Report.Step("Step 24.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 25.0:Error correction for  the transaction of SD Account:Reverse the transaction posted Amount 5000 to SAV account.");
            Application.Teller.ErrorCorrectionTellerTransaction("SD|"+SAVACC+"|USD|5000.00");

            Report.Step("Step 26.0: Error correction for Transaction of CD account:Reverse the transaction posted  Amount 5000 to CD account.");
            Application.Teller.ErrorCorrectionTellerTransaction("CD|"+CDACCT+"|USD|5000.00");

            Report.Step("Step 27.0: Login to WebCSR Application.'CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Verification of SD transaction");
            Report.Step("Step 28.0:Get Saving Account and Expected Result (R46, R48, R49, R50): Verify, via the deposit account history, the Balance tab and the Account Processing tab the following:");
            Report.Step("Step 29.0:Ledger Balance (DEP.BAL) = 10,000.00,Available Balance (DEP.AVLBAL) = 10,000.00,Collected Balance (DEP.BALCOL) = 10,000.00");
            Application.WebCSR.LoadAccountSummaryPage(SAVACC);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Collected Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"))  + ";Available Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")));
            
            Report.Step("Step 30.0: Select Transaction Processing Tab and Last Credit Amount (DEP.AMTLC) = 10,000.00 & Last Credit Date (DEP.DTLC) = System Date (Date of the original transaction).");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
            Application.WebCSR.VerifylabelValueByLabelName("Last Credit Amount:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Date of Last Credit:|" + ApplicationDate1 );

            Report.Step("Verification of CD Transaction account");
            Report.Step("Step 31.0: Get CD Account and Expected Result (R46, R48, R49, R50): Verify, via the deposit account history, the Balance tab and the Account Processing tab the following");
            Application.WebCSR.LoadAccountSummaryPage(CDACCT);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Collected Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"))  + ";Available Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")));
            
            Report.Step("Step 32.0: Select Transaction Processing Tab and Last Credit Amount (DEP.AMTLC) = 10,000.00 & Last Credit Date (DEP.DTLC) = (Date of the original transaction).");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
            Application.WebCSR.VerifylabelValueByLabelName("Last Credit Amount:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Date of Last Credit:|" + ApplicationDate1 );

            Report.Step("Step 33.0:Get CD Account and Deposit Account history shows the entry for the CD transaction posted to Account.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CDACCT, ApplicationDate1 + ";DEPOSIT (Error Corrected);-5,000.00");

            Report.Step("Step 34.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 35.0:Posting to SD  Account:Post a Debit transactions with Amount 2000 to the savings account using transaction code SD (Savings Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.WithdrawFunds(SAVACC,Data.Get("GLOBAL_AMOUNT_WITHDRAWL_2K"));

            Report.Step("Step 36.0:Posting to DDA: Using Teller application post the Debit transactions with Amount 2000 to the DDA.");
            Application.Teller.WithdrawFunds(DDACCNUM1,Data.Get("GLOBAL_AMOUNT_WITHDRAWL_2K"));

            Report.Step("Step 37.0:Error correction for DD:Reverse the transaction posted Amount 2000 to DD account.");
            Application.Teller.ErrorCorrectionTellerTransaction("DW|"+DDACCNUM1+"|USD|2000.00");

            Report.Step("Step 38.0:Posting to CD:Using Teller application post the Debit transactions with Amount 2000 to the CD account.");
            Application.Teller.WithdrawFunds(CDACCT,Data.Get("GLOBAL_AMOUNT_WITHDRAWL_2K"));

            Report.Step("Step 39.0:Login to WebCSR Application.'CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 40.0:Verification  of SD:Get Saving Account and Expected Result: Verify, via the deposit account history, the Balance tab and the Account Processing tab the following:");
            Report.Step("Step 41.0:Deposit Account history shows the entry for the SD transaction posted to Account & Ledger Balance (DEP.BAL) = 8,000.00,Available Balance (DEP.AVLBAL) = 8,000.00,Collected Balance (DEP.BALCOL) = 8,000.00");
            Application.WebCSR.LoadAccountSummaryPage(SAVACC);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_DEPOSITED_8K")) + ";Collected Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_DEPOSITED_8K"))  + ";Available Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_DEPOSITED_8K")));
            
            Report.Step("Step 42.0:Select Transaction Processing Tab Last Debit Amount (DEP.AMTLD) = 2,000.00 & Last Debit Date (DEP.DTLD) = System Date (Date of the original transaction).");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
            Application.WebCSR.VerifylabelValueByLabelName("Last Debit Amount:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_WITHDRAWL_2K")) + ";Date of Last Debit:|" + ApplicationDate1 );

            Report.Step("Step 43.0:Verification of DDA:Get Saving Account and Expected Result: Verify, via the deposit account history, the Balance tab and the Account Processing tab the following:");
            Application.WebCSR.LoadAccountSummaryPage(DDACCNUM1);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Collected Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Available Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")));
            
            Report.Step("Step 44.0:Select Transaction Processing Tab and Verify Last Debit Amount (DEP.AMTLD) = Blank or Null & Last Debit Date (DEP.DTLD) = Null.");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
            Application.WebCSR.VerifylabelValueByLabelName("Last Debit Amount:|"+""+ ";Date of Last Debit:|" +"");

            Report.Step("Verification of CD");
            Report.Step("Step 45.0:Get CD Account and Expected Result: Verify, via the deposit account history, the Balance tab and the Account Processing tab the following :");
            Application.WebCSR.LoadAccountSummaryPage(CDACCT);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_DEPOSITED_8K")) + ";Collected Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_DEPOSITED_8K")) + ";Available Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_DEPOSITED_8K")));
            
            Report.Step("Step 46.0: Select Transaction Processing Tab and Last Debit Amount (DEP.AMTLD) =2,000.00 & Last Debit Date (DEP.DTLD) = System Date (Date of the transaction posted).");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
             Application.WebCSR.VerifylabelValueByLabelName("Last Debit Amount:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_WITHDRAWL_2K")) + ";Date of Last Debit:|" + ApplicationDate1 );

            Report.Step("Step 47.0:Get CD Account and Deposit Account history shows the entry for the CW transaction posted to Account.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CDACCT, ApplicationDate1 + ";WITHDRL;2,000.00");

            Report.Step("Step 48.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 49.0:Error correct ion for SD:Reverse the Transaction posted with amount 2000 to Savings Account.");
            Application.Teller.ErrorCorrectionTellerTransaction("SW|"+SAVACC+"|USD|2000.00");

            Report.Step("Step 50.0:Error correction for CD:Reverse the transaction posted with Amount 2000 to CD Account.");
            Application.Teller.ErrorCorrectionTellerTransaction("CW|"+CDACCT+"|USD|2000.00");

            Report.Step("Step 51.0: Login to WebCSR Application.'CALL THE LOGON SCRIPT FOR SETTING THE BASE STATE FOR THE APPLICATION.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 52.0:Verification of SD:Get Saving Account,Ledger Balance (DEP.BAL) = 10,000.00,Available Balance (DEP.AVLBAL) = 10,000.00,Collected Balance (DEP.BALCOL) = 10,000.00");
            Application.WebCSR.LoadAccountSummaryPage(SAVACC);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Collected Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Available Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")));
            
            Report.Step("Step 53.0:Select Transaction Processing Tab and Last Debit Amount (DEP.AMTLD) = Blank or Null & Last Debit Date (DEP.DTLD) = Null.");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
            Application.WebCSR.VerifylabelValueByLabelName("Last Debit Amount:|"+ "" + ";Date of Last Debit:|" + "" );

            Report.Step("Step 54.0:Verification of CD:Get Saving Account and Expected Result: Verify, via the deposit account history, the Balance tab and the Account Processing tab the following:");
            Application.WebCSR.LoadAccountSummaryPage(CDACCT);
            Application.WebCSR.VerifylabelValueByLabelName("Ledger Balance:|"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")) + ";Collected Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"))  + ";Available Balance:|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")));
            
            Report.Step("Step 55.0:Select Transaction Processing Tab and Last Debit Amount (DEP.AMTLD) = Blank or Null & Last Debit Date (DEP.DTLD) = Null.");
            Application.WebCSR.NavigatetoTransactionProcessingPage();
            Application.WebCSR.VerifylabelValueByLabelName("Last Debit Amount:|"+ "" + ";Date of Last Debit:|" + "" );

            Report.Step("Step 56.0:Get CD Account and Deposit Account history shows the entry for the CW transaction posted to Account.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(CDACCT, ApplicationDate1 + ";WITHDRL (Error Corrected);-2,000.00");

            Report.Step("Step 57.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 58.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller"); 

            Report.Step("Step 59.0: End of the Test Script: PRFSMK008");
        }

    }
}

