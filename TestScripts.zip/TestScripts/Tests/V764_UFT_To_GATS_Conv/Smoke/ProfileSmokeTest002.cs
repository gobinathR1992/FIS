using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest002 : TestBase
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property("TestDescription", "Verify New Product type of CD deposit class & RC loan Class can be created, modified and deleted , navigating to  all Tabs and Verify the Navigation of all Tabs in InstitutionVariables")]
        public void ProfileSmokeTest002()
        {
            Report.Step("Step 1.0:Login into Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
                  
            Application.WebAdmin.VerifyDropdownInProductFactory(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),"Product Group|CD - Certificates of Deposit;Product Group|DDA - Demand Deposits;Product Group|DBD - Debit Balance Deposits;Product Group|ESC - Escrow;Product Group|SAV - Savings;Product Group|WASH - Wash"); 
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),"9620","Interest","Posting Options","Posting Options");

            Report.Step("Step 2.0:  Expected Result: R1: Verify ability to create New Deposit class product type by copying from an existing product type of the same class.");
            string CDPROD = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),Data.Get("GLOBAL_STD_PROD_NUM_350"),true);   

            Report.Step("Step3.0: Expected Result (R7): Verify Copy From field displays only Deposit class product types.");
            Application.WebAdmin.VerifyDropdownInProductFactory(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),"Product Group|CD - Certificates of Deposit;Product Group|DDA - Demand Deposits;Product Group|DBD - Debit Balance Deposits;Product Group|ESC - Escrow;Product Group|SAV - Savings;Product Group|WASH - Wash"); 
            Application.WebAdmin.VerifyDropdownInProductFactory(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),"Product Group|COM - Commercial Loans;Product Group|CBL - Credit Balance Loans;Product Group|CC - Credit Cards;Product Group|DM - Demand Loans;Product Group|LN - Consumer Loans;Product Group|MTG - Mortgage Loans;Product Group|RC - Revolving Credit Loans");   
            
            Report.Step("Step 4.0: Expected Result (R10): Verify an error message “Product Number already exists” is displayed.");
            Application.WebAdmin.VerifyProductExistsCopyProduct(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),Data.Get("GLOBAL_STD_PROD_NUM_350"), CDPROD );

            Report.Step("Step 5.0:Modify the CD Deposit product created above.");
            Report.Step("Step 6.0: Select the Statements Tab, set Suppress Balance Print(PRODCTL.BALSUP):  Y and Expected Result (R2 and R23): Verify user can modify the Deposit class product type and Non-Defaulting attributes of Deposit class product type created in step1 is modified.");
            Application.WebAdmin.UpdateStatementsSuppressBalancePrintOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD ,true);

            Report.Step("Step 7.0:Select Transaction Processing Tab.,set Permit Payment Order(PRODDFTD.EFTDEB):  Y and Expected Result (R24): Verify New Account defaults of Deposit class product type created in step1 is modified.");
            Application.WebAdmin.UpdateFundsTransferPermitPaymentOrderOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,true);

            Report.Step("Step 8.0:Get product to verify all  tabs for the CD Deposit Product Type. ");
            Application.WebAdmin.GetProduct(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD);

            Report.Step("Step 9.0: Select US Regulatory Tab And verify for Regulatory Options.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"U.S. Regulatory","Regulatory Options");

            Report.Step("Step 10.0: Select Transaction ProcessingTab And verify for Funds Transfer.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Transaction Processing","Funds Transfer");

            Report.Step("Step 11.0:Select interest Tab  And verify for Daily Calculation.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Interest","Daily Calculation");

            Report.Step("Step 12.0: Select Rate determination Tab/interest Tab And verify for Promotional Rate.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Interest","Promotional Rate","Rate Determination");

            Report.Step("Step 13.0:Select Tiered index valuesTab/interest Tab  And verify for Account Tiered Index Values.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Interest","Account Tiered Index Values","Tiered Index Values");

            Report.Step("Step 14.0: Select Posting	OptionsTab/interest Tab  And verify for Posting Options.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Interest","Posting Options","Posting Options");

            Report.Step("Step 15.0: Select Negative interest Tab/interest Tab  And verify for Negative Interest.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Interest","Negative Interest","Negative Interest");

            Report.Step("Step 16.0:  Select Term Accounts  And verify for Maturity Information.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Term Accounts","Maturity Information");

            Report.Step("Step 17.0: Select Penalty  Tab /Term Accounts And verify for Penalty.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Term Accounts","Penalty","Penalty");

            Report.Step("Step 18.0: Select Notice accounts tab  /Term Accounts And verify for Notice Accounts.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Term Accounts","Notice Accounts","Notice Accounts");

            Report.Step("Step 19.0: Select Scheduled Deposits  tab  /Term Accounts And verify for Scheduled Deposits.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Term Accounts","Scheduled Deposits","Scheduled Deposits");

            Report.Step("Step 20.0: Select Service Fees tab   And verify for Debit Service Fees.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Service Fees","Debit Service Fees");

            Report.Step("Step 21.0:Select Comercial analysis tab /Service Fees  And verify for Earnings Analysis.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Service Fees","Earnings Analysis","Commercial Analysis");

            Report.Step("Step 22.0: Select Checkbook Tab  And verify for Checkbook.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Checkbook","Checkbook");

            Report.Step("Step 23.0: Select Savings IncentiveTab  And verify for Program Details.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Savings Incentive","Program Details");

            Report.Step("Step 24.0:Select Funds AvailabilityTab  And verify for Check Holds.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Funds Availability","Check Holds");

            Report.Step("Step 25.0: Select Overdraft Tab  And verify for Authorized.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Overdraft","Authorized");

            Report.Step("Step 26.0:Select Linked Overdraft Tab/Overdraft Tab  And verify for Linked Account Overdraft.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Overdraft","Linked Account Overdraft","Linked Overdraft");

            Report.Step("Step 27.0:Select Investment Sweep Tab  And verify for Investment Sweep.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Investment Sweep","Investment Sweep");

            Report.Step("Step 28.0: Select  Statements Tab  And verify for General Information.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Statements","General Information");

            Report.Step("Step 29.0: Select  Escrow Tab  And verify for General");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Escrow","General");

            Report.Step("Step 30.0: Select  Transaction Codes Tab  And verify for Adjustments.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Transaction Codes","Adjustments");

            Report.Step("Step 31.0: Select  Back office Tab/Transaction Codes Tab  And verify for Back Office.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Transaction Codes","Back Office","Back Office");

            Report.Step("Step 32.0: Select  Service fees Tab/Transaction Codes Tab  And verify for Service Fees.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Transaction Codes","Service Fees","Service Fees");

            Report.Step("Step 33.0: Select  Branch AuthorizationTab  And verify for Authorized Branches.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Branch Authorization","Authorized Branches");

            Report.Step("Step 34.0: Select  Target Balance AccountsTab  And verify for Target Balance Accounts.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"Target Balance Accounts","Target Balance Accounts");

            Report.Step("Step 35.0: Select General Tab  And verify for  General Information.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD,"General","General Information");

            Report.Step("Step 36.0: Delete the CD Product Type created above and Expected Result (R13 and R3): Verify confirmation message “Delete Product ~p1” is displayed and Deposit class product type is deleted.");
            Application.WebAdmin.DeleteProductFromProductsList(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"),CDPROD);

            Report.Step("Step 37.0: Click on Products Link on the Administration Center Page.");
            Report.Step("Step 38.0: Product Configuration Page --> 	Product Class	:	<Select 'L - Loan Accounts' from the dropdown>.");
            Report.Step("Step 39.0: Expected Result (R8): Verify Product Group dropdown displays only product types that belong to the Loan class.");
            Application.WebAdmin.VerifyDropdownInProductFactory(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),"Product Group|COM - Commercial Loans;Product Group|CBL - Credit Balance Loans;Product Group|CC - Credit Cards;Product Group|DM - Demand Loans;Product Group|LN - Consumer Loans;Product Group|MTG - Mortgage Loans;Product Group|RC - Revolving Credit Loans");   

            Report.Step("Step 40.0: Verify Product Group dropdown does not shows the Depost Product Types when 'L - Loan Accounts'  item is selected from Product Class Drop down.");
            Application.WebAdmin.VerifyDropdownInProductFactory(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),"Product Group|CD - Certificates of Deposit;Product Group|DDA - Demand Deposits;Product Group|DBD - Debit Balance Deposits;Product Group|ESC - Escrow;Product Group|SAV - Savings;Product Group|WASH - Wash"); 
            
            Report.Step("Step 41.0: Expected Result	:	(R14)	:	Verify New Loan class product type is created by copying from     an existing product type of the same class. ");
            string RCPROD = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),Data.Get("GLOBAL_STAND_CSRPROD_DESC_600"),true); 

            Report.Step("Step 42.0: Click on Products Link on the Administration Center Page.");
            Report.Step("Step 43.0: Product Configuration Page	-->	Product Class	:	L- Loan Account Class, Product Group	:	RC - Revolving Credit Loans and Click on Search button.");
            Report.Step("Step 44.0: Select the Standard RC Product Number  Radio button , Click on Copy Button to create a new product.Product Copy Page	-->	New Type :Enter the existing RCProduct Number. 	and Click on Submit Button.");
            Report.Step("Step 45.0: Expected Result (R11): Verify an error message “Product Number already exists” is displayed.");
            Application.WebAdmin.VerifyProductExistsCopyProduct(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),Data.Get("GLOBAL_STAND_CSRPROD_DESC_600"),RCPROD);

            Report.Step("Step 46.0:Get the RCProduct copied above to modify.");
            Report.Step("Step 47.0:Billing Stmt Design(PRODCTL.BFP):  1-LN,Summary Stmt Desc: Modify the Stmt Desc and Click on Submit Button ");
            Report.Step("Step 48.0: Expected Result (R15 and R25): Verify user can modify the Loan class product type and Non-Defaulting attributes of Loan class product type.");
            Application.WebAdmin.EditProductGeneralSection(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"","",Data.Get("^LNB2"));

            Report.Step("Step 49.0:Currency Code(PRODDFTC.CRCD):  USD and Click on Submit Button.");
            Report.Step("Step 50.0: Expected Result (R26): Verify New Account defaults of Loan class product type can be modified.");
            Application.WebAdmin.EditProductGeneralSection(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"","","",Data.Get("GLOBAL_LOAN_GEN_CURRCODE"));
            
            Report.Step("Step 51.0: Get  RC Product to verify the Avalability of Tabs.	");
            Application.WebAdmin.GetProduct(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD);

            Report.Step("Step 52.0: Select U.S. Regulatory	Tab and	verify	for	U.S. Regulatory.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"U.S. Regulatory","Regulatory Options");

            Report.Step("Step 53.0: Select New Accounts	Tab and	verify	for	New Accounts.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"New Accounts","New Accounts");

            Report.Step("Step 53.0: Select Transaction ProcessingTab and verify 	for	Transaction Processing.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Transaction Processing","Transaction Processing");

            Report.Step("Step 53.0:Select  Payment Application Tab and	verify	for	Payment Application.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Payment Application","Payment Application");

            Report.Step("Step 54.0: Select  Payment CalculationTab and verify for Calculation Options.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Payment Calculation","Calculation Options");

            Report.Step("Step 55.0: Select  Revolving Credit Payment /Payment CalculationTab and verify	for	Revolving Credit Payment.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Payment Calculation","Revolving Credit Payment","Revolving Credit Payment");

            Report.Step("Step 56.0: Select  Adjustable Payment /Payment CalculationTab and verify	for	Adjustable Payment.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Payment Calculation","Adjustable Payment","Adjustable Payment");

            Report.Step("Step 57.0: Select  Adjustable Payment Limits/Payment CalculationTab and verify	for	Adjustable Payment Limits.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Payment Calculation","Adjustable Payment Limits","Adjustable Payment Limits");

            Report.Step("Step 58.0: Select  G/L CategoriesTab and verify for G/L Categories.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"G/L Categories","G/L Categories");

            Report.Step("Step 59.0: Select  Interest Tab and verify	for	Calculation.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Interest","Calculation");

            Report.Step("Step 60,0: Select  Rate Determination / Interest Tab and verify	for	Rate Determination.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Interest","Rate Determination","Rate Determination");

            Report.Step("Step 61.0: Select  Capitalized Interest Processing / Interest Tab and verify	for	Capitalized Interest Processing.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Interest","Capitalized Interest Processing","Capitalized Interest Processing");

            Report.Step("Step 62.0: Select  Maturity/RenewalTab and verify	for	Maturity Processing.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Maturity/Renewal","Maturity Processing");

            Report.Step("Step 63.0: Select  Renewal Processing / Maturity/RenewalTab and verify for	Renewal Processing.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Maturity/Renewal","Renewal Options","Renewal Processing");

            Report.Step("Step 64.0: Select  Delinquency Tab and verify	for	Options.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Delinquency","Options");

            Report.Step("Step 65.0: Select  Notice Offset Days / Delinquency Tab and verify	for	Notice Offset Days.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Delinquency","Notice Selection","Notice Offset Days");

            Report.Step("Step 66.0: Select  Notice Selection / Delinquency Tab and verify	for	Notice Selection.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Delinquency","Notice Selection","Notice Selection");

            Report.Step("Step 67.0: Select  Counters - Days / Delinquency Tab and verify for Counters - Days.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Delinquency","Counters - Days","Counters - Days");

            Report.Step("Step 68.0: Select  Escrow Analysis Tab and verify	for	Escrow Analysis.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Escrow Analysis","Escrow Analysis");

            Report.Step("Step 69.0: Select  Transaction Codes Tab and verify for Adjustments.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Transaction Codes","Adjustments");

            Report.Step("Step 70.0: Select  Payments / Transaction Codes Tab and verify for Payments.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Transaction Codes","Payments","Payments");

            Report.Step("Step 71.0: Select  Payoff / Transaction Codes Tab and verify	for	Payoff.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Transaction Codes","Payoff","Payoff");

            Report.Step("Step 72.0: Select  Fees/ Transaction Codes Tab and verify	for	Fees.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Transaction Codes","Fees","Fees");

            Report.Step("Step 73.0: Select  Escrow /Transaction Codes Tab and verify for Escrow.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Transaction Codes","Escrow","Escrow");

            Report.Step("Step 74.0: Select  Branch AuthorizationTab and verify	for	Authorized Branches.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Branch Authorization","Authorized Branches");

            Report.Step("Step 75.0: Select  Credit CardsTab and verify	for	Credit Cards.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"Credit Cards","Credit Cards");

            Report.Step("Step 76.0: Select  General Tab and verify	for	General Information.");
            Application.WebAdmin.VerifyValuesByLabelNameLabelValueInProductsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_REVOLVINGCREDIT_LOAN"),RCPROD,"General","General");

            Report.Step("Step 77.0: Select Institution Variables Link (Administration Center Page ->Table Configuration -> Institution Variables).");
            Application.WebAdmin.NavigatetoInstitutionVariablePage();           

            Report.Step("Step 78.0: Select GeneralTab And verify for  Institution Information.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("General","General");            
            
            Report.Step("Step 79.0: Select U.S. Regulatory  Tab And verify for  Year End Reporting. ");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("U.S. Regulatory","Year-End Reporting");     
            
            Report.Step("Step 80.0: Select  Regulatory 2 Link /U.S. RegulatoryTab  And verify for  Regulation CC Control Options.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("U.S. Regulatory","Regulation CC Control Options","Regulatory 2");
            
            Report.Step("Step 81.0: Select  OTS TFR Link / U.S. RegulatoryTab  And verify for  Schedule DI.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("U.S. Regulatory","Schedule DI","OTS Thrift Financial Report");

            Report.Step("Step 82.0: Select  AccountsTab  And verify for Customer Information.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("Accounts","Customer Information");

            Report.Step("Step 83.0: Select  Deposit Link / AccountsTab  And verify for  Interest Processing.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("Accounts","Interest Processing","Deposit");

            Report.Step("Step 84.0: Select Retirement Link / AccountsTab  And verify for  Default Reason Codes.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("Accounts","Default Reason Codes","Retirement");

            Report.Step("Step 85.0: Select  Loan Link / AccountsTab  And verify for  Loan Accrual Adjustments.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("Accounts","Loan Accrual Adjustments","Loan");

            Report.Step("Step 86.0: select  Loan Reporting Link / AccountsTab  And verify for  Escrow Processing.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("Accounts","Escrow Processing","Loan Reporting");

            Report.Step("Step 87.0: Select  Delinquency Classification Link / AccountsTab  And verify for  Provision Processing.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("Accounts","Provision Processing","Delinquency Classification");

            Report.Step("Step 88.0: Select Transaction Processing Tab  And verify for Teller.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("Transaction Processing","Teller");

            Report.Step("Step 89.0: Select  Payment System Link / Transaction Processing Tab  And verify for  Random Payment Order Processing.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("Transaction Processing","Random Payment Order Processing","Payment System");

            Report.Step("Step 90.0: Select  Foreign Currency Link / Transaction Processing Tab  And verify for  Foreign Currency Posting.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("Transaction Processing","Foreign Currency Posting","Foreign Currency");

            Report.Step("Step 91.0: Select System Tab  And verify for Integrity Information.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("System","Integrity Information");

            Report.Step("Step 92.0: Select  System Management Link / SystemTab  And verify for  Dayend Processing.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("System","Dayend Processing","System Management");

            Report.Step("Step 93.0: Select General LedgerTab  And verify for  General Ledger Reporting.");
            Application.WebAdmin.VerifyTabsInInstitutionVariablePage("General Ledger","General Ledger Reporting");

            Report.Step("Step 94.0: Logoff from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 95.0: Report Scenario Result.");
        }

    }
}

