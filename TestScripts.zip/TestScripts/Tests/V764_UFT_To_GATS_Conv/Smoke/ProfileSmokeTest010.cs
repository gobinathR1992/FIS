using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.Smoke
{
    [TestFixture]
    public class profileSmokeTest010:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "This is TestBased sample test")]
        public void ProfileSmokeTest010()
        {            
            Report.Step("Step 1.0: Log in to Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate1 = Application.WebCSR.GetApplicationDate();
           
            string SYSTEMDATEMINUS20D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -90);
            
            Report.Step("Step 2.0: In Profile WebCSR, create a Personal Customer <CIF1> by entering all required fields (Profile WebCSR | Basic Services | Create Personal Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0:Create a Savings account <SAVAccnum1> using the copied Savings product type <SAVPRODName1> for the Personal customer <CIF1> with following values: Name: SAV; Opening Date: <System Date-20 days>; Opening Deposit: USD 100; Currency: USD (Profile WebCSR | Basic Services | Create account).");
            string SAVACC = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), "", 1, Data.Get("Account Name") + "|" + "SAVACC" + ";" + Data.Get("Opening Date") + "|" + SYSTEMDATEMINUS20D + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"));

            Report.Step("Step 5.0: Login to the Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 6.0:In Profile Teller, post a deposit transaction of $250,000 to savings account <SAVACC1> on account opening date.");
            Application.Teller.DepositFunds(SAVACC, Data.Get("300000.00"), SYSTEMDATEMINUS20D);

            Report.Step("Step 7.0: Logoff from Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");

            Report.Step("Step 8.0: In Profile WebAdmin, select FDIC menu item from left navigation pane | select function Deposit Insurance Calculation } set Run Insurance Calculation:Y | click Run.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            Application.WebAdmin.AddApplyHoldandRestricAccessInFDIC370Page(Data.Get("10 - FDIC Hold"));
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));       

            Report.Step("Step 10.0: Navigate to the Account Overview page of Savings account <SAVAccnum> (Search for the customer <CIF1> on the Customer Search page | Select Account List from go to drop-down and click Submit | Select the link for account <SAVAccnum> on the Account List page).");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        
            Report.Step("Step 11.0:  In Profile WebCSR, navigate to the deposit account FDIC 370 page (Account Information | FDIC 370).");
            Report.Step("Step 12.0: Expected Result TC11: Verify that the Insured Amount <250000> and Un-insured amount <684.93> are displayed under FDIC 370 section.");
            string AccruedInterst = Application.WebCSR.CalculateAccruedInterestByAccrMethod(Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_13"),Data.Get("250000.00"),Data.Get("GLOBAL_INTEREST_RATE_10"),20,ApplicationDate1,"");
            Application.WebCSR.VerifyDataInFDIC370InsuranceSummaryTable(SAVACC,CIF1+";"+"SGL"+";"+Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("250000.00"))+";"+AccruedInterst+"|"+Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("250000.00"))+";"+AccruedInterst);

            Report.Step("Step 13.0: Navigate to the holds page (General Account Services | Account List). Select Account: Savings account <SAVAccnum1>.");
            Report.Step("Step 14.0: Expected Result TC28: Verify that the Hold Type <Permanent Hold>, Amount: <250,000.00 USD> are displayed on the Holds list page.");
            //Application.WebCSR.VerifyDataInHoldsTable(SAVACC,Data.Get("Permanent Hold"),Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("250000.00")));
            Application.WebCSR.VerifyDataInHoldsTable(SAVACC,Data.Get("Permanent Hold"),"303,465.21");

            Report.Step("Step 15.0:Add new cheque hold.");
            string SystemDatePlus360=appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(),"D",360);
            Application.WebCSR.AddHoldForSpecifiedAccountNumber(SAVACC,Data.Get("HLD8 - Check Hold"),Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"),"",SystemDatePlus360);

            Report.Step("Step 16.0: Delete the newly added cheque hold.");    
            Application.WebCSR.DeleteHoldForSpecifiedAccountnumber(SAVACC,SystemDatePlus360);    

            Report.Step("Step 17.0: Navigate to the Stops page (General Account Services | Account List).Select Account: Savings account <SAVAccnum1>.");
            Report.Step("Step 18.0: Add Stop to the SAV account <SAVCCNUM> with the following inputs ");
            string SystemDatePlus5=appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(),"D",5);
            Application.WebCSR.AddStopsForSpecifiedAccountNumber(SAVACC,Data.Get("Check Stop"),Data.Get("Reject"),Data.Get("STLNCK - Stolen Check"),SystemDatePlus5,Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K"),true);

            Report.Step("Step 19.0: Delete the newly added Stop.");
            Application.WebCSR.DeleteStopsForSpecifiedAccountNumber(SAVACC,SystemDatePlus5,true);

            Report.Step("Step 20.0:Add a new beneficiary ");
            //Application.WebCSR.AddBeneficiariesForAccount(SAVACC, 1, Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"), Data.Get("MK - NORTH MACEDONIA"));
            string BeneficiaryID = Application.WebCSR.AddBeneficiariesForAccount(SAVACC, 1, Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"), Data.Get("MK - NORTH MACEDONIA"),1);

            Report.Step("Step 21.0:  Delete the newly added beneficiary ");
            Application.WebCSR.DeleteBeneficiaryForSpecifiedAccountNumber(SAVACC,BeneficiaryID,true);

            Report.Step("Step 22.0:Add new restriction.");
            Application.WebCSR.AddAccountRestrictions(SAVACC, Data.Get("003-Temporary Signature"),"","","");

            Report.Step("Step 23.0:Delete the newly added cheque Restriction.");
            Application.WebCSR.DeleteRestrictionsForSpecifiedAccountNumber(SAVACC,ApplicationDate1,true);

            Report.Step("Step 24.0:Logoff from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            
        }               
    }
}