using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest013_TSR1:TestBase
    { 
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Add and Maintain Packages to the channel")]
        public void ProfileSmokeTest013_TSR1()
        {
            Report.Step("Step 1.0:Login into Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 2.0: Add  Packaged product types");

            Report.Step("Step 3.0: Verify the user is able to define the available Product Packages for account opening by specific channel. ");

            Report.Step("Step 4.0: Verify the user is able to define the available Product Packages for account opening by specific channel. ");

            Report.Step("Step 5.0: Verify the user is able to Add services to the product.");

            Report.Step("Step 6.0:Verify the user is able to define the allowable ownership / relationship choices for each package offering by channel.");

            Report.Step("Step 7.0: Logout from WebAdmin application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            
        }        
    }
}