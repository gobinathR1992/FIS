using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest011:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "Creation/Modification/Deletion/Cancellation of Payment Order.")]
        [Property("TestDescription", "This is TestBased sample test")]
        public void ProfileSmokeTest011()
        {
            Report.Step("Step 1.0: Login to Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate1 = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEPLUS5D = appHandle.CalculateNewDate(ApplicationDate1, "D", 5);

            Report.Step("Step 2.0: Create a new customer with all required fields.");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0:Create two new Demand Deposit accounts DDAACCNUM1 and DDAACCNUM2.");
            string CombinedAccount = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), 
                                    Data.Get("GLOBAL_STAND_CSRPROD_DESC_400"), "", 2,
	                                Data.Get("Account Name") + "|" + "DDAACCNUM1;" + 
                                    Data.Get("Account Name") + "|" + "DDAACCNUM2;"+ 
                                    Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + ";" +
                                    Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K"));

            string DDAACCNUM1 = appHandle.SplitString(CombinedAccount, "-")[0];
            string DDAACCNUM2 = appHandle.SplitString(CombinedAccount, "-")[1];
            
            Report.Step("Step 4.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Login to PDTELLER application.");
            Application.Teller.login_specified_application("Teller");

            Report.Step(" Step 6.0: Post a Deposit transaction to the Demand Deposit account for 1000 using Transaction code DD. Off set the transaction using CI.");
            Application.Teller.DepositFunds(DDAACCNUM1,Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"));

            Report.Step("Step 7.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");

            Report.Step("Step 8.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0: Schedule a Fund Transfer of $ 100.00 from DDAACCNUM1 to DDAACCNUM2.");
            Application.WebCSR.TransferFund(DDAACCNUM1,DDAACCNUM2,Data.Get("GLOBAL_AMOUNT_100"),SYSTEMDATEPLUS5D);

            Report.Step("Step 10.0: Modify the newly created Payment Order (Customer| Service| Payments| Domestic| Orders) and Expected Result (R2 and R40):  Verify the Payment Order is modified. ");
            Application.WebCSR.ModifyPendingTransfer(SYSTEMDATEPLUS5D,Data.Get("GLOBAL_AMOUNT_150"));

            Report.Step("Step 11.0: Delete the newly created Payment Order (Customer| Service| Payments| Domestic| Orders).");
            Application.WebCSR.DeletePendingTransfer(SYSTEMDATEPLUS5D);

            Report.Step("Step 4.0: Logout from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }              
    }
}