using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{

    [TestFixture]
    public class profileSmokeTest009 : TestBase
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property("TestDescription", "Verify Transactions posted to LN, RC and MTG groups can be error-corrected.")]
        public void ProfileSmokeTest009()
        {
            Report.Step("Step 1.0:Login into Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 2.0: Create a User in WebAdmin.");
            string UserID = Application.WebAdmin.Create_User(Data.Get("GLOBAL_USER_CLASS_SCA"));

            Report.Step("Step 3.0: Logout from WebAdmin application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 4.0 : Invoke Profile WebAdmin.");
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 5.0 :Login to WebAdmin application by using new user credentials and Change the Password for newly created user.");
            Application.WebAdmin.LoginWebAdminWithNewUserCredential(UserID);

            Report.Step("Step 6.0: Logout from WebAdmin application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 7.0:Login into Profile WebAdmin.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            string SYSTEMDATEMIN1Y = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", -1);

            Report.Step("Step 8.0: Copy a standard Mortgage Loan Product Type - 700.");
            string MTGPRODNUM1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_MORTGAGE_LOAN"),Data.Get("GLOBAL_STD_PROD_NUM_700"),true); 

            Report.Step("Step 9.0: Get the newly created Consumer Loan product <CONPRODNUM1> created in Step 2.0.");
            Application.WebAdmin.GetProduct(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_MORTGAGE_LOAN"),MTGPRODNUM1);

            Report.Step("Step 10.0: Loan General Page --> Start Date : System Date - 365 Days and click submit.");
            Application.WebAdmin.EditProductGeneralSection(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_MORTGAGE_LOAN"),MTGPRODNUM1,SYSTEMDATEMIN1Y);

            Report.Step("Step 11.0: Click on Transaction Processing Tab, Set Maximum Number of Disbursements:  1 and Click submit");
            Application.WebAdmin.UpdateTotalNumberOfDisbursment();
                        
            Report.Step("Step 12.0: Logout from WebAdmin application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 13.0 Reload Tomcat Server. ");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 14.0: Store Values in the Data Sheet.");
            Data.Store("UserID",UserID);
            Data.Store("MTGPRODNUM1",MTGPRODNUM1);

        }

    }
}

