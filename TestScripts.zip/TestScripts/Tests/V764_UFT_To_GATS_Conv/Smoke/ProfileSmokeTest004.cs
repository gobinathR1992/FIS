using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Smoke
{
    [TestFixture]
    public class profileSmokeTest004 : TestBase

    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string  UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        [Test]
        [Property("TestDescription", "PRFSMK004 Verify  the new loan history, account history,access of all tabs, teller posting and account verification of Loan product accounts Consumer loan, Mortgage loan and  Revolving credit loan")]
        public void ProfileSmokeTest004()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string SystemDate = Application.WebCSR.GetApplicationDate();  
            string dateparam = appHandle.GetDateParameters(SystemDate)[1].Trim();     
            
            Report.Step("Step 2.0: Create a new personal customer <CIF1> by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create a Loan Account <LNACCNUM> for the Personal Customer <CIF1> using the standard product type 500 (Opening Date. <System Date>; Disbursement Amount. <10,000.00>; Term. <1 Year>; Frequency = <1MAE> and Currency Code. <USD>) (WebCSR | Basic Services | Create Account).");
            string LNACCNUM = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"), "", 1, Data.Get("Account Name") + "|LNACCNUM;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|5Y" + ";" + Data.Get("Payment Frequency") + "|" + "1MA"+dateparam);

            Report.Step("Step 4.0 Verify an entry is recorded in account History detail page of newly created mortgage Loan Account.");
            Application.WebCSR.VerifyDataInAccountHistoryDetailsPopUp(LNACCNUM,Data.Get("GLOBAL_SETUP_ACCOUNT"),"Account Number|"+LNACCNUM+";Reference Number|1;Description|"+Data.Get("GLOBAL_SETUP_ACCOUNT")+";Posting Date|"+SystemDate+";User ID|"+StartupConfiguration.EnvironmentDetails.GLOBAL_USERID);
             
            Report.Step("Step 5.0 Verify the Tabs on Account Summary Page.");
            Application.WebCSR.VerifyTabsonAccountSummaryPage(LNACCNUM,"Title/Address;Interest;Payment;Adjustable Payment/Rate;Transaction Processing;Delinquency;Credit Card;Collateral;Loan Fees;Renewal;Maturity/Payoff;Escrow;U.S. Regulatory;Collections;General");

            Report.Step("Step 6.0: Create a Mortgage Loan using Standard Product Type (Customer| Service| Account| Add New Account).");
            string MTGACCNUM = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_700"), "", 1, Data.Get("Account Name") + "|MTGACCNUM;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Payment Frequency") + "|" + "1MA"+dateparam);

            Report.Step("Step 7.0 Update Amortization Calculation Method");
            Application.WebCSR.SelectAmortizationCalcMethodinPaymentApplicationPage(MTGACCNUM, "0 - Standard Calculation Method US & CAD");
        
            Report.Step("Step 8.0 Update customer code and verify an entry is recorded in account History detail page for customer code update.");
            Application.WebCSR.UpdateCustomerDetailsVerifyAccountHistoryDetailsPopUp(Data.Get("Customer Code"),Data.Get("Regular Customer"), MTGACCNUM, Data.Get("GLOBAL_ACCOUNT_MAINT1"), "Account Number|"+MTGACCNUM +";Description|Account Maintenance;Data Item|LN.CCODE;Old Value|0;New Value|1;Posting Date|"+SystemDate+";User ID|"+UID);
            
            Report.Step("Step 9.0 Modify Mailing Address 2 field and erify an entry is recorded in account History detail page for Address update.");
            Application.WebCSR.UpdateCustomerDetailsVerifyAccountHistoryDetailsPopUp(Data.Get("Update Address"),Data.Get("GLOBAL_ADDRESS2_VALUE"), MTGACCNUM, Data.Get("GLOBAL_ACCOUNT_MAINT3"), "Account Number|"+MTGACCNUM +";Description|Account Maintenance;Data Item|ACNADDR.AD2;New Value|"+Data.Get("GLOBAL_ADDRESS2_VALUE")+";Posting Date|"+SystemDate+";User ID|"+UID);
                    
            Report.Step("Step 10.0 Verify an entry is recorded in account History detail page of newly created mortgage Loan Account.");
            Application.WebCSR.VerifyDataInAccountHistoryDetailsPopUp(MTGACCNUM,Data.Get("GLOBAL_SETUP_ACCOUNT"),"Account Number|"+LNACCNUM+";Reference Number|1;Description|"+Data.Get("GLOBAL_SETUP_ACCOUNT")+";Posting Date|"+SystemDate+";User ID|"+UID);
            
            Report.Step("Step 11.0 : Create a loan account <RC_ACCT> using the Standard Product Type (Customer| Service| Account| Add New Account).");
            string RC_ACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_600"), "", 1, Data.Get("Account Name") + "|LNACC;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_5K") + ";" + Data.Get("Term") + "|2Y;" + Data.Get("Payment Frequency") + "|" + "1MA"+dateparam);

            Report.Step("Step 12.0 Update customer code and Verify an entry is recorded in account History detail page for customer code update.");
            Application.WebCSR.UpdateCustomerDetailsVerifyAccountHistoryDetailsPopUp(Data.Get("Customer Code"),Data.Get("Regular Customer"), RC_ACCT, Data.Get("GLOBAL_ACCOUNT_MAINT1"), "Account Number|"+RC_ACCT +";Description|Account Maintenance;Data Item|LN.CCODE;Old Value|0;New Value|1;Posting Date|"+SystemDate+";User ID|"+UID);
            
            Report.Step("Step 13.0 Modify Mailing Address 2 field and verify an entry is recorded in account History detail page for Address update.");
            Application.WebCSR.UpdateCustomerDetailsVerifyAccountHistoryDetailsPopUp(Data.Get("Update Address"),Data.Get("GLOBAL_ADDRESS2_VALUE"), RC_ACCT, Data.Get("GLOBAL_ACCOUNT_MAINT3"), "Account Number|"+RC_ACCT +";Description|Account Maintenance;Data Item|ACNADDR.AD2;New Value|"+Data.Get("GLOBAL_ADDRESS2_VALUE")+";Posting Date|"+SystemDate+";User ID|"+UID);
            
            Report.Step(" Step 14.0 Verify an entry is recorded in account History detail page of newly created Revolving Credit Loan Account.");
            Application.WebCSR.VerifyDataInAccountHistoryDetailsPopUp(RC_ACCT,Data.Get("GLOBAL_SETUP_ACCOUNT"),"Account Number|"+RC_ACCT+";Reference Number|1;Description|"+Data.Get("GLOBAL_SETUP_ACCOUNT")+";Posting Date|"+SystemDate+";User ID|"+UID);
            
            Report.Step("Step 15.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 16.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 17.0: Post a disbursement transaction to the Consumer Loan Account <LNACCNUM> with amount 10000.");
            Application.Teller.LoanDisbursement(LNACCNUM, Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"));

            Report.Step("Step 18.0: Post a disbursement transaction to the Mortgate Loan Account <MTGACCNUM> with amount 10000.");
            Application.Teller.LoanDisbursement(MTGACCNUM, Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"),"",true);

            Report.Step("Step 19.0: Post a disbursement transaction to the Revolving Credit Loan Account <RC_ACCT> with amount 10000.");
            Application.Teller.LoanDisbursement(RC_ACCT, Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"),"",true);

            Report.Step("Step 20.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            
            Report.Step("Step 21.0: Verify Consumer Loan Account passes integrity verification without error.");
            Application.WebCSR.VerifyAccountIntegrity(LNACCNUM);

            Report.Step("Step 27.0: Verify Mortgage Loan Account passes integrity verification without error.");
            Application.WebCSR.VerifyAccountIntegrity(MTGACCNUM);

            Report.Step("Step 28.0: Verify Revolving Credit Loan Account passes integrity verification without error.");
            Application.WebCSR.VerifyAccountIntegrity(RC_ACCT);

            Report.Step("Step 29.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Application.Teller.login_specified_application("Teller");
            Report.Step("Step 30.0: Post a payment to the Consumer Loan Account with amount 5000.");
            //string PMTLN = Profile7CommonLibrary.ExtractDataFromDataBase("Select PMT FROM LN WHERE CID ='"+LNACCNUM+"'","PMT");
            string PMTLN = Application.WebCSR.CalculateLoanEMIAmount(Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"),"10.00","5Y");
            Application.Teller.LoanPayment(LNACCNUM,PMTLN);

            Report.Step("Step 31.0: Post a Loan Pay off for Consumer Loan Account.");
            Application.Teller.LoanPayOffAdvancedTransactions(LNACCNUM, Data.Get("LPO"));

            Report.Step("Step 32.0: Post a payment to the Mortgage Loan Account with amount 5000.");
            //PMTLN = Profile7CommonLibrary.ExtractDataFromDataBase("Select PMT FROM LN WHERE CID ='"+MTGACCNUM+"'","PMT");
            PMTLN = Application.WebCSR.CalculateLoanEMIAmount(Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"),"10.00","1Y");
            Application.Teller.LoanPayment(MTGACCNUM,PMTLN);

            Report.Step("Step 33.0: Post a Loan Pay off for the  Mortgage Loan Account with pay off amount.");
            Application.Teller.LoanPayOffAdvancedTransactions(MTGACCNUM, Data.Get("MPO"));

            Report.Step("Step 34.0: Post a payment to the Revolving Credit Loan Account with amount 5000.");
            //PMTLN = Profile7CommonLibrary.ExtractDataFromDataBase("Select PMT FROM LN WHERE CID ='"+RC_ACCT+"'","PMT");
            PMTLN = Application.WebCSR.CalculateLoanEMIAmount(Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"),"10.00","2Y");
            Application.Teller.LoanPayment(RC_ACCT,PMTLN);

            Report.Step("Step 35.0: Post a Loan Pay off for Revolving Credit Loan Account with pay off amount.");
            Application.Teller.LoanPayOffAdvancedTransactions(RC_ACCT, Data.Get("MPO"));

            Report.Step("Step 36.0: Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

        }

    }
}
