using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement025TSR2Yp1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC32 - Verify that the year end related fields are updated when the net of interest adjustment posting transaction is 0 and when NEGIPO is set to 2.")]
        public virtual void InterestSettlement025TSR2YP1()
        {
            string DDAACC1 = Data.Fetch("InterestSettlement025TSR2","DDAACC1");

            Report.Step("Step 1: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);
            string SYSTEMDATEMIN5D = appHandle.CalculateNewDate(ApplicationDate, "D", -5);
            
            Report.Step("Step 2: Navigate to Account History and verify that the zero dollar interest transaction is posted to the account.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(DDAACC1, SYSTEMDATEMIN5D+";"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_20K")),"","","");
            
            Report.Step("Step 3: Verify that the POSACR and NEGACR components are updated with correct values in the Transaction Detail section.");
            string PosNegACRValue = Application.WebCSR.CalculatePosNegACR(Data.Get("GLOBAL_AMOUNT_REQUESTED_20K"), Data.Get("GLOBAL_VALUE_2"), ApplicationDate, Data.Get("1.1"),5);
            Application.WebCSR.ClickOnAccountHistoryTransactionLink(SYSTEMDATEMIN1D + ";" + Data.Get("DDA Increase Int Paid"));

            Report.Step("Step 4: Expected Result TC32 - Verify that the year end related fields are updated when the net of interest adjustment posting transaction is 0 and when NEGIPO is set to 2.");
            Application.WebCSR.VerifyPOSNEGACRAmount("Transaction Comment",PosNegACRValue);
            
        }
    }
}
