using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement025 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC32 - Verify that the year end related fields are updated when the net of interest adjustment posting transaction is 0 and when NEGIPO is set to 2.")]
        public virtual void InterestSettlement025()
        {
            string GLSetCodeNumber = Data.Fetch("InterestSettlementTDSETUP", "GLSetCodeNumber");

            Report.Step("Step 1: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN2D = appHandle.CalculateNewDate(ApplicationDate, "D", -2);
            string SYSTEMDATEMIN4D = appHandle.CalculateNewDate(ApplicationDate, "D", -4);

            Report.Step("Step 2: Navigate to Table Configuration | Interest Indexes and create a new Indexes: <INDEX> Index Type: <0 - Basis Index> and Click Submit.");
            string Index = Application.WebAdmin.CreateInterestIndex(Data.Get("0 - Basis Index"));

            Report.Step(" Step 3: Navigate to Table Configuration | Interet Indexes | <INDEX1> | Rates and add Interest Rates with the following values: a) Effective Date : SystemDate-4, b) Rate1: -1.1 c)Effective Date : SystemDate-2, d) Rate1: 1.1  and Click Submit.");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("0 - Basis Index"), Index, SYSTEMDATEMIN4D, Data.Get("-1.1"));
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("0 - Basis Index"), Index, SYSTEMDATEMIN2D, Data.Get("1.1"));

            Report.Step("Step 4: Logout from WEBADMIN Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 5: Reload the Tomcat Servers.");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Data.Store("Index", Index);     
        }
    }
}
