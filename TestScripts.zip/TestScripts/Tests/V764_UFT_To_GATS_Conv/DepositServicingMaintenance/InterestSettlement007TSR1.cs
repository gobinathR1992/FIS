using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement007TSr1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC08 - Verify that a 0 dollar interest posting transaction when the net interest of positive and negative accrued on negative balance is 0 and the account is configured to track the positive and negative accrued separately. (NEGACRPO=1 and NEGIPO=1).")]
        public virtual void InterestSettlement007TSR1()
        {
            string ProductCode1 = Data.Fetch("InterestSettlement007","ProductCode1");

            Report.Step("Step 1.0: Login to WEBADMIN  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);
            
            Report.Step(" Step 2.0: create a corporate customer: <CIF1> by entering all the mandatory fields (Basic Services| Create corporate Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step(" Step 3.0: Create a Deposit account <DDA_ACCOUNT3> for the customer <CIF1> using the Product Types <DDA_PRODUCT3> with the following details: a) Account Opening Date: <System Date-1>; b) Amount: 10,000.00; c) Currency: EURO and Click Submit (Basic Services| Create Account)");
            string DDAACC1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), ProductCode1, "", 1, Data.Get("Account Name") + "|DDAACC1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") +";"+ Data.Get("Currency Code") + "|" + Data.Get("EUR - Euro")+";"+Data.Get("Opening Date")  + "|" +  SYSTEMDATEMIN1D);
            
            Report.Step("Step 4.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 5.0: Post a Withdrawal transaction to the deposit account <DDA_ACCOUNT3> with the currency as EURO and opening date as System Date - 1 day for 10,000.00");
            Application.Teller.WithdrawFunds(DDAACC1, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"), SYSTEMDATEMIN1D, Data.Get("EUR"));

            Report.Step("Step 6.0: Search for the Deposit Account <DDA_ACCOUNT3> and calculate the Accrued Interest");
            string PosNegACRValue = Application.WebCSR.CalculatePosNegACR(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"), Data.Get("GLOBAL_VALUE_1"), ApplicationDate, Data.Get("3.9"), 5);

            Application.WebCSR.VerifyAccruedInterestInInterestAccrual(DDAACC1, "Accrued Interest" + "|" + 	PosNegACRValue);
            
            Report.Step("Step 7: Reload the Tomcat Servers.");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Data.Store("DDAACC1", DDAACC1);  
        }
    }
}
