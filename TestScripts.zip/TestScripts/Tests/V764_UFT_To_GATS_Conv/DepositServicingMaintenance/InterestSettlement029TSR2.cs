using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement029TSR2 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC38 -Verify the STMTCMB (Combined Statements) extract includes Transaction comment in Deposit Transaction Detail (717) record type for interest paid transaction that posted on the account where account has negative balance and account is configured as NEGIPO=2.")]
        public virtual void InterestSettlement029TSR2()
        {
            string ProductCode = Data.Fetch("InterestSettlement029TSR1", "ProductCode");

            Report.Step("Step 1: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN5D = appHandle.CalculateNewDate(ApplicationDate, "D", -5);
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);

            Report.Step("Step 2: In Profile WebCSR, create a personal customer <CIF1> by entering all the mandatory fields (Basic Services| Create Personal Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3: Create a Deposit account <DDA_ACCOUNT4> for the customer <CIF1> using the Product Types <DDA_PRODUCT4> with the following details: a) Account Opening Date: <System Date-4>; b) Amount: 10,000.00; c) Currency: EURO and Click Submit (Basic Services| Create Account)");
            string DDAACC1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), ProductCode, "", 1, Data.Get("Account Name") + "|DDAACC1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Opening Date") + "|" + SYSTEMDATEMIN5D + ";" + Data.Get("Currency Code") + "|" + Data.Get("EUR - Euro"));

            Report.Step("Step 4: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 5: Post a Withdrawal transaction to the deposit account <DDA_ACCOUNT4> for 20,000 with the currency as EURO on System Date-5");
            Application.Teller.WithdrawFunds(DDAACC1, Data.Get("GLOBAL_AMOUNT_REQUESTED_40K"), SYSTEMDATEMIN5D, Data.Get("EUR"));

            Report.Step("Step 6: Navigate to Account History and verify that the zero dollar interest transaction is posted to the account.");
            Application.WebCSR.VerifyDataInAccountHistoryTable(DDAACC1, SYSTEMDATEMIN1D + ";" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_40K")), "", "", "All");

            Report.Step("Step 7: Verify that the POSACR and NEGACR components are updated with correct values in the Transaction Detail section.");
            string PosNegACRValue = Application.WebCSR.CalculatePosNegACR(Data.Get("GLOBAL_AMOUNT_REQUESTED_40K"), Data.Get("GLOBAL_VALUE_2"), ApplicationDate, Data.Get("2.2"));

            Application.WebCSR.ClickOnAccountHistoryTransactionLink(ApplicationDate + ";" + SYSTEMDATEMIN1D);
            Application.WebCSR.VerifyPOSNEGACRAmount("Transaction Comment", PosNegACRValue);

            Report.Step("Step 8: Search for the Deposit Account <DDA_ACCOUNT4>, Navigate to Customer Services | Statement Groups, click on Add and Select the next date with SystemDate.");
            Application.WebCSR.CreateStatementGroupPage(Data.Get("GLOBAL_FREQUENCY_1DA"), ApplicationDate, DDAACC1, true, true);

            Data.Store("DDAAccountNumber", DDAACC1);
            Data.Store("PosNegACRValue", PosNegACRValue);
        }
    }
}
