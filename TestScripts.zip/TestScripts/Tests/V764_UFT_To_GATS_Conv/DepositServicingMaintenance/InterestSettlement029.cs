using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement029 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC38 -Verify the STMTCMB (Combined Statements) extract includes Transaction comment in Deposit Transaction Detail (717) record type for interest paid transaction that posted on the account where account has negative balance and account is configured as NEGIPO=2.")]
        public virtual void InterestSettlement029()
        {
            Report.Step("Step 1: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN3D = appHandle.CalculateNewDate(ApplicationDate, "D", -3);
            string SYSTEMDATEMIN5D = appHandle.CalculateNewDate(ApplicationDate, "D", -5);

            Report.Step("Step 2: Navigate to Table Configuration | Interest Indexes and create a new Indexes: <INDEX1> Index Type: <1 - Basis Index> and Click Submit.");
            string Index = Application.WebAdmin.CreateInterestIndex(Data.Get("0 - Basis Index"));

            Report.Step("Step 3: Navigate to Table Configuration | Interet Indexes | <INDEX1> | Rates and add Interest Rates with the following values: a) Effective Date : SystemDate-4, b) Rate1: -2.2 c)Effective Date : SystemDate-2, d) Rate1: 1.1  and Click Submit.");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("0 - Basis Index"), Index, SYSTEMDATEMIN3D, Data.Get("2.2"));
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("0 - Basis Index"), Index, SYSTEMDATEMIN5D, Data.Get("-2.2"));

            Report.Step("Step 4: Logout from WEBADMIN Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 5: Reload the Tomcat Servers.");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            
            Data.Store("Index", Index);
        }
    }
}
