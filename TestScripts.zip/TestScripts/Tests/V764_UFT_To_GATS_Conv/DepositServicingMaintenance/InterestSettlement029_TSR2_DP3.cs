using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class InterestSettlement029_TSR2_DP3 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC38 -Verify the STMTCMB (Combined Statements) extract includes Transaction comment in Deposit Transaction Detail (717) record type for interest paid transaction that posted on the account where account has negative balance and account is configured as NEGIPO=2.")]
        public virtual void Interestsettlement029_TSR2_DP3()
        {
            string PosNegACRValue = Data.Fetch("InterestSettlement029TSR2", "PosNegACRValue");

            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();

            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            string TempDate = appHandle.ConvertDateInGivenFormat(ApplicationDate, "r");
            string[] TempDateArr = TempDate.Split(' ');
            TempDate = TempDateArr[1].Trim();
            string TempMonth = TempDateArr[2].Trim();
            string TempYear = TempDateArr[3].Trim();

            Report.Step("Step 22.0: Download  the extract file to directory from the spool.");
         // string RemotePath = Profile7CommonLibrary.GetLocalFolderPath("outgoing");

            string returnfile = "FIS_LETSTMT_STMTCMB.EPR_" + TempDate + TempMonth.ToUpper() + TempYear;
            //Profile7CommonLibrary.DownloadFileFromRemotePath(returnfile, "/profile/qacrt_gtmlx/spool", RemotePath);

            Report.Step("Step 23.0: Expected Result : TC11 : Verify that Return Reason Code R16 can be used to return an item when processing a transaction using an ACH file.");
            //Profile7CommonLibrary.VerifyDataInFileByVerificationValues(RemotePath + "//" + returnfile, Data.Get("717") + appHandle.ReplaceString(Data.Get("NEGACR:$/POSACRNEGINTRATE:$"), "$", PosNegACRValue));

        }
    }
}
