using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement015TSR1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC16 - Verify that a 0 dollar interest transaction is posted when the net of interest adjustment posting transaction, due to an effective date deposit, is 0")]
        public virtual void InterestSettlement015TSR1()
        {
            string Index1 = Data.Fetch("InterestSettlement015","Index");
            string GLSetCodeNumber = Data.Fetch("InterestSettlementTDSETUP","GLSetCodeNumber");

            Report.Step("Step 1.0: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();

            Report.Step(" Step 2 :Copy a standard demand deposit product <COPYPRODUCT> using standard product type 400 (Product Factory|Products)");
            string CopyProduct = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), Data.Get("400"), true);
             
            Report.Step(" Step 3: Search for the product <COPYPRODUCT> and update the following: a) General Ledger Set Code: <GL_SET_CODE1>. (Product Factory | Products | <COPYPRODUCT> )");
            Application.WebAdmin.EditProductGeneralSection(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct, "", GLSetCodeNumber);

            Report.Step(" Step 4: Navigate to the Interest tab and  update the following: a) Accrual Base: Ledger Balance; b) Accrual Method: Actual/Actual 31/365,6, c) Minimum Balance To Accrue: NULL and click Submit. Actual/Actual      (31/365,6)");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct, Data.Get("Ledger Balance"),appHandle.ReplaceString(Data.Get("Actual/Actual      (31/365$6)"),"$",","),Data.Get("GLOBAL_BLANK_OR_NULL"));
            
            Report.Step("Step 5: Modify the Savings product type SAVPROD_STEP1 Get product SAVPROD_STEP1|Go to Deposit Rate Determination Page by clicking on Rate Determination Link on Interest Tab|Set Variable Interest Rate: Index and Change Frequency: 2DA.");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct, Data.Get("GLOBAL_BLANK_OR_NULL"), Index1, Data.Get("GLOBAL_FREQUENCY_2DA"), Data.Get("GLOBAL_BLANK_OR_NULL"), Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 6: Navigate to the Rate Posting Options sub Tab under the interest Tab update Disbursement Option as Remain on Deposit and Posting Frequency as 4DA");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),CopyProduct, Data.Get("RemainOnDeposit"),Data.Get("GLOBAL_FREQUENCY_4DA"), Data.Get("GLOBAL_BLANK_OR_NULL"));
            
            Report.Step("Step 7: Navigate to the Negative Interest link and update the following: a) Allow Negative Interest: Selected; b) Accrual Option: Positive and Negative Separately; c) Posting Option:Post Only Positive Net Accrued Interest/Dividend ; d) Accrue Positive Interest on Negative Balance (Negative Rate): Selected e)Post Zero-Dollar Interest Transactionâ€™: Selected and Click Submit.");
            Application.WebAdmin.UpdateTransactionCodesAdjustments(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct, true, Data.Get("Positive and Negative Accrued Separately"), Data.Get("Post Int/Div Accrued on Positive Bal and Neg Bal Separately"), Data.Get("GLOBAL_FREQUENCY_4DA"), true, true);

            Report.Step("Step 8: Navigate to Transaction Codes tab and update all the transaction codes related to Negative Interest Transaction Codes.");
            Application.WebAdmin.updateTransactionCodeAdjustmentPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct, "", "", "", "",Data.Get("AdjustmentsResidualInterestDebit"), Data.Get("AdjustmentsResidualInterestCredit"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceDebit"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceCredit"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceDebit"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceCredit"));

            Report.Step("Step 9: Logout from WEBADMIN Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 10.0 : Reload the Tomcat Servers.");
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Data.Store("ProductCode", CopyProduct);

        }
    }
}
