using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement033TSR1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC46- Verify that the zero dollar transaction is posted during CD rollover when the net of positive and negative accrued on positive balance is 0 and NEGIPO is set as 2. TC49 - Verify that the 0-dollar transaction is posted and the CD account is closed out when the net of positive and negative accrued on positive balance is 0 and NEGIPO is set as 2.")]
        public virtual void InterestSettlement033TSR1()
        {
            string ProductCode1 = Data.Fetch("InterestSettlement033", "ProductCode1");
            string ProductCode2 = Data.Fetch("InterestSettlement033", "ProductCode2");

            Report.Step("Step 1: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN2D = appHandle.CalculateNewDate(ApplicationDate, "D", -2);

            Report.Step("Step 2: In Profile WebCSR, create two corporate customers <CIF1> and <CIF2> by entering all the mandatory fields (Basic Services| Create Corporate Customer).");
            string CORPCIF1 = Application.WebCSR.createcorporatecustomer(Data.Get("GLOBAL_CORPORATE_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            string CORPCIF2 = Application.WebCSR.createcorporatecustomer(Data.Get("GLOBAL_CORPORATE_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3: Create two Deposit accounts <CD_ACCOUNT1> and <CD_ACCOUNT2> for the customers <CIF1> and <CIF2> using the Product Types <CD_PRODUCT1> and <CD_PRODUCT2> with the following details: a) Account Opening Date: <System Date-2>; b) Amount: 10,000.00; c) Currency: EURO and Click Submit (Basic Services| Create Account).");
            string LNACCT1 = Application.WebCSR.Create_Account(CORPCIF1, Data.Get("GLOBAL_RELATION_SINGLE") ,ProductCode1,"",1,  Data.Get("Account Name") + "|" + "DDAACC1;" +Data.Get("Opening Deposit") + "|" +  Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|4D;" + Data.Get("Currency Code") + "|" + Data.Get("EUR - Euro")+";"+Data.Get("Opening Date")  + "|" +  SYSTEMDATEMIN2D);
            string LNACCT2 = Application.WebCSR.Create_Account(CORPCIF2, Data.Get("GLOBAL_RELATION_SINGLE") ,ProductCode2,"",1,  Data.Get("Account Name") + "|" + "DDAACC2;" +Data.Get("Opening Deposit") + "|" +  Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|4D;" + Data.Get("Currency Code") + "|" + Data.Get("EUR - Euro")+";"+Data.Get("Opening Date")  + "|" +  SYSTEMDATEMIN2D);

            Report.Step("Step 4: Create an external account <EXT_ACC1> for the customer <CIF1> by navigating to Funding Services | External Accounts and Click Add.");            
            string EXTACN = Application.WebCSR.AddExternalAccountInWebCSR(LNACCT1, "322077818", Data.Get("Account Type"));
            // string LNACCT1 ="350000064400";
            // string LNACCT2="350000064413";
            // string EXTACN = "935908478";
            Application.WebCSR.UpdateTermAccountsMaturityDetails(LNACCT1, Data.Get("Close Transfer To External Account"), EXTACN, Data.Get("4 - Transfer to an External Account"), EXTACN);
            
            Report.Step("Step 5.0 Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Application.Teller.DepositFunds(LNACCT1, Data.Get("GLOBAL_AMOUNT_REQUESTED_100K"), SYSTEMDATEMIN2D, Data.Get("EUR"));
            
            Application.Teller.DepositFunds(LNACCT2, Data.Get("GLOBAL_AMOUNT_REQUESTED_100K"), SYSTEMDATEMIN2D, Data.Get("EUR"));
            

            Application.WebCSR.UpdateInterestRate(LNACCT1, Data.Get("5"));

            Application.WebCSR.UpdateInterestRate(LNACCT2, Data.Get("5"));
            

            Report.Step("Step 17: Logout from WEBCSR Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 18: Reload the Tomcat Servers.");
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Data.Store("CORPCIF1", CORPCIF1);   
            Data.Store("CORPCIF2", CORPCIF2);   
            Data.Store("LNACCT1", LNACCT1);   
            Data.Store("LNACCT2", LNACCT2);   
            Data.Store("EXTACN", EXTACN);   
            
        }
    }
}
