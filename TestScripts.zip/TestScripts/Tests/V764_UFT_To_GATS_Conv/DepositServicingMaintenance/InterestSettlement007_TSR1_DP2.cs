using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement007_TSr1_DP2 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that a 0 dollar interest posting transaction when the net interest of positive and negative accrued on negative balance is 0 and the account is configured to track the positive and negative accrued separately. (NEGACRPO=1 and NEGIPO=1)")]
        public virtual void InterestSettlement007_TSR1_DP2()
        {
            string AccountNumber = Data.Fetch("InterestSettlement007TSR1", "DDAACC1");

            Report.Step("Step 1.0: Login to WEBADMIN  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);

            Report.Step("Step 2: Navigate to Account History and verify that the zero dollar interest transaction is posted to the account");
            Application.WebCSR.VerifyDataInAccountHistoryTable(AccountNumber, SYSTEMDATEMIN1D + ";" + "-" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")), "", "", "All");

            string PosNegACRValue = Application.WebCSR.CalculatePosNegACR(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"), Data.Get("GLOBAL_VALUE_1"), ApplicationDate, Data.Get("3.9"), 5);

            Report.Step("Step 3: Verify that the POSACR and NEGACR components are updated with correct values in the Transaction Detail section");
            Application.WebCSR.ClickOnAccountHistoryTransactionLink(SYSTEMDATEMIN1D + ";" + "DDA Increase Int Paid");
            Application.WebCSR.VerifyPOSNEGACRAmount("Transaction Comment", PosNegACRValue, 5);


        }
    }
}
