using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement007 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC08 - Verify that a 0 dollar interest posting transaction when the net interest of positive and negative accrued on negative balance is 0 and the account is configured to track the positive and negative accrued separately. (NEGACRPO=1 and NEGIPO=1).")]
        public virtual void InterestSettlement007()
        {
            string GLSetCodeNumber = Data.Fetch("InterestSettlementTDSETUP", "GLSetCodeNumber");
            string Index = Data.Fetch("InterestSettlementTDSETUP", "Index1");

            Report.Step("Step 1.0: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);

            Report.Step(" Step 2.0: Navigate to Table Configuration | Interet Indexes | <INDEX1> | Rates and add Interest Rates with the following values: a) Effective Date : SystemDate-1, b) Rate1: -3.9 and Click Submit.");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("0 - Basis Index"), Index, SYSTEMDATEMIN1D, Data.Get("-3.9"));
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("0 - Basis Index"), Index, ApplicationDate, Data.Get("3.9"));

            Report.Step("Step 3.0: Copy a standard demand deposit product <CopyProduct> using standard product type 400 (Product Factory|Products).");
            string CopyProduct = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), Data.Get("400"), true);

            Report.Step("Step 4.0: Search for the product <DDA_PRODUCT3> and update the following: a) General Ledger Set Code: <GL_SET_CODE1>. (Product Factory | Products | <CopyProduct> )");
            Application.WebAdmin.EditProductGeneralSection(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct, "", GLSetCodeNumber);

            Report.Step("Step 5.0: Navigate to the Interest tab and  update the following: a) Accrual Base: Ledger Balance; b) Accrual Method: Actual/Actual 31/365,6, c) Minimum Balance To Accrue: NULL and click Submit. ");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct, Data.Get("Ledger Balance"), appHandle.ReplaceString(Data.Get("Actual/Actual      (31/365$6)"),"$",","), Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 6.0: Navigate to the Rate Determination link and update the Adjustable rate index as <Index> ad Click Submit. ");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct, "", Index, "", Data.Get("GLOBAL_BLANK_OR_NULL"), Data.Get("GLOBAL_BLANK_OR_NULL"));
            
            Report.Step("Step 7.0: Navigate to the Rate Posting Options sub Tab under the interest Tab update Disbursement Option as Remain on Deposit and Posting Frequency as 2DA");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct, Data.Get("RemainOnDeposit"), Data.Get("GLOBAL_FREQUENCY_2DA"), Data.Get("GLOBAL_BLANK_OR_NULL"));
            
            Report.Step("Step 8.0: Navigate to the Negative Interest link and update the following: a) Allow Negative Interest: Selected; b) Accrual Option: Positive and Negative Separately; c) Posting Option:Post Only Positive Net Accrued Interest/Dividend ; d) Accrue Positive Interest on Negative Balance (Negative Rate): Selected e)Post Zero-Dollar Interest Transactionâ€™: Selected and Click Submit.");
            Application.WebAdmin.UpdateTransactionCodesAdjustments(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct, true, Data.Get("Positive and Negative Accrued Separately"), Data.Get("Post Actual Net Accrued Interest/Dividend"), Data.Get("GLOBAL_BLANK_OR_NULL"), true, true);
            
            Report.Step("Step 9.0: Navigate to Transaction Codes tab and update all the transaction codes related to Negative Interest Transaction Codes.");
            Application.WebAdmin.updateTransactionCodeAdjustmentPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct, "", "", "", "", Data.Get("AdjustmentsResidualInterestDebit"), Data.Get("AdjustmentsResidualInterestCredit"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceDebit"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceCredit"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceDebit"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceCredit"));
            
            Report.Step("Step 13.0: Logout from WEBADMIN Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 14.0 : Reload the Tomcat Servers.");
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Data.Store("ProductCode1", CopyProduct);      
        }
    }
}
