using System.Collections.Generic;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class InterestsettlementTDSETUPTSR1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Interest Settlement Setup for CD Products")]
        public virtual void InterestSettlementTDSETUPTSR1()
        {   
            Report.Step("Step 1: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 2: Create a GL Accounts <GL_SET_ACCOUNT1> under General Ledger Account Type LIABILITY (Select General Ledger | Accounts | Add).");
            string GLLiabilityAccountCombined = Application.WebAdmin.CreateGLAccount(Data.Get("LIABILITY"), false, 10);
            
            Report.Step("Step 3: Create a GL Accounts <Revenue_GL_SET_ACCOUNT1> under General Ledger Account Type REVENUE (Select General Ledger | Accounts | Add).");
            string GLRevenueAccountCombined = Application.WebAdmin.CreateGLAccount(Data.Get("REVENUE"), false, 6);

            Report.Step("Step 4: Create a GL Accounts <GL_SET_ACCOUNT6> under General Ledger Account Type EXPENSE (Select General Ledger | Accounts | Add).");
            string GLExpenseAccountCombined = Application.WebAdmin.CreateGLAccount(Data.Get("EXPENSE"), false, 3);

            Report.Step("Step 5: Create GL Accounts <Asset_GL_SET_ACCOUNT1> under General Ledger Account Type ASSET (Select General Ledger | Accounts | Add).");
            string GLAssetAccountCombined = Application.WebAdmin.CreateGLAccount(Data.Get("ASSET"), false, 6);
            
            Report.Step("Step 6: Create a General Ledger Set Code <GL_SET_CODE1> by providing all the interest related GL accounts. (General Ledger Set Code: <GL_SET_CODE1>; Description: <GL_SET_CODE1>; Principal Balance:20105 - Principal Balance - DDA Type 400 ; AccuredInterest: 20205 - Negative Principal Balance - DDA.");
            //string GLSetCodeNumber = Application.WebAdmin.CreateGLSetCodes(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), GLLiabilityAccountCombined, GLExpenseAccountCombined, GLAssetAccountCombined, GLRevenueAccountCombined);

            Report.Step("Step 7: Logout from WEBADMIN Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 8: Reload the Tomcat Servers.");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            //Data.Store("GLSetCodeNumber", GLSetCodeNumber);
        }
    }
}
