using System.Collections.Generic;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class InterestsettlementTDSETUP : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Negative Interest Rate Processing setup for Phase II / Interest Settlement Setup")]
        public virtual void InterestSettlementTDSETUP()
        {   
            Report.Step("Step 1: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN15D = appHandle.CalculateNewDate(ApplicationDate, "D", -15);

            Report.Step("Step 2: Create a GL Accounts <GL_SET_ACCOUNT1> under General Ledger Account Type LIABILITY (Select General Ledger | Accounts | Add)");
            string GLLiabilityAccountCombined = Application.WebAdmin.CreateGLAccount(Data.Get("LIABILITY"), false, 10);
            
            Report.Step("Step 3: Create a GL Accounts <GL_SET_ACCOUNT6> under General Ledger Account Type REVENUE (Select General Ledger | Accounts | Add)");
            string GLRevenueAccountCombined = Application.WebAdmin.CreateGLAccount(Data.Get("REVENUE"), false, 6);

            Report.Step("Step 4: Create a GL Accounts <GL_SET_ACCOUNT6> under General Ledger Account Type EXPENSE (Select General Ledger | Accounts | Add)");
            string GLExpenseAccountCombined = Application.WebAdmin.CreateGLAccount(Data.Get("EXPENSE"), false, 2);

            Report.Step("Step 5: Create a GL Accounts <GL_SET_ACCOUNT6> under General Ledger Account Type ASSET (Select General Ledger | Accounts | Add)");
            string GLAssetAccountCombined = Application.WebAdmin.CreateGLAccount(Data.Get("ASSET"), false, 5);
            
            Report.Step("Step 6: Create a General Ledger Set Code <GL_SET_CODE1> by providing all the interest related GL accounts. (General Ledger Set Code: <GL_SET_CODE1>; Description: <GL_SET_CODE1>; Principal Balance:20105 - Principal Balance - DDA Type 400 ; AccuredInterest: 20205 - Negative Principal Balance - DDA");
            //string GLSetCodeNumber = Application.WebAdmin.CreateGLSetCodes(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), GLLiabilityAccountCombined, GLExpenseAccountCombined, GLAssetAccountCombined, GLRevenueAccountCombined);

            Report.Step("Step 7: In WebAdmin create a New Index - (a. Index Name: IND1, b. Description :Testing, c. Index Type: 1 - Tiered Index, d. Tiered Index Type:  C – Cumulative, e. Rate Calculation Option : Null, f. Daily Rate Option : N.");
            string TieredIndex = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"),"","","Tiered Index Type:|C - Cumulative");

            Report.Step("Step 8: Navigate to Table Configuration | Interest Indexes and create three new Indexes: <INDEX1>, <INDEX2> , <INDEX4> Index Type: <1 - Basis Index> and Click Submit.");
            string Index1 = Application.WebAdmin.CreateInterestIndex(Data.Get("0 - Basis Index"));
            string Index2 = Application.WebAdmin.CreateInterestIndex(Data.Get("0 - Basis Index"));
            string Index3 = Application.WebAdmin.CreateInterestIndex(Data.Get("0 - Basis Index"));
            
            Report.Step("Step 9: Logout from WEBADMIN Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 10.0 : Reload the Tomcat Servers.");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Data.Store("TieredIndex", TieredIndex);
            Data.Store("Index1", Index1);
            Data.Store("Index2", Index2);
            Data.Store("Index3", Index3);
            //Data.Store("GLSetCodeNumber", GLSetCodeNumber);
        }
    }
}
