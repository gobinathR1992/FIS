using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement025TSr2 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC32 - Verify that the year end related fields are updated when the net of interest adjustment posting transaction is 0 and when NEGIPO is set to 2.")]
        public virtual void InterestSettlement025TSR2()
        {
            string ProductCode1 = Data.Fetch("InterestSettlement025TSR1","ProductCode");

            Report.Step("Step 1: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN4D = appHandle.CalculateNewDate(ApplicationDate, "D", -4);
            string SYSTEMDATEMIN2D = appHandle.CalculateNewDate(ApplicationDate, "D", -2);
            
            Report.Step("Step 2: In Profile WebCSR, create a personal customer <CIF1> by entering all the mandatory fields (Basic Services| Create Personal Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3: Create a Deposit account <DDA_ACCOUNT4> for the customer <CIF1> using the Product Types <DDA_PRODUCT4> with the following details: a) Account Opening Date: <System Date-4>; b) Amount: 10,000.00; c) Currency: EURO and Click Submit (Basic Services| Create Account).");
            string DDAACC1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), ProductCode1, "", 1, Data.Get("Account Name") + "|DDAACC1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") +";"+ Data.Get("Currency Code") + "|" + Data.Get("EUR - Euro")+";"+Data.Get("Opening Date")  + "|" +  SYSTEMDATEMIN4D);
            
            Report.Step("Step 4: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 5: Post a Deposit transaction to the deposit account <DDA_ACCOUNT4> for 20,000 with the currency as EURO on System Date-5.");
            Application.Teller.DepositFunds(DDAACC1, Data.Get("GLOBAL_AMOUNT_REQUESTED_20K"), SYSTEMDATEMIN4D, Data.Get("EUR"));

            Data.Store("DDAACC1", DDAACC1);  
        }
    }
}
