using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement024 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC30 - Verify that a 0 dollar interest transaction is posted when the net of interest adjustment posting transaction, due to an effective dated rate change, is 0. TC 31- Verify that the 0 dollar interest posting transaction is not getting posted instead the Interest accrual adjustment transactions gets posted to the Account when the net of interest adjustment posting transaction, due to an effective dated rate change, is 0 and when the post zero net interest option is not selected.")]
        public virtual void InterestSettlement024()
        {
            string GLSetCodeNumber = Data.Fetch("InterestSettlementTDSETUP", "GLSetCodeNumber");

            Report.Step("Step 1: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);

            Report.Step("Step 2: Copy a standard demand deposit and create two deposit products <COPYPRODUCT> and <COPYPRODUCT1> using standard product type 400 (Product Factory|Products).");
            string CopyProduct = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), Data.Get("400"), true);
            
            Report.Step("Step 3: Search for the product <COPYPRODUCT> and update the following: a) General Ledger Set Code: <GL_SET_CODE1>. (Product Factory | Products | <COPYPRODUCT> ).");
            Application.WebAdmin.EditProductGeneralSection(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct, "", GLSetCodeNumber);

            string CopyProduct1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), Data.Get("400"), true);

            Report.Step(" Step 4: Search for the product <COPYPRODUCT1> and update the following: a) General Ledger Set Code: <GL_SET_CODE1>. (Product Factory | Products | <COPYPRODUCT1> )");            
            Application.WebAdmin.EditProductGeneralSection(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct1, "", GLSetCodeNumber);

            Report.Step("Step 5: Navigate to the Interest tab and  update the following: a) Accrual Base: Ledger Balance; b) Accrual Method: Actual/Actual 31/365,6, c) Minimum Balance To Accrue: NULL and click Submit.");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct, Data.Get("Ledger Balance"), appHandle.ReplaceString(Data.Get("Actual/Actual      (31/365$6)"),"$",","), Data.Get("GLOBAL_BLANK_OR_NULL"));
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct1, Data.Get("Ledger Balance"), appHandle.ReplaceString(Data.Get("Actual/Actual      (31/365$6)"),"$",","), Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 6: Navigate to the Rate Determination link and update the following: a) Nominal Rate: <5.00>, b) Adjustable Rate Limits Maximum Rate: NULL, c) Variable Rate Limits Minimum Rate: NULL And Click Submit.");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct, "5", "", "", Data.Get("GLOBAL_BLANK_OR_NULL"), Data.Get("GLOBAL_BLANK_OR_NULL"));
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct1, "5", "", "", Data.Get("GLOBAL_BLANK_OR_NULL"), Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 7: Navigate to the Posting Options sub Tab under the interest Tab update the following fields: a) Disbursement Option: Remain on Deposit, b) Posting Frequency: 4DA, c) Minimum Balance to Credit: NULL and Click Submit.");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct, Data.Get("RemainOnDeposit"), Data.Get("GLOBAL_FREQUENCY_4DA"), Data.Get("GLOBAL_BLANK_OR_NULL"));
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct1, Data.Get("RemainOnDeposit"), Data.Get("GLOBAL_FREQUENCY_4DA"), Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 8: Navigate to the Negative Interest link and update the following: a) Allow Negative Interest: Selected; b) Accrual Option: Positive and Negative Separately; c) Posting Option:Post Only Positive Net Accrued Interest/Dividend ; d) Accrue Positive Interest on Negative Balance (Negative Rate): Selected ; e)Post Zero-Dollar Interest Transaction’: Selected and Click Submit.");
            Application.WebAdmin.UpdateTransactionCodesAdjustments(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct, true, Data.Get("Positive and Negative Accrued Separately"), Data.Get("Post Int/Div Accrued on Positive Bal and Neg Bal Separately"), Data.Get("GLOBAL_FREQUENCY_4DA"), true, true);
            Application.WebAdmin.UpdateTransactionCodesAdjustments(Data.Get("D - Deposit Accounts"), Data.Get("DDA - Demand Deposits"), CopyProduct1, true, Data.Get("Positive and Negative Accrued Separately"), Data.Get("Post Int/Div Accrued on Positive Bal and Neg Bal Separately"), Data.Get("GLOBAL_FREQUENCY_4DA"), true, false);

            Report.Step("Step 9: Navigate to Transaction Codes tab and update all the transaction codes related to Negative Interest Transaction Codes.");
            Application.WebAdmin.updateTransactionCodeAdjustmentPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct, "", "", "", "", Data.Get("AdjustmentsResidualInterestDebit"), Data.Get("AdjustmentsResidualInterestCredit"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceDebit"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceCredit"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceDebit"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceCredit"));
            Application.WebAdmin.updateTransactionCodeAdjustmentPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), CopyProduct1, "", "", "", "", Data.Get("AdjustmentsResidualInterestDebit"), Data.Get("AdjustmentsResidualInterestCredit"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceDebit"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceCredit"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceDebit"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceCredit"));

            Report.Step("Step 10: Logout from WEBADMIN Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 11: Reload the Tomcat Servers.");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Data.Store("ProductCode1", CopyProduct);   
            Data.Store("ProductCode2", CopyProduct1);   
            
        }
    }
}
