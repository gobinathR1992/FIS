using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement033_TSR1_DP2 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC46- Verify that the 0-dollar transaction is posted during CD rollover when the net of positive and negative accrued on positive balance is 0 and NEGIPO is set as 2. TC49 - Verify that the 0-dollar transaction is posted and the CD account is closed out when the net of positive and negative accrued on positive balance is 0 and NEGIPO is set as 2.")]
        public virtual void InterestSettlement033_TSR1_DP2()
        {
            
            string LNACCT1 = Data.Fetch("InterestSettlement033TSR1", "LNACCT1");
            string LNACCT2 = Data.Fetch("InterestSettlement033TSR1", "LNACCT2");

            Report.Step("Step 1: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);
            string SYSTEMDATEPLUS4D = appHandle.CalculateNewDate(ApplicationDate, "D", 4);

            Application.WebCSR.VerifyDataInAccountHistoryTable(LNACCT1, ApplicationDate+";"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_100K")),"","","All");


            string PosNegACRValue = Application.WebCSR.CalculatePosNegACR(Data.Get("GLOBAL_AMOUNT_REQUESTED_100K"), Data.Get("GLOBAL_VALUE_2"), ApplicationDate, Data.Get("5"), 4);

            Application.WebCSR.ClickOnAccountHistoryTransactionLink(ApplicationDate + ";" + "CD Increase Int Paid");
            Application.WebCSR.VerifyPOSNEGACRAmount("Transaction Comment",PosNegACRValue, 4);
            
            
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(LNACCT1, "Maturity Date" + "|" + ApplicationDate+";"+"Account Status"+"|"+"Closed");
            

            //  //  //  /   /// //


                //Application.WebCSR.VerifyDataInAccountHistoryTable(LNACCT2, ApplicationDate+";"+ Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_100K")),"","","All");

            
            

            
        }
    }
}
