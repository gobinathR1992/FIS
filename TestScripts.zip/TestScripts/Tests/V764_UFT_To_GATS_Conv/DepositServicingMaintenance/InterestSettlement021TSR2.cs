using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement021TSR2 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC26 -Verify that a 0 dollar interest transaction is posted when the net of interest adjustment posting transaction, due to an effective dated deposit and withdrawal is 0 and when NEGIPO is set as 1")]
        public virtual void InterestSettlement021TSR2()
        {
            
            string ProductCode = Data.Fetch("InterestSettlement021TSR1","ProductCode");

            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN5D = appHandle.CalculateNewDate(ApplicationDate, "D", -5);
            string SYSTEMDATEMIN3D = appHandle.CalculateNewDate(ApplicationDate, "D", -3);
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);
            
            Report.Step("Step 2: In Profile WebCSR, create a corporate customer <CIF1> by entering all the mandatory fields (Basic Services| Create corporate Customer)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3: Create a Deposit account <DDAAC1> for the customer <CIF1> using the Product Types <DDA_PRODUCT4> with the following details: a) Account Opening Date: <System Date-5>; b) Amount: 10,000.00; c) Currency: EURO and Click Submit (Basic Services| Create Account)");
            string DDAACC1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), ProductCode, "", 1, Data.Get("Account Name") + "|DDAACC1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K")+";"+Data.Get("Opening Date")  + "|" +  SYSTEMDATEMIN5D  +";"+ Data.Get("Currency Code") + "|" + Data.Get("EUR - Euro"));
            
            Report.Step("Step 4: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 5: Post a Deposit transaction to the deposit account <DDAAC1> for 75,000 with the currency as EURO on System Date-5 days.");
            Application.Teller.DepositFunds(DDAACC1, Data.Get("GLOBAL_AMOUNT_REQUESTED_75K"), SYSTEMDATEMIN5D, Data.Get("EUR"));

            Report.Step("Step 6: Post a Withdrawal transaction to the deposit account <DDAACC1> for 1,50,000 with the currency as EURO on System Date-3 days.");
            Application.Teller.WithdrawFunds(DDAACC1, Data.Get("GLOBAL_AMOUNT_REQUESTED_150K"), SYSTEMDATEMIN3D, Data.Get("EUR"),true);
            
            Report.Step("Step 7: Navigate to Account History and verify that the zero dollar interest transaction is posted to the account");
            string PosNegACRValue1 = Application.WebCSR.CalculatePosNegACR(Data.Get("GLOBAL_AMOUNT_REQUESTED_75K"), Data.Get("GLOBAL_VALUE_4"), ApplicationDate, Data.Get("0.5"));
            Application.WebCSR.VerifyDataInAccountHistoryTable(DDAACC1,SYSTEMDATEMIN1D+";"+PosNegACRValue1+";"+"-"+Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat((Data.Get("GLOBAL_AMOUNT_REQUESTED_75K"))),"","","All");
            
        
            Report.Step("Step 8: Verify that the POSACR and NEGACR components are updated with correct values in the Transaction Detail section. Verify that the POSACR and NEGACR components are updated in the Transaction Detail section with correct values.");
            string PosNegACRValue2 = Application.WebCSR.CalculatePosNegACR(Data.Get("GLOBAL_AMOUNT_REQUESTED_75K"), Data.Get("GLOBAL_VALUE_2"), ApplicationDate, Data.Get("0.5"));
            Application.WebCSR.ClickOnAccountHistoryTransactionLink(ApplicationDate+";"+SYSTEMDATEMIN1D);
            Application.WebCSR.VerifyPOSNEGACRAmount("Transaction Comment",PosNegACRValue2);
            
        }
    }
}
