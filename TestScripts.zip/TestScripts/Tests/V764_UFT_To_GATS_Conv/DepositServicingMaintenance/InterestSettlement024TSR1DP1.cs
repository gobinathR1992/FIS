using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement024TSR1DP1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC16 -Verify that a 0 dollar interest transaction is posted when the net of interest adjustment posting transaction, due to an effective date deposit, is 0")]
        public virtual void InterestSettlement024TSR1DP1()
        {
            
            
            Report.Step("Step 1: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);

            Report.Step("Step 2: Run the report UBAL03 and verify that no OOB has been logged.");
            Application.WebAdmin.VerifyProfileReports(Data.Get("UBAL03"), Data.Get("No information available to display"), "Starting Effective Date|" + SYSTEMDATEMIN1D);

            Report.Step("Step 3: Logout from WEBADMIN Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
        }
    }
}
