using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement007TSr1DP1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC08 - Verify that a 0 dollar interest posting transaction when the net interest of positive and negative accrued on negative balance is 0 and the account is configured to track the positive and negative accrued separately. (NEGACRPO=1 and NEGIPO=1)")]
        public virtual void InterestSettlement007TSR1DP1()
        {
            string AccountNumber = Data.Fetch("InterestSettlement007TSR1","DDAACC1");
            
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);

            Report.Step("Step 2.0: Navigate to AccountSummary | Interest Page");
            Application.WebCSR.NavigateToAccountSummaryInterestPage(AccountNumber);
            
            string PosNegACRValue = Application.WebCSR.CalculatePosNegACR(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"), Data.Get("GLOBAL_VALUE_1"), ApplicationDate, "3.9", 5);

            Report.Step("Step 3.0: Verify Negative Accured Interest for Authorized Negative Accrued, Positive Accrued Interest ");
            Application.WebCSR.VerifyAccruedInterestInInterestAccrual(AccountNumber, Data.Get("Authorized Negative Accrued") + "|" + 	PosNegACRValue);
            Application.WebCSR.VerifyAccruedInterestInInterestAccrual(AccountNumber, Data.Get("Positive Accrued Interest on Negative Balance (Negative Rate)") + "|" + 	PosNegACRValue);           

            Report.Step("Step 4: Reload the Tomcat Servers.");
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }
    }
}
