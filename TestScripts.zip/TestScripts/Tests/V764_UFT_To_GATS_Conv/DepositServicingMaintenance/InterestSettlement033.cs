using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositServicingMaintenance
{
    [TestFixture]
    public class Interestsettlement033 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "TC46- Verify that the zero dollar transaction is posted during CD rollover when the net of positive and negative accrued on positive balance is 0 and NEGIPO is set as 2. TC49 - Verify that the zero dollar transaction is posted and the CD account is closed out when the net of positive and negative accrued on positive balance is 0 and NEGIPO is set as 2.")]
        public virtual void InterestSettlement033()
        {
            string GLSetCodeNumber = Data.Fetch("InterestSettlementTDSETUP", "GLSetCodeNumber");

            Report.Step("Step 1: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN1D = appHandle.CalculateNewDate(ApplicationDate, "D", -1);

            Report.Step("Step 2: Copy a standard demand deposit product <CD_PRODUCT1> using standard product type 350 (Product Factory|Products).");
            string CopyProduct1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), Data.Get("GLOBAL_STD_PROD_NUM_350"), true);
            Report.Step("Step 3: Search for the product <COPYPRODUCT1> and update the following: a) General Ledger Set Code: <GL_SET_CODE1>. (Product Factory | Products | <COPYPRODUCT1> )");
            Application.WebAdmin.EditProductGeneralSection(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), CopyProduct1, "", GLSetCodeNumber);

            Report.Step("Step 10.1: Copy a standard demand deposit product <CD_PRODUCT2> using standard product type 350 (Product Factory|Products).");
            string CopyProduct2 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), Data.Get("GLOBAL_STD_PROD_NUM_350"), true);

            Report.Step("Step 10.2: Search for the product <COPYPRODUCT2> and update the following: a) General Ledger Set Code: <GL_SET_CODE1>. (Product Factory | Products | <COPYPRODUCT2> )");
            Application.WebAdmin.EditProductGeneralSection(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), CopyProduct2, "", GLSetCodeNumber);
 
            Report.Step("Step 4: Navigate to the Interest tab and  update the following: a) Accrual Base: Ledger Balance; b) Accrual Method: Actual/Actual 31/365,6, c) Minimum Balance To Accrue: NULL and click Submit.");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), CopyProduct1, Data.Get("Ledger Balance"), appHandle.ReplaceString(Data.Get("Actual/Actual      (31/365$6)"),"$",","), Data.Get("GLOBAL_BLANK_OR_NULL"), "deselect", "", false, "deselect");
            
            Report.Step("Step 5: Navigate to the Rate Determination link and update the Nominal rate as -5 and Click Submit. ");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CopyProduct1, Data.Get("-5"), "", Data.Get("GLOBAL_BLANK_OR_NULL"), Data.Get("GLOBAL_BLANK_OR_NULL"), Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 6: Navigate to the Rate Posting Options sub Tab under the interest Tab update Disbursement Option as Remain on Deposit and Posting Frequency as 6DA");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CopyProduct1, Data.Get("RemainOnDeposit"), Data.Get("GLOBAL_FREQUENCY_6DA"), Data.Get("GLOBAL_BLANK_OR_NULL"));
            
            Report.Step("Step 7: Navigate to the Negative Interest link and update the following: a) Allow Negative Interest: Selected; b) Accrual Option: Positive and Negative Separately; c) Posting Option:Post Only Pos and Neg Separtely ; d) Accrue Positive Interest on Negative Balance (Negative Rate): Selected e)Post Zero-Dollar Interest Transaction’: Selected and Click Submit.");
            Application.WebAdmin.UpdateTransactionCodesAdjustments(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), CopyProduct1, true, Data.Get("Positive and Negative Accrued Separately"), Data.Get("Post Int/Div Accrued on Positive Bal and Neg Bal Separately"), Data.Get("GLOBAL_FREQUENCY_6DA"), true, true);

            Report.Step("Step 8: Navigate to Term Accounts Tab and update the following: a) Term: 4D; b) Principal Renewal Option: Automatically Renew; c) Interest Maturity Option: Remain On Deposit; d) Grace Days: 0 and Click Submit.");
            Application.WebAdmin.UpdateMaturityProcessingPageOption(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), CopyProduct1, Data.Get("4D"), Data.Get("Automatically Renew"), Data.Get("Remain On Deposit"));
            
            Report.Step("Step 9: Navigate to Transactions Code Page and update all the transaction codes related to Negative Interest Transaction Codes.");
            Application.WebAdmin.updateTransactionCodeAdjustmentPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CopyProduct1, "", "", "", "", "", "", Data.Get("AdjustmentsNegativeAIOnPositiveBalanceDebit1"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceCredit1"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceDebit1"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceCredit1"));

            Report.Step("Step 11: Navigate to the Interest tab and  update the following: a) Accrual Base: Ledger Balance; b) Accrual Method: Actual/Actual 31/365,6, c) Minimum Balance To Accrue: NULL and click Submit.");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), CopyProduct2, Data.Get("Ledger Balance"), appHandle.ReplaceString(Data.Get("Actual/Actual      (31/365$6)"),"$",","), Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 12: Navigate to the Rate Determination link and update the Nominal rate as -5 and Click Submit.");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CopyProduct2, Data.Get("-5"), "", Data.Get("GLOBAL_BLANK_OR_NULL"), Data.Get("GLOBAL_BLANK_OR_NULL"), Data.Get("GLOBAL_BLANK_OR_NULL"));            

            Report.Step("Step 13: Navigate to the Rate Posting Options sub Tab under the interest Tab update Disbursement Option as Remain on Deposit and Posting Frequency as 6DA");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CopyProduct2, Data.Get("RemainOnDeposit"), Data.Get("GLOBAL_FREQUENCY_6DA"), Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 14: Navigate to the Negative Interest link and update the following: a) Allow Negative Interest: Selected; b) Accrual Option: Positive and Negative Separately; c) Posting Option:Post Only Pos and Neg Separtely ; d) Accrue Positive Interest on Negative Balance (Negative Rate): Selected e)Post Zero-Dollar Interest Transaction’: UnSelect and Click Submit.");
            Application.WebAdmin.UpdateTransactionCodesAdjustments(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), CopyProduct2, true, Data.Get("Positive and Negative Accrued Separately"), Data.Get("Post Int/Div Accrued on Positive Bal and Neg Bal Separately"), Data.Get("GLOBAL_FREQUENCY_6DA"), true, false);

            Report.Step("Step 15: Navigate to Term Accounts Tab and update the following: a) Term: 4D; b) Principal Renewal Option: Automatically Renew; c) Interest Maturity Option: Remain On Deposit; d) Grace Days: 0 and Click Submit.");
            Application.WebAdmin.UpdateMaturityProcessingPageOption(Data.Get("D - Deposit Accounts"), Data.Get("CD - Certificates of Deposit"), CopyProduct2, Data.Get("4D"), Data.Get("Automatically Renew"), Data.Get("Remain On Deposit"));

            Report.Step("Step 16: Navigate to Transactions Code Page and update all the transaction codes related to Negative Interest Transaction Codes.");
            Application.WebAdmin.updateTransactionCodeAdjustmentPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_CERTIFICATEOFDEPOSIT_GROUP"), CopyProduct2, "", "", "", "", "", "", Data.Get("AdjustmentsNegativeAIOnPositiveBalanceDebit1"), Data.Get("AdjustmentsNegativeAIOnPositiveBalanceCredit1"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceDebit1"), Data.Get("AdjustmentsPositiveAIOnNegativeBalanceCredit1"));

            Report.Step("Step 17: Logout from WEBCSR Application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 18: Reload the Tomcat Servers.");
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Data.Store("ProductCode1", CopyProduct1);   
            Data.Store("ProductCode2", CopyProduct2);   
            
        }
    }
}
