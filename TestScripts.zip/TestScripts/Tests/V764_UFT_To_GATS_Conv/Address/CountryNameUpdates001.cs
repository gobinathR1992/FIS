using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Address
{
    [TestFixture]
    public class CountryNameupdates001 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "1 . As part of 9171 - ISO 3166-1 verify that customers are getting successfully created with the updated description of country as 'CZECHIA' in Profile WebCSR. 2 . As part of PDOC-14752 - ISO 3166-1 verify change for short name of country codes TF, VA and WF. 3 . As part of PDOC-15409 - ISO 3166-1 verify change for short name of country code MK.")]
        public void CountryNameUpdates001()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: In Profile WebCSR, Create a personal customer <CIF1> by using the Country : CZECHIA(Profile Direct Web CSR| Basic Services| Create Personal Customer");
            string CIF1 = Application.WebCSR.CreatePersonalCustomerByCountryCode(Data.Get("CZ - CZECHIA"));

            Report.Step("Step 3.0: Navigate to Customer Information and validate Country dropdown in Home address under Address Tab shows Country : CZECHIA");
            Application.WebCSR.VerifyHomeAddressCountryCustomerInformation(Data.Get("CZ - CZECHIA"));

            Report.Step("Step 4.0: Expected Result (PDOC-14752, PDOC-15409 -TC001, Updated Country Description: TF, VA, WF, MK): Verify that the updated description of country is displayed in Country of Residency dropdown field in Create Personal Customer page of Profile WebCSR.");
            Application.WebCSR.VerifyCountryOfResidencyCreateCustomerPage(Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + "|" + Data.Get("VA - HOLY SEE") + "|" + Data.Get("WF - WALLIS AND FUTUNA") + "|" + Data.Get("MK - NORTH MACEDONIA"));

            Report.Step("Step 5.0: Expected Result (PDOC-14752, PDOC-15409 -TC002, Updated Country Description: TF, VA, WF, MK): Verify that the updated description of country is displayed in Country of Citizenship dropdown field in Create Personal Customer page of Profile WebCSR.");
            Application.WebCSR.VerifyCountryofCitizenshipCreateCustomerPage(Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + "|" + Data.Get("VA - HOLY SEE") + "|" + Data.Get("WF - WALLIS AND FUTUNA") + "|" + Data.Get("MK - NORTH MACEDONIA"));

            Report.Step("Step 6.0: Expected Result (PDOC-14752, PDOC-15409 -TC003, Updated Country Description: TF, VA, WF, MK): Verify that the updated description of country is displayed in Home Address Country dropdown field in Create Personal Customer page of Profile WebCSR.");
            Application.WebCSR.VerifyHomeAddressCountryDropdownCreateCustomerPage(Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + "|" + Data.Get("VA - HOLY SEE") + "|" + Data.Get("WF - WALLIS AND FUTUNA") + "|" + Data.Get("MK - NORTH MACEDONIA"));

            Report.Step("Step 7.0: Expected Result (PDOC-14752, PDOC-15409 -TC004, Updated Country Description: TF, VA, WF, MK): Verify that the updated description of country is displayed in  Mailing Address Country dropdown field in Create Personal Customer page of Profile WebCSR.");
            Application.WebCSR.VerifyMailingAddressCountryDropdownCreateCustomerPage(Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + "|" + Data.Get("VA - HOLY SEE") + "|" + Data.Get("WF - WALLIS AND FUTUNA") + "|" + Data.Get("MK - NORTH MACEDONIA"));

            Report.Step("Step 8.0: Expected Result (PDOC-14752, PDOC-15409 -TC005, Updated Country Description: TF, VA, WF, MK): Verify that the updated description of country is displayed in Country of Incorporation dropdown field in Create Corporate Customer page of Profile WebCSR.");
            Application.WebCSR.VerifyCountryofIncorporationDropdownCreateCorporateCustomerPage(Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + "|" + Data.Get("VA - HOLY SEE") + "|" + Data.Get("WF - WALLIS AND FUTUNA") + "|" + Data.Get("MK - NORTH MACEDONIA"));

            Report.Step("Step 9.0: Expected Result (PDOC-14752, PDOC-15409 -TC006, Updated Country Description: TF, VA, WF, MK): Verify that the updated description of country is displayed in Principal Place of Business Address Country dropdown field in Create Corporate Customer page of Profile WebCSR.");
            Application.WebCSR.VerifyPrincipalPlaceofBusinessCountryDropdownCreateCorporateCustomerPage(Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + "|" + Data.Get("VA - HOLY SEE") + "|" + Data.Get("WF - WALLIS AND FUTUNA") + "|" + Data.Get("MK - NORTH MACEDONIA"));

            Report.Step("Step 10.0: Expected Result (PDOC-14752, PDOC-15409 -TC007, Updated Country Description: TF, VA, WF, MK): Verify that the updated description of country is displayed in Mailing Address Country dropdown field in Create Corporate Customer page of Profile WebCSR.");
            Application.WebCSR.VerifyMailingAddressCountryDropdownCreateCorporateCustomerPage(Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + "|" + Data.Get("VA - HOLY SEE") + "|" + Data.Get("WF - WALLIS AND FUTUNA") + "|" + Data.Get("MK - NORTH MACEDONIA"));

            Report.Step("Step 11.0: Expected Result (PDOC-14752 -TC008, Updated Country Description: TF - FRENCH SOUTHERN TERRITORIES): Verify that the Personal Customers <CIF2> is created successfully with the updated description of country 'FRENCH SOUTHERN TERRITORIES' in Home Address Country dropdown of Profile WebCSR (Basic Services | Create Personal Customer).");
            string CIF2 = Application.WebCSR.CreatePersonalCustomerByCountryCode(Data.Get("TF - FRENCH SOUTHERN TERRITORIES"));

            Report.Step("Step 12.0: Expected Result (PDOC-14752 -TC008, Updated Country Description: VA - HOLY SEE): Verify that the Personal Customers <CIF3> is created successfully with the updated description of country 'VA - HOLY SEE' in Home Address Country dropdown of Profile WebCSR (Basic Services | Create Personal Customer).");
            string CIF3 = Application.WebCSR.CreatePersonalCustomerByCountryCode(Data.Get("VA - HOLY SEE"));

            Report.Step("Step 13.0:Expected Result (PDOC-14752 - TC009: Updated Country Description: VA - HOLY SEE):Verify that Corporate Customer are getting successfully created with the updated description of country as 'HOLY SEE' in Profile WebCSR.");
            string CorpCustNo1 = Application.WebCSR.CreateCorporateCustomerByCountryCode(Data.Get("VA - HOLY SEE"));

            Report.Step("Step 14.0: Expected Result PDOC-14752 - TC010: Updated Country Description: TF - FRENCH SOUTHERN TERRITORIES: Verify that Trust customer is created successfully with the updated description of country FRENCH SOUTHERN TERRITORIES in Home Address Country dropdown of Profile WebCSR Basic Services | Create Trust Customer.");
            string TrustCustomer1 = Application.WebCSR.CreateTrustCustomer(Data.Get("IR - Irrevocable Trust"), CIF2, false);

            Report.Step("Step 15.0: Expected Result (PDOC-15409 -TC008, Updated Country Description: MK - NORTH MACEDONIA): Verify that the Personal Customers are created successfully with the updated description of country as 'NORTH MACEDONIA' in Profile WebCSR (Basic Services | Create Personal Customer).");
            string CIF4 = Application.WebCSR.CreatePersonalCustomerByCountryCode(Data.Get("MK - NORTH MACEDONIA"));
            string CIF5 = Application.WebCSR.CreatePersonalCustomerByCountryCode(Data.Get("MK - NORTH MACEDONIA"));

            Report.Step("Step 16.0: Expected Result (PDOC-15409 - TC009: Updated Country Description: MK - NORTH MACEDONIA) :Verify that Corporate Customer are getting successfully created with the updated description of country as 'NORTH MACEDONIA' in Profile WebCSR.");
            string CorpCustNo2 = Application.WebCSR.CreateCorporateCustomerByCountryCode(Data.Get("MK - NORTH MACEDONIA"));

            Report.Step("Step 17.0: Expected Result PDOC-15409 - TC010: Updated Country Description: MK - NORTH MACEDONIA: Verify that Trust customer is created successfully with the updated description of country NORTH MACEDONIA in Home Address Country dropdown of Profile WebCSR Basic Services | Create Trust Customer.");
            string TrustCustomer2 = Application.WebCSR.CreateTrustCustomer(Data.Get("IR - Irrevocable Trust"), CIF4, false);

            Report.Step("Step 18.0: Expected Result PDOC-14752 -TC011 Updated Country Description: VA - HOLY SEE: Verify that an existing customers Home Address Country can be modified with the updated description of country HOLY SEE in Profile WebCSR.");
            Application.WebCSR.GetCustomer(CIF1);
            Application.WebCSR.VerifyUpdateAddressByCountryCodeInCustomerInformation(Data.Get("VA - HOLY SEE"), true);

            Report.Step("Step 19.0: Expected Result (PDOC-14752 -TC012, Updated Country Description: TF - FRENCH SOUTHERN TERRITORIES): Verify that an existing customers Mailing Address Country can be modified with the updated description of country 'FRENCH SOUTHERN TERRITORIES' in Profile WebCSR.");
            Application.WebCSR.VerifyUpdateAddressByCountryCodeInCustomerInformation(Data.Get("TF - FRENCH SOUTHERN TERRITORIES"), false, true);

            Report.Step("Step 20.0: Expected Result (PDOC-14752 -TC013, Updated Country Description: WF - WALLIS AND FUTUNA): Verify that an existing customers Previous Address Country can be modified with the updated description of country 'WALLIS AND FUTUNA' in Profile WebCSR.");
            Application.WebCSR.VerifyUpdateAddressByCountryCodeInCustomerInformation(Data.Get("WF - WALLIS AND FUTUNA"), false, false, true);

            Report.Step("Step 21.0: Expected Result (PDOC-14752 -TC014, Updated Country Description: TF - FRENCH SOUTHERN TERRITORIES): Verify that an existing customers Seasonal Address Country can be modified with the updated description of country 'FRENCH SOUTHERN TERRITORIES' in Profile WebCSR.");
            Application.WebCSR.VerifyUpdateAddressByCountryCodeInCustomerInformation(Data.Get("TF - FRENCH SOUTHERN TERRITORIES"), false, false, false, true);

            Report.Step("Step 22.0: Expected Result (PDOC-15409 -TC011, Updated Country Description: MK - NORTH MACEDONIA): Verify that an existing customers Home Address Country can be modified with the updated description of country 'NORTH MACEDONIA' in Profile WebCSR.");
            Application.WebCSR.VerifyUpdateAddressByCountryCodeInCustomerInformation(Data.Get("MK - NORTH MACEDONIA"), true);

            Report.Step("Step 23.0: Expected Result (PDOC-15409 -TC012, Updated Country Description: MK - NORTH MACEDONIA): Verify that an existing customers Mailing Address Country can be modified with the updated description of country 'NORTH MACEDONIA' in Profile WebCSR.");
            Application.WebCSR.VerifyUpdateAddressByCountryCodeInCustomerInformation(Data.Get("MK - NORTH MACEDONIA"), false, true);

            Report.Step("Step 24.0: Expected Result (PDOC-15409 -TC013, Updated Country Description: MK - NORTH MACEDONIA): Verify that an existing customers Previous Address Country can be modified with the updated description of country 'NORTH MACEDONIA' in Profile WebCSR.");
            Application.WebCSR.VerifyUpdateAddressByCountryCodeInCustomerInformation(Data.Get("MK - NORTH MACEDONIA"), false, false, true);

            Report.Step("Step 25.0:Expected Result (PDOC-15409 -TC014, Updated Country Description: MK - NORTH MACEDONIA): Verify that an existing customers Seasonal Address Country can be modified with the updated description of country 'NORTH MACEDONIA' in Profile WebCSR.");
            Application.WebCSR.VerifyUpdateAddressByCountryCodeInCustomerInformation(Data.Get("MK - NORTH MACEDONIA"), false, false, false, true);

            Report.Step("Step 26.0: Expected Result (PDOC-14752 - TC015: Updated Country Description: TF - FRENCH SOUTHERN TERRITORIES, VA - HOLY SEE): Verify that the account should be created successfully with Joint relationship having updated description of country in Profile WebCSR.Create a Savings account <SAVACCT1> for the customer <CIF2, CIF3> using the standard product <300> with the following details Name: SAV; Opening Date: <System Date>; Opening Deposit: USD 100; Currency: USD (Profile WebCSR | Basic Services | Create account)");
            string SAVACCT1 = Application.WebCSR.Create_Account(CIF2, Data.Get("JointORSecondaryOwner"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), CIF3, 1, Data.Get("Account Name") + "|" + "SAVACCT1");

            Report.Step("Step 27.0 : Expected Result (PDOC-14752 - TC016: Updated Country Description: VA - HOLY SEE): Verify that the beneficiaries is added successfully with updated description of country 'VA - HOLY SEE' for Savings Account <SAVACCT1> in Profile WebCSR.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT1);
            Application.WebCSR.AddBeneficiariesForAccount(SAVACCT1, 1, Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"), Data.Get("VA - HOLY SEE"));

            Report.Step("Step 28.0: Expected Result (PDOC-14752 - TC016: Updated Country Description: TF - FRENCH SOUTHERN TERRITORIES, VA - HOLY SEE): Verify that the back dated account should be created successfully with Joint relationship having updated description of country in Profile WebCSR.Create a Savings account <SAVACCT2> for the customer <CIF2, CIF3> using the standard product <300> with the following details Name: SAV; Opening Date: <System Date - 10 days>; Opening Deposit: USD 100; Currency: USD (Profile WebCSR | Basic Services | Create account).");
            string AppDateMinusTenDays = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -10);
            string SAVACCT2 = Application.WebCSR.Create_Account(CIF2, Data.Get("JointORSecondaryOwner"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), CIF3, 1, Data.Get("Account Name") + "|" + "SAVACCT2;" + Data.Get("Opening Date") + "|" + AppDateMinusTenDays);

            Report.Step("Step 29.0:Expected Result (PDOC-15409 - TC015: Updated Country Description: MK - NORTH MACEDONIA): Verify that the account should be created successfully with Joint relationship having updated description of country in Profile WebCSR.Create a Savings account <SAVACCT1> for the customer <CIF4, CIF5> using the standard product <300> with the following details Name: SAV; Opening Date: <System Date>; Opening Deposit: USD 100; Currency: USD (Profile WebCSR | Basic Services | Create account).");
            string SAVACCT3 = Application.WebCSR.Create_Account(CIF4, Data.Get("JointORSecondaryOwner"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), CIF5, 1, Data.Get("Account Name") + "|" + "SAVACCT3");

            Report.Step("Step 30.0:Expected Result (PDOC-15409 - TC016: Updated Country Description: MK - NORTH MACEDONIA): Verify that the beneficiaries is added successfully with updated description of country 'MK - NORTH MACEDONIA' for Savings Account <SAVACCT3> in Profile WebCSR.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT3);
            Application.WebCSR.AddBeneficiariesForAccount(SAVACCT3, 1, Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"), Data.Get("MK - NORTH MACEDONIA"),3);

            Report.Step("Step 31.0:Expected Result (PDOC-15409 - TC015: Updated Country Description: MK - NORTH MACEDONIA): Verify that the back dated account should be created successfully with Joint relationship having updated description of country in Profile WebCSR.Create a Savings account <SAVACCT2> for the customer <CIF4, CIF5> using the standard product <300> with the following details Name: SAV; Opening Date: <System Date - 10 days>; Opening Deposit: USD 100; Currency: USD (Profile WebCSR | Basic Services | Create account).");
            string SAVACCT4 = Application.WebCSR.Create_Account(CIF2, Data.Get("JointORSecondaryOwner"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), CIF3, 1, Data.Get("Account Name") + "|" + "SAVACCT4;" + Data.Get("Opening Date") + "|" + AppDateMinusTenDays);

            Report.Step("Step 32.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}