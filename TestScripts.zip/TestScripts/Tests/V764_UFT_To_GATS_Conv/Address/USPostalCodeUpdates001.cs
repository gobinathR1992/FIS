using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Address
{
    [TestFixture]
    public class UsPostalCodeUpdates001:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "This script has been created and updated as part of the new enhancement PROFILEDOC-9436 U.S. Postal Codes Updates for 2017.")]
        public void USPostalCodeUpdates001()
        {
            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: In Profile WebCSR, create a Personal Customer <CUST1> by entering all required fields with Zip Code:34095 (Basic Services | Create Personal Customer).");
            string CUST1=Application.WebCSR.CreatePersonalCustomerByVaildZipCode(Data.Get("FPO"),Data.Get("AA - Armed Forces the Americas"),Data.Get("VaildZIPAA"));

            Report.Step("Step 3.0: Navigate to the Customer Address Page and Update with a ZIP Code in the format(Customer Information | Address).");
            Application.WebCSR.UpdateZipCodeOfHomeAddressInAddressPage(CUST1,Data.Get("VaildZipFormat"));

            Report.Step("Step 4.0: Navigate to the Customer Address Page and Update with Invaild ZIP code of AA(Customer Information | Address).");
            Application.WebCSR.UpdateHomeAddresswithInvaildInAddressPage(CUST1,Data.Get("InvaildZIPAA"),Data.Get("InvaildZipCodeMSGAA"));

            Report.Step("Step 5.0: In Profile WebCSR, create a Personal Customer <CUST2> by entering all required fields with states as :PR - PUERTO RICO, Zip Code:00680 (Basic Services | Create Personal Customer).");
            string CUST2=Application.WebCSR.CreatePersonalCustomerByVaildZipCode(Data.Get("Rio"),Data.Get("PR - PUERTO RICO"),Data.Get("VaildZIPPR"));

            Report.Step("Step 6.0: In Profile WebCSR, create a Personal Customer <CUST> by entering all required fields with invaild Zip Code pattern:00AWQ@ and verify the Error Message for ZipCode (Basic Services | Create Personal Customer).");
            Application.WebCSR.CreatePersonalCustomerByInVaildZipCode(Data.Get("InvaildZipCodePattern"),Data.Get("InvaildPatternMSG"));

            Report.Step("Step 7.0: In Profile WebCSR, try to create a Personal Customer <CUST> by entering all required fields with Blank Zip Code and verify the Error Message for ZipCode (Basic Services | Create Personal Customer).");
            Application.WebCSR.CreatePersonalCustomerByInVaildZipCode(" ",Data.Get("BlankZipCodePatternMSG"));

            Report.Step("Step 8.0: In Profile WebCSR, create a Personal Customer <CUST> by entering all required fields with Invaild Zip Code and verify the Error Message for ZipCode (Basic Services | Create Personal Customer).");
            Application.WebCSR.CreatePersonalCustomerByInVaildZipCode(Data.Get("InvaildZipCodePR"),Data.Get("InvaildZipCodeMSGPR"));


            Report.Step("Step 9.0: In Profile WebCSR, create a Corporate Customer <CorpCust> by entering all required fields with vaild Zip Code for AA (Basic Services | Create Corporate Customer).");
            string CorpCust = Application.WebCSR.CreateCorporateCustomerByZipCode(Data.Get("FPO"), Data.Get("AA - Armed Forces the Americas"),Data.Get("VaildZIPAA"));

            Report.Step("Step 10.0: In Profile WebCSR, create a Trust Customer <TrustCust> by entering all required fields with Vaild Zip Code for (Basic Services | Create Personal Customer).");
            string TrustCust = Application.WebCSR.CreateTrustCustomer(Data.Get("IR - Irrevocable Trust"), CUST2, false);

            Report.Step("Step 11.0:Navigate to Address Page of Personal Customer(CUST2) and update the latest postal code of mailing address (Customer Information |Address");
            Application.WebCSR.UpdateMailingAddressInAddressPage(CUST2);

            Report.Step("Step 12.0:Navigate to Address Page of Personal Customer(CUST2) and update the Previous address with Invaild ZipCode of AE:09059 (Customer Information |Address");
            Application.WebCSR.UpdatePreviousAddresswithInvaildZipCodeInAddressPage(CUST2,Data.Get("InvaildZIPAE"),Data.Get("InvaildZipCodeMSGAE"));

            Report.Step("Step 13.0:Navigate to Address Page of Personal Customer(CUST2) and update the Previous address with vaild ZipCode of AE:09003 (Customer Information |Address");
            Application.WebCSR.UpdatePreviousAddresswithVaildZipCodeInAddressPage(CUST2,Data.Get("VaildZIPAE"));

            Report.Step("Step 15.0:Navigate to Seasonal Address Page of Personal Customer(CUST1) and update the Previous address with Invaild ZipCode of AE:09059 (Customer Information |Address");
            string SystemDatePlus1D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(),"D",1);
            string SystemDatePlus2M = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(),"M",2);
            Application.WebCSR.UpdateSeasonalAddresswithInvaildZipCodeInSeasonalAddressPage(CUST2,SystemDatePlus1D,SystemDatePlus2M,Data.Get("InvaildZIPAE"),Data.Get("InvaildZipCodeMSGAE"));

            Report.Step("Step 16.0:Navigate to Seasonal Address Page of Personal Customer(CUST1) and update the Previous address with vaild ZipCode of AE:09003 (Customer Information |Address");
            Application.WebCSR.UpdateSeasonalAddresswithVaildZipCodeInSeasonalAddressPage(CUST2,SystemDatePlus1D,SystemDatePlus2M,Data.Get("VaildZIPAE"));

            Report.Step("Step 17.0: Create Savings Account<SAVACC1> using Savings product type <300> with joint relationship for the Personal customer <CUST1,CUST2> (Basic Services| Create Account.");
            string SAVACCT1 = Application.WebCSR.Create_Account(CUST1, Data.Get("JointORSecondaryOwner"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), CUST2, 1, Data.Get("Account Name") + "|" + "SAVACC1");

            Report.Step("Step 18.0: Create Savings Account<SAVACC2> using Savings product type <300> with joint relationship for the Personal customers <CUST1,CUST2> and Account opening Date as :SystemDate-10(Basic Services| Create Account.");
            string SystemDateMinus10D=appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(),"D",-10);
            string SAVACCT2 = Application.WebCSR.Create_Account(CUST1, Data.Get("JointORSecondaryOwner"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), CUST2, 1, Data.Get("Account Name") + "|" + "SAVACCT2;" + Data.Get("Opening Date") + "|" + SystemDateMinus10D);
            
            Report.Step("Step 19.0:Navigate to Beneficiaries Page and Enter Beneficiary Information as Classification: <Individual> State<P.A.> Invaild ZIP code (General Account Services | Beneficiaries) .");
            Application.WebCSR.AddBeneficiariesForAccountWithInvaildZipCode(CUST1,SAVACCT1, 1, Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"),Data.Get("InvaildZipCodeNE"),Data.Get("InvalidZipCodeMessageNE"));

            Report.Step("Step 20.0:Navigate to Beneficiaries Page and Enter Beneficiary Information as Classification: <Individual> State<P.A.> Vaild ZIP code (General Account Services | Beneficiaries) .");
            Application.WebCSR.AddBeneficiariesForAccountWithvaildZipCode(CUST1,SAVACCT1, 1, Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"),Data.Get("VaildZIPNE"),Data.Get("BeneMSG"));

            Report.Step("Step 21.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            
        }

        
    }
}