using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Address
{
    [TestFixture]
    public class address019 : TestBase
    {
        [Test]
        [Property("TestDescription", "Verify the Legal and Mailing Address for a joint account defaults from the Legal Address and Mailing Address of the primary owner, during account creation.")]
        [Property (TestType.TestBased,"")]
        public void Address019()
        {
            WebApplication appHandle;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step(" Step 1.0 Create a personal customer <CcustCIF1> by entering all mandatory field values. Profile Direct Web CSR| Basic Services| Create Personal Customer.");
            string CcustCIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step(" Step 2.0 Create a personal customer <CcustCIF2> by entering all mandatory field values. Profile Direct Web CSR| Basic Services| Create Personal Customer.");
            string CcustCIF2 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step(" Step 3.0 Create a Joint Savings account using standard product type and customer CIF1 ADDR019 as the owner and CIF2 ADDR019 as the joint applicant Profile Direct Web CSR| Basic Services| Create Account.");
            string SAVAcc1 = Application.WebCSR.Create_Account(CcustCIF1, Data.Get("JointORSecondaryOwner"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), CcustCIF2);

            Report.Step(" Step 4.0 Verify the Mailing Address for a joint account defaults from the Mailing Address of the primary owner of the account during account creation");
            Application.WebCSR.VerifyMailAddrInAccountInformation();

            Report.Step(" Step 5.0 Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }
    }
}