using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Address
{
    [TestFixture]
    public class address015:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify a Seasonal Address can be deleted from an account.")]
        public void Address015()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step(" Step 2.0 Create a personal customer <CcustCIF2> by entering all mandatory field values. Profile Direct Web CSR| Basic Services| Create Personal Customer.");
            string CcustCIF = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step(" Step 3.0: Create a Consumer Loan Account CON_ACCT1 using the Standard product type 500 and the Customer CcustCIF with the details: Amount: 10K Term: 2Y Payment Frequency: 1MA Currency: USD and Disbursment Date: System date (Customer| Service| Account| Add New Account).");
            string CON_ACCT1 = Application.WebCSR.Create_Account(CcustCIF, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"), "", 1, Data.Get("Account Name") + "|CON_ACC1;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|"  + Data.Get("GLOBAL_ACCOUNT_TERM_2Y") + ";" + Data.Get("Payment Frequency") + "|1MA" );

            Report.Step("Step 4.0: Modify the Seasonal Mailing Address of the Consumer Loan account in TitleAddressPage(Loan Account Services|Account Information|Title/address.");
            string StartDate = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D",1);
            string EndDate = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(),"D",4);
            Application.WebCSR.ModifySeasonalMailingAddressOnTitleAddress(CON_ACCT1,StartDate,EndDate,Data.Get("SeaAddLine1"),Data.Get("SeaAddLine2"),Data.Get("GLOBAL_CITY_MALVERN"),Data.Get("US - UNITED STATES OF AMERICA"),Data.Get("PA - PENNSYLVANIA"),Data.Get("GLOBAL_ZIPCODE_19355"));

            Report.Step("Step 5.0: Modify the Non-Seasonal Mailing Address of the Consumer Loan account(CON_ACCT1) in LoanTitleAddressPage(Loan Account Services|Account Information|Title/Address).");
            Application.WebCSR.ModifyNonSeasonalMailingAddressOnTitleAddress(CON_ACCT1,Data.Get("OffSeaAddLine1"),Data.Get("OffSeaAddLine2"),Data.Get("GLOBAL_CITY_MALVERN"),Data.Get("US - UNITED STATES OF AMERICA"),Data.Get("PA - PENNSYLVANIA"),Data.Get("GLOBAL_ZIPCODE_19355"));

            Report.Step("Step 6.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 7.0: Create datasheet to store the values.");
            Data.Store("CON_ACCT1", CON_ACCT1);
            Data.Store("CcustCIF",CcustCIF);
            
            Report.Step("Step 8.0: Run One Dayend.");







            
        }
    }
}

       