using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Address
{
    [TestFixture]
    public class address015_DP1:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Seasonal Address can be deleted from an account")]
        public void Address015_DP1()
        {
            Report.Step("Step 1.0 Get the Consumer Loan Account <CON_ACCT1>  from Address015 datasheet.");
            string CON_ACCT1 = Data.Fetch("Address015","CON_ACCT1");
            
            Report.Step("Step 2.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 3.0: Access the Consumer Loan Account(CON_ACCT1)and Verify that the Seasonal mailing address is updated to the Mailing Address(Loan Account Services|Account Information|Address/Title).");
            Application.WebCSR.VerifySeasonalAddressUpdatedonTitleAddressPage(CON_ACCT1,Data.Get("AddressLine1") + "|" + Data.Get("SeaAddLine1") + ";" + Data.Get("City") + "|" + Data.Get("GLOBAL_CITY_MALVERN") + ";" + Data.Get("Country") + "|" + Data.Get("US - UNITED STATES OF AMERICA") + ";" + Data.Get("State") + "|" + Data.Get("PA - PENNSYLVANIA") + ";" + Data.Get("ZipCode") + "|" + Data.Get("GLOBAL_ZIPCODE_19355")); 

            Report.Step("Step 4.0: Access the Consumer Loan Account(CON_ACCT1)and Verify that Non seasonal Mailing address is updated with Mailing address(Loan Account Services|Account Information|Address/Title).");
            Application.WebCSR.VerifyNonSeasonalAddressUpdatedonTitleAddressPage(CON_ACCT1,Data.Get("AddressLine1") + "|" + Data.Get("GLOBAL_FIS") + ";" + Data.Get("City") + "|" + Data.Get("GLOBAL_CITY") + ";" + Data.Get("Country") + "|" + Data.Get("GLOBAL_ADDCOUNTRY") + ";" + Data.Get("State") + "|" + Data.Get("GLOBAL_ADDSTATE") + ";" + Data.Get("ZipCode") + "|" + Data.Get("GLOBAL_ADDZIP")); 

            Report.Step("Step 5.0: Access the Consumer Loan Account (CON_ACCT1) and Delete the Seasonal Mailing Address.(Loan Account Services|Account Information|Title/Address) ");
            Application.WebCSR.DeleteSeasonalMailingAddressOnTitleAddress(CON_ACCT1);

            Report.Step("Step 6.0: Access the Consumer Loan Account (CON_ACCT1) and verify the Non-Seasonal Mailing Address is used as the Mailing Address.(Loan Account Services|Account Information|Title/Address) ");
            Application.WebCSR.VerifyMailingAddressUpdatedonTitleAddressPage(CON_ACCT1,Data.Get("AddressLine1") + "|" + Data.Get("GLOBAL_FIS") + ";" + Data.Get("City") + "|" + Data.Get("GLOBAL_CITY") + ";" + Data.Get("Country") + "|" + Data.Get("GLOBAL_ADDCOUNTRY") + ";" + Data.Get("State") + "|" + Data.Get("GLOBAL_ADDSTATE") + ";" + Data.Get("ZipCode") + "|" + Data.Get("GLOBAL_ADDZIP")); 

            Report.Step("Step 6.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            
        }

              
    }
}