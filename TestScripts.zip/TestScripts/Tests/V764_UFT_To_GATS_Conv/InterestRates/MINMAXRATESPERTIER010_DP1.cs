/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0010_DP1:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0010_DP1()
        {

            string DDINTRAccNum = Data.Fetch("mINMAXRATESPERTIER0010", "DDINTRAccNum");
            string SAVINTRAccNum = Data.Fetch("mINMAXRATESPERTIER0010", "SAVINTRAccNum");
            string savINTRATE = "1.36819";

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0:Search for the DDA account <DDINTRAccNum> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(DDINTRAccNum);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string ddaACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_00"), Data.Get("GLOBAL_AMOUNT_REQUESTED_4K"),Data.Get("GLOBAL_VALUE_1"),1,systemDate,"",5, DDINTRAccNum);
            
            Report.Step("Step 2.1:Verify the interest is accrued based on Interest Accrual Method 00 – Standard/Standard 30/360.");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + ddaACCINT);

            Report.Step("Step 2.2:Expected Result (TC57): Verify that the correct interest rate (CHILDINDX +.1 U2) is picked from attached cumulative tiered index defaulted from the deposit product to the new deposit account, on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(DDINTRAccNum, "1.00000");

            Report.Step("Step 3.0:Search for the Savings account <SAVINTRAccNum> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(SAVINTRAccNum);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string savACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_00"), "5500",savINTRATE,1,systemDate,"",5,SAVINTRAccNum);
            
            Report.Step("Step 3.1:Verify the interest is accrued based on Interest Accrual Method 00 – Standard/Standard 30/360.");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + savACCINT);

            Report.Step("Step 3.2:Expected Result (TC58): Verify that the correct interest rate (CHILDINDX -.1 U2) is picked from attached incremental tiered index defaulted from the deposit product to the new deposit account, on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(SAVINTRAccNum, savINTRATE);

            Report.Step("Step 4: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}