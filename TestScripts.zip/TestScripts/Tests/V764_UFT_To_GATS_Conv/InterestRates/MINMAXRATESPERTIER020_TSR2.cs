/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0020_TSR2:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0020_TSR2()
        {

            string MTGPROD1 = Data.Fetch("mINMAXRATESPERTIER0020", "MTGPROD1");
            string LNPROD1 = Data.Fetch("mINMAXRATESPERTIER0020", "LNPROD1");
            string DDAPROD1 = Data.Fetch("mINMAXRATESPERTIER0020", "DDAPROD1");
            string SAVPROD1 = Data.Fetch("mINMAXRATESPERTIER0020", "SAVPROD1");

            string CUMINDX2 = Data.Fetch("mINMAXRATESPERTIER0020", "CUMINDX2");
            string INCINDX2 = Data.Fetch("mINMAXRATESPERTIER0020", "INCINDX2");
            string CUMINDX1 = Data.Fetch("mINMAXRATESPERTIER0020", "CUMINDX1");
            string INCINDX1 = Data.Fetch("mINMAXRATESPERTIER0020", "INCINDX1");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();
            string SYSDATEMINUS2 = appHandle.CalculateNewDate(systemDate, "D", -2);

            Report.Step("Step 2.0:In Profile WebCSR, create a personal customer <CIF1> by entering all required fields (Basic Services| Create Personal Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create a mortgage loan account <mtgaccnum> for the customer <custno> using copied Mortgage product type : mtgproductname with the following values: Account Name: MTG; Disbursement Date:  <system date-2Days>; Disbursement Amount: USD 11,000; Account Term: 1Y; Frequency: 5DA.");
            string MTGACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), MTGPROD1, "", 1, Data.Get("Account Name") + "|MTG;" + Data.Get("Amount") + "|" + Data.Get("11000") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Disbursement Date") + "|" +  SYSDATEMINUS2 +  ";" + Data.Get("Payment Frequency") + "|" + Data.Get("GLOBAL_FREQUENCY_1DA") + ";Collateral Type|0 - Unsecured");
            
            Report.Step("Step 3.1: Create a installment loan account <LNACCT> for the customer <custno> using copied installment product type : lnproductname with the following values: Account Name: LN; Disbursement Date:  <system date>-2 days; Disbursement Amount: USD 10,000; Account Term: 1Y; Frequency: 5DA.");         
            string LNACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), LNPROD1, "", 1, Data.Get("Account Name") + "|LN;" + Data.Get("Amount") + "|" + Data.Get("11000") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Disbursement Date") + "|" +  SYSDATEMINUS2 +  ";" + Data.Get("Payment Frequency") + "|" + Data.Get("GLOBAL_FREQUENCY_1DA"));

            Report.Step("Step 3.2: Create a demand deposit account <DDINTRAccNum> (Basic Services | Create Account). a. Product Type <DDA_PRODUCT1>, b. Customer <CUSTNUM>, c.Amount:<4000>, d. Opening Date:<Sysdate-2Days>.");
            string DDAACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), DDAPROD1, "", 1, Data.Get("Account Name") + "|" + "DDA" + ";" + Data.Get("Opening Date")+ "|" + SYSDATEMINUS2 + ";"+ Data.Get("Opening Deposit") + "|" + Data.Get("11000") );

            Report.Step("Step 3.3: Create a SAV account <SAVINTRAccNum>  (Basic Services | Create Account). a. Product Type <SAV_PRODUCT1>, b. Customer <CUSTNUM>, c. Amount:<10000>, d. Opening date:<Sysdate-2Days>.");
            string SAVACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), SAVPROD1, "", 1, Data.Get("Account Name") + "|" + "SAV" + ";" + Data.Get("Opening Date")+ "|" + SYSDATEMINUS2 + ";"+ Data.Get("Opening Deposit") + "|" + "6000");

            Report.Step("Step 3.4: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 4.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 4.1: Post an disbursement to the Mortgage loan account mtgaccnum for USD 11,000 using transaction code MD (Mortgage Disbursement) with effective date T-3. Offset the transaction using transaction code CO (Cash Out).");
            Application.Teller.LoanDisbursement(MTGACCT, "11000", SYSDATEMINUS2);

            Report.Step("Step 4.2: Post an disbursement to the installment loan account mtgaccnum for USD 11,000 with effective date T-3. Offset the transaction using transaction code CO (Cash Out).");
            Application.Teller.LoanDisbursement(LNACCT, "6000", SYSDATEMINUS2);

            Report.Step("Step 4.3: Post a Deposit to the DDACCT for 11000.00 using transaction code DDA(DD Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(DDAACCT, "11000", SYSDATEMINUS2);

            Report.Step("Step 4.4: Post a Deposit to the SAVACCT for 11000.00 using transaction code SAV(SD Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(SAVACCT, "6000", SYSDATEMINUS2);

            Report.Step("Step 3.3:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 4.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string ApplicationDateM2 = appHandle.CalculateNewDate(ApplicationDate, "D", -2);

            Report.Step("Step 4.1: In WebAdmin, select Table Configuration | Interest Indexes On the Interest Index List page,  select the incremental tiered index radio button <INCINDX2>.");
            Report.Step("Step 4.2: Select the Rate added to Effective Date: T-2 days and click Edit (Table Configuration | Interest Indexes | Rates | Edit).");     
            Report.Step("Step 4.3: Update balance tier2 with valid values Nominal Rate: 'INCINDX1 *1.1 U2', Minimum Rate: 'INCINDX1 -0.2 D2', Maximum Rate: 'INCINDX1 -0.1 D2' in Anticipated Run mode.");
            Report.Step("Step 4.3: Update balance tier3 with valid values Nominal Rate: 'INCINDX1 *1.1 U2', Minimum Rate: 'INCINDX1 -.2 U2', Maximum Rate: 'INCINDX1 -.1 U2' in Anticipated Run mode.");

            string varRateNom22 = INCINDX1 +" *1.1 D2";
            string varRatemin22 = INCINDX1 +" -.2 D2";
            string varRatemax22 = INCINDX1 +" -.1 D2";

            string varRateNom33 = INCINDX1 +" *1.1 U2";
            string varRatemin33 = INCINDX1 +" +.1 U2";
            string varRatemax33 = INCINDX1 +" +.1 U2";

            Application.WebAdmin.EditAndAddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX2,ApplicationDateM2,"","","","0|2||1.87|2.08;5000.00|" + varRateNom22 + "||" + varRatemin22 + "|" + varRatemax22 + ";10000.00|" + varRateNom33 +"||"+ varRatemin33 + "|"+ varRatemax33 ,true, "",false);
 
            Report.Step("Step 5.1: In WebAdmin, select Table Configuration | Interest Indexes On the Interest Index List page,  select the Cumulative tiered index radio button <CUMINDX2>.");
            Report.Step("Step 5.2: Select the Rate added to Effective Date: T-2 days and click Edit (Table Configuration | Interest Indexes | Rates | Edit).");     
            Report.Step("Step 5.3: Update balance tier2 with valid values Nominal Rate: 'CUMINDX1 /1.1 U2', MInimum Rate: 'CUMINDX1 -.2 U2', Maximum Rate: 'CUMINDX1 -.1 U2' in Anticipated Run mode.");
            Report.Step("Step 5.4: Update balance tier3 with valid values Nominal Rate: 'CUMINDX1 -.1 U2', MInimum Rate: 'CUMINDX1 +.2 D2', Maximum Rate: 'CUMINDX1 +.4 D2' in Anticipated Run mode.");

            string varRateNom222 = CUMINDX1 +" /1.1 U2";
            string varRatemin222 = CUMINDX1 +" -.2 U2";
            string varRatemax222 = CUMINDX1 +" -.1 U2";

            string varRateNom333 = CUMINDX1 +" -.1 U2";
            string varRatemin333 = CUMINDX1 +" +.2 D2";
            string varRatemax333 = CUMINDX1 +" +.4 D2";

            Application.WebAdmin.EditAndAddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX2,ApplicationDateM2,"","","","0|2||1.87|2.08;5000.00|" + varRateNom222 +"||" + varRatemin222 +"|" + varRatemax222 +";10000.00|" + varRateNom333 +"||"+ varRatemin333 + "|"+ varRatemax333 ,true, "",false);

            Report.Step("Step 6.0: Expected Result (TC101): Verify that the Mass Index Change Report (REP003) displays minimum and maximum rate set to incremental tiered index.");
            Report.Step("Step 6.1: Verify that the Rate in report REP003 displays Old Value:5.00 and New Value: INCINDX1 +.2 D2 for incremental index INCINDX2.");
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","Old Values|5.00","Index|" +INCINDX2);
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","New Values|" +varRateNom33 ,"Index|" +INCINDX2);

            Report.Step("Step 6.2: Verify that the Minimum Rate in report REP003 displays Old Value: 4.90 and New Value: INCINDX1 +.2 U2 for incremental index INCINDX2.");
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","Old Values|5.10","Index|" +INCINDX2);
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","New Values|" +varRatemin33 ,"Index|" +INCINDX2);

            Report.Step("Step 6.3: Verify that the Maximum Rate in report REP003 displays Old Value: 5.60 and New Value: INCINDX1 +.2 U2 for incremental index INCINDX2.");
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","Old Values|5.60","Index|" +INCINDX2);
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","New Values|" +varRatemax33 ,"Index|" +INCINDX2);

            Report.Step("Step 7.0: Expected Result (TC101): Verify that the Mass Index Change Report (REP003) displays minimum and maximum rate set to incremental tiered index.");
            Report.Step("Step 7.1: Verify that the Rate in report REP003 displays Old Value:5.00 and New Value: CUMINDX1 +.2 D2 for incremental index CUMINDX2.");
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","Old Values|5.00","Index|" +CUMINDX2);
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","New Values|" +varRateNom333 ,"Index|" +CUMINDX2);

            Report.Step("Step 7.2: Verify that the Minimum Rate in report REP003 displays Old Value: 4.90 and New Value: CUMINDX1 +.2 U2 for incremental index CUMINDX2.");
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","Old Values|5.10","Index|" +CUMINDX2);
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","New Values|" +varRatemin333 ,"Index|" +CUMINDX2);

            Report.Step("Step 7.3: Verify that the Maximum Rate in report REP003 displays Old Value: 5.60 and New Value: CUMINDX1 +.2 U2 for incremental index CUMINDX2.");
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","Old Values|5.60","Index|" +CUMINDX2);
            Application.WebAdmin.VerifyProfileReports("Mass Index Change Report","New Values|" +varRatemax333 ,"Index|" +CUMINDX2);

            Report.Step("Step 8.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
    
            Report.Step("Step 8.1: Run a Dayend"); 

            Report.Step("Step 8.2: Create datasheet to store the values.");
            Data.Store("MTGACCT", MTGACCT);
            Data.Store("LNACCT", LNACCT);
            Data.Store("DDAACCT", DDAACCT);
            Data.Store("SAVACCT", SAVACCT); 

        }
    }
}