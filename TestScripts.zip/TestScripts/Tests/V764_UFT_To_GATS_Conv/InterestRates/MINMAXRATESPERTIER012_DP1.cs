/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/24/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0012_DP1:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0012_DP1()
        {

            string MTGACCT = Data.Fetch("mINMAXRATESPERTIER0012", "MTGACCT");
            string LNACCT = Data.Fetch("mINMAXRATESPERTIER0012", "LNACCT");
            string DDAACCT = Data.Fetch("mINMAXRATESPERTIER0012", "DDAACCT");
            string SAVACCT = Data.Fetch("mINMAXRATESPERTIER0012", "SAVACCT");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0:Search for the DDA account <DDAACCT> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(DDAACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");
            string ddaACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, Data.Get("11000"),"4.50000",1,systemDate,"",5, DDAACCT);
            
            Report.Step("Step 2.1:Verify the interest is accrued based on Interest Accrual Method 00 – Standard/Standard 30/360.");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + ddaACCINT);

            Report.Step("Step 2.2:Expected Result (TC61): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the deposit product, during interest accrual for the new deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyDepositInterestRate(DDAACCT, "4.50000");

            Report.Step("Step 3.0:Search for the Savings account <SAVACCT> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string savACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "5500","1.18182",1,systemDate,"",5,SAVACCT );

            Report.Step("Step 3.1:Verify the interest is accrued based on Interest Accrual Method 00 – Standard/Standard 30/360.");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + savACCINT);

            Report.Step("Step 3.2:Expected Result (TC63): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, during interest accrual for the new deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyDepositInterestRate(SAVACCT, "1.18182");

            Report.Step("Step 4.1: Expected Result (TC64): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, during interest accrual for the new loan account on the Accrual page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyLoanInterestRate(LNACCT, "2.27273");
            
            Report.Step("Step 4.2: Search for the Installment Account <LNACCT> and navigate to the Interest | Balances sub-tab.");
            Application.WebCSR.LoadAccountSummaryPage(LNACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string LNACCINT = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000","2.27273",1,systemDate,"",5);
            
            Report.Step("Step 4.3: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Balances page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyAccruedInterest("Last Amount Accrued" + "|" + LNACCINT);
            
            Report.Step("Step 5.0:Search for the MTG Loan Account <MTGACCT> and navigate to Accrual sub-tab .WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(MTGACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string MTGACCINT = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000","4.54000",1,systemDate,"",5);

            Report.Step("Step 5.1: Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Balances page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyAccruedInterest("Last Amount Accrued" + "|" + MTGACCINT);
            
            Report.Step("Step 5.2: Expected Result (TC62): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the loan product, during interest accrual for the new loan account on the Balances page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyLoanInterestRate(MTGACCT, "4.54000");

            Report.Step("Step 5.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}