/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0020_DP1:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0020_DP1()
        {

            string DDAACCT = Data.Fetch("mINMAXRATESPERTIER0020", "DDAACCT");
            string SAVACCT = Data.Fetch("mINMAXRATESPERTIER0020", "SAVACCT");
            string MTGACCT = Data.Fetch("mINMAXRATESPERTIER0020", "MTGACCT");
            string LNACCT = Data.Fetch("mINMAXRATESPERTIER0020", "LNACCT");            

            string CUMINDX2 = Data.Fetch("mINMAXRATESPERTIER0020", "CUMINDX2");
            string INCINDX2 = Data.Fetch("mINMAXRATESPERTIER0020", "INCINDX2");
            string CUMINDX1 = Data.Fetch("mINMAXRATESPERTIER0020", "CUMINDX1");
            string INCINDX1 = Data.Fetch("mINMAXRATESPERTIER0020", "INCINDX1");

            string ddaINTRATE = "2.96364";
            string savINTRATE = "2.25000";
            string mtgINTRATE = "5.10000";
            string lnINTRATE = "3.50000";

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();
            string ApplicationDateM1 = appHandle.CalculateNewDate(systemDate, "D", -1);
            string ApplicationDateM3 = appHandle.CalculateNewDate(systemDate, "D", -3);

            Report.Step("Step 2.0:Search for the DDA account <DDINTRAccNum> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(DDAACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");

            string ddaACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "11000",ddaINTRATE,3,systemDate,"",5, DDAACCT);

            Report.Step("Step 2.1: Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + ddaACCINT);

            Report.Step("Step 2.2: Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(DDAACCT, ddaINTRATE);

            Report.Step("Step 3.0:Search for the Savings account <SAVINTRAccNum> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string savACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "6000",savINTRATE,3,systemDate,"",5, SAVACCT);

            Report.Step("Step 3.1: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + savACCINT);

            Report.Step("Step 3.2: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(SAVACCT, savINTRATE);

            Report.Step("Step 4.0: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyLoanInterestRate(LNACCT, lnINTRATE);
            
            Report.Step("Step 4.1: Search for the Installment Account <LNACCT> and navigate to the Interest | Balances sub-tab.");
            Application.WebCSR.LoadAccountSummaryPage(LNACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string LNACCINT = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "6000",lnINTRATE,3,systemDate,"",5);
            
            Report.Step("Step 4.2: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Balances page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyAccruedInterest("Accrued Interest" + "|" + LNACCINT);

            Report.Step("Step 5.0:Search for the MTG Loan Account <MTGACCT> and navigate to Accrual sub-tab .WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(MTGACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string MTGACCINT = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000",mtgINTRATE,3,systemDate,"",5);

            Report.Step("Step 5.1: Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Balances page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyAccruedInterest("Accrued Interest" + "|" + MTGACCINT);

            Report.Step("Step 5.2: Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyLoanInterestRate(MTGACCT, mtgINTRATE);

            Report.Step("Step 6.0: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));
 
            Report.Step("Step 7.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string ApplicationDateMN3 = appHandle.CalculateNewDate(ApplicationDate, "D", -3);

            Report.Step("Step 7.1: In WebAdmin, select Table Configuration | Interest Indexes On the Interest Index List page,  select the incremental tiered index radio button <INCINDX2>.");
            Report.Step("Step 7.2: Select the Rate added to Effective Date: T-2 days and click Edit (Table Configuration | Interest Indexes | Rates | Edit).");     
            Report.Step("Step 7.3: Update balance tier2 with valid values Nominal Rate: 'INCINDX1 *1.1 U2', MInimum Rate: 'INCINDX1 -0.2 D2', Maximum Rate: 'INCINDX1 -0.1 D2'.");
            Report.Step("Step 7.4: Update balance tier3 with valid values Nominal Rate: 'INCINDX1 *1.1 U2', MInimum Rate: 'INCINDX1 -.2 U2', Maximum Rate: 'INCINDX1 -.1 U2'.");

            string varRateNom22 = INCINDX1 +" *1.1 D2";
            string varRatemin22 = INCINDX1 +" -.2 D2";
            string varRatemax22 = INCINDX1 +" -.1 D2";

            string varRateNom33 = INCINDX1 +" *1.1 U2";
            string varRatemin33 = INCINDX1 +" +.1 U2";
            string varRatemax33 = INCINDX1 +" +.1 U2";

            Application.WebAdmin.EditAndAddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX2,ApplicationDateMN3,"","","","0|2||1.87|2.08;5000.00|" + varRateNom22 + "||" + varRatemin22 + "|" + varRatemax22 + ";10000.00|" + varRateNom33 +"||"+ varRatemin33 + "|"+ varRatemax33 ,false, "",true);
 
            Report.Step("Step 8.1: In WebAdmin, select Table Configuration | Interest Indexes On the Interest Index List page,  select the Cumulative tiered index radio button <CUMINDX2>.");
            Report.Step("Step 8.2: Select the Rate added to Effective Date: T-2 days and click Edit (Table Configuration | Interest Indexes | Rates | Edit).");     
            Report.Step("Step 8.3: Update balance tier2 with valid values Nominal Rate: 'CUMINDX1 /1.1 U2', MInimum Rate: 'CUMINDX1 -.2 U2', Maximum Rate: 'CUMINDX1 -.1 U2'.");
            Report.Step("Step 8.4: Update balance tier3 with valid values Nominal Rate: 'CUMINDX1 -.1 U2', MInimum Rate: 'CUMINDX1 +.2 D2', Maximum Rate: 'CUMINDX1 +.4 D2'.");

            string varRateNom222 = CUMINDX1 +" /1.1 U2";
            string varRatemin222 = CUMINDX1 +" -.2 U2";
            string varRatemax222 = CUMINDX1 +" -.1 U2";

            string varRateNom333 = CUMINDX1 +" -.1 U2";
            string varRatemin333 = CUMINDX1 +" +.2 D2";
            string varRatemax333 = CUMINDX1 +" +.4 D2";

            Application.WebAdmin.EditAndAddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX2,ApplicationDateMN3,"","","","0|2||1.87|2.08;5000.00|" + varRateNom222 +"||" + varRatemin222 +"|" + varRatemax222 +";10000.00|" + varRateNom333 +"||"+ varRatemin333 + "|"+ varRatemax333 ,false, "",true);

            Report.Step("Step 8.4: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
     
            Report.Step("Step 9.0: Run a Dayend"); 
        }
    }
}