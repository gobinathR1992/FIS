/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 09/08/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0021_DP2:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0021_DP2()
        {

            string SAVACCT = Data.Fetch("mINMAXRATESPERTIER0021", "SAVACCT");
            string LNACCT = Data.Fetch("mINMAXRATESPERTIER0021", "LNACCT");  

            string CUMINDX2 = Data.Fetch("mINMAXRATESPERTIER0021", "CUMINDX2");
            string INCINDX2 = Data.Fetch("mINMAXRATESPERTIER0021", "INCINDX2");
            string CUMINDX1 = Data.Fetch("mINMAXRATESPERTIER0021", "CUMINDX1");
            string INCINDX1 = Data.Fetch("mINMAXRATESPERTIER0021", "INCINDX1");                       

            string savINTRATE = "2.96364";
            string lnINTRATE = "5.10000";

            string savINTRATE1 = "2.72727";           
            string lnINTRATE1 = "6.00000";            

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();
            string ApplicationDateM1 = appHandle.CalculateNewDate(systemDate, "D", -1);
            string ApplicationDateM3 = appHandle.CalculateNewDate(systemDate, "D", -3);

            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");

            Report.Step("Step 2.0:Search for the Savings account <SAVINTRAccNum> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string savACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "11000",savINTRATE,3,systemDate,"",9, SAVACCT);
            string savACCINT1 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "11000",savINTRATE1,1,systemDate,"",9, SAVACCT);
            double savACCINT2 = 0;
            savACCINT2 = Convert.ToDouble(savACCINT1) + Convert.ToDouble(savACCINT);
            savACCINT2 = Math.Round(savACCINT2, 5);
            string savACCINT3 = savACCINT2.ToString();

            Report.Step("Step 2.1: Expected Result (TC95): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during mass index change to an deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + savACCINT3);

            Report.Step("Step 2.2: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(SAVACCT, savINTRATE1);

            Report.Step("Step 3.0: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyLoanInterestRate(LNACCT, lnINTRATE1);
            
            Report.Step("Step 3.1: Search for the Installment Account <LNACCT> and navigate to the Interest | Balances sub-tab.");
            Application.WebCSR.LoadAccountSummaryPage(LNACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string LNACCINT = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000",lnINTRATE,3,systemDate,"",9);
            string LNACCINT1 = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000",lnINTRATE1,1,systemDate,"",9);
            double LNACCINT2 = 0;
            LNACCINT2 = Convert.ToDouble(LNACCINT1) + Convert.ToDouble(LNACCINT);
            LNACCINT2 = Math.Round(LNACCINT2, 5);
            string LNACCINT3 = LNACCINT2.ToString();

            Report.Step("Step 3.2: Expected Result (TC96): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the loan product, for interest adjustments during mass index change to an loan account on the Balances page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyAccruedInterest("Accrued Interest" + "|" + LNACCINT3);

            Report.Step("Step 3.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 4.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 4.1: Post a debit transaction to the Savings Account <SAVINTRAccNum> for account opening date of 3000.00 using transaction code SW. Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.WithdrawFunds(SAVACCT,"3000");

            Report.Step("Step 4.2: Post an loan payment to the installment loan account LNACCT for USD 3,000 with effective date T-1. Offset the transaction using transaction code CO (Cash Out).");
            Application.Teller.LoanPayment(LNACCT,"3000");

            Report.Step("Step 4.3:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 5.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string ApplicationDateMN3 = appHandle.CalculateNewDate(ApplicationDate, "D", -3);

            Report.Step("Step 5.1: In WebAdmin, select Table Configuration | Interest Indexes On the Interest Index List page,  select the incremental tiered index radio button <INCINDX2>.");
            Report.Step("Step 5.2: Select the Rate added to Effective Date: T-2 days and click Edit (Table Configuration | Interest Indexes | Rates | Edit).");                
            Report.Step("Step 5.3: Update balance tier2 with valid values Nominal Rate: 'INCINDX1 +.1 U2', Minimum Rate: 'INCINDX1 /1.2 D2', Maximum Rate: 'INCINDX1 /1.1 D2'.");

            string varRateNom22 = INCINDX1 +" +.1 U2";
            string varRatemin22 = INCINDX1 +" /1.2 D2";
            string varRatemax22 = INCINDX1 +" /1.1 D2";

            string varRateNom33 = INCINDX1 +" -.1 U2";
            string varRatemin33 = INCINDX1 +" *1.1 D2";
            string varRatemax33 = INCINDX1 +" *1.2 D2";

            Application.WebAdmin.EditAndAddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX2,ApplicationDateMN3,"","","","0|2||1.87|2.08;5000.00|" + varRateNom22 +"||"+ varRatemin22 + "|"+ varRatemax22 + ";10000.00|" + varRateNom33 +"||"+ varRatemin33 + "|"+ varRatemax33 ,false, "",true); 

            Report.Step("Step 6.1: In WebAdmin, select Table Configuration | Interest Indexes On the Interest Index List page,  select the Cumulative tiered index radio button <CUMINDX2>.");
            Report.Step("Step 6.2: Select the Rate added to Effective Date: T-2 days and click Edit (Table Configuration | Interest Indexes | Rates | Edit).");                 
            Report.Step("Step 6.3: Update balance tier2 with valid values Nominal Rate: 'CUMINDX1 -.1 U2', MInimum Rate: 'CUMINDX1 /1.2 D2', Maximum Rate: 'CUMINDX1 /1.1 D2'.");

            string varRateNom222 = CUMINDX1 +" -.1 U2";
            string varRatemin222 = CUMINDX1 +" /1.2 D2";
            string varRatemax222 = CUMINDX1 +" /1.1 D2";

            string varRateNom333 = CUMINDX1 +" /1.1 U2";
            string varRatemin333 = CUMINDX1 +" *1.1 D2";
            string varRatemax333 = CUMINDX1 +" *1.2 D2";

            Application.WebAdmin.EditAndAddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX2,ApplicationDateMN3,"","","","0|2||1.87|2.08;5000.00|"  + varRateNom222 +"||"+ varRatemin222 + "|"+ varRatemax222 +   ";10000.00|" + varRateNom333 +"||"+ varRatemin333 + "|"+ varRatemax333 ,false, "",true);

            Report.Step("Step 6.4: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
     
            Report.Step("Step 7.0: Run a Dayend"); 
        }
    }
}