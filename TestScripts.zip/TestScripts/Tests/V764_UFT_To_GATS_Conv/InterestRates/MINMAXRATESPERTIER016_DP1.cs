/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0016_DP1:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0016_DP1()
        {

            string DDAACCT = Data.Fetch("mINMAXRATESPERTIER0016", "DDAACCT");
            string SAVACCT = Data.Fetch("mINMAXRATESPERTIER0016", "SAVACCT");

            string ddaINTRATE = "1.50000";
            string ddaINTRATE1 = "2.50000";

            string savINTRATE = "1.10333";
            string savINTRATE1 = "2.10333";

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0:Search for the DDA account <DDINTRAccNum> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(DDAACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");

            string ddaACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "4500",ddaINTRATE,2,systemDate,"",9, DDAACCT);
            string ddaACCINT1 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "4500",ddaINTRATE1,2,systemDate,"",9, DDAACCT);
            double ddaACCINT2 = 0;
            ddaACCINT2 = Convert.ToDouble(ddaACCINT) + Convert.ToDouble(ddaACCINT1);
            ddaACCINT2 = Math.Round(ddaACCINT2, 5);
            string ddaACCINT3 = ddaACCINT2.ToString();

            Report.Step("Step 2.1: Expected Result (TC77): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + ddaACCINT3);

            Report.Step("Step 2.2: Expected Result (TC73): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(DDAACCT, ddaINTRATE1);

            Report.Step("Step 3.0:Search for the Savings account <SAVINTRAccNum> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string savACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "6000",savINTRATE,2,systemDate,"",9, SAVACCT);
            string savACCINT1 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "6000",savINTRATE1,2,systemDate,"",9, SAVACCT);
            double savACCINT2 = 0;
            savACCINT2 = Convert.ToDouble(savACCINT) + Convert.ToDouble(savACCINT1);
            savACCINT2 = Math.Round(savACCINT2, 5);
            string savACCINT3 = savACCINT2.ToString();

            Report.Step("Step 3.1: Expected Result (TC78): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + savACCINT3);

            Report.Step("Step 3.2: Expected Result (TC74): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(SAVACCT, savINTRATE1);

            Report.Step("Step 4: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}