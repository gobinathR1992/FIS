/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/30/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0014:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0014()
        {

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string ApplicationDateP2 = appHandle.CalculateNewDate(ApplicationDate, "D", 2);

            Report.Step("Step 2.0: In WebAdmin, create a New Index of type: 1 - Tiered Index, Tiered Index Type: I - Incremental. (Table Configuration | Interest Indexes | Add).");
            string INCINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + "I - Incremental");
            
            Report.Step("Step 2.1: In WebAdmin, search for the Tiered index <INCINDX1> and rates for Effective date: T with following values Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 1.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX1,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.87" + "|" + "1.02" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.49" + "|" + "5.12", false, "", false);

            Report.Step("Step 2.2: In WebAdmin, search for the Tiered index <INCINDX1> and rates for Effective date: T+2 with following values Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 1.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX1,ApplicationDateP2,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_2") + "|" + "" + "|" + "1.87" + "|" + "2.08" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + "3.50" + "|" + "" + "|" + "3.40" + "|" + "4.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.49" + "|" + "5.12", false, "", false);

            Report.Step("Step 2.3: In WebAdmin, create a New Index of type: 1 - Tiered Index, Tiered Index Type: I - Incremental. (Table Configuration | Interest Indexes | Add).");
            string INCINDX2 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + "I - Incremental");
            
	        string varINTRate2 = INCINDX1 +" *1.2 U2";
	        string varINTRate3 = INCINDX1 +" -.1 D2";
	
	        string minRateNew2 = INCINDX1 +" -.1 U2";
	        string maxRateNew2 = INCINDX1 +" -.2 U2";
	        string minRateNew3 = INCINDX1 +" -.1 D2";
	        string maxRateNew3 = INCINDX1 +" -.2 D2";

            Report.Step("Step 2.4: In WebAdmin, search for the Tiered index <INCINDX2> and rates for Effective date: T with following values Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.95, Maximum Rate: 1.04, Tier2: Balance Tier:5000, Nominal Rate or Index: 'INCINDX1 *1.1 U2', Minimum Rate: 'INCINDX1 -.1 U2', Maximum Rate: 'INCINDX1 -.2 U2' and Tier3: Balance Tier:10,000, Nominal Rate or Index: 'INCINDX1 /1.1 D2', Minimum Rate:'INCINDX1 -.1 D2', Maximum Rate: 'INCINDX1 -.2 D2'. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX2,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.95" + "|" + "1.04" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + varINTRate2 + "|" + "" + "|" + minRateNew2 + "|" + maxRateNew2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + varINTRate3 + "|" + "" + "|" + minRateNew3 + "|" + maxRateNew3, false, "", false);

	        string varINTRate22 = INCINDX1 +" *1.2 U2";
	        string varINTRate33 = INCINDX1 +" -.1 D2";
	
	        string minRateNew22 = INCINDX1 +" -.1 U2";
	        string maxRateNew22 = INCINDX1 +" -.1 U2";
	        string minRateNew33 = INCINDX1 +" -.1 D2";
	        string maxRateNew33 = INCINDX1 +" -.1 D2";

            Report.Step("Step 2.5: In WebAdmin, search for the Tiered index <INCINDX2> and rates for Effective date: T with following values Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.95, Maximum Rate: 1.04, Tier2: Balance Tier:5000, Nominal Rate or Index: 'INCINDX1 *1.1 U2', Minimum Rate: 'INCINDX1 -.1 U2', Maximum Rate: 'INCINDX1 -.2 U2' and Tier3: Balance Tier:10,000, Nominal Rate or Index: 'INCINDX1 /1.1 D2', Minimum Rate:'INCINDX1 -.1 D2', Maximum Rate: 'INCINDX1 -.2 D2'. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX2,ApplicationDateP2,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_2") + "|" + "" + "|" + "1.95" + "|" + "2.04" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + varINTRate22 + "|" + "" + "|" + minRateNew22 + "|" + maxRateNew22 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + varINTRate33 + "|" + "" + "|" + minRateNew33 + "|" + maxRateNew33, false, "", false);

            Report.Step("Step 3.0: In WebAdmin, create a New Index of type: 1 - Tiered Index, Tiered Index Type: C - Cumulative. (Table Configuration | Interest Indexes | Add).");
            string CUMINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("C - Cumulative"));

            Report.Step("Step 3.1: In WebAdmin, search for the Tiered index <CUMINDX1> and rates for Effective date: T with following values Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 2.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX1,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.87" + "|" + "1.02" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.49" + "|" + "5.12", false, "", false);

            Report.Step("Step 3.2: In WebAdmin, search for the Tiered index <CUMINDX1> and rates for Effective date: T+2 with following values Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 2.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX1,ApplicationDateP2,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_2") + "|" + "" + "|" + "1.87" + "|" + "2.08" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + "3.50" + "|" + "" + "|" + "3.40" + "|" + "4.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.49" + "|" + "5.12", false, "", false);

            Report.Step("Step 3.3: In WebAdmin, create a New Index of type: 1 - Tiered Index, Tiered Index Type: C - Cumulative. (Table Configuration | Interest Indexes | Add).");
            string CUMINDX2 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("C - Cumulative"));

	        string varINTRate111 = CUMINDX1 +" +.1 U2";
	        string varINTRate222 = CUMINDX1 +" +.1 U2";
	
	        string minRateNew111 = CUMINDX1 +" *1.2 U2";
	        string maxRateNew111 = CUMINDX1 +" *1.1 U2";
	        string minRateNew222 = CUMINDX1 +" -.1 D2";
	        string maxRateNew222 = CUMINDX1 +" -.1 D2";

            Report.Step("Step 3.4: In WebAdmin, search for the Tiered index <CUMINDX2> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: CUMINDX1 +.1 D2, Maximum Rate: 1.04, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.85, Maximum Rate: 3.10 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.88, Maximum Rate: 5.11. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX2,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + varINTRate111 + "|" + "" + "|" + minRateNew111 + "|" + maxRateNew111 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + varINTRate222 + "|" + "" + "|" + minRateNew222 + "|" + maxRateNew222 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.49" + "|" + "5.12", false, "", false);

	        string varINTRate1111 = CUMINDX1 +" +.1 U2";
	        string varINTRate2222 = CUMINDX1 +" +.1 U2";
	
	        string minRateNew1111 = CUMINDX1 +" *1.2 U2";
	        string maxRateNew1111 = CUMINDX1 +" *1.1 U2";
	        string minRateNew2222 = CUMINDX1 +" -.1 D2";
	        string maxRateNew2222 = CUMINDX1 +" -.1 D2";

            Report.Step("Step 3.5: In WebAdmin, search for the Tiered index <CUMINDX2> and rates for Effective date: T+2 with following values Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.95, Maximum Rate: 2.04, Tier2: Balance Tier:5000, Nominal Rate or Index: 'CUMINDX1 *2.1 U2', Minimum Rate: 2.85, Maximum Rate: 3.10 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 'CUMINDX1 /2.1 D2', Minimum Rate: 4.88, Maximum Rate: 5.12. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX2,ApplicationDateP2,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + varINTRate1111 + "|" + "" + "|" + minRateNew1111 + "|" + maxRateNew1111 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + varINTRate2222 + "|" + "" + "|" + minRateNew2222 + "|" + maxRateNew2222 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.49" + "|" + "5.12", false, "", false);

            Report.Step("Step 4.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
            
            Report.Step("Step 4.1: Create datasheet to store the values.");
            Data.Store("INCINDX1", INCINDX1);
            Data.Store("INCINDX2", INCINDX2);
            Data.Store("CUMINDX1", CUMINDX1);
            Data.Store("CUMINDX2", CUMINDX2);
        }
               
    }
}