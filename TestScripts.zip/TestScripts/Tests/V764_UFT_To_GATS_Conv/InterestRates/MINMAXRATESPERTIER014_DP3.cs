/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/31/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0014_DP3:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0014_DP3()
        {

            string LNACCT = Data.Fetch("mINMAXRATESPERTIER0014", "LNACCT");
            string SAVACCT = Data.Fetch("mINMAXRATESPERTIER0014", "SAVACCT");
            string LNACCINT = Data.Fetch("mINMAXRATESPERTIER0014", "LNACCINT");
            string savACCINT = Data.Fetch("mINMAXRATESPERTIER0014", "savACCINT");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();

            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");

            Report.Step("Step 2.0: Expected Result (TC68): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, during interest accrual for the new loan account on the Accrual page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyLoanInterestRate(LNACCT, "2.17754");
            
            Report.Step("Step 2.1: Search for the Installment Account <LNACCT> and navigate to the Interest | Balances sub-tab.");
            Application.WebCSR.LoadAccountSummaryPage(LNACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string LNACCINT1 = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "8001.06","2.17754",1,systemDate );

            Report.Step("Step 2.2: Verify the interest is accrued based on Interest Accrual Method 00 – Standard/Standard 30/360.");
            Application.WebCSR.VerifyAccruedInterest("Last Amount Accrued" + "|" + LNACCINT1);

            Report.Step("Step 3.0:Search for the Savings account <SAVACCT> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string savACCINT1 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "10500","4.99",1,systemDate );
            double savACCINT2 = 0;
            savACCINT2 = Convert.ToDouble(savACCINT1) + Convert.ToDouble(savACCINT);
            savACCINT2 = Math.Round(savACCINT2, 5);
            string savACCINT3 = savACCINT2.ToString();

            Report.Step("Step 3.1:Verify the interest is accrued based on Interest Accrual Method 00 – Standard/Standard 30/360.");
            Application.WebCSR.VerifyAccruedInterest("Accrued Interest" + "|" + savACCINT3);

            Report.Step("Step 3.2:Expected Result (TC67): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the deposit product, during interest accrual for the new deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyDepositInterestRate(SAVACCT, "4.99000");

            Report.Step("Step 3.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}