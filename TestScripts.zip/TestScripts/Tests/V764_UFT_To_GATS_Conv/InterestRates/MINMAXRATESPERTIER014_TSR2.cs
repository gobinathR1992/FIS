/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/30/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0014_TSR2:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0014_TSR2()
        {

            string LNPROD1 = Data.Fetch("mINMAXRATESPERTIER0014", "LNPROD1");
            string SAVPROD1 = Data.Fetch("mINMAXRATESPERTIER0014", "SAVPROD1");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0:In Profile WebCSR, create a personal customer <CIF1> by entering all required fields (Basic Services| Create Personal Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.1: Create a installment loan account <LNACCT> for the customer <custno> using copied installment product type : lnproductname with the following values: Account Name: MTG; Disbursement Date:  <system date>-15 days; Disbursement Amount: USD 10,000; Account Term: 1Y; Frequency: 5DA.");
            string LNACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), LNPROD1, "", 1, Data.Get("Account Name") + "|LN;" + Data.Get("Amount") + "|" + Data.Get("11000") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Payment Frequency") + "|" + Data.Get("GLOBAL_FREQUENCY_1DA"));

            Report.Step("Step 3.2: Create a SAV account <SAVINTRAccNum>  (Basic Services | Create Account). a. Product Type <SAV_PRODUCT1>, b. Customer <CUSTNUM>, c. Amount:<10000>, d. Opening date:<Sysdate>.");
            string SAVACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), SAVPROD1, "", 1, Data.Get("Account Name") + "|" + "SAV" + ";" + Data.Get("Opening Date")+ "|" + systemDate + ";"+ Data.Get("Opening Deposit") + "|" + "5500");

            Report.Step("Step 3.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 4.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 4.1: Post an disbursement to the installment loan account mtgaccnum for USD 11,000. Offset the transaction using transaction code CO (Cash Out).");
            Application.Teller.LoanDisbursement(LNACCT, "11000");

            Report.Step("Step 4.2: Post a Deposit to the SAVACCT for 5,500.00 using transaction code SAV(SD Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(SAVACCT, "5500");

            Report.Step("Step 3.3:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 4.0: Run a Dayend"); 

            Report.Step("Step 4.1: Create datasheet to store the values.");
            Data.Store("LNACCT", LNACCT);
            Data.Store("SAVACCT", SAVACCT);
        }
    }
}