/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0010_TSR2:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0010_TSR2()
        {

            string DDAPROD1 = Data.Fetch("mINMAXRATESPERTIER0010", "DDAPROD1");
            string SAVPROD1 = Data.Fetch("mINMAXRATESPERTIER0010", "SAVPROD1");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0:In Profile WebCSR, create a personal customer <CIF1> by entering all required fields (Basic Services| Create Personal Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 2.1: Create a demand deposit account <DDINTRAccNum> (Basic Services | Create Account). a. Product Type <DDA_PRODUCT1>, b. Customer <CUSTNUM>, c.Amount:<4000>, d. Opening Date:<Sysdate>");
            string DDINTRAccNum = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), DDAPROD1, "", 1, Data.Get("Account Name") + "|" + "DDAACC" + ";" + Data.Get("Opening Date")+ "|" + systemDate + ";"+ Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_4K") );

            Report.Step("Step 2.2: Create a SAV account <SAVINTRAccNum>  (Basic Services | Create Account). a. Product Type <SAV_PRODUCT1>, b. Customer <CUSTNUM>, c. Amount:<5500>, d. Opening date:<Sysdate>");
            string SAVINTRAccNum = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), SAVPROD1, "", 1, Data.Get("Account Name") + "|" + "SAVACC" + ";" + Data.Get("Opening Date")+ "|" + systemDate + ";"+ Data.Get("Opening Deposit") + "|" + "5500");

            Report.Step("Step 2.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 3.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 3.1: Post a Deposit to the Demand Deposit Account <DDINTRAccNum> for account opening date of 4,000.00 using transaction code DD (DDA Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(DDINTRAccNum, Data.Get("GLOBAL_AMOUNT_REQUESTED_4K"));

            Report.Step("Step 3.2: Post a Deposit to the Savings Account <SAVINTRAccNum> for account opening date of 5,500.00 using transaction code SAV(SD Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(SAVINTRAccNum, "5500");

            Report.Step("Step 3.3:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 4.0: Run a Dayend"); 

            Report.Step("Step 4.1: Create datasheet to store the values.");
            Data.Store("DDINTRAccNum", DDINTRAccNum);
            Data.Store("SAVINTRAccNum", SAVINTRAccNum);

        }
    }
}