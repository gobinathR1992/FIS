/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 09/08/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0021_DP3:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0021_DP3()
        {

            string SAVACCT = Data.Fetch("mINMAXRATESPERTIER0021", "SAVACCT");
            string LNACCT = Data.Fetch("mINMAXRATESPERTIER0021", "LNACCT");  
    
            string savINTRATE = "2.96364";
            string savINTRATE1 = "2.72727"; 
            string savINTRATE2 = "1.81250";

            string lnINTRATE = "5.10000";
            string lnINTRATE1 = "6.00000"; 
            string lnINTRATE2 = "2.50000";         
           
            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();
            string ApplicationDateM1 = appHandle.CalculateNewDate(systemDate, "D", -1);
            string ApplicationDateM3 = appHandle.CalculateNewDate(systemDate, "D", -3);

            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");

            Report.Step("Step 2.0:Search for the Savings account <SAVINTRAccNum> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string savACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "11000",savINTRATE,3,systemDate,"",9, SAVACCT);
            string savACCINT1 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "11000",savINTRATE1,1,systemDate,"",9, SAVACCT);
            string savACCINT2 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "8000",savINTRATE2,1,systemDate,"",9, SAVACCT);

            double savACCINT3 = 0;
            savACCINT3 = Convert.ToDouble(savACCINT2) + Convert.ToDouble(savACCINT1) + Convert.ToDouble(savACCINT);
            savACCINT3 = Math.Round(savACCINT3, 5);
            string savACCINT4 = savACCINT3.ToString();

            Report.Step("Step 2.1: Expected Result (TC99): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during mass index change to an deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + savACCINT4);

            Report.Step("Step 2.2: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(SAVACCT, savINTRATE2);

            Report.Step("Step 3.0: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyLoanInterestRate(LNACCT, lnINTRATE2);
            
            Report.Step("Step 3.1: Search for the Installment Account <LNACCT> and navigate to the Interest | Balances sub-tab.");
            Application.WebCSR.LoadAccountSummaryPage(LNACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string LNACCINT = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000",lnINTRATE,3,systemDate,"",9);
            string LNACCINT1 = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000",lnINTRATE1,1,systemDate,"",9);
            string LNACCINT2 = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "8106.4",lnINTRATE2,1,systemDate,"",5);

            double LNACCINT3 = 0;
            LNACCINT3 = Convert.ToDouble(LNACCINT2) + Convert.ToDouble(LNACCINT1) + Convert.ToDouble(LNACCINT);
            LNACCINT3 = Math.Round(LNACCINT3, 5);
            string LNACCINT4 = LNACCINT3.ToString();

            Report.Step("Step 3.2: Expected Result (TC100): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the loan product, for interest adjustments during mass index change to an loan account on the Balances page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyAccruedInterest("Last Amount Accrued" + "|" + LNACCINT2);

            Report.Step("Step 3.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}