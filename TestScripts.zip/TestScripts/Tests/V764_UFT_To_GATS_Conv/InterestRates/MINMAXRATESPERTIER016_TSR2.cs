/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0016_TSR2:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0016_TSR2()
        {

            string DDAPROD1 = Data.Fetch("mINMAXRATESPERTIER0016", "DDAPROD1");
            string SAVPROD1 = Data.Fetch("mINMAXRATESPERTIER0016", "SAVPROD1");
            string INCINDX1 = Data.Fetch("mINMAXRATESPERTIER0016", "INCINDX1");
            string INCINDX2 = Data.Fetch("mINMAXRATESPERTIER0016", "INCINDX2");
            string CUMINDX1 = Data.Fetch("mINMAXRATESPERTIER0016", "CUMINDX1");
            string CUMINDX2 = Data.Fetch("mINMAXRATESPERTIER0016", "CUMINDX2");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();
            string ApplicationDateM1 = appHandle.CalculateNewDate(systemDate, "D", -1);
            string ApplicationDateM3 = appHandle.CalculateNewDate(systemDate, "D", -3);

            Report.Step("Step 2.0:In Profile WebCSR, create a personal customer <CIF1> by entering all required fields (Basic Services| Create Personal Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 2.1: Create a demand deposit account <DDINTRAccNum> (Basic Services | Create Account). a. Product Type <DDA_PRODUCT1>, b. Customer <CUSTNUM>, c.Amount:<4000>, d. Opening Date:<Sysdate>");
            string DDAACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), DDAPROD1, "", 1, Data.Get("Account Name") + "|" + "DDAACC" + ";" + Data.Get("Opening Date")+ "|" + ApplicationDateM3 + ";"+ Data.Get("Opening Deposit") + "|" + "4500");

            Report.Step("Step 2.2: Create a SAV account <SAVINTRAccNum>  (Basic Services | Create Account). a. Product Type <SAV_PRODUCT1>, b. Customer <CUSTNUM>, c. Amount:<5500>, d. Opening date:<Sysdate>");
            string SAVACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), SAVPROD1, "", 1, Data.Get("Account Name") + "|" + "SAVACC" + ";" + Data.Get("Opening Date")+ "|" + ApplicationDateM3 + ";"+ Data.Get("Opening Deposit") + "|" + "6000");

            Report.Step("Step 2.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 3.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 3.1: Post a Deposit to the DDACCT for 4,500.00 using transaction code DDA(DD Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(DDAACCT, "4500",ApplicationDateM3);

            Report.Step("Step 3.2: Post a Deposit to the Savings Account <SAVINTRAccNum> for account opening date of 6000.00 using transaction code SAV(SD Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(SAVACCT, "6000",ApplicationDateM3);

            Report.Step("Step 3.3:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 4.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
 
            Report.Step("Step 4.1: Navigate to Utilities | Interest Index Summary page. Select dropdown Index: CUMINDX1, enter date From: T-3 and To: T and Submit.");         
            Report.Step("Step 4.1: Expected Result (TC102): Verify that the minimum and maximum rate fields set to an incremental/cumulative tiered index associated with an account is displayed in Interest Index Summary page of Profile WebCSR");
            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM3 +";0;1;0.87;1.02",CUMINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3;2.80;3.15",CUMINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",CUMINDX1,ApplicationDateM3,ApplicationDateM1);

            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM1 +";0;2;1.87;2.08",CUMINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3.50;3.40;4.10",CUMINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",CUMINDX1,ApplicationDateM3,ApplicationDateM1);

	        string varINTRate19 = CUMINDX1 +" +.1 D2";	
	        string minRateNew19 = CUMINDX1 +" *1.2 U2";
	        string maxRateNew19 = CUMINDX1 +" *1.1 U2";

            Report.Step("Step 4.2: Select dropdown Index: CUMINDX2, enter date From: T-3 and To: T and Submit.");
            Report.Step("Step 4.2: Expected Result (TC102): Verify that the minimum and maximum rate fields set to an incremental/cumulative tiered index associated with an account is displayed in Interest Index Summary page of Profile WebCSR.");
            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM3 +";0;" + varINTRate19 + ";" + minRateNew19 +";" + maxRateNew19,CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3;2.85;3.10",CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",CUMINDX2,ApplicationDateM3,ApplicationDateM1);

	        string varINTRate111 = CUMINDX1 +" +.1 U2";		
	        string minRateNew1119 = CUMINDX1 +" *1.2 U2";
	        string maxRateNew1119 = CUMINDX1 +" *1.1 U2";

            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM1 +";0;" + varINTRate111 + ";" + minRateNew1119 + ";" + maxRateNew1119,CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3.50;3.41;4.12",CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            
            Report.Step("Step 4.3: Select dropdown Index: INCINDX1, enter date From: T-3 and To: T and Submit.");
            Report.Step("Step 4.3: Expected Result (TC102): Verify that the minimum and maximum rate fields set to an incremental/cumulative tiered index associated with an account is displayed in Interest Index Summary page of Profile WebCSR.");
            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM3 +";0;1;0.87;1.02",INCINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3;2.80;3.15",INCINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",INCINDX1,ApplicationDateM3,ApplicationDateM1);

            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM1 +";0;2;1.87;2.08",INCINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3.50;3.40;4.10",INCINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",INCINDX1,ApplicationDateM3,ApplicationDateM1);

        	string varINTRate2 = INCINDX1 +" +.1 U2";		
	        string minRateNew29 = INCINDX1 +" +.1 U2";
	        string maxRateNew29 = INCINDX1 +" +.1 U2";

            Report.Step("Step 4.4: Select dropdown Index: INCINDX2, enter date From: T-3 and To: T and Submit.");
            Report.Step("Step 4.4: Expected Result (TC102): Verify that the minimum and maximum rate fields set to an incremental/cumulative tiered index associated with an account is displayed in Interest Index Summary page of Profile WebCSR.");
            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM3 +";0;1;0.95;1.04",INCINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;" + varINTRate2 + ";" + minRateNew29 + ";" + maxRateNew29,INCINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.48;5.11",INCINDX2,ApplicationDateM3,ApplicationDateM1);

	        string varINTRate22 = INCINDX1 +" +.2 U2";		
	        string minRateNew229 = INCINDX1 +" +.2 U2";
	        string maxRateNew229 = INCINDX1 +" +.2 U2";

            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM1 +";0;2;1.95;2.04",INCINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;" + varINTRate22 + ";" + minRateNew229 + ";" + maxRateNew229,INCINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.48;5.11",INCINDX2,ApplicationDateM3,ApplicationDateM1);

            Report.Step("Step 4.5: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Run a Dayend"); 

             Report.Step("Step 5.1: Create datasheet to store the values.");
            Data.Store("DDAACCT", DDAACCT);
            Data.Store("SAVACCT", SAVACCT); 

        }
    }
}