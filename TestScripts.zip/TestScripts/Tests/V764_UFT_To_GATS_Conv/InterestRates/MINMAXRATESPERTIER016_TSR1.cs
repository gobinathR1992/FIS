/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0016_TSR1:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0016_TSR1()
        {

            string CUMINDX2 = Data.Fetch("mINMAXRATESPERTIER0016", "CUMINDX2");
            string INCINDX2 = Data.Fetch("mINMAXRATESPERTIER0016", "INCINDX2");

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string SYSDATEPLUS1M = appHandle.CalculateNewDate(ApplicationDate, "M", 1);

            Report.Step("Step 2.0:Copy a standard Demand Deposit product.<DDAPROD1> with product type 400.WebADMIN|Product Factory|Products.");
            string DDAPROD1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),Data.Get("GLOBAL_STD_PROD_NUM_400"),true);

            Report.Step("Step 2.1: Navigate to Interest Accrual page and Enter Accrual Calculation Base:  1 – Ledger Balance & Set Accrual Calc Method (DEP.IACM)to :<Actual/Actual (31/365,6)> and click on submit button.");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPROD1, Data.Get("GLOBAL_ACCRUAL_BASE"),appHandle.ReplaceString("Actual/Actual (31/365$6)","$",","),Data.Get("0.01"),"","");

            Report.Step("Step 2.2: Navigate to Posting Option and Enter Posting Option:  0 – Remain on Deposit, Posting Frequency:  1DA  and click on submit button.");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPROD1,Data.Get("GLOBAL_DISBURSEMENT_OPTION"),"8DA","",false,false);

            Report.Step("Step 2.3: Navigate to Rate Determination Page and set Index created (DEP.INDEX) to:<CUMINDX2> and	Change Frequency (DEP.INTFRE)to :<1DA> and click on Submit button.");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPROD1,"",CUMINDX2,Data.Get("GLOBAL_FREQUENCY_1DA"));

            Report.Step("Step 3.0:Copy a standard Savings product.<SAVPROD1> with product type 400.WebADMIN|Product Factory|Products.");
            string SAVPROD1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_SAVINGSDEPOSIT_GROUP"),Data.Get("GLOBAL_STD_PROD_NUM_300"),true);

            Report.Step("Step 3.1: Navigate to Interest Accrual page and Set Accrual Calc Method (DEP.IACM)as :<Actual/Actual (31/365,6)> and click on submit button.");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_SAVINGSDEPOSIT_GROUP"),SAVPROD1, Data.Get("GLOBAL_ACCRUAL_BASE"),appHandle.ReplaceString("Actual/Actual (31/365$6)","$",","),Data.Get("0.01"),"","");

            Report.Step("Step 3.2: Navigate to Posting Option and Enter Posting Option:  0 – Remain on Deposit, Posting Frequency:  1DA  and click on submit button.");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_SAVINGSDEPOSIT_GROUP"),SAVPROD1,Data.Get("GLOBAL_DISBURSEMENT_OPTION"),"8DA","",false,false);

            Report.Step("Step 3.3: Navigate to Rate Determination Page and set Index created (DEP.INDEX) to:<INCINDX2> and	Change Frequency (DEP.INTFRE)to :<1DA> and click on Submit button.");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_SAVINGSDEPOSIT_GROUP"),SAVPROD1,"",INCINDX2,Data.Get("GLOBAL_FREQUENCY_1DA"),"","","0.02");

            Report.Step("Step 4.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
            
            Report.Step("Step 4.1: Create datasheet to store the values.");
            Data.Store("DDAPROD1", DDAPROD1);
            Data.Store("SAVPROD1", SAVPROD1);

        }
               
    }
}