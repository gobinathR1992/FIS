/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0012:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0012()
        {

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string SYSDATEPLUS1M = appHandle.CalculateNewDate(ApplicationDate, "M", 1);

            Report.Step("Step 2.0: In WebAdmin, create a New Index of type: 1 - Tiered Index, Tiered Index Type: C - Cumulative. (Table Configuration | Interest Indexes | Add).");
            string CUMINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("C - Cumulative"));

            Report.Step("Step 2.1: In WebAdmin, search for the Tiered index <CUMINDX1> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 1.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX1,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.87" + "|" + "1.02" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.49" + "|" + "5.12", false, "", false);

            Report.Step("Step 2.2: In WebAdmin, create a New Index of type: 1 - Tiered Index, Tiered Index Type: C - Cumulative. (Table Configuration | Interest Indexes | Add).");
            string CUMINDX2 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("C - Cumulative"));

	        string varINTRate2 = CUMINDX1 +" *1.2 U2";
	        string varINTRate3 = CUMINDX1 +" /1.1 D2";

            Report.Step("Step 2.3: In WebAdmin, search for the Tiered index <CUMINDX2> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.95, Maximum Rate: 1.04, Tier2: Balance Tier:5000, Nominal Rate or Index: 'CUMINDX1 *1.1 U2', Minimum Rate: 2.85, Maximum Rate: 3.10 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 'CUMINDX1 /1.1 D2', Minimum Rate: 4.88, Maximum Rate: 5.11. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX2,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.95" + "|" + "1.04" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + varINTRate2 + "|" + "" + "|" + "2.85" + "|" + "3.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + varINTRate3 + "|" + "" + "|" + "4.48" + "|" + "5.11", false, "", false);

            Report.Step("Step 3.0: In WebAdmin, create a New Index of type: 1 - Tiered Index, Tiered Index Type: I - Incremental. (Table Configuration | Interest Indexes | Add).");
            string INCINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + "I - Incremental");
            
            Report.Step("Step 3.1: In WebAdmin, search for the Tiered index <INCINDX1> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 1.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX1,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.87" + "|" + "1.02" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.49" + "|" + "5.12", false, "", false);

            Report.Step("Step 4.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
            
            Report.Step("Step 4.1: Create datasheet to store the values.");
            Data.Store("INCINDX1", INCINDX1);
            Data.Store("CUMINDX1", CUMINDX1);
            Data.Store("CUMINDX2", CUMINDX2);
        }
               
    }
}