/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0017_DP1:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0017_DP1()
        {

            string LNACCT = Data.Fetch("mINMAXRATESPERTIER0017", "LNACCT");
            string MTGACCT = Data.Fetch("mINMAXRATESPERTIER0017", "MTGACCT");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();
            string SYSDATEM2 = appHandle.CalculateNewDate(systemDate, "D", -2);

            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");

            Report.Step("Step 2.0: Expected Result (TC76): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyLoanInterestRate(LNACCT, "2.72728");
            
            Report.Step("Step 2.1: Search for the Installment Account <LNACCT> and navigate to the Interest | Balances sub-tab.");
            Application.WebCSR.LoadAccountSummaryPage(LNACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string LNACCINT = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000","2.72728",1,systemDate,"",9);
            
            string LNACCINT1 = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000","2.04546",2,systemDate,"",9 );
            string LNACCINT2 = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000","2.5",1,systemDate,"",9 );

            double LNACCINT3 = 0;
            LNACCINT3 = Convert.ToDouble(LNACCINT) + Convert.ToDouble(LNACCINT1) + Convert.ToDouble(LNACCINT2);
            LNACCINT3 = Math.Round(LNACCINT3, 5);
            string LNACCINT6 = LNACCINT3.ToString();

            double LNACCINT4 = Convert.ToDouble(LNACCINT);
            LNACCINT4 = Math.Round(LNACCINT4, 5);
            string LNACCINT5 = LNACCINT4.ToString();

            Report.Step("Step 2.2: Expected Result (TC80): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Balances page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyAccruedInterest("Last Amount Accrued" + "|" + LNACCINT5);
            Application.WebCSR.VerifyAccruedInterest("Accrued Interest" + "|" + LNACCINT6);

            Report.Step("Step 3.0:Search for the MTG Loan Account <MTGACCT> and navigate to Accrual sub-tab .WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(MTGACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string MTGACCINT = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000","4.54",1,systemDate,"",5);

            string MTGACCINT1 = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000","4.54",2,systemDate,"",9);
            string MTGACCINT2 = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "11000","4.04",2,systemDate,"",9);

            double MTGACCINT3 = 0;
            MTGACCINT3 = Convert.ToDouble(MTGACCINT1) + Convert.ToDouble(MTGACCINT2);
            MTGACCINT3 = Math.Round(MTGACCINT3, 5);
            string MTGACCINT4 = MTGACCINT3.ToString();

            Report.Step("Step 3.1: Expected Result (TC79): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Balances page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyAccruedInterest("Last Amount Accrued" + "|" + MTGACCINT);
            Application.WebCSR.VerifyAccruedInterest("Accrued Interest" + "|" + MTGACCINT4);

            Report.Step("Step 3.2: Expected Result (TC75): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the loan product, for interest adjustments during effective dated transactions to an loan account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyLoanInterestRate(MTGACCT, "4.54000");

            Report.Step("Step 3.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 4.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 4.1: Post an loan payment to the installment loan account LNACCT for USD 3,000. Offset the transaction using transaction code CO (Cash Out).");
            Application.Teller.LoanPayment(LNACCT,"3000",SYSDATEM2);

            Report.Step("Step 4.1: Post an loan payment to the MTG loan account MTGACCT for USD 7,000. Offset the transaction using transaction code CO (Cash Out).");
            Application.Teller.LoanPayment(MTGACCT,"7000",SYSDATEM2);

            Report.Step("Step 4.3:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

        }
    }
}