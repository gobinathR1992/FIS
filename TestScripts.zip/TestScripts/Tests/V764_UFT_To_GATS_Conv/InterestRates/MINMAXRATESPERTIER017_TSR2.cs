/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0017_TSR2:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0017_TSR2()
        {

            string MTGPROD1 = Data.Fetch("mINMAXRATESPERTIER0017", "MTGPROD1");
            string LNPROD1 = Data.Fetch("mINMAXRATESPERTIER0017", "LNPROD1");
            string INCINDX1 = Data.Fetch("mINMAXRATESPERTIER0017", "INCINDX1");
            string INCINDX2 = Data.Fetch("mINMAXRATESPERTIER0017", "INCINDX2");
            string CUMINDX1 = Data.Fetch("mINMAXRATESPERTIER0017", "CUMINDX1");
            string CUMINDX2 = Data.Fetch("mINMAXRATESPERTIER0017", "CUMINDX2");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();
            string ApplicationDateM1 = appHandle.CalculateNewDate(systemDate, "D", -1);
            string ApplicationDateM3 = appHandle.CalculateNewDate(systemDate, "D", -3);

            Report.Step("Step 2.0:In Profile WebCSR, create a personal customer <CIF1> by entering all required fields (Basic Services| Create Personal Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create a mortgage loan account <mtgaccnum> for the customer <custno> using copied Mortgage product type : mtgproductname with the following values: Account Name: MTG; Disbursement Date:  <system date-3 days>; Disbursement Amount: USD 11,000; Account Term: 1Y; Frequency: 1DA.");
            string MTGACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), MTGPROD1, "", 1, Data.Get("Account Name") + "|MTG;" + Data.Get("Amount") + "|" + Data.Get("11000") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Disbursement Date") + "|" +  ApplicationDateM3 +  ";" + Data.Get("Payment Frequency") + "|" + Data.Get("GLOBAL_FREQUENCY_1DA") + ";Collateral Type|0 - Unsecured");

            Report.Step("Step 3.1: Create a installment loan account <LNACCT> for the customer <custno> using copied installment product type : lnproductname with the following values: Account Name: MTG; Disbursement Date:  <system date>-3 days; Disbursement Amount: USD 10,000; Account Term: 1Y; Frequency: 5DA.");
            string LNACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), LNPROD1, "", 1, Data.Get("Account Name") + "|LN;" + Data.Get("Amount") + "|" + Data.Get("11000") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Disbursement Date") + "|" +  ApplicationDateM3 +  ";" + Data.Get("Payment Frequency") + "|" + Data.Get("GLOBAL_FREQUENCY_1DA"));

            Report.Step("Step 3.2: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 4.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 4.1: Post an disbursement to the Mortgage loan account mtgaccnum for USD 11,000 using transaction code MD (Mortgage Disbursement). Offset the transaction using transaction code CO (Cash Out).");
            Application.Teller.LoanDisbursement(MTGACCT, "11000", ApplicationDateM3);

            Report.Step("Step 4.2: Post an disbursement to the installment loan account mtgaccnum for USD 11,000. Offset the transaction using transaction code CO (Cash Out).");
            Application.Teller.LoanDisbursement(LNACCT, "11000", ApplicationDateM3);

            Report.Step("Step 4.3:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 4.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
 
            Report.Step("Step 4.1: Navigate to Utilities | Interest Index Summary page. Select dropdown Index: CUMINDX1, enter date From: T-3 and To: T and Submit.");         
            Report.Step("Step 4.1: Expected Result (TC102): Verify that the minimum and maximum rate fields set to an incremental/cumulative tiered index associated with an account is displayed in Interest Index Summary page of Profile WebCSR");
            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM3 +";0;1;0.87;1.02",CUMINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3;2.80;3.15",CUMINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",CUMINDX1,ApplicationDateM3,ApplicationDateM1);

            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM1 +";0;2;1.87;2.08",CUMINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3.50;3.40;4.10",CUMINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",CUMINDX1,ApplicationDateM3,ApplicationDateM1);

	        string varINTRate39 = CUMINDX1 +" +.1 D2";	
	        string minRateNew39 = CUMINDX1 +" /1.1 D2";
	        string maxRateNew39 = CUMINDX1 +" /1.2 D2";

            Report.Step("Step 4.2: Select dropdown Index: CUMINDX2, enter date From: T-3 and To: T and Submit.");
            Report.Step("Step 4.2: Expected Result (TC102): Verify that the minimum and maximum rate fields set to an incremental/cumulative tiered index associated with an account is displayed in Interest Index Summary page of Profile WebCSR.");
            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM3 +";0;1;0.95;1.04" ,CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3;2.85;3.10",CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;" + varINTRate39 + ";" + minRateNew39 +";" + maxRateNew39,CUMINDX2,ApplicationDateM3,ApplicationDateM1);

	        string varINTRate333 = CUMINDX1 +" +.1 D2";		
	        string minRateNew3339 = CUMINDX1 +" -.1 D2";
	        string maxRateNew3339 = CUMINDX1 +" -.1 D2";
            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM1 +";0;2;1.95;2.04",CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3.50;3.41;4.12",CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;" + varINTRate333 + ";" + minRateNew3339 + ";" + maxRateNew3339,CUMINDX2,ApplicationDateM3,ApplicationDateM1);
            
            Report.Step("Step 4.3: Select dropdown Index: INCINDX1, enter date From: T-3 and To: T and Submit.");
            Report.Step("Step 4.3: Expected Result (TC102): Verify that the minimum and maximum rate fields set to an incremental/cumulative tiered index associated with an account is displayed in Interest Index Summary page of Profile WebCSR.");
            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM3 +";0;1;0.87;1.02",INCINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3;2.80;3.15",INCINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",INCINDX1,ApplicationDateM3,ApplicationDateM1);

            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM1 +";0;2;1.87;2.08",INCINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;3.50;3.40;4.10",INCINDX1,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.49;5.12",INCINDX1,ApplicationDateM3,ApplicationDateM1);

        	string varINTRate2 = INCINDX1 +" /1.1 U2";		
	        string minRateNew29 = INCINDX1 +" /1.1 U2";
	        string maxRateNew29 = INCINDX1 +" /1.1 U2";

            Report.Step("Step 4.4: Select dropdown Index: INCINDX2, enter date From: T-3 and To: T and Submit.");
            Report.Step("Step 4.4: Expected Result (TC102): Verify that the minimum and maximum rate fields set to an incremental/cumulative tiered index associated with an account is displayed in Interest Index Summary page of Profile WebCSR.");
            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM3 +";0;1;0.95;1.04",INCINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;" + varINTRate2 + ";" + minRateNew29 + ";" + maxRateNew29,INCINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.48;5.11",INCINDX2,ApplicationDateM3,ApplicationDateM1);

	        string varINTRate22 = INCINDX1 +" /1.1 U2";		
	        string minRateNew229 = INCINDX1 +" /1.1 U2";
	        string maxRateNew229 = INCINDX1 +" /1.1 U2";

            Application.WebCSR.VerifyInterestIndexSummaryTable(ApplicationDateM1 +";0;2;1.95;2.04",INCINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("5000;" + varINTRate22 + ";" + minRateNew229 + ";" + maxRateNew229,INCINDX2,ApplicationDateM3,ApplicationDateM1);
            Application.WebCSR.VerifyInterestIndexSummaryTable("10000;5;4.48;5.11",INCINDX2,ApplicationDateM3,ApplicationDateM1);

            Report.Step("Step 4.5: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 4.0: Run a Dayend"); 

            Report.Step("Step 4.1: Create datasheet to store the values.");
            Data.Store("MTGACCT", MTGACCT);
            Data.Store("LNACCT", LNACCT); 
        }
    }
}