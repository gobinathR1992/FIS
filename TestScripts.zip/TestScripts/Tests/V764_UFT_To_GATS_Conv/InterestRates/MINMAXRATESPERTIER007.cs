/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER007:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER007()
        {

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string SYSDATEPLUS1M = appHandle.CalculateNewDate(ApplicationDate, "M", 1);

            Report.Step("Step 2.0: In WebAdmin, create a New Index INCINDX1 of type: 1 - Tiered Index, Tiered Index Type: I - Incremental. (Table Configuration | Interest Indexes | Add).");
            string INCINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("I - Incremental"));
            
            Report.Step("Step 2.1: In WebAdmin, search for the Tiered index <INCINDX1> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 1.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX1,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.85" + "|" + "5.05", false, "", false);

            Report.Step("Step 3.0: In WebAdmin, create a New Index INCINDX2 of type: 1 - Tiered Index, Tiered Index Type: I - Incremental. (Table Configuration | Interest Indexes | Add).");
            string INCINDX2 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("I - Incremental"));
    
            string varRatemin1 = INCINDX1 +" *.1 D2";
            string varRatemax1 = INCINDX1 +" *.2 U2";
            string varRatemin2 = INCINDX1 +" /.1 U2";
            string varRatemax2 = INCINDX1 +" /.2 D2";

            Report.Step("Step 3.1: In WebAdmin, search for the Tiered index <INCINDX2> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: INCINDX1 *.1 D2, Maximum Rate: INCINDX1 *.2 U2, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: INCINDX1 -.1 U2, Maximum Rate: INCINDX1 -.2 D2 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX2,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin1 + "|" + varRatemax1 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.85" + "|" + "5.05", false, "", false);

            Report.Step("Step 4.0: Search and select the Tiered Index <INCINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 4.1: Expected Result (TC22): Verify that an index can be set as maximum and minimum rate for each tier while adding rates to a incremental tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INCINDX> | Rates | Add).");
            Report.Step("Step 4.2: Expected Result (TC37): Verify that the variable rates having operand '*' and rounding option 'Up' (ex - INDEX1 *.1 U2) is set as maximum and minimum rate for each tier while adding rates to a tiered index on the Add Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Add).");
            Report.Step("Step 4.3: Expected Result (TC41): Verify that the variable rates having operand '/' and rounding option 'Up' (ex - INDEX1 /.1 U2) is set as maximum and minimum rate for each tier while adding rates to a tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Add).");
            Application.WebAdmin.VerifyInterestIndexTableValues("0;1;" + varRatemin1 +";" + varRatemax1,INCINDX2,ApplicationDate);
            Application.WebAdmin.VerifyInterestIndexTableValues("5000;3;" + varRatemin2 +";" + varRatemax2,INCINDX2,ApplicationDate);

            string varRatemin33 = INCINDX1 +" *.1 D2";

            Report.Step("Step 5.0 : Update balance tier3 Minimum Rate with an valid value 'INCINDX1 *.1 D2'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(INCINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin1 + "|" + varRatemax1 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + "5.05");

            Report.Step("Step 5.1 : Search and select the Tiered Index <INCINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 5.2 : Expected Result (TC26): Verify that the field, minimum rate is updated with an index for a  incremental tiered index on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INCINDX> | Rates | Edit).");
            Report.Step("Step 5.3 : Expected Result (TC38): Verify that the field minimum rate is updated with variable rate having operand '*' and rounding option 'Down' (ex - INDEX1 *.1 D2) on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("10000;5;" + varRatemin33 +";5.05",INCINDX2,ApplicationDate);

            string varRatemax33 = INCINDX1 +" *.1 D3";

            Report.Step("Step 6.0 : Update balance tier3 Maximum Rate with an valid value 'INCINDX1 *.1 D3'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(INCINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin1 + "|" + varRatemax1 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax33);

            Report.Step("Step 6.1 : Search and select the Tiered Index <INCINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 6.2 : Expected Result (TC27): Verify that the field, maxinum rate is updated with an index for a incremental tiered index on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INCINDX> | Rates | Edit).");
            Report.Step("Step 6.3 : Expected Result (TC39): Verify that the field maximum rate is updated with variable rate having operand '*' and rounding option 'Up' (ex - INDEX1 *.1 U2) on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("10000;5;" + varRatemin33 +";" + varRatemax33,INCINDX2,ApplicationDate);

            string varRatemin21 = INCINDX1 +" *.2 D3";
	        string varRatemax21 = INCINDX1 +" *.2 U3";

            Report.Step("Step 7.0 : Update balance tier1 Minimum and Maximum Rate with an valid value 'INCINDX1 *.2 D3' and 'INCINDX1 *.2 U3'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(INCINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin21 + "|" + varRatemax21 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax33);

            Report.Step("Step 7.1 : Search and select the Tiered Index <INCINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 7.2 : Expected Result (TC28): Verify that the fields, maximum and minimum rate are updated with indexes for a incremental tiered index on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <INCINDX> | Rates | Edit).");
            Report.Step("Step 7.3 : Expected Result (TC40): Verify that the fields maximum and minimum rate are updated with variable rate having operand '*' and rounding option 'Down' (ex - INDEX1 *.1 D2) on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("0;1;" + varRatemin21 +";" + varRatemax21,INCINDX2,ApplicationDate);
            
            string varRatemin31 = INCINDX1 +" /.1 D2";

            Report.Step("Step 8.0 : Update balance tier1 Minimum Rate with an valid value 'INDEX1 /.1 D2'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(INCINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin31 + "|" + varRatemax21 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax33);

            Report.Step("Step 8.1 : Search and select the Tiered Index <INCINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 8.2 : Expected Result (TC42): Verify that the field minimum rate is updated with variable rate having operand '/' and rounding option 'Down' (ex - INDEX1 /.1 D2) on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("0;1;" + varRatemin31 +";" + varRatemax21,INCINDX2,ApplicationDate);

            string varRatemax31 = INCINDX1 +" /.1 U2";

            Report.Step("Step 9.0 : Update balance tier1 Maximum Rate with an valid value 'INCINDX1 /.1 U2'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(INCINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin31 + "|" + varRatemax31 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax33);

            Report.Step("Step 9.1 : Search and select the Tiered Index <INCINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 9.2 : Expected Result (TC43): Verify that the field maximum rate is updated with variable rate having operand '/' and rounding option 'Up' (ex - INDEX1 /.1 U2) on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("0;1;" + varRatemin31 +";" + varRatemax31,INCINDX2,ApplicationDate);

            string varRatemin03 = INCINDX1 +" /.2 D2";
	        string varRatemax03 = INCINDX1 +" /.3 U2";

            Report.Step("Step 10.0 : Update balance tier2 Minimum and Maximum Rate with an valid value 'INCINDX1 /.2 D2' and 'INCINDX1 /.3 U2'.");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(INCINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin31 + "|" + varRatemax31 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin03 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax03);

            Report.Step("Step 10.1 : Search and select the Tiered Index <INCINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 10.2 : Expected Result (TC44): Verify that the fields maximum and minimum rate are updated with variable rate having operand '/' and rounding option 'Down' (ex - INDEX1 /.1 D2) on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("5000;3;" + varRatemin03 +";" + varRatemax2,INCINDX2,ApplicationDate);
            Application.WebAdmin.VerifyInterestIndexTableValues("10000;5;" + varRatemin33 +";" + varRatemax03,INCINDX2,ApplicationDate);

            Report.Step("Step 11.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
            
        }
               
    }
}