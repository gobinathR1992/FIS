/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER006:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER006()
        {

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string SYSDATEPLUS1M = appHandle.CalculateNewDate(ApplicationDate, "M", 1);

            Report.Step("Step 2.0: In WebAdmin, create a New Index CUMINDX1 of type: 1 - Tiered Index, Tiered Index Type: C - Cumulative. (Table Configuration | Interest Indexes | Add).");
            string CUMINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("C - Cumulative"));
            
            Report.Step("Step 2.1: In WebAdmin, search for the Tiered index <CUMINDX1> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 1.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX1,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ "5000" + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.85" + "|" + "5.05", false, "", false);

            Report.Step("Step 3.0: In WebAdmin, create a New Index CUMINDX2 of type: 1 - Tiered Index, Tiered Index Type: C - Cumulative. (Table Configuration | Interest Indexes | Add).");
            string CUMINDX2 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("C - Cumulative"));
    
            string varRatemin1 = CUMINDX1 +" +.1 D2";
            string varRatemax1 = CUMINDX1 +" +.2 D2";
            string varRatemin2 = CUMINDX1 +" -.1 D2";
            string varRatemax2 = CUMINDX1 +" -.2 D2";

            Report.Step("Step 3.1: In WebAdmin, search for the Tiered index <CUMINDX2> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: CUMINDX1 +.1 D2, Maximum Rate: CUMINDX1 +.2 D2, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: CUMINDX1 -.1 D2, Maximum Rate: CUMINDX1 -.2 D2 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX2,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin1 + "|" + varRatemax1 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.85" + "|" + "5.05", false, "", false);

            Report.Step("Step 4.0: Search and select the Tiered Index <CUMINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 4.1: Expected Result (TC21): Verify that an index can be set as maximum and minimum rate for each tier while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Report.Step("Step 4.2: Expected Result (TC29): Verify that an variable rate having operand '+' and rounding option 'Down' (ex - INDEX1 +.1 D2) is set as maximum and minimum rate for each tier while adding rates to a tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INCINDX> | Rates | Add).");
            Report.Step("Step 4.3: Expected Result (TC33): Verify that the variable rates having operand '-' (ex - INDEX1 -.1) is set as maximum and minimum rate for each tier while adding rates to a tiered index using on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Add).");
            Application.WebAdmin.VerifyInterestIndexTableValues("0;1;" + varRatemin1 +";" + varRatemax1,CUMINDX2,ApplicationDate);
            Application.WebAdmin.VerifyInterestIndexTableValues("5000;3;" + varRatemin2 +";" + varRatemax2,CUMINDX2,ApplicationDate);

            string varRatemin33 = CUMINDX1 +" +.1 U2";

            Report.Step("Step 5.0 : Update balance tier3 Minimum Rate with an valid value 'CUMINDX1 +.1 U2'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(CUMINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin1 + "|" + varRatemax1 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + "5.05");

            Report.Step("Step 5.1 : Search and select the Tiered Index <CUMINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 5.2 : Expected Result (TC23): Verify that the field, minimum rate is updated with an index for a  cumulative tiered index on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("10000;5;" + varRatemin33 +";5.05",CUMINDX2,ApplicationDate);

            string varRatemax33 = CUMINDX1 +" +.1 D3";

            Report.Step("Step 6.0 : Update balance tier3 Maximum Rate with an valid value 'CUMINDX1 +.1 D3'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(CUMINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin1 + "|" + varRatemax1 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax33);

            Report.Step("Step 6.1 : Search and select the Tiered Index <CUMINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 6.2 : Expected Result (TC24): Verify that the field, maxinum rate is updated with an index for a cumulative tiered index on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("10000;5;" + varRatemin33 +";" + varRatemax33,CUMINDX2,ApplicationDate);

            string varRatemin21 = CUMINDX1 +" +.2 D3";
	        string varRatemax21 = CUMINDX1 +" +.2 U3";

            Report.Step("Step 7.0 : Update balance tier1 Minimum and Maximum Rate with an valid value 'CUMINDX1 +.2 D3' and 'CUMINDX1 +.2 U3'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(CUMINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin21 + "|" + varRatemax21 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax33);

            Report.Step("Step 7.1 : Search and select the Tiered Index <CUMINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 7.2 : Expected Result (TC25): Verify that the fields, maximum and minimum rate are updated with indexes for a cumulative tiered index on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <INCINDX> | Rates | Edit).");
            Report.Step("Step 7.3 : Expected Result (TC32): Verify that the fields maximum and minimum rate are updated with variable rate having operand '+' and rounding option 'Down' (ex - INDEX1 +.1 D2) on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("0;1;" + varRatemin21 +";" + varRatemax21,CUMINDX2,ApplicationDate);
            
            string varRatemin31 = CUMINDX1 +" -.1 D2";

            Report.Step("Step 8.0 : Update balance tier1 Minimum Rate with an valid value 'INDEX1 -.1 D2'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(CUMINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin31 + "|" + varRatemax21 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax33);

            Report.Step("Step 8.1 : Search and select the Tiered Index <CUMINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 8.2 : Expected Result (TC34): Verify that the filed minimum rate is updated with variable rate having operand '-' (ex - INDEX1 -.1) on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("0;1;" + varRatemin31 +";" + varRatemax21,CUMINDX2,ApplicationDate);

            string varRatemax31 = CUMINDX1 +" -.1 U2";

            Report.Step("Step 9.0 : Update balance tier1 Maximum Rate with an valid value 'CUMINDX1 -.1 U2'");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(CUMINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin31 + "|" + varRatemax31 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin2 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax33);

            Report.Step("Step 9.1 : Search and select the Tiered Index <CUMINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 9.2 : Expected Result (TC35): Verify that the filed maximum rate is updated with variable rate having operand '-' (ex - INDEX1 -.1) on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("0;1;" + varRatemin31 +";" + varRatemax31,CUMINDX2,ApplicationDate);

            string varRatemin03 = CUMINDX1 +" -.2 D2";
	        string varRatemax03 = CUMINDX1 +" -.3 U2";

            Report.Step("Step 10.0 : Update balance tier2 Minimum and Maximum Rate with an valid value 'CUMINDX1 -.2 D2' and 'CUMINDX1 -.3 U2'.");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(CUMINDX2, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + varRatemin31 + "|" + varRatemax31 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + varRatemin03 + "|" + varRatemax2 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + varRatemin33 + "|" + varRatemax03);

            Report.Step("Step 10.1 : Search and select the Tiered Index <CUMINDX2>, Select the Rate added to Effective Date: System date and click Edit  (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 10.2 : Expected Result (TC36): Verify that the fileds maximum and minimum rate are updated with variable rate having operand '-' and rounding option 'Down' (ex - INDEX1 -.1 D2) on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <INTINDX> | Rates | Edit).");
            Application.WebAdmin.VerifyInterestIndexTableValues("5000;3;" + varRatemin03 +";" + varRatemax2,CUMINDX2,ApplicationDate);
            Application.WebAdmin.VerifyInterestIndexTableValues("10000;5;" + varRatemin33 +";" + varRatemax03,CUMINDX2,ApplicationDate);

            Report.Step("Step 11.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
            
        }
               
    }
}