/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0013_DP2:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0013_DP2()
        {

            string LNACCT = Data.Fetch("mINMAXRATESPERTIER0013", "LNACCT");
            string SAVACCT = Data.Fetch("mINMAXRATESPERTIER0013", "SAVACCT");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();

            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");

            Report.Step("Step 2.0: Expected Result (TC66): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the loan product, during interest accrual for the new loan account on the Accrual page in WebCSR (Account Summary | Interest | Balances).");
            Application.WebCSR.VerifyLoanInterestRate(LNACCT, "1.51857");
            
            Report.Step("Step 2.1: Search for the Installment Account <LNACCT> and navigate to the Interest | Balances sub-tab.");
            Application.WebCSR.LoadAccountSummaryPage(LNACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string LNACCINT = Application.WebCSR.CalculateLoanAccruedInterestByAccrMethod(accrMethod, "7000","1.51857",2,systemDate );

            Report.Step("Step 2.2: Verify the interest is accrued based on Interest Accrual Method 00 – Standard/Standard 30/360.");
            Application.WebCSR.VerifyAccruedInterest("Accrued Interest" +"|" + LNACCINT);

            Report.Step("Step 3.0:Search for the Savings account <SAVACCT> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string savACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_00"), "4000","1.02",2,systemDate );

            Report.Step("Step 3.1:Verify the interest is accrued based on Interest Accrual Method 00 – Standard/Standard 30/360.");
            Application.WebCSR.VerifyAccruedInterest("Accrued Interest"  + "|" + savACCINT);

            Report.Step("Step 3.2:Expected Result (TC63): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, during interest accrual for the new deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyDepositInterestRate(SAVACCT, "1.02000");

            Report.Step("Step 3.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 4.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 4.1: Post an loan payment to the installment loan account LNACCT for USD 3,000. Offset the transaction using transaction code CO (Cash Out).");
            Application.Teller.LoanPayment(LNACCT,"3000");
 
            Report.Step("Step 4.2: Post a Deposit to the Savings Account <SAVINTRAccNum> for account opening date of 4,000.00 using transaction code SAV(SD Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(SAVACCT, "2000");

            Report.Step("Step 4.3:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 4.1: Create datasheet to store the values.");
            Data.Store("LNACCINT", LNACCINT);
            Data.Store("savACCINT", savACCINT);
        }
    }
}