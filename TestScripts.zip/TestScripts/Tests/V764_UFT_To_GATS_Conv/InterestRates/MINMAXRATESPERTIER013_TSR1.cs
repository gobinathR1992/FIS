/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0013_TSR1:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0013_TSR1()
        {

            string INCINDX1 = Data.Fetch("mINMAXRATESPERTIER0013", "INCINDX1");
            string INCINDX2 = Data.Fetch("mINMAXRATESPERTIER0013", "INCINDX2");

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string SYSDATEPLUS1M = appHandle.CalculateNewDate(ApplicationDate, "M", 1);

            Report.Step("Step 2.0: Copy a new product <LNPROD1> using standard Installment Loan Product Type.");
            string LNPROD1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_CONSUMER_LOAN"), Data.Get("GLOBAL_STD_PROD_NUM_500"), true);

            Report.Step("Step 2.1: Get the copied Installment Loan product <LN_PRODUCT1>, Set Accrual Calc Method (LN.IACM)to :<11 - Actual/Actual (31/365,6)> and Minimum Balance to Accrue: 0.1.");
            Application.WebAdmin.updateLoanCalculationPageOption(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_CONSUMER_LOAN"), LNPROD1, appHandle.ReplaceString("Actual/Actual(31/365$6)","$",","),"" , "0.01","" , false );

            Report.Step("Step 2.2: Modify the copied product <LN_PRODUCT1> .Set Index:  INDEX_NAME :  INCINDX2,Change Frequency :  1DA,Interest Change Method:  Null (Interest Tab |Rate Determination page).");
            Application.WebAdmin.UpdateLoanInterestRateDeterminationPageOption(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_CONSUMER_LOAN"), LNPROD1, "", INCINDX2, "1DA", "Interest Spread|-0.01;Interest Rate Ceiling|;Interest Rate Floor|");

            Report.Step("Step 2.3: Modify the copied product <LN_PRODUCT1> .Set  Loan Payment Sweep Grid: Blank ,Automatic Loan Payment Method: Blank ,Automatic Loan Payment Retry Processing:  No ,Automatic Loan Payment Retry Days:  Blank(Product factory | Products |Payment Application Tab).");
            Application.WebAdmin.UpdateLoanCalculationOptionsPage(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_CONSUMER_LOAN"), LNPROD1, false, false, "", appHandle.ReplaceString("15 - Amortized$ Accrued Interest On-Line Bills OK","$",","), "Calculated at Payment", "1MAE");

            Report.Step("Step 3.0:Copy a standard Savings product.<SAVPROD1> with product type 400.WebADMIN|Product Factory|Products.");
            string SAVPROD1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_SAVINGSDEPOSIT_GROUP"),Data.Get("GLOBAL_STD_PROD_NUM_300"),true);

            Report.Step("Step 3.1: Navigate to Interest Accrual page and Enter Accrual Calculation Base:  1 – Ledger Balance & Accrual Calc Method:  Standard/Standard  (30/360) and click on submit button.");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_SAVINGSDEPOSIT_GROUP"),SAVPROD1, Data.Get("GLOBAL_ACCRUAL_BASE"),"Standard/Standard (30/360)",Data.Get("0.01"),"","");

            Report.Step("Step 3.2: Navigate to Posting Option and Enter Posting Option:  0 – Remain on Deposit, Posting Frequency:  1DA  and click on submit button.");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_SAVINGSDEPOSIT_GROUP"),SAVPROD1,Data.Get("GLOBAL_DISBURSEMENT_OPTION"),"8DA","",false,false);

            Report.Step("Step 3.3: Navigate to Rate Determination Page and set Index created (DEP.INDEX) to:<INCINDX2> and	Change Frequency (DEP.INTFRE)to :<1DA> and click on Submit button.");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_SAVINGSDEPOSIT_GROUP"),SAVPROD1,"",INCINDX2,Data.Get("GLOBAL_FREQUENCY_1DA"),"","","0.02");

            Report.Step("Step 4.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
            
            Report.Step("Step 4.1: Create datasheet to store the values.");
            Data.Store("LNPROD1", LNPROD1);
            Data.Store("SAVPROD1", SAVPROD1);

        }
               
    }
}