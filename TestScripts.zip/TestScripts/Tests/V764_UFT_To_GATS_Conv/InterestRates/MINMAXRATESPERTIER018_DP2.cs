/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER0018_DP2:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER0018_DP2()
        {

            string DDAACCT = Data.Fetch("mINMAXRATESPERTIER0018", "DDAACCT");
            string SAVACCT = Data.Fetch("mINMAXRATESPERTIER0018", "SAVACCT");

            Report.Step("Step 1.0: Login to the WEBCSR Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string systemDate = Application.WebCSR.GetApplicationDate();
            string SYSDATEM1D = appHandle.CalculateNewDate(systemDate, "D", -1);
            string SYSDATEM2D = appHandle.CalculateNewDate(systemDate, "D", -2);
            string SYSDATEM3D = appHandle.CalculateNewDate(systemDate, "D", -3);

            string ddaINTRATE = "5.00000";
            string ddaINTRATE1 = "2.00000";

            string savINTRATE = "2.05546";
            string savINTRATE1 = "2.73728";
            string savINTRATE2 = "2.01000";

            Report.Step("Step 2.0:Search for the DDA account <DDINTRAccNum> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(DDAACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");

            string ddaACCINT = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "11000",ddaINTRATE,3,systemDate,"",9, DDAACCT);
            string ddaACCINT1 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "2000",ddaINTRATE1,2,systemDate,"",9, DDAACCT);
            double ddaACCINT2 = 0;
            ddaACCINT2 = Convert.ToDouble(ddaACCINT) + Convert.ToDouble(ddaACCINT1);
            ddaACCINT2 = Math.Round(ddaACCINT2, 5);
            string ddaACCINT3 = ddaACCINT2.ToString();

            Report.Step("Step 2.1: Expected Result (TC81, 83): Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + ddaACCINT3);

            Report.Step("Step 2.2: Verify that the correct interest rate is picked from attached cumulative tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(DDAACCT, ddaINTRATE1);

            Report.Step("Step 3.0:Search for the Savings account <SAVACCT> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCT);
            Application.WebCSR.NavigatetoInterestAccrualPage();

            string savACCINT1 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "11000",savINTRATE,2,systemDate );
            string savACCINT2 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "11000",savINTRATE1,1,systemDate );
            string savACCINT3 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, "5500",savINTRATE2,2,systemDate );
            double savACCINT4 = 0;
            savACCINT4 = Convert.ToDouble(savACCINT1) + Convert.ToDouble(savACCINT2) + Convert.ToDouble(savACCINT3);
            savACCINT4 = Math.Round(savACCINT4, 5);
            string savACCINT = savACCINT4.ToString();

            Report.Step("Step 3.1: Expected Result (TC83, 87): Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Accrual page in WebCSR (Account Summary | Interest | Accrual).");
            Application.WebCSR.VerifyAccruedInterest(Data.Get("Accrued Interest: ") + "|" + savACCINT);

            Report.Step("Step 3.2: Verify that the correct interest rate is picked from attached incremental tiered index defaulted from the deposit product, for interest adjustments during effective dated transactions to an deposit account on the Rate Determination page in WebCSR (Account Summary | Interest | Rate Determination).");
            Application.WebCSR.VerifyDepositInterestRate(SAVACCT, "2.01000"); 

            Report.Step("Step 3.3: Logoff from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application (Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 4.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 4.2: Reverse the transaction 'DW' posted to the Deposit account DDAACCT of USD 9,000.");
            Application.Teller.ReverseTransactions(DDAACCT, "CI - Cash-In", SYSDATEM1D + "|DW|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat("9000") + "|" + SYSDATEM1D + "|USD|0", "9000", SYSDATEM2D, SYSDATEM1D);

            Report.Step("Step 4.2: Reverse the transaction 'Savings Deposit' posted to the Savings account SAVACCT of USD 5,500.");
            Application.Teller.ReverseTransactions(SAVACCT, "CI - Cash-In", SYSDATEM1D + "|SW|" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat("5500") + "|" + SYSDATEM1D + "|USD|0", "5500", SYSDATEM2D, SYSDATEM1D);

            Report.Step("Step 4.3:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));
 
        }
    }
}