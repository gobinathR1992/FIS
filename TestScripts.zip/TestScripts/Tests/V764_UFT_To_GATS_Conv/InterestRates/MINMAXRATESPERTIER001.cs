/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER001:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER001()
        {
            string invalidMAXRATEMSG = "Invalid Maximum Rate: Invalid index name or rate";
            string invalidMINRATEMSG = "Invalid Minimum Rate: Invalid index name or rate";
            string invalidINTRATEMSG = "Invalid Interest Rate: Invalid index name or rate";

            string invalidRate = "*.ab";
	        string invalidRate1 = "o.&^";
	        string invalidRate2 = "(ab)";

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string SYSDATEPLUS1M = appHandle.CalculateNewDate(ApplicationDate, "M", 1);

            Report.Step("Step 2.0: In WebAdmin, create a New Index CUMINDX1 of type: 1 - Tiered Index, Tiered Index Type: C - Cumulative. (Table Configuration | Interest Indexes | Add).");
            string CUMINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("C - Cumulative"));
                        
            Report.Step("Step 3.0 : Search and select the Tiered Index<CUMINDX1>, Click on Rates button and Add rates with Effective Date: System Date, Balance Tier1 values as Balance Tier: 0, Nominal Rate or Index: 1, Minimum Rate: 1.2 and Maximum Rate an invalid value 'ab&*' (Table Configuration | Interest Indexes | Rates button).");
            Report.Step("Step 4.0 : Expected Result (TC01): Verify that the message 'Invalid Maximum Rate: Invalid index name or rate' displayed when an invalid rate value is entered in maximum rate field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + invalidRate , invalidMAXRATEMSG);

            Report.Step("Step 5.0 : Search and select the Tiered Index<CUMINDX1>, Add a valid Maximum Rate in Tier1, enter Balance Tier2 values as Balance Tier: 5000, Nominal Rate or Index: 3, Minimum Rate: 2.80 and Maximum Rate an invalid value 'ab&*'.");
            Report.Step("Step 6.0 : Expected Result (TC01): Verify that the message 'Invalid Maximum Rate: Invalid index name or rate' displayed when an invalid rate value is entered in maximum rate field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + invalidRate , invalidMAXRATEMSG);

            Report.Step("Step 7.0 : Search and select the Tiered Index<CUMINDX1>, Add a valid Maximum Rate in Tier2, enter Balance Tier3 values as Balance Tier: 10000, Nominal Rate or Index: 3, Minimum Rate: 2.80 and Maximum Rate an invalid value 'ab&*'.");
            Report.Step("Step 8.0 : Expected Result (TC01): Verify that the message 'Invalid Maximum Rate: Invalid index name or rate' displayed when an invalid rate value is entered in maximum rate field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.85" + "|" + invalidRate , invalidMAXRATEMSG);

            Report.Step("Step 8.0 : Search and select the Tiered Index<CUMINDX1>, Click on Rates button and Enter a valid Maximum Rate in Tier3, followed by an invalid Minimum Rate: '*.ab' in Tier1.");
            Report.Step("Step 9.0 : Expected Result (TC03): Verify that the message 'Invalid Minimum Rate: Invalid index name or rate' displayed when an invalid rate value is entered in minimum rate field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + invalidRate + "|" +  "1.10", invalidMINRATEMSG);

            Report.Step("Step 10.0 : Search and select the Tiered Index<CUMINDX1>, Enter a valid Minimum Rate in Tier1, followed by an invalid Minimum Rate: '*.ab' in Tier2.");
            Report.Step("Step 11.0 : Expected Result (TC03): Verify that the message 'Invalid Minimum Rate: Invalid index name or rate' displayed when an invalid rate value is entered in minimum rate field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + invalidRate + "|" + "3.15" , invalidMINRATEMSG);

            Report.Step("Step 12.0 : Search and select the Tiered Index<CUMINDX1>, Enter a valid Minimum Rate in Tier2, followed by an invalid Minimum Rate: '*.ab' in Tier3.");
            Report.Step("Step 13.0 : Expected Result (TC03): Verify that the message 'Invalid Minimum Rate: Invalid index name or rate' displayed when an invalid rate value is entered in minimum rate field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + invalidRate + "|" + "5.05" , invalidMINRATEMSG);

            Report.Step("Step 14.0 : Search and select the Tiered Index<CUMINDX1>, Click on Rates button and Enter a valid Minimum Rate in Tier3, followed by an invalid Nominal Rate or Index: '*.ab' in Tier1.");
            Report.Step("Step 15.0 : Expected Result (TC05): Verify that the message 'Invalid Interest Rate: Invalid index name or rate' displayed when an invalid rate value is entered in Nominal Rate or Index field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + invalidRate + "|" + "" + "|" + "0.97" + "|" +  "1.10", invalidINTRATEMSG);

            Report.Step("Step 16.0 : Search and select the Tiered Index<CUMINDX1>, Enter a valid Nominal Rate or Index Rate in Tier1, followed by an invalid Nominal Rate or Index: '*.ab' in Tier2.");
            Report.Step("Step 17.0 : Expected Result (TC05): Verify that the message 'Invalid Interest Rate: Invalid index name or rate' displayed when an invalid rate value is entered in Nominal Rate or Index field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + invalidRate + "|" + "" + "|" + "2.80" + "|" + "3.15" , invalidINTRATEMSG);

            Report.Step("Step 18.0 : Search and select the Tiered Index<CUMINDX1>, Enter a valid Nominal Rate or Index Rate in Tier2, followed by an invalid Nominal Rate or Index: '*.ab' in Tier3.");
            Report.Step("Step 19.0 : Expected Result (TC05): Verify that the message 'Invalid Interest Rate: Invalid index name or rate' displayed when an invalid rate value is entered in Nominal Rate or Index field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + invalidRate + "|" + "" + "|" + "4.85" + "|" + "5.05" , invalidINTRATEMSG);

            Report.Step("Step 20.0 : Search and select the Tiered Index<CUMINDX1>, Click on Rates button and Enter a valid Nominal Rate or Index Rate in Tier3, followed by an invalid Nominal Rate or Index: '*.ab' in Tier1 and an invalid Minimum Rate: o.&^ in Tier2.");
            Report.Step("Step 21.0 : Expected Result (TC05): Verify that the message 'Invalid Interest Rate: Invalid index name or rate' displayed when an invalid rate value is entered in Nominal Rate or Index field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + invalidRate + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + invalidRate1 + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.85" + "|" + "5.05" , invalidINTRATEMSG);

            Report.Step("Step 22.0 : Search and select the Tiered Index<CUMINDX1>, Enter a valid Nominal Rate or Index Rate in Tier1 and valid Minimum Rate in Tier2, followed by an invalid Nominal Rate or Index: '*.ab' in Tier2 and an invalid Maximum Rate: o.&^ in Tier3.");
            Report.Step("Step 23.0 : Expected Result (TC01): Verify that the message 'Invalid Maximum Rate: Invalid index name or rate' displayed when an invalid rate value is entered in maximum rate field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + invalidRate1 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + invalidRate + "|" + "" + "|" + "4.85" + "|" + "5.05" , invalidMAXRATEMSG);

            Report.Step("Step 24.0 : Search and select the Tiered Index<CUMINDX1>, Enter a valid Nominal Rate or Index Rate in Tier2 and valid Maximum Rate in Tier3, followed by an invalid Minimum Rate: *.ab in Tier2 and an invalid Maximum Rate: o.&^ in Tier3.");
            Report.Step("Step 25.0 : Expected Result (TC03): Verify that the message 'Invalid Minimum Rate: Invalid index name or rate' displayed when an invalid rate value is entered in minimum rate field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + invalidRate + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.85" + "|" + invalidRate1 , invalidMINRATEMSG);
            
            Report.Step("Step 26.0 : Enter a valid Minimum Rate in Tier2 and valid Maximum Rate in Tier3, followed by an invalid Nominal Rate or index Rate: (ab) in Tier1, an invalid Maximum Rate: *.ab in Tier2 and an invalid Minimum Rate: o.&^ in Tier3.");
            Report.Step("Step 27.0 : Expected Result (TC05): Verify that the message 'Invalid Interest Rate: Invalid index name or rate' displayed when an invalid rate value is entered in Nominal Rate or Index field for each tier, while adding rates to a cumulative tiered index on the Add Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Add).");
            Application.WebAdmin.RatesOfTiredInterestIndexErrorMessage(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + invalidRate2 + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + invalidRate1 +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + invalidRate + "|" + "5.05" , invalidINTRATEMSG);

            Report.Step("Step 28.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
            
        }
               
    }
}