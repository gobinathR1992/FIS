/*
Objective: UFT to GATS conversion (V764 PDOC-15595)
Author: Jagadeesh Vajravelu
Creation Date: 08/17/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestRates
{
    [TestFixture]
    public class MINMAXRATESPERTIER005:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "PDOC-15595 Minimum and maximum rates per tier")]
        public void mINMAXRATESPERTIER005()
        {

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string SYSDATEPLUS1M = appHandle.CalculateNewDate(ApplicationDate, "M", 1);

            Report.Step("Step 2.0: In WebAdmin, create a New Index CUMINDX1 of type: 1 - Tiered Index, Tiered Index Type: C - Cumulative. (Table Configuration | Interest Indexes | Add).");
            string CUMINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("C - Cumulative"));
            
            Report.Step("Step 2.1: In WebAdmin, search for the Tiered index <CUMINDX1> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 1.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),CUMINDX1,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.85" + "|" + "5.05", false, "", false);

            Report.Step("Step 3.0: In WebAdmin, create a New Index INCINDX1 of type: 1 - Tiered Index, Tiered Index Type: I - Incremental. (Table Configuration | Interest Indexes | Add).");
            string INCINDX1 = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("1 - Tiered Index"), "", "", Data.Get("Tiered Index Type") + "|" + Data.Get("I - Incremental"));
            
            Report.Step("Step 3.1: In WebAdmin, search for the Tiered index <INCINDX1> and rates for Tier1: Balance Tier:0, Nominal Rate or Index: 1, Minimum Rate: 0.97, Maximum Rate: 1.10, Tier2: Balance Tier:5000, Nominal Rate or Index: 3, Minimum Rate: 2.80, Maximum Rate: 3.15 and Tier3: Balance Tier:10,000, Nominal Rate or Index: 5, Minimum Rate: 4.85, Maximum Rate: 5.05. (Table Configuration | Interest Indexes | Add).");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"),INCINDX1,ApplicationDate,"","","",Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.97" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.15" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.85" + "|" + "5.05", false, "", false);

            Report.Step("Step 4.0 : Search and select the Tiered Index <CUMINDX1>, Select the Rate added to Effective Date: System date and click Edit, Update balance tier1 Minimum Rate with an valid value '0.84' (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 4.1 : Expected Result (TC15): Verify that the field, minimum rate is updated with fixed rate for an cumulative tiered index on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Edit).");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.84" + "|" + "1.10");

            Report.Step("Step 5.0 : Search and select the Tiered Index <CUMINDX1>, Select the Rate added to Effective Date: System date and click Edit, Update balance tier2 Maximum Rate with an valid value '3.19' (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 5.1 : Expected Result (TC17): TC17: Verify that the field, maximum rate is updated with a fixed rate for an cumulative tiered index on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Edit).");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.84" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.19" );

            Report.Step("Step 6.0 : Search and select the Tiered Index <CUMINDX1>, Select the Rate added to Effective Date: System date and click Edit, Update balance tier3 Minimum and Maximum Rate with an valid value '4.88' and '5.11' (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 6.1 : Expected Result (TC19): Verify that the fields, maximum and minimum rates are updated  with fixed rate for an cumulative tiered index on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Edit).");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(CUMINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.84" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.19"  +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.88" + "|" + "5.11");

            Report.Step("Step 7.0 : Search and select the Tiered Index <INCINDX1>, Select the Rate added to Effective Date: System date and click Edit, Update balance tier1 Minimum Rate with an valid value '0.84' (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 7.1 : Expected Result (TC16): Verify that the field, minimum rate is updated with fixed rate for an Incremental tiered index on the Edit Tiered Index Rate page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Edit).");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(INCINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.84" + "|" + "1.10");

            Report.Step("Step 8.0 : Search and select the Tiered Index <INCINDX1>, Select the Rate added to Effective Date: System date and click Edit, Update balance tier2 Maximum Rate with an valid value '3.19' (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 8.1 : Expected Result (TC18): Verify that the field, maximum rate is updated with a fixed rate for an Incremental tiered index on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Edit).");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(INCINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.84" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.19" );

            Report.Step("Step 9.0 : Search and select the Tiered Index <INCINDX1>, Select the Rate added to Effective Date: System date and click Edit, Update balance tier3 Minimum and Maximum Rate with an valid value '4.88' and '5.11' (Table Configuration | Interest Indexes | Rates | Edit).");
            Report.Step("Step 9.1 : Expected Result (TC20): Verify that the fields, maximum and minimum rates are updated  with fixed rate for an Incremental tiered index on the Edit Tiered Index Rate  page in WebAdmin (Table Configuration | Interest Indexes | <CUMINDX> | Rates | Edit).");
            Application.WebAdmin.EditRatesOfTiredInterestIndex(INCINDX1, ApplicationDate, Data.Get("GLOBAL_VALUE_ZERO") + "|" + Data.Get("GLOBAL_VALUE_1") + "|" + "" + "|" + "0.84" + "|" + "1.10" +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_5K") + "|" + Data.Get("GLOBAL_VALUE_3") + "|" + "" + "|" + "2.80" + "|" + "3.19"  +";"+ Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K") + "|" + Data.Get("GLOBAL_VALUE_5") + "|" + "" + "|" + "4.88" + "|" + "5.11");
            
            Report.Step("Step 10.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
            
        }
               
    }
}