using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using NUnit.Framework;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.ProductMaintenance
{
    [TestFixture]
    public class productMaintenance010:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify existing product type that belongs to deposit, Loan and which has active accounts cannot be deleted.")]
        public void ProductMaintenance010()
        {
            Report.Step(" Step 1 : Login WEBADMIN  APPLICATION");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step(" Step 2 : Copy a standard Demand Deposit product type <DDAPROD> (Product Factory | Products | Copy Product");
            string setup_DDA = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),Data.Get("GLOBAL_STD_PROD_NUM_400"),true);

            Report.Step(" Step 3 : Copy a standard Demand Deposit product type <DDAPROD> (Product Factory | Products | Copy Product");
            string setup_LN = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"),Data.Get("GLOBAL_CONSUMER_LOAN"),Data.Get("GLOBAL_STD_PROD_NUM_500"),true);

            Report.Step(" Step 4 : Logging off from the application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
           Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            Data.Store("setup_DDA", setup_DDA);
            Data.Store("setup_LN", setup_LN);
        }
    }
} 