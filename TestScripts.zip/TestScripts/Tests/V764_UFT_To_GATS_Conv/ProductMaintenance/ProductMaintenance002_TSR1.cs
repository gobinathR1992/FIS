using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.ProductMaintenance
{
    [TestFixture]
    public class productMaintenance002_TSR1 : TestBase
    {
        [Test]
        [Property("TestDescription", "  Loan Specific ")]
        [Property(TestType.TestBased, "")]
        public void ProductMaintenance002_TSR1()
        {
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            //OBJECTIVE		:  Loan Specific :Verify a Error message "Product type ~p1 not available prior to ~p2" is returned in Account Information General page of Profile WebCSR, when a change is made in Product Type for the account created, with a product type having start date greater than the account creation date.
            Report.Step(" Step 1.0: Open WEB CSR Application");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step(" Step 2.0 Fetch the Accountnumber and Copy Product from CSV");
            string accountnumber = Data.Fetch("ProductMaintenance002", "LNACCT");
            string Product = Data.Fetch("ProductMaintenance002", "CopyProduct");
            string SYSTEMDATEMAX15D = Data.Fetch("ProductMaintenance002", "SYSTEMDATEMAX15D");

            Report.Step(" Step 3.0 Update the CopyProductType for the Account");
            Application.WebCSR.ChangeProducTypeForAccount(accountnumber, Product);

            Report.Step(" Step 4.0 Validate Error message");
            Application.WebCSR.ValidateErrorMessagebleForProductType("Product type " + Product + " not available prior to " + SYSTEMDATEMAX15D);

            Report.Step(" Step 5.0 Logoff WebCSR");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}