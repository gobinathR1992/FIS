using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.ProductMaintenance
{
    [TestFixture]
    public class productmaintenance002 : TestBase
    {
        [Test]
        [Property("TestDescription", "  Loan Specific ")]
        [Property(TestType.TestBased, "")]
        public void ProductMaintenance002()
        {
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            //OBJECTIVE		:  Loan Specific :Verify a Error message "Product type ~p1 not available prior to ~p2" is returned in Account Information General page of Profile WebCSR, when a change is made in Product Type for the account created, with a product type having start date greater than the account creation date.
            Report.Step(" Step 1: Open WEB CSR Application");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string SYSTEMDATEMAX15D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 15);

            Report.Step(" Step 2: Create a Personal Customer CIF_NUMBER1.");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("  Step 3 Create a backdated T-1M LN account with payment frequency as 1MAE.");
            string LNACCT = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"));

            Report.Step(" Step 4 :Close WEB CSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step(" Step 5 :Open WEB ADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step(" Step 6 :Copy a standard Installment Loan Product Type.");
            string CopyProduct = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("L - Loan Accounts"), Data.Get("LN - Consumer Loans"), Data.Get("500"), true);

            Report.Step(" Step 7 :Edit the Copy Loan Product Type.");
            Application.WebAdmin.EditProductGeneralSection(Data.Get("L - Loan Accounts"), Data.Get("LN - Consumer Loans"), CopyProduct, SYSTEMDATEMAX15D);
            Data.Store("LNACCT", LNACCT);
            Data.Store("CopyProduct", CopyProduct);
            Data.Store("SYSTEMDATEMAX15D", SYSTEMDATEMAX15D);

            Report.Step(" Step 8 :Close  WEB ADMIN   Application and Reload WebCSR Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
        }
    }
}