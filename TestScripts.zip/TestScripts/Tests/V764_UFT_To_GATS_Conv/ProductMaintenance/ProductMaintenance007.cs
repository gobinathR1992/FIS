using System.Collections.Generic;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.ProductMaintenance
{
    [TestFixture]
    public class productmaintenance007 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify a New Demand Deposit Product type of deposit class can be created, modified and deleted.")]
        public void ProductMaintenance007()
        {

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));

            Report.Step("Step 2.0:In Profile WebAdmin Copy a product type from the standard Demand Deposit Product Type 400 Product Factory | Products - Product Class: D - Deposit Class; Product Group: GLOBAL_DEPOSIT_ACCT_CLASS. Verify a New Deposit class product type <DDAPRODNEWNUM> is created by copying from an existing product type of the same class.");
            string DDAPRODNEWNUM = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), Data.Get("GLOBAL_STD_PROD_NUM_400"), false);
 
            Report.Step(" Step 3.0:Copy another product type from the standard Demand Deposit Product Type 400 by giving an existing product type Ex:<DDAPRODNEWNUM> i.e product type which is copied in the above step.");
            Application.WebAdmin.VerifyProductExistsCopyProduct(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), Data.Get("GLOBAL_STD_PROD_NUM_400"), DDAPRODNEWNUM );
           
            Report.Step(" Step 4.0: Modify the copied Demand Deposit Product Type <DDAPRODNEWNUM>. Navigate to Statements page Statements Tab and Set - Suppress Balance Print Checkbox: Y.");
            Application.WebAdmin.UpdateStatementsSuppressBalancePrintOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPRODNEWNUM ,true);
            
            Report.Step(" Step 5.0: Modify the copied Demand Deposit Product Type <DDAPRODNEWNUM>. Navigate to Deposit Transaction Processing page Transaction Processing Tab and Set - Permit Payment Order: Y.");
            Application.WebAdmin.UpdateFundsTransferPermitPaymentOrderOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPRODNEWNUM,true);

            Report.Step(" Step 6.0: Delete the copied demand deposit product type <DDAPRODNEWNUM>.");
            Application.WebAdmin.DeleteProductFromProductsList(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPRODNEWNUM);

            Report.Step("Step 7.0: Logout from Profile WebAdmin Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("WebAdmin"));
        }
    }

}