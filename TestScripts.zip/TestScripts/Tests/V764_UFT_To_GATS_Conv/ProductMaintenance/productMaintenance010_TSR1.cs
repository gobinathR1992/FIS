using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.Util;
using NUnit.Framework;
using System.Collections.Generic;
using GTS_CORE.HelperLibs;


namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.ProductMaintenance
{
    [TestFixture]
    public class productMaintenance010_TSR1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify existing product type that belongs to deposit, Loan and which has active accounts cannot be deleted.")]
        public void ProductMaintenance010_TSR1()
        {
            string setup_DDA = Data.Fetch("ProductMaintenance010", "setup_DDA");
            string setup_LN = Data.Fetch("ProductMaintenance010", "setup_LN");


            Report.Step(" Step 1 : Login WEBCSR  APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step(" Step 2: Create a Personal Customer CIF_NUMBER1.");
            string CIF_NUMBER1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step(" Step 3: Create Demand Deposit account DDA_ACCT_PM010 for the Customer CIF_NUMBER1 using copied Demand Deposit Product Type < setup_DDA > with the details Opening Deposit: 5000.00 and Opening Date: System Date Currency Code:  United States Dollars Profile Direct Web CSR| Basic Services| Create Account.");
            string DDA_ACCT_PM010 = Application.WebCSR.Create_Account(CIF_NUMBER1, Data.Get("GLOBAL_RELATION_SINGLE"), setup_DDA);

            Report.Step(" Step 4: Create a Consumer Loan Account CON_ACCT_LNMA003 using the LN Product Type <setup_LN> and the Customer CIF_NUMBER1 with the details: Amount: 10K Term: 1Y Payment Frequency: 1MA Currency: USD and Disbursment Date: System date.");
            string CON_ACCT_LNMA003 = Application.WebCSR.Create_Account(CIF_NUMBER1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), setup_LN, "", 1, Data.Get("Account Name") + "|MTGACCNUM;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE"));

            Report.Step(" Step 5 : Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step(" Step 6 : Login WEBADMIN  APPLICATION");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step(" Step 7 : Delete the copied Deposit Product Type <setup_DDA>");
            Application.WebAdmin.DeleteProductFromProductsList(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), setup_DDA);

            Report.Step(" Step 7 :Verify the message Accounts exist with this product type. cannot delete is displayed for Deposit class product type setup_DDA");
            Application.WebAdmin.VerifyErrorMessageDeletingProductWithAccount();

            Report.Step(" Step 8 : Delete the copied Loan Product Type <setup_LN>");
            Application.WebAdmin.DeleteProductFromProductsList(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_CONSUMER_LOAN"), setup_LN);

            Report.Step(" Step 7 :Verify the message Accounts exist with this product type. cannot delete. is displayed for Deposit class product type setup_DDA");
            Application.WebAdmin.VerifyErrorMessageDeletingProductWithAccount();

            Report.Step(" Step 5 : Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
        }
    }
}