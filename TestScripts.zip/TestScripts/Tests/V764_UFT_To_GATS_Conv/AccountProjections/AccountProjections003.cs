using System;
using System.Collections.Generic;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.AccountProjections
{
    [TestFixture]
    public class Accountprojections003 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "DISB001 (R1, R2, R5, R6 and R29):  Verify General Loan Disbursement functionality. (LN)")]
        public void AccountProjections003()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
 
            Report.Step("Step 2.0: Create a new personal customer <CustNo> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CustNo = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create a Mortgage Loan using Standard Product Type (Customer| Service| Account| Add New Account).");
            string MTGACCNUM = Application.WebCSR.Create_Account(CustNo, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_700"), "", 1, Data.Get("Account Name") + "|MTGACCNUM;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE"));

            Report.Step("Step 4.0 :Get  the Mortgage Loan Account MTGACCNUM. Set the Interest Rate   (LN.IRN):  10");
            Application.WebCSR.UpdateInterestRatesInLoanRateDeterminationPage(MTGACCNUM, Data.Get("GLOBAL_INTEREST_RATE_10"));

            Report.Step("Step 5.0 : Set the Payment Term (LN.PTRM):  1Y");
            Application.WebCSR.UpdateLoanMaturityInLoanMaturityPayOffPage(MTGACCNUM, Data.Get("1Y"));

            Report.Step("Step 6.0: Create a Commercial Loan Account using standard Product Type (Customer| Service| Account| Add New Account).Set Frequency as 1MA(Day) .");
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string DayOfApplicationDate = appHandle.GetDateParameters(ApplicationDate)[1];
            string COMMACCNUM = Application.WebCSR.Create_Account(CustNo, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("Commercial Loan 800"), "", 1, Data.Get("Account Name") + "|COMMACCNUM;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K") + ";" + Data.Get("Term") + "|1Y;" + Data.Get("Payment Frequency") + "|1MA" + DayOfApplicationDate);

            Report.Step("Step 7.0: Get  the Commercial Loan Account COMMACCNUM. Set the Interest Rate   (LN.IRN):  10");
            Application.WebCSR.UpdateInterestRatesInLoanRateDeterminationPage(COMMACCNUM, Data.Get("GLOBAL_INTEREST_RATE_10"));

            Report.Step("Step 8.0 : Set the Payment Term (LN.PTRM):  1Y");
            Application.WebCSR.UpdateLoanMaturityInLoanMaturityPayOffPage(COMMACCNUM, Data.Get("1Y"));

            Report.Step("Step 9.0 : Set Payment Calculation Method (LN.PCM):  2N - Accrued Interest, Fixed Principal No On-Line B in Payment Calculation Tab");
            string CalcMethod = Data.Get("2N - Accrued Interest. Fixed Principal No On-Line B");
            Application.WebCSR.UpdateLoanPaymentCalculationMethod(COMMACCNUM, CalcMethod.Replace(".", ","));

            Report.Step("Step 10.0 : Click on Loan Account Services Projected Activity Link. Select Account as <COMMACCNUM> . Enter Projected Through Date as SYSTEMDATEPLUS1 .");
            string SYSTEMDATE = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEPLUS1Y = appHandle.CalculateNewDate(SYSTEMDATE, "Y", 1);
            Application.WebCSR.GenerateLoanAccountServicesProjectedActivityData(COMMACCNUM, SYSTEMDATEPLUS1Y);

            Report.Step("Step 11.0: Verify Projected Activity Details as - Beginning Date : SYSTEMDATE , Ending Date : SYSTEMDATEPLUS1 , Account Number : COMMACCNUM , Disbursement Date : SYSTEMDATE , Maturity Date : SYSTEMDATEPLUS1 , Interest Rate : 10 , Amount Requested : 1,000 , Account Term : 1Y .");
            Application.WebCSR.VerifyProjectedActivityDetailsByLabelnameLabelValue(Data.Get("Beginning Date") + "|" + SYSTEMDATE + ";" + Data.Get("Ending Date") + "|" + SYSTEMDATEPLUS1Y + ";" + Data.Get("Account Number") + "|" + COMMACCNUM + ";" + Data.Get("Disbursement Date") + "|" + SYSTEMDATE + ";" + Data.Get("Maturity Date") + "|" + SYSTEMDATEPLUS1Y + ";" + Data.Get("Interest Rate") + "|10" + ";" + Data.Get("Amount Requested") + "|1000" + ";" + Data.Get("Account Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y"));
            Application.WebCSR.VerifyBorrowerTotalInProjectedActivityDetails();

            Report.Step("Step 12.0: Verify Loan disbursement date,  amount, Payoff - Close Account , Amount in Projected activity table.");
            Application.WebCSR.VerifyProjectedActivityTableDetails(Data.Get("Payoff - Close Account") + ";" + SYSTEMDATEPLUS1Y + ";" + "1,000.00");
            Application.WebCSR.VerifyProjectedActivityTableDetails(Data.Get("Disbursement") + ";" + "1,000.00" + ";" + SYSTEMDATE);

            Report.Step(" Step 13.0 Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }

    }
}