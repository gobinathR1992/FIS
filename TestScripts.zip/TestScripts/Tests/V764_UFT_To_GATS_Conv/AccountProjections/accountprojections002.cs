using System;
using System.Collections.Generic;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.AccountProjections
{
    [TestFixture]
    public class accountprojections002 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "DISB001 (R1, R2, R5, R6 and R29):  Verify General Loan Disbursement functionality. (LN)")]
        public void AccountProjections002()
        {
                     Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0:Create interest index type for Basis index.");
            string Index = Application.WebAdmin.CreateTableConfigurationInterestIndex(Data.Get("0 - Basis Index"));

            Report.Step("Step 3.0:Add interest rates to Basis index newInd.");
            Application.WebAdmin.AddRatesToInterestIndex(Data.Get("0 - Basis Index"), Index, ApplicationDate, Data.Get("6"));

            Report.Step("Step 4.0 :Create New Rate Schedule.");
            string RateSchedule = Application.WebAdmin.CreateTableConfigurationRateSchedule(Data.Get("Months"), Data.Get("Round to nearest 1/2"), Data.Get("Select rate from term/balance tier"));

            Report.Step("Step 5.0: Add Rates to Rate Schedule.");
            Application.WebAdmin.AddRatesToRateSchedule(RateSchedule, Data.Get("GLOBAL_VALUE_12") + "|" + Data.Get("9") + ";" + Data.Get("24") + "|" + Data.Get("8") + ";" + Data.Get("36") + "|" + Data.Get("7.009") + ";" + Data.Get("48") + "|" + Data.Get("6.504") + ";" + Data.Get("60") + "|" + Data.Get("6"));

            Report.Step("Step 6.0: Copy a Mortgage Loan Product (System Manager| Product| Copy Product Definition).");
            string LoanProd = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_MORTGAGE_LOAN"), Data.Get("GLOBAL_STD_PROD_NUM_700"), true);

Report.Step("Step 3.0: Modify the Savings product type SAVPROD_STEP1 Get product SAVPROD_STEP1|Go to Deposit Interest Calculation Page on Interest Tab|Set Accrual Calculation Base (PRODDFTD.IRCB):  0 – No Accrual  and Accrual Calculation Method (PRODDTFD.IACM):  00 – Standard/Standard (30/360).");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_MORTGAGE_LOAN"), LoanProd, Data.Get("No Accrual"), Data.Get("Standard/Standard  (30/360)"));

            Report.Step("Step 7.0 : Reload the Tomcat Servers.");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 8.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 9.0:Navigate to Interest Tab , Select Rate Determination Link and select  Variable Rate Index:<Index> in Rate Determination Page and select Submit .");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"), Data.Get("GLOBAL_MORTGAGE_LOAN"), LoanProd, "", Index);

            Report.Step("Step 10.0 : Reload the Tomcat Servers.");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 11.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));



        }
    }
}