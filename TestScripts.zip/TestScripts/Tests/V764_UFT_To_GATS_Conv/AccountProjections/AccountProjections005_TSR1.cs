using System;
using System.Collections.Generic;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.AccountProjections
{
    [TestFixture]
    public class Accountprojections005_TSR1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify (R89, R91, R94 and R95)  Disbursement Schedule.")]
        public void AccountProjections005_TSR1()
        {
            string AccountNumber = Data.Fetch("AccountProjections005", "AccountNumber");
            string CustNo = Data.Fetch("AccountProjections005", "CustomerNumber");
            string ProductNumber = Data.Fetch("AccountProjections005", "ProductCode1");

            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN15D = appHandle.CalculateNewDate(ApplicationDate, "D", -15);
            string SYSTEMDATEPLUS10D = appHandle.CalculateNewDate(ApplicationDate, "D", 10);
            string SYSTEMDATEPLUS20D = appHandle.CalculateNewDate(ApplicationDate, "D", 20);
            string SYSTEMDATEPLUS1D = appHandle.CalculateNewDate(ApplicationDate, "D", 1);
            string SYSTEMDATEPLUS2D = appHandle.CalculateNewDate(ApplicationDate, "D", 2);
            string SYSTEMDATEPLUS1Y = appHandle.CalculateNewDate(ApplicationDate, "Y", 1);


            Report.Step("Step 3.0: Create a Demand Deposit Account using standard Product Type (Customer| Service| Account| Add New Account)");
            string MTGACCNUM = Application.WebCSR.Create_Account(CustNo, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), ProductNumber, "", 1, Data.Get("Account Name") + "|MTGACCNUM;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_20K") + ";" + Data.Get("Opening Date") + "|" + ApplicationDate + ";" + Data.Get("Term") + "|1Y" + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured"));

            Report.Step("Step 4.0: Navigate to Interest Tab | Rate Determination Page for the Mortgage Loan Account <MLACCNUM> and enter the Interest Rate (LN.IRN):  10.00.(Basic services | Customer search: Account number <MLACCNUM> | Account information | Interest Tab | Rate Determination Sub Tab)");
            Application.WebCSR.UpdateInterestRatesInLoanRateDeterminationPage(MTGACCNUM, Data.Get("GLOBAL_INTEREST_RATE_10"));

            Report.Step("Step 5.0: Modify account MTGACCNUM details, Get Account MTGACCNUM|Go to Maturity Payoff Page on Maturity/PayoffTab| Set Maturity Payoff Tab - Payment Term (LN.PTRM):  1Y.");
            Application.WebCSR.UpdatePayoffDetailsInLoanMaturityPayOffPage(MTGACCNUM, "", Data.Get("GLOBAL_ACCOUNT_TERM_1Y"));

            Report.Step("Step 6.0: Navigate to Transaction Processing Tab | Disbursement Schedule for the Mortgage Loan Account <MLACCNUM> and add,edit three disbursement schedule for DDA Account number <DDAC_CNUM>");
            Application.WebCSR.UpdateTransactionProcessingDisbursementSchedule(MTGACCNUM, AccountNumber, Data.Get("GLOBAL_VALUE_3"), true);
            Application.WebCSR.AddDisbursementSchedule(MTGACCNUM, SYSTEMDATEPLUS10D, Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"), Data.Get("Second Disbursment"), true);
            Application.WebCSR.AddDisbursementSchedule(MTGACCNUM, SYSTEMDATEPLUS20D, Data.Get("GLOBAL_AMOUNT_DEPOSITED_8K"), Data.Get("Third Disbursment"), true);

            Report.Step("Step 7.0: Set the Generate Projected Report flag and Number of days to project  in Payment Application Tab");
            Application.WebCSR.UpdatePreAuthorizedPaymentAllowedInLoanPaymentPaymentApplicationPage(MTGACCNUM, true, Data.Get("GLOBAL_VALUE_365"));

            Report.Step("Step 8.0: Access Existing Loan Projection Utility. Loan Account:  Mortgage Loan Account created ");
            Application.WebCSR.GenerateLoanAccountServicesProjectedActivityData(MTGACCNUM, SYSTEMDATEPLUS1Y);

            Report.Step("Step 9.0: Verify Account number is displayed in Projected Activity (Loan Account Services |  Projected Activity)");
            Application.WebCSR.VerifyProjectedActivityDetailsByLabelnameLabelValue(Data.Get("Account Number") + "|" + MTGACCNUM);

            Report.Step("Step 10.0: Verify Report displays three Disbursements. (Loan Account Services |  Projected Activity)");
            Application.WebCSR.VerifyProjectedActivityTableDetails(SYSTEMDATEPLUS10D + ";" + Data.Get("Disbursement") + ";" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_1K")));
            Application.WebCSR.VerifyProjectedActivityTableDetails(SYSTEMDATEPLUS20D + ";" + Data.Get("Disbursement") + ";" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_DEPOSITED_8K")));

        }

    }
}