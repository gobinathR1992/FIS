using System;
using System.Collections.Generic;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.AccountProjections
{
    [TestFixture]
    public class Accountprojections005 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify (R89, R91, R94 and R95)  Disbursement Schedule.")]
        public void AccountProjections005()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0: Create a new personal customer <CustNo> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CustNo = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create a Demand Deposit Account using standard Product Type (Customer| Service| Account| Add New Account)");
            string MTGACCNUM = Application.WebCSR.Create_Account(CustNo, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_400"), "", 1, Data.Get("Account Name") + "|MTGACCNUM;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_20K") + ";" + Data.Get("Opening Date") + "|" + ApplicationDate);

            Report.Step("Step 4.0: Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Login to WEBADMIN  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 6.0: Copy a Mortgage Loan Product  <MLPROD> with product type< 700 - Fixed CD Account>. (Profile Direct Web Admin| Product Factory| Products)");
            string CopyProduct = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("L - Loan Accounts"), Data.Get("GLOBAL_MORTGAGE_LOAN"), Data.Get("GLOBAL_STD_PROD_NUM_700"), true);

            Report.Step("Step 7.0: Search for the Mortgage Loan product < MLPROD > and navigate to Transaction ProcessingTab to set  Disbursement Schedule Processing (PRODDFTL.DSCHPR):  Y.");
            Application.WebAdmin.UpdateMortgageDisbursementProcessing(Data.Get("L - Loan Accounts"), Data.Get("GLOBAL_MORTGAGE_LOAN"), CopyProduct, "3", "Automatic Disbursement Plan", "Automatic Disbursement to Check", "Automatic Loan Disbursement Checks", true);

            Report.Step("Step 8.0 Logging off from the application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Data.Store("ProductCode1", CopyProduct);
            Data.Store("CustomerNumber", CustNo);
            Data.Store("AccountNumber", MTGACCNUM);

            Report.Step("Step 9.0: Reload the Tomcat Servers.");
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }

    }
}