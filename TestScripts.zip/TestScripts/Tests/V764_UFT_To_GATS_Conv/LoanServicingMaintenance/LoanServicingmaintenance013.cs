using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.LoanServicingMaintenance
{
    [TestFixture]
    public class LoanServicingmaintenance013 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property("TestDescription", "Verify the Loan Closeout Condition Report can be generated.")]
        [Property(TestType.TestBased, "")]
        public void LoanServicingMaintenance013()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMINUS31D = appHandle.CalculateNewDate(ApplicationDate, "D", -31);
            string DayOfApplicationDate = appHandle.GetDateParameters(SYSTEMDATEMINUS31D)[1];

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create a back dated Credit Balance Loan Account <LNACCT1> for the Personal Customer <CIF1> using the standard product type 900 (Opening Date. <System Date-31>; Disbursement Amount. <10,000.00>; Term. <1 Year>; Frequency = <1MADate> and Currency Code. <USD>) (WebCSR | Basic Services | Create Account).");
            string LNACCT1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("Credit Balance Loan 900"), "", 1, Data.Get("Account Name") + "|" + "LNACCT1;" + Data.Get("Disbursement Date") + "|" + SYSTEMDATEMINUS31D + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|32D;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MA") + DayOfApplicationDate);

            Report.Step("Step 4.0: Create a back dated Consumer Loan Account <LNACCT2> for the Personal Customer <CIF1> using the standard product type 500 (Opening Date. <System Date-31>; Disbursement Amount. <10,000.00>; Term. <1 Year>; Frequency = <1MADate> and Currency Code. <USD>) (WebCSR | Basic Services | Create Account).");
            string LNACCT2 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"), "", 1, Data.Get("Account Name") + "|" + "LNACCT2;" + Data.Get("Disbursement Date") + "|" + SYSTEMDATEMINUS31D + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|32D;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MA") + DayOfApplicationDate);

            Report.Step("Step 4.0: Create a back dated Mortgage Loan Account <LNACCT3> for the Personal Customer <CIF1> using the standard product type 700 (Opening Date. <System Date-31>; Disbursement Amount. <10,000.00>; Term. <1 Year>; Frequency = <1MADate> and Currency Code. <USD>) (WebCSR | Basic Services | Create Account).");
            string LNACCT3 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_700"), "", 1, Data.Get("Account Name") + "|" + "LNACCT3;" + Data.Get("Disbursement Date") + "|" + SYSTEMDATEMINUS31D + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|32D;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MA") + DayOfApplicationDate);

            Report.Step("Step 5.0 : Load LNACCT1 .Navigate to Account Summary | Payments | Payment Application . Select 'Pre-Authorized Transfer Allowed' checkbox. Click on Submit button. Verify the message : The information has been updated.");
            Application.WebCSR.UpdatePreAuthorizedPaymentAllowedInLoanPaymentPaymentApplicationPage(LNACCT1, true);

            Report.Step("Step 6.0: Load LNACCT2 .Navigate to Account Summary | Payments | Payment Application . Select 'Pre-Authorized Transfer Allowed' checkbox. Click on Submit button. Verify the message : The information has been updated.");
            Application.WebCSR.UpdatePreAuthorizedPaymentAllowedInLoanPaymentPaymentApplicationPage(LNACCT2, true);

            Report.Step("Step 7.0: Load LNACCT3 .Navigate to Account Summary | Payments | Payment Application . Select 'Pre-Authorized Transfer Allowed' checkbox. Click on Submit button. Verify the message : The information has been updated.");
            Application.WebCSR.UpdatePreAuthorizedPaymentAllowedInLoanPaymentPaymentApplicationPage(LNACCT3, true);

            Report.Step("Step 8.0 : Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 10.0: Post a disbursement transaction to the Credit Balance Loan Account created abvove with amount 10000.");
            Application.Teller.LoanDisbursementAdvancedTransactions(LNACCT1, Data.Get("CBD"), Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"), SYSTEMDATEMINUS31D);

            Report.Step("Step 11.0: Post a Loan Pay off for the Credit Balance Loan Account with pay off amount.");
            Application.Teller.LoanPayOffAdvancedTransactions(LNACCT1, Data.Get("CBPO"));

            Report.Step("Step 12.0: Post a disbursement transaction to the Consumer Loan Account created abvove with amount 10000.");
            Application.Teller.LoanDisbursementAdvancedTransactions(LNACCT2, Data.Get("LD"), Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"), SYSTEMDATEMINUS31D);

            Report.Step("Step 13.0: Post a Loan Pay off for the  Consumer Loan Account with pay off amount");
            Application.Teller.LoanPayOffAdvancedTransactions(LNACCT2, Data.Get("LPO"));

            Report.Step("Step 14.0: Post a disbursement transaction to the Mortgage Loan Account created abvove with amount 10000.");
            Application.Teller.LoanDisbursementAdvancedTransactions(LNACCT3, Data.Get("MD"), Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"), SYSTEMDATEMINUS31D);

            Report.Step("Step 15.0: Post a Loan Pay off for the  Mortgage Loan Account with pay off amount.");
            Application.Teller.LoanPayOffAdvancedTransactions(LNACCT3, Data.Get("MPO"));

            Report.Step("Step 16.0: Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 17.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));

            Report.Step("Step 18.0:Navigate to Profile Reports. Select REP411 . Verify the Loan Closeout Condition Report can be generated based on the criteria of Notification Code.Verify the Loan Closeout Condition Report can be generated based on the criteria of Loan Product Group.");
            Application.WebAdmin.VerifyProfileReports(Data.Get("REP411"), Data.Get("Loan Close-Out Condition Report  (SCA411)") + "|" + Data.Get("CBL    Credit Balance Loans") + "|" + Data.Get("CBL    PATUF - Preauthorized Transfer Use Flag                  Y    10") + "|" + Data.Get("MTG    PATUF - Preauthorized Transfer Use Flag                  Y    10") + "|" + Data.Get("MTG    Mortgage Loans") + "|" + Data.Get("LN     Consumer Loans") + "|" + Data.Get("LN     PATUF - Preauthorized Transfer Use Flag                  Y    10"));

            Report.Step("Step 9.0: Logout from WEBAdmin Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("WebAdmin"));
        }

    }
}