using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;



namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.LoanServicingMaintenance
{
    [TestFixture]
    public class LoanServicingmaintenance014 : TestBase
    {
        [Test]
        [Property("TestDescription", "Verify the Negative Loan Balance Report can be generated.")]
        [Property(TestType.TestBased, "")]
        public void LoanServicingMaintenance014()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 4.0: Create a Loan Account <LNACCNUM> for the Personal Customer <CIF1> using the standard product type 500 (Opening Date. <System Date>; Disbursement Amount. <10,000.00>; Term. <1 Year>; Frequency = <1MAE> and Currency Code. <USD>) (WebCSR | Basic Services | Create Account).");
            string LNACCNUM = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"), "", 1, Data.Get("Account Name") + "|LNACCNUM;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|1Y" + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE"));

            Report.Step("Step 5.0: Set the data item Negative Balance Option:LN.NBF to option 2 Allow Conditions without override under Transaction Processing in Account Summary.");
            Application.WebCSR.UpdateNegativeBalanceOptionLoanTransactionProcessingPage(LNACCNUM, Data.Get("2 - Allow Condition without Override"));

            Report.Step("Step 6.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 6.0: Post a disbursement transaction to the Consumer Loan Account created abvove with amount 10000.");
            Application.Teller.LoanDisbursement(LNACCNUM, Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K"));

            Report.Step("Step 7.0: Post a payment to the Consumer Loan Account with amount 11000.");
            Application.Teller.LoanPayment(LNACCNUM, Data.Get("11000"),"",true);

            Report.Step("Step 8.0:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 9.0 Store the data . Run One Day end to Execute ");
            Data.Store("LNACCNUM", LNACCNUM);
        }

    }
}