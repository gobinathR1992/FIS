using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;
using System;


namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.LoanServicingMaintenance
{
    [TestFixture]
    public class loanServicingMaintenance003 : TestBase
    {
        [Test]
        [Property("TestDescription", " Verify a user defines an existing loan account with a Next Scheduled Payment Date  in the past and selects the dayend process of Schedule Payment Date Roll.")]
        [Property(TestType.TestBased, "")]
        public void LoanServicingMaintenance003()
        {
            //OBJECTIVE : Verify a user defines an existing loan account with a Next Scheduled Payment Date  in the past and selects the dayend process of Schedule Payment Date Roll.

            Report.Step(" Step 1 : Login WEBCSR  APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            Report.Step(" Step 2: Create a Personal Customer CIF_NUMBER1.");
            string CIF_NUMBER1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step(" Step 3: Create a Consumer Loan Account CON_ACCT_LNMA003 using the LN Product Type CopyProductName and the Customer CIF_NUMBER1 with the details: Amount: 10K Term: 1Y Payment Frequency: 1MA Currency: USD and Disbursment Date: System date - 7 Days.");
            string CON_ACCT_LNMA003 = Application.WebCSR.Create_Account(CIF_NUMBER1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"));

            Report.Step(" Step 4: Validate Loan Correction Process for Account");
            Application.WebCSR.NextScheduledPaymentDate(CON_ACCT_LNMA003);

            Report.Step(" Step 5 : Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }
    }
}