using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.LoanServicingMaintenance
{
    [TestFixture]
    public class LoanServicingmaintenance014_DP1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property("TestDescription", "Verify the Negative Loan Balance Report can be generated.")]
        [Property(TestType.TestBased, "")]
        public void LoanServicingMaintenance014_DP1()
        {
            Report.Step("Step 1.0: Login to WebAdmin  Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            string AccountNumber = Data.Fetch("LoanServicingMaintenance014", "LNACCNUM");
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string AccountOpenDate = appHandle.CalculateNewDate(ApplicationDate, "D", -1);

            Report.Step("Step 2.0: Navigate to Profile Reports. Select REP246 . Enter Report Date : Application Date , Loan Group : ALL , Loan Type: ALL . Click on Run Button. Verify the Negative Loan Balance Report can be generated to display information about loans that have been overpaid based on the criteria of Report Date.");
            Application.WebAdmin.VerifyProfileReports(Data.Get("REP246"), AccountNumber + "|" + AccountOpenDate + "|-" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"), Data.Get("Report Date") + "|" + ApplicationDate + ";" + Data.Get("Loan Group") + "|" + Data.Get("ALL") + ";" + Data.Get("Loan Type") + "|" + Data.Get("ALL"));

            Report.Step("Step 3.0: Navigate to Profile Reports. Select REP246 . Enter Report Date : ALL , Loan Group : LN , Loan Type: All . Click on Run Button. Verify the Negative Loan Balance Report can be generated to display information about loans that have been overpaid based on the criteria of Loan Product Group.");
            Application.WebAdmin.VerifyProfileReports(Data.Get("REP246"), AccountNumber + "|" + AccountOpenDate + "|-" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"), Data.Get("Report Date") + "|" + Data.Get("ALL") + ";" + Data.Get("Loan Group") + "|" + Data.Get("LN") + ";" + Data.Get("Loan Type") + "|" + Data.Get("ALL"));

            Report.Step("Step 4.0: Navigate to Profile Reports. Select REP246 . Enter Report Date : ALL , Loan Group : All , Loan Type: Product type used to create account . Click on Run Button. Verify the Negative Loan Balance Report can be generated to display information about loans that have been overpaid based on the criteria of Loan Product Type");
            Application.WebAdmin.VerifyProfileReports(Data.Get("REP246"), AccountNumber + "|" + AccountOpenDate + "|-" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"), Data.Get("Report Date") + "|" + Data.Get("ALL") + ";" + Data.Get("Loan Group") + "|" + Data.Get("ALL") + ";" + Data.Get("Loan Type") + "|" + Data.Get("GLOBAL_STD_PROD_NUM_500"));

            Report.Step("Step 5.0: Navigate to Profile Reports. Select REP246 . Enter Report Date : Application Date , Loan Group : LN , Loan Type: ALL . Click on Run Button. Verify the Negative Loan Balance Report can be generated to display information about loans that have been overpaid based on the criteria of Report Date and Loan Product Group.");
            Application.WebAdmin.VerifyProfileReports(Data.Get("REP246"), AccountNumber + "|" + AccountOpenDate + "|-" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"), Data.Get("Report Date") + "|" + ApplicationDate + ";" + Data.Get("Loan Group") + "|" + Data.Get("LN") + ";" + Data.Get("Loan Type") + "|" + Data.Get("ALL"));

            Report.Step("Step 6.0: Navigate to Profile Reports. Select REP246 . Enter Report Date : Application Date , Loan Group : ALL , Loan Type: Product type used to create account . Click on Run Button. Verify the Negative Loan Balance Report can be generated to display information about loans that have been overpaid based on the criteria of Report Date and Loan Product Type.");
            Application.WebAdmin.VerifyProfileReports(Data.Get("REP246"), AccountNumber + "|" + AccountOpenDate + "|-" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"), Data.Get("Report Date") + "|" + ApplicationDate + ";" + Data.Get("Loan Group") + "|" + Data.Get("ALL") + ";" + Data.Get("Loan Type") + "|" + Data.Get("GLOBAL_STD_PROD_NUM_500"));

            Report.Step("Step 7.0: Navigate to Profile Reports. Select REP246 . Enter Report Date : ALL , Loan Group : LN , Loan Type: Product type used to create account . Click on Run Button. Verify the Negative Loan Balance Report can be generated to display information about loans that have been overpaid based on the criteria of Loan Product Group and Loan Product Type.");
            Application.WebAdmin.VerifyProfileReports(Data.Get("REP246"), AccountNumber + "|" + AccountOpenDate + "|-" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"), Data.Get("Report Date") + "|" + Data.Get("ALL") + ";" + Data.Get("Loan Group") + "|" + Data.Get("LN") + ";" + Data.Get("Loan Type") + "|" + Data.Get("GLOBAL_STD_PROD_NUM_500"));

            Report.Step("Step 8.0: Navigate to Profile Reports.Execute Mortgage Trial Balance Report by Currency Code (REP402). Enter Effective Date as : Application Date .Click On Run Button.Verify the Negative Balance Account Report can be generated to display information about negative deposit and loan balance accounts based on the criteria of Effective Date");
            Application.WebAdmin.VerifyProfileReports(Data.Get("REP402"), AccountNumber + "|" + AccountOpenDate + "|-" + Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Data.Get("GLOBAL_AMOUNT_REQUESTED_1K")), Data.Get("Effective Date") + "|" + ApplicationDate);

            Report.Step("Step 9.0: Logout from WEBAdmin Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("WebAdmin"));
        }

    }
}