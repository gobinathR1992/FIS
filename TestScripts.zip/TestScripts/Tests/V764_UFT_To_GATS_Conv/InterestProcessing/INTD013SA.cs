using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestProcessing
{
    [TestFixture]
    public class iNTD013SA:TestBase
    { 
        static WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "R280: Verify value set in backup w/h percentage field from institution variables is used, if withholding calculation method is not specified at the account level. \n Verify the backup withholding percentage entered in the institution variable is applied to all the deposit accounts having subject to withholding flag set as Y. \n R279: Verify that the withholding flag is set to N, the interest is not withheld (for tax purpose) when interest payments occurs. ")]
        public void INTD013SA()
        {
            Report.Step(" Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step(" Step 2.0:Copy a standard Demand Deposit product.<DDAPROD1> with product type 400.WebADMIN|Product Factory|Products.");
            string DDAPROD1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),Data.Get("GLOBAL_STD_PROD_NUM_400"),true);

            Report.Step(" Step 3.0: Navigate to Interest Accrual page and Enter Accrual Calculation Base:  1 – Ledger Balance & Accrual Calc Method:  11 – Actual / Actual (31/365, 6) and click on submit button.");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPROD1, Data.Get("GLOBAL_ACCRUAL_BASE"),appHandle.ReplaceString(Data.Get("Actual/Actual      (31/365$6)"),"$",","),"","","");

            Report.Step("Step 4.0: Navigate to Rate Determination Page and Enter Nominal Rate (PRODDFTD.IRN):  20.00 and click on submit button.");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPROD1,Data.Get("20.00"),Data.Get("GLOBAL_BLANK_OR_NULL"),Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 5.0: Navigate to Posting Option and Enter Posting Option:  0 – Remain on Deposit Posting Frequency:  2DA ,Enter Subject to Withholding:  Checked (Y) and click on submit button.");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPROD1,Data.Get("GLOBAL_DISBURSEMENT_OPTION"),Data.Get("2DA"),"",true,true);

            Report.Step(" Step 6.0:Copy a standard Demand Deposit product.<DDAPROD1> with product type 400.WebADMIN|Product Factory|Products.");
            string DDAPROD2 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),Data.Get("GLOBAL_STD_PROD_NUM_400"),true);

            Report.Step(" Step 7.0: Navigate to Interest Accrual page and Enter Accrual Calculation Base:  1 – Ledger Balance & Accrual Calc Method:  11 – Actual / Actual (31/365, 6) and click on submit button.");
            Application.WebAdmin.UpdateDepositInterestCalculationAccrualOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPROD2, Data.Get("GLOBAL_ACCRUAL_BASE"),appHandle.ReplaceString(Data.Get("Actual/Actual      (31/365$6)"),"$",","),"","","");

            Report.Step("Step 8.0: Navigate to Rate Determination Page and Enter Nominal Rate (PRODDFTD.IRN):  20.00 and click on submit button.");
            Application.WebAdmin.UpdateDepositInterestRateDeterminationPageOption(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPROD2,Data.Get("20.00"),Data.Get("GLOBAL_BLANK_OR_NULL"),Data.Get("GLOBAL_BLANK_OR_NULL"));

            Report.Step("Step 9.0: Navigate to Posting Option and Enter Posting Option:  0 – Remain on Deposit Posting Frequency:  2DA ,Enter Subject to Withholding:  Checked (Y) and click on submit button.");
            Application.WebAdmin.UpdateInterestPostingOptionPageDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"),Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPROD2,Data.Get("GLOBAL_DISBURSEMENT_OPTION"),Data.Get("2DA"),"",true);

            Report.Step("Step 19.0: Logout from WEBADMIN Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 11.0 Reload Tomcat Server. ");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Data.Store("DDAPROD1", DDAPROD1);
            Data.Store("DDAPROD2", DDAPROD2);


        }

               
    }
}