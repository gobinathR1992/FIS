using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestProcessing
{
    [TestFixture]
    public class iNTD013TSR1DP3SA:TestBase
    { 
        static WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "R280: Verify value set in backup w/h percentage field from institution variables is used, if withholding calculation method is not specified at the account level. \n Verify the backup withholding percentage entered in the institution variable is applied to all the deposit accounts having subject to withholding flag set as Y. \n R279: Verify that the withholding flag is set to N, the interest is not withheld (for tax purpose) when interest payments occurs.")]
        public void INTD013TSR1DP3SA()
        {
            string DDAPROD1 = Data.Fetch("INTD013SA", "DDAPROD1");
            string CIF1 = Data.Fetch("INTD013TSR1SA","CIF1");
            string DDAACCNUM1 = Data.Fetch("INTD013TSR1SA","DDAACCNUM1");
            
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR")); 
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            
            Report.Step("Step 2.0: Search for the Deposit account <DDAACCNUM1> and navigate to Interest Accrual Page.WebCSR|Customer Search|Account Summary|Interest.");
            Application.WebCSR.LoadAccountSummaryPage(DDAACCNUM1);
            string LedgerBalance = Application.WebCSR.GetCellValueByLabel("Ledger Balance:");
            Application.WebCSR.NavigatetoInterestAccrualPage(); 
            string accrMethod1 = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod1 = appHandle.ReplaceString(accrMethod1, "$", ",");
            string AccruedInterst = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod1,LedgerBalance,Data.Get("20.00"),1,ApplicationDate);
            Application.WebCSR.VerifyAccruedInterest("Accrued Interest|" + AccruedInterst);
            
            Report.Step("Step 3.0: Navigate to Payment page and Verify Year To Date");
            string YeartoDate = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod1,Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"),Data.Get("20.00"),2,ApplicationDate);
            double yeartoDate = Math.Round(Convert.ToDouble(YeartoDate),2);
            Application.WebCSR.VerifyPaymentPageFieldValue(DDAACCNUM1,"Year-to-Date|"+yeartoDate );

            Report.Step("Step 4.0: Navigate to Withholding page and Verify interest posting of USD 5.46 and withholding of System Currency .");
            double FederalWitholdingCurrentTaxYear = Convert.ToDouble(AccruedInterst)*33;
            FederalWitholdingCurrentTaxYear = FederalWitholdingCurrentTaxYear /100;
            double FederalWitholdingCurrentTaxYear1 = Math.Round(FederalWitholdingCurrentTaxYear*2,2);
            Application.WebCSR.VerifyWitholdingField(DDAACCNUM1,"Federal Withholding Current Tax Year|"+FederalWitholdingCurrentTaxYear1+";State Withholding Current Tax Year|0.00000"+";Accrued Withholding Tax Amount|"+FederalWitholdingCurrentTaxYear);

            Report.Step("Step 5.0: Expected Result: R280 - Verify value set in backup w/h percentage field from institution variables is used, if withholding calculation method is not specified at the account level. ");
            Report.Step("Step 6.0: Expected Result: R116 - Verify the backup withholding percentage entered in the institution variable is applied to all the deposit accounts having subject to withholding flag set as Y.");
            Application.WebCSR.UpdateWithholdingPageOptions(DDAACCNUM1,true,true);      

            Report.Step("Step 3.0: Create a Demand Deposit Account <DDAcc> | Amount Requested LN.AMTREQ:  USD 1000.00 | Opening Date: System Date with standard Copy Product Type DDAPRODNUM for the Customer <CIF1> Profile Direct Web CSR| Basic Services| Create Account .");
            string DDAACCNUM2 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), DDAPROD1, "", 1, Data.Get("Account Name") + "|DDAACCNUM1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") );

            Report.Step("Step 4.0: Navigate to Withholding page and Checked (Y)  &  Calculation Method:  US.");
            Application.WebCSR.UpdateWithholdingPageOptions(DDAACCNUM2,true,false,Data.Get("US - United States"));       

            Report.Step("Step 6.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 7.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step(" Step 12.0:Post a deposit transaction to the demand deposit account DDACT_INTD013_STEP3 for 5,000.00 using transaction code DD (DDA Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(DDAACCNUM2,Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"));

            Report.Step("Step 9.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");

            Data.Store("DDAACCNUM2",DDAACCNUM2);
                
        }

              
    }
}