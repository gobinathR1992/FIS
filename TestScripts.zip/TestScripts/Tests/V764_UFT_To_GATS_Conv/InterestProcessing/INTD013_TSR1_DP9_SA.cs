using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestProcessing
{
    [TestFixture]
    public class iNTD013_TSR1_DP9_SA:TestBase
    { 
        static WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "INTEREST WITHHOLDINGS ")]
        public void INTD013_TSR1_DP9_SA()
        {
            string DDAACCNUM3 = Data.Fetch("INTD013TSR1DP6SA","DDAACCNUM3");
            
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR")); 
            string ApplicationDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0: Expected Result (R279): Verify that the withholding flag is set to N, the interest is not withheld (for tax purpose) when interest payments occurs. ");
            Application.WebCSR.VerifyWitholdingField(DDAACCNUM3,"Federal Withholding Current Tax Year|"+0.00000+";State Withholding Current Tax Year|"+0.00000);

            Report.Step("Step 6.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            
        }
               
    }
}