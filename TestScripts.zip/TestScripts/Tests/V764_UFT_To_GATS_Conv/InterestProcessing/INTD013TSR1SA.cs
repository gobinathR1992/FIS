using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestProcessing
{
    [TestFixture]
    public class iNTD013TSR1SA:TestBase
    { 
        static WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "R280: Verify value set in backup w/h percentage field from institution variables is used, if withholding calculation method is not specified at the account level. \n Verify the backup withholding percentage entered in the institution variable is applied to all the deposit accounts having subject to withholding flag set as Y. \n R279: Verify that the withholding flag is set to N, the interest is not withheld (for tax purpose) when interest payments occurs.")]
        public void INTD013TSR1SA()
        {
            string DDAPROD1 = Data.Fetch("INTD013SA", "DDAPROD1");
            
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();
            
            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            
            Report.Step("Step 3.0: Create a Demand Deposit Account <DDAcc> | Amount Requested LN.AMTREQ:  USD 1000.00 | Opening Date: System Date with standard Copy Product Type DDAPRODNUM for the Customer <CIF1> Profile Direct Web CSR| Basic Services| Create Account .");
            string DDAACCNUM1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), DDAPROD1, "", 1, Data.Get("Account Name") + "|DDAACCNUM1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") );

            Report.Step("Step 4.0: Navigate to Withholding page and Verify the value in the withholding flag at account level defaults from the value set at product level in the subject to withholding flag. ");
            Application.WebCSR.UpdateWithholdingPageOptions(DDAACCNUM1,true,true);            

            Report.Step("Step 6.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 7.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step(" Step 12.0:Post a deposit transaction to the demand deposit account DDACT_INTD013_STEP3 for 5,000.00 using transaction code DD (DDA Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(DDAACCNUM1,Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"));

            Report.Step("Step 9.0: Logout to Profile Teller.");
            Application.Teller.logoff_specified_application("Teller");

            Data.Store("CIF1",CIF1);
            Data.Store("DDAACCNUM1",DDAACCNUM1);
            
            
        }
        
    }
}