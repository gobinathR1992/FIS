using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.InterestProcessing
{
    [TestFixture]
    public class iNTDSETUP:TestBase
    { 
        static WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "DEPOSIT INTEREST PROCESSING SETUP")]
        public void INTDSETUP()
        {
            Report.Step(" Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 2.0: Navigate to Institute Variable Deposit Account page and set Interest Posting Option :<Beginning-of-Day Queue Posting> and Account Selection for Backup Withholding:<Default based on product values>");
            Application.WebAdmin.EnterInstititionVariableOption("Interest Posting Option:|Beginning-of-Day Queue Posting;Account Selection for Backup Withholding:|Default based on product values");                        

            Report.Step("Step 3.0: Logout from WEBADMIN Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 11.0 Reload Tomcat Server. ");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            
        }
      
    }
}