/*
Objective: UFT to GATS conversion (DepositFees_BLSETUP)
Author: 
Creation Date: 
Modified By: Jagadeesh Vajravelu
Modified Date:  09/27/2021
Modification Reason 1: Added required setpup only for DepositFess002 script, existing script had only CreateServiceFeeSchedule step. 
*/

using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositFee
{
    [TestFixture]
    public class DepositFeesTDsetUP:TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Test Data Setup for Deposit Fee test scripts.")]
        public void DepositFeesTDSetUP()
        {
            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("WebAdmin"));
            
            Report.Step("Step 2.0: Navigate to Table Configuration | General Table Management . Search and select UTBLFEESCH table  in General table management search page.Click Submit button.Create a new Service Fee Schedule.");
            string TiredValuesPipeDelimited="0|50|10;10000|100|15;100000|150|20;10000000|200|25";
            string SERVICE_FEE_SCHED1=Application.WebAdmin.CreateServiceFeeSchedule(Data.Get("0 - Cumulative"),Data.Get("0 - Account Balance"),TiredValuesPipeDelimited,Data.Get("Cumulative & A/C Bal"));

            Report.Step("Step 3.0: Logoff from profile webadmin application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

// setup for DepositFess002 script starts //

            Report.Step("Step 1: Login to Profile WebAdmin Application");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();

            Report.Step("Step 1.1: Add Service Fee Plan for System Date(T)(Profile WebAdminTable Configuration | Service Fee Plans)");
            string inputdata1 = ApplicationDate + ";" + Data.Get("Debit Plan - Service Fees") + ";" + Data.Get("Not Applicable") + ";0.00";
            string DDA12 = Application.WebAdmin.AddServiceFeePlan(inputdata1,Data.Get("GLOBAL_LOAN_GEN_CURRCODE"));

            Report.Step("Step 2.0: Copy transaction code DWATM to DWATMTST.");
            string DWATMTST = Application.WebAdmin.CopyTransactionCode("D - Deposit", "DDA - Demand Deposit", "DWATM");

            Report.Step("Step 2.1: Copy transaction code DDATM to DDATMTST.");
            string DDATMTST = Application.WebAdmin.CopyTransactionCode("D - Deposit", "DDA - Demand Deposit", "DDATM");

            Report.Step("Step 2.2: Copy transaction code CPW to CPWTST.");
            string CPWTST = Application.WebAdmin.CopyTransactionCode("D - Deposit", "CD - Certificates", "CPW");

            Report.Step("Step 3.0: Navigate to Table Configuration | General Table Management | UTBLTRNGRPT and Add New Service Fee Transaction Code Group TRNCDGRP.");
            string tableValuePipeDelimitedValues = DWATMTST +"|50.00;" + DDATMTST + "|50;" + CPWTST +"|10";
            string TRNCDGRP = Application.WebAdmin.AddRecordForTableInGeneralTableManagment("UTBLTRNGRPT",tableValuePipeDelimitedValues,"",ApplicationDate,"","",3);

            Report.Step("Step 4.0: Logoff from profile webadmin application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 4.1: Create datasheet to store the values.");
            Data.Store("DDA12",DDA12);
            Data.Store("TRNCDGRP",TRNCDGRP);

// setup for DepositFess002 script Ends //   


        }
    }
}