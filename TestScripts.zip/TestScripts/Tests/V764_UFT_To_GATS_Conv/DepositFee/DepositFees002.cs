/*
Objective: UFT to GATS conversion (Copy/Delete Service Fee Plan (Items))
Author: Jagadeesh Vajravelu
Creation Date: 09/30/2021
Modified By: 
Modified Date:  
Modification Reason 1: 
*/

using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.DepositFee
{
    [TestFixture]
    public class DepositFeeS002:TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Copy/Delete Service Fee Plan (Items).")]
        public void DepositFees002()
        {
            string DDA12 = Data.Fetch("DepositFeesTDSetUP", "DDA12");
            string TRNCDGRP = Data.Fetch("DepositFeesTDSetUP", "TRNCDGRP");

            Report.Step("Step 1.0: Login to Profile WebAdmin Application");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            string ApplicationDate = Application.WebAdmin.GetApplicationDate();
            string Sysdate_Minus1 = appHandle.CalculateNewDate(ApplicationDate, "d", -1);

            Report.Step("Step 2.0: Execute Service Fee Plan Copy (SRV003).Copy from Service Fee Plan:  DDA12, Effective Date:  most recent effective date,To Service Fee Plan:  PLNDL,Effective Date:  System date-1(Profile WebAdmin | Table Configuration | Service Fee plans).");
            Report.Step("Step 2.1: R19:  Verify the message “Effective Date must be the same as or after the system date.” displays.");
            string PLNDL1 = Application.WebAdmin.CopyServiceFeePlan(DDA12, ApplicationDate, Sysdate_Minus1);

            Report.Step("Step 2.2: Re-enter Effective Date (FEE.DT):  System date and submit.");
            Report.Step("Step 2.3: R19:  Verify the message “The service fee plan has been copied.” displays.");
            string PLNDL = Application.WebAdmin.CopyServiceFeePlan(DDA12, ApplicationDate, ApplicationDate);

            Report.Step("Step 2.4: R19:  Verify the Service Plan Definition page displays same plan parameters as service fee plan DDA12."); 
            string LabelNameLabelValueSemiPipeDelimited = "Service Fee Plan|" + PLNDL +";Effective Date|" + ApplicationDate + ";Plan Type|Debit Plan - Service Fees;Balance Used for Fee Computation|Not Applicable;Base Fee Amount|0.00";
            Application.WebAdmin.VerifyServiceFeePlanParameters(PLNDL, ApplicationDate, LabelNameLabelValueSemiPipeDelimited);

            Report.Step("Step 3.0: Add fees for the service fee plan <SRV001> .Set  Fee Category :  2 - Event-Related Fees , Fee Type:  ODT,Charge Option :  1 - Direct charge at time of  service , Amount : 100(Select <SRV001>| Edit | Fees Tab |Add).");
            string feesOptionPipeDelimited = "Event|ODT - Overdraft Transfer;Charge Option|Direct Charge at Time of Service;Fixed Amount|100";
            Application.WebAdmin.AddServiceFeePlanFees(PLNDL,ApplicationDate,"Event",feesOptionPipeDelimited);

            Report.Step("Step 3.1: Add fees for the service fee plan <SRV001> .Set  Fee Category :  1 - Miscellaeneous Transactions , Fee Type:  SRVPMT - Service Item Fee Pay,Charge Option :   Direct charge at time of  service , Amount : 100 (Select <SRV001>| Edit | Fees Tab |Add).");
            string feesOptionPipeDelimited1 = "Transaction Code:|SRVPMT - Service Item Fee Payment;Charge Option|Direct Charge at Time of Service;Fixed Amount|100";
            Application.WebAdmin.AddServiceFeePlanFees(PLNDL,ApplicationDate,"Miscellaneous Transactions",feesOptionPipeDelimited1);

            Report.Step("Step 3.2: Add fees for the service fee plan <SRV001> .Set  Fee Category :  Periodic , Fee Type:  CHARGE - Service fee, Charge Option :   Direct charge at time of  service , Amount : 10 (Select <SRV001>| Edit | Fees Tab |Add).");
            string feesOptionPipeDelimited2 = "Service:|CHARGE - Service fee;Charge Option|Assess at End of Fee Period;Fixed Amount|10";
            Application.WebAdmin.AddServiceFeePlanFees(PLNDL,ApplicationDate,"Periodic",feesOptionPipeDelimited2);

            Report.Step("Step 4.0: Select Event Category and click on Delete button.");
            Report.Step("Step 4.1: The message “The fees for the service fee plan have been deleted.” displays.");
            Application.WebAdmin.DeleteServiceFeePlansFees(PLNDL,ApplicationDate,"Event");

            Report.Step("Step 4.2: Select Miscellaneous Fees Category and click on Delete button.");
            Report.Step("Step 4.3: The message “The fees for the service fee plan have been deleted.” displays.");
            Application.WebAdmin.DeleteServiceFeePlansFees(PLNDL,ApplicationDate,"Miscellaneous Transactions");

            Report.Step("Step 4.4: Select Perodic Fees Category and click on Delete button.");
            Report.Step("Step 4.5: The message “The fees for the service fee plan have been deleted.” displays.");
            Application.WebAdmin.DeleteServiceFeePlansFees(PLNDL,ApplicationDate,"Periodic");

            Report.Step("Step 5.0: Navigate to Table Configuration | General Table Management | UTBLTRNGRPT and Delete the Service Fee Transaction Code Group TRNCDGRP."); 
            Report.Step("Step 5.1: R40:  The Transaction Code Group <TRNCDGRP> is deleted from system.");
            Application.WebAdmin.DeleteRecordInGeneralTableManagementUTBLTRNGRPT("UTBLTRNGRPT",TRNCDGRP,ApplicationDate);

            Report.Step("Step 6.0: Delete Service Fee Plan DDA12 for System Date(T)(Profile WebAdminTable Configuration | Service Fee Plans)"); 
            Report.Step("Step 6.1: R20:  Verify the error message displays The effective date for the service fee plan has been deleted.");
            Application.WebAdmin.DeleteServiceFeePlans(DDA12,ApplicationDate);

            Report.Step("Step 7.0: Logoff from profile webadmin application");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

        }
    }
}