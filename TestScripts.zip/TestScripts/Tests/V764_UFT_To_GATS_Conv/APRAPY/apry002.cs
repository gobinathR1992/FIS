using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;


namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.APRAPY
{
    [TestFixture]
    public class apry002 : TestBase
    {
        [Test]
        [Property("TestDescription"," APR Calculation for calculation method 1 US Regulatory Calculation Method for closed ended loan account")]
        [Property (TestType.TestBased,"")]
        public void APRY002() 
        {
            WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Step("Step 1.0 : Login to Profile WebCSR");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            string appdate=Application.WebCSR.GetApplicationDate();
            string DayOfApplicationDate = appHandle.GetDateParameters(appdate)[1];
            string payFreq = "1MA"+DayOfApplicationDate;

            Report.Step("Step 1.0 : In Profile WebCSR create a Personal Customer CUSTNUM1Profile Direct Web CSR| Basic Services| Create Personal Customer.");
            string CUSTNUM1  = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 1.1 : Create a Consumer Loan account ACCNUM1 using standard Installment Loan product type  and customer CUSTNUM1.");
            string ACCNUM1 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"),"",1,  Data.Get("Account Name") + "|" + "LNACCNUM;" +";"+ Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_10K") + ";" + Data.Get("Term") + "|3Y;" + Data.Get("Disbursement Date") + "|" +  appdate +  ";" +Data.Get("Payment Frequency") + "|" + payFreq);

            Report.Step("Step 1.2 : Get the consumer loan account  ACCNUM1| Calculate the Annual Disclosure Rate.");
            string APR=Application.WebCSR.CalculateAnnualDisclosureRate(Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"),Data.Get("GLOBAL_INTEREST_RATE_10"),"3Y");

            Report.Step("Step 1.3: R7 R8 R35 : Go to LoanRateDeterminationPage by selecting Interest tab | RateDeterminationLink and verify Anual Diclosure Rate is calculated correctly.");
            Application.WebCSR.VerifyAnnualDisclosureRateSpecifiedAccount(ACCNUM1, APR);

            Report.Step("Step 2.0: Get the account number ACCNUM1| Go to Loan Rate Determination Page by selecting Interest Rate tab | Rate Determination Link | Set Interest Rate : 15.");
            Application.WebCSR.UpdateInterestRatesInLoanRateDeterminationPage(ACCNUM1, Data.Get("GLOBAL_VALUE_15"));

            Report.Step("Step 2.1 : R12 : Get the account number ACCNUM1 | Verify the Annual Percentage Rate is not recalculated.");
            Application.WebCSR.VerifyAnnualDisclosureRateSpecifiedAccount(ACCNUM1, APR);

            Report.Step("Step 3.0 : Get the Account | Go to LoanCalculationOptionsPage by selecting Interest Tab | Set Interest Calculation Period Frequency : 1QAE. ");
            Application.WebCSR.UpdateCalculationOptionsInLoanInterestCalculationOptionsPage(ACCNUM1, "", Data.Get("GLOBAL_FREQUENCY_1QAE"));

            Report.Step("Step 3.1 : R13 : Get the account number ACCNUM1 | Verify when the Interest Calculation Period Frequency is modified the Annual Percentage Rate is not recalculated for a closed-end loan account.");
            Application.WebCSR.VerifyAnnualDisclosureRateSpecifiedAccount(ACCNUM1, APR);

            Report.Step("Step 4.0 : Get the Account | Interest Tab | Rate Determination Link | Set Interest rate : 12. ");
            Application.WebCSR.UpdateInterestRatesInLoanRateDeterminationPage(ACCNUM1, Data.Get("GLOBAL_VALUE_12"));

            Report.Step("Step 4.1 : Get the Account | Go to LoanCalculationOptionsPage by selecting Interest Tab | Set Interest Calculation Period Frequency : 1MAE. ");
            Application.WebCSR.UpdateCalculationOptionsInLoanInterestCalculationOptionsPage(ACCNUM1, "", Data.Get("GLOBAL_FREQUENCY"));

            Report.Step("Step 4.2 : R17 : Get the account number ACCNUM1 | Verify when the Nominal Interest Rate and the Interest Calculation Period Frequency are modified the Annual Percentage Rate is not recalculated.");
            Application.WebCSR.VerifyAnnualDisclosureRateSpecifiedAccount(ACCNUM1, APR);

            Report.Step("Step 5.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR")); 
        }
    }
}    