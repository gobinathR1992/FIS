using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.APRAPY
{
    [TestFixture]
    public class apry001 : TestBase
    {
        [Test]
        [Property("TestDescription", " Verify APR Calculation method defaults from product level.")]
        [Property(TestType.TestBased, "")]
        public void APRY001()
        {
             WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            
            Report.Step("Step 1.0: Login to the Profile WebCSR.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            
            Report.Step("Step 2.0: Create a new Create Personal Customer with all required fields.");
            string CUSTNUM1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            
            Report.Step("Step 3.0: Create a Consumer Loan account.");
            string ACCNUM1 = Application.WebCSR.Create_Account(CUSTNUM1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"));

            // Step 5.0: Navigate to Interest Calculation Options Page for Consumer Loan Account by selecting Interest tab | Calculation Options Link.
            Report.Step("Step 5.0: Navigate to Interest Calculation Options Page for Consumer Loan Account by selecting Interest tab | Calculation Options Link.");
            Application.WebCSR.LoadAccountSummaryPage(ACCNUM1);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Calculation Options"));

            Report.Step("Step 6.0: R3 and R5: Verify that APR Calculation method defaults from product level.");
            // Profile7CommonLibrary.VerifyLoanAccountInterestCalculationOptions(Data.Get("Annual Percentage Rate Calculation Method")+"|"+Data.Get("1 - U.S. Regulatory Calculation Method"));
            Profile7Automation.BusinessFunctions.Application.WebCSR.VerifyLoanAccountInterestCalculationOptions(Data.Get("Annual Percentage Rate Calculation Method")+"|"+Data.Get("1 - U.S. Regulatory Calculation Method"));

            Report.Step("Step 7.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));        
        }
    }
}
