using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Overdraft
{
    [TestFixture]
    public class tempodlim003_dp2 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the Temporary Authorized Overdraft Limit Spread, Temporary Authorized Overdraft Limit Start Date and Temporary Authorized Overdraft Limit End Date fields are reset to null when the temporary authorized limit has expired.")]

        public void TEMPODLIM003_DP2()
        {
            Report.Step("Step 1.0 Get the Deposit Accounts <DDAACCNUM1> and <DDAACCNUM2> from TEMPODLIM_DP datasheet.");
            string DDAACCNUM1 = Data.Fetch("TEMPODLIM003","DDAACC1");
            string DDAACCNUM2 = Data.Fetch("TEMPODLIM003","DDAACC2");

            Report.Step("Step 2.0:Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 3.0:Access the Deposit account (DDAACC1) and Verify that the Temporary Authorized Overdraft Limit Spread, Temporary Authorized Overdraft Limit Start Date and Temporary Authorized Overdraft Limit End Date fields are reset to null when the temporary authorized limit has expired");
            string SYSTEMDATEMINUS1D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -1); ;
            string SYSTEMDATEMINUS2D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -2); ;
            Application.WebCSR.VerifyTemporaryAuthorizedOverdraftLimit(DDAACCNUM1,Data.Get("Temporary Authorized Overdraft Limit Spread") + "|"+ "100" + ";"+ Data.Get("Temporary Authorized Overdraft Limit Start Date") + "|" + SYSTEMDATEMINUS2D + ";" + Data.Get("Temporary Authorized Overdraft Limit End Date") + "|" + SYSTEMDATEMINUS1D );

            Report.Step("Step 4.0: Access the Deposit account (DDAACC1) and verify the authorized and unauthorized amounts are updated correctly after the temporary OD period has expired ");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM1, Data.Get("Total Authorized Overdraft Limit") + "|" + "200" + ";" + Data.Get("Unauthorized Amount") + "|" + "200");

            Report.Step("Step 5.0: Access the Deposit account (DDAACC2) and Verify the entire negative authorized balance is moved to unauthorized balance when the Authorized Overdraft Limit End Date is reached but the Temporary Authorized Overdraft Limit End Date is in effect ");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM2, Data.Get("Unauthorized Amount") + "|" + "200");

            Report.Step("Step 6.0:Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));


        }


    }
}