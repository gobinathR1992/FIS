using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Overdraft
{
    [TestFixture]
    public class tempodlim003 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the Temporary Authorized Overdraft Limit Spread, Temporary Authorized Overdraft Limit Start Date and Temporary Authorized Overdraft Limit End Date fields are reset to null when the temporary authorized limit has expired.")]
        public void TEMPODLIM003()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));


            Report.Step("Step 2.0:In Profile WebCSR, create a personal customer CIF1 using the standard CIF Product Type (Profile Direct Web CSR| Basic Services| Create Personal Customer).");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create Demand Deposit account <DDAACC1> for the Customer <CIF1> using Demand Deposit Product Type < 992 > with the details Opening Date: System Date Currency Code:  United States Dollars Profile Direct Web CSR| Basic Services| Create Account.");
            string CombinedAccount1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_402"), "", 2, Data.Get("Account Name") + "|" + "DDAACC1;" + Data.Get("Account Name") + "|" + "DDAACC2");
            string DDAACC1 = appHandle.SplitString(CombinedAccount1, "-")[0];
            string DDAACC2 = appHandle.SplitString(CombinedAccount1, "-")[1];

            Report.Step("Step 4.0: Access the Deposit Account (DDAACC1) and update the AuthorizedOverdraftLimit: 200,AuthorizedOverdraftTerm: 3D,Temporary Authorized Overdraft Limit Spread:100, Temporary Authorized Overdraft Limit Start Date: System Date,Temporary Authorized Overdraft Limit End Date: (System Date + 1 day) ");
            string AppDatePlusone = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 1);
            string SystemDate = Application.WebCSR.GetApplicationDate();
            Application.WebCSR.UpdateAuthorizedOverdraftInOverdraftProcessing(DDAACC1, Data.Get("GLOBAL_AMOUNT_200"), Data.Get("3D"), Data.Get("GLOBAL_AMOUNT_100"), SystemDate, AppDatePlusone);

            Report.Step("Step5.0: Access the Deposit account and Verify the Total Authorized Overdraft Limit: 300 (Account Information|Transaction Processing|Overdraft Processing)");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACC1, Data.Get("Total Authorized Overdraft Limit") + "|" + Data.Get("GLOBAL_AMOUNT_300"));

            Report.Step("Step 6.0: Access the Deposit Account (DDAACC2) and update the AuthorizedOverdraftLimit: 200,AuthorizedOverdraftTerm: 2D,Temporary Authorized Overdraft Limit Spread:100, Temporary Authorized Overdraft Limit Start Date: System Date,Temporary Authorized Overdraft Limit End Date: (System Date + 4 days) ");
            string AppDatePlus4D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 4);
            Application.WebCSR.UpdateAuthorizedOverdraftInOverdraftProcessing(DDAACC2, Data.Get("GLOBAL_AMOUNT_200"), Data.Get("2D"), Data.Get("GLOBAL_AMOUNT_100"), SystemDate, AppDatePlus4D);

            Report.Step("Step 7.0: Access the Deposit account and Verify the Total Authorized Overdraft Limit: 300 (Account Information|Transaction Processing|Overdraft Processing)");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACC2, Data.Get("Total Authorized Overdraft Limit") + "|" + Data.Get("GLOBAL_AMOUNT_300"));

            Report.Step("Step 8.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 10.0 : In Profile Teller, post a withdrawal transaction of amount USD 400.00 from the Deposit Account DDAACC1 .");
            Application.Teller.WithdrawFunds(DDAACC1, Data.Get("GLOBAL_AMOUNT_REQUESTED_400"), "", "", true);

            Report.Step("Step 11.0 : In Profile Teller, post a withdrawal transaction of amount USD 400.00 from the Deposit Account DDAACC2 .");
            Application.Teller.WithdrawFunds(DDAACC2, Data.Get("GLOBAL_AMOUNT_REQUESTED_400"), "", "", true);

            Report.Step("Step 12.0 :Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 13.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 14.0 : Access the deposit account <DDAACC1> Overview page and verify that the “Account Available Balance” (DEP.BLACSPEC calculated as: col balc + Aval Auth OD Limit)  have correct values.");
            string amt1 = "-400.00";
            Application.WebCSR.LoadAccountSummaryPage(DDAACC1);
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(DDAACC1, Data.Get("Account Available Balance") + "|" + amt1);

            Report.Step("Step 15.0 : Access the deposit account <DDAACC1> Overview page and verify that the “Account Available Balance” (DEP.BLACSPEC calculated as: col balc + Aval Auth OD Limit)  have correct values.");
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(DDAACC2, Data.Get("Account Available Balance") + "|" + amt1);

            Report.Step("Step 16.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 17.0: Create datasheet to store the values.");
            Data.Store("DDAACC1", DDAACC1);
            Data.Store("DDAACC2", DDAACC2);

            Report.Step("Step 19.0: Run Two Dayend.");

        }
    }
}

