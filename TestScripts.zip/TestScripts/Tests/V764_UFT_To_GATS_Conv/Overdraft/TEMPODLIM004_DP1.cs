using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Overdraft
{
    [TestFixture]
    public class tempodlim004_dp1 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the negative interest amount is calculated correctly and stored in Authorized Negative Accrued field for the authorized overdraft balance and Unauthorized Negative Accrued field for the unauthorized overdraft balance on the Deposit Accrual page.")]
        public void TEMPODLIM004_DP1()
        {
            Report.Step("Step 1.0 Get the Deposit Account <DDAACCNUM1>  from TEMPODLIM004 datasheet.");
            string DDAACCNUM1 = Data.Fetch("TEMPODLIM004","DDAACC1");

            Report.Step("Step 2.0:Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 3.0 : Access the deposit account <DDAACC1> Overview page and verify that the “Account Available Balance” (DEP.BLACSPEC calculated as: col balc + Aval Auth OD Limit)  have correct values.");
            string amt1 = "-800.00";
            Application.WebCSR.LoadAccountSummaryPage(DDAACCNUM1);
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(DDAACCNUM1, Data.Get("Account Available Balance") + "|" + amt1);

            Report.Step("Step 4.0: Access the Deposit account (DDAACC1) and verify the authorized and unauthorized amounts are updated correctly after the temporary OD period has expired ");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM1, Data.Get("Total Authorized Overdraft Limit") + "|" + Data.Get("GLOBAL_AMOUNT_450") + ";" + Data.Get("Unauthorized Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_350"));

            Report.Step("step 5.0: Access the Deposit account (DDAACC1) and Verify that the negative interest amount is calculated correctly and stored in Authorized Negative Accrued field for the authorized overdraft balance and Unauthorized Negative Accrued field for the unauthorized overdraft balance on the Deposit Accrual page");
            string SystemDate = Application.WebCSR.GetApplicationDate();
            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");
            string AccuredInterest = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, Data.Get("GLOBAL_AMOUNT_800"), Data.Get("GLOBAL_INTEREST_RATE_27.5"), 1, SystemDate);
            string AuthorizedAccuredInterest = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_200"), Data.Get("1D"), Data.Get("20"));
            string UnauthorizedAccruedInterest = Application.WebCSR.CalculateUnAuthorizedNegativeAccrued(AccuredInterest, AuthorizedAccuredInterest);
            Application.WebCSR.VerifyAccrualInterest(DDAACCNUM1,Data.Get("Accrued Interest") + "|" + "-" + AccuredInterest + ";" + Data.Get("Authorized Negative Accrued: ") + "|" + AuthorizedAccuredInterest + ";" + Data.Get("Unauthorized Negative Accrued: ") + "|" + UnauthorizedAccruedInterest);

            Report.Step("Step 6.0:Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 7.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 8.0 : In Profile Teller, post a withdrawal transaction of amount USD 100.00 from the Deposit Account DDAACC1 .");
            Application.Teller.WithdrawFunds(DDAACCNUM1, Data.Get("GLOBAL_AMOUNT_100"), "", "", true);

            Report.Step("Step 9.0 :Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 10.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 11.0 : Access the deposit account <DDAACC1> Overview page and verify that the “Account Available Balance” (DEP.BLACSPEC calculated as: col balc + Aval Auth OD Limit)  have correct values.");
            string amt = "-900.00";
            Application.WebCSR.LoadAccountSummaryPage(DDAACCNUM1);
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(DDAACCNUM1, Data.Get("Account Available Balance") + "|" + amt);

            Report.Step("Step 12.0: Access the Deposit account (DDAACC1) and verify the authorized and unauthorized amounts are updated correctly after the temporary OD period has expired ");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM1, Data.Get("Total Authorized Overdraft Limit") + "|" + "450" + ";" + Data.Get("Unauthorized Amount") + "|" + "450");

            Report.Step("Step 13.0:Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 14.0: Create datasheet to store the values.");
            Data.Store("DDAACC1", DDAACCNUM1);
            Data.Store("AccuredInterest", AccuredInterest);
            Data.Store("AuthorizedAccuredInterest", AuthorizedAccuredInterest);
            Data.Store("unAuthorizedAccuredInterest", UnauthorizedAccruedInterest);


            Report.Step("Step 15.0: Run One Dayend.");


        }


    }
}