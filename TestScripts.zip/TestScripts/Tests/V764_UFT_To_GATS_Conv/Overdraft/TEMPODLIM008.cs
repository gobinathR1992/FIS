using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using Profile7Automation.BusinessFunctions;


namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Overdraft
{
    [TestFixture]
    public class tempodlim008 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the Temporary Authorized Overdraft Limit Spread, Temporary Authorized Overdraft Limit Start Date and Temporary Authorized Overdraft Limit End Date fields are reset to null when the temporary authorized limit has expired.")]
        public void TEMPODLIM008()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));


            Report.Step(" Step 3.0:Create two Deposit Accounts <DDAACCNUM1> and <DDAACCNUM2> for the Personal Customer <CIF1> using the standard product type 402 Opening Date: <System Date>; Opening Deposit: <1000.00> and Currency Code: <United States Dollars> WebCSR | Basic Services | Create Account.");
            string CombinedAccount1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_402"), "", 2, Data.Get("Account Name") + "|" + "DDAACC1;" + Data.Get("Account Name") + "|" + "DDAACC2;" + "|" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"));
            string DDAACC1 = appHandle.SplitString(CombinedAccount1, "-")[0];
            string DDAACC2 = appHandle.SplitString(CombinedAccount1, "-")[1];

            Report.Step(" Step 4.0:Create one Deposit Accounts <DDAACCNUM3> for the Personal Customer <CIF1> using the standard product type 402 Opening Date: <System Date-2 days>; Opening Deposit: <1000.00> and Currency Code: <United States Dollars> WebCSR | Basic Services | Create Account.");
            string SYSTEMDATEMINUS2D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -2);
            string DDAACC3 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_402"), "", 1, Data.Get("Account Name") + "|DDAACC3;" + Data.Get("Opening Date")+ "|" + SYSTEMDATEMINUS2D + ";" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_1K"));


            Report.Step(" Step 6.0:Set Limit: <200.00> Term: <6D> Temporary Authorized Overdraft Limit Spread: <250.00> Temporary Authorized Overdraft Limit Start Date: <System Date + 2 day> Temporary Authorized Overdraft Limit End Date: <System Date + 4 days> and click Submit on the Overdraft Processing page for the Deposit Account <DDAACCNUM1>.");
            string AppDatePlus4D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 4);
            string AppDatePlus2D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 2);
            Application.WebCSR.UpdateAuthorizedOverdraftInOverdraftProcessing(DDAACC1, Data.Get("GLOBAL_AMOUNT_200"), Data.Get("6D"), Data.Get("250"), AppDatePlus2D, AppDatePlus4D);  

            Report.Step(" Step 7.0:Verify that the Total Authorized Overdraft Limit is ‘200.00’ on the Overdraft Processing page.");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACC1, Data.Get("Total Authorized Overdraft Limit") + "|" + Data.Get("GLOBAL_AMOUNT_200"));


            Report.Step(" Step 8.0:Set Limit: <200.00> Term: <10D> Temporary Authorized Overdraft Limit Spread: <300.00> Temporary Authorized Overdraft Limit Start Date: <System Date> Temporary Authorized Overdraft Limit End Date: <System Date + 6 days> and click Submit on the Overdraft Processing page for the Deposit Account <DDAACCNUM2>.");
            string AppDatePlus6D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 6);
            string SystemDate = Application.WebCSR.GetApplicationDate();
            Application.WebCSR.UpdateAuthorizedOverdraftInOverdraftProcessing(DDAACC2, Data.Get("GLOBAL_AMOUNT_200"), Data.Get("10D"), Data.Get("GLOBAL_AMOUNT_300"), SystemDate, AppDatePlus6D);


            Report.Step(" Step 9.0:Verify that the Total Authorized Overdraft Limit is ‘500.00’ on the Overdraft Processing page.");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACC2, Data.Get("Total Authorized Overdraft Limit") + "|" + Data.Get("500"));

            Report.Step(" Step 10.0:Set Limit: <250.00> Term: <10D> Temporary Authorized Overdraft Limit Spread: <300.00> Temporary Authorized Overdraft Limit Start Date: <System Date -2 days> Temporary Authorized Overdraft Limit End Date: <System Date + 6 days> and click Submit on the Overdraft Processing page for the Deposit Account <DDAACCNUM3>.");
            Application.WebCSR.UpdateAuthorizedOverdraftInOverdraftProcessing(DDAACC3, Data.Get("GLOBAL_AMOUNT_250"), Data.Get("10D"), Data.Get("GLOBAL_AMOUNT_300"), SYSTEMDATEMINUS2D, AppDatePlus6D);

            Report.Step(" Step 11.0:Verify that the Total Authorized Overdraft Limit is ‘500.00’ on the Overdraft Processing page.");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACC3, Data.Get("Total Authorized Overdraft Limit") + "|" + Data.Get("550"));


            Report.Step("Step 12.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step(" Step 13.0Post a withdrawal transaction of amount USD 600.00 from the Deposit Account <DDAACCNUM1>.");
            Application.Teller.WithdrawFunds(DDAACC1, Data.Get("GLOBAL_AMOUNT_REQUESTED_600"), "", "", true);

            Report.Step(" Step 14.0Post a withdrawal transaction of amount USD 600.00 from the Deposit Account <DDAACCNUM2>.");
            Application.Teller.WithdrawFunds(DDAACC2, Data.Get("GLOBAL_AMOUNT_REQUESTED_600"), "", "", true);

            Report.Step(" Step 15.1Post a withdrawal transaction of amount USD 600.00 from the Deposit Account <DDAACCNUM3> for effective date T-2 days.");
            Application.Teller.WithdrawFunds(DDAACC3, Data.Get("GLOBAL_AMOUNT_REQUESTED_600"),SYSTEMDATEMINUS2D,"", true);

            Report.Step("Step 16.0 :Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));



            Report.Step(" Step 17.0:Verify that the Deposit Account <DDAACCNUM1> balance is ‘-600.00’ on the Deposit General page.");
            string amt1 = "-600";
            Application.WebCSR.LoadAccountSummaryPage(DDAACC1);
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(DDAACC1, Data.Get("Account Available Balance") + "|" + amt1);

            Report.Step(" Step 18.0:Search for the Deposit Account <DDAACCNUM2> and navigate to the Deposit General page.");
            Application.WebCSR.LoadAccountSummaryPage(DDAACC2);
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(DDAACC2, Data.Get("Account Available Balance") + "|" + amt1);

            Report.Step(" Step 19.2:Verify that the Deposit Account <DDAACCNUM3> balance is ‘-600.00’ on the Deposit General page.");
            Application.WebCSR.LoadAccountSummaryPage(DDAACC3);
            Application.WebCSR.VerifyAccountOverViewTableByLabelNameValue(DDAACC2, Data.Get("Account Available Balance") + "|" + amt1);

            Report.Step("Step 20.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 21.0: Create datasheet to store the values.");
            Data.Store("DDAACC1", DDAACC1);
            Data.Store("DDAACC2", DDAACC2);
            Data.Store("DDAACC3", DDAACC3);

            Report.Step(" Step 22.0:Run three dayends and run TEMPODLIM008_DP3 script.");










        }

    }

}

