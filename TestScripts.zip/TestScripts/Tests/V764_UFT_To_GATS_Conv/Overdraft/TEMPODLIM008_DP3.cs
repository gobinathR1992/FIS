using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System;
using Profile7Automation.BusinessFunctions;


namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Overdraft
{
    [TestFixture]
    public class tempodlim008_dp3 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify that the Temporary Authorized Overdraft Limit Spread, Temporary Authorized Overdraft Limit Start Date and Temporary Authorized Overdraft Limit End Date fields are reset to null when the temporary authorized limit has expired.")]
        public void TEMPODLIM008_DP3()
        {

            Report.Step("Step 1.0: Get the Deposit Accounts <DDAACCNUM1> and <DDAACCNUM2> from TEMPODLIM_DP datasheet.");
            string DDAACCNUM1 = Data.Fetch("TEMPODLIM008", "DDAACC1");
            string DDAACCNUM2 = Data.Fetch("TEMPODLIM008", "DDAACC2");
            string DDAACCNUM3 = Data.Fetch("TEMPODLIM008", "DDAACC3");

            Report.Step("Step 2.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 3.0: Access the Deposit account and Verify that the Total Authorized Overdraft Limit as :450.00 and Unauthorized Amount as : 150.00(Account Information|Transaction Processing|Overdraft Processing)");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM1, Data.Get("Total Authorized Overdraft Limit") + "|" + "450" + ";" + Data.Get("Unauthorized Amount") + "|" + "150");

            Report.Step("Step 4.0: Access the Deposit account (DDAACC1) and Verify that the negative interest amount is calculated correctly and stored in Authorized Negative Accrued field for the authorized overdraft balance and Unauthorized Negative Accrued field for the unauthorized overdraft balance on the Deposit Accrual page");
            string accrMethod = (string)Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_11");
            accrMethod = appHandle.ReplaceString(accrMethod, "$", ",");
            string SystemDate = Application.WebCSR.GetApplicationDate();
            string AccuredInterest = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, Data.Get("GLOBAL_AMOUNT_600"), Data.Get("GLOBAL_INTEREST_RATE_25.2"), 3,"");
            string AuthorizedAccuredInterest = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_200"), Data.Get("3D"), Data.Get("GLOBAL_INTEREST_RATE_28.3"));
            string UnauthorizedAccruedInterest = Application.WebCSR.CalculateUnAuthorizedNegativeAccrued(AccuredInterest, AuthorizedAccuredInterest);
            Application.WebCSR.VerifyAccrualInterest(DDAACCNUM1, Data.Get("Accrued Interest") + "|" + "-" + AccuredInterest + ";" + Data.Get("Authorized Negative Accrued") + "|" + AuthorizedAccuredInterest + ";" + Data.Get("Unauthorized Negative Accrued") + "|" + UnauthorizedAccruedInterest);

            Report.Step("Step 5.0: Change the Temporary Authorized Overdraft Limit Start Date from ‘System Date – 1 day’ to ‘System Date – 3 days’ on the Overdraft Protection page for the Deposit Account <DDAACCNUM1>.");
            string SYSTEMDATEPLUS1D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 1);
            string SYSTEMDATEMINUS3D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -3);
            Application.WebCSR.UpdateAuthorizedOverdraftInOverdraftProcessing(DDAACCNUM1, Data.Get("GLOBAL_AMOUNT_200"), Data.Get("6D"), Data.Get("GLOBAL_AMOUNT_250"), SYSTEMDATEMINUS3D, SYSTEMDATEPLUS1D);

            Report.Step("Step 6.0: Verify that the Total Authorized Overdraft Limit is ‘450.00’ and Unauthorized Amount is 150.00 on the Overdraft Processing page.");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM1, Data.Get("Total Authorized Overdraft Limit") + "|" + "450" + ";" + Data.Get("Unauthorized Amount") + "|" + "150");

            Report.Step("Step 7.0: Access the Deposit account (DDAACCNUM1) and Verify that the negative interest amount is calculated correctly and stored in Authorized Negative Accrued field for the authorized overdraft balance and Unauthorized Negative Accrued field for the unauthorized overdraft balance on the Deposit Accrual page");
            string AuthorizedAccuredInterest1 = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_450"), Data.Get("3D"), Data.Get("GLOBAL_INTEREST_RATE_19.99"));
            string UnAuthorizedAccuredInterest1 = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_150"), Data.Get("3D"), Data.Get("GLOBAL_INTEREST_RATE_30")); ;
            Application.WebCSR.VerifyAccrualInterest(DDAACCNUM1, Data.Get("Authorized Negative Accrued") + "|" + AuthorizedAccuredInterest1 + ";" + Data.Get("Unauthorized Negative Accrued") + "|" + UnAuthorizedAccuredInterest1);

            Report.Step("Step 8.0: Access the Deposit account (DDAACC2) and Verify that the negative interest amount is calculated correctly and stored in Authorized Negative Accrued field for the authorized overdraft balance and Unauthorized Negative Accrued field for the unauthorized overdraft balance on the Deposit Accrual page");
            string AccuredInterest1 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, Data.Get("GLOBAL_AMOUNT_600"), Data.Get("GLOBAL_INTEREST_RATE_21.6"),3,"");
            string AuthorizedAccuredInterest2 = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_450"), Data.Get("3D"), Data.Get("GLOBAL_INTEREST_RATE_22.2"));
            string UnauthorizedAccruedInterest2 = Application.WebCSR.CalculateUnAuthorizedNegativeAccrued(AccuredInterest, AuthorizedAccuredInterest);
            Application.WebCSR.VerifyAccrualInterest(DDAACCNUM2, Data.Get("Accrued Interest") + "|" + "-" + AccuredInterest1 + ";" + Data.Get("Authorized Negative Accrued") + "|" + AuthorizedAccuredInterest2 + ";" + Data.Get("Unauthorized Negative Accrued") + "|" + UnauthorizedAccruedInterest2);


            Report.Step("Step 9.0: Verify that the Total Authorized Overdraft Limit is ‘500.00’ and Unauthorized Amount is 100.00 on the Overdraft Processing page.");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM2, Data.Get("Total Authorized Overdraft Limit") + "|" + "500" + ";" + Data.Get("Unauthorized Amount") + "|" + "100");

            Report.Step("Step 10.0: Change the Temporary Authorized Overdraft Limit Start Date from ‘System Date – 3 days’ to ‘System Date + 1 day’ on the Overdraft Protection page for the Deposit Account <DDAACCNUM2>.");
            string SYSTEMDATEPLUS3D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 3);
            Application.WebCSR.UpdateAuthorizedOverdraftInOverdraftProcessing(DDAACCNUM2, Data.Get("GLOBAL_AMOUNT_200"), Data.Get("10D"), Data.Get("GLOBAL_AMOUNT_300"), SYSTEMDATEPLUS1D, SYSTEMDATEPLUS3D);

            Report.Step("Step 11.0: Verify that the Total Authorized Overdraft Limit is ‘200.00’ and Unauthorized Amount is 400.00 on the Overdraft Processing page.");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM2, Data.Get("Total Authorized Overdraft Limit") + "|" + "200" + ";" + Data.Get("Unauthorized Amount") + "|" + "400");

            Report.Step("Step 12.0: Access the Deposit account (DDAACCNUM2) and Verify that the negative interest amount is calculated correctly and stored in Authorized Negative Accrued field for the authorized overdraft balance and Unauthorized Negative Accrued field for the unauthorized overdraft balance on the Deposit Accrual page");
            string AccuredInterest2 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, Data.Get("GLOBAL_AMOUNT_600"), Data.Get("GLOBAL_INTEREST_RATE_26.66"), 2,SystemDate);
            string AuthorizedAccuredInterest3 = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_200"), Data.Get("3D"), Data.Get("GLOBAL_INTEREST_RATE_20"));
            string UnAuthorizedAccuredInterest3 = Application.WebCSR.CalculateUnAuthorizedNegativeAccrued(AccuredInterest2, AuthorizedAccuredInterest3);
            Application.WebCSR.VerifyAccrualInterest(DDAACCNUM2, Data.Get("Authorized Negative Accrued") + "|" + AuthorizedAccuredInterest3 + ";" + Data.Get("Unauthorized Negative Accrued") + "|" + UnAuthorizedAccuredInterest3);

            Report.Step("Step 13.0: Verify that the Total Authorized Overdraft Limit is ‘550.00’ and Unauthorized Amount is 50.00 on the Overdraft Processing page.");
            Application.WebCSR.LoadAccountSummaryPage(DDAACCNUM3);
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM3, Data.Get("Total Authorized Overdraft Limit") + "|" + "550" + ";" + Data.Get("Unauthorized Amount") + "|" + "50");

            Report.Step("Step 14.0: Access the Deposit account (DDAACCNUM3) and Verify that the negative interest amount is calculated correctly and stored in Authorized Negative Accrued field for the authorized overdraft balance and Unauthorized Negative Accrued field for the unauthorized overdraft balance on the Deposit Accrual page");
            string AuthorizedAccuredInterest4 = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_550"), Data.Get("5D"), Data.Get("GLOBAL_INTEREST_RATE_20"));
            string UnAuthorizedAccuredInterest4 = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_50"), Data.Get("5D"), Data.Get("GLOBAL_INTEREST_RATE_29.9"));
            Application.WebCSR.VerifyAccrualInterest(DDAACCNUM3, Data.Get("Authorized Negative Accrued") + "|" + AuthorizedAccuredInterest4 + ";" + Data.Get("Unauthorized Negative Accrued") + "|" + UnAuthorizedAccuredInterest4);


            Report.Step("Step 15.0: Change the Temporary Authorized Overdraft Limit Start Date from ‘System Date – 3 days’ to ‘System Date + 1 day’ on the Overdraft Protection page for the Deposit Account <DDAACCNUM3>.");
            Application.WebCSR.UpdateAuthorizedOverdraftInOverdraftProcessing(DDAACCNUM3, Data.Get("GLOBAL_AMOUNT_250"), Data.Get("10D"), Data.Get("GLOBAL_AMOUNT_300"), SYSTEMDATEPLUS1D, SYSTEMDATEPLUS3D);

            Report.Step("Step 16.0: Verify that the Total Authorized Overdraft Limit is ‘250.00’ and Unauthorized Amount is 350.00 on the Overdraft Processing page.");
            Application.WebCSR.VerifyTotalAuthorizedOverdraftLimit(DDAACCNUM3, Data.Get("Total Authorized Overdraft Limit") + "|" + "250" + ";" + Data.Get("Unauthorized Amount") + "|" + "350");
            string AccuredInterest4 = Application.WebCSR.CalculateAccruedInterestByAccrMethod(accrMethod, Data.Get("GLOBAL_AMOUNT_600"), Data.Get("GLOBAL_INTEREST_RATE_25.8"), 5,SystemDate);
            string AuthorizedAccuredInterest5 = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_250"), Data.Get("5D"), Data.Get("GLOBAL_INTEREST_RATE_19.9"));
            string UnAuthorizedAccuredInterest5 = Application.WebCSR.CalculateUnAuthorizedNegativeAccrued(AccuredInterest4, AuthorizedAccuredInterest5);
            Application.WebCSR.VerifyAccrualInterest(DDAACCNUM3, Data.Get("Authorized Negative Accrued") + "|" + AuthorizedAccuredInterest5 + ";" + Data.Get("Unauthorized Negative Accrued") + "|" + UnAuthorizedAccuredInterest5);


            Report.Step("Step 17.0: Log off from Profile WebCSR.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));


        }

    }
}








