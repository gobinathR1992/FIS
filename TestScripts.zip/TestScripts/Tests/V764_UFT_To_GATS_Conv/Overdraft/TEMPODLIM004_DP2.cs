using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using System;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.Overdraft
{
    [TestFixture]
    public class tempodlim004_DP2 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "This is TestBased sample test")]
        public void TEMPODLIM004_DP2()
        {

            Report.Step("Step 1.0 Get the Deposit Account <DDAACCNUM1>  from TEMPODLIM004 datasheet.");
            string DDAACCNUM1 = Data.Fetch("TEMPODLIM004", "DDAACC1");
            string AuthorizedAccruedInterest1 = Data.Fetch("TEMPODLIM004", "AuthorizedAccuredInterest");
            string UnauthorizedAccruedInterest1 = Data.Fetch("TEMPODLIM004", "UnauthorizedAccruedInterest");

            Report.Step("Step 2.0:Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("step 3.0: Access the Deposit account (DDAACC1) and Verify that the negative interest amount is calculated correctly and stored in Authorized Negative Accrued field for the authorized overdraft balance and Unauthorized Negative Accrued field for the unauthorized overdraft balance on the Deposit Accrual page");
            string AuthorizedAccuredInterest = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_450"), Data.Get("1D"), Data.Get("GLOBAL_INTEREST_RATE_28.88"));
            string UnauthorizedAccruedInterest = Application.WebCSR.CalculateAuthorizedNegativeAccrued(Data.Get("GLOBAL_AMOUNT_450"), Data.Get("2D"), Data.Get("GLOBAL_INTEREST_RATE_35"));
             Application.WebCSR.VerifyAccrualInterest(DDAACCNUM1,Data.Get("Authorized Negative Accrued") + "|" + AuthorizedAccuredInterest + ";" + Data.Get("Unauthorized Negative Accrued") + "|" + UnauthorizedAccruedInterest);

            Report.Step("Step 4.0:Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));


        }



    }
}