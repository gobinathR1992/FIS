using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.AccountVerification
{
    [TestFixture]
    public class accountverification002 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property (TestType.TestBased,"")]
        [Property("TestDescription", " Verify there are no integrities on the Corporate Customer account.")]
        public void AccountVerification002()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: In Profile WebCSR, create a corporate customer <CORPCIF1> (Basic Services | Create Corporate Customer)");
            string CustNo = Application.WebCSR.createcorporatecustomer(Data.Get("GLOBAL_CORPORATE_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Select  Customer Information  from the Goto Dropdown.Verify the Customer Verification Link is available.Click on the Customer Verification link. Verify a customer number can be entered in the Number field, when a user selects a customer to perform verification and the message # Account passes integrity verification without error # is displayed. ");
            Application.WebCSR.VerifyCustomerIntegrity((string)Data.Get("GLOBAL_CUSTOMER_INFORMATION"));

            Report.Step("Step 4.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}