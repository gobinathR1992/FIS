using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.AccountVerification
{
    [TestFixture]
    public class accountverification008 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", " 1. Verify there are no integrities on the Mortgage Loan Account. 2. For a Mortgage loan account verify Maximum Daily Return Item Fee Amount , Maximum Number of Disbursements , Maximum Funds Transfer Amount , Max Number of Funds Transfers Per Day , Minimum Disbursement Amount , Incremental Disbursement Amount fields can accept numeric values in Account Summary | Account Information | Transaction Processing . 3. Verify error messages while creating Mortgage loan account by entering blank in Amount and Disbursement Date field. 4. Create a DDA account. Update Transaction Acceptance Enrolled value in Transaction Processing under Account Information and verify it is updated successfully.")]
        public void AccountVerification008()
        {
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
           
            Report.Step("Step 3.0: Create a new Mortgage  Loan account <MTGACCNUM> for Customer <CIF1>. Account Name: MTG; AMount: 100000; Term: 30Y; Payment Frequency: 1MAE; Currency Code: USD; Collateral Type: Real Estate.");
            string MTGACCNUM = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_700"), "", 1, Data.Get("Account Name") + "|MTGACCNUM;" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_100K") + ";" + Data.Get("Term") + "|30Y;" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE"));
         
            Report.Step("Step 4.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");
          
            Report.Step("Step 6.0: Post a disbursement to the loan account <MTGACCNUM> for 1000000 using Transaction code MD. Off set  the transaction using CO.");
            Application.Teller.LoanDisbursement(MTGACCNUM, Data.Get("GLOBAL_AMOUNT_REQUESTED_100K"));
          
            Report.Step("Step 7.0:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 8.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0: Search for the Mortgage Loan account < MTGACCNUM> Profile Direct WebCSR / Customer Search.");
            Application.WebCSR.GetAccount(MTGACCNUM);

            Report.Step("Step 10.0 : Verify Account Integrity :: Account passes integrity verification without error :: is displayed");
            Application.WebCSR.VerifyAccountIntegrity(MTGACCNUM);

            Report.Step("Step 11.0: For a Mortgage loan account verify Maximum Daily Return Item Fee Amount , Maximum Number of Disbursements , Maximum Funds Transfer Amount , Max Number of Funds Transfers Per Day , Minimum Disbursement Amount , Incremental Disbursement Amount fields can accept numeric values in Account Summary | Account Information | Transaction Processing .");
            Application.WebCSR.LoadAccountSummaryPage(MTGACCNUM);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            string inputToBeEntered = Data.Get("Maximum Daily Return Item Fee Amount") + "|" + Data.Get("GLOBAL_PASSWORD_HINT") + ";" + Data.Get("Maximum Number of Disbursements") + "|" + Data.Get("GLOBAL_PASSWORD_HINT") + ";" + Data.Get("Maximum Funds Transfer Amount") + "|" + Data.Get("GLOBAL_PASSWORD_HINT") + ";" + Data.Get("Max Number of Funds Transfers Per Day") + "|" + Data.Get("GLOBAL_PASSWORD_HINT") + ";" + Data.Get("Minimum Disbursement Amount") + "|" + Data.Get("GLOBAL_PASSWORD_HINT") + ";" + Data.Get("Incremental Disbursement Amount") + "|" + Data.Get("GLOBAL_PASSWORD_HINT");
            string MSGSToBEValidated = Data.Get("Maximum Daily Return Item Fee Amount is not a valid amount.") + "|" + Data.Get("Maximum Number of Disbursements must be numeric.") + "|" + Data.Get("Maximum Funds Transfer Amount is not a valid amount.") + "|" + Data.Get("Max Number of Funds Transfers Per Day must be numeric.") + "|" + Data.Get("Minimum Disbursement Amount is not a valid amount.") + "|" + Data.Get("Incremental Disbursement Amount is not a valid amount.");
            Application.WebCSR.VerifyAmountFieldsWithInvalidInputTransactionProcessingLoan(inputToBeEntered, MSGSToBEValidated);
            inputToBeEntered = Data.Get("Maximum Daily Return Item Fee Amount") + "|" + Data.Get("GLOBAL_VALUE_1") + ";" + Data.Get("Maximum Number of Disbursements") + "|" + Data.Get("GLOBAL_VALUE_1") + ";" + Data.Get("Maximum Funds Transfer Amount") + "|" + Data.Get("GLOBAL_VALUE_1") + ";" + Data.Get("Max Number of Funds Transfers Per Day") + "|" + Data.Get("GLOBAL_VALUE_1") + ";" + Data.Get("Minimum Disbursement Amount") + "|" + Data.Get("GLOBAL_VALUE_1") + ";" + Data.Get("Incremental Disbursement Amount") + "|" + Data.Get("GLOBAL_VALUE_1");
            MSGSToBEValidated = Data.Get("GLOBAL_INFORMATION_UPDATED");
            Application.WebCSR.VerifyAmountFieldsWithValidInputTransactionProcessingLoan(inputToBeEntered, MSGSToBEValidated);

            Report.Step("Step 12.0: Perform Steps to create a mortgage account using customer number <CIF1> . On selecting product type select number of accounts as 2.In Account Details section Enter all mandatory fields .Enter blank in Amount and Disbursement Date field. Click on Submit button and validate the error message.");
            Application.WebCSR.VerifyAccountCreationWithInvalidDataInAccountDetails(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_700"), "", 2, Data.Get("Account Name") + "|MTGACCNUM1" + ";" + Data.Get("Account Name") + "|MTGACCNUM2" + ";" + Data.Get("Amount") + "|" + Data.Get("BLANK") + ";" + Data.Get("Amount") + "|" + Data.Get("BLANK") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Disbursement Date") + "|" + Data.Get("BLANK") + ";" + Data.Get("Disbursement Date") + "|" + Data.Get("BLANK") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured"), Data.Get("Amount is required for") + " MTGACCNUM1" + "|" + Data.Get("Disbursement Date is required for") + " MTGACCNUM1" + "|" + Data.Get("Amount is required for") + " MTGACCNUM2" + "|" + Data.Get("Disbursement Date is required for") + " MTGACCNUM2");

            Report.Step("Step 13.0: Create a Demand Deposit account");
            string DDAACC1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_400"));

            Report.Step("Step 14.0: Navigate to Account Information Page. Navigate to Transaction Processing tab.");
            Application.WebCSR.LoadAccountSummaryPage(DDAACC1);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));

            Report.Step("Step 15.0: Capture Transaction Acceptance Enrolled value. Update it to Yes . To update to Yes Navigate to Customer Services | Service Management and update required changes. Verify the update made for Transaction Acceptance Enrolled.");
            Application.WebCSR.UpdateAndVerifyTransactionAcceptanceEnrolledForAccountPositivePay(DDAACC1);

            Report.Step("Step 16.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

        }
    }
}