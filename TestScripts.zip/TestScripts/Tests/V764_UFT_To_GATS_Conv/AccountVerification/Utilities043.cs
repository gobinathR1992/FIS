using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.AccountVerification
{
    [TestFixture]
    public class utilities043 : TestBase
    {
        [Test]
        [Property("TestDescription", "  Verify that the expected message “No service items found” is displayed, when there are no service items in the list.")]
        [Property(TestType.TestBased, "")]
        public void Utilities043()
        {
            //OBJECTIVE	:  Verify that the expected message “No service items found” is displayed, when there are no service items in the list.
            Report.Step(" Step 1: Login to WebCSR application");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step(" Step 2: Navigate to ServiceItemAssignment Page and validate ServiceItemAssignment.");
            Application.WebCSR.ClickLinkFromMenuItem(Data.Get("Utilities") + "|" + Data.Get("ServiceItemAssignment"));
            Application.WebCSR.ValidateServiceItemsMessage(Data.Get("SafeDepositBox") + "|" + Data.Get("SafeDepositBox-1") + "|" + Data.Get("BackOffice0"));

            Report.Step(" Step 3: Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }
    }
}