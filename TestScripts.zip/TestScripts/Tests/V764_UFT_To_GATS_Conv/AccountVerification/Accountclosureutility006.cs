using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.AccountVerification
{
    [TestFixture]
    public class accountclosureutility006 : TestBase
    {
        [Test]
        [Property("TestDescription", " Verify that Linkage type as 'Loan Negative Balance Transfer Account' and 'Loan Front Money Deposit Account' are displayed in Account Closure Utility Page under Other Account Linkages (Discretionary) section in Profile WebCSR.")]
        [Property(TestType.TestBased, "")]
        public void AccountClosureUtility006()
        {
            //OBJECTIVE	: Verify that Linkage type as 'Loan Negative Balance Transfer Account' and 'Loan Front Money Deposit Account' are displayed in Account Closure Utility Page under Other Account Linkages (Discretionary) section in Profile WebCSR.
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            
            Report.Step("Step 3.0 : Create a Certificate of Deposit Account CDAccNum using customer CIF1 and standard product type 350 with Amount :10K account term: 1Y and Currency: USD.");
            string SAVACCNUM1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"));
            
            Report.Step("Step 4.0 : Create a Mortgage Loan Account <MTGACCT1> for the Personal Customer <CIF1> using the standard product type 700 Opening Date: <System Date>; Opening Deposit: 10k and Currency Code: <United States Dollars> Profile WebCSR | Basic Services | Create Account.");
            string MTGACCT1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE_LOAN2"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_700"));
            
            Report.Step("Step 5.0:Navigate to Revolving Options Page of the Mortgage Loan Account <MTGACCT1> Loan Account Services|Transaction Processing|Revolving Options.");
            Application.WebCSR.AccountClosure(SAVACCNUM1, MTGACCT1);

            Report.Step(" Step 5.0 Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }
    }
}