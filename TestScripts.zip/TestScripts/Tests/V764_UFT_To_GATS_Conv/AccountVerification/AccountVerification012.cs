using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;


namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.AccountVerification
{
    [TestFixture]
    public class accountverification012 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property (TestType.TestBased,"")]
        [Property("TestDescription", "Verify there are no integrities on the Demand Deposit Account.")]
        public void AccountVerification012()
        {

            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create Demand Deposit account <DDAACC1> for the Customer <CIF1> using Demand Deposit Product Type < Consumer Interest Checking > with the details Opening Deposit: 5000.00 and Opening Date: System Date Currency Code:  United States Dollars Profile Direct Web CSR| Basic Services| Create Account.");
            string DDAACC1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_400"), "", 1, Data.Get("Account Name") + "|DDAACC1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"));

            Report.Step("Step 4.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 6.0: Post a deposit to the Demand Deposit account < DDAACC1> for USD 5000.00 using transaction code DD (Demand Deposit). Offset the transaction using transaction code CI (Cash In).");
            Application.Teller.DepositFunds(DDAACC1, Data.Get("GLOBAL_AMOUNT_REQUESTED_5K"));

            Report.Step("Step 7.0:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 8.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0: Search for the Demand Deposit account < DDAACC1>Profile Direct WebCSR / Customer Search.");
            Application.WebCSR.GetAccount(DDAACC1);

            Report.Step("Step 10.0 : Verify Account Integrity :: Account passes integrity verification without error :: is displayed");
            Application.WebCSR.VerifyAccountIntegrity(DDAACC1);

            Report.Step("Step 11.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }
    }
}