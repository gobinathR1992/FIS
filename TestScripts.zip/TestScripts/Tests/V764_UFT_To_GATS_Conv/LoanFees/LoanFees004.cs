using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.LoanFees
{
    [TestFixture]
    public class loanFees004:TestBase
    { 
        static WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Create/Modify/Copy/Delete loan fee group.")]
        public void LoanFees004()
        {
            Report.Step("Step 1.0: Login to WebAdmin application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            string ApplicationDate=Application.WebCSR.GetApplicationDate();
            string SYSTEMDATEMIN360D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -360);

            Report.Step("Step 2.0: Create a New Loan Fee Plan(Web Admin|Table Configuration|Loan Fee Plan).");
            Report.Step("Step 3.0: Click on Add button to Add New Loan Fee Plan, Set Loan Fee Plan: LoanFeePlan Description (LNFEEP.DESC):LoanFeePlan and Click on submit");
            string LoanFee = Application.WebAdmin.AddLoanFeePlan(SYSTEMDATEMIN360D,true);

            Report.Step("Step 6.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));   
                 
            Report.Step("Step 11.0 Reload Tomcat Server. ");
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            
            Data.Store("LoanFee",LoanFee);
        }               
    }
}