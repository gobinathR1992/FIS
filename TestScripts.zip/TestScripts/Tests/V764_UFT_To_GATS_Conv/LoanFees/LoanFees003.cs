using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;
namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.LoanFees
{
    [TestFixture]
    public class Loanfees003:TestBase
    {
         static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Create/Modify/Delete loan fee transaction code group.")]
        public void LoanFees003()
        {
            
            Report.Step("Step 1.0: Login to WebAdmin application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
       
            Report.Step("Step 2.0: Create a new Loan Fee Transaction code group :Set Loan Fee Transaction Code Group: LoanFeeTransactionCodeGroup,Description: LoanFeeTransactionCodeGroup,Transaction Code: LD - Disbursement (Web Admin|General Table Management");
            string LoanFee = Application.WebAdmin.AddRecordForTableInGeneralTableManagment("UTBLTRNGRPLT","LD - Disbursement","LoanFeesCodeGroup");

            Report.Step("Step 3.0: R7: Modify the created Loan Fee Transaction Code Group : LoanFeeTransactionCodeGroup,Set Transaction Code:CMP - Payment.");
            Application.WebAdmin.ModifyRecordInGeneralTableManagement("UTBLTRNGRPLT","CMP - Payment",LoanFee);
            
            Report.Step("Step 4.0: Delete the loan fee transaction code group : LoanFeeTransactionCodeGroup");
            Report.Step("Step 5.0: R9: Verify that the loan fee group is deleted: LoanFeeTransactionCodeGroup");
            Application.WebAdmin.DeleteRecordInGeneralTableManagement("UTBLTRNGRPLT",LoanFee);

            Report.Step("Step 6.0: Logout from Profile WebAdmin.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));         

        }
        
    }
}