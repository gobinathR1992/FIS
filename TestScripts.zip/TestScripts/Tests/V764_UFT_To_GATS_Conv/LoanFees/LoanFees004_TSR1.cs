using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.LoanFees
{
    [TestFixture]
    public class loanFees004_TSR1:TestBase
    { 
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Create/Modify/Copy/Delete loan fee group.")]
        public void LoanFees004_TSR1()
        {
            string LoanFee = Data.Fetch("LoanFees004","LoanFee");

            Report.Step("Step 1.0: Login to WEBADMIN Application.");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            string ApplicationDate = Application.WebCSR.GetApplicationDate();

            Report.Step("Step 2.0: R67:- Add a new loan fee group :NewRecord (Web Admin|General Table Management).");
            Report.Step("Step 3.0: Copy the newly created Loan Fee Group: NewRecord to LoanFeegroupName2");
            Report.Step("Step 4.0: Loan Fee Group: LoanFeegroupName2,Description: LoanFeegroupName2 and click on submit.\n R71:Verify that the Loan fee group is copied to: LoanFeegroupName2");
            string LoanFeeGroup = Application.WebAdmin.AddRecordForTableInGeneralTableManagment("UTBLLNFEEGRP",LoanFee);

            Report.Step("Step 5.0: Modify the copied loan fee group : LoanFeegroupName2,Set Description: LoanFeeGroupEditDesc.\n  R68 and R72:Verify that the loan fee group:LoanFeegroupName2 is modified.");
            Application.WebAdmin.ModifyRecordInGeneralTableManagement("UTBLLNFEEGRP","",LoanFeeGroup);

            Report.Step("Step 6.0:Delete the copied loan fee group : LoanFeegroupName2. R70:Verify that the loan fee group is deleted: LoanFeegroupName2");
            Application.WebAdmin.DeleteRecordInGeneralTableManagement("UTBLLNFEEGRP",LoanFeeGroup);

            Report.Step("Step 7.0: Logout from WebAdmin Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));            
        }           
    }
}