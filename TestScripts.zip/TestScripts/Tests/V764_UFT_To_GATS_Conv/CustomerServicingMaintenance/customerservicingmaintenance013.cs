using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;
namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.CustomerServicingMaintenance
{
    [TestFixture]
    public class customerservicingmaintenance013 : TestBase
    {
        [Test]
        [Property("TestDescription", "  Verify that error message is displaying if the user is selected invalid postal code while creating / maintaining")]
        [Property(TestType.TestBased, "")]
        public void CustomerServicingMaintenance013()
        {
            Report.Step(" Step 1 : Login WEBCSR  APPLICATION");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            
            Report.Step(" Step 2 : Validation of Pincode in Address fields for customer creation and Creation of a new customer");
            string CustId = Application.WebCSR.CreateCustomerInvalidAddr(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            
            Report.Step(" Step 3 : Create a new account");
            string AccountNumber = Application.WebCSR.Create_Account(CustId, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"));
            
            Report.Step(" Step 4 : Validation of the Pincode in Account Information page");
            Application.WebCSR.ValidateInvalidPostalCode_Account();

            Report.Step(" Step 5 : Logging off from the application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }
    }
}