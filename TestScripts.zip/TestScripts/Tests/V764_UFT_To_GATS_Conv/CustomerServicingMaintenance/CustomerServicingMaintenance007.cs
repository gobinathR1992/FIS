using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using Profile7Automation.BusinessFunctions;
namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.CustomerServicingMaintenance
{
    [TestFixture]
    public class customerservicingmaintenance007 : TestBase
    {
        
        [Test]
        [Property (TestType.TestBased,"")]
        [Property("TestDescription", "Adding information to Contact information and Servicing information in Customer Information Page.")]
        public void CustomerServicingMaintenance007()
        {
                        
            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Enter Contact information , servicing information in Customer Information Page . Verify customer data is successfully updated with message :: " + Data.Get("GLOBAL_CUSTOMER_INFORMATION_UPDATED"));
            Application.WebCSR.VerifyEnterContactInfoServiceInfoInCustomerInformation();

            Report.Step("Step 4.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }
    }
}