using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.CustomerServicingMaintenance
{
    [TestFixture]
    public class customerservicingmaintenance025 : TestBase
    {
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "  Verify that CLONE - Change Customer Info-Non Personal Customer – Credit Financial tab has correct labels for Limit Group in sub-tabs Customer Limits and Limits List.")]
        public void CustomerServicingMaintenance025()
        {
            //OBJECTIVE			:  Verify that CLONE - Change Customer Info-Non Personal Customer – Credit Financial tab has correct labels for Limit Group in sub-tabs Customer Limits and Limits List.
            //Script created to validate the Maintenence JI WEBCSR-5831
            Report.Step(" Step 1.0 Login to WebCSR Application");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step(" Step 2.0 Creation of a  new Corporate Customer");
            string CORPORATE_CUSTOMER1 = Application.WebCSR.createcorporatecustomer(Data.Get("GLOBAL_CORPORATE_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step(" Step 3.0:  Retrieving Corporate Customer Details");
            Application.WebCSR.GetCustomer(CORPORATE_CUSTOMER1);

            Report.Step(" Step 4.0:  Navigating to 'Credit/Financial' Tab and validating the labels");
            Application.WebCSR.NavigateAndValidateCreditLimitLabels(Data.Get("Credit/Financial"));

            Report.Step(" Step 5.0: Closing the Browser Instance");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
        }
    }
}