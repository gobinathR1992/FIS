using GTS_OSAF;
using NUnit.Framework;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.BusinessFunctions;
using GTS_OSAF.CoreLibs;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.CustomerServicingMaintenance
{
    [TestFixture]
    public class customerservicingmaintenance034 : TestBase
    {
        [Test]
        [Property("TestDescription", "  PROFILEDOC-2622-GSR-Region Code User Table")]
        [Property(TestType.TestBased, "")]
        public void CustomerServicingMaintenance034()
        {
            // OBJECTIVE: PROFILEDOC - 2622 - GSR - Region Code User Table;
            // //Verify new record is added into UTBLREGION table and validation of business rules and error messages
            Report.Step(" Step 1.0 Login to WebCSR Application");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step(" 2.0Click on GeneralTableManagementLink.");
            Application.WebAdmin.ValidateUTBLREGION();

            Report.Step(" Step 5.0: Closing the Browser Instance");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

        }
    }
}