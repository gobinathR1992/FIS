using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using Profile7Automation.BusinessFunctions;


namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.FundsTransfer
{
    [TestFixture]
    public class fundstransfer005_TSR1:TestBase
    { 
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify Error Message The maximum number of funds transfers per day has been reached.")]
        public void FundsTransfer005_TSR1()
        {
            
            string DDAPRO1 = Data.Fetch("FundsTransfer005", "DDAPRO1");

            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0: Create Demand Deposit account <DDAACC1> for the Customer <CIF1> using Demand Deposit Product Type < Consumer Interest Checking > with the details Opening Deposit: 1000.00 and Opening Date: System Date Currency Code:  United States Dollars Profile Direct Web CSR| Basic Services| Create Account.");
            string DDAACC1 = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), DDAPRO1, "", 1, Data.Get("Account Name") + "|DDAACC1;" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_DEPOSITED_1K"));

            Report.Step("Step 4.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 6.0 : Post a deposit transaction to the DDAACC1 of  2000.00 using transaction code SD. Offset the transaction using transaction code CI (Cash In)");
            Application.Teller.DepositFunds(DDAACC1, Data.Get("GLOBAL_AMOUNT_DEPOSITED_2K"));

            Report.Step("Step 7.0:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 8.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0: Navigate to External Accounts page and Create an external account for the customer <CIF1> using Routing Number 122000496 with following details: External Account Number: any random number <ExtAcctNo1> ; ExternalAccountOwner: <ExtAcctNo1>; External Account Type: DDA Account; External Account Method : Pre-approved.(Funds Services | External Accounts)");
            string extrnAcct=Application.WebCSR.AddExternalAccountInWebCSR(DDAACC1,"122000496",Data.Get("Account Type"));

            Report.Step("Step 10.0:Navigate to Transfer Funds page and transfer 50 USD from DDAACC1 to External Account (Profile Direct WebCSR| Funds Services| Transfer Funds).");
            Application.WebCSR.LoadAccountSummaryPage(DDAACC1);
            Application.WebCSR.TrasferFundsFundingServices(DDAACC1, extrnAcct,"50");

            Report.Step("Step 11.0:Navigate to Transfer Funds page and transfer 60 USD from DDAACC1 to External Account (Profile Direct WebCSR| Funds Services| Transfer Funds).");
            Application.WebCSR.LoadAccountSummaryPage(DDAACC1);
            Application.WebCSR.LoadAccountSummaryPage(DDAACC1);
            Application.WebCSR.LoadAccountSummaryPage(DDAACC1);
            Application.WebCSR.TrasferFundsFundingServices(DDAACC1, extrnAcct,"60");

            Report.Step("Step 12.0:Navigate to Transfer Funds page and transfer 80 USD from DDAACC1 to External Account then verify Verify that “The maximum number of funds transfers per day has been reached.” Error message is displayed(Profile Direct WebCSR| Funds Services| Transfer Funds).");
            Application.WebCSR.LoadAccountSummaryPage(DDAACC1);
            Application.WebCSR.TrasferFundsFundingServices(DDAACC1, extrnAcct,"80");
            Application.WebCSR.VerifytransactionErrorMessageInFundsTransfer(Data.Get("The maximum number of funds transfers per day has been reached"));

            Report.Step("Step 13.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step(" Step 1.0 : Login WEBADMIN  APPLICATION");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 3.0: Navigate to Transaction Processing Page and Update Maximum Funds Transfers Per Day as:Null ");
            Application.WebAdmin.UpdateMaximumFundsTransferPerDay(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPRO1);

            Report.Step("Step 4.0: Log off from WebAdmin Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
                      
            




            
        }

        
       
    }
}