using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;

using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.FundsTransfer
{
    [TestFixture]
    public class fundstransfer002 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "1. Setting up of Funds Transfers.Validate conditions under WEBCSR-4421 . 2.Verify the error ::no account transactions found in Account History when searched with future dates  SYSDATE_PLUS2Y")]
        public void FundsTransfer002()
        {

            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0:Create multiple accounts for product type 300 <SAVACCOUNT1> and <SAVACCOUNT2> (Profile Direct WebCSR| Basic Services| Create Account).");
            string CombinedAccount = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), "", 2, Data.Get("Account Name") + "|" + "SAVACCT1;" + Data.Get("Account Name") + "|" + "SAVACCT2");
            string SAVACCOUNT1 = appHandle.SplitString(CombinedAccount, "-")[0];
            string SAVACCOUNT2 = appHandle.SplitString(CombinedAccount, "-")[1];

            Report.Step("Step 4.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 6.0 : Post a deposit transaction to the SAVACCOUNT1 of  20,000.00 using transaction code SD. Offset the transaction using transaction code CI (Cash In)");
            Application.Teller.DepositFunds(SAVACCOUNT1, Data.Get("GLOBAL_AMOUNT_REQUESTED_20K"));

            Report.Step("Step 7.0:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 8.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0:Navigate to <SAVACCOUNT1> account summary page.Go to Transfer Funds (Profile Direct WebCSR| Funds Services| Transfer Funds). Perform Funds transfer from SAVACCOUNT1 to SAVACCOUNT2 without entering Amount and validate the error message.");
            Application.WebCSR.LoadAccountSummaryPage(SAVACCOUNT1);
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, "");
            Application.WebCSR.VerifytransactionErrorMessageInFundsTransfer(Data.Get("Amount is required."));

            Report.Step("Step 10.0: Perform Perform Funds transfer from SAVACCOUNT1 to SAVACCOUNT2 for a negative balance and validate the error message.");
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, "-" + Data.Get("GLOBAL_AMOUNT_100"));
            Application.WebCSR.VerifytransactionErrorMessageInFundsTransfer(Data.Get("Amount must be greater than zero."));

            Report.Step("Step 11.0: Perform Funds transfer from SAVACCOUNT1 to SAVACCOUNT2 for  balance  greater than SAVACCOUNT1 available balance : 50000 and validate the error message.");
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, Data.Get("GLOBAL_AMOUNT_REQUESTED_50K"));
            Application.WebCSR.VerifyAuthorizationMessage(Data.Get("Transaction exceeds available balance"));
            Application.WebCSR.ClickOnAuthorizationCancelButton();
            Application.WebCSR.VerifyCustomerSearchLinkIsLoaded();

            Report.Step("Step 12.0: Perform Funds transfer from SAVACCOUNT1 to SAVACCOUNT2 for  Amount : 10000 and validate the Funds Transfer success message.");
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"));
            Application.WebCSR.VerifySuccessfullTransferFundsMesage();

            Report.Step("Step 13.0:Go to Transfer Funds (Profile Direct WebCSR| Funds Services| Transfer Funds). Perform Funds transfer from SAVACCOUNT1 to SAVACCOUNT2 by entering End Date as Less than current application date and validate the error message. ");
            Application.WebCSR.ClickLinkFromMenuItem(Data.Get("Funding Services") + "|" + Data.Get("Transfer Funds"));
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"), null, null, appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", -1));
            Application.WebCSR.VerifytransactionErrorMessageInFundsTransfer(Data.Get("End Date is not allowed."));
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, Data.Get("GLOBAL_AMOUNT_100"), null, null, null);
            Application.WebCSR.VerifySuccessfullTransferFundsMesage();

            Report.Step("Step 14.0:Go to Transfer Funds (Profile Direct WebCSR| Funds Services| Transfer Funds). Perform Funds transfer from SAVACCOUNT1 to SAVACCOUNT2 of amount 10000.Verify Restriction appears for – Transaction exceeds available balance,Transaction exceeds ledger balance,Transaction exceeds collected balance. Override using invalid password. Verify :: Not authorized :: message is displayed after overriding with invalid password.");
            string UserID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            Application.WebCSR.ClickLinkFromMenuItem(Data.Get("Funding Services") + "|" + Data.Get("Transfer Funds"));
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"), "", "", "", true, UserID, appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 5).ToString(), Data.Get("Transaction exceeds available balance") + "|" + Data.Get("Transaction exceeds ledger balance") + "|" + Data.Get("Transaction exceeds collected balance"));
            Application.WebCSR.VerifytransactionErrorMessageInFundsTransfer(Data.Get("Not authorized"));

            Report.Step("Step 15.0:Go to Transfer Funds (Profile Direct WebCSR| Funds Services| Transfer Funds). Perform Funds transfer from SAVACCOUNT1 to SAVACCOUNT2 of amount 10000. Override using invalid User ID. Verify :: Not authorized :: message is displayed after overriding with invalid password.");
            string password = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"), "", "", "", true, appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 5).ToString(), password);
            Application.WebCSR.VerifytransactionErrorMessageInFundsTransfer(Data.Get("Not authorized"));

            Report.Step("Step 16.0:Go to Transfer Funds (Profile Direct WebCSR| Funds Services| Transfer Funds). Perform Funds transfer from SAVACCOUNT1 to SAVACCOUNT2 of amount 10000. Override using valid User ID and validate the Funds Transfer success message.");
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, Data.Get("GLOBAL_AMOUNT_REQUESTED_10K"), "", "", "", true, UserID, password);

            Report.Step("Step 17.0:Verify the error ::no account transactions found in Account History when searched with future dates  SYSDATE_PLUS2Y");
            Application.WebCSR.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Account History"));
            string DATEPLUS2Y=Application.WebCSR.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "Y", 2);
            Application.WebCSR.VerifyNoAccountTransAccountHistoryTable(SAVACCOUNT1,DATEPLUS2Y ,DATEPLUS2Y);

            Report.Step("Step 18.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            

        }
    }
}