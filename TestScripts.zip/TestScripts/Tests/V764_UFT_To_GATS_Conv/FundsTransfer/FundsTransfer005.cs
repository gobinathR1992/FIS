using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter; 
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using NUnit.Framework;
using GTS_CORE.HelperLibs;
using Profile7Automation.BusinessFunctions;


namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.FundsTransfer
{
    [TestFixture]
    public class fundstransfer005:TestBase
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "Verify Error Message “The maximum number of funds transfers per day has been reached.”")]
        public void FundsTransfer005()
        {
            Report.Step(" Step 1.0 : Login WEBADMIN  APPLICATION");
            Application.WebAdmin.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Report.Step("Step 2.0: In Profile WebAdmin Copy a product type from the standard Demand Deposit Product Type 400 (Product Factory | Products - Product Class: D - Deposit Class; Product Group: GLOBAL_DEPOSIT_ACCT_CLASS).");
            string DDAPRO1 = Application.WebAdmin.EnterCopyProductDefinitionDetails(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"), Data.Get("GLOBAL_STD_PROD_NUM_400"), true);

            Report.Step("Step 3.0: Navigate to Transaction Processing Page and Update Maximum Funds Transfers Per Day as:2 ");
            Application.WebAdmin.UpdateMaximumFundsTransferPerDay(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("GLOBAL_DEMANDDEPOSIT_GROUP"),DDAPRO1,"2");

            Report.Step("Step 4.0: Log off from WebAdmin Application.");
            Application.WebAdmin.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));
            Application.WebCSR.ReloadWebCSRapplication(Data.Get("GLOBAL_APPLICATION_WEBCSR"));
            Application.WebAdmin.ReloadWebAdminapplication(Data.Get("GLOBAL_APPLICATION_WEBADMIN"));

            Data.Store("DDAPRO1", DDAPRO1);
                       
 
            
        }

               
    }
}