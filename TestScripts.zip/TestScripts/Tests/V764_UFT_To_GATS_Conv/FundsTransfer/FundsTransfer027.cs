using System.Collections.Generic;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using NUnit.Framework;
using OpenQA.Selenium;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.TestScripts.Tests.V764_UFT_To_GATS_Conv.FundsTransfer
{
    [TestFixture]
    public class fundstransfer027 : TestBase
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        [Test]
        [Property(TestType.TestBased, "")]
        [Property("TestDescription", "1.Setting up of Funds Transfers and  WEBCSR-5483 = An additional character <br> is displayed next to the From Account and To Account numbers for Pending Transaction records on Deposit Account Overview page.")]
        public void FundsTransfer027()
        {

            Report.Step("Step 1.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 2.0: Create a new personal customer <CIF1> using the standard product type by entering all mandatory field values Profile Direct WebCSR | Basic Services | Create Personal Customer.)");
            string CIF1 = Application.WebCSR.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));

            Report.Step("Step 3.0:Create multiple accounts for product type 300 <SAVACCOUNT1> and <SAVACCOUNT2> (Profile Direct WebCSR| Basic Services| Create Account).");
            string CombinedAccount = Application.WebCSR.Create_Account(CIF1, Data.Get("GLOBAL_RELATION_SINGLE"), Data.Get("GLOBAL_STAND_CSRPROD_DESC_300"), "", 2, Data.Get("Account Name") + "|" + "SAVACCT1;" + Data.Get("Account Name") + "|" + "SAVACCT2");
            string SAVACCOUNT1 = appHandle.SplitString(CombinedAccount, "-")[0];
            string SAVACCOUNT2 = appHandle.SplitString(CombinedAccount, "-")[1];

            Report.Step("Step 4.0: Logout from WEBCSR Application.");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 5.0: Login to Profile Teller.");
            Application.Teller.login_specified_application("Teller");

            Report.Step("Step 6.0 : Post a deposit transaction to the SAVACCOUNT1 of  20,000.00 using transaction code SD. Offset the transaction using transaction code CI (Cash In)");
            Application.Teller.DepositFunds(SAVACCOUNT1, Data.Get("GLOBAL_AMOUNT_REQUESTED_20K"));

            Report.Step("Step 7.0:Logout from PDTeller  Application.");
            Application.Teller.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_PDTELLER"));

            Report.Step("Step 8.0: Login to WEBCSR  Application.");
            Application.WebCSR.login_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));

            Report.Step("Step 9.0:Navigate to <SAVACCOUNT1> account summary page.Go to Transfer Funds (Profile Direct WebCSR| Funds Services| Transfer Funds). Perform Funds transfer from SAVACCOUNT1 to SAVACCOUNT2 .Enter Amount of 999 . Frequency: Monthly . Start Date: SYSTEMDATEPLUS1D . End Date: SYSTEMDATEPLUS183D");
            string TranactionAmount = appHandle.CreateRamdomData(FieldType.NUMERIC, 111, 999, 3) + "." + appHandle.CreateRamdomData(FieldType.NUMERIC, 11, 99, 2) + "";
            string SYSTEMDATEPLUS1D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 1);
            string SYSTEMDATEPLUS183D = appHandle.CalculateNewDate(Application.WebCSR.GetApplicationDate(), "D", 183);
            Application.WebCSR.LoadAccountSummaryPage(SAVACCOUNT1);
            Application.WebCSR.TrasferFundsFundingServices(SAVACCOUNT1, SAVACCOUNT2, TranactionAmount, SYSTEMDATEPLUS1D, Data.Get("Monthly"), SYSTEMDATEPLUS183D);
            

            Report.Step("Step 10.0:Verify transaction is successfully completed. Verify From Account, To Account , Amount, Start Date , End Date , Frequency as per the completed transaction.");
            Application.WebCSR.VerifySuccessfullTransferFundsMesage();
            Application.WebCSR.VerifyTransactionInTableTransferFundsConfirmationPage(Data.Get("From Account") + "|" + SAVACCOUNT1 + ";" + Data.Get("To Account") + "|" + SAVACCOUNT2 + ";" + Data.Get("Amount") + "|" + TranactionAmount + ";" + Data.Get("Start Date") + "|" + SYSTEMDATEPLUS1D + ";" + Data.Get("End Date") + "|" + SYSTEMDATEPLUS183D + ";" + Data.Get("Frequency") + "|" + Data.Get("Monthly"));

            Report.Step("Step 11.0: Go to Pending Transfers Profile Direct WebCSR| Funds Services| PendingTransfers. Validate the transactions in Pending tranactions table.");
            Application.WebCSR.ClickLinkFromMenuItem(Data.Get("Funding Services") + "|" + Data.Get("Pending Transfers"));
            Application.WebCSR.VerifyTransactionsInPendingTransfersTable(SAVACCOUNT1 + ";" + SAVACCOUNT2 + ";" + TranactionAmount + ";" + SYSTEMDATEPLUS1D + ";" + Data.Get("Monthly"));

            Report.Step("Step 12.0: Logout from WEBCSR Application");
            Application.WebCSR.logoff_specified_application(Data.Get("GLOBAL_APPLICATION_WEBCSR"));



        }
    }
}