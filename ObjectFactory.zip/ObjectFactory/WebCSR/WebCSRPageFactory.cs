﻿using System.Diagnostics;
using GTS_OSAF.Config;
using Profile7Automation.ObjectFactory.WebCSR.Pages;

using Spring.Aop.Framework;

namespace Profile7Automation.ObjectFactory.WebCSR
{
    [DebuggerStepThrough]
    public static class WebCSRPageFactory
    {
        public static LoginPage LoginPage { get => (LoginPage)ClassRegister.Get(typeof(LoginPage)); }
        public static CreatePersonalCustomerPage CreatePersonalCustomerPage { get => (CreatePersonalCustomerPage)GTS_OSAF.Config.ClassRegister.Get(typeof(CreatePersonalCustomerPage)); }
        public static VerifyCreatePersonalCustomerPage VerifyCreatePersonalCustomerPage { get => (VerifyCreatePersonalCustomerPage)GTS_OSAF.Config.ClassRegister.Get(typeof(VerifyCreatePersonalCustomerPage)); }
        public static WebCSRMasterPage WebCSRMasterPage { get => (WebCSRMasterPage)ClassRegister.Get(typeof(WebCSRMasterPage)); }
        public static CustomerSearchPage CustomerSearchPage { get => (CustomerSearchPage)ClassRegister.Get(typeof(CustomerSearchPage)); }
        public static CreateAccountPage CreateAccountPage { get => (CreateAccountPage)ClassRegister.Get(typeof(CreateAccountPage)); }
        public static VerifyCustomerPage VerifyCustomerPage { get => (VerifyCustomerPage)ClassRegister.Get(typeof(VerifyCustomerPage)); }
        public static AccountOverviewPage AccountOverviewPage { get => (AccountOverviewPage)ClassRegister.Get(typeof(AccountOverviewPage)); }
        public static AccountHistoryPage AccountHistoryPage { get => (AccountHistoryPage)ClassRegister.Get(typeof(AccountHistoryPage)); }
        public static AccountSummaryPage AccountSummaryPage { get => (AccountSummaryPage)ClassRegister.Get(typeof(AccountSummaryPage)); }
        public static CreateCorporateCustomerPage CreateCorporateCustomerPage { get => (CreateCorporateCustomerPage)ClassRegister.Get(typeof(CreateCorporateCustomerPage)); }
        public static FundTransferPage FundTransferPage { get => (FundTransferPage)ClassRegister.Get(typeof(FundTransferPage)); }
        public static PendingTransferPage PendingTransferPage { get => (PendingTransferPage)ClassRegister.Get(typeof(PendingTransferPage)); }
        public static CustomerHistoryPage CustomerHistoryPage { get => (CustomerHistoryPage)ClassRegister.Get(typeof(CustomerHistoryPage)); }
        public static CustomerInformationPage CustomerInformationPage { get => (CustomerInformationPage)ClassRegister.Get(typeof(CustomerInformationPage)); }
        public static AccountListPage AccountListPage { get => (AccountListPage)ClassRegister.Get(typeof(AccountListPage)); }
        public static AccountInformationPage AccountInformationPage { get => (AccountInformationPage)ClassRegister.Get(typeof(AccountInformationPage)); }
        public static LoanPaymentTabPage LoanPaymentTabPage { get => (LoanPaymentTabPage)ClassRegister.Get(typeof(LoanPaymentTabPage)); }
        public static LoanPaymentDetailPage LoanPaymentDetailPage { get => (LoanPaymentDetailPage)ClassRegister.Get(typeof(LoanPaymentDetailPage)); }
        public static LoanInterestTab LoanInterestTab { get => (LoanInterestTab)ClassRegister.Get(typeof(LoanInterestTab)); }
        public static LoanCalculationOptionsPage LoanCalculationOptionsPage { get => (LoanCalculationOptionsPage)ClassRegister.Get(typeof(LoanCalculationOptionsPage)); }
        public static TransactionProcessingPage TransactionProcessingPage { get => (TransactionProcessingPage)ClassRegister.Get(typeof(TransactionProcessingPage)); }
        public static DepositTransactionProcessingGeneralPage DepositTransactionProcessingGeneralPage { get => (DepositTransactionProcessingGeneralPage)ClassRegister.Get(typeof(DepositTransactionProcessingGeneralPage)); }
        public static AccountVerificationPage AccountVerificationPage { get => (AccountVerificationPage)ClassRegister.Get(typeof(AccountVerificationPage)); }
        public static AddBeneficiaryPage AddBeneficiaryPage { get => (AddBeneficiaryPage)ClassRegister.Get(typeof(AddBeneficiaryPage)); }
        public static BankingCenterPage BankingCenterPage { get => (BankingCenterPage)ClassRegister.Get(typeof(BankingCenterPage)); }
        public static StatementGroupPage StatementGroupPage { get => (StatementGroupPage)ClassRegister.Get(typeof(StatementGroupPage)); }
        public static UpdateStatementGroupPage UpdateStatementGroupPage { get => (UpdateStatementGroupPage)ClassRegister.Get(typeof(UpdateStatementGroupPage)); }
        public static DomesticPaymentPage DomesticPaymentPage { get => (DomesticPaymentPage)ClassRegister.Get(typeof(DomesticPaymentPage)); }
        public static DomesticPaymentAddPage DomesticPaymentAddPage { get => (DomesticPaymentAddPage)ClassRegister.Get(typeof(DomesticPaymentAddPage)); }

        public static DomesticPaymentAddPaymentOrderPage DomesticPaymentAddPaymentOrderPage { get => (DomesticPaymentAddPaymentOrderPage)ClassRegister.Get(typeof(DomesticPaymentAddPaymentOrderPage)); }

        public static CreateRetirementPlanPage CreateRetirementPlanPage { get => (CreateRetirementPlanPage)ClassRegister.Get(typeof(CreateRetirementPlanPage)); }

        public static AddDeathBeneficiariesPage AddDeathBeneficiariesPage { get => (AddDeathBeneficiariesPage)ClassRegister.Get(typeof(AddDeathBeneficiariesPage)); }
        public static DepositAccountOverviewPage DepositAccountOverviewPage { get => (DepositAccountOverviewPage)ClassRegister.Get(typeof(DepositAccountOverviewPage)); }
        public static HoldsPage HoldsPage { get => (HoldsPage)ClassRegister.Get(typeof(HoldsPage)); }
        public static CustomerAccountsCreatedPage CustomerAccountsCreatedPage { get => (CustomerAccountsCreatedPage)ClassRegister.Get(typeof(CustomerAccountsCreatedPage)); }
        public static CreateTrustCustomerPage CreateTrustCustomerPage { get => (CreateTrustCustomerPage)ClassRegister.Get(typeof(CreateTrustCustomerPage)); }
        public static CreateAccountRelationshipPage CreateAccountRelationshipPage { get => (CreateAccountRelationshipPage)ClassRegister.Get(typeof(CreateAccountRelationshipPage)); }
        public static AddHoldPage AddHoldPage { get => (AddHoldPage)ClassRegister.Get(typeof(AddHoldPage)); }
        public static AuthorizationOverrideRequiredPage AuthorizationOverrideRequiredPage { get => (AuthorizationOverrideRequiredPage)ClassRegister.Get(typeof(AuthorizationOverrideRequiredPage)); }
        public static SecurityPage SecurityPage { get => (SecurityPage)ClassRegister.Get(typeof(SecurityPage)); }
        public static SelectPackagePage SelectPackagePage { get => (SelectPackagePage)ClassRegister.Get(typeof(SelectPackagePage)); }
        public static CreateAccounSelectAccountsPage CreateAccounSelectAccountsPage { get => (CreateAccounSelectAccountsPage)ClassRegister.Get(typeof(CreateAccounSelectAccountsPage)); }
        public static CreateRetirementAccountInformationPage CreateRetirementAccountInformationPage { get => (CreateRetirementAccountInformationPage)ClassRegister.Get(typeof(CreateRetirementAccountInformationPage)); }
        public static CreateRetirementAccountSelectAccountsPage CreateRetirementAccountSelectAccountsPage { get => (CreateRetirementAccountSelectAccountsPage)ClassRegister.Get(typeof(CreateRetirementAccountSelectAccountsPage)); }
        public static CreateDepositAccountInformationPage CreateDepositAccountInformationPage { get => (CreateDepositAccountInformationPage)ClassRegister.Get(typeof(CreateDepositAccountInformationPage)); }
        public static CreateLoanAccountInformationPage CreateLoanAccountInformationPage { get => (CreateLoanAccountInformationPage)ClassRegister.Get(typeof(CreateLoanAccountInformationPage)); }
        public static TargetBalanceAccountsPage TargetBalanceAccountsPage { get => (TargetBalanceAccountsPage)ClassRegister.Get(typeof(TargetBalanceAccountsPage)); }
        public static PaymentApplicationPage PaymentApplicationPage { get => (PaymentApplicationPage)ClassRegister.Get(typeof(PaymentApplicationPage)); }
        public static EFDRateChangePage EFDRateChangePage { get => (EFDRateChangePage)ClassRegister.Get(typeof(EFDRateChangePage)); }
        public static DepositRateDeterminationPage DepositRateDeterminationPage { get => (DepositRateDeterminationPage)ClassRegister.Get(typeof(DepositRateDeterminationPage)); }
        public static LoanRateDeterminationPage LoanRateDeterminationPage { get => (LoanRateDeterminationPage)ClassRegister.Get(typeof(LoanRateDeterminationPage)); }
        public static FDIC370InformationPage FDIC370InformationPage { get => (FDIC370InformationPage)ClassRegister.Get(typeof(FDIC370InformationPage)); }
        public static BeneficiariesPage BeneficiariesPage { get => (BeneficiariesPage)ClassRegister.Get(typeof(BeneficiariesPage)); }
        public static BeneficiarySearchPage BeneficiarySearchPage { get => (BeneficiarySearchPage)ClassRegister.Get(typeof(BeneficiarySearchPage)); }
        public static AccountActivityPage AccountActivityPage { get => (AccountActivityPage)ClassRegister.Get(typeof(AccountActivityPage)); }
        public static paymentcalculationpage paymentcalculationpage { get => (paymentcalculationpage)ClassRegister.Get(typeof(paymentcalculationpage)); }
        public static LoanMaturityPayoffPage LoanMaturityPayoffPage { get => (LoanMaturityPayoffPage)ClassRegister.Get(typeof(LoanMaturityPayoffPage)); }
        public static Unpaidpaymentspage Unpaidpaymentspage { get => (Unpaidpaymentspage)ClassRegister.Get(typeof(Unpaidpaymentspage)); }
        public static Editunpaidpaymentspage Editunpaidpaymentspage { get => (Editunpaidpaymentspage)ClassRegister.Get(typeof(Editunpaidpaymentspage)); }
        public static LoanRevolvingOptionsPage LoanRevolvingOptionsPage { get => (LoanRevolvingOptionsPage)ClassRegister.Get(typeof(LoanRevolvingOptionsPage)); }
        public static DepositAccountProductTransferPage DepositAccountProductTransferPage { get => (DepositAccountProductTransferPage)ClassRegister.Get(typeof(DepositAccountProductTransferPage)); }
        public static AddBeneficialOwnerstoCreateCorporateCustomerPage AddBeneficialOwnerstoCreateCorporateCustomerPage { get => (AddBeneficialOwnerstoCreateCorporateCustomerPage)ClassRegister.Get(typeof(AddBeneficialOwnerstoCreateCorporateCustomerPage)); }
        public static BeneficialOwnersInformationProviderPage BeneficialOwnersInformationProviderPage { get => (BeneficialOwnersInformationProviderPage)ClassRegister.Get(typeof(BeneficialOwnersInformationProviderPage)); }
        public static LoanAccountOverviewPage LoanAccountOverviewPage { get => (LoanAccountOverviewPage)ClassRegister.Get(typeof(LoanAccountOverviewPage)); }
        public static PaymentSnapshotPage PaymentSnapshotPage { get => (PaymentSnapshotPage)ClassRegister.Get(typeof(PaymentSnapshotPage)); }
        public static BillingStatementPage BillingStatementPage { get => (BillingStatementPage)ClassRegister.Get(typeof(BillingStatementPage)); }
        public static BillingStatementDetailPage BillingStatementDetailPage { get => (BillingStatementDetailPage)ClassRegister.Get(typeof(BillingStatementDetailPage)); }
        public static AddunpaidpaymentsPage AddunpaidpaymentsPage { get => (AddunpaidpaymentsPage)ClassRegister.Get(typeof(AddunpaidpaymentsPage)); }
        public static AccountRestrictionPage AccountRestrictionPage { get => (AccountRestrictionPage)ClassRegister.Get(typeof(AccountRestrictionPage)); }
        public static ServiceItemAssignmentPage ServiceItemAssignmentPage { get => (ServiceItemAssignmentPage)ClassRegister.Get(typeof(ServiceItemAssignmentPage)); }
        public static AddressPage AddressPage { get => (AddressPage)ClassRegister.Get(typeof(AddressPage)); }
        public static CustomerServicesServiceManagementPage CustomerServicesServiceManagementPage { get => (CustomerServicesServiceManagementPage)ClassRegister.Get(typeof(CustomerServicesServiceManagementPage)); }
        public static AccountClosureUtilityPage AccountClosureUtilityPage { get => (AccountClosureUtilityPage)ClassRegister.Get(typeof(AccountClosureUtilityPage)); }
        public static LoanCorrectionsPage LoanCorrectionsPage { get => (LoanCorrectionsPage)ClassRegister.Get(typeof(LoanCorrectionsPage)); }
        public static DelinquencyPaymentPerformancePage DelinquencyPaymentPerformancePage { get => (DelinquencyPaymentPerformancePage)ClassRegister.Get(typeof(DelinquencyPaymentPerformancePage)); }

        public static DepositAccountOverdraftProtectionPage DepositAccountOverdraftProtectionPage { get => (DepositAccountOverdraftProtectionPage)ClassRegister.Get(typeof(DepositAccountOverdraftProtectionPage)); }
        public static USRegulatoryPage USRegulatoryPage { get => (USRegulatoryPage)ClassRegister.Get(typeof(USRegulatoryPage)); }
        public static LoanAccountServicesProjectedActivityPage LoanAccountServicesProjectedActivityPage { get => (LoanAccountServicesProjectedActivityPage)ClassRegister.Get(typeof(LoanAccountServicesProjectedActivityPage)); }
        public static DepositAccountServicesInvestmentSweepPage DepositAccountServicesInvestmentSweepPage { get => (DepositAccountServicesInvestmentSweepPage)ClassRegister.Get(typeof(DepositAccountServicesInvestmentSweepPage)); }
        public static RenewalProcessingPage RenewalProcessingPage { get => (RenewalProcessingPage)ClassRegister.Get(typeof(RenewalProcessingPage)); }
        public static DepositInterestAccrualPage DepositInterestAccrualPage { get => (DepositInterestAccrualPage)ClassRegister.Get(typeof(DepositInterestAccrualPage)); }
        public static DepositPaymentPage DepositPaymentPage { get => (DepositPaymentPage)ClassRegister.Get(typeof(DepositPaymentPage)); }
        public static OverdraftProcessingPage OverdraftProcessingPage { get => (OverdraftProcessingPage)ClassRegister.Get(typeof(OverdraftProcessingPage)); }
        public static AccountNotesPage AccountNotesPage { get => (AccountNotesPage)ClassRegister.Get(typeof(AccountNotesPage)); }
        public static CreateRetirementAccountPage CreateRetirementAccountPage { get => (CreateRetirementAccountPage)ClassRegister.Get(typeof(CreateRetirementAccountPage)); }
        public static LoanTitleAddressPage LoanTitleAddressPage { get => (LoanTitleAddressPage)ClassRegister.Get(typeof(LoanTitleAddressPage));}
        public static CustomerServicesAlertManagementPage CustomerServicesAlertManagementPage { get => (CustomerServicesAlertManagementPage)ClassRegister.Get(typeof(CustomerServicesAlertManagementPage));} 
        public static CustomerInformationAddressChangePage CustomerInformationAddressChangePage { get => (CustomerInformationAddressChangePage)ClassRegister.Get(typeof(CustomerInformationAddressChangePage));}
        public static CustomerInformationSeasonalAddressPage CustomerInformationSeasonalAddressPage { get => (CustomerInformationSeasonalAddressPage)ClassRegister.Get(typeof(CustomerInformationSeasonalAddressPage));}
        public static LoanServicememberProtectionsPage LoanServicememberProtectionsPage { get => (LoanServicememberProtectionsPage)ClassRegister.Get(typeof(LoanServicememberProtectionsPage)); }
        public static DebitAuthorizationPage DebitAuthorizationPage { get => (DebitAuthorizationPage)ClassRegister.Get(typeof(DebitAuthorizationPage)); } 
        public static CustomerInformationResidencyPage CustomerInformationResidencyPage { get =>(CustomerInformationResidencyPage)ClassRegister.Get(typeof(CustomerInformationResidencyPage));}
        public static LoanPaymentPaymentApplicationPage LoanPaymentPaymentApplicationPage { get => (LoanPaymentPaymentApplicationPage)ClassRegister.Get(typeof(LoanPaymentPaymentApplicationPage)); }
        public static LoanTransactionProcessingPage LoanTransactionProcessingPage { get => (LoanTransactionProcessingPage)ClassRegister.Get(typeof(LoanTransactionProcessingPage)); }
        public static DepositAccountInformationPage DepositAccountInformationPage { get => (DepositAccountInformationPage)ClassRegister.Get(typeof(DepositAccountInformationPage)); }
        public static DepositAccountEFDRateChangePage DepositAccountEFDRateChangePage { get => (DepositAccountEFDRateChangePage)ClassRegister.Get(typeof(DepositAccountEFDRateChangePage)); }
        public static RetairementServicesPage RetairementServicesPage { get => (RetairementServicesPage)ClassRegister.Get(typeof(RetairementServicesPage));}
        public static AccontServicesRelationshipsPage AccontServicesRelationshipsPage { get =>(AccontServicesRelationshipsPage)ClassRegister.Get(typeof(AccontServicesRelationshipsPage));}
        public static DepositWithholdingPage DepositWithholdingPage { get =>(DepositWithholdingPage)ClassRegister.Get(typeof(DepositWithholdingPage));}
        public static UtilityExceptionProcessingPage UtilityExceptionProcessingPage { get => (UtilityExceptionProcessingPage)ClassRegister.Get(typeof(UtilityExceptionProcessingPage)); } 
        public static ExternalAccountsPage ExternalAccountsPage { get => (ExternalAccountsPage)ClassRegister.Get(typeof(ExternalAccountsPage)); } 

        //public static DepositAccountInformationPage DepositAccountInformationPage { get => (DepositAccountInformationPage)ClassRegister.Get(typeof(DepositAccountInformationPage)); }
        public static EditSatementGroupPage EditSatementGroupPage { get => (EditSatementGroupPage)ClassRegister.Get(typeof(EditSatementGroupPage)); }

        //public static ExternalAccountsPage ExternalAccountsPage { get => (ExternalAccountsPage)ClassRegister.Get(typeof(ExternalAccountsPage)); }

        public static ServiceManagementPage ServiceManagementPage { get => (ServiceManagementPage)ClassRegister.Get(typeof(ServiceManagementPage)); }
        public static IRS1042SReportingCorrectionPage IRS1042SReportingCorrectionPage { get => (IRS1042SReportingCorrectionPage)ClassRegister.Get(typeof(IRS1042SReportingCorrectionPage)); }   
        public static NameChangePage NameChangePage { get => (NameChangePage)ClassRegister.Get(typeof(NameChangePage)); }
        public static DepositAccountFeePage DepositAccountFeePage { get => (DepositAccountFeePage)ClassRegister.Get(typeof(DepositAccountFeePage));}
        public static Form8966ReportCorrectionPage Form8966ReportCorrectionPage { get => (Form8966ReportCorrectionPage)ClassRegister.Get(typeof(Form8966ReportCorrectionPage));}
        public static CardManagementPage CardManagementPage { get => (CardManagementPage)ClassRegister.Get(typeof(CardManagementPage));}
        public static RetirementTransactionCorrectionsPage RetirementTransactionCorrectionsPage { get => (RetirementTransactionCorrectionsPage)ClassRegister.Get(typeof(RetirementTransactionCorrectionsPage));}

        public static AdjustablePaymentCalculationPage AdjustablePaymentCalculationPage { get => (AdjustablePaymentCalculationPage)ClassRegister.Get(typeof(AdjustablePaymentCalculationPage)); }
        public static PurchasedImpairedLoanPage PurchasedImpairedLoanPage { get => (PurchasedImpairedLoanPage)ClassRegister.Get(typeof(PurchasedImpairedLoanPage)); }
        
        public static PaymentDetailPage PaymentDetailPage { get => (PaymentDetailPage)ClassRegister.Get(typeof(PaymentDetailPage)); }
        public static LoanRateChangesPage LoanRateChangesPage { get => (LoanRateChangesPage)ClassRegister.Get(typeof(LoanRateChangesPage)); }
        public static PurchasedImpairedLoanSOP3Page PurchasedImpairedLoanSOP3Page { get => (PurchasedImpairedLoanSOP3Page)ClassRegister.Get(typeof(PurchasedImpairedLoanSOP3Page)); }
        public static ChexSystemsDataPage ChexSystemsDataPage { get => (ChexSystemsDataPage)ClassRegister.Get(typeof(ChexSystemsDataPage)); }
        public static AccountInformationPenaltyPage AccountInformationPenaltyPage { get => (AccountInformationPenaltyPage)ClassRegister.Get(typeof(AccountInformationPenaltyPage)); }
        public static AccountInformationInterestAccrualPage AccountInformationInterestAccrualPage { get => (AccountInformationInterestAccrualPage)ClassRegister.Get(typeof(AccountInformationInterestAccrualPage)); }
        public static StopsPage StopsPage { get => (StopsPage)ClassRegister.Get(typeof(StopsPage)); }
        public static MaturityPage MaturityPage { get => (MaturityPage)ClassRegister.Get(typeof(MaturityPage)); }
        public static DepositProductServiceFeesPage DepositProductServiceFeesPage { get => (DepositProductServiceFeesPage)ClassRegister.Get(typeof(DepositProductServiceFeesPage)); }
        public static CreateTrustAccountPage CreateTrustAccountPage { get => (CreateTrustAccountPage)ClassRegister.Get(typeof(CreateTrustAccountPage)); }
        public static AccountInformationFeesPage AccountInformationFeesPage { get => (AccountInformationFeesPage)ClassRegister.Get(typeof(AccountInformationFeesPage)); } 
        public static AddEscrowDetailsPage AddEscrowDetailsPage { get => (AddEscrowDetailsPage)ClassRegister.Get(typeof(AddEscrowDetailsPage)); } 
        public static UtilitiesInterestIndexSummaryPage UtilitiesInterestIndexSummaryPage { get => (UtilitiesInterestIndexSummaryPage)ClassRegister.Get(typeof(UtilitiesInterestIndexSummaryPage)); } 
        public static IRAMoneyMovementPage IRAMoneyMovementPage { get => (IRAMoneyMovementPage)ClassRegister.Get(typeof(IRAMoneyMovementPage)); } 
        public static FDIC370Page FDIC370Page {get => (FDIC370Page)ClassRegister.Get(typeof(FDIC370Page));}
        public static LoanFeePage LoanFeePage {get => (LoanFeePage)ClassRegister.Get(typeof(LoanFeePage));}
        public static CustomerRestrictionPage CustomerRestrictionPage {get => (CustomerRestrictionPage)ClassRegister.Get(typeof(CustomerRestrictionPage));}
        
        public static DelinquencyNonaccrualPage DelinquencyNonaccrualPage { get => (DelinquencyNonaccrualPage)ClassRegister.Get(typeof(DelinquencyNonaccrualPage)); }
        public static LoanAccountServicesPaymentChangePage LoanAccountServicesPaymentChangePage { get => (LoanAccountServicesPaymentChangePage)ClassRegister.Get(typeof(LoanAccountServicesPaymentChangePage)); }
        public static LoanCommitmentProcessingPage LoanCommitmentProcessingPage { get => (LoanCommitmentProcessingPage)ClassRegister.Get(typeof(LoanCommitmentProcessingPage)); }
        public static LoanCalculatorPage LoanCalculatorPage { get => (LoanCalculatorPage)ClassRegister.Get(typeof(LoanCalculatorPage)); }
        public static DepositTitleAddressPage DepositTitleAddressPage { get => (DepositTitleAddressPage)ClassRegister.Get(typeof(DepositTitleAddressPage));}

        public static LoanCapitalizationPage LoanCapitalizationPage {get => (LoanCapitalizationPage)ClassRegister.Get(typeof(LoanCapitalizationPage));}
        public static MakerAndCheckerLitePage MakerAndCheckerLitePage {get => (MakerAndCheckerLitePage)ClassRegister.Get(typeof(MakerAndCheckerLitePage));}
        
    }
}

