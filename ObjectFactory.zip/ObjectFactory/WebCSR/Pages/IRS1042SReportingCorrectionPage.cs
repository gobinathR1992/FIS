using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class IRS1042SReportingCorrectionPage
    { 
        public static WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        
        private static string AccountDropdown = "XPath;//td/select[@name='accountNumber']";
        private static string drptaxyear = "XPath;//select[@name='taxYear']";
        private static string drpcountrycode = "XPath;//*[contains(text(),'Nonresident Country Code:')]/following-sibling::*/descendant::select[1]";
        private static string Submit_Button = "XPath;//input[@value='Submit']";
        private static string AmendButton = "XPath;//input[@value='Amend']";   
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string txtwithholdingpercentage = "Xpath;//input[@name ='backupWithholdingPercentage']";
        private static string TaxInformation1042SFileTable="Xpath;.//*[contains(@class,'ledgerScrollable dataTable')]/tbody";  
        
        public virtual bool VerifyAccountExistsInAccountDropdown(string AccountNumber)
        {
            bool Result = false;
            string temp = applicationHandle.GetObjectText(AccountDropdown + "/parent::*[1]");
            if (temp.Contains(AccountNumber))
            {
                Result = true;
            }

            return Result;
        }
        public virtual void UpdateDataInIRS1042SReportingCorrection(string AccountNumber,string taxyear ,string date,string percentage,string countrycode="")
        {            
            applicationHandle.SelectDropdownSpecifiedValueByPartialText(AccountDropdown, AccountNumber);
            applicationHandle.Wait_For_Specified_Time(5);
            if (!string.IsNullOrEmpty(taxyear))
            {
                applicationHandle.SelectDropdownSpecifiedValueByPartialText(drptaxyear, taxyear);
            }
            applicationHandle.SelectRadioButtonInTable(TaxInformation1042SFileTable,date);
            ClickOnAmendButton();
            if (!string.IsNullOrEmpty(percentage))
            {
                applicationHandle.Set_field_value(txtwithholdingpercentage, percentage);
            }
             if (!string.IsNullOrEmpty(countrycode))
            {
                applicationHandle.SelectDropdownSpecifiedValueByPartialText(drpcountrycode, countrycode);
            }
            ClickOnSubmitButton();            
        }

        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Submit_Button))
            {
                applicationHandle.ClickObjectViaJavaScript(Submit_Button);
            }
        }
        public virtual void ClickOnAmendButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(AmendButton))
            {
                applicationHandle.ClickObjectViaJavaScript(AmendButton);
            }
        }
         public virtual bool VerifyMessageInstitutionVariable(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (applicationHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

    }
}