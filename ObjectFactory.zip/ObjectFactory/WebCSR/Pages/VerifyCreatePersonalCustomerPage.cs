using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class VerifyCreatePersonalCustomerPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string txt_SuccessMessage = "Xpath;//p[contains(text(),'The application was successfully processed.')]";
        private static string txt_FailureErrorMessage = "Xpath;//p[contains(text(),'Failed')]";
        
        private static string Submit_Button = "Xpath;//input[@value='Submit']";
        private static string Cancel_Button = "Xpath;//input[@value='Cancel']";
        private static string Back_Button = "Xpath;//input[@value='Back']";
        public virtual void select_submit_button()
        {
            appHandle.Wait_for_object(Cancel_Button,3);
            appHandle.SelectButton(Submit_Button);
            appHandle.Wait_For_Specified_Time(5);
        }
        public virtual void select_cancel_button()
        {
            appHandle.Wait_for_object(Cancel_Button,3);
            appHandle.SelectButton(Cancel_Button);
        }
        public virtual void select_back_button()
        {
            appHandle.Wait_for_object(Back_Button,3);
            appHandle.SelectButton(Back_Button);
        }        
        
        // To check the Successfully Created Confirmation Message exists or not
        public virtual bool verify_seccessfully_created_confirmation_message_exist()
        {
            bool blnSuccess = false;
            if (appHandle.IsObjectExists(txt_SuccessMessage))
            {
                blnSuccess = true;
            }
            else
            {                
                blnSuccess = false;
            }                
            return blnSuccess;
        }

        // To check the Failure Error Message exists or not
        public virtual bool verify_failure_error_message_exist()
        {
            bool blnSuccess = false;
            if (appHandle.IsObjectExists(txt_FailureErrorMessage))
            {
                blnSuccess = true;
            }
            else
            {                
                blnSuccess = false;
            }                
            return blnSuccess;
        }

    }

}