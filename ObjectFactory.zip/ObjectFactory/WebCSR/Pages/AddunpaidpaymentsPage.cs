
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AddunpaidpaymentsPage
    {
        public static string txtUnpaidPrincipal = "XPath;//input[@name='LNBIL1_PE02AD']";
        public static string txtPaymentRecordDueDate = "XPath;//input[@name='LNBIL1_CDPD']";
        public static string txtPrincipalInterestUnpaid = "XPath;//input[@name='LNBIL1_PE01AD']";
    }
}