using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class PaymentDetailPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtPrincipalAndInterestAmount="XPath;//input[@name='LN_PMTPI']";
        public static string txtfrequency = "Xpath;//input[@name= 'LN_DIST1FRE']";
        private static string btnsubmit = "Xpath;//input[@name='submit']";
        public virtual string GetPIAmountValue()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPrincipalAndInterestAmount);
            return appHandle.GetEditFieldValue(txtPrincipalAndInterestAmount);
        }

        public virtual void UpdatePaymentDetails(string frequency)
        {
            if(!string.IsNullOrEmpty(frequency))
            {
                appHandle.Set_field_value(txtfrequency,frequency);
            }
            appHandle.ClickObjectViaJavaScript(btnsubmit);
        }
                

    }
}
