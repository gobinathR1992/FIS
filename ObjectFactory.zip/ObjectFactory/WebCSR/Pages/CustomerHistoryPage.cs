using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Threading;
using GTS_OSAF;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CustomerHistoryPage
    {
        WebApplication appHandle;
        public static string identityGotoDropDown = "Xpath;//select [@name='nextpage']";
        public static string SubmitButton = "Xpath;//input[@name='submit']";
        public static string CustomerHistoryServicesHistoryLink= "Xpath;//td[@class='menuSub'][contains(text(),'History')]";
        public static string CustomerHistoryTable="Xpath;.//*[contains(@class,'dataTables_scroll')]";
        public static string Buttonclose = "Xpath;//*[@class='ui-icon ui-icon-closethick']";
        public static string drpdwnAccountNumber ="Xpath;//select[@name='accountNumber']";
        public static string CustomerHistoryPopupwindow="Xpath;//div[@class='ui-dialog-titlebar ui-widget-header ui-helper-clearfix']//following::table/tbody/tr[3]/td/table/tbody";
        private static string tableContent = "Xpath;//table[@class='contentTable']/tbody";             
       public virtual void NavigateToCustomerHistoryPage()
       {
        try{
         appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
         appHandle.SelectDropdownSpecifiedValue(identityGotoDropDown,"Customer Information");
         appHandle.ClickObject(SubmitButton);
         appHandle.SyncPage();
        }
        catch(Exception e)
        {
             Report.Fail(e.Message, "NavigateToCustomerHistoryPage Exception", appHandle);
        }

       }
       public virtual void VerifyCustomerHistory(string HistoryLinkName)
       {
        appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        appHandle.SelectLinkInLabel(CustomerHistoryTable,HistoryLinkName);
        //  appHandle.Select_link (CustomerHistoryServicesHistoryLink);
        //  appHandle.SyncPage();        
        //  appHandle.SyncPage();
        //  appHandle.Wait_For_Specified_Time(5000);
        // Switch to Pop Up and verify Customer Number;Reference Number;Description;Posting Date;User ID/
        //Also Close the Pop Up Browser
        // Needs to be updated
        // appHandle.SwitchWindow();
   
       }
public virtual void selectAccountFromDropDown(string account)
        {
            try
            { 
                if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpdwnAccountNumber))

                appHandle.SelectDropdownSpecifiedValueByPartialText(drpdwnAccountNumber, account);
                           
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
 public virtual void ClickonLink(string sDescription)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            
                
            string linkDescription = "Xpath;//*[@class='dataTables_scrollBody']/descendant::tbody//td[contains(.,'" + sDescription + "')]";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkDescription))
            {
                
                appHandle.ClickObjectWithOutJavaScript(linkDescription);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(CustomerHistoryPopupwindow);
            }

        }
       
        public virtual bool ValidateValueofPopupWindow(string RefValuesPipeDelimited)
        { 
            int matchcounter=0;
            string FeildName ="";
            string FeildValue ="";
            RefValuesPipeDelimited=RefValuesPipeDelimited+";";
             // string[] arr= null;
            string[] arr=RefValuesPipeDelimited.Split(';');
            bool Result = false;
             // arr=RefValues.Split('|');
            for(int i=0;i<arr.Length-1;i++)
            {
                 // if(Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue())
                 // {

                 // }
                
                
                
                 FeildName=arr[i].Split('|')[0];
                 FeildValue=arr[i].Split('|')[0];
                 if(appHandle.IsObjectExists("Xpath;//*[contains(text(),'"+FeildName+"')]/following::*[contains(text(),'"+FeildValue+"')]"))
                {
                     Result=true;
                }
                 else
                {
                     Result=false;
                     Report.Fail("For "+FeildName+" and "+FeildValue+"is not validated in the customer History");                
                }
                    
             }
            return Result;


        }      
       public virtual void ClosePopup()
        {
            appHandle.ScrollToObject(Buttonclose);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Buttonclose))
            {
                appHandle.ClickObjectViaJavaScript(Buttonclose);

            }
        }    
        public virtual bool VerifyTableDataByLabelNameLabelValue(string sLabelNameLabelValuePipeDelimited,string stabledatavaluepipedelimited="")
        {
            bool Result = false;
            if (!string.IsNullOrEmpty(sLabelNameLabelValuePipeDelimited))
            {
                if (Profile7CommonLibrary.VerifyLabelValueByLabelNameInPopUp(sLabelNameLabelValuePipeDelimited) == true)
                {
                    Result = true;
                }
                else
                {
                    Result = false;
                }
            }
            if (!string.IsNullOrEmpty(stabledatavaluepipedelimited))
            {
                if (Profile7CommonLibrary.VerifyDataInTableByColumnValues(stabledatavaluepipedelimited) == true)
                {
                    Result = true;
                }
                else
                {
                    Result = false;
                }
            }
            return Result;
        }



    }
}