using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class PaymentApplicationPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string drpPaymentAppicationAccount="Xpath;//select[@name='ACN_CID']";
        public static string drpApplicatonRulesPaymentActionGrid="Xpath;//select[@name='LN_PDAG']";
        public static string drpApplicatonRulesPaymentApplicationString="Xpath;//select[@name='LN_PAS']";
        public static string drpApplicatonRulesPaymentApplicationPath="Xpath;//select[@name='LN_PAP']";
        public static string drpApplicationOptionsNegativeBalanceOption="Xpath;//select[@name='LN_NBF']";
        public static string drpApplicationOptionsZeroBalanceOption="Xpath;//select[@name='LN_NOBF']";
        public static string drpApplicationOptionsPaymentMaturityRecalculationOption="Xpath;//select[@name='LN_PMRO']";
        public static string drpApplicationOptionsDirectPrincipalPaymentOption="Xpath;//select[@name='LN_DPPO']";
        public static string drpApplicationOptionsDirectPricipalDebitOption="Xpath;//select[@name='LN_DPDO']";
        public static string drpApplicationOptionsPrepaymentAllowed="Xpath;//select[@name='LN_PPF']";
        public static string drpApplicationMethodsLoanPaymentSweepGrid="Xpath;//select[@name='LN_LPSPDAG']";
        public static string drpApplicationMethodsAutomaticLoanPaymentMethod="Xpath;//select[@name='LN_ALPDUE']";
        public static string drpApplicationMethodsAutomaticLoanPaymentSourceAccount="Xpath;//select[@name='LN_AUPTCID']";
        public static string drpProbLnPaymentAllocationPaymentApplicationMethod="Xpath;//select[@id='LN_PRBLPMT']";
        public static string drpProbLnPaymentAllocationSubAccElement="Xpath;//select[@id='LN_PRBLPMTSA']";
        public static string ckbApplicationOptionsAdvanceDueDatewLateChargePayments="Xpath;//input[@name='LN_ADDLCHG']";
        public static string ckbApplicationOptionsApplyInterestonPrincipalRepayment="Xpath;//input[@name='LN_AIPR']";
        public static string ckbApplicationOptionsIncludePaymentDate="Xpath;//input[@name='LN_IPD']";
        public static string ckbApplicationOptionsExcessPaymentsAllowed="Xpath;//input[@name='LN_EPA']";
        public static string ckbApplicationOptionsPartialPaymentAmount="Xpath;//input[@name='LN_PAF']";
        public static string ckbMatchMissPaymentsAllowed="Xpath;//input[@name='LN_MNM']";
        public static string ckbApplicationOptionsGenerateAccountProjectedActReport="Xpath;//input[@name='LN_GENPRJREP']";
        public static string ckbApplicationMethodsPreauthorizedTransferAllowed="Xpath;//input[@name='LN_PTF']";
        public static string ckbApplicationMethodsEFTPaymentAllowed="Xpath;//input[@name='LN_EFTREQ']";
        public static string ckbApplicationMethodsAutomaticLoanPaymentRetryProcessing="Xpath;//input[@name='LN_ALPRTY']";
        public static string txtApplicationOptionsUnAppliedFundsBalance="Xpath;//input[@name='LN_UNAPF']";
        public static string txtApplicationOptionsPrepaymentsBeforeOverride="Xpath;//input[@name='LN_OLIMIT']";
        public static string txtApplicationOptionsMaximumPrepayments="Xpath;//input[@name='LN_LIMIT']";
        public static string txtApplicationOptionsNumberofDaystoProject="Xpath;//input[@name='LN_NUMDTP']";
        public static string txtApplicationMethodsAutomaticLoanPaymentRetryDays="Xpath;//input[@name='LN_ALPRTYD']";
        public static string txtApplicationMethodsAutomaticLoanPaymentMinimumAmount="Xpath;//input[@name='LN_ALPMIN']";

        
    }
}
