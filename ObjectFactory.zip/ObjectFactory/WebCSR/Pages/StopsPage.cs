using System;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class StopsPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string drpStopsAccount = "Xpath;//*[contains(text(),'Account')]/following-sibling::*/select[contains(@name, 'ZSTOPALL_CID')]";
        private static string buttonAdd = "XPath;//*[contains(@name, 'add')]";
        private static string drpStopAction = "XPath;//select[contains(@name, 'STOP2_ACT')]";
        private static string txtExpDate = "XPath;//input[contains(@name, 'STOP2_EXP')]";
        private static string txtCheckNumber = "XPath;//input[@name='STOP3_CHKNUM']";
        private static string txtACHAmount = "XPAth;//input[@name='STOP5_AMT']";
        private static string linkFindCompany = "XPath;//a[@class='smallLink']";
        private static string txtCheckAmt = "XPath;//input[contains(@name, 'STOP3_AMT')]";
        private static string drpReasonforStop = "XPath;//select[contains(@name, 'STOP2_STPWHY')]";
        private static string buttonSubmit = "Xpath;//*[@name='submit']";
        private static string DeleteButton = "Xpath;.//input[@name='delete']";
        private static string StopTable = "Xpath;.//*[contains(@class,'ledgerScrollable dataTable')]/tbody";
        private static string drpAccountNumber = "//*[contains(text(),'Account')]/following-sibling::*/select[contains(@name, 'STOP2_CID')]";
        private static string txtCompanyNumber = "XPath;//h1[text()='Company Search']/ancestor::tbody[2]/descendant::input[@name='companyNumber']";
        private static string btnSearch = "XPath;//*[@value='Search']";
        private static string drpdownDebitCreditIndicator = "XPath;//select[@name='STOP5_DC']";
        private static string tblcellCompanyFound = "XPath;//*[@class='ledgerScrollable dataTable no-footer']/descendant::td[1]";
        public virtual void SelectAccountFromDropdown(string sAccountNumber)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpStopsAccount))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpStopsAccount, sAccountNumber);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            }

        }

        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual void AddStopsForSpecifiedAccountNumber(string AccountNumber, string StopType, string stopaction, string stopreason, string ExpirationDate = "", string Amount = "", string Companynumber = "", string DebitCreditIndicator = "")
        {
                        this.SelectAccountFromDropdown(AccountNumber);
            this.ClickOnAddButton();
            string RunTimeRadiobutton = "XPath;//*[contains(text(),'" + StopType + "')]/ancestor::tr[1]/descendant::*[@type='radio']";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeRadiobutton);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpStopAction, stopaction);
            appHandle.Set_field_value(txtExpDate, ExpirationDate);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpReasonforStop, stopreason);

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeRadiobutton))
            {
                appHandle.ScrollToObject(RunTimeRadiobutton);
                Report.Info(StopType + " is to be selected.", StopType + "ToSelect", "True", appHandle);
                appHandle.ClickObjectViaJavaScript(RunTimeRadiobutton);
            }
            switch (StopType)
            {
                case "Check Stop":

                    string checkNum = appHandle.CreateRamdomData(FieldType.NUMERIC, 1000000, 9999999).ToString();
                    appHandle.Set_field_value(txtCheckNumber, checkNum);
                    appHandle.Set_field_value(txtCheckAmt, Amount);
                    break;
                case "ACH Stop":
                    appHandle.Set_field_value(txtACHAmount, Amount);
                    ClickOnFindCompanySelectCompanyByCompanyNumber(Companynumber);
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownDebitCreditIndicator, DebitCreditIndicator);
                    break;

            }
                    }
        public virtual bool VerifyMSGInHoldsPage(string inputMSG)
        {
            bool result = false;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Contains(inputMSG))
            {
                result = true;
            }
            return result;
        }

        public virtual void DeleteStopsFromTable(string date)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle.SelectRadioButtonInTable(StopTable, date);
                appHandle.ClickObjectViaJavaScript(DeleteButton);


            }
            catch (Exception e)
            {
                Report.Fail(e.Message, "DeletePendingTransfer Exception", appHandle);
            }
        }
        public virtual void ClickOnFindCompanySelectCompanyByCompanyNumber(string Companynumber = "")
        {
            if (string.IsNullOrEmpty(Companynumber))
            {
                Companynumber = Data.Get("ACH_INCOMING_HEADER_IMMEDIATE_DESTINATION");
            }
            appHandle.ClickObjectViaJavaScript(linkFindCompany);
            appHandle.SwitchWindow(SwitchInto.WINDOW);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCompanyNumber);
            appHandle.Set_field_value(txtCompanyNumber, Companynumber);
            appHandle.ClickObjectViaJavaScript(btnSearch);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tblcellCompanyFound);
            appHandle.ClickObjectViaJavaScript(tblcellCompanyFound);
            appHandle.SwitchWindow(SwitchInto.DEFAULT);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkFindCompany);
        }
    }
}