using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class CustomerSearchPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string linkCreateTrustCustomer = "XPath;//td[text()='Create Trust Customer']";
        public static string SearchCustomerLink = "Xpath;//td[text()='Customer Search']";
        //"Xpath;.//*[contains(@class,'menuSub')][contains(., 'Customer Search')]";

        // private static string CustomerInfoUpdatedLabel = "Xpath;.//*[@class='msg-box'][contains(.,'The customer information has been updated.')]";
        private static string TaxIDRadioButton = "Xpath;//input[@type='radio'][ @value='CIF_TAXID']";
        private static string CustomerNumberRadioButton = "Xpath;//input[@type='radio'][ @value='CIF_ACN']";
        private static string AccountNumberRadioButton = "Xpath;//input[@type='radio'][ @value='RELCIF_CID']";
        private static string LastNameRadioButton = "Xpath;//input[@type='radio'][ @value='CIF_LNM']";
        private static string UserIDRadioButton = "Xpath;//input[@type='radio'][ @value='CIFAUTH_USERID1']";
        private static string CardNumberRadioButton = "XPath;//input[@type='radio'][ @value='CRD_CRDNUM']";
        private static string ApplicationIDRadioButton = "XPath;//input[@type='radio'][ @value='APPID']";
        public static string SearchField = "Xpath;//input[@name='searchTerm']";
        public static string TaxIdField = "Xpath;.//*[@class='fieldLabelLeft'][contains(.,'Tax ID Number')]/following-sibling::td";
        private static string SubmitButton = "XPATH;//INPUT[@value='Submit']";
        public static string CustomerNumber = "Xpath;.//*[@class='fieldLabelLeft'][contains(.,'Customer Number')]/following-sibling::td";
        private static string UserIDField = "Xpath;.//*[@class='fieldLabelLeft'][contains(.,'User ID')]/following-sibling::td";
        // private static string AccountNumber = "Xpath;.//*[@class='fieldLabelLeft'][contains(.,'Account Number')]/following-sibling::td";

        public static string RefineSearchCityField = "Xpath;//input[@name='CIF_PCITY']";
        public static string RefineSearchDateofBirthField = "Xpath;//input[@name='CIF_DOB']";
        public static string RefineSearchEmailField = "Xpath;//input[@name='CIF_EMAIL']";
        public static string RefineSearchPhoneNumberField = "Xpath;//input[@name='CIF_HPH']";
        public static string RefineSearchZipCodeField = "Xpath;//input[@name='CIF_PZIP']";
        public static string RefineSearchCountryDropdown = "Xpath;//select[@name='CIF_PCNTRY']";
        public static string RefineSearchStateDropdown = "Xpath;//select[@name='CIF_PSTATE']";
        public static string lnkCreateAccount = "Xpath;//td[@class='menuSubHighlight']";
        public static string btnSearch = "Xpath;//input[@name='_eventId_search']";
        public static string rdbCustomerNumber = "Xpath;//*[@name='searchType'][@value='customerNumber']";
        public static string linkCustomerServices = "XPath;//td[contains(text(),'Customer Services')]";
        public static string dropdownIndentityConfirmed = "XPath;//td[contains(text(),'Identity confirmed')]/ancestor::tr[1]/descendant::select";
        public static string linkCustomerVerification = "XPath;//td[contains(text(),'Customer Verification')]";
        public static string AccountIntegrityMSGOBJ = "XPath;//div[@class='dataTables_scrollHead']/following-sibling::div/descendant::td";
        private static string checkboxBeneficiary = "XPath;//*[@name='trustBeneficiariesDefined']";
        private static string TableHeaderParentRow_TrustCustomer = "XPath;//*[text()='Trust Customer']/ancestor::tr[1]/following-sibling::*/descendant::*[@class='dataTables_scrollHead']/descendant::tr";
        private static string TableBody_TrustCustomer = "XPath;//*[text()='Trust Customer']/ancestor::tr[1]/following-sibling::*/descendant::div[@class='dataTables_scrollBody']";
        private static string dropdownCompanyCode = "Xpath;//*[@name='companyCode']";
        private static string labelTaxIDVal="XPath;//*[contains(text(),'Tax ID Number')]/following-sibling::td";
        private static string radiobuttonJointAcctCustomer="XPath;//*[contains(@name,'customerSearchForm')]/descendant::input[@type='radio'][1]";
        public virtual void SelectSearchTypeRadioButton(string SearchType)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            try
            {

                if (SearchType.ToUpper().Contains("Last Name".ToUpper()))
                {
                    appHandle.Set_radiobutton(LastNameRadioButton);
                }
                if (SearchType.ToUpper().Contains("Tax".ToUpper()))
                {
                    appHandle.Set_radiobutton(TaxIDRadioButton);
                }
                if (SearchType.ToUpper().Contains("Account".ToUpper()))
                {
                    appHandle.Set_radiobutton(AccountNumberRadioButton);
                }
                if (SearchType.ToUpper().Contains("User".ToUpper()))
                {
                    appHandle.Set_radiobutton(UserIDRadioButton);
                }
                if (SearchType.ToUpper().Contains("Customer".ToUpper()))
                {
                    appHandle.Set_radiobutton(CustomerNumberRadioButton);
                }
                if (SearchType.ToUpper().Contains("Card".ToUpper()))
                {
                    appHandle.Set_radiobutton(CardNumberRadioButton);
                }
                if (SearchType.ToUpper().Contains("Application".ToUpper()))
                {
                    appHandle.Set_radiobutton(ApplicationIDRadioButton);
                }

            }
            catch (Exception e)
            {
                Report.Fail("Please check Searchtype." + e);
            }

        }
        public virtual string SearchCustomer(string value, string searchType)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string custNum = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SearchCustomerLink))
            {
                appHandle.Select_link(SearchCustomerLink);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TaxIDRadioButton))
            {
                this.SelectSearchTypeRadioButton(searchType);
            }
            appHandle.Set_field_value(SearchField, value);
            this.ClickOnSubmitButton();
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownIndentityConfirmed))
            {
                custNum = appHandle.GetLabelText(CustomerNumber);
            }
            return custNum;
        }
        public virtual string get_customer_number(string searchType, string value)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string custNum = "";
            if (appHandle.GetTitle().Contains(Data.Get("Customer Search"))) { }
            else
            {
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SearchCustomerLink))
                {
                    appHandle.Select_link(SearchCustomerLink);
                }
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TaxIDRadioButton))
            {
                this.SelectSearchTypeRadioButton(searchType);
            }
            appHandle.Set_field_value(SearchField, value);
            this.ClickOnSubmitButton();
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownIndentityConfirmed))
            {
                custNum = appHandle.GetLabelText(CustomerNumber);
            }

            return custNum;
        }
        public virtual string get_Trust_customer_number(string value)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string custNum = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SearchCustomerLink))
            {
                appHandle.Select_link(SearchCustomerLink);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TaxIDRadioButton))
            {
                this.SelectSearchTypeRadioButton(Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            }
            appHandle.Set_field_value(SearchField, value);
            this.ClickOnSubmitButton();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(TableBody_TrustCustomer + "/descendant::td[1]/input");
            int HeadersCount = appHandle.GetRowCountfromList(TableHeaderParentRow_TrustCustomer);
            int customernumberColNo = 0;
            for (int i = 1; i <= HeadersCount; i++)
            {
                if (appHandle.GetObjectText(TableHeaderParentRow_TrustCustomer + "/descendant::th[" + i + "]").Equals(Data.Get("Customer Number")))
                {
                    customernumberColNo = i;
                }
            }
            custNum = appHandle.GetObjectText(TableHeaderParentRow_TrustCustomer + "/ancestor::div[@class='dataTables_scrollHead']/following-sibling::*[@class='dataTables_scrollBody']/descendant::td[" + customernumberColNo + "]").Trim();
            appHandle.ClickObjectViaJavaScript(TableBody_TrustCustomer + "/descendant::td[1]/input");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownIndentityConfirmed);
            return custNum;
        }
        public virtual bool SelectGoToDropdown(string ItemToBeSelected)
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownIndentityConfirmed))
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownIndentityConfirmed, ItemToBeSelected);
            }
            if (appHandle.CheckValueInDropdown(dropdownIndentityConfirmed, ItemToBeSelected))
            {
                result = true;
            }
            return result;
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton))
            {
                appHandle.SelectButton(SubmitButton);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(SearchCustomerLink);
        }
        public virtual void NavigateToCustomerVerificationPage()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkCustomerServices))
            {
                appHandle.ClickObjectViaJavaScript(linkCustomerServices);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkCustomerServices);
                appHandle.ClickObjectViaJavaScript(linkCustomerServices);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkCustomerVerification))
                {
                    appHandle.ClickObjectViaJavaScript(linkCustomerVerification);
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(AccountIntegrityMSGOBJ + "/ancestor::div[1]/preceding-sibling::div/descendant::th[1]");
                }
                else
                {
                    appHandle.ClickObjectViaJavaScript(linkCustomerServices);
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkCustomerVerification);
                    appHandle.ClickObjectViaJavaScript(linkCustomerVerification);
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(AccountIntegrityMSGOBJ + "/ancestor::div[1]/preceding-sibling::div/descendant::th[1]");
                }
            }
        }
        public virtual bool VerifyCustomerInformationIntegrity()
        {
            bool Result = false;
            if (appHandle.GetObjectText(AccountIntegrityMSGOBJ).Equals(Data.Get("CHECK_INTEGRITY_SUCCESS_MSG")))
            {
                Result = true;
            }

            return Result;
        }
        public virtual string GetUserID()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string UserID = appHandle.GetLabelText(UserIDField);
            return UserID;
        }

        public virtual void ClickOnCreateAccountLink()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Select_link(lnkCreateAccount);
            Thread.Sleep(1000);
            Report.Info("Clicked on <Create Account> link");
        }

        public virtual void selectCustomerNumberradiobutton()
        {
            //Method to select the radio button
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.WaitUntilElementVisible(rdbCustomerNumber);
            appHandle.WaitUntilElementClickable(rdbCustomerNumber);
            appHandle.ClickObject(rdbCustomerNumber);
        }

        public virtual void EnterSearchForField(string sCustomerNumber)
        {
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(SearchField, sCustomerNumber);
        }

        public virtual void ClickonSearchbuttonforInnerpage()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(btnSearch);
        }
        public virtual string GetLabelValue(string sLabelField)
        {
            string TaxId = null;
            try
            {
                TaxId = appHandle.GetLabelText(sLabelField);
            }
            catch (Exception e)
            {
                Report.Fail("Please check Searchtype." + e);
            }
            return TaxId;
        }
        public virtual void NavigateToCreateTrustCustomerPage()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SearchCustomerLink))
            {
                appHandle.ClickObjectViaJavaScript(linkCreateTrustCustomer);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxBeneficiary);
        }
        public virtual bool WaitUntilCustomerSearchLinkIsLoaded()
        {
            return Profile7CommonLibrary.WaitForSpecifiedObjectExists(SearchCustomerLink);
        }
        public virtual void NavigateToCreateAccountPage()
        {
            this.WaitUntilCustomerSearchLinkIsLoaded();
            this.SelectGoToDropdown((string)Data.Get("GLOBAL_AccountCreate"));
            this.ClickOnSubmitButton();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownCompanyCode);
        }
        public virtual string GetTaxIDFromVerifyCustomerPage()
        {
            string temp=appHandle.GetObjectText(labelTaxIDVal).Trim();
            return temp;
        }
        public virtual void NavigateToCustomerInformationPage()
        {
            this.WaitUntilCustomerSearchLinkIsLoaded();
            this.SelectGoToDropdown((string)Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            this.ClickOnSubmitButton();
            
        }
        public virtual void SelectCustomerNumberByJointAccountNumber(string AccountNumber)
        {
             appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SearchCustomerLink))
            {
                appHandle.Select_link(SearchCustomerLink);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TaxIDRadioButton))
            {
                this.SelectSearchTypeRadioButton("AccountNumber");
            }
            appHandle.Set_field_value(SearchField, AccountNumber);
            this.ClickOnSubmitButton();
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonJointAcctCustomer))
            {appHandle.ScrollToObject(radiobuttonJointAcctCustomer);
Report.Info("One of the customer name is selected.","custselect","True",appHandle);
                appHandle.ClickObjectViaJavaScript(radiobuttonJointAcctCustomer);
            }
            

        }

        public virtual void SelectSearchTypeRadioButtonforBeneficiary(string SearchType)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            try
            {

                if (SearchType.ToUpper().Contains("Last Name".ToUpper()))
                {
                    appHandle.Set_radiobutton("XPath;//input[@type='radio'][ @value='lastName']");
                }
                if (SearchType.ToUpper().Contains("Tax".ToUpper()))
                {
                    appHandle.Set_radiobutton("XPath;//input[@type='radio'][ @value='taxIdNumber']");
                }
                if (SearchType.ToUpper().Contains("Account".ToUpper()))
                {
                    appHandle.Set_radiobutton("XPath;//input[@type='radio'][ @value='accountNumber']");
                }
                if (SearchType.ToUpper().Contains("User".ToUpper()))
                {
                    appHandle.Set_radiobutton("XPath;//input[@type='radio'][ @value='userName']");
                }
                if (SearchType.ToUpper().Contains("Customer".ToUpper()))
                {
                    appHandle.Set_radiobutton("XPath;//input[@type='radio'][ @value='customerNumber']");
                }               

            }
            catch (Exception e)
            {
                Report.Fail("Please check Searchtype." + e);
            }

        }

        public virtual void SearchForBeneficiaryCustomer(string searchType,string value){
            SelectSearchTypeRadioButtonforBeneficiary(searchType);            
            appHandle.Set_field_value(SearchField, value);        
        }
    }
}
