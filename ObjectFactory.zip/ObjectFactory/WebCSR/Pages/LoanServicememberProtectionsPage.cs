using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs; 
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.BusinessFunctions;
 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class LoanServicememberProtectionsPage
    { 
         static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

         //SCRA
         private static string dropdownAccountNumber ="Xpath;//*[contains(text(),'Account')]/following-sibling::*/descendant::Select";

         //General Information
         private static string checkboxSCRAProtected="Xpath;//*[@name='LN_SCRA']";
         private static string txtSCRAInterestRate ="Xpath;//*[@name='LN_SCRAIRN']";
         private static string txtActiveDutyStartDate ="Xpath;//*[@name='LN_ADSTDT']";
         private static string txtActiveDutyEndDate = "Xpath;//*[@name='LN_ADENDT']";
         private static string txtSCRAProtectionExpirationDate = "Xpath;//*[@name='LN_SCRAEXPDT']";
         private static string buttonContinue = "Xpath;//*[@name='submit']";
         private static string buttonCancel ="Xpath;//*[@name='cancel']";
         public static string MSG ="Xpath;//td[contains(text(),'The account has been updated.')]";

         public virtual void SelectAccountFromDropdown(string accountnumber)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccountNumber))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccountNumber,accountnumber);
            }
        }

        public virtual bool ClickOnSCRAProtectedCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxSCRAProtected))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxSCRAProtected)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxSCRAProtected);
                        if (appHandle.CheckCheckBoxChecked(checkboxSCRAProtected))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxSCRAProtected) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxSCRAProtected);
                        if (appHandle.CheckCheckBoxChecked(checkboxSCRAProtected) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }

        public virtual void UpdateSCRAInterestRate(string InterestRate)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSCRAInterestRate);
            appHandle.Set_field_value(txtSCRAInterestRate,InterestRate);
        }

        public virtual void UpdateDutyDates(string StartDate,string EndDate,string ExpirationDate)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtActiveDutyStartDate);
            appHandle.Set_field_value(txtActiveDutyStartDate,StartDate);
            appHandle.Set_field_value(txtActiveDutyEndDate,EndDate);
            appHandle.Set_field_value(txtSCRAProtectionExpirationDate,ExpirationDate);
        }

        public virtual void ClickOnContinue()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonContinue);
            appHandle.ClickObjectViaJavaScript(buttonContinue);
        }

        public virtual bool VerifyMSGInServicememberProtectionsPage()
        {
            bool result = false;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSG);
            if (appHandle.GetObjectText(MSG).Equals(Data.Get("The account has been updated.")))
            {
                result = true;
            }
            return result;
        }

        public virtual bool VerifyFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "SCRA Interest Rate":
                        if (appHandle.GetSpecifiedObjectAttribute(txtSCRAInterestRate, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;

                    case "Active Duty Start Date":
                        if (appHandle.GetSpecifiedObjectAttribute(txtActiveDutyStartDate, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;

                        case "Active Duty End Date":
                        if (appHandle.GetSpecifiedObjectAttribute(txtActiveDutyEndDate, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }


            return result;
        }


    }
}