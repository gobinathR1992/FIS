
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateDepositAccountInformationPage
    {
        WebApplication appHandle;
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To Generate Xpath for Deposit Accounts Fields.
        /// <param name= "product Desc"></param> 
        /// <param name= "sLabelname"></param> 
        /// <param name= "sFieldType"></param> --> select for dropdown , input for Edit Field
        /// <param name= "index"></param> --> if creating creating mutilple accounts for same product then Index will 1 for first account and 2 for second account and so on
        /// <returns>string</returns>
        /// <example>GenerateXpathforDepositAccFields("SAV12","Account Name", "input", 1)</example>
        public virtual String GenerateXpathforDepositAccFields(string sProductDesc, string sLabelname, string sFieldType, int index)
        {
            string prodType = null;
            try
            {
                prodType = "XPath;((//h2[contains(text(),'" + sProductDesc + "')])[" + index.ToString() + "]/parent::td/parent::tr/following-sibling::tr[2]//td[contains(text(),'" + sLabelname + "')]/parent::tr//" + sFieldType + ")[1]";
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return prodType;
        }

        /// <summary>
        /// To Enter value for Deposit Accounts Fields.
        /// <param name= "sFieldname"></param> 
        /// <param name= "sFieldValue"></param> 
        /// <returns></returns>
        /// <example>SetEditValueforDepositAccFields(sFieldname,sFieldValue)</example>
        public virtual void SetEditValueforDepositAccFields(string sFieldname, string sFieldValue)
        {
            try
            {
                if (AppHandle.IsObjectExists(sFieldname))
                    AppHandle.Set_field_value(sFieldname, sFieldValue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To Select value for Deposit Accounts Dropdowns.
        /// <param name= "sdropname"></param> 
        /// <param name= "sValue"></param> 
        /// <returns></returns>
        /// <example>SelectDropdownValueforDepositAccFields(sdropname,sValue)</example>
        public virtual void SelectDropdownValueforDepositAccFields(string sdropname, string sValue)
        {
            try
            {
                if (AppHandle.IsObjectExists(sdropname))
                    AppHandle.SelectDropdownSpecifiedValue(sdropname, sValue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }


    }
}




