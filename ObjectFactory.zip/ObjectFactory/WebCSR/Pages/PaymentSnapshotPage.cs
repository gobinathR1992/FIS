using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class PaymentSnapshotPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string tblPaymentListheader = "Xpath;//div[@class='dataTables_scrollHeadInner']//table[@class='ledgerScrollable dataTable no-footer']";
        public static string tblPaymentListbody = "Xpath;//table[@id='scheduledPayments-list']/tbody";
        private static string tblPaymentList = "Xpath;//*[contains(@class,'ledgerScrollable dataTable')]/tbody";
        private static string EditButton = "Xpath;//input[@name='edit']";
        private static string buttonCancel = "Xpath;//input[@name='cancel']";
        private static string AddButton = "Xpath;//input[@name='add']";
        private static string txtDueDate = "Xpath;//input[@name = 'LNBIL1_CDPD']";
        private static string txtInterest = "Xpath;//input[@name = 'LNBIL1_PE01AD']";
        private static string txtLoanfee = "Xpath;//input[@name = 'LNBIL1_PE02AD']";
        private static string txtPrinciple = "Xpath;//input[@name = 'LNBIL1_PE03AD']";
        private static string chkfullysatisfiedpay = "Xpath;//input[@name= 'satisfiedPayments']";
        private static string btnsubmit = "Xpath;//input[@name='submit']";
        private static string btnDelete = "Xpath;//input[@name='delete']";
        private static string btnEdit = "Xpath;//input[@name='edit']";


        public virtual void SelectTableValue(string date)
        {
            appHandle.SelectRadioButtonInTable(tblPaymentList, date);
            appHandle.ClickObjectViaJavaScript(EditButton);
        }

        public virtual void ClickOnCancel()
        {
            appHandle.ClickObjectViaJavaScript(buttonCancel);
        }

        public virtual void AddPaymentSnapshot(string date,string interest="",string loanfee="",string principle="")
        {
            appHandle.ClickObjectViaJavaScript(AddButton);
            appHandle.Set_field_value(txtDueDate,date);
            if(!string.IsNullOrEmpty(interest))
            {
                appHandle.Set_field_value(txtInterest,interest);
            }
            if(!string.IsNullOrEmpty(loanfee))
            {
            appHandle.Set_field_value(txtLoanfee,loanfee);
            }
            if(!string.IsNullOrEmpty(principle))
            {
            appHandle.Set_field_value(txtPrinciple,principle);   
            }        
            Report.Info("",true);
            appHandle.ClickObjectViaJavaScript(btnsubmit);
        }

        public virtual void selectfullysatisfiedCheckbox()
        {
            appHandle.ClickObjectViaJavaScript(chkfullysatisfiedpay);
        }

        public virtual void DeleteBill(string date)
        {
            SelectTableValue(date);
            appHandle.ClickObjectViaJavaScript(btnDelete);
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
        }

        public virtual void ModifyExistingBill(string date,string interest="",string loanfee="",string principle="")
        {
            SelectTableValue(date);
            appHandle.ClickObjectViaJavaScript(btnEdit);
            if(!string.IsNullOrEmpty(interest))
            {
                appHandle.Set_field_value(txtInterest,interest);
            }
            if(!string.IsNullOrEmpty(loanfee))
            {
            appHandle.Set_field_value(txtLoanfee,loanfee);
            }
            if(!string.IsNullOrEmpty(principle))
            {
            appHandle.Set_field_value(txtPrinciple,principle);   
            }        
            Report.Info("",true);
            appHandle.ClickObjectViaJavaScript(btnsubmit);
        }
    }
}
