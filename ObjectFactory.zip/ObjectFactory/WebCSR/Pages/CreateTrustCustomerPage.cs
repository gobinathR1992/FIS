using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using System.Collections.Generic;
using System.Threading;
using System;
using Profile7Automation.Libraries.Util;


namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateTrustCustomerPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        public static string txtTrustInformationTaxIdNumber = "Xpath;//input[@name='taxIdNumber']";
        public static string txtTrustInformationTrustDatedDate = "Xpath;//input[@name='trustDate']";
        public static string txtTrustInformationTrustName = "Xpath;//input[@name='fullName']";
        public static string dropdownTrustType = "Xpath;//select[@name='trustType']";
        public static string checkboxTrustBeneficiaries = "Xpath;//input[@name='trustBeneficiariesDefined']";
        public static string btnSearch = "Xpath;//input[@name='_eventId_grantorSearch']";
        public static string btnContinue = "Xpath;//input[@name='_eventId_submit']";
        public static string btnCancel = "Xpath;//input[@name='_eventId_cancel']";
        public static string rdbCustomerNumber = "Xpath;//tr[5]//td[2]//input[1]";
        public static string txtSearchFor = "Xpath;//input[@name='searchTerm']";
        public static string btnSearchforInnerpage = "Xpath;//input[@name='_eventId_search']";
        public static string rdbCustomerFound = "Xpath;//input[@name='customerNumber']";
        public static string tblCustomerFound = "Xpath;//div[@class='dataTables_scroll']";
        public static string tblGrantorTrusteeInformation = "Xpath;//body[@class='main']/table[@id='mainTable']/tbody/tr/td[@id='content']/table/tbody/tr/td/table/tbody/tr/td/form[@name='actionForm']/table[@class='contentTable']/tbody/tr/td/table/tbody/tr/td[1]/table[1]";
        private static string radiobuttonCustomerNumber = "XPath;//input[@value='customerNumber']";
        private static string buttonGrantorCustomerSearch = "XPath;//input[@name='_eventId_search']";
        private static string radiobuttonCustomerFound = "XPath;//*[contains(text(),'Customers Found')]/ancestor::tr[1]/following-sibling::tr/descendant::div[@class='dataTables_scrollBody']/descendant::td/input";
        private static string TAXID_RetrievedCustomer = "XPath;//*[contains(text(),'Tax ID Number')][@class='fieldLabelLeft']/following-sibling::*[@class='data']";
        private static string button_Add_Beneficiary_TrustInfo = "Xpath;//*[@id='addBeneficiaries']";
        private static string button_Add_Beneficiary_Customer_beneficiaries = "Xpath;//*[@name='_eventId_add']";
        private static string dropdownTrustBeneficiaryBeneficiaryClassification = "XPath;//*[@name='trustBeneficiary.beneficiaryClassification']";
        private static string txtTrustBeneficiaryFirstName = "XPath;//*[@name='trustBeneficiary.firstName']";
        private static string txtTrustBeneficiaryLastName = "XPath;//*[@name='trustBeneficiary.lastName']";
        private static string txtTrustBeneficiaryTaxID = "Xpath;//*[@name='trustBeneficiary.taxIdNumber']";
        private static string txtTrustBeneficiaryDOB = "XPath;//*[@name='trustBeneficiary.dateOfBirth']";
        private static string dropdownTrustBeneficiaryCountryOfCitizenship = "XPath;//*[@name='trustBeneficiary.citizenshipCountry']";
        private static string txtTrustBeneficiaryAddressLine1 = "XPath;//*[@name='trustBeneficiary.address.addressLine1']";
        private static string txtTrustBeneficiaryAddressLine2 = "XPath;//*[@name='trustBeneficiary.address.addressLine2']";
        private static string txtTrustBeneficiaryCity = "XPath;//*[@name='trustBeneficiary.address.city']";
        private static string dropdownTrustBeneficiaryCountry = "XPath;//*[@name='trustBeneficiary.address.country']";
        private static string dropdownTrustBeneficiaryState = "XPath;//*[@name='trustBeneficiary.address.state']";
        private static string checkboxInvalidforFDICInsurance = "XPath;//*[contains(text(),'Invalid for FDIC Insurance:')]/following-sibling::*/input[@type='checkbox']";
        private static string txtTrustBeneficiaryZIPCode = "XPath;//*[@name='trustBeneficiary.address.zipCode']";
        private static string txtTrustBeneficiaryTelephone = "XPath;//*[@name='trustBeneficiary.telephone']";
        private static string dropdownTrustBeneficiaryRelationship = "XPath;//*[@name='trustBeneficiary.relationship']";
        private static string dropdownTrustBeneficiaryType = "XPath;//*[@name='trustBeneficiary.type']";
        private static string checkboxTrustBeneficiaryNonContigent = "XPath;//*[@name='trustBeneficiary.nonContingentForFdic']";
        private static string txtTrustBeneficiaryPercentage = "XPath;//*[@name='trustBeneficiary.percentage']";
        private static string dropdownTrustBeneficiaryIdentificationType = "XPath;//*[@name='trustBeneficiary.otherIdType']";
        private static string txtTrustBeneficiaryIdentificationNumber = "XPath;//*[@name='trustBeneficiary.otherIdNumber']";
        private static string txtTrustBeneficiaryIdentificationIssuer = "XPath;//*[@name='trustBeneficiary.otherIdIssuer']";
        private static string txtTrustBeneficiaryIdentificationIssueDate = "XPath;//*[@name='trustBeneficiary.otherIdIssueDate']";
        private static string txtTrustBeneficiaryIdentificationExpirationDate = "XPath;//*[@name='trustBeneficiary.otherIdExpirationDate']";
        private static string txtTrustBeneficiaryEntityName = "XPath;//*[@name='trustBeneficiary.beneficiaryEntityName']";
        private static string txtTrustBeneficiaryContactFirstName = "XPath;//*[@name='trustBeneficiary.beneficiaryEntityFirstName']";
        private static string txtTrustBeneficiaryContactLastName = "XPath;//*[@name='trustBeneficiary.beneficiaryEntityLastName']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        public static string btnSubmit = "Xpath;//input[@name='_eventId_submit']";
        public static string linkBeneficiaries="XPath;//tr[@id='s11']/descendant::*[contains(text(),'Beneficiaries')]";
        
        public static string buttonAdd="XPath;//input[@name='add']";
        public static string dropdownClassification="XPath;//select[@name='BENEFICIARYINFO_CLASSIFICATION']";
        //public static string checkboxInvalidforFDICInsurance="XPath;//input[@name='BENEFICIARYINFO_ISINVALIDFORFDICINSURANCE']";
        public static string txtTaxIdNumber="XPath;//input[@name='BENEFICIARYINFO_TAXID']";
        public static string txtFirstname="XPath;//input[@name='BENEFICIARYINFO_FIRSTNAME']";
        public static string txtLastname="XPath;//input[@name='BENEFICIARYINFO_LASTNAME']";
        public static string txtDOB="XPath;//input[@name='BENEFICIARYINFO_DATEOFBIRTH']";
        public static string txtAddress="XPath;//input[@name='BENEFICIARYINFO_ADDRESSLINE1']";
        public static string txtCity="XPath;//input[@name='BENEFICIARYINFO_CITY']";
        public static string dropdownCountry="XPath;//select[@name='BENEFICIARYINFO_COUNTRY']";
        public static string dropdownState="XPath;//select[@name='BENEFICIARYINFO_STATE']";
        public static string txtZipcode="XPath;//input[@name='BENEFICIARYINFO_ZIPCODE']";
        public static string dropdownType="XPath;//select[@name='CIFBENDTL_BENTYPE']";
        public static string txtPercentage="XPath;//input[@name='CIFBENDTL_BENPCT']";
        public static string dropdownIdentificationType="XPath;//select[@name='BENEFICIARYINFO_OTHERIDTYPE']";
        public static string txtIdentificationNumber="XPath;//input[@name='BENEFICIARYINFO_OTHERIDNUMBER']";
        public static string txtissuer="XPath;//input[@name='BENEFICIARYINFO_OTHERIDISSUEDBY']";
        public static string txtissuedate="XPath;//input[@name='BENEFICIARYINFO_OTHERIDISSUEDATE']";
        public static string txtexpirationdate="XPath;//input[@name='BENEFICIARYINFO_OTHERIDEXPIRATIONDATE']";
        public static string checkboxNonContingent="XPath;//*[@name='CIFBENDTL_FDICNONCONTINGENTINT']";



        public virtual void selecttrusttype(string sTrusttype)
        {
            //Method to Enter the Trust Type.
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(dropdownTrustType, sTrusttype);
            Report.Info("Selected the Trust Type");
        }
        public static string ApplicationDate = new CreateTrustCustomerPage().GetApplicationDate();
        public virtual string GetApplicationDate()
        {
            string result = "";
            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }
        public virtual void entertrustname(string sTrustname)
        {
            //Method to Enter the Trust Name.
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(txtTrustInformationTrustName, sTrustname);
            Report.Info("Entered the Trust Name");
        }

        public virtual void entertaxidnumber(string sTaxID)
        {
            //Method to Enter the Tax Id.
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(txtTrustInformationTaxIdNumber, sTaxID);
            Report.Info("Entered the Tax ID Number");
        }

        public virtual void ClickonSearchbutton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(btnSearch);
        }

        public virtual void selectradiobutton()
        {
            //Method to select the radio button
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(rdbCustomerNumber);
        }

        public virtual void EnterSearchForFieldDetails(string sCustomerNumber)
        {
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(txtSearchFor, sCustomerNumber);
        }

        public virtual void ClickonSearchbuttonforInnerpage()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(btnSearchforInnerpage);
        }

        public virtual void selectbuttonforcustomerfound()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(rdbCustomerFound);
        }

        public virtual void ClickonContinuebutton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnContinue))
            {
                appHandle.ClickObject(btnContinue);
            }
        }

        public virtual void ClickonCancelbutton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(btnCancel);
        }

        public virtual bool ConfirmExpectedMessageforGrantInfoDetailstoTrustCustomer()
        {
            bool bCheck = false;
            try
            {
                bCheck = appHandle.CheckSuccessMessage("grantor information details for the trust customer.");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;
        }
        public virtual string EnterDataForIrrevocableTrustType(string PrimaryCustomerORGrantorNumber)
        {
            string TrustName = Data.Get("National Trust");
            TrustName = ((string)Data.Get("IR - Irrevocable Trust")).Substring(0, 2) + " " + TrustName + appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999, 4) + "";
            string Trust_Tax_ID = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownTrustType))
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownTrustType, (string)Data.Get("IR - Irrevocable Trust"));
                appHandle.Set_field_value(txtTrustInformationTrustName, TrustName);
                appHandle.Set_field_value(txtTrustInformationTaxIdNumber, Trust_Tax_ID);
                appHandle.ClickObjectViaJavaScript(btnSearch);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonCustomerNumber);
                appHandle.ClickObjectViaJavaScript(radiobuttonCustomerNumber);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSearchFor);
                appHandle.Set_field_value(txtSearchFor, PrimaryCustomerORGrantorNumber);
                appHandle.ClickObjectViaJavaScript(buttonGrantorCustomerSearch);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonCustomerFound);
                appHandle.ClickObjectViaJavaScript(radiobuttonCustomerFound);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownTrustType);

            }
            return Trust_Tax_ID;
        }
        public virtual string EnterDataForRevocableTrustType(string PrimaryCustomerORGrantorNumber)
        {
            string TrustName = Data.Get("National Trust");
            TrustName = ((string)Data.Get("RT - Revocable Trust")).Substring(0, 2) + " " + TrustName + appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999, 4) + "";
            string Trust_Tax_ID = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownTrustType))
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownTrustType, (string)Data.Get("RT - Revocable Trust"));
                appHandle.Set_field_value(txtTrustInformationTrustName, TrustName);
                appHandle.Set_field_value(txtTrustInformationTaxIdNumber, Trust_Tax_ID);
                appHandle.ClickObjectViaJavaScript(btnSearch);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonCustomerNumber);
                appHandle.ClickObjectViaJavaScript(radiobuttonCustomerNumber);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSearchFor);
                appHandle.Set_field_value(txtSearchFor, PrimaryCustomerORGrantorNumber);
                appHandle.ClickObjectViaJavaScript(buttonGrantorCustomerSearch);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonCustomerFound);
                appHandle.ClickObjectViaJavaScript(radiobuttonCustomerFound);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownTrustType);
                Trust_Tax_ID = appHandle.GetObjectText(TAXID_RetrievedCustomer);
                appHandle.Set_field_value(txtTrustInformationTaxIdNumber, Trust_Tax_ID);
            }
            return Trust_Tax_ID;
        }
        public virtual void EnterBeneficiaryDetails(int NumberOfBeneficiaries, string BeneficiaryClassificationType, string ContigentNonContigentOrderWithHashDelimiter = "")
        {
            string FirstName = "";
            string LastName = "";
            string TaxIDIndividual = "";
            string TaxIDCharity = "";
            string[] arr = null;
            string temp = "";

            if (ContigentNonContigentOrderWithHashDelimiter.Contains("#"))
            {
                arr = ContigentNonContigentOrderWithHashDelimiter.Split(new string[] { "#" }, StringSplitOptions.None);
            }

            int Pecentagevalue = (int)100 / NumberOfBeneficiaries;
            string percentageContribution = Pecentagevalue.ToString();
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxTrustBeneficiaries))
            {
                appHandle.ClickObjectViaJavaScript(checkboxTrustBeneficiaries);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(button_Add_Beneficiary_TrustInfo);
                appHandle.ClickObjectViaJavaScript(button_Add_Beneficiary_TrustInfo);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(button_Add_Beneficiary_Customer_beneficiaries);
                for (int i = 1; i <= NumberOfBeneficiaries; i++)
                {

                    appHandle.ClickObjectViaJavaScript(button_Add_Beneficiary_Customer_beneficiaries);
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownTrustBeneficiaryBeneficiaryClassification);
                    appHandle.ClickObjectViaJavaScript(checkboxInvalidforFDICInsurance);
                    if (BeneficiaryClassificationType.Equals(Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL")))
                    {
                        appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryBeneficiaryClassification, (string)Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"));
                        TaxIDIndividual = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"), "-");
                        appHandle.Set_field_value(txtTrustBeneficiaryTaxID, TaxIDIndividual);
                        FirstName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[0].Trim();
                        LastName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[1].Trim();
                        appHandle.Set_field_value(txtTrustBeneficiaryFirstName, FirstName);
                        appHandle.Set_field_value(txtTrustBeneficiaryLastName, LastName);
                        appHandle.Set_field_value(txtTrustBeneficiaryDOB, appHandle.CalculateNewDate(ApplicationDate, "Y", -45));
                        appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryCountryOfCitizenship, (string)Data.Get("US - UNITED STATES OF AMERICA"));

                    }

                    if (BeneficiaryClassificationType.Equals(Data.Get("NC - Non-Profit or Charity")))
                    {
                        appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryBeneficiaryClassification, (string)Data.Get("NC - Non-Profit or Charity"));
                        FirstName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[0].Trim();
                        LastName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[1].Trim();
                        TaxIDCharity = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
                        appHandle.Set_field_value(txtTrustBeneficiaryTaxID, TaxIDCharity);
                        appHandle.Set_field_value(txtTrustBeneficiaryEntityName, FirstName + LastName);
                        appHandle.Set_field_value(txtTrustBeneficiaryContactFirstName, FirstName);
                        appHandle.Set_field_value(txtTrustBeneficiaryContactLastName, LastName);

                    }
                    appHandle.Set_field_value(txtTrustBeneficiaryAddressLine1, Data.Get("National Trust"));
                    appHandle.Set_field_value(txtTrustBeneficiaryAddressLine2, Data.Get("456 Street"));
                    appHandle.Set_field_value(txtTrustBeneficiaryCity, Data.Get("Jacksonville"));
                    appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryCountry, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                    appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryState, (string)Data.Get("FL - FLORIDA"));
                    appHandle.Set_field_value(txtTrustBeneficiaryZIPCode, Data.Get("32256"));
                    appHandle.Set_field_value(txtTrustBeneficiaryTelephone, RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_PHONE_NUMBER_FORMAT"), "-"));
                    appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryRelationship, (string)Data.Get("NR - No Relation"));
                    appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryType, (string)Data.Get("P - PRIMARY"));
                    if (string.IsNullOrEmpty(ContigentNonContigentOrderWithHashDelimiter))
                    { }
                    else
                    {
                        if (arr[i - 1].Equals(Data.Get("Contigent")))
                        { }
                        else
                        {
                            appHandle.ClickObjectViaJavaScript(checkboxTrustBeneficiaryNonContigent);
                        }
                    }
                    appHandle.Set_field_value(txtTrustBeneficiaryPercentage, percentageContribution);
                    appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryIdentificationType, (string)Data.Get("DL - Driver's License"));
                    appHandle.Set_field_value(txtTrustBeneficiaryIdentificationNumber, appHandle.CreateRamdomData(FieldType.NUMERIC, 111111, 999999, 6) + "");
                    appHandle.Set_field_value(txtTrustBeneficiaryIdentificationIssuer, Data.Get("FL - FLORIDA"));
                    appHandle.Set_field_value(txtTrustBeneficiaryIdentificationIssueDate, appHandle.CalculateNewDate(ApplicationDate, "Y", -20));
                    appHandle.Set_field_value(txtTrustBeneficiaryIdentificationExpirationDate, appHandle.CalculateNewDate(ApplicationDate, "Y", 10));
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnSubmit))
                    {
                        appHandle.ClickObjectViaJavaScript(btnSubmit);
                    }
                    TaxIDIndividual = "";
                    TaxIDCharity = "";
                    FirstName = "";
                    LastName = "";
                    Report.Info("Beneficiary " + i + "" + " data is entered.", "benfdata" + i + "", "true", appHandle);
                }
            }

        }
        public virtual string GenerateCustomerName()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string strCustName = "";
            string strFirstName = "";
            string strLastName = "";
            string strRandomString1 = appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 5).ToString();
            string strRandomString2 = appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 5).ToString();

            string strUserName = StartupConfiguration.UserSettings.GLOBAL_USER_NAME;

            if (!strUserName.Contains(" "))
            {
                // strFirstName = strUserName.Substring(0,1).ToUpper() + strUserName.Substring(1,strUserName.Length-1).ToLower() + strRandomString1;
                strFirstName = strUserName.Substring(0, 1).ToUpper() + strUserName.Substring(1, strUserName.Length - 1).ToLower() + strRandomString1;
                strLastName = strUserName.Substring(0, 1).ToUpper() + strUserName.Substring(1, strUserName.Length - 1).ToLower() + strRandomString2;
            }
            else
            {
                string[] arrUserDetails = strUserName.Split(' ');
                strFirstName = arrUserDetails[0].Substring(0, 1).ToUpper() + arrUserDetails[0].Substring(1, arrUserDetails[0].Length - 1).ToLower() + strRandomString1;
                strLastName = arrUserDetails[1].Substring(0, 1).ToUpper() + arrUserDetails[1].Substring(1, arrUserDetails[1].Length - 1).ToLower() + strRandomString2;
            }

            strCustName = strFirstName + " " + strLastName;
            return strCustName;
        }
        public virtual void ClickonSubmitbutton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnSubmit))
            {
                appHandle.ClickObjectViaJavaScript(btnSubmit);
            }
        }
        public virtual bool VerifyTrustCustomerCreationSuccess()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_APPLICATION_SUCCESSFULLY_PROCESSED")))
            {
                Result = true;
            }

            return Result;
        }


        public virtual bool AddBeneficiaryToTrustCustomer(string classificationtype,bool invalidforFDICinsurance,bool NonContingent,string percenatgeval)
        {
            string random1=appHandle.CreateRamdomData(FieldType.NUMERIC,100,999).ToString();
            string name="BenName"+random1;
            string taxid1=appHandle.CreateRamdomData(FieldType.NUMERIC,100,999).ToString();
            string taxid2=appHandle.CreateRamdomData(FieldType.NUMERIC,10,99).ToString();
            string taxid3=appHandle.CreateRamdomData(FieldType.NUMERIC,1000,9999).ToString();
            string taxid=taxid1+"-"+taxid2+"-"+taxid3;

            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkBeneficiaries);
            appHandle.ClickObject(linkBeneficiaries);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObject(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownClassification);
            appHandle.SelectDropdownSpecifiedValue(dropdownClassification,classificationtype);
            if(invalidforFDICinsurance)
                appHandle.ClickObject(checkboxInvalidforFDICInsurance);
            appHandle.Set_field_value(txtFirstname,name);
            appHandle.Set_field_value(txtLastname,name);
            appHandle.Set_field_value(txtTaxIdNumber,taxid);
            appHandle.Set_field_value(txtDOB,appHandle.CalculateNewDate(ApplicationDate, "Y", -60));
            appHandle.Set_field_value(txtTrustBeneficiaryAddressLine1, Data.Get("National Trust"));
            appHandle.Set_field_value(txtTrustBeneficiaryAddressLine2, Data.Get("456 Street"));
            appHandle.Set_field_value(txtTrustBeneficiaryCity, Data.Get("Jacksonville"));
            appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryCountry, (string)Data.Get("US - UNITED STATES OF AMERICA"));
            appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryState, (string)Data.Get("FL - FLORIDA"));
            appHandle.Set_field_value(txtTrustBeneficiaryZIPCode, Data.Get("32256"));
            appHandle.SelectDropdownSpecifiedValue(dropdownTrustBeneficiaryIdentificationType, (string)Data.Get("DL - Driver's License"));
            appHandle.Set_field_value(txtTrustBeneficiaryIdentificationNumber, appHandle.CreateRamdomData(FieldType.NUMERIC, 111111, 999999, 6) + "");
            appHandle.Set_field_value(txtTrustBeneficiaryIdentificationIssuer, Data.Get("FL - FLORIDA"));
            appHandle.Set_field_value(txtTrustBeneficiaryIdentificationIssueDate, appHandle.CalculateNewDate(ApplicationDate, "Y", -20));
            appHandle.Set_field_value(txtTrustBeneficiaryIdentificationExpirationDate, appHandle.CalculateNewDate(ApplicationDate, "Y", 10));
            if(NonContingent)
                appHandle.ClickObject(checkboxNonContingent);
            appHandle.Set_field_value(txtPercentage,percenatgeval);
            appHandle.ClickObject(btnSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("beneficiarywarningmsg"));
        }

    }

}

