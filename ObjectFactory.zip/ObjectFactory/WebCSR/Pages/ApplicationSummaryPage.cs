using GTS_OSAF.CoreLibs;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class ApplicationSummaryPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string btnDetails = "Xpath;//input[@name='_eventId_creditCheckDetail']";
     
    }
}