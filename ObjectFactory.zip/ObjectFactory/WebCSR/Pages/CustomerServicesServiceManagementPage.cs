using GTS_OSAF.CoreLibs;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class CustomerServicesServiceManagementPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonRefreshList = "XPath;//*[@value='Refresh List']";
         public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string buttonPositivePayAdd = "XPath;//*[contains(text(),'Positive Pay')]/ancestor::td/following-sibling::td/input";
         private static string buttonCustomerServiceAdd = "Xpath;//*[@value='Add']"; 

        public virtual void ClickOnAddButtonForPositivePay(string AccountNumber)
        {
            string RunTimeButton = "XPath;//*[contains(text(),'" + AccountNumber + "')]/following-sibling::td/a[text()='Positive Pay']/ancestor::td/following-sibling::td/input";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeButton))
            {
                appHandle.ClickObjectViaJavaScript(RunTimeButton);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeButton);
            }
            else
            {
                Report.Fail("Verify the account number OR Make sure setup is done in UTBLSRVPRD table for this service to be available.", "servicemgmtfail", "true", appHandle, true);
            }
        }
        public virtual bool VerifyRemoveButtonAfterAddingPositivePay()
        {

            bool Result = false;
            if (appHandle.GetSpecifiedObjectAttribute(buttonPositivePayAdd, "value").Equals(Data.Get("Remove")))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void ClickOnRefreshListButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRefreshList))
            {
                appHandle.ClickObjectViaJavaScript(buttonRefreshList);
            }
        }
         public virtual bool VerifyListRefreshSuccess()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("The list has been refreshed.")))
            {
                Result = true;
            }

            return Result;
        }
                public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCustomerServiceAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonCustomerServiceAdd);
            }
        }
        public virtual void ClickOnAddButtonForCourtesyOverdraft(string AccountNumber)
        {
            string RunTimeButton = "XPath;//*[contains(text(),'" + AccountNumber + "')]/following-sibling::td/a[text()='Courtesy Overdraft']/ancestor::td/following-sibling::td/input";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeButton))
            {
                appHandle.ClickObjectViaJavaScript(RunTimeButton);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeButton);
            }
            else
            {
                Report.Fail("Verify the account number OR Make sure setup is done in UTBLSRVPRD table for this service to be available.", "servicemgmtfail", "true", appHandle, true);
            }
        }
        public virtual void ClickonTermsandConditionCheckbox(string AccountNumber)
        {
            string RunTimeCheckbox="Xpath;//div[@id='" + AccountNumber + "']/input";

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeCheckbox))
            {
                appHandle.ClickObjectViaJavaScript(RunTimeCheckbox);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeCheckbox);
            }
            else
            {
                Report.Fail("Verify the account number ", "servicemgmtfail", "true", appHandle, true);
            }


        }







    }
}