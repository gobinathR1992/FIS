using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class EmploymentPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string EmployeeInformationEmployeeNumber_Field="Xapth;//input[@name='CIF_EMPNUM']";
        public static string EmployeeInformationPositionTitle_Field="Xpath;//input[@name='CIF_EMPTITLE']";
        public static string EmployerInformationMonthlyIncome_Field="Xpath;//input[@name='CIF_MINCOME']";
        public static string EmploymentVerificationDate_Field="Xpath;//input[@name='CIF_EMPVERDT']";
        public static string EmployerInformationEmployerName_Field="Xpath;//input[@name='CIF_EMPNAME']";
        public static string EmployerInformationNumberofEmployees_Field="Xpath;//input[@name='CIF_NE']";
        public static string EmployerInformationAddress_Field="Xpath;//input[@name='CIF_EMPAD1']";
        public static string EmployeeInformationTownship_Field="Xpath;//input[@name='CIF_EMPLOC']";
        public static string EmployerInformationCounty_Field="Xpath;//input[@name='CIF_EMPCNTY']";
        public static string EmployerInformationCity_Field="Xpath;//input[@name='CIF_EMPCITY']";
        public static string EmployerInformationZipCode_Field="Xpath;//input[@name='CIF_EMPZIP']";
        public static string EmployeeInformationOccupation_Dropdown="Xpath;//select[@name='CIF_OCC']";
        public static string EmployeeInformationTypeofEmployee_Dropdown="Xpath;//select[@name='CIF_EMPCD']";
        public static string EmployeeInformationSalaryRange_Dropdown="Xpath;//select[@name='CIF_INC']";
        public static string EmployerInformationEmployerNumber_Dropdown="Xpath;//select[@name='CIF_EMPLNO']";
        public static string EmployerInformationCountry_Dropdown="Xpath;//select[@name='CIF_EMPCNTRY']";
        public static string EmployerInformationState_Dropdown="Xpath;//select[@name='CIF_EMPSTATE']";
        public static string SelfEmployed_Radiobutton="Xpath;//input[@name='CIF_SELFEMP'][@value='true']";
        public static string EmployeeInformation_Table="Xpath;//body[@class='main']/table[@id='mainTable']/tbody/tr/td[@id='content']/table/tbody/tr/td/table/tbody/tr/td/form[@name='customerEmploymentForm']/table[@class='contentTable']/tbody/tr[2]/td[1]/table[1]";
        public static string EmployerInformation_Table="Xpath;//body[@class='main']//tr//tr//tr//tr[4]//td[1]//table[1]";



    }

}
