
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages

{
    public class LoanRateDeterminationPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtInterestRate = "XPath;//input[@name='LN_IRN']";
        public static string txtInterestRatesAnnualDisclosureRate = "XPath;//input[@name='LN_DISAPR']";
        private static string txtEffectiveDisclosureRate = "XPath;//input[@name='LN_EIRN']";
        private static string buttonSubmit = "XPath;//input[@name='submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        public virtual void EnterInterestRates(string InterestRate = "", string AnnualDIsClosureRate = "", string EffectiveDisclosureRate = "")
        {
            if (!string.IsNullOrEmpty(InterestRate))
            {
                appHandle.Set_field_value(txtInterestRate, InterestRate);
            }
            if (!string.IsNullOrEmpty(AnnualDIsClosureRate))
            {
                appHandle.Set_field_value(txtInterestRatesAnnualDisclosureRate, AnnualDIsClosureRate);
            }
            if (!string.IsNullOrEmpty(EffectiveDisclosureRate))
            {
                appHandle.Set_field_value(txtEffectiveDisclosureRate, EffectiveDisclosureRate);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMessageInLoanRateDeterminationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyAnnualDisclosurate(string CalculatedannualDiscRate)
        {
            bool result=false;
            if(appHandle.GetSpecifiedObjectAttribute(txtInterestRatesAnnualDisclosureRate,"value").Contains(CalculatedannualDiscRate))
                {
                    result=true;
                }
                return result;
        }
        public virtual bool WaitUntilLoanInterestPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtInterestRate))
            {
                result = true;
            }

            return result;

        }
    }

}