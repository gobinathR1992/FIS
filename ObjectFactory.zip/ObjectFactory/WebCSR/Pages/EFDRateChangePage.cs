using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;
using Profile7Automation.Libraries.Util;
using System;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class EFDRateChangePage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string drpAccount="Xpath;//select[@name='ACN_CID']";
        public static string txtEFDRateChangeEffectiveDate="Xpath;//input[@name='effectiveDate']";
        public static string txtFixedRatePlansNewInterestRate="Xpath;//input[@name='newInterestRate']";
        public static string txtVariableRateInterestSpread="Xpath;//input[@name='LN_INTSPR']";
        public static string txtVariableRateRateRoundingMethod="Xpath;//input[@name='LN_RNDMTD']";
        public static string txtVariableRateInterestChangeFrequency="Xpath;//input[@name='LN_INTFRE']";
        public static string txtVariableRateReviewOffset="Xpath;//input[@name='LN_INTOFF']";
        public static string txtPromotionalRateNewInterestRate="Xpath;//input[@name='newPromotionalInterestRate']";
        public static string txtPromotionalRatePromotionalExpirationDate="Xpath;//input[@name='LN_TREXD']";
        public static string rdbFixedRateInterestRatetoChangeInterestRate="Xpath;//td[contains(text(),'Interest Rate 10.00000%')]";
        public static string rdbrdbFixedRateInterestRatetoChangeEffectiveDisclosureRate="Xpath;//tr//tr//tr//tr[3]//td[2]//input[1]";
        public static string rdbPromotionalRateInterestRatetoChangeInterestRate="Xpath;//td[contains(text(),'Interest Rate 0.00000%')]";
        public static string rdbPromotionalRateInterestRatetoChangeEffectiveDisclosureRate="Xpath;//tr[16]//td[2]//input[1]";
        public static string drpVariableRateInterestIndex="Xpath;//select[@name='LN_INDEX']";
        public static string drpVariableRateInterestMatrix="Xpath;//select[@name='LN_INTMAT']";
        public static string drpVariableRateRateChangeMethod="Xpath;//select[@name='LN_ICHM']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
		private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string lnkLoanAccountServices = "XPath;//td[contains(text(),'Loan Account Services')]";
		private static string lnkEFDRateChange = "XPath;//td[contains(text(),'EFD Rate Change')]";

    public virtual void EnterLoanEFDRateChangePageOptions(string Account = " ", string EftDt=" ", string  IntIndx = " ", string IntChngFrq = " ", string RateChangeMethod="", string sMessage="" )
        {
		 
		try
		  {
		   if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpAccount))
            {
                if(!string.IsNullOrEmpty(Account))
                {
                appHandle.SelectDropdownSpecifiedValue(drpAccount,Account);
                }
                                       
            }
			
		    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtEFDRateChangeEffectiveDate))
            {
                if(!string.IsNullOrEmpty(EftDt))
                {
				appHandle.Set_field_value(txtEFDRateChangeEffectiveDate,EftDt);
                }	
		    }
	
		    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtVariableRateInterestChangeFrequency))
            {
                if(!string.IsNullOrEmpty(IntChngFrq))
                {
                appHandle.Set_field_value(txtVariableRateInterestChangeFrequency, IntChngFrq);
                }
                                       
            }

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpVariableRateRateChangeMethod))
            {
                if(!string.IsNullOrEmpty(RateChangeMethod))
                {
                appHandle.SelectDropdownSpecifiedValue(drpVariableRateRateChangeMethod,RateChangeMethod);
                }
                                       
            }
		
		 }
		  catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }	
			
        }
		
		 public virtual void SelectSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            
        }
	   
	    public virtual bool VerifyMessageLoanEFDRateChange(string sMessage)
        {
         bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
                
            }
          return Result;
		} 
        

        public virtual void SelectLoanEFDRateChangeLink()
        {
            appHandle.WaitUntilElementVisible(lnkLoanAccountServices);
            appHandle.WaitUntilElementClickable(lnkLoanAccountServices);
            appHandle.Select_link(lnkLoanAccountServices);
            appHandle.Wait_For_Specified_Time(5);
            appHandle.WaitUntilElementVisible(lnkEFDRateChange);
            appHandle.WaitUntilElementClickable(lnkEFDRateChange);
            appHandle.Select_link(lnkEFDRateChange);
             
        }

    }
}
