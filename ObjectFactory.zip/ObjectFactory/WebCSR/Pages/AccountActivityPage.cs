using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountActivityPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpAccountStatus="Xpath;//select[@name='ACN_STAT']";
        public static string drpCloseoutReason="Xpath;//select[@name='ACN_CLR']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string Submit_Button = "Xpath;//input[@value='Submit']";

        public virtual bool CloseAccount(string AccountNumber)
        {
            bool flag = false;
            
            Application.WebCSR.LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("General"),Data.Get("Account Activity"));
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpAccountStatus))
            {
                appHandle.SelectDropdownSpecifiedValue(drpAccountStatus,Data.Get("4 - Account Closed"), false);
               this.ClickSubmitButton();
                if(this.ValidateSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Closed Account succesfully", "CloseAccount", "true", appHandle);
                    flag = true;
                }
                else 
                {
                    Report.Fail("Not able to close Account", "CloseAccount Fail", "true", appHandle);
                }
            }
            return flag;
        }
        public virtual bool ValidateSuccessMessage(string inputmessage)
        {
            bool Result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals(inputmessage))
            {
                Result = true;
            }

            return Result;
        }
        public virtual void ClickSubmitButton()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(Submit_Button))
            {
            appHandle.ClickObject(Submit_Button);
            }
        }
        
    }
}