using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
using OpenQA.Selenium;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class RetirementTransactionCorrectionsPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string DropdownAccount = "Xpath;//select[@name='ACN_CID']";
        private static string DropdownReasonCode = "Xpath;//*[@id='transactionDetailsGridBody']/descendant::select[@name='reasonCode0']";
        private static string dropdownMilitaryZoneCode = "XPath;//*[@id='transactionDetailsGridBody']/descendant::select[@name='militaryZoneCode0']";
        private static string txtFederalWithholding = "XPath;//*[@id='transactionDetailsGridBody']/descendant::input[@name='federalWithholding0']";
        private static string txtStateWithholding = "XPath;//*[@id='transactionDetailsGridBody']/descendant::input[@name='stateWithholding0']";
        private static string txtMilitaryYearOfService = "XPath;//*[@id='transactionDetailsGridBody']/descendant::input[@name='militaryYearOfService0']";
        private static string txtAmt = "XPath;//*[@id='transactionDetailsGridBody']/descendant::input[@name='amount0']";
        private static string txtContributionYear = "XPath;//*[@id='transactionDetailsGridBody']/descendant::input[@name='contributionForYear0']";
        private static string DropdownHistorySequence = "XPath;//*[contains(text(),'History Sequence')]/following-sibling::*/descendant::select";
        private static string mainbody = "XPAth;//*[@class='main']";
        private static string buttonAdd = "Xpath;//*[@class='ledgerTableToolbar']/input[@value='Add']";
        private static string buttonSubmit = "Xpath;//input[@value='Submit']";
        private static string TransactionDetailTableHeader = "XPath;//div[@class='dataTables_scrollHead']/descendant::thead/tr";
        private static string tableTransactionDetailsGrid = "XPath;//tbody[@id='transactionDetailsGridBody']";
        public virtual void SelectAccountNumber(string AccountNumber)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccount, AccountNumber);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownHistorySequence);
        }
        public virtual void SelectHistorySequence(string TransactionSeq)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownHistorySequence, TransactionSeq);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownReasonCode);
        }
        public virtual bool VerifyMilitaryZoneCode(string inputVal)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMilitaryZoneCode, inputVal);
            appHandle.ScrollToObject(dropdownMilitaryZoneCode);
            return appHandle.CheckValueInDropdown(dropdownMilitaryZoneCode, inputVal);

        }
        public virtual bool WaitRetirementTransactionCorrectionPageLoads()
        {
            return Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownAccount);
        }
        public virtual bool VerifyContributionFieldsExitInRetirementTransactionPage()
        {
            bool Result = false;
            if (appHandle.IsObjectExists(DropdownReasonCode)
            && appHandle.IsObjectExists(dropdownMilitaryZoneCode)
            && appHandle.IsObjectExists(txtAmt)
            && appHandle.IsObjectExists(txtMilitaryYearOfService)
            && appHandle.IsObjectExists(txtContributionYear))
            {
                Result = true;
                appHandle.ScrollToObject(txtMilitaryYearOfService);
            }

            return Result;
        }
        public virtual bool VerifyMilitaryZoneCodeDropdownEnabled()
        {
            return Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownMilitaryZoneCode);
        }
        public virtual bool VerifyContributionYearFieldEnabled()
        {
            return Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtContributionYear);
        }
        public virtual bool SelectReasonCode(string inputval)
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownReasonCode))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownReasonCode, inputval);
            }
            return appHandle.CheckValueInDropdown(DropdownReasonCode, inputval);
        }
        public virtual bool CheckRetirementTransactionCorrectionPageLoaded()
        {
            bool Result = false;
            if (appHandle.GetObjectText(mainbody).Contains(Data.Get("Retirement Transaction Corrections")))
            {

                Result = true;

            }

            return Result;
        }
        public virtual bool ClickOnAddButton()
        {
            bool Result = false;
            int rowCount = GetNumberOfRowsInTransactionDetailsTable();

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);

            }
            int tempcount = GetNumberOfRowsInTransactionDetailsTable();
            if (tempcount > rowCount)
            {
                appHandle.ScrollToObject(tableTransactionDetailsGrid);
                Result = true;
            }
            return Result;
        }
        public virtual int GetNumberOfRowsInTransactionDetailsTable()
        {
            int count = 0;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableTransactionDetailsGrid))
            {
                count = appHandle.GetRowCountfromList(tableTransactionDetailsGrid);
            }

            return count;
        }
        public virtual bool EnterDataInTransactionDetailsTableByRowNumber(string ColumnNameColumnValuePipeDelimited, string RowNumber)
        {
            bool Result = false;
            int colCount = appHandle.GetRowCountfromList(TransactionDetailTableHeader);
            string temp = "";
            string colno = "";
            for (int a = 1; a <= colCount; a++)
            {
                temp = temp + "|" + appHandle.GetObjectText(TransactionDetailTableHeader + "/th[" + a + "]") + "-" + a;

            }
            temp = temp.Substring(1, temp.Length - 1);
            string[] colarr = temp.Split('|');
            ColumnNameColumnValuePipeDelimited = ColumnNameColumnValuePipeDelimited + ";";
            string[] arr = ColumnNameColumnValuePipeDelimited.Split(';');
            string colName = "";
            string colValue = "";
            string tagname = "";
            string RunTimeObj = "";
            int n = 0;
            for (int b = 0; b < arr.Length - 1; b++)
            {
                colName = arr[b].Split('|')[0].Trim(); ;
                colValue = arr[b].Split('|')[1].Trim();
                string temp2 = Array.Find(colarr, t => t.Contains(colName));
                if (temp2.Contains(colName))
                {
                    colno = temp2.Split('-')[1].Trim();
                    RunTimeObj = tableTransactionDetailsGrid + "/tr[" + RowNumber + "]/td[" + colno + "]/descendant::*[1]";
                    try
                    {
                        IWebElement obj = (IWebElement)appHandle.FindElement(RunTimeObj);
                        tagname = obj.TagName;
                        if (tagname.Trim().ToUpper().Equals("SELECT"))
                        {
                            appHandle.SelectDropdownSpecifiedValueByPartialText(RunTimeObj, colValue);
                            n++;
                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            if (colValue.Equals("ON"))
                            {
                                if (appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                    n++;
                                }
                            }
                            else
                            {
                                if (!appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                    n++;
                                }
                            }

                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && !appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            appHandle.Set_field_value(RunTimeObj, colValue);
                            n++;
                        }
                    }
                    catch (Exception e) { };
                }
                if (n == arr.Length - 1)
                {
                    Result = true;
                    appHandle.ScrollToObject(tableTransactionDetailsGrid);
                }
            }

            return Result;
        }

        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);

            }
        }
        public virtual bool VerifyCellsOfTransactionTableEnabledSpecifiedReasonCodeByRowNumber(string ReasonCode, string ColumnNamesToBeVerifiedPipeDelimited, string RowNumber)
        {
            bool Result = false;
            EnterDataInTransactionDetailsTableByRowNumber("Reason Code" + "|" + ReasonCode, RowNumber);
            int colCount = appHandle.GetRowCountfromList(TransactionDetailTableHeader);
            string temp = "";
            string colno = "";
            for (int a = 1; a <= colCount; a++)
            {
                temp = temp + "|" + appHandle.GetObjectText(TransactionDetailTableHeader + "/th[" + a + "]") + "-" + a;

            }
            temp = temp.Substring(1, temp.Length - 1);
            string[] colarr = temp.Split('|');
            ColumnNamesToBeVerifiedPipeDelimited = ColumnNamesToBeVerifiedPipeDelimited + "|";
            string[] arr = ColumnNamesToBeVerifiedPipeDelimited.Split('|');
            string colName = "";
            string RunTimeObj = "";
            int n = 0;
            for (int b = 0; b < arr.Length - 1; b++)
            {
                colName = arr[b].Trim(); ;

                string temp2 = Array.Find(colarr, t => t.Contains(colName));
                if (temp2.Contains(colName))
                {
                    colno = temp2.Split('-')[1].Trim();
                    RunTimeObj = tableTransactionDetailsGrid + "/tr[" + RowNumber + "]/td[" + colno + "]/descendant::*[1]";
                    if (appHandle.IsObjectEnabled(RunTimeObj))
                    {
                        n++;
                    }
                }
                if (n == arr.Length - 1)
                {
                    Result = true;
                }
            }
            return Result;
        }
    
        public virtual bool VerifyDistributionFieldsExitInRetirementTransactionPage()
        {
            bool Result = false;
            if (appHandle.IsObjectExists(DropdownReasonCode)
            && appHandle.IsObjectExists(txtFederalWithholding)
            && appHandle.IsObjectExists(txtAmt)
            && appHandle.IsObjectExists(txtStateWithholding))
            {
                Result = true;
                appHandle.ScrollToObject(txtFederalWithholding);
            }

            return Result;
        }
        public virtual bool VerifyTotalAmountInTransactionDetailTable(string ExpectedTotalAmount)
        {
            bool Result = false;
            int rowcount = GetNumberOfRowsInTransactionDetailsTable();
            string temp3 = "";
            int colCount = appHandle.GetRowCountfromList(TransactionDetailTableHeader);
            string temp = "";
            string colno = "";
            for (int a = 1; a <= colCount; a++)
            {
                temp = temp + "|" + appHandle.GetObjectText(TransactionDetailTableHeader + "/th[" + a + "]") + "-" + a;

            }
            temp = temp.Substring(1, temp.Length - 1);

            string[] colarr = temp.Split('|');

            string colName = Data.Get("Amount");
            string RunTimeObj = "";
            int n = 0;
            for (int b = 0; b < colarr.Length; b++)
            {

                string temp2 = Array.Find(colarr, t => t.Contains(colName));
                if (temp2.Contains(colName))
                {
                    colno = temp2.Split('-')[1].Trim();
                    for (int c = 1; c <= rowcount; c++)
                    {
                        RunTimeObj = tableTransactionDetailsGrid + "/tr[" + c + "]/td[" + colno + "]/descendant::*[1]";
                        temp3 = temp3 + "|" + appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "value");
                        n++;

                    }

                }
                if (n == rowcount)
                {
                    break;
                }
            }
            temp3 = temp3.Substring(1, temp3.Length - 1);
            string[] arrtemp = temp3.Split('|');
            double total = 0;
            for (int d = 0; d < arrtemp.Length; d++)
            {
                total = total + Convert.ToDouble(arrtemp[d]);
            }
            string totalAmt = total.ToString();
            ExpectedTotalAmount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(ExpectedTotalAmount);
            totalAmt = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(totalAmt);
            string TotalAmount_Footer = appHandle.GetObjectText("Xpath;//div[@class='dataTables_scrollFoot']/descendant::tr[1]/td[" + colno + "]");
            if (totalAmt.Equals(TotalAmount_Footer))
            {
                if (ExpectedTotalAmount.Equals(totalAmt))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyAccountNumberInAccountsDropdown(string AccountNumber)
        {
            bool Result = false;
            string temp = appHandle.GetObjectText(DropdownAccount);
            if (temp.Contains(AccountNumber))
            {
                if (appHandle.CheckValueInDropdown(DropdownAccount, temp))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyTransactionSequenceInHistorySequenceDropdown(string TranSeq)
        {
            bool Result = false;
            if (appHandle.CheckSelectedValueExistsInDropdown(DropdownHistorySequence, TranSeq))
            {
                Result = true;
            }

            return Result;
        }
        public virtual bool VerifyMessageInRetirementTransactionsPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }       
        
    }
}