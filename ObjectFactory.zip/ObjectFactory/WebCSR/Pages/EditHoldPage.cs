using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class EditHoldPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string EditPermanentHoldStartDate_Field="Xapth;//input[@name='PHLD_STDT']";
        public static string EditPermanentHoldExpirationDate_Field="Xpath;//input[@name='PHLD_EXPDT']";
        public static string EditPermanentHoldComment_Field="Xpath;//textarea[@name='PHLD_TCMT']";
        public static string EditPermanentHoldFixedAmount_Field="Xpath;//input[@name='PHLD_AMT']";
        public static string EditPermanentHoldPercentage_Field="Xpath;//input[@name='PHLD_PERCNT']";
        public static string EditPermanentHoldReferenceAccount_Field="Xpath;//input[@name='PHLD_AREF']";
        public static string EditPermanentHoldCode_Dropdown="Xpath;//select[@name='PHLD_PHC']";
        public static string EditPermanentHoldCurrencyCode_Dropdown="Xpath;//select[@name='PHLD_CRCD']";
        public static string EditPermanentHoldBalanceType_Dropdown="Xpath;//select[@name='PHLD_COMP']";
        public static string EditCheckHoldAmount_Field="Xpath;//input[@name='HLD8_AMT']";
        public static string EditCheckHoldCashHoldAmount_Field="Xpath;//input[@name='HLD8_CSHAMT']";
        public static string EditCheckHoldCurrencyCode_Dropdown="Xpath;//select[@name='HLD8_CRCD']";
        public static string EditFloatHoldAmount_Field="Xpath;//input[@name='HLD7_AMT']";
        public static string EditFloatHoldCurrencyCode_Dropdown="Xpath;//select[@name='HLD7_CRCD']";


    }

}
