using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class SelectPackagePage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);


        /// <summary>
        /// This method is used to check most popular label exists for the specified package.
        /// </summary>
        /// <param name ="PackageName"/>
        /// <returns>true/false</returns> 
        /// <example>
        /// SelectPackagePage.CheckMostPopularLabelExists(PackageName);
        /// </example>
        public virtual bool CheckMostPopularLabelExists(string PackageName)
        {
            bool bCheck = false;
            try
            {
                string imgMostPopularLabel = "Xpath;//h2[contains(text(),'" + PackageName + "')]/parent::td/parent::tr/following-sibling::tr/td[@class='packageRecommended']//img[@src='images/mostpopular.gif']";
                bCheck = appHandle.IsObjectExists(imgMostPopularLabel);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;

        }
        /// <summary>
        /// This method is used to check product exists for the specified package..
        /// </summary>
        /// <param name ="PackageName"/>
        /// <param name = "ProductName"/>
        /// <returns>true/false</returns> 
        /// <example>
        /// SelectPackagePage.CheckProductExistsUnderSpecifiedPackage("packYE1244962","SAV8991");
        /// </example>
        public virtual bool CheckProductExistsUnderSpecifiedPackage(string PackageName, string ProductName)
        {
            bool bCheck = false;
            try
            {
                string obj = "Xpath;//h2[contains(text(),'" + PackageName + "')]/parent::td/parent::tr/following-sibling::*[1]//li[text()='" + ProductName + "']";
                bCheck = appHandle.IsObjectExists(obj);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;

        }

        /// <summary>
        /// To select Specified Package.
        /// <param name= "Package Name"></param> 
        /// <returns>bool</returns>
        /// <example>SelectSpecifiedPackage(sPackage)</example>
        public bool SelectSpecifiedPackage(string sPackage)
        {
            bool bcheck = false;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                string package = "XPath;(//h2[text()='" + sPackage + "']/parent::td/parent::tr/following-sibling::tr//input[@value='SELECT'])[1]";
                if (appHandle.IsObjectExists(package))
                {
                    appHandle.WaitUntilElementClickable(package);
                    appHandle.SelectButton(package);
                    bcheck = true;
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

        /// <summary>
        /// To select Specified Product in Package.
        /// <param name= "Product Description"></param> 
        /// <returns></returns>
        /// <example>SelectSpecifiedProductinPackage(sProdDesc)</example>
        public void SelectSpecifiedProductinPackage(string sProdDesc)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                string prod = "XPath;//td[text()='" + sProdDesc + "']/preceding-sibling::td/input";
                appHandle.WaitUntilElementClickable(prod);
                appHandle.ClickObject(prod);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select Number of Account for Product in Package.
        /// <param name= "Product Description"></param> 
        /// <param name= "No of Accounts"></param> 
        /// <returns></returns>
        /// <example>SelectNoOfAccforProductinPackage(sProdDesc,NoofAcc)</example>
        public void SelectNoOfAccforProductinPackage(string sProdDesc, string NoofAcc)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                string prod = "XPath;//td[text()='" + sProdDesc + "']/following-sibling::td/select";
                appHandle.WaitUntilElementClickable(prod);
                appHandle.SelectDropdownSpecifiedValue(prod, NoofAcc);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
    }
}