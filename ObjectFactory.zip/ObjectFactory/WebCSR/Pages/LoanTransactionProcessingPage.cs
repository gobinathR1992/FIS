using GTS_OSAF.CoreLibs;
using System.Collections.Generic;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class LoanTransactionProcessingPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string dropdownNegativeBalanceOption = "XPath;//*[contains(text(),'Negative Balance Option')]/following-sibling::td/descendant::select";

        public virtual void SelectSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.SelectButton(buttonSubmit);

        }

        public virtual bool VerifyMessageLoanTrasactionProcessingPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual bool WaitUntilOverdraftProcessingPageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownNegativeBalanceOption))
            {
                result = true;
            }

            return result;
        }
        public virtual void UpdateNegativeBalanceOption(string ItemToBeSelected)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownNegativeBalanceOption, ItemToBeSelected);
        }
    }
}