using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AddressPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string txtHomeAddressAddress1 = "Xpath;//input[@name='CIF_PAD1']";
        private static string txtHomeAddressAddress2 = "Xpath;//input[@name='CIF_PAD2']";
        private static string txtHomeAddressAddress3 = "Xpath;//input[@name='CIF_PAD3']";
        private static string txtHomeAddressTownship = "Xpath;//input[@name='CIF_PLOC']";
        private static string txtHomeAddressCounty = "Xpath;//input[@name='CIF_PCOUNTY']";
        private static string txtHomeAddressCity = "Xpath;//input[@name='CIF_PCITY']";
        private static string drpHomeAddressCountry = "Xpath;//select[@name='CIF_PCNTRY']";
        private static string drpHomeAddressState = "Xpath;//select[@name='CIF_PSTATE']";
        private static string txtHomeAddressZipCode = "Xpath;//input[@name='CIF_PZIP']";
        private static string txtMailingAddressAddress1 = "Xpath;//input[@name='CIF_MAD1']";
        private static string txtMailingAddressAddress2 = "Xpath;//input[@name='CIF_MAD2']";
        private static string txtMailingAddressAddress3 = "Xpath;//input[@name='CIF_MAD3']";
        private static string txtMailingAddressTownship = "Xpath;//input[@name='CIF_MLOC']";
        private static string txtMailingAddressCounty = "Xpath;//input[@name='CIF_MCOUNTY']";
        private static string txtMailingAddressCity = "Xpath;//input[@name='CIF_MCITY']";
        private static string txtMailingAddressZipCode = "Xpath;//input[@name='CIF_MZIP']";
        private static string drpMailingAddressCountry = "Xpath;//select[@name='CIF_MCNTRY']";
        private static string drpMailingAddressState = "Xpath;//select[@name='CIF_MSTATE']";
        private static string txtEffectiveDatesFutureDate = "Xpath;//input[@name='effectiveDate']";
        private static string txtEffectiveDatesExpirationDate = "Xpath;//input[@name='expirationDate']";
        private static string rdbSameasHomeAddress = "Xpath;//tr[4]//td[1]//table[1]//tbody[1]//tr[1]//td[2]//table[1]//tbody[1]//tr[1]//td[1]//input[1]";
        private static string rdbDoesthisaddressbelongtosomeoneelse = "Xpath;//tr[4]//td[1]//table[1]//tbody[1]//tr[2]//td[2]//table[1]//tbody[1]//tr[1]//td[1]//input[1]";
        private static string ckbAccounts = "Xpath;//input[@name='accountAddressChange[0]']";
        private static string tblHomeAddress = "Xpath;//body[@class='main']//tr//tr//tr//tr[2]//td[1]//table[1]";
        private static string tblMailingAddress = "Xpath;//body[@class='main']/table[@id='mainTable']/tbody/tr/td[@id='content']/table/tbody/tr/td/table/tbody/tr/td/form[@name='customerAddressChangeForm']/table[@class='contentTable']/tbody/tr[4]/td[1]/table[1]";
        private static string btnSubmit = "Xpath;//input[@name='submit']";
        private static string btnCancel = "Xpath;//input[@name='cancel']";
        private static string RadiobuttonMailAddrSameAsHomeAddr_NO = "XPath;//input[@name='mailAddressSameAsMain'][@value='N']";
        private static string RadiobuttonMailAddrSameAsHomeAddr_YES = "XPath;//input[@name='mailAddressSameAsMain'][@value='Y']";
        private static string txtPreviousAddr1 = "XPath;//*[@name='CIF_PRAD1']";
        private static string txtPreviousAddr2 = "XPath;//*[@name='CIF_PRAD2']";
        private static string txtPreviousCity = "XPath;//*[@name='CIF_PRCITY']";
        private static string dropdownPreviousCountry = "XPath;//*[@name='CIF_PRCNTRY']";
        private static string txtPreviousAddrZipCode = "XPath;//*[@name='CIF_PRZIP']";
        private static string txtSeasonalAddrStartDate = "XPath;//*[@name='SADDRCIF_SADSD']";
        private static string txtSeasonalAddrEndDate = "XPath;//*[@name='SADDRCIF_SADED']";
        private static string txtSeasonalAddrLine1 = "XPath;//*[@name='SADDRCIF_SAD1']";
        private static string txtSeasonalAddrLine2 = "XPath;//*[@name='SADDRCIF_SAD2']";
        private static string txtSeasonalAddrCity = "XPath;//*[@name='SADDRCIF_SCITY']";
        private static string dropdownSeasonalCountry = "XPath;//*[@name='SADDRCIF_SCNTRY']";
        private static string txtSeasonaladdrZIP = "XPAth;//*[@name='SADDRCIF_SZIP']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p[1]";
        private static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";



        public virtual void EnterHomeAddressDetails(string sHAddress1, string sCity, string sCountry, string sState, string sZipcode)
        {
            //Method to Enter the Home address details.
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(txtHomeAddressAddress1, sHAddress1);
            appHandle.Set_field_value(txtHomeAddressCity, sCity);
            appHandle.Set_field_value(txtHomeAddressZipCode, sZipcode);
            appHandle.SelectDropdownSpecifiedValue(drpHomeAddressCountry, sCountry);
            appHandle.SelectDropdownSpecifiedValue(drpHomeAddressState, sState);
            Report.Info("Entered the Home Address Details");
        }

        public virtual void EnterMailingAddressDetails(string sMaddress1, string sCity, string sCountry, string sState, string sZipcode)
        {
            //Method to enter the Mailing address details.
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(txtMailingAddressAddress1, sMaddress1);
            appHandle.Set_field_value(txtMailingAddressCity, sCity);
            appHandle.Set_field_value(txtMailingAddressZipCode, sZipcode);
            appHandle.SelectDropdownSpecifiedValue(drpMailingAddressCountry, sCountry);
            appHandle.SelectDropdownSpecifiedValue(drpMailingAddressState, sState);
            Report.Info("Entered the Mailing Address Details");
        }

        public virtual void EntertheEffectiveDates(string sFDate, string sEDate)
        {
            //Method to Enter the Dates.
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(txtEffectiveDatesFutureDate, sFDate);
            appHandle.Set_field_value(txtEffectiveDatesExpirationDate, sEDate);
            Report.Info("Entered the Date");

        }
        public virtual void ClickonSubmitbutton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnSubmit))
            {
                appHandle.ClickObjectViaJavaScript(btnSubmit);
            }
        }

        public virtual void ClickonCancelbutton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(btnCancel);
        }
        public virtual bool VerifyCountryInHomeAddress(string CountryName)
        {
            bool Result = false;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpHomeAddressCountry);
            if (appHandle.CheckValueInDropdown(drpHomeAddressCountry, CountryName))
            {
                appHandle.ScrollToObject(drpHomeAddressCountry);
                Result = true;
            }
            return Result;
        }
        public virtual bool VerifyUpdateAddr_CZ(bool IsHomeAddr = false, bool IsMailingAddr = false, bool IsPreviousAddr = false, bool IsSeasonalAddr = false)
        {
            bool Result = false;
            if (IsHomeAddr)
            {
                appHandle.Set_field_value(txtHomeAddressAddress1, Data.Get("CITYCZ") + " Manson");
                appHandle.Set_field_value(txtHomeAddressAddress2, Data.Get("CITYCZ") + "Building");
                appHandle.Set_field_value(txtHomeAddressCity, Data.Get("CITYCZ"));
                appHandle.SelectDropdownSpecifiedValue(drpHomeAddressCountry, (string)Data.Get("CZ - CZECHIA"));
                appHandle.Set_field_value(txtHomeAddressZipCode, Data.Get("ZIPCODE_CZ"));
                Report.Info("Home address with Country code " + Data.Get("CZ - CZECHIA") + " is entered successfully.", "CZ_Home_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsMailingAddr)
            {
                appHandle.ClickObjectViaJavaScript(RadiobuttonMailAddrSameAsHomeAddr_NO);
                appHandle.Set_field_value(txtMailingAddressAddress1, Data.Get("CITYCZ") + " Manson");
                appHandle.Set_field_value(txtMailingAddressAddress2, Data.Get("CITYCZ") + "Building");
                appHandle.Set_field_value(txtMailingAddressCity, Data.Get("CITYCZ"));
                appHandle.SelectDropdownSpecifiedValue(drpMailingAddressCountry, (string)Data.Get("CZ - CZECHIA"));
                appHandle.Set_field_value(txtMailingAddressZipCode, Data.Get("ZIPCODE_CZ"));
                Report.Info("Mailing address with Country code " + Data.Get("CZ - CZECHIA") + " is entered successfully.", "CZ_Mail_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsPreviousAddr)
            {
                appHandle.Set_field_value(txtPreviousAddr1, Data.Get("CITYCZ") + " Manson");
                appHandle.Set_field_value(txtPreviousAddr2, Data.Get("CITYCZ") + "Building");
                appHandle.Set_field_value(txtPreviousCity, Data.Get("CITYCZ"));
                appHandle.SelectDropdownSpecifiedValue(dropdownPreviousCountry, (string)Data.Get("CZ - CZECHIA"));
                appHandle.Set_field_value(txtPreviousAddrZipCode, Data.Get("ZIPCODE_CZ"));
                Report.Info("Previous address with Country code " + Data.Get("CZ - CZECHIA") + " is entered successfully.", "CZ_Previous_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsSeasonalAddr)
            {
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Seasonal Address"));
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSeasonalAddrLine1);
                string StartDate = appHandle.CalculateNewDate(ApplicationDate, "D", 1);
                string EndDate = appHandle.CalculateNewDate(ApplicationDate, "M", 2);
                appHandle.Set_field_value(txtSeasonalAddrStartDate, StartDate);
                appHandle.Set_field_value(txtSeasonalAddrEndDate, EndDate);
                appHandle.Set_field_value(txtSeasonalAddrLine1, Data.Get("CITYCZ") + " Manson");
                appHandle.Set_field_value(txtSeasonalAddrLine2, Data.Get("CITYCZ") + "Building");
                appHandle.Set_field_value(txtSeasonalAddrCity, Data.Get("CITYCZ"));
                appHandle.SelectDropdownSpecifiedValue(dropdownSeasonalCountry, (string)Data.Get("CZ - CZECHIA"));
                appHandle.Set_field_value(txtSeasonaladdrZIP, Data.Get("ZIPCODE_CZ"));
                Report.Info("Seasonal address with Country code " + Data.Get("CZ - CZECHIA") + " is entered successfully.", "CZ_Seasonal_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyUpdateAddr_TF(bool IsHomeAddr = false, bool IsMailingAddr = false, bool IsPreviousAddr = false, bool IsSeasonalAddr = false)
        {
            bool Result = false;
            if (IsHomeAddr)
            {
                appHandle.Set_field_value(txtHomeAddressAddress1, Data.Get("CITYTF") + " Manson");
                appHandle.Set_field_value(txtHomeAddressAddress2, Data.Get("CITYTF") + "Building");
                appHandle.Set_field_value(txtHomeAddressCity, Data.Get("CITYTF"));
                appHandle.SelectDropdownSpecifiedValue(drpHomeAddressCountry, (string)Data.Get("TF - FRENCH SOUTHERN TERRITORIES"));
                appHandle.Set_field_value(txtHomeAddressZipCode, Data.Get("ZIPCODE_TF"));
                Report.Info("Home address with Country code " + Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + " is entered successfully.", "TF_Home_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsMailingAddr)
            {
                appHandle.ClickObjectViaJavaScript(RadiobuttonMailAddrSameAsHomeAddr_NO);
                appHandle.Set_field_value(txtMailingAddressAddress1, Data.Get("CITYTF") + " Manson");
                appHandle.Set_field_value(txtMailingAddressAddress2, Data.Get("CITYTF") + "Building");
                appHandle.Set_field_value(txtMailingAddressCity, Data.Get("CITYTF"));
                appHandle.SelectDropdownSpecifiedValue(drpMailingAddressCountry, (string)Data.Get("TF - FRENCH SOUTHERN TERRITORIES"));
                appHandle.Set_field_value(txtMailingAddressZipCode, Data.Get("ZIPCODE_TF"));
                Report.Info("Mailing address with Country code " + Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + " is entered successfully.", "TF_Mail_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsPreviousAddr)
            {
                appHandle.Set_field_value(txtPreviousAddr1, Data.Get("CITYTF") + " Manson");
                appHandle.Set_field_value(txtPreviousAddr2, Data.Get("CITYTF") + "Building");
                appHandle.Set_field_value(txtPreviousCity, Data.Get("CITYTF"));
                appHandle.SelectDropdownSpecifiedValue(dropdownPreviousCountry, (string)Data.Get("TF - FRENCH SOUTHERN TERRITORIES"));
                appHandle.Set_field_value(txtPreviousAddrZipCode, Data.Get("ZIPCODE_TF"));
                Report.Info("Previous address with Country code " + Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + " is entered successfully.", "TF_Previous_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsSeasonalAddr)
            {
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Seasonal Address"));
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSeasonalAddrLine1);
                string StartDate = appHandle.CalculateNewDate(ApplicationDate, "D", 1);
                string EndDate = appHandle.CalculateNewDate(ApplicationDate, "M", 2);
                appHandle.Set_field_value(txtSeasonalAddrStartDate, StartDate);
                appHandle.Set_field_value(txtSeasonalAddrEndDate, EndDate);
                appHandle.Set_field_value(txtSeasonalAddrLine1, Data.Get("CITYTF") + " Manson");
                appHandle.Set_field_value(txtSeasonalAddrLine2, Data.Get("CITYTF") + "Building");
                appHandle.Set_field_value(txtSeasonalAddrCity, Data.Get("CITYTF"));
                appHandle.SelectDropdownSpecifiedValue(dropdownSeasonalCountry, (string)Data.Get("TF - FRENCH SOUTHERN TERRITORIES"));
                appHandle.Set_field_value(txtSeasonaladdrZIP, Data.Get("ZIPCODE_TF"));
                Report.Info("Seasonal address with Country code " + Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + " is entered successfully.", "CZ_Seasonal_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual bool VerifyUpdateAddr_VA(bool IsHomeAddr = false, bool IsMailingAddr = false, bool IsPreviousAddr = false, bool IsSeasonalAddr = false)
        {
            bool Result = false;
            if (IsHomeAddr)
            {
                appHandle.Set_field_value(txtHomeAddressAddress1, Data.Get("CITYVA") + " Manson");
                appHandle.Set_field_value(txtHomeAddressAddress2, Data.Get("CITYVA") + "Building");
                appHandle.Set_field_value(txtHomeAddressCity, Data.Get("CITYVA"));
                appHandle.SelectDropdownSpecifiedValue(drpHomeAddressCountry, (string)Data.Get("VA - HOLY SEE"));
                appHandle.Set_field_value(txtHomeAddressZipCode, Data.Get("ZIPCODE_VA"));
                Report.Info("Home address with Country code " + Data.Get("VA - HOLY SEE") + " is entered successfully.", "VA_Home_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsMailingAddr)
            {
                appHandle.ClickObjectViaJavaScript(RadiobuttonMailAddrSameAsHomeAddr_NO);
                appHandle.Set_field_value(txtMailingAddressAddress1, Data.Get("CITYVA") + " Manson");
                appHandle.Set_field_value(txtMailingAddressAddress2, Data.Get("CITYVA") + "Building");
                appHandle.Set_field_value(txtMailingAddressCity, Data.Get("CITYVA"));
                appHandle.SelectDropdownSpecifiedValue(drpMailingAddressCountry, (string)Data.Get("VA - HOLY SEE"));
                appHandle.Set_field_value(txtMailingAddressZipCode, Data.Get("ZIPCODE_VA"));
                Report.Info("Mailing address with Country code " + Data.Get("VA - HOLY SEE") + " is entered successfully.", "VA_Mail_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsPreviousAddr)
            {
                appHandle.Set_field_value(txtPreviousAddr1, Data.Get("CITYVA") + " Manson");
                appHandle.Set_field_value(txtPreviousAddr2, Data.Get("CITYVA") + "Building");
                appHandle.Set_field_value(txtPreviousCity, Data.Get("CITYVA"));
                appHandle.SelectDropdownSpecifiedValue(dropdownPreviousCountry, (string)Data.Get("VA - HOLY SEE"));
                appHandle.Set_field_value(txtPreviousAddrZipCode, Data.Get("ZIPCODE_VA"));
                Report.Info("Previous address with Country code " + Data.Get("VA - HOLY SEE") + " is entered successfully.", "VA_Previous_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsSeasonalAddr)
            {
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Seasonal Address"));
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSeasonalAddrLine1);
                string StartDate = appHandle.CalculateNewDate(ApplicationDate, "D", 1);
                string EndDate = appHandle.CalculateNewDate(ApplicationDate, "M", 2);
                appHandle.Set_field_value(txtSeasonalAddrStartDate, StartDate);
                appHandle.Set_field_value(txtSeasonalAddrEndDate, EndDate);
                appHandle.Set_field_value(txtSeasonalAddrLine1, Data.Get("CITYVA") + " Manson");
                appHandle.Set_field_value(txtSeasonalAddrLine2, Data.Get("CITYVA") + "Building");
                appHandle.Set_field_value(txtSeasonalAddrCity, Data.Get("CITYVA"));
                appHandle.SelectDropdownSpecifiedValue(dropdownSeasonalCountry, (string)Data.Get("VA - HOLY SEE"));
                appHandle.Set_field_value(txtSeasonaladdrZIP, Data.Get("ZIPCODE_VA"));
                Report.Info("Seasonal address with Country code " + Data.Get("VA - HOLY SEE") + " is entered successfully.", "VA_Seasonal_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyUpdateAddr_WF(bool IsHomeAddr = false, bool IsMailingAddr = false, bool IsPreviousAddr = false, bool IsSeasonalAddr = false)
        {
            bool Result = false;
            if (IsHomeAddr)
            {
                appHandle.Set_field_value(txtHomeAddressAddress1, Data.Get("CITYWF") + " Manson");
                appHandle.Set_field_value(txtHomeAddressAddress2, Data.Get("CITYWF") + "Building");
                appHandle.Set_field_value(txtHomeAddressCity, Data.Get("CITYWF"));
                appHandle.SelectDropdownSpecifiedValue(drpHomeAddressCountry, (string)Data.Get("WF - WALLIS AND FUTUNA"));
                appHandle.Set_field_value(txtHomeAddressZipCode, Data.Get("ZIPCODE_WF"));
                Report.Info("Home address with Country code " + Data.Get("WF - WALLIS AND FUTUNA") + " is entered successfully.", "WF_Home_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsMailingAddr)
            {
                appHandle.ClickObjectViaJavaScript(RadiobuttonMailAddrSameAsHomeAddr_NO);
                appHandle.Set_field_value(txtMailingAddressAddress1, Data.Get("CITYWF") + " Manson");
                appHandle.Set_field_value(txtMailingAddressAddress2, Data.Get("CITYWF") + "Building");
                appHandle.Set_field_value(txtMailingAddressCity, Data.Get("CITYWF"));
                appHandle.SelectDropdownSpecifiedValue(drpMailingAddressCountry, (string)Data.Get("WF - WALLIS AND FUTUNA"));
                appHandle.Set_field_value(txtMailingAddressZipCode, Data.Get("ZIPCODE_WF"));
                Report.Info("Mailing address with Country code " + Data.Get("WF - WALLIS AND FUTUNA") + " is entered successfully.", "WF_Mail_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsPreviousAddr)
            {
                appHandle.Set_field_value(txtPreviousAddr1, Data.Get("CITYWF") + " Manson");
                appHandle.Set_field_value(txtPreviousAddr2, Data.Get("CITYWF") + "Building");
                appHandle.Set_field_value(txtPreviousCity, Data.Get("CITYWF"));
                appHandle.SelectDropdownSpecifiedValue(dropdownPreviousCountry, (string)Data.Get("WF - WALLIS AND FUTUNA"));
                appHandle.Set_field_value(txtPreviousAddrZipCode, Data.Get("ZIPCODE_WF"));
                Report.Info("Previous address with Country code " + Data.Get("WF - WALLIS AND FUTUNA") + " is entered successfully.", "WF_Previous_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsSeasonalAddr)
            {
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Seasonal Address"));
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSeasonalAddrLine1);
                string StartDate = appHandle.CalculateNewDate(ApplicationDate, "D", 1);
                string EndDate = appHandle.CalculateNewDate(ApplicationDate, "M", 2);
                appHandle.Set_field_value(txtSeasonalAddrStartDate, StartDate);
                appHandle.Set_field_value(txtSeasonalAddrEndDate, EndDate);
                appHandle.Set_field_value(txtSeasonalAddrLine1, Data.Get("CITYWF") + " Manson");
                appHandle.Set_field_value(txtSeasonalAddrLine2, Data.Get("CITYWF") + "Building");
                appHandle.Set_field_value(txtSeasonalAddrCity, Data.Get("CITYWF"));
                appHandle.SelectDropdownSpecifiedValue(dropdownSeasonalCountry, (string)Data.Get("WF - WALLIS AND FUTUNA"));
                appHandle.Set_field_value(txtSeasonaladdrZIP, Data.Get("ZIPCODE_WF"));
                Report.Info("Seasonal address with Country code " + Data.Get("WF - WALLIS AND FUTUNA") + " is entered successfully.", "WF_Seasonal_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual bool VerifyUpdateAddr_MK(bool IsHomeAddr = false, bool IsMailingAddr = false, bool IsPreviousAddr = false, bool IsSeasonalAddr = false)
        {
            bool Result = false;
            if (IsHomeAddr)
            {
                appHandle.Set_field_value(txtHomeAddressAddress1, Data.Get("CITYMK") + " Manson");
                appHandle.Set_field_value(txtHomeAddressAddress2, Data.Get("CITYMK") + "Building");
                appHandle.Set_field_value(txtHomeAddressCity, Data.Get("CITYMK"));
                appHandle.SelectDropdownSpecifiedValue(drpHomeAddressCountry, (string)Data.Get("MK - NORTH MACEDONIA"));
                appHandle.Set_field_value(txtHomeAddressZipCode, Data.Get("ZIPCODE_MK"));
                Report.Info("Home address with Country code " + Data.Get("MK - NORTH MACEDONIA") + " is entered successfully.", "MK_Home_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsMailingAddr)
            {
                appHandle.ClickObjectViaJavaScript(RadiobuttonMailAddrSameAsHomeAddr_NO);
                appHandle.Set_field_value(txtMailingAddressAddress1, Data.Get("CITYMK") + " Manson");
                appHandle.Set_field_value(txtMailingAddressAddress2, Data.Get("CITYMK") + "Building");
                appHandle.Set_field_value(txtMailingAddressCity, Data.Get("CITYMK"));
                appHandle.SelectDropdownSpecifiedValue(drpMailingAddressCountry, (string)Data.Get("MK - NORTH MACEDONIA"));
                appHandle.Set_field_value(txtMailingAddressZipCode, Data.Get("ZIPCODE_MK"));
                Report.Info("Mailing address with Country code " + Data.Get("MK - NORTH MACEDONIA") + " is entered successfully.", "MK_Mail_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsPreviousAddr)
            {
                appHandle.Set_field_value(txtPreviousAddr1, Data.Get("CITYMK") + " Manson");
                appHandle.Set_field_value(txtPreviousAddr2, Data.Get("CITYMK") + "Building");
                appHandle.Set_field_value(txtPreviousCity, Data.Get("CITYMK"));
                appHandle.SelectDropdownSpecifiedValue(dropdownPreviousCountry, (string)Data.Get("MK - NORTH MACEDONIA"));
                appHandle.Set_field_value(txtPreviousAddrZipCode, Data.Get("ZIPCODE_MK"));
                Report.Info("Previous address with Country code " + Data.Get("MK - NORTH MACEDONIA") + " is entered successfully.", "MK_Previous_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }
            if (IsSeasonalAddr)
            {
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Seasonal Address"));
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSeasonalAddrLine1);
                string StartDate = appHandle.CalculateNewDate(ApplicationDate, "D", 1);
                string EndDate = appHandle.CalculateNewDate(ApplicationDate, "M", 2);
                appHandle.Set_field_value(txtSeasonalAddrStartDate, StartDate);
                appHandle.Set_field_value(txtSeasonalAddrEndDate, EndDate);
                appHandle.Set_field_value(txtSeasonalAddrLine1, Data.Get("CITYMK") + " Manson");
                appHandle.Set_field_value(txtSeasonalAddrLine2, Data.Get("CITYMK") + "Building");
                appHandle.Set_field_value(txtSeasonalAddrCity, Data.Get("CITYMK"));
                appHandle.SelectDropdownSpecifiedValue(dropdownSeasonalCountry, (string)Data.Get("MK - NORTH MACEDONIA"));
                appHandle.Set_field_value(txtSeasonaladdrZIP, Data.Get("ZIPCODE_MK"));
                Report.Info("Seasonal address with Country code " + Data.Get("MK - NORTH MACEDONIA") + " is entered successfully.", "MK_Seasonal_Addr", "true", appHandle);
                ClickonSubmitbutton();
                if (VerifyMSGInAddressPage(Data.Get("The address information has been updated.")))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyMSGInAddressPage(string inputMSG)
        {
            bool result = false;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Contains(inputMSG))
            {
                result = true;
            }
            return result;
        }
        public static string ApplicationDate = new AddressPage().GetApplicationDate();
        public virtual string GetApplicationDate()
        {
            string result = "";

            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }


        public virtual void SelectValueOfSameAsHomeAddressRadioButton(bool value)
        {
            string selval = "";
            if (value)
            {
                selval = "Y";
            }
            else
            {
                selval = "N";
            }
            string dynobj = "Xpath;//input[@name='mailAddressSameAsMain'][@value='" + selval + "']";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnSubmit);
            appHandle.ClickObjectViaJavaScript(dynobj);

        }

        public virtual bool checkSuccessMessage()
        {
            bool Result=false;

            string msg = Data.Get("The address information has been updated.");
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
            Result= appHandle.CheckSuccessMessage(msg);
            }

            return Result;
        }
        public virtual string GetStreetName()
        {
            string addrline1 = "";

            addrline1 = appHandle.GetObjectText(txtHomeAddressAddress1);
            return addrline1;
        }
public virtual string GetCityName()
{
    string HomeCity="";

HomeCity=appHandle.GetObjectText(txtHomeAddressCity);
    return HomeCity;
}
    }

}
