using System;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using OpenQA.Selenium;
using System.Linq;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class HoldsPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string drpHoldsAccount = "Xpath;//*[contains(text(),'Account')]/following-sibling::*/select[contains(@name, 'accountNumber')]";
        public static string buttonAdd = "XPath;//*[contains(@name, 'add')]";
        private static string dropdownHoldType = "XPath;//*[contains(text(),'Hold Type')]/following-sibling::*/select";
        private static string dropdownHoldCode = "XPath;//select[@name='PHLD_PHC']";
        private static string txtPermanentHoldFixedAmount = "XPath;//*[@name='PHLD_AMT']";
        private static string txtPermanentHoldStartDate = "XPath;//*[@name='PHLD_STDT']";
        private static string txtPermanentHoldEndDate = "XPath;//*[@name='PHLD_EXPDT']";
        private static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        private static string txtHoldComment = "XPath;//*[@name='PHLD_TCMT']";
        private static string buttonSubmit = "Xpath;//*[@name='submit']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string dropddownCurrencyCodeCheckTypeHold = "XPath;//*[contains(text(),'Amount')]/following-sibling::*/select[@name='HLD8_CRCD']";
        private static string dropddownCurrencyCodeFloatTypeHold = "XPath;//*[contains(text(),'Amount')]/following-sibling::*/select[@name='HLD7_CRCD']";
        private static string txtCheckHoldTypeAmount = "XPath;//*[@name='HLD8_AMT']";
        private static string txtCheckHoldTypeExpirationDate = "XPath;//*[@name='HLD8_EXPDT']";
        private static string txtFloatHoldTypeAmount = "XPath;//*[@type='text'][@name='HLD7_AMT']";
        private static string txtFloatHoldTypeExpirationDate = "XPath;//*[@type='text'][@name='HLD7_EXPDT']";
        private static string txtHoldPercentage = "XPath;//*[@name='PHLD_PERCNT']";
        private static string txtPercentageOfAccountBalanceAccount = "XPath;//*[@name='PHLD_AREF']";
        private static string dropdownBalanceType = "XPath;//*[@name='PHLD_COMP']";
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string buttonDelete = "XPath;//*[@value='Delete']";
        private static string linkHoldDetailDialogClose = "XPath;//*[contains(@class,'ui-dialog ui-widget')]/descendant::*[text()='Hold Detail']/following-sibling::a";
        private static string tableHoldDetailDialog = "XPath;//*[contains(@class,'ui-dialog ui-widget')]/descendant::*/*[@class='contentTable']/tbody";
        private static string labelvalTotalHoldAmount = "Xpath;//*[contains(text(),'Total Hold Amount')]/following-sibling::*";
        private static string dropddownCurrencyCodePHLD = "XPath;//*[contains(text(),'Currency Code')]/following-sibling::*/descendant::select";
        private static string lblAvailableBalance = "Xpath;//*[@class='fieldLabelLeft'][contains(.,'Account Available Balance:')]/following-sibling::td";
        private static string lblAmountOfBalanceHeld = "Xpath;//*[contains(text(),'Amount of Balance Held')]/following-sibling::*/*[1]";
        private static string buttonCancel = "XPath;//*[@value='Cancel']";
        string tableHolds = "XPath;//*[contains(text(),'Expiration Date')]/ancestor::thead/following-sibling::tbody";
        private static string HoldTable="Xpath;.//*[contains(@class,'ledgerScrollable dataTable')]/tbody";
        private static string DeleteButton="Xpath;.//input[@name='delete']";
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
            }
        }
        /// <summary>
        /// This method is select account from account dropdown.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.HoldsPage.SelectAccountFromDropdown();
        /// </example>
        public virtual void SelectAccountFromDropdown(string sAccountNumber)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpHoldsAccount))
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpHoldsAccount, sAccountNumber);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
        }

        /// <summary>
        /// This method is used to check column exists in CheckHoldsTable.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.HoldsPage.CheckHoldsTable();
        /// </example>
        public virtual bool CheckColumnExistsInTable(string sTableName, string sColumnName)
        {
            bool bCheck = false;
            try
            {
                bCheck = appHandle.CheckSpecifiedColumnExistsInTable(sTableName, sColumnName);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;

        }
        public virtual bool VerifyDataInHoldsTable(string AccountNumber, string HoldType, string Amount, string ExpirationDate = "")
        {
            bool result = false;
            string inputXPath = "", tempHoldType = "";
            this.SelectAccountFromDropdown(AccountNumber);
            if (Amount.Any(char.IsLetter)) { Amount = Amount.Split(' ')[0].Trim(); }
            else
            {
                Amount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Amount);
            }
            if (HoldType.Contains("-"))
            {
                tempHoldType = HoldType.Split('-')[1].Trim();
            }
            else
            {
                tempHoldType = HoldType;
            }
            if (!string.IsNullOrEmpty(ExpirationDate))
            {
                inputXPath = "Xpath;//*[contains(text(),'" + tempHoldType + "')]/ancestor::tr/descendant::td[contains(text(),'" + Amount + "')]/ancestor::tr/descendant::td[contains(text(),'" + ExpirationDate + "')]";
            }
            else
            {
                inputXPath = "Xpath;//*[contains(text(),'" + HoldType + "')]/ancestor::tr/descendant::td[contains(text(),'" + Amount + "')]";
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(inputXPath))
            {
                result = true;
            }
            return result;
        }
        public virtual string AddHoldForSpecifiedAccountNumber(string AccountNumber, string HoldType, string Amount, string sHoldCode, string ExpirationDate = "", string PercentageOfAccountBalanceHoldPercentage = "", string PercentageOfAccountBalanceAccountNo = "", string PercentageOfAccountBalanceBalanceType = "", string CurrencyCode = "", string HoldStartDate = "")
        {
            string TotalHoldAmount = "";
            this.SelectAccountFromDropdown(AccountNumber);
            this.ClickOnAddButton();
            if (string.IsNullOrEmpty(HoldStartDate))
            {
                HoldStartDate = ApplicationDate;
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownHoldType);

            switch (HoldType)
            {
                case "PHLD - Permanent Hold":
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldType, Data.Get("PHLD - Permanent Hold"));
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownHoldCode);
                    appHandle.Set_field_value(txtPermanentHoldStartDate, HoldStartDate);
                    appHandle.Set_field_value(txtPermanentHoldEndDate, ExpirationDate);
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldCode, sHoldCode);
                    if (!string.IsNullOrEmpty(CurrencyCode))
                    {
                        appHandle.SelectDropdownSpecifiedValueByPartialText(dropddownCurrencyCodePHLD, CurrencyCode);
                    }
                    appHandle.Set_field_value(txtHoldComment, "Hold to be placed with Details ::  Account Number : " + AccountNumber + " , Hold Type : " + HoldType + " + Amount : " + Amount + " + Hold Code : " + sHoldCode + " + Expiration Date : " + ExpirationDate);
                    appHandle.Set_field_value(txtPermanentHoldFixedAmount, Amount);
                    if (!string.IsNullOrEmpty(Amount)
                   && !string.IsNullOrEmpty(PercentageOfAccountBalanceHoldPercentage)
                   && !string.IsNullOrEmpty(PercentageOfAccountBalanceAccountNo)
                   && !string.IsNullOrEmpty(PercentageOfAccountBalanceBalanceType))
                    {
                        TotalHoldAmount = CalculateTotalHoldAmountWhileAddingHold(Amount, PercentageOfAccountBalanceHoldPercentage, PercentageOfAccountBalanceAccountNo, PercentageOfAccountBalanceBalanceType);
                    }
                    else
                    {
                        TotalHoldAmount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Amount);
                    }
                    if (!string.IsNullOrEmpty(PercentageOfAccountBalanceHoldPercentage))
                    {
                        appHandle.Set_field_value(txtHoldPercentage, PercentageOfAccountBalanceHoldPercentage);
                    }
                    if (!string.IsNullOrEmpty(PercentageOfAccountBalanceAccountNo))
                    {
                        appHandle.Set_field_value(txtPercentageOfAccountBalanceAccount, PercentageOfAccountBalanceAccountNo);
                    }
                    if (!string.IsNullOrEmpty(PercentageOfAccountBalanceBalanceType))
                    {
                        appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBalanceType, PercentageOfAccountBalanceBalanceType);
                    }

                    break;
                case "HLD8 - Check Hold":
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownHoldType);
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldType, Data.Get("HLD8 - Check Hold"));
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropddownCurrencyCodeCheckTypeHold);
                    if (!string.IsNullOrEmpty(CurrencyCode))
                    {
                        appHandle.SelectDropdownSpecifiedValueByPartialText(dropddownCurrencyCodeCheckTypeHold, CurrencyCode);
                    }
                    appHandle.Set_field_value(txtCheckHoldTypeAmount, Amount);
                    appHandle.Set_field_value(txtCheckHoldTypeExpirationDate, ExpirationDate);
                    TotalHoldAmount = Amount;
                    break;
                case "HLD7 - Float Hold":
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownHoldType);
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldType, Data.Get("HLD7 - Float Hold"));
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropddownCurrencyCodeFloatTypeHold);
                    if (!string.IsNullOrEmpty(CurrencyCode))
                    {
                        appHandle.SelectDropdownSpecifiedValueByPartialText(dropddownCurrencyCodeFloatTypeHold, CurrencyCode);
                    }
                    appHandle.Set_field_value(txtFloatHoldTypeAmount, Amount);
                    appHandle.Set_field_value(txtFloatHoldTypeExpirationDate, ExpirationDate);
                    TotalHoldAmount = Amount;
                    break;
            }

            return TotalHoldAmount;
        }
        public static string ApplicationDate = new HoldsPage().GetApplicationDate();
        public virtual string GetApplicationDate()
        {
            string result = "";

            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMSGInHoldsPage(string inputMSG)
        {
            bool result = false;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Contains(inputMSG))
            {
                result = true;
            }
            return result;
        }

        public virtual string EditHoldForSpecifiedAccountNumber(string AccountNumber, string HoldType, string FixedAmount, string AmountToBeSelectedInHoldsTable = "", string sHoldCode = "", string ExpirationDate = "", string PercentageOfAccountBalanceHoldPercentage = "", string PercentageOfAccountBalanceAccountNo = "", string PercentageOfAccountBalanceBalanceType = "")
        {

            string inputRadioButtonXPath = "";
            string tempHoldType = "";
            string TotalHoldAmount = "";
            this.SelectAccountFromDropdown(AccountNumber);
            if (AmountToBeSelectedInHoldsTable.Any(char.IsLetter)) { AmountToBeSelectedInHoldsTable = AmountToBeSelectedInHoldsTable.Split(' ')[0].Trim(); }
            else
            {
                AmountToBeSelectedInHoldsTable = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(AmountToBeSelectedInHoldsTable);
            }
            if (HoldType.Contains("-"))
            {
                tempHoldType = HoldType.Split('-')[1].Trim();
            }
            inputRadioButtonXPath = "Xpath;//*[contains(text(),'" + tempHoldType + "')]/ancestor::tr/descendant::td[contains(text(),'" + AmountToBeSelectedInHoldsTable + "')]/ancestor::tr[1]/descendant::td[1]/input[@type='radio']";

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(inputRadioButtonXPath))
            {
                appHandle.ClickObjectViaJavaScript(inputRadioButtonXPath);
            }
            this.ClickOnEditButton();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);

            switch (HoldType)
            {
                case "PHLD - Permanent Hold":
                    if (!string.IsNullOrEmpty(ExpirationDate))
                    {
                        appHandle.Set_field_value(txtPermanentHoldEndDate, ExpirationDate);
                    }
                    if (!string.IsNullOrEmpty(sHoldCode))
                    {
                        appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldCode, sHoldCode);
                    }
                    appHandle.Set_field_value(txtHoldComment, "Hold to be modified with Details ::  Account Number : AccountNumber + " + " , Hold Type : " + HoldType + " + Amount : " + FixedAmount + " + Hold Code : " + sHoldCode + " + Expiration Date : " + ExpirationDate);
                    if (!string.IsNullOrEmpty(FixedAmount))
                    {
                        appHandle.Set_field_value(txtPermanentHoldFixedAmount, FixedAmount);
                    }
                    if (!string.IsNullOrEmpty(FixedAmount)
                    && !string.IsNullOrEmpty(PercentageOfAccountBalanceHoldPercentage)
                    && !string.IsNullOrEmpty(PercentageOfAccountBalanceAccountNo)
                    && !string.IsNullOrEmpty(PercentageOfAccountBalanceBalanceType))
                    {
                        TotalHoldAmount = CalculateTotalHoldAmountWhileAddingHold(FixedAmount, PercentageOfAccountBalanceHoldPercentage, PercentageOfAccountBalanceAccountNo, PercentageOfAccountBalanceBalanceType);
                    }
                    else
                    {
                        TotalHoldAmount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(FixedAmount);
                    }
                    if (!string.IsNullOrEmpty(PercentageOfAccountBalanceHoldPercentage))
                    {
                        appHandle.Set_field_value(txtHoldPercentage, PercentageOfAccountBalanceHoldPercentage);
                    }
                    if (!string.IsNullOrEmpty(PercentageOfAccountBalanceAccountNo))
                    {
                        appHandle.Set_field_value(txtPercentageOfAccountBalanceAccount, PercentageOfAccountBalanceAccountNo);
                    }
                    if (!string.IsNullOrEmpty(PercentageOfAccountBalanceBalanceType))
                    {
                        appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBalanceType, PercentageOfAccountBalanceBalanceType);
                    }

                    break;
                case "HLD8 - Check Hold":

                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropddownCurrencyCodeCheckTypeHold);
                    if (!string.IsNullOrEmpty(FixedAmount))
                    {
                        appHandle.Set_field_value(txtCheckHoldTypeAmount, FixedAmount);
                    }
                    if (!string.IsNullOrEmpty(ExpirationDate))
                    {
                        appHandle.Set_field_value(txtCheckHoldTypeExpirationDate, ExpirationDate);
                    }
                    TotalHoldAmount = FixedAmount;
                    break;
                case "HLD7 - Float Hold":
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropddownCurrencyCodeFloatTypeHold);
                    if (!string.IsNullOrEmpty(FixedAmount))
                    {
                        appHandle.Set_field_value(txtFloatHoldTypeAmount, FixedAmount);
                    }
                    if (!string.IsNullOrEmpty(ExpirationDate))
                    {
                        appHandle.Set_field_value(txtFloatHoldTypeExpirationDate, ExpirationDate);
                    }
                    TotalHoldAmount = FixedAmount;
                    break;
            }
            return TotalHoldAmount;
        }
        public virtual void ClickOnEditButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
            }
        }
        public virtual bool VerifyDataInHoldDetailPage(string AccountNumber, string HoldType, string Amount, string LabelNameLabelValuePipeDelimited, string ExpirationDate = "")
        {
            bool Result = false;
            string inputRadioButtonXPath = "";
            string tempHoldType = "";
            string HoldTypelinkobj = "";
            if (Amount.Any(char.IsLetter)) { Amount = Amount.Split(' ')[0].Trim(); }
            else
            {
                Amount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Amount);
            }

            if (HoldType.Contains("-"))
            {
                tempHoldType = HoldType.Split('-')[1].Trim();
            }
            if (string.IsNullOrEmpty(ExpirationDate))
            {
                inputRadioButtonXPath = "Xpath;//*[contains(text(),'" + tempHoldType + "')]/ancestor::tr/descendant::td[text()='" + Amount + "']/ancestor::tr/descendant::td[contains(text(),'" + ExpirationDate + "')]/ancestor::tr[1]/descendant::td[1]/input[@type='radio']";
            }
            else
            {
                inputRadioButtonXPath = "Xpath;//*[contains(text(),'" + tempHoldType + "')]/ancestor::tr/descendant::td[text()='" + Amount + "']/ancestor::tr[1]/descendant::td[1]/input[@type='radio']";
            }
            if (string.IsNullOrEmpty(ExpirationDate))
            {
                HoldTypelinkobj = "Xpath;//*[contains(text(),'" + tempHoldType + "')]/ancestor::tr/descendant::td[text()='" + Amount + "']/ancestor::tr/descendant::td[contains(text(),'" + ExpirationDate + "')]/ancestor::tr[1]/descendant::a";
            }
            else
            {
                HoldTypelinkobj = "Xpath;//*[contains(text(),'" + tempHoldType + "')]/ancestor::tr/descendant::td[text()='" + Amount + "']/ancestor::tr[1]/descendant::a";
            }
            string linkHoldDetailDialogCloseRunTime = "XPath;//*[contains(text(),'" + AccountNumber + "')]/ancestor::div/descendant::*[text()='Hold Detail']/following-sibling::a";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(inputRadioButtonXPath))
            {
                appHandle.ClickObjectViaJavaScript(inputRadioButtonXPath);
                appHandle.ClickObjectViaJavaScript(HoldTypelinkobj);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkHoldDetailDialogCloseRunTime);
                if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableHoldDetailDialog, LabelNameLabelValuePipeDelimited))
                {
                    Result = true;
                }

            }
            return Result;
        }
        public virtual void CloseHoldDetailDialog(string AccountNumber)
        {
            string linkHoldDetailDialogCloseRunTime = "XPath;//*[contains(text(),'" + AccountNumber + "')]/ancestor::div/descendant::*[text()='Hold Detail']/following-sibling::a";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkHoldDetailDialogCloseRunTime))
            {
                appHandle.ClickObjectViaJavaScript(linkHoldDetailDialogCloseRunTime);
            }
        }



        public virtual string GetAmountOfBalanceHeld(string AccountNumber, string HoldType, string AmountinHoldsTable, string Label = "")
        {
            string AmountofBalanceHeld = "";
            string Hold = HoldType.Split('-')[1].Trim();
            string Amount = AmountinHoldsTable.Split(' ')[0].Trim();
            string inputRadioButtonXPath = "Xpath;//*[contains(text(),'" + Hold + "')]/ancestor::tr/descendant::td[contains(text(),'" + Amount.TrimEnd() + "')]/ancestor::tr[1]/descendant::td[1]/input[@type='radio']";
            this.SelectAccountFromDropdown(AccountNumber);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(inputRadioButtonXPath))
            {
                appHandle.ClickObjectViaJavaScript(inputRadioButtonXPath);
            }
            this.ClickOnEditButton();
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                if (!string.IsNullOrEmpty(Label))
                {
                    string xpath = "Xpath;//*[@class='fieldLabel'][contains(.,'" + Label + "')]/following-sibling::td";
                    AmountofBalanceHeld = appHandle.GetLabelText(xpath);
                }
                else
                {
                    AmountofBalanceHeld = appHandle.GetLabelText(lblAmountOfBalanceHeld);
                }
            }
            return AmountofBalanceHeld;
        }


        public virtual bool CompareReferencealanceAmountWithTotalHold(string TotalHoldAmount)
        {
            bool flag = false;
            string AvailableBalance = appHandle.GetLabelText(lblAvailableBalance);
            if (Convert.ToDouble(TotalHoldAmount.Split(' ')[0].Trim()) == Convert.ToDouble(AvailableBalance))
            {
                flag = true;
            }
            return flag;
        }
        public virtual void EnterPHLDDetails(string HoldCode, string FixedAmt = "", string holdPercentage = "", string RefAcc = "", string BalanceType = "", string CurrencyCode = "", string ExpirationDate = "")
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldType, Data.Get("PHLD - Permanent Hold"));
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownHoldCode);
            appHandle.Set_field_value(txtPermanentHoldEndDate, ExpirationDate);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldCode, HoldCode);
            if (!string.IsNullOrEmpty(CurrencyCode))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropddownCurrencyCodePHLD, CurrencyCode);
            }
            appHandle.Set_field_value(txtHoldComment, "Test");
            if (!string.IsNullOrEmpty(FixedAmt))
            {
                appHandle.Set_field_value(txtPermanentHoldFixedAmount, FixedAmt);
            }
            else
            {
                appHandle.Set_field_value(txtPermanentHoldFixedAmount, string.Empty);
            }
            if (!string.IsNullOrEmpty(holdPercentage))
            {
                appHandle.Set_field_value(txtHoldPercentage, holdPercentage);
            }
            else
            {
                appHandle.Set_field_value(txtHoldPercentage, string.Empty);
            }
            if (!string.IsNullOrEmpty(RefAcc))
            {
                appHandle.Set_field_value(txtPercentageOfAccountBalanceAccount, RefAcc);
            }
            else
            {
                appHandle.Set_field_value(txtPercentageOfAccountBalanceAccount, string.Empty);
            }
            if (!string.IsNullOrEmpty(BalanceType))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBalanceType, BalanceType);
            }
            else
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBalanceType, string.Empty);
            }
        }
        public virtual bool VerifySpecifiedCurrencyCodeAvailableInPermanentHoldCurrencyCodeDropdown(string CurrencyCodesPipeDelimited)
        {
            bool Result = true;
            string textDrpdownText = "";
            int matchCount = 0;
            CurrencyCodesPipeDelimited = CurrencyCodesPipeDelimited + "|";
            string[] arr = CurrencyCodesPipeDelimited.Split('|');
            textDrpdownText = appHandle.GetObjectText(dropddownCurrencyCodePHLD + "/parent::*[1]");
            textDrpdownText = string.Join("|", textDrpdownText.Split(new string[] { "\r\n      " }, StringSplitOptions.None));

            for (int a = 0; a < arr.Length - 1; a++)
            {
                if (textDrpdownText.Contains(arr[a]))
                {
                    matchCount++;
                }
                if (matchCount == arr.Length - 1)
                {
                    Result = true;
                    break;
                }
            }


            return Result;
        }
        public virtual string CalculateTotalHoldAmountWhileAddingHold(string FixedAmount, string PercentageOfAccountBalanceHoldPercentage, string PercentageOfAccountBalanceAccountNo, string PercentageOfAccountBalanceBalanceType)
        {
            string TotalHoldAmount = "";
            string temp = "";
            double result = 0;

            appHandle.Set_field_value(txtHoldPercentage, Data.Get("GLOBAL_VALUE_100"));
            appHandle.Set_field_value(txtPercentageOfAccountBalanceAccount, PercentageOfAccountBalanceAccountNo);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBalanceType, PercentageOfAccountBalanceBalanceType);
            do
            {
                temp = appHandle.GetObjectText(lblAmountOfBalanceHeld);

            }
            while (temp.Equals(string.Empty));
            double amt = Convert.ToDouble(temp) * ((Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_1")) - Convert.ToDouble(Convert.ToDouble(PercentageOfAccountBalanceHoldPercentage) / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")))));
            if (amt == 0)
            {
                result = Convert.ToDouble(FixedAmount) + Convert.ToDouble(temp);
            }
            else
            {
                amt = Convert.ToDouble(temp) - amt;
                result = Convert.ToDouble(FixedAmount) + amt;
            }
            TotalHoldAmount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(result.ToString());
            return TotalHoldAmount;
        }
        public virtual bool VerifyAmountOfBalanceHeldForPHLDHold(string AccountNumber, string AmountToBeSelectedInHoldsTable, string strExpectedAmtOfBalHeld)
        {
            bool res = false;
            string inputRadioButtonXPath = "";
            string tempHoldType = Data.Get("Permanent Hold");
            this.SelectAccountFromDropdown(AccountNumber);
            if (AmountToBeSelectedInHoldsTable.Any(char.IsLetter)) { AmountToBeSelectedInHoldsTable = AmountToBeSelectedInHoldsTable.Split(' ')[0].Trim(); }
            else
            {
                AmountToBeSelectedInHoldsTable = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(AmountToBeSelectedInHoldsTable);
            }

            inputRadioButtonXPath = "Xpath;//*[contains(text(),'" + tempHoldType + "')]/ancestor::tr/descendant::td[contains(text(),'" + AmountToBeSelectedInHoldsTable + "')]/ancestor::tr[1]/descendant::td[1]/input[@type='radio']";

            this.SelectAccountFromDropdown(AccountNumber);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(inputRadioButtonXPath))
            {
                appHandle.ClickObjectViaJavaScript(inputRadioButtonXPath);
            }
            this.ClickOnEditButton();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldType, Data.Get("PHLD - Permanent Hold"));
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownHoldCode);
            if (Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(appHandle.GetObjectText(lblAmountOfBalanceHeld)).Contains(Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(strExpectedAmtOfBalHeld)))
            {
                res = true;
            }
            return res;
        }
        public virtual string GetAmountOfBalanceHeldForPHLDHold(string AccountNumber, string AmountToBeSelectedInHoldsTable)
        {
            string res = "";
            string inputRadioButtonXPath = "";
            string tempHoldType = Data.Get("Permanent Hold");
            this.SelectAccountFromDropdown(AccountNumber);
            if (AmountToBeSelectedInHoldsTable.Any(char.IsLetter)) { AmountToBeSelectedInHoldsTable = AmountToBeSelectedInHoldsTable.Split(' ')[0].Trim(); }
            else
            {
                AmountToBeSelectedInHoldsTable = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(AmountToBeSelectedInHoldsTable);
            }

            inputRadioButtonXPath = "Xpath;//*[contains(text(),'" + tempHoldType + "')]/ancestor::tr/descendant::td[contains(text(),'" + AmountToBeSelectedInHoldsTable + "')]/ancestor::tr[1]/descendant::td[1]/input[@type='radio']";


            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(inputRadioButtonXPath))
            {
                appHandle.ClickObjectViaJavaScript(inputRadioButtonXPath);
            }
            this.ClickOnEditButton();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownHoldCode);
            res = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(appHandle.GetObjectText(lblAmountOfBalanceHeld));
            return res;
        }
        public virtual void ClickOnCancelButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCancel))
            {
                appHandle.ClickObjectViaJavaScript(buttonCancel);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit);
            }
        }
        public virtual bool VerifySpecifiedHoldNotPresentInHoldsTable(string AccountNumber, string HoldType, string Amount, string ExpirationDate = "")
        {
            bool result = false;
            string tempHoldType = "";
            this.SelectAccountFromDropdown(AccountNumber);
            if (Amount.Any(char.IsLetter)) { Amount = Amount.Split(' ')[0].Trim(); }
            else
            {
                Amount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Amount);
            }
            if (HoldType.Contains("-"))
            {
                tempHoldType = HoldType.Split('-')[1].Trim();
            }
            else
            {
                tempHoldType = HoldType;
            }
            string tableText = appHandle.GetObjectText(tableHolds);
            string[] arr = tableText.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            string temp = string.Join("#", arr);

            if (!string.IsNullOrEmpty(ExpirationDate))
            {
                if (temp.Contains(Amount)
                && temp.Contains(tempHoldType)
                && temp.Contains(ExpirationDate))
                {
                    for (int a = 0; a < arr.Length; a++)
                    {
                        if (arr[a].Contains(Amount)
                        && arr[a].Contains(tempHoldType)
                        && temp.Contains(ExpirationDate))
                        {
                            continue;
                        }
                        else { result = true; break; }
                    }
                }
                else { result = true; }
            }

            else
            {
                if (temp.Contains(Amount)
                    && temp.Contains(tempHoldType))
                {
                    for (int a = 0; a < arr.Length; a++)
                    {
                        if (arr[a].Contains(Amount)
                        && arr[a].Contains(tempHoldType))
                        {
                            continue;
                        }
                        else { result = true; break; }
                    }
                }
                else { result = true; }
            }
            return result;
        }
        public virtual bool VerifyDefaultHoldStartDateAsSystemDate()
        {
            bool result = false;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownHoldType);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldType, (string)Data.Get(Data.Get("PHLD - Permanent Hold")));
            string date = appHandle.GetSpecifiedObjectProperty(txtPermanentHoldStartDate, "value");
            if (date.Trim().Equals(ApplicationDate))
            {
                result = true;
            }
            return result;
        }
        public virtual void DeleteHoldForSpecifiedAccountnumber(string AccountNumber, string HoldType, string AmountToBeSelectedInHoldsTable = "", string ExpirationDate = "")
        {
            string HoldDeleteMSG = "Are you sure you want to delete this hold?";
            string inputRadioButtonXPath = "";
            string tempHoldType = "";

            this.SelectAccountFromDropdown(AccountNumber);
            if (AmountToBeSelectedInHoldsTable.Any(char.IsLetter)) { AmountToBeSelectedInHoldsTable = AmountToBeSelectedInHoldsTable.Split(' ')[0].Trim(); }
            else
            {
                AmountToBeSelectedInHoldsTable = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(AmountToBeSelectedInHoldsTable);
            }
            if (HoldType.Contains("-"))
            {
                tempHoldType = HoldType.Split('-')[1].Trim();
            }
            inputRadioButtonXPath = "Xpath;//*[contains(text(),'" + tempHoldType + "')]/ancestor::tr/descendant::td[contains(text(),'" + AmountToBeSelectedInHoldsTable + "')]/ancestor::tr[1]/descendant::td[1]/input[@type='radio']";

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(inputRadioButtonXPath))
            {
                appHandle.ClickObjectViaJavaScript(inputRadioButtonXPath);
            }
            Report.Info("Specific hold has been selected.", "holdentry", "True", appHandle);
            appHandle.ClickObjectViaJavaScript(buttonDelete);
            appHandle.SwitchTo(SwitchInto.ALERT);

            appHandle.PerformActionOnAlert(PopUpAction.Verify, HoldDeleteMSG);

            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);


        }
        public virtual void DeleteHoldTypeFromTable(string date)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);  
                appHandle.SelectRadioButtonInTable(HoldTable,date);
                appHandle.ClickObjectViaJavaScript(DeleteButton);
                
        
            }
            catch (Exception e)
            {
                Report.Fail(e.Message, "DeletePendingTransfer Exception", appHandle);   
            }
        }
         public virtual void ClickOnDeleteButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonDelete))
            {
                appHandle.ClickObjectViaJavaScript(buttonDelete);
            }
        }
        
    }
}
