using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DepositWithholdingPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpWithholdingUSResidencyStatus="Xpath;//select[@name='DEP_USRESTAT']";
        public static string ckbSubjecttoFATCAWithholding="Xpath;//input[@name='DEP_ISFATCAWTH']";
        public static string drpWithholding1042SReportingChapter3Status="Xpath;//select[@name='DEP_CHAPTER3STATUS']";
        public static string ckbWithholding="Xpath;//input[@name='DEP_BWF']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        public static string checkboxWithholding="XPath;//input[@name='DEP_BWF']";
        public static string dropdown1042SReportingChapter3Status="XPath;//select[@name='DEP_CHAPTER3STATUS']";
        public static string dropdowncalculationmethod = "Xpath;//select[@name='DEP_INTWCALC']";
        public static string drpFATCAWaiverforReporting = "Xpath;//select[@name='DEP_WAIVERFORFATCARPT']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string drp1042ReportingChapter4status="Xpath;//*[@name='DEP_CHAPTER4STATUS']";
        private static string ckbAccrWitholding="Xpath;//input[@name='DEP_AWTP']";
        public static string drpChapter3ExemptionReason ="Xpath;//select[@name ='DEP_WHEXR']";
        public static string drpChapter3Status ="Xpath;//select[@name ='DEP_CHAPTER3STATUS']";
        public static string drpWithholdingReason="Xpath;//select[@name='DEP_INTWR']";
        public static string dropdownWithholdingReason="XPath;//select[@name='DEP_INTWR']";
        public static string dropdownWithholdingcalmethod="XPath;//select[@name='DEP_INTWCALC']";
        private static string drpAccrWithholdingTaxIndex="Xpath;//*[@name='DEP_AWTI']";
        private static string txtAccrWithholdingTaxRate ="Xpath;//[@name='DEP_AWTR']"; 
        private static string drpW8BENEFATCAStatus="Xpath;//*[@name='DEP_W8BENEFATCASTATUS']";
        private static string drpFATCAExemptionCode="Xpath;//*[@name='DEP_FATCAEXEMPTCD']";
        private static string drp1042sReportingStatus = "Xpath;//*[@name='DEP_CHAPTER3STATUS']";
        public virtual bool CheckSubjToWithholding(bool SubjToWithholdingONorOFF)
        {    
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbWithholding))
            {
                if (SubjToWithholdingONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(ckbWithholding)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbWithholding);
                        if (appHandle.CheckCheckBoxChecked(ckbWithholding))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(ckbWithholding) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbWithholding);
                        if (appHandle.CheckCheckBoxChecked(ckbWithholding) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }    
        public virtual void EnterInterestPageOptions(string CalculationMethod,string WitholdingReason="", string USResidencystatus="",string Chapter3ExemptionReason = "", string Chapter3Status= "")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdowncalculationmethod))
            {
                if(!string.IsNullOrEmpty(WitholdingReason))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpWithholdingReason,WitholdingReason);
                }
                if(!string.IsNullOrEmpty(CalculationMethod))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdowncalculationmethod,CalculationMethod);
                }                
                if(!string.IsNullOrEmpty(USResidencystatus))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpWithholdingUSResidencyStatus,USResidencystatus);
                }
                if(!string.IsNullOrEmpty(Chapter3ExemptionReason))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpChapter3ExemptionReason,Chapter3ExemptionReason);
                }
                if(!string.IsNullOrEmpty(Chapter3Status))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpChapter3Status,Chapter3Status);
                }        
            }
        }   
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);

            }
        }
         public virtual bool VerifyMessageDepositWitholdingPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual bool CheckAccruedWitholdingTax(bool AccrWitholdingONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbAccrWitholding))
            {
                if (AccrWitholdingONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(ckbAccrWitholding)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbAccrWitholding);
                        if (appHandle.CheckCheckBoxChecked(ckbAccrWitholding))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(ckbAccrWitholding) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbAccrWitholding);
                        if (appHandle.CheckCheckBoxChecked(ckbAccrWitholding) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }
        public virtual void UpdateWithholdindDetails(string Reason,string Chapter4Status)
        {
            appHandle.WaitUntilElementExists(drpWithholdingReason);
            appHandle.SelectDropdownSpecifiedValue(drpWithholdingReason,Reason);
            appHandle.SelectDropdownSpecifiedValue(drp1042ReportingChapter4status,Chapter4Status);
        }
        public virtual bool VerifyFATCAWithholdingDetailsyFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "W-8BEN-E FATCA Status":
                        if (appHandle.CheckValueInDropdown(drpW8BENEFATCAStatus,expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "Exemption Code":
                        if (appHandle.CheckValueInDropdown(drpFATCAExemptionCode, expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }
            
            return result;
            }
        
        public virtual void UpdateAccrWithholdingTaxIndexandRate(string WithholdingTaxIndex,string TaxRate)
        {
            appHandle.WaitUntilElementExists(drpAccrWithholdingTaxIndex);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpAccrWithholdingTaxIndex,WithholdingTaxIndex);
            appHandle.Set_field_value(txtAccrWithholdingTaxRate,TaxRate);
        }
        public virtual bool ToCheckTheStatusofWithholdingCheckBox()
        {
            bool result = false;
            appHandle.WaitUntilElementExists(ckbWithholding);
            if(appHandle.CheckCheckBoxUnchecked(ckbWithholding))
            {
                result = true;
            }
            return result;
        }
        public virtual string GetValueForLabelForFATCAWithholding(string Label)
        {
            string LabelValueXpath = "Xpath;//table[@class='contentTable']/descendant::h2[contains(text(),'FATCA Withholding')]/following::td[contains(text(),'"+ Label +"')]/following::td";
            string LabelValue = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(LabelValueXpath))
            {
                LabelValue = appHandle.Get_Label_Text(LabelValueXpath);
            }

            return LabelValue;
        }
        
        public virtual bool selectvaluefromWithholding1042chapter3status(string value,string withholdreason="",string withholdcalmethod="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdown1042SReportingChapter3Status);
            if(!appHandle.CheckCheckBoxChecked(checkboxWithholding))
            {
                appHandle.ClickObjectViaJavaScript(checkboxWithholding);
            }
            appHandle.SelectDropdownSpecifiedValue(dropdown1042SReportingChapter3Status,value);
            
            if(!string.IsNullOrEmpty(withholdreason))
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownWithholdingReason,withholdreason);
            }
            if(!string.IsNullOrEmpty(withholdcalmethod))
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownWithholdingcalmethod,withholdcalmethod);
            }
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }
        
    }
}