using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;
using System.Threading;



namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanInterestTab
    {
        WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string Balances_Link = "Xpath;//a[contains(text(),'Balances')]";
        public static string Rate_Determination_Link = "Xpath;//a[contains(text(),'Rate Determination')]";
        public static string Calculation_Options_Link = "Xpath;//a[contains(text(),'Calculation Options')]";
        public static string Capitalization_Link = "Xpath;//a[contains(text(),'Capitalization')]";
        public static string Rate_Buydowns_Link = "Xpath;//a[contains(text(),'Rate Buydowns')]";
        public static string Cancel_Button = "Xpath;//input[@value='Cancel']";
        private static string Interestlink = "Xpath;//table[@class='tab']//td[text()='Interest']";

        private static string tablecontent = "Xpath;//*[@class='contentTable']/descendant::tbody[1]";
        private static string DrpDownInterestCalculationOption = "XPath;//*[@name='LN_PPICO']";

        public virtual bool VerifyLoanBalanceValuesBylabelNameLabelValue(string sLabelNamePipeDelimitedsLabelValue)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tablecontent))
            {
                if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tablecontent, sLabelNamePipeDelimitedsLabelValue))
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual bool VerifyDetailsInInterestCalcualtionOption(string CalculationOption)
        {
            bool result = false;
            applicationHandle.WaitUntilElementExists(DrpDownInterestCalculationOption);
            if (applicationHandle.CheckValueInDropdown(DrpDownInterestCalculationOption, CalculationOption))
            {
                result = true;
            }
            return result;


        }
        


       
        public virtual void select_balances_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Balances_Link);
        }

        public virtual void select_rate_determination_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Rate_Determination_Link);
        }

        public virtual void select_calculation_options_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Calculation_Options_Link);
        }

        public virtual void select_capitalization_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Capitalization_Link);
        }

        public virtual void select_rate_buydowns_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Rate_Buydowns_Link);
        }

        public virtual void SelectInterestTab()
        {
            applicationHandle.ClickObjectViaJavaScript(Interestlink);
        }
        public virtual string GetValueForLabel(string Label)
        {
            string LabelValueXpath = "Xpath;//*[table[@class='contentTable']]//*[contains(text(),'" + Label + "')]/following-sibling::td";
            string LabelValue = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(LabelValueXpath))
            {
                LabelValue = applicationHandle.GetLabelText(LabelValueXpath);
            }

            return LabelValue;
        }


    }
}