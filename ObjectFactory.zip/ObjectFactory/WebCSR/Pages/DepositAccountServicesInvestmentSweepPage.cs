using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class DepositAccountServicesInvestmentSweepPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string dropdownAccount = "XPath;//*[contains(text(),'Account')]/following-sibling::*/select";
        private static string buttonAdd = "XPath;//*[@value='Add →']";
        private static string buttonSubmit = "Xpath;//*[@value='Submit']";
        private static string radiobuttonAvailableAccounts = "Xpath;//input[@name='eligibleAccountSelected']";
        private static string radiobuttonSelectedAccounts = "Xpath;//input[@name='selectedAccountSelected']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        public virtual bool SelectAccountNumberFromAccountDropdown(string AccountNumber)
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccount))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccount, AccountNumber);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
                {
                    result = true;
                }
            }
            return result;
        }
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }

        public virtual bool MoveAccountFromSweepEligibleAccountsTableToSweepAccountsTable(string AccountNumber, string SweepPercentage = "")
        {
            bool Result = false;
            string radiobuttonAvailableAccounts = "XPath;//table[@id='sweep-eligible-accounts-list']/descendant::*[contains(text(),'" + AccountNumber + "')]/ancestor::tr/descendant::td/input[@type='radio']";
            string radiobuttonSelectedAccounts = "XPath;//table[@id='sweep-accounts-list']/descendant::*[contains(text(),'" + AccountNumber + "')]/ancestor::tr/descendant::td/input[@type='radio']";
            string txtSweepPercentage = "XPath;//table[@id='sweep-accounts-list']/descendant::*[contains(text(),'" + AccountNumber + "')]/ancestor::tr/descendant::td/input[contains(@name,'percentage')]";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonAvailableAccounts))
            {
                appHandle.ClickObjectViaJavaScript(radiobuttonAvailableAccounts);
                this.ClickOnAddButton();
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonSelectedAccounts))
                {
                    appHandle.ClickObjectViaJavaScript(radiobuttonSelectedAccounts);
                    if (string.IsNullOrEmpty(SweepPercentage)) { }
                    else
                    {
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSweepPercentage))
                        {
                            appHandle.Set_field_value(txtSweepPercentage, SweepPercentage);
                        }
                    }
                    Result = true;
                }
            }
            return Result;
        }
public virtual bool VerifySuccessfulUpdateMessageInInvestmentSweepPage()
        {
            bool Result=false;
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if(appHandle.GetObjectText(MSGOBJ).Contains(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Result=true;
                }
            }
            return Result;
        }

    }
}