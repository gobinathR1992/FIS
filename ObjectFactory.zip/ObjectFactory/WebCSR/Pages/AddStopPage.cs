using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AddStopPage
    {
         WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
         public static string StopInformationExpirationDate_Field= "Xpath;//input[@name='STOP2_EXP']";
         public static string StopInformationComments_Field="Xpath;//input[@name='STOP2_CMT']";
         public static string StopTypeCheckNumber_Field="Xpath;//input[@name='STOP3_CHKNUM']";
         public static string StopTypeCheckAmount_Field="Xpath;//input[@name='STOP3_AMT']";
         public static string StopTypeCheckPayee_Field="Xapth;//input[@name='STOP3_PAYEE']";
         public static string StopTypeCheckIssueDate_Field="Xpath;//input[@name='STOP3_ISS']";
         public static string StopTypeNewCheckIssued_Field="Xpath;//input[@name='STOP3_NCKI']";
         public static string StopTypeBeginningCheckNumber_Field="Xpath;//input[@name='STOP3_CHKLO']";
         public static string StopTypeEndingCheckNumber_Field="Xpath;//input[@name='STOP3_CHKHI']";
         public static string AmountStopCheckAmount_Field="Xpath;//input[@name='STOP4_AMT']";
         public static string AmountStopCheckIssueDate_Field="Xpath;//input[@name='STOP4_ISS']";
         public static string AmountStopNewCheckIssued_Field="Xpath;//input[@name='STOP4_NCKI']";
         public static string AmountStopPayeeName_Field="Xpath;//input[@name='STOP4_PAYEE']";
         public static string ACHStopACHAmount_Field="Xpath;//input[@name='STOP5_AMT']";
         public static string ACHStopCompanyNumber_Field="Xpath;//input[@name='STOP5_ACH']";
         public static string StopInformationAccountNumber_Dropdown="Xpath;//select[@name='STOP5_CID']";
         public static string StopInformationStopAction_Dropdown="Xpath;//select[@name='STOP5_ACT']";
         public static string StopInformationReasonforStop_Dropdown="Xpath;//select[@name='STOP5_STPWHY']";
         public static string StopInformationFeeAssessmentAccount_Dropdown="Xpath;//select[@name='STOP5_FEECID']";
         public static string ACHStopDebitCreditIndicator_Dropdown="Xpath;//select[@name='STOP5_DC']";
         public static string StopInformationConfirmationReceived_Checkbox="Xpath;//input[@id='STOP5_ID']";
         public static string StopType_Radiobutton="Xpath;//td[@class='data']//input[@name='ZSTOPALL_STPTYP']";
         

    }

}
