using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class RenewalProcessingPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtRenewalAnalysisandProcessingMaturityAnalysisOffsetDays = "Xpath;//input[@name='LN_MAODYS']";
        public static string txtRenewalAnalysisandProcessingOptionsProductionOffsetDays = "Xpath;//input[@name='LN_RNWOOD']";
        public static string txtRenewalAnalysisandProcessingNextAnalysisDate = "Xpath;//input[@name='LN_MADT']";
        public static string tblRenewalProcessing = "Xpath;//table[@class='contentTable']";
        public static string lblNextProductiondate = "Xpath;//td[contains(text(),'Next Production Date:')]";
        private static string drpDownRenewalRecommendationCode = "Xpath;//select[@name='LN_RRC']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";


        public virtual void UpdateRenewalAnalysis(string RecommendationCode)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpDownRenewalRecommendationCode))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpDownRenewalRecommendationCode, RecommendationCode);

            }

        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }

        public virtual bool VerifySuccessMessage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
    }
}