using GTS_OSAF.CoreLibs;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class GooglePage
    {
        WebApplication webApp;

        private static string searchField = "id;lst-ib";
        private static string googleSearchButton= "Xpath;//input[@value='Google Search'][@type='submit']";
        public virtual void GoogleSearchField (string strSearchName)
        {
            webApp = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            webApp.Set_field_value(searchField,strSearchName);
        }

         public virtual string GetTextFieldValue ()
        {
            webApp = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string text = webApp.GetObjectText(searchField);
            return text;
        }

        public virtual void GoogleSearchButton()
        {
            webApp = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            webApp.SelectButton(googleSearchButton);
        }
    }
}