using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class LoanAccountServicesPaymentChangePage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string rdbPaymentFrequencyChange = "Xpath;//input[@name='paymentChangeOption'])[2]";       
		private static string buttonSubmit = "XPath;//*[@value='Submit']";
		private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
		private static string txtInterimInterestCollectionMethod = "Xpath;//select[@name='LN_ODIO']";
		private static string drpAccount = "Xpath;//input[@name='LN_NAI']";    
		
		public virtual void EnterPaymentChangePageOptions(string Account = " ", string Paymntfqcng=" ", string  InmIntCollMthd = " " )
        {
		 
		try
		  {
		   if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpAccount))
            {
                if(!string.IsNullOrEmpty(Account))
                {
                appHandle.SelectDropdownSpecifiedValue(drpAccount,Account);
                }
                                       
            }
			
		    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(rdbPaymentFrequencyChange))
            {
                if(!string.IsNullOrEmpty(Paymntfqcng))
                {
                appHandle.Set_radiobutton(rdbPaymentFrequencyChange);
                }	
		    }
	
		    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtInterimInterestCollectionMethod))
            {
                if(!string.IsNullOrEmpty(InmIntCollMthd))
                {
                appHandle.SelectDropdownSpecifiedValue(txtInterimInterestCollectionMethod, "");
                }
                                       
            }
		
		 }
		  catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }	
			
        }
		
		 public virtual void SelectSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            
        }
	   
	    public virtual bool VerifyMessagePaymentChangePage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
    }
}

