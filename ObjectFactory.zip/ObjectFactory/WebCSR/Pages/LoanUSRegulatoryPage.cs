using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanUSRegulatoryPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string RequesttoCancel_Field="Xapth;//input[@name='LN_BRPMICDT']";
        public static string CancellationDate_Field="Xpath;//input[@name='LN_ACTPMICDT']";
        public static string CancellationRequestDeclined_Field="Xpath;//input[@name='LN_PMICRDD']";
        public static string AutomaticTermination_Field="Xpath;//input[@name='LN_PMIATDT']";
        public static string FinalTermination_Field="Xpath;//input[@name='LN_PMIFTDT']";
        public static string ReturnedUnearnedPremium_Field="Xpath;//input[@name='LN_RUPMIP']";
        public static string BorrowerPaidPMIInterestRate_Field="Xpath;//input[@name='LN_BPMIRN']";
        public static string RegulationEDisputeAmount_Field="Xpath;//input[@name='ACN_REGEAMT']";
        public static string FHAVACaseNumber_Field="Xpath;//input[@name='LN_CASE']";
        public static string EarlyInterventionNoticeDate_Field="Xpath;//input[@name='LN_EARLYINTERVENNOTDT']";
        public static string CensusTract_Field="Xpath;//input[@name='LN_CEN']";
        public static string CountyCode_Field="Xpath;//input[@name='LN_CRACNTCD']";
        public static string StateCode_Field="Xpath;//input[@name='LN_CRASTCD']";
        public static string AnnualSales_Field="Xpath;//input[@name='LN_ANSALE']";
        public static string HighRiskLoan_Checkbox="Xpath;//input[@name='LN_HRLA']";
        public static string LenderPaidPMILoan_Checkbox="Xpath;//input[@name='LN_LPMI']";
        public static string AddLateChargeToInterestPaid_Checkbox="Xpath;//input[@name='LN_IPLCF']";
        public static string CMRMortgageSecurity_Checkbox="Xpath;//input[@name='LN_SECMTG']";
        public static string AffiliateLoan_Checkbox="Xpath;//input[@name='LN_AFFLN']";
        public static string USRegulatoryAccount_Dropdown="Xpath;//table[@class='contentTable']//table//tbody//tr//td//select[@name='accountNumber']";
        public static string CancellationRequestDeclineReason_Dropdown="Xpath;//select[@name='LN_PMICRDR']";
        public static string BorrowerPaidPMIInterestIndex_Dropdown="Xpath;//select[@name='LN_BPMIND']";
        public static string IRS1098ReportingExemption_Dropdown="Xpath;//select[@name='LN_IRSEXM']";
        public static string LoanFDICOTSPrimaryReportingCode_Dropdown="Xpath;//select[@name='LN_LFPC']";
        public static string LoanFDICOTSSecondaryReportingCode_Dropdown="Xpath;//select[@name='LN_LFSC']";
        public static string LoanFDICOTSResidenceClassification_Dropdown="Xpath;//select[@name='LN_RESCLS']";
        public static string LoanFeature_Dropdown="Xpath;//select[@name='LN_FCLF']";
        public static string LoanPurpose_Dropdown="Xpath;//select[@name='LN_FCLP']";
        public static string PropertyType_Dropdown="Xpath;//select[@name='LN_FCPT']";
        public static string ResidualAssetClassification_Dropdown="Xpath;//select[@name='LN_RAC']";
        public static string ResidualAssetClassNonaccrual_Dropdown="Xpath;//select[@name='LN_RACNA']";
        public static string AssetBaseDeterminationMethod_Dropdown="Xpath;//select[@name='LN_ABDM']";
        public static string MSACode_Dropdown="Xpath;//select[@name='LN_MSACD']";


    }

}