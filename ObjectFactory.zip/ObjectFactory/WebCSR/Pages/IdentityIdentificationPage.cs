using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class IdentityIdentificationPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string DriversLicenseNumber_Field= "Xpath;//input[@name='CIF_DLNUM']";
        public static string DriversLicenseIssueDate_Field="Xpath;//input[@name='CIF_DLISDT']";
        public static string DriversLicenseExpirationDate_Field="Xpath;//input[@name='CIF_DLEXPDT']";
        public static string PassportNumber_Field="Xpath;//input[@name='CIF_PASNUM']";
        public static string PassportIssueDate_Field="Xpath;//input[@name='CIF_PISDT']";
        public static string PassportExpirationDate_Field="Xpath;//input[@name='CIF_PED']";
        public static string OtherNumber_Field="Xpath;//input[@name='CIF_OIN']";
        public static string OtherIssueDate_Field="Xpath;//input[@name='CIF_OISDT']";
        public static string OtherExpirationDate_Field="Xpath;//input[@name='CIF_OED']";
        public static string CreditorBusinessCode_Field="Xpath;//input[@name='CIF_CRBC']";
        public static string CountrySpecificCreditorIdentifier_Field="Xpath;//input[@name='CIF_CRIDCNTRY']";
        public static string DriversLicenseStateDropdown="Xpath;//select[@name='CIF_DLSTATE']";
        public static string PassportCountryofIssue_Dropdown="Xpath;//select[@name='CIF_PCI']";
        public static string OtherType_Dropdown="Xpath;//select[@name='CIF_OIT']";
        public static string OtherIssuer_Dropdown="Xpath;//select[@name='CIF_ISSR']";
        public static string Identification_Radiobutton="Xpath;//body[@class='main']/table[@id='mainTable']/tbody/tr/td[@id='content']/table/tbody/tr/td/table/tbody/tr/td/form[@name='customerIdentificationForm']/table[@class='contentTable']/tbody/tr/td/table/tbody/tr[1]/td[1]/input[1]";

    }
}
