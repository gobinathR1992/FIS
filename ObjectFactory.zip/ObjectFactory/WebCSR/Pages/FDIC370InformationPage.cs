using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class FDIC370InformationPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpFDIC370Account = "Xpath;//select[@name='DEPFDIC370_CID']";
        public static string drpOverrideORCCode = "Xpath;//select[@name='DEPFDIC370_ORCOVERRIDE']";
        public static string drpPendingReason = "Xpath;//select[@name='DEPFDIC370_PENDINGREASON']";
        public static string ckbPassThroughAccount = "Xpath;//input[@name='DEPFDIC370_ISPASSTHROUGHACCOUNT']";
        public static string ckbSubAccountsWithTransactionalFeatures = "Xpath;//input[@name='DEPFDIC370_HASSUBACCOUNT']";
        public static string tableInsuranceSummary="Xpath;//*[@id='depositInsuranceSummaryList_wrapper']";
        public static string tableBeneficiarySummary="Xpath;//*[@id='fdicBeneficiarySummaryList_wrapper']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        public static string buttonSubmit="XPath;//input[@name='submit']";

     

        /// <summary>
        /// Method for Verify the status of Unchecked checkbox.
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRPageFactory.VeifytheStatusofUncheckedCheckbox();
        /// </example>
        public virtual bool VeifytheStatusofUncheckedCheckbox(string Checkbox1)
        {
            bool bcheck = false;
            try
            {
                {
                    bcheck = appHandle.CheckCheckBoxUnchecked(Checkbox1);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

       /// <summary>
        /// Method for Verify the status of Checked checkbox.
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRPageFactory.VerifytheStatusofcheckedCheckbox();
        /// </example>
        public virtual bool VerifytheStatusofcheckedCheckbox(string Checkbox2)
        {
            bool bcheck = false;
            try{
            {
                bcheck = appHandle.CheckCheckBoxChecked(Checkbox2);
            }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

       /// <summary>
        /// Method for Verify the Object is exists.
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRPageFactory.VerifytheObjectExists();
        /// </example>
        public virtual bool VerifytheObjectExists(string obj1)
        {
            bool bcheck = false;
            try{
            {
                bcheck = appHandle.CheckObjectExist(obj1);
            }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }


        /// <summary>
        /// Method for Verify the values are there in dropdown.
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRPageFactory.VerifytheValuesinDropdown();
        /// </example>
        public virtual void VerifytheValuesinDropdown(string dropdownpath, string[] ORCValues)
        {
            appHandle.CheckDropdownContents(dropdownpath, ORCValues);
        }
        public virtual bool VerifyDataInInsurancesummary(string LabelNameLabelValuePipeDelimited)
        {
            return Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableInsuranceSummary,LabelNameLabelValuePipeDelimited);
          }
        public virtual bool VerifyDataInBeneficiarysummary(string LabelNameLabelValuePipeDelimited)
        {
           return Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableBeneficiarySummary,LabelNameLabelValuePipeDelimited);
        }

        public virtual void EnterFDIC370PageDetails(string ORCCode)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpOverrideORCCode,ORCCode);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }
        public virtual bool VerifyMessageInFDIC370Page(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyDataInFDIC370PendingReasonDropDown(string drpPendingReasonValue)
        {
            bool Result = false;
            if (Profile7CommonLibrary.CheckDropdownSpecifiedValueExistsTrue(drpPendingReason, drpPendingReasonValue))
            {
            
                Result = true;
            }
            else
            {
                Result = false;
            }
            return Result;
        }

    }
}
