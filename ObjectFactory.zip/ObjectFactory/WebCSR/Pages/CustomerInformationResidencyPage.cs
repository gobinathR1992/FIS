using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.Util;


namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CustomerInformationResidencyPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string lnkFATCA = "Xpath;//a[contains(text(),'FATCA')]";
        public static string drpdownReportingStatus = "Xpath;//*[@name='CIF_FATCARPTSTATUS']";
        public static string ckbSubjecttoWithholding = "Xpath;//input[@name='CIF_ISFATCAWTH']";

        public static string ckbResidencyInformationNonResidency = "Xpath;//input[@id='nonResidentFlag']";

        public static string lnkGeneral = "Xpath;//a[contains(text(),'General')]";
        public static string ckbResidencyInformationForeignCorporation = "Xpath;//input[@id='foreignCorporationFlag']";
        public static string drpResidencyInformationResidencyStatus = "Xpath;//select[@name='CIF_USRESTAT']";
        public static string drpResidencyInformationCountryofIncorporation = "Xpath;//select[@name='CIF_RESCNTRY']";
        public static string drpResidencyInformationExemptionReasonCode = "Xpa th;//select[@name='CIF_CHAPTER3EXEMPTION']";
        public static string ckbInterestWithholdingSubjecttoWithholding = "Xpath;//input[@name='CIF_BWF']";
        public static string drpInterestWithholdingCalculationMethod = "xpath;//select[@name='CIF_INTWCALC']";
        public static string ckbResidencyInformationW8Required = "Xpath;//input[@id='w8RequiredFlag']";
        public static string drpResidencyInformationW8Type = "Xpath;//select[@name='w8Formtype']";
        public static string txtResidencyInformationW8DateReceived = "Xpath;//input[@name='w8DateReceived']";
        public static string txtResidencyInformationW8ExpirationDate = "Xpath;//input[@name='w8ExpirationDate']";
        public static string drpFATCAExcemptionCode = "Xpath;//select[@name='CIF_FATCAEXEMPTCD']";
        public static string drpFATCA1042SReportingChapter4Status = "Xpath;//select[@name='CIF_CHAPTER4STATUS']";
        public static string drp1042SReportingChapter3Status = "Xpath;//select[@name='CIF_CHAPTER3STATUS']";
        public static string drpResidencyInformationCountryofCitizenship = "Xpath;//select[@name='CIF_CITZSHP']";
        public static string drpFATCAWaiverforReporting = "Xpath;//select[@name='CIF_WAIVERFORFATCARPT']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        public static string buttonSubmit = "Xpath;//*[@name='submit']";
        public static string buttonCancel = "Xpath;//*[@name='cancel']";
        // private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string dropdownNegIntPostingOption = "Xpath;//select[@name = 'DEP_NEGIPO']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string ckbResidencyInformationW9Required = "Xpath;//input[@id='w9RequiredFlag']";
        private static string ckbNonresidence = "Xpath;//input[@name = 'CIF_NR']";
        private static string ckbW8Required = "Xpath;//input[@name = 'w8Required']";
        private static string txtResidencyInformationW9DateReceived = "Xpath;//input[@name='w9DateReceived']";
        private static string dropdownWitholdingReason = "Xpath;//select[@name = 'CIF_INTWR']";
        private static string dropdownCalculationMethod = "Xpath;//select[@name = 'CIF_INTWCALC']";
        private static string dropdownW8Type = "Xpath;//select[@name = 'w8Formtype']";
        private static string txtW8Datereceived = "Xpath;//input[@name = 'w8DateReceived']";
        private static string dropdown1042SReportingChapter3Status = "Xpath;//select[@name = 'CIF_CHAPTER3STATUS']";
        private static string chkGIINAppliedFor="Xpath;//*[@name='CIFW8BEN_APPLIEDFORGIIN']";
        //Us substantial
        private static string ckbIsthisanOrganization = "Xpath;//*[@name='SUBSUSOWNER_ISORGANIZATION']";
        private static string txtOrgName = "Xpath;//*[@name='SUBSUSOWNER_NAME']";
        private static string buttonAdd = "Xpath;//*[@name='add']";
        private static string txtFirstName = "Xpath;//*[@name='SUBSUSOWNER_FIRSTNAME']";
        private static string txtTIN = "Xpath;//*[@name='SUBSUSOWNER_TIN']";
        private static string txtPoO = "Xpath;//*[@name='SUBSUSOWNER_PERCENTOWNERSHIP']";
        private static string ckbW9onFile = "Xpath;//*[@name='SUBSUSOWNER_ISW9ONFILE']";
        private static string txtLastName = "Xpath;//*[@name='SUBSUSOWNER_LASTNAME']";
        private static string txtAddressLine1 = "Xpath;//*[@name='SUBSUSOWNER_ADDRESSLINE1']";
        private static string txtCity = "Xpath;//*[@name='SUBSUSOWNER_CITY']";
        private static string drpdownCountry = "Xpath;//*[@name='SUBSUSOWNER_COUNTRY']";
        private static string drpdownState = "Xpath;//*[@name='SUBSUSOWNER_STATE']";
        private static string txtZipCode = "Xpath;//*[@name='SUBSUSOWNER_ZIPCODE']";
        private static string txtForeignTaxid = "Xpath;//*[@name='CIF_NRTAXID']";
        private static string txtGIIN = "Xpath;//*[@name='CIFW8BEN_GIIN']";
        private static string txtGIINClaimDate = "Xpath;//*[@name='CIFW8BEN_CLAIMDT']";
        private static string txtGIINCollectedDate = "Xpath;//*[@name='CIFW8BEN_COLLECTNDT']";
        private static string txtGIINVerificationDate = "Xpath;//*[@name='CIFW8BEN_VERIFICATIONDT']";

        private static string txtFATCACooments = "Xpath;//*[@name='CIFW8BEN_FATCACOM']";
        private static string dropdownW8BENEStatus = "xpath;//*[@name='CIFW8BEN_FATCASTATUS']";
        private static string tableofSubstantialUSOwner ="Xpath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";
        private static string buttonEdit="Xpath;//*[@name='edit']";
        





        public virtual void UpdateReportingStatus(string Status)
        {
            appHandle.WaitUntilElementExists(drpdownReportingStatus);
            appHandle.SelectDropdownSpecifiedValue(drpdownReportingStatus, Status);

        }
        public virtual bool ClickOnSubjectToWithholdingCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbSubjecttoWithholding))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(ckbSubjecttoWithholding)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbSubjecttoWithholding);
                        if (appHandle.CheckCheckBoxChecked(ckbSubjecttoWithholding))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(ckbSubjecttoWithholding) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbSubjecttoWithholding);
                        if (appHandle.CheckCheckBoxChecked(ckbSubjecttoWithholding) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }
        public virtual void WaiverForReporting(string Report)
        {
            appHandle.WaitUntilElementExists(drpFATCAWaiverforReporting);
            appHandle.SelectDropdownSpecifiedValue(drpFATCAWaiverforReporting, Report);

        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            
        }

        public virtual bool ValidateCustomerInfoUpdateMSG()
        {
            bool result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_CUSTOMER_INFORMATION_UPDATED")))
            {
                result = true;
            }

            return result;
        }


        public virtual bool WaitUntilCustomerInformationResidencyPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpResidencyInformationResidencyStatus))
            {
                result = true;
            }

            return result;

        }
        public virtual void SelectSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMessageAccountInformationResidencyPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }


        public virtual void EnterResidencyInformationDetails(string ResidencyStatus = " ", string CountryofResidency = "", string CountryofCitizenship = " ", bool W9RequiredONorOFF = false, string W9DateReceived = "")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpResidencyInformationResidencyStatus))
            {
                if (!string.IsNullOrEmpty(ResidencyStatus))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpResidencyInformationResidencyStatus, ResidencyStatus);
                }
                if (!string.IsNullOrEmpty(CountryofResidency))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpResidencyInformationCountryofIncorporation, CountryofResidency);

                }
                if (!string.IsNullOrEmpty(CountryofCitizenship))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpResidencyInformationCountryofCitizenship, CountryofCitizenship);
                }
                if (W9RequiredONorOFF == true)
                {
                    bool Result = false;
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbResidencyInformationW9Required))
                    {
                        if (W9RequiredONorOFF)
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbResidencyInformationW9Required)) { Result = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbResidencyInformationW9Required);
                                if (appHandle.CheckCheckBoxChecked(ckbResidencyInformationW9Required))
                                { Result = true; }

                            }
                        }
                        else
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbResidencyInformationW9Required) == false) { Result = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbResidencyInformationW9Required);
                                if (appHandle.CheckCheckBoxChecked(ckbResidencyInformationW9Required) == false) { Result = true; }
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(W9DateReceived))
                {
                    appHandle.Set_field_value(txtResidencyInformationW9DateReceived, W9DateReceived);
                }
            }

        }
        public virtual void EnterInterestWithholdingDetails(bool SubjtoWitholdingONorOFF = false, string WithholdingReason = "", string CalculationMethod = "")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpResidencyInformationResidencyStatus))
            {

                if (SubjtoWitholdingONorOFF == true)
                {
                    bool Result = false;
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbInterestWithholdingSubjecttoWithholding))
                    {
                        if (SubjtoWitholdingONorOFF)
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbInterestWithholdingSubjecttoWithholding)) { Result = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbInterestWithholdingSubjecttoWithholding);
                                if (appHandle.CheckCheckBoxChecked(ckbInterestWithholdingSubjecttoWithholding))
                                { Result = true; }

                            }
                        }
                        else
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbInterestWithholdingSubjecttoWithholding) == false) { Result = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbInterestWithholdingSubjecttoWithholding);
                                if (appHandle.CheckCheckBoxChecked(ckbInterestWithholdingSubjecttoWithholding) == false) { Result = true; }
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(WithholdingReason))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownWitholdingReason, WithholdingReason);
                }
                if (!string.IsNullOrEmpty(CalculationMethod))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownCalculationMethod, CalculationMethod);
                }
            }

        }
        public virtual void EnterNonResidenceDetails(bool NonresidentONorOFF = false, string ResidencyStatus = " ", string CountryofResidency = "", string CountryofCitizenship = " ", bool W8RequiredONorOFF = true, string w8type = "", string w8datereceived = "", string ReportingChapter3Status = " ", string CalculationMethod = "", bool SubjecttoWithholding = true,string WithholdingReason = "")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpResidencyInformationResidencyStatus))
            {

                if (NonresidentONorOFF == true)
                {
                    bool Result = false;
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbNonresidence))
                    {
                        if (NonresidentONorOFF)
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbNonresidence)) { Result = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbNonresidence);
                                if (appHandle.CheckCheckBoxChecked(ckbNonresidence))
                                { Result = true; }

                            }
                        }
                        else
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbNonresidence) == false) { Result = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbNonresidence);
                                if (appHandle.CheckCheckBoxChecked(ckbNonresidence) == false) { Result = true; }
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(ResidencyStatus))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpResidencyInformationResidencyStatus, ResidencyStatus);
                }
                if (!string.IsNullOrEmpty(CountryofResidency))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpResidencyInformationCountryofIncorporation, CountryofResidency);

                }
                if (!string.IsNullOrEmpty(CountryofCitizenship))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpResidencyInformationCountryofCitizenship, CountryofCitizenship);
                }
                if (W8RequiredONorOFF == true)
                {
                    bool Result1 = false;
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbW8Required))
                    {
                        if (W8RequiredONorOFF)
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbW8Required)) { Result1 = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbW8Required);
                                if (appHandle.CheckCheckBoxChecked(ckbW8Required))
                                { Result1 = true; }

                            }
                        }
                        else
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbW8Required) == false) { Result1 = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbW8Required);
                                if (appHandle.CheckCheckBoxChecked(ckbW8Required) == false) { Result1 = true; }
                            }
                        }
                    }
                }
                if (!string.IsNullOrEmpty(w8type))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownW8Type, w8type);
                }
                if (!string.IsNullOrEmpty(w8datereceived))
                {
                    appHandle.Set_field_value(txtW8Datereceived, w8datereceived);

                }
                if (!string.IsNullOrEmpty(ReportingChapter3Status))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdown1042SReportingChapter3Status, ReportingChapter3Status);
                }
                if (SubjecttoWithholding == true)
                {
                    bool Result1 = false;
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbInterestWithholdingSubjecttoWithholding))
                    {
                        if (SubjecttoWithholding)
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbInterestWithholdingSubjecttoWithholding)) { Result1 = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbInterestWithholdingSubjecttoWithholding);
                                if (appHandle.CheckCheckBoxChecked(ckbInterestWithholdingSubjecttoWithholding))
                                { Result1 = true; }

                            }
                        }
                        else
                        {
                            if (appHandle.CheckCheckBoxChecked(ckbInterestWithholdingSubjecttoWithholding) == false) { Result1 = true; }
                            else
                            {
                                appHandle.ClickObjectViaJavaScript(ckbInterestWithholdingSubjecttoWithholding);
                                if (appHandle.CheckCheckBoxChecked(ckbInterestWithholdingSubjecttoWithholding) == false) { Result1 = true; }
                            }
                        }
                    }
                }   
                if (!string.IsNullOrEmpty(WithholdingReason))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownWitholdingReason, WithholdingReason);
                }
                if (!string.IsNullOrEmpty(CalculationMethod))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpInterestWithholdingCalculationMethod, CalculationMethod);
                }
            }
        }
        public virtual bool VerifyObjectExistInUSSubstantialOwnerPage()
        {
            bool Name = appHandle.IsObjectExists(txtFirstName);
            bool TIN = appHandle.IsObjectExists(txtTIN);
            bool PoO = appHandle.IsObjectExists(txtPoO);
            bool W9File = appHandle.IsObjectExists(ckbW9onFile);
            bool Address = appHandle.IsObjectExists(txtAddressLine1);
            if (Name && !TIN && PoO && W9File && Address)
            {
                return true;
            }

            return false;

        }
        public virtual void UpdateUSSubstantialOwnerDetailsForCorporate()
        {
            string TIN = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
            appHandle.WaitUntilElementExists(ckbIsthisanOrganization);
            appHandle.SelectCheckBox(ckbIsthisanOrganization);
            appHandle.Set_field_value(txtOrgName, "FIS");
            appHandle.Set_field_value(txtTIN, TIN);
            appHandle.Set_field_value(txtPoO, "100");
            appHandle.SelectCheckBox(ckbW9onFile);
            appHandle.Set_field_value(txtAddressLine1, "FIS");
            appHandle.Set_field_value(txtCity, "Collegeville");
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownCountry, (string)Data.Get("US - United States"));
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownState, (string)Data.Get("PA - PENNSYLVANIA"));
            appHandle.Set_field_value(txtZipCode, Data.Get("GLOBAL_ZIPCODE_19355"));
        }
        public virtual void ClickOnAddButtonInSubtantialUSOwnersPage()
        {
            appHandle.WaitUntilElementExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
        }
        public virtual void UpdateW8Details(string w8DateReceived)
        {
            appHandle.WaitUntilElementExists(ckbResidencyInformationW8Required);
            appHandle.SelectCheckBox(ckbResidencyInformationW8Required);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpResidencyInformationW8Type, "W-8BEN-E");
            appHandle.Set_field_value(txtResidencyInformationW8DateReceived, w8DateReceived);
        }
        public virtual bool VerifyObjectExist()
        {
            bool W8Type = appHandle.IsObjectExists(drpResidencyInformationW8Type);
            bool CoI = appHandle.IsObjectExists(drpResidencyInformationCountryofIncorporation);
            if (W8Type && !CoI)
            {
                return true;
            }

            return false;
        }
        public virtual void UpdateForeignCorporationDetails()
        {
            string Taxid = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
            appHandle.WaitUntilElementExists(ckbResidencyInformationForeignCorporation);
            appHandle.Select_CheckBox(ckbResidencyInformationForeignCorporation);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpResidencyInformationResidencyStatus, "1 - Nonresident Alien");
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpResidencyInformationCountryofIncorporation, "GB - UNITED KINGDOM");
            appHandle.Set_field_value(txtForeignTaxid, Taxid);

        }
        public virtual bool VerifyObjectExistInFATCAPage()
        {
            bool W8Status = appHandle.IsObjectExists(dropdownW8BENEStatus);
            bool FATCAWithHolding = appHandle.IsObjectExists(ckbSubjecttoWithholding);
            bool EC = appHandle.IsObjectExists(drpFATCAExcemptionCode);
            bool GIIN = appHandle.IsObjectExists(txtGIIN);
            bool GCD = appHandle.IsObjectExists(txtGIINClaimDate);
            bool GcedD = appHandle.IsObjectExists(txtGIINCollectedDate);
            bool GVD = appHandle.IsObjectExists(txtGIINVerificationDate);
            bool com = appHandle.IsObjectExists(txtFATCACooments);
            if (W8Status && !EC && FATCAWithHolding && GIIN && GCD && GcedD && GVD && com)
            {
                return true;
            }

            return false;

        }
        public virtual void UpdateFATCADetailsForCorporate(string W8BeneStatus="",string FATCAExcemptionCode="",string GIIN ="",string ClaimDate="", string CollectionDate="", string VerificationDate="")
        {
            appHandle.WaitUntilElementExists(dropdownW8BENEStatus);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownW8BENEStatus, W8BeneStatus);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpFATCAExcemptionCode, FATCAExcemptionCode);
            appHandle.Set_field_value(txtGIIN, "A26355.00000.LE.634");
            appHandle.Set_field_value(txtGIINClaimDate, ClaimDate);
            appHandle.Set_field_value(txtGIINCollectedDate, CollectionDate);
            appHandle.Set_field_value(txtGIINVerificationDate, VerificationDate);
            appHandle.Set_field_value(txtFATCACooments, "Subject To FATCA");
        }
        public virtual bool VerifyDetailsInResidencyGeneralPage(string W8Type)
        {
            bool result = false;
            appHandle.WaitUntilElementExists(dropdownW8Type);
            if (appHandle.CheckValueInDropdown(dropdownW8Type, W8Type))
            {
                result = true;
            }
            return result;


        }
        public virtual bool VerifyFATCADetailsyFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "W-8BEN-E Status":
                        if (appHandle.GetSpecifiedObjectAttribute(dropdownW8BENEStatus, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "GIIN":
                        if (appHandle.GetSpecifiedObjectAttribute(txtGIIN, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "GIIN Claim Date":
                        if (appHandle.GetSpecifiedObjectAttribute(txtGIINClaimDate,"value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    
                }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }
            
            return result;
            }
            public virtual bool VerifySubstantialOwnerDetailsyFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "Name":
                        if (appHandle.GetSpecifiedObjectAttribute(txtOrgName, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "TIN":
                        if (appHandle.GetSpecifiedObjectAttribute(txtTIN, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "Percentage of Ownership":
                        if (appHandle.GetSpecifiedObjectAttribute(txtPoO,"value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                        case "Address":
                        if (appHandle.GetSpecifiedObjectAttribute(txtAddressLine1,"Value").Contains(expval))
                        {
                           result = true;
                            matchcount++;
                        }
                        break;
                        case "City":
                        if (appHandle.GetSpecifiedObjectAttribute(txtCity, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "Country":
                        if (appHandle.CheckValueInDropdown(drpdownCountry, "value").Equals(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "State":
                        if (appHandle.CheckValueInDropdown(drpdownState, "value").Equals(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;    

                        case "ZipCode":
                        if (appHandle.GetSpecifiedObjectAttribute(txtZipCode, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    
                }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }
            
            return result;
            }
            public virtual void SelectOwnersInOwnerList(string UniqueOrderRefValue)
        {
            appHandle.SelectRadioButtonInTable(tableofSubstantialUSOwner, UniqueOrderRefValue);
            
        }
        public virtual void ClickOnEditButton()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
            }
        }
        public virtual void ToCheckGIINIsDisabledAndAppliedForisChecked()
        {
            appHandle.WaitUntilElementExists(txtGIIN);
            appHandle.CheckFieldMasked(txtGIIN);
            appHandle.CheckCheckBoxChecked(chkGIINAppliedFor);
        }
        public virtual bool ClickOnAppliedForGIINCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chkGIINAppliedFor))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(chkGIINAppliedFor)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(chkGIINAppliedFor);
                        if (appHandle.CheckCheckBoxChecked(chkGIINAppliedFor))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(chkGIINAppliedFor) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(chkGIINAppliedFor);
                        if (appHandle.CheckCheckBoxChecked(chkGIINAppliedFor) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }
        public virtual void UpdateSubjecttoWithholdingForCorporate(bool ONorOFF,string Chapter4104sStatus)
        {
            this.ClickOnSubjectToWithholdingCheckBox(ONorOFF);
            appHandle.SelectDropdownSpecifiedValue(drpFATCA1042SReportingChapter4Status,Chapter4104sStatus);
        }
        
        

        


        }
    }
