using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class AccontServicesRelationshipsPage
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string DropdownAccount = "Xpath;//select[@name='ACN_CID']";
        
        private static string selectUser ="Xpath;//input[@name = 'selectUser']";
        private static string CustomerFound ="Xpath;//input[@name = 'customerNumber']";
        private static string btnSeach = "XPath;//input[@type='submit'][@value='Search']";
        private static string btnContinue = "XPath;//input[@name='_eventId_continue']";
        private static string SearchCustomerLink = "Xpath;//td[text()='Customer Search']";
        private static string TaxIDRadioButton = "Xpath;//input[@type='radio'][ @value='taxIdNumber']";
        private static string CustomerNumberRadioButton = "Xpath;//input[@type='radio'][ @value='customerNumber']";
        private static string AccountNumberRadioButton = "Xpath;//input[@type='radio'][ @value='accountNumber']";
        private static string LastNameRadioButton = "Xpath;//input[@type='radio'][ @value='userName']";
        private static string UserIDRadioButton = "Xpath;//input[@type='radio'][ @value='CIFAUTH_USERID1']";
        private static string SearchField = "Xpath;//input[@name='searchTerm']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string buttonPrimaryOwnerSearch = "Xpath;//tbody/tr[9]/td/table/tbody/tr[3]/td/div/input[@value='Search']";
        private static string buttonSecondaryOwner1Search = "Xpath;//tbody/tr[12]/td/table/tbody/tr[3]/td/div/input[@value='Search']";
        private static string txtPrimaryOwnerPercentage = "Xpath;//*[@name='roleUsers[1][0].role.percentage']";
        private static string txtSecondaryOwnerPercentage = "Xpath;//*[@name='roleUsers[2][0].role.percentage']";
        private static string txtPrimaryOwnerStartDate = "Xpath;////*[@name='account.primaryAccountOwnershipStartDate']";
        
        private static string buttonSecondaryOwner2Search = "Xpath;//tbody/tr[15]/td/table/tbody/tr[3]/td/div/input[@value='Search']";
        private static string drpdownNoofCustomerforJointRln = "Xpath;//*[@name='rolesCount[B][2]']";
        private static string radiobuttonSingleRelatioship = "Xpath;//*[@name='relationship'][@value='A']";
        private static string radiobuttonJointRelationship = "Xpath;//*[@name='relationship'][@value='B']";

        public virtual void SelectAccountFromAccountsDropdown(string AccountNumber)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccount, AccountNumber);
        }
        
        public virtual void ClickOnSearchButton()
        {
            appHandle.SelectButton(btnSeach);
            Thread.Sleep(1000);
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }

        }
        public virtual void ClickOnContinueButton()
        {
            appHandle.WaitUntilElementVisible(btnContinue);
            appHandle.ClickObject(btnContinue);
        }

         public virtual bool VerifyMessageAccontServicesRelationshipsPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void SelectSearchTypeRadioButton(string SearchType)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            try
            {

                if (SearchType.ToUpper().Contains("Last Name".ToUpper()))
                {
                    appHandle.Set_radiobutton(LastNameRadioButton);
                }
                if (SearchType.ToUpper().Contains("Tax".ToUpper()))
                {
                    appHandle.Set_radiobutton(TaxIDRadioButton);
                }
                if (SearchType.ToUpper().Contains("Account".ToUpper()))
                {
                    appHandle.Set_radiobutton(AccountNumberRadioButton);
                }
                if (SearchType.ToUpper().Contains("User".ToUpper()))
                {
                    appHandle.Set_radiobutton(UserIDRadioButton);
                }
                if (SearchType.ToUpper().Contains("Customer".ToUpper()))
                {
                    appHandle.Set_radiobutton(CustomerNumberRadioButton);
                }
               

            }
            catch (Exception e)
            {
                Report.Fail("Please check Searchtype." + e);
            }

        }
        public virtual void SearchCustomer(string searchType,string value)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TaxIDRadioButton))
            {
                this.SelectSearchTypeRadioButton(searchType);
            }
            appHandle.Set_field_value(SearchField, value);
            
        }

        public virtual void EditAccountRelationship(string Relationship,string Taxid)
        {
            
            if(!string.IsNullOrEmpty(Relationship))
            {
                string runTimeObj = "XPath;//*[@name='relationship'][@value='"+Relationship+"']";
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runTimeObj))
                {
                    appHandle.ClickObjectViaJavaScript(runTimeObj);
                }
            }
            ClickOnContinueButton();
            appHandle.ClickObjectViaJavaScript(selectUser);
            ClickOnSearchButton();
            SearchCustomer(Data.Get("Tax ID Number"),Taxid);
            ClickOnSearchButton();
            appHandle.ClickObjectViaJavaScript(CustomerFound);
            appHandle.Wait_For_Specified_Time(5);
            ClickOnContinueButton();
        }
        public virtual void EditAccountRelationshiptojoint(string Relationship, string NoofCust, string PrimaryCustomerno, string SecondaryCustomer1no, string SecondaryCust2No, string PrimaryOwnerPer, string SecondaryOwnerPer, string PrimaryOwnerStartDate)
        {

            Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonJointRelationship);
            appHandle.ClickObjectViaJavaScript(radiobuttonJointRelationship);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownNoofCustomerforJointRln, NoofCust);

            ClickOnContinueButton();
            if (!string.IsNullOrEmpty(PrimaryCustomerno))
            {
                appHandle.ClickObjectViaJavaScript(buttonPrimaryOwnerSearch);
                SearchCustomer(Data.Get("Customer Number"), PrimaryCustomerno);
                ClickOnSearchButton();
                appHandle.ClickObjectViaJavaScript(CustomerFound);
            }
            if (!string.IsNullOrEmpty(SecondaryCustomer1no))
            {
                appHandle.ClickObjectViaJavaScript(buttonSecondaryOwner1Search);
                SearchCustomer(Data.Get("Customer Number"), SecondaryCustomer1no);
                ClickOnSearchButton();
                appHandle.ClickObjectViaJavaScript(CustomerFound);
            }
            if (!string.IsNullOrEmpty(SecondaryCust2No))
            {
                appHandle.ClickObjectViaJavaScript(buttonSecondaryOwner2Search);
                SearchCustomer(Data.Get("Customer Number"), SecondaryCust2No);
                ClickOnSearchButton();
                appHandle.ClickObjectViaJavaScript(CustomerFound);
            }
            ClickOnContinueButton();
            appHandle.WaitUntilElementExists(txtPrimaryOwnerPercentage);
            appHandle.Set_field_value(txtPrimaryOwnerPercentage, PrimaryOwnerPer);
            appHandle.Set_field_value(txtSecondaryOwnerPercentage, SecondaryOwnerPer);
            appHandle.Set_field_value(txtPrimaryOwnerStartDate, PrimaryOwnerStartDate);
        }


         
    }
}