using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;
using System.Threading;
using Profile7Automation.Libraries.Helper;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountClosureUtilityPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string AccountDropDown = "Xpath;//*[@id='content']//following-sibling::td/descendant::select";
        private static string AccountLinkageCheckBox = "Xpath;//*[@type='checkbox']";
        private static string RemoveLinkButton = "/Xpath;/*[@name='removeLink']";
        private static string AccountLinkageRemovedMessage = "Xpath;//*[text()='Account linkage(s) removed successfully.']";
        private static string LinkageTypeFirstRow = "Xpath;//*[@id='auto-linkages-list']/tbody/tr[1]/td[3]";
        private static string ResolutionFirstRow = "Xpath;//*[@id='auto-linkages-list']/tbody/tr[1]/td[4]";
        private static string AccountNumberFromGrid = "Xpath;//*[@id='auto-linkages-list']/tbody/tr[1]/td[2]";
        private static string OtherAccountLinkagesNoRecordsLabel = "Xpath;(//td[@class='fieldLabelLeft'])[3]";

        public static string dropdownAccountNumber="XPath;//td/select[@name='accountNumber']";

        public static string buttonRemoveLink="XPath;//input[@name='removeLink']";

        public static string tableAccountLinkage="XPath;//table[@id='auto-linkages-list']/tbody";


        public virtual void SelectAccount(string AccountNumber, string MortgageAccountNumber)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(AccountDropDown))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(AccountDropDown, AccountNumber);
            }
            string AccountNumberFromGridValue = appHandle.GetLabelText(AccountNumberFromGrid);
            string LinkageTypeValue = appHandle.GetLabelText(LinkageTypeFirstRow);
            string ResolutionValue = appHandle.GetLabelText(ResolutionFirstRow);
            string OtherAccountLinkagesValue = appHandle.GetLabelText(OtherAccountLinkagesNoRecordsLabel);
            string temp = AccountNumberFromGridValue+" "+LinkageTypeValue+" "+ResolutionValue+" "+OtherAccountLinkagesValue;
            string temp2 = MortgageAccountNumber+" "+Data.Get("FrontMoneyDepositAccount")+" "+Data.Get("SetFrontMoneyOption")+" "+Data.Get("OtherAccountLinkagesNoRecords");
            string temp3 = Data.Get("SetFrontMoneyOption");
            if ((WebCSRPageFactory.WebCSRMasterPage.comparestringvalues(AccountNumberFromGridValue, MortgageAccountNumber)) &&
            (WebCSRPageFactory.WebCSRMasterPage.comparestringvalues(LinkageTypeValue, Data.Get("FrontMoneyDepositAccount"))) &&
            (WebCSRPageFactory.WebCSRMasterPage.comparestringvalues(OtherAccountLinkagesValue, Data.Get("OtherAccountLinkagesNoRecords"))) &&
            (ResolutionValue.Contains(Data.Get("SetFrontMoneyOption"))))
            {
                Report.Pass("Mortgage Account displayed in Account Closure Utility Page under Account Linkages (Eligible for Automatic Removal of Links)", "SelectAccount", "true", appHandle);
            }
            else
            {
                Report.Fail("Mortgage Account displayed in Account Closure Utility Page under Account Linkages (Eligible for Automatic Removal of Links)", "SelectAccount", "true", appHandle, true);
            }
        }
     

        public virtual bool AccountLinkageRemovedMessageValidation()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (appHandle.GetObjectText(AccountLinkageRemovedMessage).Equals(Data.Get("AccountRemovedMessage")))
            {
                Result = true;
            }
            return Result;
        }

        public virtual bool CheckDataInAccountLinkageTable(string accountnumber,string Linkagetype)
        {
            string dynamicobj="XPath;//table[@id='auto-linkages-list']/tbody/descendant::td[contains(text(),'"+Linkagetype+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccountNumber);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccountNumber,accountnumber);
            return appHandle.IsObjectExists(dynamicobj);
        
        }

        public virtual bool CheckDataNotInAccountLinkageTable(string accountnumber,string Linkagetype)
        {
            string dynamicobj="XPath;//table[@id='auto-linkages-list']/tbody/descendant::td[contains(text(),'"+Linkagetype+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccountNumber);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccountNumber,accountnumber);
            return appHandle.IsObjectExists(dynamicobj);
        
        }


    }
}