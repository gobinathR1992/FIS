using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DepositTitleAddressPage
    {
       public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

       public static string drpTitleAddressAccount="Xpath;//select[@name='ACN_CID']";
       public static string txtAccountTitle1= "Xpath;//input[@name='ACN_TITLE1']";
       public static string txtAccountTitle2= "Xpath;//input[@name='ACN_TITLE2']";
       public static string txtAccountTitle3= "Xpath;//input[@name='ACN_TITLE3']";
       public static string txtAccountTitle4= "Xpath;//input[@name='ACN_TITLE4']";
       public static string txtTitleAddressMailingAddressAddress1="Xpath;//input[@name='ACNADDR_AD1']";
       public static string txtTitleAddressMailingAddressAddress2="Xpath;//input[@name='ACNADDR_AD2']";
       public static string txtTitleAddressMailingAddressAddress3="Xpath;//input[@name='ACNADDR_AD3']";
       public static string txtTitleAddressMailingAddressTownship="Xpath;//input[@name='ACNADDR_LOC']";
       public static string txtTitleAddressMailingAddressCounty="Xpath;//input[@name='ACNADDR_MCOUNTY']";
       public static string txtTitleAddressMailingAddressCity="Xpath;//input[@name='ACNADDR_CITY']";
       public static string txtTitleAddressMailingAddressZipCode="Xpath;//input[@name='ACNADDR_MZIP']";
       public static string txtSeasonalMailingAddressStartDate="Xpath;//input[@name='SADDRACN_SADSD']";
       public static string txtSeasonalMailingAddressEndDate="Xpath;//input[@name='SADDRACN_SADED']";
       public static string txtSeasonalMailingAddressAddress1="Xpath;//input[@name='SADDRACN_SAD1']";
       public static string txtSeasonalMailingAddressAddress2="Xpath;//input[@name='SADDRACN_SAD2']";
       public static string txtSeasonalMailingAddressAddress3="Xpath;//input[@name='SADDRACN_SAD3']";
       public static string txtSeasonalMailingAddressTownship="Xpath;//input[@name='SADDRACN_SLOC']";
       public static string txtSeasonalMailingAddressCounty="Xapth;//input[@name='SADDRACN_SCOUNTY']";
       public static string txtSeasonalMailingAddressCity="Xpath;//input[@name='SADDRACN_SCITY']";
       public static string txtSeasonalMailingAddressZipCode="Xpath;//input[@name='SADDRACN_SZIP']";
       public static string txtOffSeasonMailingAddressAddress1="Xpath;//input[@name='SADDRACN_NSAD1']";
       public static string txtOffSeasonMailingAddressAddress2="Xpath;//input[@name='SADDRACN_NSAD2']";
       public static string txtOffSeasonMailingAddressAddress3="Xpath;//input[@name='SADDRACN_NSAD3']";
       public static string txtOffSeasonMailingAddressTownship="Xpath;//input[@name='SADDRACN_NSLOC']";
       public static string txtOffSeasonMailingAddressCounty="Xpath;//input[@name='SADDRACN_NSCOUNTY']";
       public static string txtOffSeasonMailingAddressCity="Xpath;//input[@name='SADDRACN_NSCITY']";
       public static string txtOffSeasonMailingAddressZipcode="Xpath;//input[@name='SADDRACN_NSZIP']";
       public static string drpTitleAddressMailingAddressMailOption="Xpath;//select[@name='ACN_MF']";
       public static string drpTitleAddressMailingAddressCountry="Xpath;//select[@name='ACNADDR_CNTRY']";
       public static string drpTitleAddressMailingAddressState="Xpath;//select[@name='ACNADDR_STATE']";
       public static string drpSeasonalMailingAddressCountry="Xpath;//select[@name='SADDRACN_SCNTRY']";
       public static string drpSeasonalMailingAddressState="Xpath;//select[@name='SADDRACN_SSTATE']";
       public static string drpOffSeasonMailingAddressCountry="Xpath;//select[@name='SADDRACN_NSCNTRY']";
       public static string drpOffSeasonMailingAddressState="Xpath;//select[@name='SADDRACN_NSSTATE']";

       private  static string txtCustomerShortName = "Xpath;//input[@name='ACN_LNM']";  
       private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";       
       private  static string buttonSubmit = "Xpath;//*[@name='submit']";

       public virtual void EnterCustomerShortName(string CustomerShortName)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCustomerShortName);
            appHandle.Set_field_value(txtCustomerShortName,CustomerShortName);
      
        }

        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
        }
       
       
	   	public virtual bool VerifyMessageTitleAddressPage(string sMessage)
        {
     		bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
		}



    }

}








