using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class CardManagementPage
    { 
         static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

         private static string buttonAdd ="Xpath;//*[@name='add']";
         public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
         private static string buttonSubmit = "Xpath;//*[@name='submit']";
         private static string buttonCancel ="Xpath;//*[@name='cancel']";
         public static string tableListOfCards ="Xpath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";
         private static string txtCardNo= "Xpath;//*[@name='CRD_CRDNUM']";
         private static string buttonDelete = "XPath;//*[@value='Delete']";
         private static string drpdwnAccount ="Xpath;//*[@name='CRD_CID']";
         public static string DrpCardHisAccountno ="Xpath;//*[@name='CRD_CRDNUM']";
         private static string drpCardType="Xpath;//*[@name='CRD_CRDTYP']";
         private static string drpCardNumber = "Xpath;//*[@name='CRD_CRDNUM']";
         private static string drpAccessOption="Xpath;//*[@name='CRD_CARACC']";
         private static string drpEmbossingOption ="Xpath;//*[@name='CRD_EMBOPT']";
         private static string drpChargeAccount="Xpath;//*[@name='CRD_FEECID']";
         private static string txtDailyithdrawalLimit="Xpath;//*[@name='CRD_LMT']";
         private static string txtATMDailyLimit="Xpath;//*[@name='CRD_ATMLMT']";
         private static string txtCashbackDailyLimit="Xpath;//*[@name='CRD_CSBLMT']";
         
         private static string txtExpirationDate="Xpath;//*[@name='CRD_EXPDT']";
         private static string buttonEdit="XPath;//*[@name='edit']";
         private static string drpCardStatus="XPath;//*[@name='CRD_STAT']";
         private static string drpreasoncode="XPath;//*[@name='CRD_MKERSNCD']";
         //Member Information
        public static string txtMember="Xpath;//input[@name='CRDMEM_MNUM']";
        public static string drpMemCardStatus="Xpath;//select[@name='CRDMEM_STAT']";
        public static string txtMemOrderDate="Xpath;//input[@name='CRDMEM_ORD']";
        public static string txtMemIssueDate="Xpath;//input[@name='CRDMEM_ISDT']";
        public static string btnAdd="Xpath;//input[@name='add']";

        //Card Notes
        public static string txtNoteDescription = "Xpath;//input[@name='CRDNOT_DESC']";
        public static string txtNoteExpirationDate = "Xpath;//input[@name='CRDNOT_EXP']";
        public static string txtCardNote = "Xpath;//input[@name='CRDNOT_NOTE']";



        public virtual void ClickonAddbutton()
        {
           
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnAdd))
            {appHandle.ClickObjectViaJavaScript(btnAdd);}
            
        }  
         public virtual string UpdateCardDetails(string CardType,string Account,string Option="",string EmbossOption="",string Amount="",string Expdate=null,string cardstatus="")
         {
             string CardNo = appHandle.GetElementValue(txtCardNo);
             appHandle.SelectDropdownSpecifiedValueByPartialText(drpCardStatus,cardstatus);
             appHandle.SelectDropdownSpecifiedValueByPartialText(drpEmbossingOption,EmbossOption);
             appHandle.Set_field_value(txtDailyithdrawalLimit,Amount);
             appHandle.Set_field_value(txtATMDailyLimit,Amount);
             appHandle.Set_field_value(txtCashbackDailyLimit,Amount);              
             appHandle.SelectDropdownSpecifiedValueByPartialText(drpChargeAccount,Account);            
             appHandle.Set_field_value(txtExpirationDate,Expdate);
             return CardNo;
         } 

         public virtual void MoveAccountFromAvailableAccountToSelectedAccounts(string AccountNumber)
        {
            string AvailableAccounts = "XPath;//select[@name='eligibleList']/descendant::*[contains(text(),'" + AccountNumber + "')]";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(AvailableAccounts))
            {
                appHandle.ClickObjectWithOutJavaScript(AvailableAccounts);
                this.ClickOnAddButton();


            }

        }
        public virtual void ClickOnAddButton()
        {
            appHandle.WaitUntilElementExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);

        }
        public virtual bool VerifyMessageInCardManagementPage(string Msg)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (appHandle.GetObjectText(MSGOBJ).Contains(Msg))
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual void ClickOnSubmitButton()
        {
            appHandle.WaitUntilElementExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);

        }
        public virtual void ClickOnDeleteButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonDelete))
            {
                appHandle.ClickObjectViaJavaScript(buttonDelete);

            }
        }
        public virtual void SelectCardInCardList(string UniqueOrderRefValue)
        {
            appHandle.SelectRadioButtonInTable(tableListOfCards, UniqueOrderRefValue);

        }

        public virtual void selectAccountFromDropDown(string account)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpdwnAccount))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpdwnAccount, account);

            }
            
        }
        public virtual void selectCardNumberFromDropDown(string card)
        {
        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpCardNumber))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpCardNumber, card);
                
            }
        }
        public virtual void SelectCardType(string CardType)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpCardType, CardType);
        }
        public virtual bool VerifyCardHistory(string Account)
        {
            bool Result = false;
            appHandle.SelectDropdownSpecifiedValue(drpdwnAccount, Account);
            if (appHandle.GetDropdownSelectedValue(DrpCardHisAccountno).Contains(Data.Get("No cards found for this account.")))
            {
                Result = true;
            }

            return Result;

        }
        public virtual void EnterMemberInformation(string AccountNumber, string CardNumber, string MemberStatus, string Members, string OrderDate, string IssueDate)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpdwnAccount, AccountNumber);
            appHandle.SelectDropdownSpecifiedValueByPartialText(DrpCardHisAccountno, CardNumber);
            appHandle.Wait_For_Specified_Time(3);
            this.ClickonAddbutton();
            appHandle.Wait_For_Specified_Time(3);
            appHandle.Set_field_value(txtMember, Members);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpMemCardStatus, MemberStatus);
            appHandle.Set_field_value(txtMemOrderDate, OrderDate);
            appHandle.Set_field_value(txtMemIssueDate, IssueDate);
        }
        public virtual void EnterCardNotes(string AccountNumber, string CardNumber, string Description, string ExpDate, string Note)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpdwnAccount, AccountNumber);
            appHandle.SelectDropdownSpecifiedValueByPartialText(DrpCardHisAccountno, CardNumber);
            appHandle.Wait_For_Specified_Time(3);
            this.ClickonAddbutton();
            appHandle.Wait_For_Specified_Time(3);
            appHandle.Set_field_value(txtNoteDescription, Description);
            appHandle.Set_field_value(txtNoteExpirationDate, ExpDate);
            appHandle.Set_field_value(txtCardNote, Note);
        }
        public virtual void ClickOnEditButton()
        {
            appHandle.WaitUntilElementExists(buttonEdit);
            appHandle.ClickObjectViaJavaScript(buttonEdit);

        }
        public virtual bool VerifyCardStatus(string Status)
        {
            bool Result = false;
            if (appHandle.GetDropdownSelectedValue(drpCardStatus).Contains(Status))
            {
                Result = true;
            }

            return Result;

        }


       public virtual void SelectIssueReplacementOption(bool IssueReplacementONorOFF)
        {
            //  appHandle.SelectDropdownSpecifiedValueByPartialText(drpCardStatus,cardstatus);
            //  appHandle.SelectDropdownSpecifiedValueByPartialText(drpreasoncode,reasoncode);

             if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("Issue Replacement")))
            {
                if (!IssueReplacementONorOFF)
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Issue Replacement") + "|" + Data.Get("OFF"));
                }
                else
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Issue Replacement") + "|" + Data.Get("GLOBAL_ON"));
                }
            }          
            
        } 
        

    }
}