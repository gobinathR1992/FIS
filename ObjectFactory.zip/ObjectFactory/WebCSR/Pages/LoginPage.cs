﻿using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoginPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string UserIDField = "Xpath;//input[@type='text'][@name='userName']";
        private static string PasswordField = "Name;password";
        private static string SubmitButton = "XPATH;//INPUT[@value='Submit']";
        private static string BranchDropDown = "Xpath;//*[text()='Branch:']/following-sibling::select";
        private static string NewPasswordField = "Name;newPassword";
        private static string ConfirmPasswordField = "Name;newPasswordVerify";
        private static string LogOutButton = "name;logout";
        private static string MSGOBJ="Xpath;//div[@class='msg-box']/descendant::p";
        public virtual bool VerifyCustomerSearchPageLoads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton, 30))
            {
                result = true;
            }
            return result;
        }
        public virtual void enter_reset_password_details(string Password, string NewPassword)
        {

            Report.Info("Enter Reset Passsword details.");
            appHandle.Set_field_value(PasswordField, Password);
            appHandle.Set_field_value(NewPasswordField, NewPassword);
            appHandle.Set_field_value(ConfirmPasswordField, NewPassword);
            Report.Info("Reset Passsword details entered.");

        }
        //  public virtual  void enter_reset_password_details(string Password, string NewPassword)
        // {
        //     if (DataAdapterUtility.GetWebApplicationType().Equals("mobile"))
        //     {
        //         Report.Info("Enter Reset Passsword details.");
        //         appHandle.Set_field_value(PasswordField, Password);
        //         appHandle.Set_field_value(NewPasswordField, NewPassword);
        //         appHandle.Set_field_value(ConfirmPasswordField, NewPassword);
        //         Report.Info("Reset Passsword details entered.");
        //     }
        //     else
        //     {
        //         Report.Info("Enter Reset Passsword details.");
        //         appHandle.Set_field_value(PasswordField, Password);
        //         appHandle.Set_field_value(NewPasswordField, NewPassword);
        //         appHandle.Set_field_value(ConfirmPasswordField, NewPassword);
        //         Report.Info("Reset Passsword details entered.");
        //     }
        // }

        public virtual void enter_login_details(String userID, String password, String Branch)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(UserIDField, 30);
            appHandle.Set_field_value(UserIDField, userID);
            appHandle.Set_field_value(PasswordField, password);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(BranchDropDown, 30))
            {
                appHandle.SelectDropdownSpecifiedValue(BranchDropDown, Branch);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton, 30);

        }
        public virtual string get_user_id_field_value()
        {
            return appHandle.GetObjectText(UserIDField);
        }
        public virtual void select_submit_button()
        {
            appHandle.ClickObjectViaJavaScript(SubmitButton);

        }
        public virtual void WebCSRLogOut()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(LogOutButton))
            {
                appHandle.ClickObjectViaJavaScript(LogOutButton);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton, 30);
                Profile7CommonLibrary.KillProcessByProcessName("chrome");                
            }
       
            
        }
        public virtual bool VerifyMSGToResetPassword()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("You must change your password before you can proceed. Please choose a new password.")))
            {
                Result = true;
            }

            return Result;
        }
        public virtual bool VerifyResetPasswordMessage(string Msg ="Password changed successfully. Please login again.")
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Msg))
            {
                Result = true;
            }

            return Result;
        }




    }
}
