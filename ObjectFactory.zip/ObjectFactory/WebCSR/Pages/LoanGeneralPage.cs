using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanGeneralPage
    {
        WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string ProducePrintedBill_Checkbox = "Xpath;//input[@name='LN_BMET']";
        public static string AccountPurchased_Checkbox = "Xpath;//input[@name='LN_PPFLG']";
        public static string EligibleForInvestmentSweep_Checkbox = "Xpath;//input[@name='LN_SWPEL']";
        public static string CombinedStatements_Checkbox = "Xpath;//input[@name='LN_CMBSTAT']";
        public static string ElectronicStatements_Checkbox = "Xpath;//input[@name='LN_ESTAT']";
        public static string FinancialManagementStatementPrintOption_Checkbox = "Xpath;//input[@name='ACN_SMET']";
        public static string AccountBalances_CreditLimit_Field = "Xpath;//input[@name='LN_CRLMT']";
        public static string AccountInformation_Name_Field = "Xpath;//input[@name='ACN_ACCTNAME']";
        public static string AccountInformation_PromotionCode_Field = "Xpath;//input[@name='ACN_SOFCODE']";
        public static string AccountInformation_CurrentRisk_Field = "Xpath;//input[@name='LN_CURRISK']";
        public static string MinimumPaymentAmounttoProduceBill_Field = "Xpath;//input[@name='LN_MPPF']";
        public static string CouponBookProductionFrequency_Field = "Xpath;//input[@name='LN_CBFRE']";
        public static string CouponBookProductionOffsetDays_Field = "Xpath;//input[@name='LN_CBOFF']";
        public static string LoanGeneralAccount_Dropdown = "Xpath;//select[@name='ACN_CID']";
        public static string AccountInformation_BranchOfOwnership_Dropdown = "Xpath;//select[@name='ACN_BOO']";
        public static string AccountInformation_CostCenter_Dropdown = "Xpath;//select[@name='ACN_CC']";
        public static string AccountInformation_ProductType_Dropdown = "Xpath;//select[@name='ACN_TYPE']";
        public static string AccountInformation_CustomerCode_Dropdown = "Xpath;//select[@name='ACN_CCODE']";
        public static string AccountInformation_AccountPurpose_Dropdown = "Xpath;//select[@name='LN_PURCD']";
        public static string AccountInformation_AccountSubtype_Dropdown = "Xpath;//select[@name='LN_SUBT']";
        public static string AccountInformation_AccountOfficer_Dropdown = "Xpath;//select[@name='ACN_OFF']";
        public static string AccountInformation_CompanyCode_Dropdown = "Xpath;//select[@name='LN_CO']";
        public static string AccountInformation_LoanSaleableCode_Dropdown = "Xpath;//select[@name='LN_SLBL']";
        public static string CouponBookProductionMethod_Dropdown="Xpath;//select[@name='LN_CBMET']";
        public static string AnticipatedActivity_Dropdown="Xpath;//select[@name='ACN_ANTICIPATEDACTIVITY']";
        












    }

}