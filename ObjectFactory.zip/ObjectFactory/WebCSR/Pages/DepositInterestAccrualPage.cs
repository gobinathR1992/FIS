using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Threading;
using GTS_OSAF;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DepositInterestAccrualPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tblBalance = "Xpath;//table[@class='contentTable']/tbody/tr[2]/td/h2";
        public static string imgCompoundingFrequencyCalculator = "Xpath;//input[@name='DEP_ICF']/parent::td/child::a";
        public static string DropdownAccount = "Xpath;//select[@name = 'ACN_CID']";
        public static string DropdownAccrualMethod = "Xpath;//select[@name = 'DEP_IACM']";
        public static string DropdownAccrualBase = "Xpath;//select[@name = 'DEP_IRCB']";
        public static string txtCompoundingFrequency ="Xpath;//input[@name = 'DEP_ICF']";
        public static string dropdownNegativeAccrualOption = "Xpath;//select[@name = 'DEP_NEGACRPO']";

        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string AccruedInterest = "Xpath;//td[contains(text(),'Accrued Interest')]/following-sibling::td[1][input[@name ='DEP_ACR' ]]";
        private static string PositiveAccruedInterest = "Xpath;//td[contains(text(),'Positive Accrued Interest:')]/following-sibling::td[1][input[@name ='DEP_POSACR' ]]";
        private static string NegativeAccruedIntNegRate = "Xpath;//td[contains(text(),'Negative Accrued Interest (Negative Rate):')]/following-sibling::td";
        private static string AuthorizedNegativeAccrued = "Xpath;//td[contains(text(),'Authorized Negative Accrued:')]/following-sibling::td";
        private static string UnauthorizedNegativeAccrued = "Xpath;//td[contains(text(),'Unauthorized Negative Accrued:')]/following-sibling::td";
        private static string PositiveAccruedInterestonNegativeRate = "Xpath;//td[contains(text(),'Positive Accrued Interest on Negative Balance (Negative Rate):')]/following-sibling::td";
        private static string tableContent = "Xpath;//table[@class='contentTable']/tbody";
        private static string CompoundedNextDateField = "Xpath;//input[@name = 'DEP_INC']";
        private static string CompoundedInterestField = "Xpath;//td[contains(text(),'Compounded Interest:')]/following-sibling::td";
        private static string txtMinimumBalancetoAccrue = "Xpath;//input[@name = 'DEP_MINACR']";
        private static string dropdownMinBalAccrualOpt = "Xpath;//select[@name = 'DEP_MINOPT']";

        public virtual bool WaitUntilDepositInterestPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownAccount))
            {
                result = true;
            }

            return result;

        }
        public virtual void EnterInterestAccrualCalculationOptions(string AccrualMethod= "",string AccrualBase = "",string compfreq ="", string NegativeAccrOpt = "", string MinBalAccr = "", string MinBalAccrOpt = "")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownAccount))
            {
                if(!string.IsNullOrEmpty(AccrualMethod))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccrualMethod,AccrualMethod);
                }
                if(!string.IsNullOrEmpty(AccrualBase))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccrualBase,AccrualBase);
                }
                if(!string.IsNullOrEmpty(compfreq))
                {
                appHandle.Set_field_value(txtCompoundingFrequency,compfreq);
                }
                if(!string.IsNullOrEmpty(NegativeAccrOpt))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownNegativeAccrualOption,NegativeAccrOpt);
                }      
                 if(!string.IsNullOrEmpty(MinBalAccr))
                {
                appHandle.Set_field_value(txtMinimumBalancetoAccrue,MinBalAccr);
                }
                if(!string.IsNullOrEmpty(MinBalAccrOpt))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMinBalAccrualOpt,MinBalAccrOpt);
                }     

            }

        }
        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage, 5);
        }
        public virtual bool VerifyMessageDepositInterestPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyTableDataByLabelNameLabelValue(string sLabelNameLabelValuePipeDelimited)
        {
            bool Result = false;
            if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableContent, sLabelNameLabelValuePipeDelimited))
            {
                Result = true;
            }
            return Result;
        }

        public virtual string GetCompoundedNextDateFieldVal()
        {
            string outputValue = null;
            try
            {
                outputValue = appHandle.GetElementValue(CompoundedNextDateField);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return outputValue;
        }
         public virtual string GetInterestAccrualCalculationOptionsByFieldName(string FieldName)
        {
            string outvalue="";
            try
            {
            switch(FieldName)
                {
                    case "Compounded Interest":
                    outvalue=appHandle.GetObjectText(CompoundedInterestField);
                    break;

                    case "Compounded Next Date":
                    outvalue=appHandle.GetElementValue(CompoundedNextDateField);
                    break;
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return outvalue;

        }

    }

}

