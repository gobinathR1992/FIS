using GTS_OSAF.CoreLibs;
using System;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateRetirementPlanPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tblRetirementPlanOptions = "Xpath;//h2[text()='Retirement Plan']/parent::td/parent::tr/following-sibling::tr/td/table";
        public static string ckbSpousalConsentRequired = "Name;plan.spousalConsentRequired";
        public static string ckbSpousalConsentOnFile = "Name;plan.spousalConsentOnFile";
        public static string txtPlanId = "Name;plan.id";
        public static string txtPlanDate = "Name;plan.date";
        public static string drpNumberofDeathBeneficiaries = "Name;plan.numberOfBeneficiaries";
        public static string buttonContinue="XPath;//input[@name='_eventId_continue']";
        public static string txtPlanID="XPath;//input[@name='plan.id']";
        public static string txtPlandate="XPath;//input[@name='plan.date']";        
        public static string buttonSubmit="XPath;//input[@name='_eventId_submit']";
        private static string buttonSearch = "XPath;//input[@value='Search']";
        private static string buttonRadio = "XPath;//input[@name='customerNumber']";
        public static string dropdownNumberofDeathBeneficiaries="XPath;//select[@name='plan.numberOfBeneficiaries']";
        private static string dropdownrelationship = "XPath;//select[@name='plan.relationshipToRI']";
        private static string buttonCreatePlan = "Xpath;//input[@value='Create Plan']";

        /// <summary>
        /// This method is select to Retirement Plan in table
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.CreateRetirementPlanPage.SelectRetirementPlan();
        /// </example>
        public virtual void SelectRetirementPlan(string sRetirementPlanName)
        {
            try
            {
                appHandle.SelectRadioButtonInTable(tblRetirementPlanOptions, sRetirementPlanName);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        /// <summary>
        /// This method is Check sucess message for retirement plan creation
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRPageFactory.CreateRetirementPlanPage.CheckSuccessMessageForRetirementPlanCreation();
        /// </example>
        public virtual bool CheckSuccessMessageForRetirementPlanCreation()
        {
             bool bCheck = false;
            try{
            bCheck = appHandle.CheckSuccessMessage("Retirement plan is created successfully");
            }
            catch(Exception e)
            {
              Report.Info("Exception logged : "+e);
            }
            return bCheck;   
        }

        /// <summary>
        /// This method is used to Enter Retirement plan details
        /// </summary>
        /// <returns>Number of Death Beneficiaries</returns>     
        /// <param name = "RetirementDetails"></param>
        /// RetirementDetails[0] = ""        'Retirement Plan Date' 'By default application date'
        /// RetirementDetails[1] = ""   'Retirement Plan ID'
        /// RetirementDetails[2] = "1"  'Retirement No Of Death Beneficiaries'
        /// RetirementDetails[3] = "GLOBAL_ON" 'To check Spousal Consent Required check box' 'otherwise RetirementDetails[3]=""'
        /// RetirementDetails[4] = "GLOBAL_ON" 'To check Spousal Consent on File check box'  'otherwise RetirementDetails[4]=""' 
        public virtual void EnterPlanDetails(string[] RetirementDetails)
        {
            appHandle.Set_field_value(txtPlanDate, RetirementDetails[0]);
            int PlanidNumber = RandomNumber();
            RetirementDetails[1] = PlanidNumber.ToString();
            appHandle.Set_field_value(txtPlanId, RetirementDetails[1]);
            appHandle.SelectDropdownSpecifiedValue(drpNumberofDeathBeneficiaries, RetirementDetails[2]);
            if (RetirementDetails[3] == "GLOBAL_ON")
            {
                appHandle.SelectCheckBox(ckbSpousalConsentRequired);
            }
            if (RetirementDetails[4] == "GLOBAL_ON")
            {
                appHandle.SelectCheckBox(ckbSpousalConsentOnFile);
            }
        }
        public static int RandomNumber()
        {
            Random random = new Random();
            return random.Next(100000000, 999999999);
        }

        public virtual void SelectRetirementPlanBasedOnPlanValue(string retirementplanname)
        {
            string dynamicobj="Xpath;//td[contains(text(),'"+retirementplanname+"')]/ancestor::td[1]/preceding-sibling::td/input";
            appHandle.Set_radiobutton(dynamicobj);
            Report.Info("The RetirementPlan "+retirementplanname+"has been selected successfully","selectplanpass","True",appHandle);
        
            

        }

        public virtual void ClickOnContinue()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonContinue);
            appHandle.ClickObjectViaJavaScript(buttonContinue);
        }

        public virtual void ClickOnSearch()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearch);
            appHandle.ClickObjectViaJavaScript(buttonSearch);
        }

         public virtual void ClickOnRadioButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRadio);
            appHandle.ClickObjectViaJavaScript(buttonRadio);
        }

        public virtual void EnterDetailsForPlan(string plandate,string dob,int noofbeneficiary=0,string relationship="",string BeneficiaryRelationship="")
        {
            if(appHandle.IsObjectExists(buttonCreatePlan))
            {
                appHandle.ClickObjectViaJavaScript(buttonCreatePlan);
            }
            string randnum=appHandle.CreateRamdomData(FieldType.NUMERIC,1000,9999).ToString();
            string planid="Plan"+appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 3).ToString().ToUpper()+randnum;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPlanID);
            appHandle.Set_field_value(txtPlanID,planid);
            appHandle.Set_field_value(txtPlandate,plandate);

            if(appHandle.IsObjectExists(dropdownrelationship))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownrelationship,relationship);
            }           
            if(noofbeneficiary>0)
            {
                EnterBeneficiaryDetailsForRetirementAccount(noofbeneficiary,dob,BeneficiaryRelationship);
            }
            Report.Info("The Plan details are entered","planinfo","True",appHandle);

        }

        public virtual void ClickOnSubmitButton()
        {
             Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
             appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }

        public virtual void EnterBeneficiaryDetailsForRetirementAccount(int numberofbeneficiary,string dob,string relationship)
        {
            //int i=0;
            int wper=0;
            bool evennbrflg=false;
            if(100%numberofbeneficiary==0)
            {
                wper=100/numberofbeneficiary;
                evennbrflg=true;

            }
            else
            {
                wper=100/numberofbeneficiary;
                evennbrflg=false;

            }
            
            string ran1=appHandle.CreateRamdomData(FieldType.NUMERIC,100,999).ToString();
            string ran2=appHandle.CreateRamdomData(FieldType.NUMERIC,10,99).ToString();
            string ran3=appHandle.CreateRamdomData(FieldType.NUMERIC,1000,9999).ToString();
            string taxid=ran1+"-"+ran2+"-"+ran3;
            string dropdownNumberofDeathBeneficiariesnew="XPath;//select[@name='plan.numberOfBeneficiaries']";
            
            string buttonContinue="XPath;//input[@name='_eventId_continue']";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownNumberofDeathBeneficiariesnew);
            appHandle.SelectDropdownSpecifiedValue(dropdownNumberofDeathBeneficiariesnew,numberofbeneficiary+"");
            appHandle.ClickObject(buttonContinue);
            for(int i=0;i<numberofbeneficiary;i++)
            {                
                
                string dropdownType="XPath;//select[@name='plan.beneficiaries["+i+"].type']";
                string txtnameobj="XPath;//input[@name='plan.beneficiaries["+i+"].name']";
                string txtDOB="XPath;//input[@name='plan.beneficiaries["+i+"].dateOfBirth']";
                string txtTaxid="XPath;//input[@name='plan.beneficiaries["+i+"].taxIdNumber']";
                string dropdownRelationshipToOwner="XPath;//select[@name='plan.beneficiaries["+i+"].relationship']";
                string txtPercentage="XPath;//input[@name='plan.beneficiaries["+i+"].percentage']";
                string txtAddressLine1="XPath;//input[@name='plan.beneficiaries["+i+"].mailingAddress.addressLine1']";
                string txtCity="XPath;//input[@name='plan.beneficiaries["+i+"].mailingAddress.city']";
                string dropdownCountry="XPath;//select[@name='plan.beneficiaries["+i+"].mailingAddress.country']";
                string dropdownState="XPath;//select[@name='plan.beneficiaries["+i+"].mailingAddress.state']";
                string txtZipCode="XPath;//input[@name='plan.beneficiaries["+i+"].mailingAddress.zipCode']";
                ran1=appHandle.CreateRamdomData(FieldType.NUMERIC,100,999).ToString();
                ran2=appHandle.CreateRamdomData(FieldType.NUMERIC,10,99).ToString();
                ran3=appHandle.CreateRamdomData(FieldType.NUMERIC,1000,9999).ToString();
                taxid=ran1+"-"+ran2+"-"+ran3;
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonContinue);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownType,"PRIMARY");
                appHandle.Set_field_value(txtnameobj,"Test"+ran1);
                appHandle.Set_field_value(txtTaxid,taxid);
                appHandle.Set_field_value(txtDOB,dob);
                if (!string.IsNullOrEmpty(relationship))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownRelationshipToOwner,relationship);
                }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownRelationshipToOwner,"Trust");
                }
                                
                if(evennbrflg==true)
                {
                    appHandle.Set_field_value(txtPercentage,wper+"");
                }
                else
                {
                    if(i==(numberofbeneficiary-1))
                    {
                        wper=wper+1;
                        appHandle.Set_field_value(txtPercentage,wper+"");

                    }
                    else
                    {    
                        appHandle.Set_field_value(txtPercentage,wper+"");
                    }
                }
                
                appHandle.Set_field_value(txtAddressLine1,"Central Park");
                appHandle.Set_field_value(txtCity,"Malvern");
                appHandle.SelectDropdownSpecifiedValue(dropdownCountry,"US - UNITED STATES OF AMERICA");
                appHandle.SelectDropdownSpecifiedValue(dropdownState,"PA - PENNSYLVANIA");
                appHandle.Set_field_value(txtZipCode,"15047");

            }
        }

    }
}
