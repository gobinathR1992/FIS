using System;
using GTS_OSAF.CoreLibs;

using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class BankingCenterPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tabAppicationService = "Xpath;//td[contains(text(),'Application Services')]";
        public static string lnkApplicationManagement = "Xpath; //td[contains(text(),'Application Management')]";
        public static string CreateAccountLink = "Xpath;//td[contains(text(),'Create Account')]";
        public static string CreateCorpCustLink = "Xpath;//td[contains(text(),'Create Corporate Customer')]";
        public static string CreatePersCustLink = "Xpath;//td[contains(text(),'Create Personal Customer')]";
        public static string CreateRetirementAccLink = "Xpath;//td[contains(text(),'Create Retirement Account')]";
        public static string CreateRetirementPlanLink = "Xpath;//td[contains(text(),'Create Retirement Plan')]";
        public static string CreateTrustCustLink = "Xpath;//td[contains(text(),'Create Trust Customer')]";
        public static string CustomerSearchLink = "Xpath;//td[contains(text(),'Customer Search')]";
        public static string CardServicesLink = "Xpath;//td[contains(text(),'Card Services')]";
        public static string CardServiceAuthLink = "Xpath;//td[contains(text(),'Authorizations')]";
        public static string CardServiceDisputedTransactionLink = "Xpath;//td[contains(text(),'Disputed Transactions')]";
        public static string CardServicePayoffQuoteLink = "Xpath;//td[contains(text(),'Payoff Quote')]";
        public static string LogoutButton = "Name;logout";
        public static string CustServicesLink = "Xpath;//td[contains(text(),'Customer Services')]";
        public static string CustServiceAlertManagementLink = "Xpath;//td[contains(text(),'Alert Management')]";
        public static string CustServiceAvgBalLink = "Xpath;//td[contains(text(),'Average Balances')]";
        public static string CustServiceBeneficaryLink = "Xpath;//tr[@id='s11']//td[contains(text(), 'Beneficiaries')]";
        public static string CustServiceCommericalRelLInk = "Xpath;//td[contains(text(),'Commercial Relationship')]";
        public static string CustServiceInformationLink = "Xpath;//td[contains(text(),'Customer Information'))]";
        public static string CustServiceProfileLink = "Xpath;//td[contains(text(),'Customer Profile')]";
        public static string CustServiceSettlementInstrucLink = "Xpath;//td[contains(text(),'Customer Settlement Instructions')]";
        public static string CustServiceVerificationLink = "Xpath;//td[contains(text(),'Customer Verification')]";
        public static string CustServiceFutureDatedMaintenanceLink = "Xpath;//tr[@id='s11']//td[contains(text(),'Future-Dated Maintenance')]";
        public static string CustServiceHistoryLink = "//tr[@id='s11']//td[contains(text(), 'History')]";
        public static string CustServiceNotesLink = "//tr[@id='s11']//td[contains(text(), 'Notes')]";
        public static string CustServiceFinancialManagementLink = "Xpath;//td[contains(text(),'Personal Financial Management')]";
        public static string CustServicesRemindersLink = "Xpath;//tr[@id='s11']//td[contains(text(),'Reminders')]";
        public static string CustServiceRestrictionsLink = "Xapth;//tr[@id='s11']//td[contains(text(),'Restrictions')]";
        public static string CustServiceManagementLink = "Xpath;//td[contains(text(),'Service Management')]";
        public static string CustServiceStatementGroupLink = "Xpath;//td[contains(text(),'Statement Groups')]";
        public static string CustServiceStopsLink = "Xpath;//tr[@id='s11']//td[contains(text(),'Stops')]";
        public static string DepositAccServiceLink = "Xpath;//td[contains(text(),'Deposit Account Services')]";
        public static string DepositAccServiceAccInformationLink = "Xpath;//tr[@id='s6']//td[contains(text(),'Account Information')]";
        public static string DepositAccServiceCommercialLink = "Xpath;//td[contains(text(),'Combined Commercial Analysis')]";
        public static string DepositAccServiceEFDRateChangeLink = "Xpath;//tr[@id='s6']//td[contains(text(),'EFD Rate Change')]";
        public static string DepositAccServiceInvestmentSummaryLink = "Xpath;//td[contains(text(),'Investment Sweep Summary')]";
        public static string DepositAccServiceInvestmentSweepLink = "Xpath;//td[text() = 'Investment Sweep')]";
        public static string DepositAccServiceIRS1042ReportCorrectionLink = "Xpath;//td[contains(text(),'IRS 1042-S Reporting Correction')]";
        public static string DepositAccServiceLoanPaymentSweepLink = "Xpath;//td[contains(text(),'Loan Payment Sweep')]";
        public static string DepositAccServiceOverDraftProtectionLink = "Xpath;//td[contains(text(),'Overdraft Protection')]";
        public static string DepositAccServiceProductTrnasferLink = "Xpath;//td[contains(text(),'Product Transfer')]";
        public static string DepositAccServiceRedemptionQuoteLink = "Xpath;//td[contains(text(),'Redemption Quote')]";
        public static string DepositAccServiceTBACAHierarchyLink = "Xpath;//td[contains(text(),'TBA and CA Hierarchy')]";
        public static string DepositAccServiceTBACALinkageLink = "Xpath;//td[contains(text(),'TBA and CA Linkage')]";
        public static string IRSFormsLink = "Xpath;//td[contains(text(),'IRS Forms')]";
        public static string IRSForm_8966ReportingCorrectionLink = "Xpath;//td[contains(text(),'Form 8966 Reporting Correction')]";
        public static string FundingServicesLink = "Xpath;//td[contains(text(),'Funding Services')]";
        public static string FundingServiceCommitmentPaymentLink = "Xpath;//td[contains(text(),'Commitment Mass Payment')]";
        public static string FundingServiceDebitAuthLink = "Xpath;//td[contains(text(),'Debit Authorization')]";
        public static string FundingServiceExternalAccountsLink = "Xpath;//td[contains(text(),'External Accounts')]";
        public static string FundingServiceMissPaymentLink = "Xpath;//td[contains(text(),'Match/Miss Payment')]";
        public static string FundingServicePendingTransferLink = "Xpath;//td[contains(text(),'Pending Transfers')]";
        public static string FundingServiceTransferFundLink = "Xpath;//td[contains(text(),'Transfer Funds')]";
        public static string GeneralAccServicesTab = "Xpath;//td[contains(text(),'General Account Services')]";
        public static string GeneralAccServiceAccClosureLink = "Xpath;//td[contains(text(),'Account Closure Utility')]";
        public static string GeneralAccServiceAccHistoryLink = "Xpath;//td[contains(text(),'Account History')]";
        public static string GeneralAccServiceAccListLink = "Xpath;//td[contains(text(),'Account History')]";
        public static string GeneralAccServicesAccountVerificationLink = "Xpath;//td[contains(text(),'Account Verification')]";
        public static string GeneralAccServiceAnticipatedAccrualLink = "Xpath;//td[contains(text(),'Actual/Anticipated Accrual')]";
        public static string GeneralAccServiceBeneficiariesLink = "Xpath;//tr[@id='s4']//td[contains(text(),'Beneficiaries')]";
        public static string GeneralAccServiceCardManagementLink = "Xpath;//tr[@id='s4']//td[contains(text(),'Card Management')]";
        public static string GeneralAccServiceCheckHoldCorrectionLink = "Xpath;//td[contains(text(),'Check/Float Hold Corrections')]";
        public static string GeneralAccServiceCustomerHomeLink = "Xpath;//tr[@id='s4']//td[contains(text(),'Customer Home')]";
        public static string GeneralAccServiceFutureDatedMainLink = "Xpath;//tr[@id='s4']//td[contains(text(),'Future-Dated Maintenance')]";
        public static string GeneralAccServiceHoldsLink = "Xpath;//td[contains(text(),'Holds')]";
        public static string GeneralAccServiceInterestChangeSummary = "Xpath;//td[contains(text(),'Interest Change Summary')]";
        public static string GeneralAccServiceNotesLink = "Xpath;//tr[@id='s4']//td[contains(text(),'Notes')]";
        public static string GeneralAccServiceRelationshipsLink = "Xpath;//td[contains(text(),'Relationships')]";
        public static string GeneralAccServiceRemindersLink = "Xpath;//tr[@id='s4']//td[contains(text(),'Reminders')]";
        public static string GeneralAccServiceRestrictionsLink = "Xpath;//tr[@id='s4']//td[contains(text(),'Restrictions')]";
        public static string GeneralAccServiceStopsLink = "Xpath;//tr[@id='s4']//td[contains(text(),'Stops')]";
        public static string GeneralAccServiceTranscationDisputesLink = "Xpath;//tr[@id='s4']//td[contains(text(),'Transaction Disputes')]";
        public static string LoanAccServicesLink = "Xpath;//td[contains(text(),'Loan Account Services')]";
        public static string LoanAccServiceAccInformationLink = "Xpath;//tr[@id='s7']//td[contains(text(),'Account Information')]";
        public static string LoanAccServiceAutomaticLoanPaymentLink = "Xpath;//td[contains(text(),'Automatic Loan Payments')]";
        public static string LoanAccServiceCreditReportingCorrectionLink = "Xpath;//td[contains(text(),'Credit Reporting Corrections')]";
        public static string LoanAccServiceEFDRateChangeLink = "Xpath;//tr[@id='s7']//td[contains(text(),'EFD Rate Change')]";
        public static string LoanAccServiceLoanChargeOffLink = "Xpath;//td[contains(text(),'Loan Charge-Off')]";
        public static string LoanAccServiceLoanCorrectionsLink = "Xpath;//td[contains(text(),'Loan Corrections')]";
        public static string LoanAccServiceNewLoanProjectionLink = "Xpath;//td[contains(text(),'New Loan Projection')]";
        public static string LoanAccServicePaymentChangeLink = "Xpath;//td[contains(text(),'Payment Change')]";
        public static string LoanAccServicePayOff = "Xpath;//tr[@id='s7']//td[contains(text(),'Payoff')]";
        public static string LoanAccServiceProjectedActivityLink = "Xpath;//td[contains(text(),'Projected Activity')]";
        public static string LoanAccServiceProjectedSundryLink = "Xpath;//td[contains(text(),'Projected Sundry Summary')]";
        public static string LoanAccServiceRenewalApprovalLink = "Xpath;//td[contains(text(),'Renewal Option Approval')]";
        public static string LoanAccServiceRenewalOptionLink = "Xpath;//td[contains(text(),'Renewal Options')]";
        public static string LoanAccServicePurchasedImpairedLoanLInk = "Xpath;//td[contains(text(),'Purchased Impaired Loans')]";
        public static string MemberCenterLink = "Xpath;//td[contains(text(),'Message Center')]";
        public static string MemberCenterOpenItemsLink = "Xpath;//td[contains(text(),'Open Items')]";
        public static string MemberCenterClosedItemsLink = "Xpath;//td[contains(text(),'Closed Items')]";
        public static string MemberCenterSearchLink = "Xpath;//tr[@id='s3']//td[contains(text(),'Search')]";
        public static string PaymentServiceLink = "Xpath;//td[contains(text(),'Payment Services')]";
        public static string PaymentServiceDomesticPaymentCust = "Xpath;//td[contains(text(),'Domestic Payments - Customer')]";
        public static string PaymentServiceDomesticPaymentGL = "Xpath;//td[contains(text(),'Domestic Payments - G/L')]";
        public static string PaymentServiceForeignPaymentCust = "Xpath;//td[contains(text(),'Foreign Payments - Customer')]";
        public static string PaymentServiceForeignPaymentGL = "Xpath;//td[contains(text(),'Foreign Payments - G/L')]";
        public static string PoolingArrangementsLink = "Xpath;//td[contains(text(),'Pooling Arrangements')]";
        public static string PoolingArrangementCreateIntPoolLink = "Xpath;//td[contains(text(),'Create Interest Pool')]";
        public static string PoolingArrangementIntPoolInformationLink = "Xpath;//td[contains(text(),'Interest Pool Information')]";
        public static string PoolingArrangementIntPoolExceptionsLink = "Xpath;//td[contains(text(),'Interest Pool Exceptions')]";
        public static string PoolingArrangementCreateBalancePoolLink = "Xpath;//td[contains(text(),'Create Balance Pool')]";
        public static string RetirementServicesLink = "Xpath;//td[contains(text(),'Retirement Services')]";
        public static string RetirementServiceBeneficiariesLink = "Xpath;//tr[@id='s8']//td[contains(text(),'Beneficiaries')]";
        public static string RetirementServiceFutureDatedMaintenanceLink = "Xpath;//tr[@id='s8']//td[contains(text(),'Future-Dated Maintenance')]";
        public static string RetirementServiceMADModelerLink = "Xpath;//td[contains(text(),'MAD Modeler')]";
        public static string RetirementServicePlanInformationLink = "Xpath;//td[contains(text(),'Plan Information')]";
        public static string RetirementServiceRestrictionsLink = "Xpath;//tr[@id='s8']//td[contains(text(),'Restrictions')]";
        public static string RetirementServiceTaxYearDetailLink = "Xpath;//td[contains(text(),'Tax Year Detail')]";
        public static string RetirementServiceTransactionCorrectionLink = "Xpath;//td[contains(text(),'Transaction Corrections')]";
        public static string SEPACreditTransferLink = "Xpath;//td[contains(text(),'SEPA Credit Transfer')]";
        public static string SEPACreditIncomingSCTCustLink = "Xpath;//td[contains(text(),'Incoming SCT - Customer')]";
        public static string SEPACreditIncomingSCTGLink = "Xpath;//td[contains(text(),'Incoming SCT - G/L')]";
        public static string SEPACreditOneTimeOutgoingSCTLink = "Xpath;//td[contains(text(),'One-Time Outgoing SCT')]";
        public static string SEPACreditRecurringOutgoingSCTLink = "Xpath;//td[contains(text(),'Recurring Outgoing SCT')]";
        public static string SEPACreditRejectedOutgoingCreditTransferLink = "Xpath;//td[contains(text(),'Rejected Outgoing Credit Transfers')]";
        public static string SEPACreditReturnedOutgoingCreditTransferLink = "Xpath;//td[contains(text(),'Returned Outgoing Credit Transfers')]";
        public static string SEPADirectDebitLink = "Xpath;//td[contains(text(),'SEPA Direct Debit')]";
        public static string SEPADirectDebitIncomingSDDCustLink = "Xpath;//td[contains(text(),'Incoming SDD - Customer')]";
        public static string SEPADirectDebitIncomingSDDGLLink = "Xpath;//td[contains(text(),'Incoming SDD - G/L')]";
        public static string SEPADirectDebitReceivedRTranscationsLink = "Xpath;//td[contains(text(),'Received R-Transactions')]";
        public static string UtilitiesLink = "Xpath;//td[contains(text(),'Utilities')]";
        public static string UtilitiesActivitySummaryLink = "Xpath;//td[contains(text(),'Activity Summary')]";
        public static string UtilitiesCheckItemAssignmentLink = "Xpath;//td[contains(text(),'Check Item Assignment')]";
        public static string UtilitiesCollectionsQueueLink = "Xpath;//td[contains(text(),'Collections Queue')]";
        public static string UtilitiesDepositCalculatorLink = "Xpath;//td[contains(text(),'Deposit Calculator')]";
        public static string UtilitiesEscrowRemittanceUpdateLink = "Xpath;//td[contains(text(),'Escrow Remittance Update')]";
        public static string UtilitiesExceptionProcessingLink = "Xpath;//td[contains(text(),'Escrow Remittance Update')]";
        public static string UtilitiesInterestCalculatorLink = "Xpath;//td[contains(text(),'Interest Calculator')]";
        public static string UtilitiesInterestIndexSummaryLink = "Xpath;//td[contains(text(),'Interest Index Summary')]";
        public static string UtilitiesInvestorLink = "Xpath;//td[contains(text(),'Investor')]";
        public static string UtilitiesInvestorLoanSalePoolsLink = "Xpath;//td[contains(text(),'Investor Loan Sale Pools')]";
        public static string UtilitiesInvestorLoanSaleGroupsLink = "Xpath;//td[contains(text(),'Investor Loan Sale Groups')]";
        public static string UtilitiesLoanCalculatorLink = "Xpath;//td[contains(text(),'Loan Calculator')]";
        public static string UtilitiesRateScheduleSummaryLink = "Xpath;//td[contains(text(),'Rate Schedule Summary')]";
        public static string UtilitiesRegulationCCExceptionInquiryLink = "Xpath;//td[contains(text(),'Regulation CC Exception Inquiry')]";
        public static string UtilitiesServiceItemAssignmentLink = "Xpath;//td[contains(text(),'Service Item Assignment')]";
        public static string UtilitiesTransferAccountsLink = "Xpath;//td[contains(text(),'Transfer Accounts')]";
        public static string AccountDetailDropDown = "Name;accountNumber";
        public static string BankingCenterTable = "Xpath;//table[@id='header']";
        public static string DepositAccountServicesTab = "Xpath;//a[contains(text(),'Deposit Account Services')]";



        /// <summary>
        /// This method is used to select Domestic Payments Customer link
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.BankingCenterPage.selectPaymentServicesDomesticPaymentsCustomerLink();
        /// </example>
        public virtual void selectPaymentServicesDomesticPaymentsCustomerLink()
        {
            try
            {
                appHandle.WaitUntilElementVisible(PaymentServiceLink);
                appHandle.Select_link(PaymentServiceLink);
                appHandle.WaitUntilElementVisible(PaymentServiceDomesticPaymentCust);
                appHandle.WaitUntilElementClickable(PaymentServiceDomesticPaymentCust);
                appHandle.Select_link(PaymentServiceDomesticPaymentCust);
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged: " + e);
            }
        }
        
        public virtual void ClickLinkFromMenuItem(string MenuNameLinkNameDelimitedByPipe)
        {
            string[] arr = MenuNameLinkNameDelimitedByPipe.Split('|');
            string MenuName = arr[0].Trim();
            string LinkName = arr[1].Trim();

            string desc = appHandle.GetSpecifiedObjectAttribute("XPath;//*[contains(text(),'" + MenuName + "')]/ancestor::*/following-sibling::*[@class='subMenu'][1]", "style");
            string DynamicLinkObj = "XPath;//*[contains(text(),'" + MenuName + "')]/ancestor::*/following-sibling::*[@class='subMenu'][1]/descendant::*[contains(text(),'" + LinkName + "')][1]";
            string MenuLinkObj = "XPath;//*[@class='menuGroupHeading']/descendant::*[contains(text(),'" + MenuName + "')]";

            if (string.IsNullOrEmpty(desc))
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(DynamicLinkObj);
                appHandle.ClickObjectViaJavaScript(DynamicLinkObj);
                            }
            else
            {
                appHandle.ClickObjectViaJavaScript(MenuLinkObj);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(DynamicLinkObj);
                appHandle.ClickObjectViaJavaScript(DynamicLinkObj);
            }
        }

    }

}