
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanRevolvingOptionsPage
    {
        public static string txtRevolvingCreditMinimumFinanceCharge = "XPath;//input[@name='LN_MFCB']";
    }
}