using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
//using Profile7Automation.Extended;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class ExternalAccountsPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string buttonAdd="XPath;//input[@name='add']";
        public static string txtRoutingNumber="XPath;//input[@name='CIFEXTREG_EXTINST']";
        public static string txtAccountNumber="XPath;//input[@name='CIFEXTREG_EXTACCT']";
        public static string dropdownType="XPath;//select[@name='CIFEXTREG_EXTACCTP']";
        public static string txtOwner="XPath;//input[@name='CIFEXTREG_BENNAME']";
        public static string buttonSubmit="XPath;//input[@name='submit']";


        public virtual string AddExternalAccount(string routingnumber,string accountTypeValue)
        {
            string ownername=StartupConfiguration.EnvironmentDetails.GLOBAL_USER_NAME;
            string externalaccount=appHandle.CreateRamdomData(FieldType.NUMERIC,111,999999999).ToString();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtAccountNumber);
            appHandle.Set_field_value(txtAccountNumber,externalaccount);
            appHandle.Set_field_value(txtRoutingNumber,routingnumber);
            appHandle.SelectDropdownSpecifiedValue(dropdownType,accountTypeValue);
            appHandle.Set_field_value(txtOwner,ownername);
            Report.Info("The External Account Details are added successfully","ext","True",appHandle);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage(Data.Get("SuccessMsgExternalAccount")))
            {
                Report.Pass("The External Account is added successfully","exty","True",appHandle);

            }
            else
            {
                Report.Fail("The External Account is not added","extp","True",appHandle);
            }
            return externalaccount;

        }
        public virtual void ClickOnAddButton()
        {
            appHandle.WaitUntilElementExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
        }






    }

}
