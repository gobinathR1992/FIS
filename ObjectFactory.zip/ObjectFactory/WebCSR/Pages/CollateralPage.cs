using GTS_OSAF.CoreLibs;


namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CollateralPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string tblCollateralActionBody = "Xpath;//table[@class='ledgerScrollable dataTable no-footer']/tbody";
        public static string tblCollateralActionHeader = "Xpath;//div[@class='dataTables_scrollHeadInner']//table[@class='ledgerScrollable dataTable no-footer']/thead";

        public static string drpCollateralType = "name;collateralCode";
        public static string txtVehicleMake = "name;make";
        public static string drpVehicleCurrencyCode = "name;currencyCode";
        public static string txtVehicleCurrentValue = "name;currentValue";
        public static string cbkPledgedAmountsMayBeReleased = "name;mayBeReleased";

    }
}
