using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs; 
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class BillingStatementDetailPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tblPrincipalBillingStatementDetail = "XPath;//table[@id='detail-list']";

    
    public virtual bool  VerifyBillInterestDataInTableByColumnValues(string sLabelNameLabelValuePipeDelimited)
         {
             bool Result = false;
            if (Profile7CommonLibrary.VerifyDataInTableByColumnValues(sLabelNameLabelValuePipeDelimited))
            {
                Result = true;
            }
            return Result;
   

         }
}
}