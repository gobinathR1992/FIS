using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DomesticPaymentPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string DomesticPaymentAccountDropDown = "XPath;//*[contains(text(),'Account')]/following-sibling::*/descendant::Select";
        public static string DomesticPaymentAddButton = "XPath;//*[contains(@name,'selectPaymentType')]";
        private static string tableListOfOrders = "XPath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";
        private static string dropdownPaymentType = "XPath;//*[contains(text(),'Payment Type')]/following-sibling::*/descendant::select";
        private static string buttonDelete = "XPath;//*[@value='Delete']";
        private static string buttonEdit="XPath;//*[@value='Edit']";
        /// <summary>
        /// This method is used to select account from dropdown
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DomesticPaymentPage.selectAccountFromDropDown();
        /// </example>    
        public virtual void selectAccountFromDropDown(string account)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DomesticPaymentAccountDropDown))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DomesticPaymentAccountDropDown, account);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(DomesticPaymentAddButton);
            }

        }
        /// <summary>
        /// This method is used to click on add button
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DomesticPaymentPage.clickonAddButton();
        /// </example>
        public virtual void clickonAddButton()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DomesticPaymentAddButton))
            {
                appHandle.ClickObjectViaJavaScript(DomesticPaymentAddButton);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownPaymentType);
            }

        }
        public virtual bool VerifyDomesticPaymentsCustomerPageLoads()
        {
            bool Result = false;

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DomesticPaymentAccountDropDown))
            {
                Result = true;
            }

            return Result;
        }
       
        public virtual void ClickOnDeleteButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonDelete))
            {
                appHandle.ClickObjectViaJavaScript(buttonDelete);

            }
        }
        public virtual void SelectOrderInPayListOrder(string UniqueOrderRefValue)
        {
            appHandle.SelectRadioButtonInTable(tableListOfOrders, UniqueOrderRefValue);
            
        }

        public virtual string GetStatusFromOrdersTable(string orderdetails)
        {
            string Status=appHandle.GetSpecifiedDataAvailableInTable(orderdetails,tableListOfOrders);
            return Status;
        }
        public virtual void ClickOnEditButton()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
            }
        }
        public virtual bool VerifyPaymentOrderIsNotGenerated(string UniqueOrderRefValue)
        {
            bool Result = false;
            if (appHandle.CheckObjectNotExist(tableListOfOrders,UniqueOrderRefValue) )
            {
                Result =true;
            }
            return Result;

        }
        
    }
}