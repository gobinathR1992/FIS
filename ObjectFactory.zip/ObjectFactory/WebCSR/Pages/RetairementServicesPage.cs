using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class RetairementServicesPage
    { 
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string drpPlanOptionRetirementPlan = "Xpath;//select[@name='sequence']";
        private static string DropdownRetairementPlan = "Xpath;//select[@name='DEP_RPASEQ']";
        private static string CheckboxWithholdingIndicator="Xpath;//input[@name='IRATYPE_RSPWIND']";
        private static string txtFederalWithholdingPercentage="Xpath;//input[@name='IRATYPE_WTHPCT']";
        private static string txtStateWithholdingPercentage="Xpath;//input[@name='IRATYPE_STWHPCT']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string dropdownStateIdentification="Xpath;//*[@name='IRATYPE_STPLNID']";
        private static string dropdownFederalwithholdingCalcMethod = "Xpath;//select[@name='IRATYPE_RSPWCALC']";
        private static string dropdownFederalwithholdingSchedule = "Xpath;//select[@name='IRATYPE_RSPWSCH']";
        private static string txtFederalwithholdingFixedAmt = "Xpath;//input[@name='IRATYPE_WTHAMT']";
        private static string dropdownStatewithholdingCalcMethod = "Xpath;//select[@name='IRATYPE_STWHCALC']";
        private static string dropdownStatewithholdingSchedule = "Xpath;//select[@name='IRATYPE_STWHSCH']";
        private static string txtStatewithholdingFixedAmt = "Xpath;//input[@name='IRATYPE_STWHAMT']";
        private static string CheckboxFileComplete="Xpath;//input[@name='fileComplete']";
        public virtual void SelectRetirementPlanDropdown(string RetirementPlan)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownRetairementPlan, RetirementPlan);
        }
        public virtual void EnterWitholdingOptionsDetails(bool WitholdingIndicatorONorOFF,string FederalWithholdingPer ="", string StateWithholdingPer= "",string FedWitholdingCalcMethod="",string FedWitholdingSchedule="",string FedWitholdingFixedAmt="",string StatWitholdingCalcMethod="",string StatWitholdingSchedule="",string StatWitholdingFixedAmt="")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(CheckboxWithholdingIndicator))
            {
               
                    bool Result = false;
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(CheckboxWithholdingIndicator))
                    {
                    if (WitholdingIndicatorONorOFF)
                    {
                    if (appHandle.CheckCheckBoxChecked(CheckboxWithholdingIndicator)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(CheckboxWithholdingIndicator);
                        if (appHandle.CheckCheckBoxChecked(CheckboxWithholdingIndicator))
                        { Result = true; }

                    }
                    }
                    else
                    {
                    if (appHandle.CheckCheckBoxChecked(CheckboxWithholdingIndicator) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(CheckboxWithholdingIndicator);
                        if (appHandle.CheckCheckBoxChecked(CheckboxWithholdingIndicator) == false) { Result = true; }
                    }
                    }
                    }
                
                
                int fedwithholdingperlength = appHandle.GetLengthOfText(txtFederalWithholdingPercentage);
                for(int i=0;i<=fedwithholdingperlength-1;i++)
                {
                    appHandle.SendKeyStroke(txtFederalWithholdingPercentage, InputKey.Backspace);
                }
                appHandle.Set_field_value(txtFederalWithholdingPercentage,FederalWithholdingPer);
                                
                if(!string.IsNullOrEmpty(StateWithholdingPer))
                {
                    appHandle.Set_field_value(txtStateWithholdingPercentage,StateWithholdingPer);
                }

                if(!string.IsNullOrEmpty(FedWitholdingCalcMethod))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownFederalwithholdingCalcMethod,FedWitholdingCalcMethod);
                }
                 if(!string.IsNullOrEmpty(FedWitholdingSchedule))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownFederalwithholdingSchedule,FedWitholdingSchedule);
                }
                if(!string.IsNullOrEmpty(FedWitholdingFixedAmt))
                {
                    appHandle.Set_field_value(txtFederalwithholdingFixedAmt,FedWitholdingFixedAmt);
                }
                 if(!string.IsNullOrEmpty(StatWitholdingCalcMethod))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownStatewithholdingCalcMethod,StatWitholdingCalcMethod);
                }
                if(!string.IsNullOrEmpty(StatWitholdingSchedule))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownStatewithholdingSchedule,StatWitholdingSchedule);
                }
                 if(!string.IsNullOrEmpty(StatWitholdingFixedAmt))
                {
                    appHandle.Set_field_value(txtStateWithholdingPercentage,StatWitholdingFixedAmt);
                }
            }  
            
        }
        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }
        public virtual bool VerifyMessageAccountInformationResidencyPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void UpdateWitholdingOptionsDetails(string FederalWithholdingPer ="", string StateID="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(CheckboxWithholdingIndicator);
            appHandle.DeSelectCheckBox(CheckboxWithholdingIndicator);
            appHandle.Set_field_value(txtFederalWithholdingPercentage,FederalWithholdingPer);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownStateIdentification,StateID);

        }
        
        public virtual void EnterDetailsWitholdingOptions(bool filecompleteOnorOff=false)
        {
            if(filecompleteOnorOff == true)
                {
                    bool Result = false;
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(CheckboxFileComplete))
                    {
                    if (filecompleteOnorOff)
                    {
                    if (appHandle.CheckCheckBoxChecked(CheckboxFileComplete)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(CheckboxFileComplete);
                        if (appHandle.CheckCheckBoxChecked(CheckboxFileComplete))
                        { Result = true; }

                    }
                    }
                    else
                    {
                    if (appHandle.CheckCheckBoxChecked(CheckboxFileComplete) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(CheckboxFileComplete);
                        if (appHandle.CheckCheckBoxChecked(CheckboxFileComplete) == false) { Result = true; }
                    }
                    
                    }
                }
                               
            }  
            
        }

         public virtual void SelectRetirementPlan(string RetirementPlan)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpPlanOptionRetirementPlan, RetirementPlan);
        }


    }
}