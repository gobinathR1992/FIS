using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CustomerAccountsCreatedPage
    {
        static WebApplication appHandle;
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        public static string tblAccountNumber = "//table[@class='contentTable']//h2[text()='Packages']/../../../..";

        private static string AccountNumber = "Xpath;.//*[@class='fieldLabel'][contains(.,'Account Number')]/following-sibling::td";

        /// <summary>
        /// This method is get all accounts numbers.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.CustomerAccountsCreatedPage.GetAccountNumbers();
        /// </example>
        //public virtual List<string> GetAccountNumbers()
        public virtual List<string> GetAccountNumbers()
        {
            List<string> accNumbers = null;
            //accNumbers = appHandle.GetLabelText(AccountNumber); 
            return accNumbers;
        }

        /// <summary>
        /// To get account Numbers by Index for Different Products.
        /// <param name="List<string> lstProducts"></param>
        /// lstProducts.Add("SAV1169;2");
        /// lstProducts.Add("CD Product 2608;2");
        /// <returns "List of Account Numbers"></returns>
        /// <example>List<string> AccNumbers = GetAccountNumbersbyIndexforDiffProds(lstProducts)</example>
        public virtual List<string> GetAccountNumbersbyIndexforDiffProds(List<string> lstProducts)
        {
            List<string> AccNumbers = new List<string>();
            try
            {
                for (int j = 0; j < lstProducts.Count; j++)
                {
                    string[] arrDetails = new string[3];
                    arrDetails = AppHandle.SplitString(lstProducts[j], ";");
                    for (int i = 1; i <= Int32.Parse(arrDetails[1]); i++)
                    {
                        string obj = "Xpath;((//h2[contains(text(),'" + arrDetails[0] + "')])[" + i.ToString() + "]/parent::td/parent::tr/following-sibling::tr//td[contains(text(),'Account Number')])[1]/following-sibling::td[@class='data']";
                        string AccNumber = AppHandle.GetLabelText(obj);
                        AccNumbers.Add(arrDetails[0] + "-" + AccNumber);
                    }
                }

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return AccNumbers;
        }

    }
}