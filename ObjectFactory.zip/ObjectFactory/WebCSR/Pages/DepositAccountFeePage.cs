using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs; 
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.Reporter;

 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class DepositAccountFeePage
    { 
         static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

         private static string tableExceptionItemProcessing="Xpath;//*[@id='exception-items-list']/tbody";
         private static string drpAccountno="Xpath;//*[@name='ACN_CID']";
         private static string drpPlan="XPath;//*[@name='DEP_FEEPLN']";
         private static string buttonSubmit ="Xpath;//*[@name='submit']";
         private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
          private static string drpdownServiceFeeOption = "Xpath;//*[@name='DEP_FEEOPT']";
         private static string txtServiceFeeFrquency = "Xpath;//*[@name='DEP_SCFRE']";
         private static string txtfrequency = "Xpath;//input[@name='DEP_SCFRE']";
         private static string drpfeeoption = "Xpath;//select[@name='DEP_FEEOPT']";
         private static string txtItemPaidMaxDailyFee = "Xpath;//input[@name='DEP_PDMXFEE']";
         private static string  txtItemRetMaxDailyFee= "Xpath;//input[@name='ACN_RETMXFEE']";


         public virtual bool  VerifyDataInTableByColumnValues(string sLabelNameLabelValuePipeDelimited,string itempaid="",string itemreturned = "")
         {
             bool Result = false;
            if (Profile7CommonLibrary.VerifyDataInTableByColumnValues(sLabelNameLabelValuePipeDelimited))
            {
                Result = true;
            }
            if(appHandle.GetObjectText(txtItemPaidMaxDailyFee).Contains(itempaid) || appHandle.GetObjectText(txtItemRetMaxDailyFee).Contains(itemreturned))
            {
                Result = true;
            }
            return Result;
   

         }
         public virtual void UpdateFeePlan(string PlanType)
         {
            appHandle.WaitUntilElementExists(drpPlan);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpPlan,PlanType);
            Report.Pass("The Fee Plan was Updated successfully In Deposit Fee Page", "FeePage", "true", appHandle);
         }
         public virtual void ClickOnSubmit()
         {
             appHandle.WaitUntilElementExists(buttonSubmit);
             appHandle.ClickObjectViaJavaScript(buttonSubmit);
             
         }
         public virtual bool VerifyMessageDepositFeePage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void UpdateServiceFeeOption(string FeeOption,string FeeFrequency="")
        {
            appHandle.WaitUntilElementExists(drpdownServiceFeeOption);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownServiceFeeOption,FeeFrequency);
           
            appHandle.Set_field_value(txtServiceFeeFrquency,FeeOption);
            appHandle.Wait_For_Specified_Time(5);
        }





    }
}