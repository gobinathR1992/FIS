using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DepositAccountProductTransferPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpAccount="Xpath;//select[@name='ACN_CID']";
        public static string drpToAccount="Xpath;//select[@name='ACN_TYPE']";
        public static string txtDEPProductTransferMsg="Xpath;//td[contains(text(),'Deposit Account Product Transfer')]";
   

        /// <summary>
        /// This method is used to select Account From AccountDropdown
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DepositAccountProductTransferPage.selectAccountFromDropdown();
        /// </example>
        public virtual void selectAccountFromDropdown(string accName)
        {
            try
            {
                appHandle.WaitUntilElementVisible(drpAccount);
                appHandle.SelectDropdownSpecifiedValue(drpAccount, accName);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }


        //Method for Navigated to the Deposit Account Product Transfer page.
        public virtual bool ConfirmDepositProductTransferPage()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirmed the Product Transfer page");
            bool blnSuccess = false;
            if (appHandle.CheckObjectExist(txtDEPProductTransferMsg))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }

    }
}