using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages

{
    public class DepositRateDeterminationPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtRateDeterminationInterestRate = "XPath;//input[@name='ACN_IRN']";
        private static string txtAnnualYield = "Xpath;//*[@class='fieldLabel'][contains(.,'Annual Yield')]/following-sibling::td";
        private static string dropdownVariableRateIndex = "Xpath;//select[@name = 'ACN_INDEX']";
        private static string txtInterestChangeFrequency = "Xpath;//input[@name = 'ACN_INTFRE']";
        private static string txtInterestChangeLastDate = "Xpath;//input[@name = 'ACN_ICHLD']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string dropdownInterestMatrix = "Xpath;//select[@name = 'ACN_INTMAT']";


        public virtual bool WaitUntilDepositInterestPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtRateDeterminationInterestRate))
            {
                result = true;
            }

            return result;

        }

        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage, 5);
        }
        public virtual bool VerifyMessageDepositRateDeterminationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void EnterInterestPageOptions(string InterestRate = "", string VarInterestIndex = "", string VarChangeFreq = " ", string IndexLastdate = "", string VarRateMatrix = " ")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtRateDeterminationInterestRate))
            {
                if (!string.IsNullOrEmpty(InterestRate))
                {
                    appHandle.Set_field_value(txtRateDeterminationInterestRate, InterestRate);
                }
                if (!string.IsNullOrEmpty(VarInterestIndex))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownVariableRateIndex, VarInterestIndex);
                }
                if (!string.IsNullOrEmpty(IndexLastdate))
                {
                    appHandle.Set_field_value(txtInterestChangeLastDate, IndexLastdate);
                }
                if (!string.IsNullOrEmpty(VarChangeFreq))
                {
                    appHandle.Set_field_value(txtInterestChangeFrequency, VarChangeFreq);
                    appHandle.WaitForSpecifiedTime(5);
                }
                if (!string.IsNullOrEmpty(VarRateMatrix))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownInterestMatrix, VarRateMatrix);
                }
            }
        }
        public virtual void getInterestRate(string ROI)
        {
            appHandle.GetEditFieldValue(txtRateDeterminationInterestRate);
        }

        public virtual bool EnterValueOfInterestRate(string intrate)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtRateDeterminationInterestRate);
            appHandle.Set_field_value(txtRateDeterminationInterestRate, intrate);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }
        public virtual bool VerifyAnnualYield(string annualYield)
        {
            bool Result = false;
            string AY1 = appHandle.GetObjectText(txtAnnualYield);
            //double AY1=Convert.ToDouble(AY);
            if (annualYield == AY1)
            {
                Result = true;
            }
            return Result;
        }
    }

}