using GTS_OSAF.CoreLibs;
using System;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AddBeneficialOwnerstoCreateCorporateCustomerPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpBeneficialOwnerType = "Xpath;//select[@name='beneficialOwner.beneficialOwnerType']";
        public static string txtBeneficialOwnerTitle = "Xpath;//input[@name='beneficialOwner.positionTitle']";
        public static string txtFirstName = "Xpath;//input[@name='beneficialOwner.firstName']";
        public static string txtLastName = "Xpath;//input[@name='beneficialOwner.lastName']";
        public static string cbkUSPerson = "Xpath;//input[@name='beneficialOwner.usTaxpayer']";
        public static string txtTaxID = "Xpath;//input[@name='beneficialOwner.taxID']";
        public static string txtDateofBirth = "Xpath;//input[@name='beneficialOwner.dateOfBirth']";
        public static string txtAddressLine1 = "Xpath;//input[@name='beneficialOwner.address1']";
        public static string txtCity = "Xpath;//input[@name='beneficialOwner.city']";
        public static string drpCountry = "Xpath;//select[@name='beneficialOwner.country']";
        public static string drpState = "Xpath;//select[@name='beneficialOwner.state']";
        public static string txtZIPCode = "Xpath;//input[@name='beneficialOwner.zipCode']";
        public static string txtDriversLicenseNumber = "Xpath;//input[@name='beneficialOwner.driversLicenseNumber']";
        public static string drpDriversLicenseState = "Xpath;//select[@name='beneficialOwner.driversLicenseState']";
        public static string txtDriversLicenseIssueDate = "Xpath;//input[@name='beneficialOwner.driversLicenseIssueDate']";
        public static string txtDriversLicenseExpirationDate = "Xpath;//input[@name='beneficialOwner.driversLicenseExpirationDate']";
        public static string BeneficiaryTaxId = null;

        public virtual void EnterBeneficiaryDetails()
        {
            try
            {
                string[] BeneficiaryDetails = Data.Get("GLOBAL_BENEFICIARY_1");
                appHandle.SelectDropdownSpecifiedValue(drpBeneficialOwnerType, (string)Data.Get("GLOBAL_BENEFICIAL_OWNER"));
                appHandle.Set_field_value(txtBeneficialOwnerTitle, "CEO");
                appHandle.Set_field_value(txtFirstName, BeneficiaryDetails[0]);
                appHandle.Set_field_value(txtLastName, BeneficiaryDetails[1]);
                BeneficiaryTaxId = GetBeneficaryTaxId();
                appHandle.Set_field_value(txtTaxID, BeneficiaryTaxId);
                appHandle.Set_field_value(txtDateofBirth, BeneficiaryDetails[2]);
                appHandle.Set_field_value(txtAddressLine1, BeneficiaryDetails[3]);
                appHandle.Set_field_value(txtCity, BeneficiaryDetails[4]);
                appHandle.SelectDropdownSpecifiedValue(drpCountry, "US - UNITED STATES OF AMERICA");
                appHandle.SelectDropdownSpecifiedValue(drpState, BeneficiaryDetails[5]);
                appHandle.Set_field_value(txtZIPCode, BeneficiaryDetails[6]);
                appHandle.Set_field_value(txtDriversLicenseNumber, BeneficiaryDetails[7]);
                appHandle.SelectDropdownSpecifiedValue(drpDriversLicenseState, BeneficiaryDetails[8]);
                appHandle.Set_field_value(txtDriversLicenseIssueDate, BeneficiaryDetails[9]);
                appHandle.Set_field_value(txtDriversLicenseExpirationDate, BeneficiaryDetails[10]);

            }
            catch (Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

        public virtual string GetBeneficaryTaxId()
        {
            try
            {
                CreateCorporateCustomerPage corporateCustomerPage = new CreateCorporateCustomerPage();
                BeneficiaryTaxId = corporateCustomerPage.GenerateRandomNumberByFormat(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"));
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return BeneficiaryTaxId;
        }
    }
}