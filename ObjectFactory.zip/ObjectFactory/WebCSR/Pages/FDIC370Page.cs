using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class FDIC370Page
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonSubmit = "XPath;//input[@value='Submit']";
        private static string AccountDropdown = "XPath;//td/select[@name='accountNumber']";
        public virtual bool VerifyDataInFDIC370Reporting(string AccountNumber, string refColumnValuesSemicolonDelimited)
        {
            bool Result = false;
            int matchCount=0;
            refColumnValuesSemicolonDelimited=refColumnValuesSemicolonDelimited+"|";
            string[] arr=refColumnValuesSemicolonDelimited.Split('|');
            appHandle.SelectDropdownSpecifiedValueByPartialText(AccountDropdown, AccountNumber);
            for(int a=0;a<arr.Length-1;a++)
            {
                if(Profile7CommonLibrary.VerifyDataInTableByColumnValues(arr[a]))
                {
                    matchCount++;
                }
                if(matchCount==arr.Length-1)
                {
                    Result=true;
                    break;
                }
            }

            return Result;
            
        }

        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }


    }
}