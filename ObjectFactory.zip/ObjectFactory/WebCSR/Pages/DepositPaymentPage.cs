using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DepositPaymentPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string PositiveInterestTransferAccountImage = "Xpath;//body[@class='main']//tr//tr//tr//tr//tr[3]//td[2]//a[1]";
        public static string NegativeInterestTransferAccountImage = "Xpath;//tr[5]//td[2]//a[1]";
        public static string EXternalTransferCustomerImage="Xpath;//body[@class='main']//tr//tr//tr//tr//tr[7]//td[2]//a[1]";
        public static string txtDisbursementPositiveInterestTransferAccount="Xpath;//input[@name='DEP_ITRF']";
        public static string txtDisbursementNegativeInterestTransferAccount="Xpath;//input[@name='DEP_NEGITRF']";
        public static string txtDisbursementExternalTransferCustomer="Xpath;//input[@name='DEP_INTDISETC']";
        public static string txtDisbursementMinimumCheckAmount="Xpath;//input[@name='DEP_INTCHKMIN']";
        public static string txtDisbursementCheckFrequency="Xpath;//input[@name='DEP_INTCHKFRE']";
        public static string txtDisbursementDateofNextCheck="Xpath;//input[@name='DEP_INTCHKND']";
        public static string txtPositiveInterestPostingFrequency="Xpath;//input[@name='DEP_IPF']";
        public static string txtPositiveInterestPostingNextDate="Xpath;//input[@name='DEP_INP']";
        public static string txtPositiveInterestMininmumBalancetoPay="Xpath;//input[@name='DEP_MININT']";
        public static string txtNegativeInterestPostingFrequency="Xpath;//input[@name='DEP_NEGIPF']";
        public static string txtNegativeInterestPostingNextDate="Xpath;//input[@name='DEP_NEGINP']";
        public static string txtNegativeInterestMinimumAmountToChange="Xpath;//input[@name='DEP_NEGMININT']";
        public static string txtUncollectedFundsInteresMinimumDailyAmount="Xpath;//input[@name='DEP_DUMI']";
        public static string txtOverdraftFundsInterestInitialMinimumDailyAmount="Xpath;//input[@name='DEP_IDOMI']";
        public static string txtOverdraftFundsInteresSubsequentMinimumDailyAmount="Xpath;//input[@name='DEP_SDOMI']";
        public static string drpPaymentAccount="Xpath;//select[@name='ACN_CID']";
        public static string drpDisbursementOption="Xpath;//select[@name='DEP_IOPT']";
        public static string drpPositiveInterestAvailableInterestOption="Xpath;//select[@name='DEP_IAF']";
        public static string drpNegativeInterestPostingOption="Xpath;//select[@name='DEP_NEGIPO']";
        public static string drpNegativeInterestNegativeBalanceOption="Xpath;//select[@name='DEP_NEGBALOP']";
        public static string drpNegativeInterestMinimumChangeOption="Xpath;//select[@name='DEP_NEGMINOP']";
        public static string drpUncollectedFundsInterestApplicationOption="Xpath;//select[@name='DEP_NIAO']";
        public static string drpUncollectedFundsInteresIndex="Xpath;//select[@name='DEP_UFINDEX']";
        public static string drpRealInterestInflationRateCalculationIndex="Xpath;//select[@name='DEP_ANLINFLCALIN']";
        public static string ckbNegativeInterestPostZeroNetInterest="Xpath;//input[@name='DEP_ISZERONETINTPOSTALLOWED']";
        public static string tblPaymentDisbursement="Xpath;//body[@class='main']/table[@id='mainTable']/tbody/tr/td[@id='content']/table/tbody/tr/td/table/tbody/tr/td/form[@name='depositAccountInterestPaymentForm']/table[@class='contentTable']/tbody/tr[3]/td[1]/table[1]";
        public static string tblPaymentAnticipatedCheck="Xpath;//td[@id='content']//tr[5]//td[1]//table[1]";
        public static string tblPaymentPositiveInterest="Xpath;//form[@name='depositAccountInterestPaymentForm']//tr[1]//td[1]//table[1]";
        public static string tblPaymentNegativeInterest="Xpath;//body[@class='main']/table[@id='mainTable']/tbody/tr/td[@id='content']/table/tbody/tr/td/table/tbody/tr/td/form[@name='depositAccountInterestPaymentForm']/table[@class='contentTable']/tbody/tr[9]/td[1]/table[1]/tbody[1]";
        public static string tblPaymentUncollectedFundsInterest="Xpath;//tr[11]//td[1]//table[1]//tbody[1]";
        public static string tblPaymentOverdraftFundsInterest="Xpath;//form[@name='depositAccountInterestPaymentForm']//tr[1]//td[1]//table[1]";
        public static string tblPaymentRealInterest="Xpath;//tr[15]//td[1]//table[1]";
        public static string imgDisbursementCheckFrequencyCalculator = "Xpath;//input[@name='DEP_INTCHKFRE']/parent::td/child::a";
        public static string imgPositiveInterestPostingFrequencyCalculator = "Xpath;//input[@name='DEP_IPF']/parent::td/child::a";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string dropdownNegIntPostingOption = "Xpath;//select[@name = 'DEP_NEGIPO']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        

        private static string tableContent = "Xpath;//table[@class='contentTable']/tbody";
        private static string txtPostingFreq ="Xpath;//input[@name='DEP_IPF']";

         public virtual bool WaitUntilDepositPaymentPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpPaymentAccount))
            {
                result = true;
            }

            return result;

        }
        
        public virtual void SelectSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            
        }
         public virtual bool VerifyMessageDepositPaymentPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void EnterInterestPaymentPageOptions(string DisOption=" ",string PostingFreq= "", string NegIntPostFreq = " ", string NegIntPostOpt = "" )
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpPaymentAccount))
            {
                if(!string.IsNullOrEmpty(DisOption))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpDisbursementOption,DisOption);
                }
                if(!string.IsNullOrEmpty(PostingFreq))
                {
                appHandle.Set_field_value(txtPostingFreq,PostingFreq);
                    appHandle.Wait_For_Specified_Time(5);
             
                }
                if(!string.IsNullOrEmpty(NegIntPostFreq))
                {
                appHandle.Set_field_value(txtNegativeInterestPostingFrequency,NegIntPostFreq);
                }
                if(!string.IsNullOrEmpty(NegIntPostOpt))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownNegIntPostingOption,NegIntPostOpt);
             
                }
                                       
            }
        }
            public virtual void UpdatePositiveInterestPostingFrequency(string Frequency)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPositiveInterestPostingFrequency);
            appHandle.Set_field_value(txtPositiveInterestPostingFrequency,Frequency);
        }
        public virtual bool VerifyTableDataByLabelNameLabelValue(string sLabelNameLabelValuePipeDelimited)
        {
            bool Result = false;
            if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableContent, sLabelNameLabelValuePipeDelimited))
            {
                Result = true;
            }
            return Result;
        }

        public virtual bool CheckSuccessMessage()
        {
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }

    }
}


