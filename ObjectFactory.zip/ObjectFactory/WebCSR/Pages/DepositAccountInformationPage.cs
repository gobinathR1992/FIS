using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DepositAccountInformationPage
    {
        public static WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string General_Tab = "Xpath;//table[@class='tab']//td[contains(text(),'General')]";
        private static string Interest_Tab = "Xpath;//table[@class='tab']//td[text()='Interest']";
        private static string Submit_Button = "Xpath;//input[@value='Submit']";
        private static string Cancel_Button = "Xpath;//input[@value='Cancel']";

        public static string drpCompanyCode="Xpath;//select[@name='DEP_CO']";
        public static string drpCustomerCode="Xpath;//select[@name='ACN_CCODE']";
        public static string drpCostcenter="Xpath;//select[@name='ACN_CC']";
        public static string drpBranch="Xpath;//select[@name='ACN_BOO']";
        public static string lnkAccountActivity="Xpath;//a[contains(text(),'Account Activity')]";
        public static string txtAttention="Xpath;//input[@name='ACN_ATN']";
        public static string lnkGeneral="Xpath;//a[contains(text(),'General')]";
        public static string txtAccountInformationName="Xpath;//input[@name='ACN_ACCTNAME']";

        private static string TransactionProcessing_Tab="Xpath;//table[@class='tabSelected']//td[contains(text(),'Transaction Processing')]";

        //Deposit| Transaction Processing Tab|Investment Sweep

        public static string lnkInvestmentSweep="Xpath;//td[@class='tabSub'][contains(text(),'Investment Sweep')]";
        public static string drpInvestmentSweepEligibility="Xpath;//select[@name='DEP_SWPF']";

        public static string drpInvestmentSweepType="Xpath//select[@name='DEP_SWPOPT']";



        // Loan | General Tab element locators
        private static string General_LedgerBalance_Field = "Xpath;//tr[td[contains(text(),'Ledger Balance')]]//td[input[@name='ACN_BAL']]";
        private static string General_AvailableBalance_Field = "Xpath;//tr[td[contains(text(),'Available Balance')]]//td[input[@name='DEP_CSHBLAVL']]";
        private static string General_CollectedBalance_Field = "Xpath;//tr[td[contains(text(),'Collected Balance:')]]//input[@name='ACN_BALCOL']";
        private static string tableAccountBalancesContentTable ="Xpath;//*[text()='Authorized Overdraft']/ancestor::table/tbody";

        //Deposits|Transaction Processing|Overdraft Processing
        public static string lnkOverdraftProcessing="Xpath;//td[@class='tabSub'][contains(text(),'Overdraft Processing')]";
        public static string drpOverdraftOption="Xpath;//select[@name='ACN_ODO']";

        public static string txtAuthorizeOverdraftLimit ="Xpath;//*[@name='DEPAUTHODLIMIT_ODLIMITAMT']";

        public static string txtAuthorizeOverdraftTerm = "Xpath;//*[@name='DEPAUTHODLIMIT_ODTERM']";

        public static string txtTempAuthorizedOverdraftLimitSpread="Xpath;//*[@name='DEPAUTHODLIMIT_TMPAUTHODLIMIT']";
        public static string txtTempAuthorizedOverdraftLimitStartDate ="Xpath;//*[@name='DEPAUTHODLIMIT_TMPODLIMITSTARTDTE']";
        public static string txtTempAuthorizedOverdraftLimitEndDate="Xpath;//*[@name='DEPAUTHODLIMIT_TMPODLIMITEXPDTE']";

        public static string buttonSubmit="Xpath;//*[@type='submit']";

        public static string buttonCancel="Xpath;//*[@name='cancel']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";

        public static string DropdownAccount ="Xpath;//*[@name='ACN_CID']";

        public static string tableAuthorizedOverdraftContentTable = "Xpath;//*[@class='contentTable']/descendant::tbody[1]";

        public static string ApplicationDate = new CreateTrustCustomerPage().GetApplicationDate();
     
    



        public virtual void select_interest_tab()
        {
            applicationHandle.ClickObject(Interest_Tab);
            applicationHandle.Wait_For_Specified_Time(3);
            Report.Info("Account Information | Interest tab selected.");            
        }

        public virtual string get_ledger_balance_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(General_LedgerBalance_Field);
        }
        public virtual string get_available_balance_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(General_LedgerBalance_Field);
        }
        public virtual string get_computed_balance_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(General_CollectedBalance_Field);
        }

        public virtual bool VerifyDatainAccountBalances(string labelnamepipelabelvalue)
        {
            bool result = false;

            if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableAccountBalancesContentTable, labelnamepipelabelvalue))
            {
                result = true;
            }
            return result;
        }

        public virtual void UpdateAuthorizedOverdraftDetails(string AuthorizeOverdraftLimit,string AuthorizeOverdraftTerm,string TempAuthorizedOverdraftLimitSpread,string TempAuthorizedOverdraftLimitStartDate="",string TempAuthorizedOverdraftLimitEndDate = "")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtAuthorizeOverdraftLimit);
            applicationHandle.Set_field_value(txtAuthorizeOverdraftLimit,AuthorizeOverdraftLimit);
            applicationHandle.Set_field_value(txtAuthorizeOverdraftTerm,AuthorizeOverdraftTerm);
            applicationHandle.Set_field_value(txtTempAuthorizedOverdraftLimitSpread,TempAuthorizedOverdraftLimitSpread);
            applicationHandle.Set_field_value(txtTempAuthorizedOverdraftLimitStartDate,TempAuthorizedOverdraftLimitStartDate);                            
            applicationHandle.Set_field_value(txtTempAuthorizedOverdraftLimitEndDate,TempAuthorizedOverdraftLimitEndDate);
                


        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
    
                applicationHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
        }
        public virtual bool ValidateCustomerInfoUpdateMSG()
        {
            bool result = false;
            if (applicationHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                result = true;
            }
 
            return result;
        }
       public virtual void SelectAccountFromAccountsDropdown(string AccountNumber)
        {
            applicationHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccount, AccountNumber);
        }

        public virtual bool VerifyDatainAuthorizedOverdraft(string labelnamepipelabelvalue)
        {
            bool result = false;

            if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableAuthorizedOverdraftContentTable, labelnamepipelabelvalue))
            {
                result = true;
            }
            return result;
        }

        public virtual bool VerifyFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "Temporary Authorized Overdraft Limit Spread":
                        if (applicationHandle.GetSpecifiedObjectAttribute(txtTempAuthorizedOverdraftLimitSpread, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;

                    case "Temporary Authorized Overdraft Limit Start Date":
                        if (applicationHandle.GetSpecifiedObjectAttribute(txtTempAuthorizedOverdraftLimitStartDate, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;

                        case "Temporary Authorized Overdraft Limit End Date":
                        if (applicationHandle.GetSpecifiedObjectAttribute(txtTempAuthorizedOverdraftLimitEndDate, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }


            return result;
        }


    }

    }
