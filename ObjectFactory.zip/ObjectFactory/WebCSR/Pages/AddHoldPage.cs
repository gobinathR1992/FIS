using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;
using System;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AddHoldPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtAddCheckHoldAmount = "Xapth;//input[@name='HLD8_AMT']";
        public static string txtAddCheckHoldCashHoldAmount = "Xpath;//input[@name='HLD8_CSHAMT']";
        public static string txtAddCheckHoldExpirationDate = "Xpath;//input[@name='HLD8_EXPDT']";
        public static string drpAddHoldType = "Xpath;//select[@name='type']";
        public static string drpAddCheckHoldCurrencyCode = "Xpath;//select[@name='HLD8_CRCD']";
        public static string txtAddFloatHoldAmount = "Xpath;//input[@name='HLD7_AMT']";
        public static string txtAddFloatHoldExpirationDate = "Xpath;//input[@name='HLD7_EXPDT']";
        public static string drpAddFloatHoldCurrencyCode = "Xpath;//select[@name='HLD7_CRCD']";
        public static string txtAddPermanentHoldStartDate = "Xpath;//input[@name='PHLD_STDT']";
        public static string txtAddPermanentHoldExpirationDate = "Xpath;//input[@name='PHLD_EXPDT']";
        public static string txtAddPermanentHoldComment = "Xpath;//textarea[@name='PHLD_TCMT']";
        public static string txtAddPermanentHoldFixedAmount = "Xpath;//input[@name='PHLD_AMT']";
        public static string txtAddPermanentHoldPercentage = "Xpath;//input[@name='PHLD_PERCNT']";
        public static string txtAddPermanentHoldReferenceAccount = "Xpath;//input[@name='PHLD_AREF']";
        public static string drpAddPermanentHoldCode = "Xpath;//select[@name='PHLD_PHC']";
        public static string drpAddPermanentHoldCurrencyCode = "Xpath;//select[@name='PHLD_CRCD']";
        public static string drpAddPermanentHoldBalanceType = "Xpath;//select[@name='PHLD_COMP']";
        public static string btnsubmit = "Xpath;//input[@name='submit']";
        private static string HoldsMSGOBJ = "XPath;//div[@class='dataTables_scrollHeadInner']//following::table";
        public virtual void EnterCheckHoldDetails(string sHoldType, string sAmount, string sExpDate)
        {

            try
            {
                //Method to Enter the Check Hold details.
                WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle.SelectDropdownSpecifiedValue(drpAddHoldType, sHoldType);
                appHandle.Set_field_value(txtAddCheckHoldAmount, sAmount);
                appHandle.Set_field_value(txtAddCheckHoldExpirationDate, sExpDate);
                appHandle.ClickObject(btnsubmit);
                Report.Info("Entered the Check Hold Details");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        public virtual bool VerifyNoHolds()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(HoldsMSGOBJ))
            {
                if (appHandle.GetObjectText(HoldsMSGOBJ).Contains(Data.Get("CHECK_HOLD_MSG")))
                {
                    Result = true;
                }
            }

            return Result;
        }
    }

}
