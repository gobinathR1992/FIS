using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using System;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateAccounSelectAccountsPage
    {
        WebApplication appHandle;
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To select Number of Account for specified product.
        /// <param name= "product Desc"></param> 
        /// <param name= "noofaccounts"></param> 
        /// <returns>bool</returns>
        /// <example>SelectAccountsinWebCSR(sProductDesc,sNoofaccounts)</example>
        public bool SelectAccountsinWebCSR(string sProductDesc, string sNoofaccounts)
        {
            bool bcheck = false;
            try
            {
                string prodType = "XPath;//tr[td[a[text()='" + sProductDesc + "']]]//select";
                if (AppHandle.IsObjectExists(prodType))
                {
                    AppHandle.WaitUntilElementClickable(prodType);
                    AppHandle.SelectDropdownSpecifiedValue(prodType, sNoofaccounts);
                    bcheck = true;
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

        public bool CheckExpectedValueinDropdown(string sProductDesc, string ExpectedValue)
        {
            bool bcheck = false;
            try
            {
                string prodType = "XPath;//tr[td[a[text()='" + sProductDesc + "']]]//select";
                if (AppHandle.IsObjectExists(prodType))
                {
                    AppHandle.WaitUntilElementClickable(prodType);
                    bcheck=appHandle.CheckValueInDropdown(prodType, ExpectedValue);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

    }
}




