
using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountRestrictionPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string dropdownAccount = "XPath;//*[contains(text(),'Account')]/following-sibling::*/descendant::select[1]";
        private static string buttonAdd = "XPath;//*[@type='submit'][@name='add']";
        private static string dropdownRestrictionType = "XPath;//*[contains(text(),'Restriction:')]/following-sibling::*/descendant::select";
        private static string txtStartDate = "XPath;//*[contains(text(),'Start Date')]/following-sibling::td/descendant::input";
        private static string txtExpirationDate = "XPath;//*[contains(text(),'Expiration Date')]/following-sibling::td/descendant::input";
        private static string txtComment = "XPath;//*[contains(text(),'Comment')]/following-sibling::td/descendant::input";
        private static string buttonSubmit = "Xpath;//*[contains(@type,'submit')][@name='submit']";
        private static string buttonCancel = "Xpath;//*[contains(@type,'button')][@name='cancel']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        private static string ApplicationDate = new CreateTrustCustomerPage().GetApplicationDate();
        private static string DeleteButton="Xpath;.//input[@name='delete']";
        private static string RestrictionTable="Xpath;.//*[contains(@class,'ledgerScrollable dataTable')]/tbody";

        /// <summary>
        /// This returns application date.
        /// </summary>
        /// <returns></returns>
        public virtual string GetApplicationDate()
        {
            string result = "";
            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccount);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccount);
            }
        }
        public virtual void ClickOnCancelButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCancel))
            {
                appHandle.ClickObjectViaJavaScript(buttonCancel);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccount);
            }
        }
        public virtual void SelectAccountfromAccountsDropdown(string AccountNumber)
        {
            int optionscount = appHandle.GetRowCountfromList(dropdownAccount);
            for (int i = 1; i <= optionscount; i++)
            {
                if (appHandle.GetObjectText(dropdownAccount + "/option[" + i + "]").Contains(AccountNumber))
                {
                    appHandle.SelectDropdownValueByIndex(dropdownAccount, i);
                    break;
                }
            }
        }
        public virtual void EnterRestrictionDetails(string RestrictionType, string StartDate = "", string ExpirationDate = "", string Comment = "")
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownRestrictionType))
            {
               
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownRestrictionType, RestrictionType);
                if (string.IsNullOrEmpty(StartDate))
                {
                    appHandle.Set_field_value(txtStartDate, ApplicationDate);

                }
                else
                {
                    appHandle.Set_field_value(txtStartDate, StartDate);
                }
                if (string.IsNullOrEmpty(ExpirationDate))
                {
                    appHandle.Set_field_value(txtExpirationDate, appHandle.CalculateNewDate(ApplicationDate, "Y", 1));
                }
                else
                {
                    appHandle.Set_field_value(txtStartDate, ExpirationDate);
                }
                if (string.IsNullOrEmpty(Comment))
                {
                    appHandle.Set_field_value(txtComment, "Restriction Account :" + appHandle.GetDropdownSelectedValue(dropdownAccount) + " .");
                }
                else
                {
                    appHandle.Set_field_value(txtComment, Comment);
                }

            }
        }
        public virtual bool VerifyRestrictionCreationSuccessful()
        {
            bool result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals((string)Data.Get("The restriction has been created.")))
            {
                result = true;
            }
            return result;
        }
        public virtual void DeleteRestrictionFromTable(string date)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);  
                appHandle.SelectRadioButtonInTable(RestrictionTable,date);
                appHandle.ClickObjectViaJavaScript(DeleteButton);
                
        
            }
            catch (Exception e)
            {
                Report.Fail(e.Message, "DeletePendingTransfer Exception", appHandle);   
            }
        }

    }
}