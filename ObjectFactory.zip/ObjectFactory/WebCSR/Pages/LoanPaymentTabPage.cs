using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanPaymentTabPage
    {
        WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string Payment_Snapshot_Link = "Xpath;//a[contains(text(),'Payment Snapshot')]";
        public static string Payment_Detail_Link = "XPath;//a[contains(text(),'Payment Detail')]";
        public static string Payment_Calculation_Link = "Xpath;//a[contains(text(),'Payment Calculation')]";
        public static string Payment_Application_Link = "Xpath;//a[contains(text(),'Payment Application')]";
        public static string Billing_Statement_Link = "Xpath;//a[contains(text(),'Billing Statement')]";
        public static string Payment_Schedule_Link = "Xpath;//a[contains(text(),'Payment Schedule')]";

       
        public virtual void select_payment_snapshot_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Payment_Snapshot_Link);
        }

        public virtual void select_payment_detail_link()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(Payment_Detail_Link);
            applicationHandle.Select_link(Payment_Detail_Link);
        }

        public virtual void select_payment_calculation_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Payment_Calculation_Link);
        }

        public virtual void select_payment_application_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Payment_Application_Link);
        }

        public virtual void select_billing_statement_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Billing_Statement_Link);
        }
        
        public virtual void select_payment_schedule_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Payment_Schedule_Link);
        }
    




    }
}