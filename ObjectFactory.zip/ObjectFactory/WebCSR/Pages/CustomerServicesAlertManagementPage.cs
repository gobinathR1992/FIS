using GTS_OSAF.CoreLibs;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class CustomerServicesAlertManagementPage
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //Alert Manager
        private static string buttonAdd = "Xpath;//*[@value='Add']";
        //Add Alert  
        private static string dropdownAlertType = "Xpath;//*[@name='CIFALTPAR_ALRTID']";

        private static string dropdownAccount = "Xpath;//*[@name='CIFALTPAR_CID']";
        private static string dropdownThreshold ="Xpath;//*[@name='CIFALTPAR_ALTTRH']";
        private static string txtAmount = "Xpath;//*[@name='CIFALTPAR_TRNAMT']";
        private static string buttonSubmit = "Xpath;//*[@name='submit']";
        private static string buttonCancel = "Xpath;//*[@name='cancel']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";

        //Alert Messages
        private static string tableListofAlert = "XPath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";


        public virtual void ClickOnAddButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
        }


        public virtual void AddAlertToAccount( string AlertType,string Account,string Threshold,string Amount)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAlertType);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAlertType,AlertType);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccount,Account);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownThreshold,Threshold);
            appHandle.Set_field_value(txtAmount,Amount);
        }

        public virtual void ClickOnSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);

        }
        public virtual bool VerifyAddAlertSuccessMSG()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("AlertMsg")))
            {
                Result = true;
            }

            return Result;
        }

        

        public virtual bool VerifyTableDataByLabelNameLabelValue(string sLabelNameLabelValuePipeDelimited)
        {
            bool Result = false;
            if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableListofAlert, sLabelNameLabelValuePipeDelimited))
            {
                Result = true;
            }
            return Result;
        }
    }





         
    }
