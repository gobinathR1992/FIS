using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class PurchasedImpairedLoanSOP3Page
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string buttonAdd="XPath;//input[@name='add']";
        public static string dropdownAccount="XPath;//table[@class='contentTable']/descendant::select";
        public static string txtCashFlowsExpectedtobeCollected="XPath;//input[@name='LNSOP_CFEXP2BCOLL']";
        public static string txtInitialInvestment="XPath;//input[@name='LNSOP_INITINV']";
        public static string txtEffectiveInterestRate="XPath;//input[@name='LNSOP_SOPEIRN']";

        public static string buttonSubmit="XPath;//input[@name='submit']";
        public static string tablePurchasedLoan="XPath;//table[@class='ledger']/tbody";

        public static string buttonEdit="XPath;//input[@name='edit']";

        public static string txtProvisionforLoanLossesIncreases="XPath;//input[@name='LNSOP_PROV4LNLOSSINC']";
        public static string txtProvisionforLoanLossesDecreases="XPath;//input[@name='LNSOP_PROV4LNLOSSDEC']";


        public virtual void ClickAddbutton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);

        }

        public virtual void SelectValueFromAccuntDropdown(string val)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccount);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccount,val);
        }

        public virtual bool AddPurchasedImpairedLoan(string accnum,string CashFlowsExpectedToBeCollected,string InitialInvestment,string SOPEffectiveInterestRate)
        {
            ClickAddbutton();
            SelectValueFromAccuntDropdown(accnum);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCashFlowsExpectedtobeCollected);
            appHandle.Set_field_value(txtCashFlowsExpectedtobeCollected,CashFlowsExpectedToBeCollected);
            appHandle.Set_field_value(txtInitialInvestment,InitialInvestment);
            appHandle.Set_field_value(txtEffectiveInterestRate,SOPEffectiveInterestRate);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
            
        }


        public virtual void SelectAccountFromPurchasedtable(string accountnum)
        {
            string dynobjtbl="XPath;//table[@class='ledger']/tbody/descendant::td[contains(text(),'"+accountnum+"')]/preceding-sibling::td/input";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynobjtbl);            
            appHandle.ClickObjectViaJavaScript(dynobjtbl);            
            Report.Pass("The radio button is selected for account number","rtga","True",appHandle);

        }

        public virtual void ClickEditButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit);
            appHandle.ClickObjectViaJavaScript(buttonEdit);
        }


        public virtual bool EditPurchasedLoan(string cashflowexpectcollval,string lossincreaseval="",string lossdecreaseval="",string effectrate="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCashFlowsExpectedtobeCollected);
            appHandle.Set_field_value(txtCashFlowsExpectedtobeCollected,cashflowexpectcollval);
            if(!string.IsNullOrEmpty(lossincreaseval))
            {
                appHandle.Set_field_value(txtProvisionforLoanLossesIncreases,lossincreaseval);
            }
            if(!string.IsNullOrEmpty(lossdecreaseval))
            {
                appHandle.Set_field_value(txtProvisionforLoanLossesDecreases,lossdecreaseval);
            }
            if(!string.IsNullOrEmpty(effectrate))
            {
                appHandle.Set_field_value(txtEffectiveInterestRate,effectrate);
            }
            
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }



    }
}