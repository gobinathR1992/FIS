using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class paymentcalculationpage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string chkCalculationRulesAmortizationOptionAllowRemainingAmortizationToExceedOriginal = "XPath;//input[@name='LN_RAMOGROAMO']";
        public static string drpCalculationrulesinterestdeterminationpoint = "XPath;//select[@name='LN_IDP']";
        public static string drpCalculationrulesinterestcollectionmethod = "XPath;//select[@name='LN_ICM']";
        public static string drpCalculationrulespaymentcalculationmethod = "XPath;//select[@name='LN_PCM']";
        private static string buttonSubmit = "XPath;//input[@name='submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        public virtual void SelectPaymentCalculationMethod(string sMethod)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpCalculationrulespaymentcalculationmethod))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpCalculationrulespaymentcalculationmethod, (string)sMethod);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMessageInLoanPaymentCalculationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
    }
}