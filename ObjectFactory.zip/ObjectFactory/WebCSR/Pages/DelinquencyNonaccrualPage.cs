using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class DelinquencyNonaccrualPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string cbxNonaccrualIndicator = "Xpath;//input[@name='LN_NAI']";
		private static string buttonSubmit = "XPath;//*[@value='Submit']";
		private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
		
		
		public virtual void EnterDelinquencyNonaccrualPageOptions(string Nonaccrual=" ")
        {
		  try
		  {
		   if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(cbxNonaccrualIndicator))
            {
                if(!string.IsNullOrEmpty(Nonaccrual))
                {
                appHandle.Set_radiobutton(cbxNonaccrualIndicator);
                }
                                       
            }
		  }
		  catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
		
		 public virtual void SelectSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            
        }
	   
	    public virtual bool VerifyMessageDepositPaymentPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
    }
}

