using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DepositAccountOverviewPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string imgAggregateAvailableBalance = "Xpath;//td[@class='fieldLabelLeft'][contains(text(),'Aggregate Available Balance:')]//following-sibling::td//child::a/img";
        public static string tblAccountSummary = "Xpath;//table//tr//td[contains(text(), 'Account Summary')]/parent::tr/following-sibling::tr";
        public static string tblBalances = "Xpath;//div[@id='core-modal-dialog']//table[@class='contentTable']";
        public static string tblAggregateAvailableBalCalculation = "Xpath;//table[@class='contentTable']//h2[text()='Aggregate Available Balance Calculation']/../../following-sibling::tr//td/table//td[@class='fieldLabel'][contains(text(),'Aggregate Available Balance:')]/../..";
        public static string lnkHolds = "Xpath;//td[text()='Holds']";
        protected static string tblPostedTransaction = "Xpath;//h1[contains(text(),'Posted Transactions')]/../../../parent::table/../../../parent::table/following-sibling::table/tbody";
        protected static string tabPostedTransaction = "Xpath;//td[@class='summaryTableHeading'][contains(text(),'Posted Transactions')]";

        public static string tabAccountSummary = "Xpath;//td[contains(text(),'Account Summary')]";
        public static string tabAccountHistory = "Xpath;//td[@class='summaryTableHeading'][contains(text(),'Account History')]";
        public static string tabAccountNotes = "Xpath;//td[contains(text(),'Account Notes')]";
        public static string tabCards = "Xpath;//td[contains(text(),'Cards')]";
        public static string tabInterestPool = "Xpath;//td[@class='summaryTableHeading'][contains(text(),'Interest Pool')]";
        public static string tabCollectionRecords = "Xpath;//td[contains(text(),'Collection Records')]";
        public static string tabStops = "Xpath;//table[@class='summaryTableHeading']//td[contains(text(),'Stops')]";
        
        public static string tableAccountHistorycell="XPath;//table[@id='posted-transactions-list']/tbody/tr[1]/td[7]";
        
        public static string linkAccountClosureUtility="XPath;//td[contains(text(),'Account Closure Utility')]";

        public static string tableAccountHistory="XPath;//table[@id='history-list']/tbody";

        public static string tabGenralAccountServices="XPath;//*[contains(text(),'General Account Services')]";
        public static string tblAccountAvailableBalCalculation = "Xpath;//td[contains(text(),'Account Available Balance:')]//following-sibling::td[1]";
        public static string permanentHoldField= "XPath;//td[contains(text(),'Permanent Holds')]//following-sibling::td[1]";
        /// <summary>
        /// This method is click on AggregateAvailableBalanceImg
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DepositAccountOverviewPage.ClickOnAggregateAvailableBalanceImg();
        /// </example>
        public virtual void ClickOnAggregateAvailableBalanceImg()
        {
            try{
                appHandle.WaitUntilElementVisible(imgAggregateAvailableBalance);
                appHandle.ClickObject(imgAggregateAvailableBalance);
            }
            catch(Exception e)
            {
                Report.Info("Exception logged : "+e);
            }
        }

        /// <summary>
        /// This method is used to check column exists in AvailableBalanceCalculationTable.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DepositAccountOverviewPage.CheckColumnExistsInTable();
        /// </example>
        public virtual bool CheckColumnExistsInTable(string sTableName, string sColumnName)
        {
         bool bCheck = false;
         try{
         bCheck = appHandle.CheckSpecifiedColumnExistsInTable(sTableName, sColumnName);
         }
         catch(Exception e)
         {
           Report.Info("Exception logged : "+e);  
         }
         return bCheck;

        }

        /// <summary>
        /// This method is click on Holds Link.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DepositAccountOverviewPage.ClickOnHoldsLink();
        /// </example>
        public virtual void ClickOnHoldsLink()
        {
            try{
                appHandle.WaitUntilElementVisible(lnkHolds);
                appHandle.ClickObject(lnkHolds);
            }
            catch(Exception e)
            {
                Report.Info("Exception logged : "+e);
            }
        }

         /// <summary>
        /// This method is used to navigate to posted transaction table.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DepositAccountOverviewPage.navigate_to_posted_transaction_table();
        /// </example>
        
       public virtual void NavigateToPostedTransactionDateTable()
        {
            appHandle.ClickObject(tabPostedTransaction);
            appHandle.SyncPage();
        }

        /// <summary>
        /// This method is used to check value exists in PostedTransaction Table.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DepositAccountOverviewPage.CheckValueExistsInPostedTransactionTable();
        /// </example>
        public virtual bool CheckDataExistsInPostedTransactionTable(string Refvalue)
        {
         bool bCheck = false;
         try{
                bCheck = appHandle.CheckSpecifiedDataAvailableInTable(Refvalue, tblPostedTransaction);
         }
         catch(Exception e)
         {
           Report.Info("Exception logged : "+e);  
         }
         return bCheck;

        }

         public virtual string GetValueForLabel(string Label)
        {
            string LabelValueXpath = "Xpath;//*[table[@class='contentTable']]//*[contains(text(),'" + Label + "')]/following-sibling::td";
            string LabelValue = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(LabelValueXpath))
            {
                LabelValue = appHandle.Get_Label_Text(LabelValueXpath);
            }

            return LabelValue;
        }

        public virtual void SelectHeaderInDepositAccountOverview(string headername)
        {
            string dynobj="XPath;//table[@class='contentTable']/descendant::td[contains(text(),'"+headername+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynobj);
            appHandle.ClickObjectViaJavaScript(dynobj);
        
        }

        public virtual string GetValueOfInterest()
        {
            string intval1=appHandle.GetObjectText(tableAccountHistorycell);
            intval1=intval1.Replace(",","");
            intval1=intval1.Replace(".","");
            return intval1;
        }

        public virtual void ClickOnAccountClosureUtilityLink()
        {
            if(appHandle.IsObjectExists(linkAccountClosureUtility))
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkAccountClosureUtility);
                appHandle.ClickObjectViaJavaScript(linkAccountClosureUtility);

            }
            else
            {
            
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(tabGenralAccountServices);
                appHandle.ClickObjectViaJavaScript(tabGenralAccountServices);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkAccountClosureUtility);
                appHandle.ClickObjectViaJavaScript(linkAccountClosureUtility);
            }
            
        }

        public virtual bool CheckDataInAccountHistoryTableBasedOnRefValues(string refvaluesseperatedbydelimsemicolon)
        {
            
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableAccountHistory);
            return appHandle.CheckSpecifiedDataAvailableInTable(tableAccountHistory,refvaluesseperatedbydelimsemicolon);

        }

        public virtual string getAccountAvailableBalanceFieldValue()
        {
            appHandle.Wait_for_object(tblAccountAvailableBalCalculation, 5);
            return appHandle.GetObjectText(tblAccountAvailableBalCalculation);
        }
       public virtual string getAccountPermanentHoldFieldValue()
        {
            appHandle.Wait_for_object(permanentHoldField, 5);
            return appHandle.GetObjectText(permanentHoldField);
        }  


    }
}

