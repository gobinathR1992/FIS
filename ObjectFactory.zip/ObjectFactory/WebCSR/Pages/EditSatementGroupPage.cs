using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class EditSatementGroupPage
    {
        WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tableStatementGroup="XPath;//table[@id='accounts-list']/tbody";
        public static string buttonSubmit="XPath;//input[@name='edit']";

        public static string txtFrequency="XPath;//input[@name='CMBGRP_SFRE']";

        public virtual void SelectAccountFromTable(string account)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableStatementGroup);
            appHandle.SelectCheckBoxInTable(tableStatementGroup,account);
        }

        public virtual void ClickOnSubmit()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            Report.Info("The Account's are selected","sel","True",appHandle);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }

        public virtual void EnterDataForFrequency(string frequencyvalue)
        {
              Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtFrequency);
              appHandle.Set_field_value(txtFrequency,frequencyvalue);
        }
    }
}