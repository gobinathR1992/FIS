using System;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanAccountOverviewPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string tabInterestSummary = "Xpath;//td[text()='Interest Summary']";
        public static string tabPaymentSummary = "XPath;//td[text()='Payment Summary']";
        private static string tablecontent = "XPath;//table[@class='contentTable']/tbody";
        
        public static string linknotes="XPath;//table[@class='menuOptions']/descendant::td[contains(text(),'Holds')]/../following-sibling::tr/td[contains(text(),'Notes')]";
        
        public virtual bool VerifyLoanAccountOverviewValuesBylabelNameLabelValue(string sLabelNamePipeDelimitedsLabelValue)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tablecontent))
            {
                if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tablecontent, sLabelNamePipeDelimitedsLabelValue))
                {
                    Result = true;
                }
            }
            return Result;
        }

        public virtual string GetValueForLabel(string Label)
        {
            string LabelValueXpath = "Xpath;//*[table[@class='contentTable']]//*[contains(text(),'" + Label + "')]/following-sibling::td";
            string LabelValue = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(LabelValueXpath))
            {
                LabelValue = appHandle.Get_Label_Text(LabelValueXpath);
            }

            return LabelValue;
        }

        public virtual string CalculateActualLoanPayoffAmount(string Amount1, string Amount2)
        {
            string ActualLoanPayoffAmount = string.Format("{0:n}", Convert.ToDecimal(Amount1) - Convert.ToDecimal(Amount2));
            return ActualLoanPayoffAmount;
        }

        public virtual void ClickOnNotesLink()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linknotes);
            appHandle.ClickObjectViaJavaScript(linknotes);
        }

        public virtual void ClickOnPaymentSummaryTab()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tabPaymentSummary);
            appHandle.ClickObjectViaJavaScript(tabPaymentSummary);
        }
    }
}

