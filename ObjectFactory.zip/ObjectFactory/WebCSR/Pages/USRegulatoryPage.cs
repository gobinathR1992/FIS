using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class USRegulatoryPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonSubmit = "XPath;//input[@value='Submit']";
        private static string AccountDropdown = "XPath;//td/select[@name='accountNumber']";
        private static string checkBoxRegulationCCAccount = "XPath;//*[contains(text(),'Regulation CC Account')]/following-sibling::*/input";
        private static string dropdownReporting1099Exemption ="Xpath;//select[@name='DEP_IRSEXM']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        private static string drpRegulationCCExpCode="Xpath;//*[@name='DEP_REGCCEXC']";
        public static string checkboxRegulationDDAccount="XPath;//input[@name='DEP_REGDD']";
        public static string dropdownScheduleRCEReportingCategory="XPath;//select[@name='DEP_RCE']";



        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMessageInUSRegulatoryPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyUSRegulatoryPageLoads()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                return Result;
            }

            return Result;
        }

        public virtual void EnterUSRegulatoryPageOption(bool RegulationCCOnorOff =true,string Reporting1099Exemption="")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownReporting1099Exemption))
            {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkBoxRegulationCCAccount))
            {
                if (RegulationCCOnorOff)
                {
                    if (appHandle.CheckCheckBoxChecked(checkBoxRegulationCCAccount)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkBoxRegulationCCAccount);
                        if (appHandle.CheckCheckBoxChecked(checkBoxRegulationCCAccount))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkBoxRegulationCCAccount) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkBoxRegulationCCAccount);
                        if (appHandle.CheckCheckBoxChecked(checkBoxRegulationCCAccount) == false) { Result = true; }
                    }
                }
            }
            if(!string.IsNullOrEmpty(Reporting1099Exemption))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownReporting1099Exemption,Reporting1099Exemption);
                }
            }
        }
        public virtual bool VerifyAccountExistsInAccountDropdown(string AccountNumber)
        {
            bool Result=false;
            string temp=appHandle.GetObjectText(AccountDropdown+ "/parent::*[1]");
            if(temp.Contains(AccountNumber))
            {
                Result=true;
            }
        return Result;
        }
        public virtual bool VerifyDataInSplitReporting(string AccountNumber, string refColumnValuesSemicolonDelimited)
        {
            bool Result = false;
            int matchCount=0;
            refColumnValuesSemicolonDelimited=refColumnValuesSemicolonDelimited+"|";
            string[] arr=refColumnValuesSemicolonDelimited.Split('|');
            appHandle.SelectDropdownSpecifiedValueByPartialText(AccountDropdown, AccountNumber);
            for(int a=0;a<arr.Length-1;a++)
            {
                if(Profile7CommonLibrary.VerifyDataInTableByColumnValues(arr[a]))
                {
                    matchCount++;
                }
                if(matchCount==arr.Length-1)
                {
                    Result=true;
                    break;
                }
            }

            return Result;
            
        }
        public virtual void UpdateRegulationCCExceptionCode(string ExceptionCode)
        {
            appHandle.SelectDropdownSpecifiedValue(drpRegulationCCExpCode,ExceptionCode);
        }

        public virtual bool EnterDataForRegDDAndRCEReportingCategory(bool regddval,string RCEreportingval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxRegulationDDAccount);
            if(regddval)
            {
                if(!appHandle.CheckCheckBoxChecked(checkboxRegulationDDAccount))
                {
                    appHandle.ClickObject(checkboxRegulationDDAccount);
                }
            }
            else
            {
                if(appHandle.CheckCheckBoxChecked(checkboxRegulationDDAccount))
                {
                    appHandle.ClickObject(checkboxRegulationDDAccount);
                }
            }

            appHandle.SelectDropdownSpecifiedValue(dropdownScheduleRCEReportingCategory,RCEreportingval);
            appHandle.ClickObject(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }
     
         public virtual bool VerifyRegulationCCExceptionCodeStatus(string labelname,string labelvalue)
        {
            bool Result = false;
            //string runtimexpath = "//*[contains(text(),'"+labelname+"')]/following-sibling::*/*[1]";
            if (appHandle.GetDropdownSelectedValue("Xpath;//select[@name='DEP_REGCCEXC']").Contains(labelvalue))
            {
                Result = true;
            }

            return Result;

        }

    }
}