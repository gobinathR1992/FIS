using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs; 
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class DebitAuthorizationPage
    { 
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string buttonAdd = "Xpath;//*[@name='add']";
        public static string buttonEdit = "Xpath;//*[@name='edit']";
        public static string drpdownFinancialInstitution = "Xpath;//*[@name='DEBAUT_AUTINST']";
        public static string txtAccountNumber = "Xpath;//*[@name='DEBAUT_AUTACCT']";
        public static string drpdownAccountToDebit = "Xpath;//*[@name='DEBAUT_DCID']";
        public static string buttonSubmit ="Xpath;//*[@name='submit']";
        public static string buttonCancel ="Xpath;//*[@name='cancel']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";

        public virtual void ClickOnAddButton()
        {
            appHandle.WaitUntilElementExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
        }

        public virtual void AddDebitAuthorization(string Institution,string accountNumber,string AccountToDebit)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpdownFinancialInstitution);
            appHandle.SelectDropdownSpecifiedValue(drpdownFinancialInstitution,Institution);
            appHandle.Set_field_value(txtAccountNumber,accountNumber);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpdownAccountToDebit);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownAccountToDebit,AccountToDebit);
            
        }
        public virtual void ClickOnSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);

        }

        public virtual bool VerifyAddDebitSuccessMSG()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("DebitMsg")))
            {
                Result = true;
            }

            return Result;
        }




         
    }
}