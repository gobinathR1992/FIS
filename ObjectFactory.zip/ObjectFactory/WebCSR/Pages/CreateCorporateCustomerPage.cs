
using System.Threading;
using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateCorporateCustomerPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string CorporateInformationCompanyNameField = "Xpath;//input[@type='text'][@name='lastName']";
        //*[contains(@name,'lastName')]";
        public static string CorporateInformationTaxIDNumberField = "Xpath;//input[@type='text'][@name='taxIdNumber']";
        public static string CorporateInformationIncoporationDateField = "Xpath;//input[@name='incorporationDate']";
        public static string drpCorporateInformationCountryofIncorporation = "Xpath;//select[@name='residencyCountry']";
        //*[contains(@name,'taxIdNumber')]";
        // public static string CorporateInformationIncoporationDateField = "Xpath;//*[contains(@name,'inceptionDate')]";
        // public static string CorporateInformationCountryOfIncorporationDropDown = "Xpath;//*[contains(@name,'residencyCountry')]";
        // public static string CorporateInformationSingleOwnerOfTBAandCAHierarchyCheckbox = "XPath;//*[contains(@name,'singleOwnerTBACAH')][@type='checkbox']";
        // public static string CorporateInformationHowDidYouHearAboutFISBankDropdown = "XPath;//*[contains(@name,'discoveryMethod')]";
        //public static string CorporateInformationReportingChapter3StatusDropdown = "XPath;//*[contains(@name,'chapter3Status')]";
        // public static string CorporateInformationChapter3ExemptionCode = "XPath;//*[contains(@name,'chapter3Exemption')]";
        //public static string BeneficialOwnersInformationBeneficialOwnersCheckbox = "XPath;//*[contains(@name,'beneficialOwnersFlag')][@type='checkbox']";
        public static string CorporateTelephonePhoneNumberField = "Xpath;//input[@type='text'][@name='businessPhoneNumber']";
        //*[contains(@name,'businessPhoneNumber')]";
        //public static string CorporateTelephoneMobileCheckBox = "XPath;//*[contains(@name,'mobileNumberForBusinessPhone')][@type='checkbox']";
        // public static string CorporateTelephoneTeleMarketingConsentCheckbox = "XPath;//*[contains(@name,'allowTelemarketCallsForBusinessPhone')][@type='checkbox']";
        //  public static string CorporateTelephoneCollectionsConsentCehckbox = "XPath;//*[contains(@name,'allowCollectionCallsForBusinessPhone')][@type='checkbox']";
        public static string PrimaryContactNameField = "XPath;//input[@type='text'][@name='contact']";
        //*[contains(@name,'contact')][@type='text']";
        public static string PrimaryContactPhoneNumberField = "XPath;//input[@type='text'][@name='mainPhoneNumber']";
        //*[contains(@name,'mainPhoneNumber')][@type='text']";
        //public static string PrimaryContactExtensionField = "XPath;//*[contains(@name,'businessExtension')][@type='text']";
        // public static string PrimaryContactFaxNumberField = "XPath;//*[contains(@name,'faxNumber')][@type='text']";
        public static string PrimaryContactEmailField = "XPath;//input[@type='text'][@name='email']";
        //*[contains(@name,'email')][@type='text']";
        public static string SEPACountryThatIssuedCreditorIdentifierDropdown = "XPath;//select[@name='sepaDDInformationCountry']";
        //*[contains(@name,'sepaDDInformationCountry')]";
        //public static string SEPACreditorBusinessCodeField = "XPath;//*[contains(@name,'sepaDDBusinessCode')]";
        public static string SEPACountrySpecificCreditorIdentifierField = "XPath;//input[@type='text'][@name='sepaDDSpecificClientIdentifier']";
        //*[contains(@name,'sepaDDSpecificClientIdentifier')]";
        // public static string FATCAReportingStatusDropDown = "XPath;//*[contains(@name,'fatcaReportingStatus')]";
        // public static string FATCASubjectToWithholdingDropdown = "//*[contains(@name,'subjectToFatcaWithholding')][@type='checkbox']";
        //public static string FATCAReportingChapter4StatusDropdown = "XPAth;//*[contains(@name,'chapter4Status')]";
        //public static string FATCAExemptionCodeDropdown = "XPath;//*[contains(@name,'fatcaExemptionCode')]";
        //public static string FATCAWaiverForReportingDropdown = "XPath;//*[contains(@name,'waiverForFatcaReporting')]";
        public static string PrincipalAddressLine1Field = "XPath;//*[contains(@name,'mainAddress.addressLine1')]";
        public static string PrincipalAddressLine2Field = "XPath;//*[contains(@name,'mainAddress.addressLine2')]";
        public static string PrincipalAddressLine3Field = "XPath;//*[contains(@name,'mainAddress.addressLine3')]";
        // public static string PrincipalAddressTownShipField = "XPath;//*[contains(@name,'mainAddress.township')][@type='text']";
        // public static string PrincipalAddressCountyField = "XPATH;//*[contains(@name,'mainAddress.county')][@type='text']";
        public static string PrincipalAddressCityField = "XPath;//*[contains(@name,'mainAddress.city')][@type='text']";
        public static string PrincipalAddressCountryDropdown = "Xpath;//*[contains(@name,'mainAddress.country')]";
        public static string PrincipalAddressStateDropdown = "XPath;//select[contains(@name,'mainAddress.state')]";
        public static string PrincipalAddressZIPCOdeField = "XPath;//*[contains(@name,'mainAddress.zipCode')]";
        public static string MailingAddressSaemAsPrincipalPlaceOfBusinessYesRadioButton = "XPath;//*[contains(@name,'mailAddressSameAsMain')][@value='true']";
        public static string MailingAddressSaemAsPrincipalPlaceOfBusinessNoRadioButton = "XPath;//*[contains(@name,'mailAddressSameAsMain')][@value='false']";
        public static string MailingAddressLine1Field = "XPath;//*[contains(@name,'mailingAddress.addressLine1')]";
        public static string MailingAddressLine2Field = "XPath;//*[contains(@name,'mailingAddress.addressLine2')]";
        //public static string MailingAddressLine3Field = "XPath;//*[contains(@name,'mailingAddress.addressLine3')]";
        // public static string MailingAddressTownshipField = "XPath;//*[contains(@name,'mailingAddress.township')][@type='text']";
        //public static string MailingAddressCountyField = "XPath;//*[contains(@name,'mailingAddress.county')][@type='text']";
        public static string drpFATCAStatus = "Xpath;//select[@name='w8Beneficiary.fatcaStatus']";
        public static string drpW8Type = "Xpath;//select[@name='w8FormType']";
        public static string drpFATCAWaiverforReporting = "Xpath;//select[@name='waiverForFatcaReporting']";
        public static string MailingAddressCityField = "XPath;//*[contains(@name,'mailingAddress.city')][@type='text']";
        public static string MailingAddressCountryDropdown = "XPath;//*[contains(@name,'mailingAddress.country')]";
        public static string MailingAddressStateDropdown = "XPath;//*[contains(@name,'mailingAddress.state')][@class='enabled']";
        public static string MailingAddressZIPCodeField = "XPath;//*[contains(@name,'mailingAddress.zipCode')]";
        public static string OnlineAccessAllowOnlineAccessYesRadioButton = "XPath;//*[contains(@name,'allowOnlineAccess')][@value='true']";
        public static string OnlineAccessAllowOnlineAccessNoRadioButton = "XPath;//*[contains(@name,'allowOnlineAccess')][@value='false']";
        public static string OnlineAccessUserIDField = "XPath;//*[contains(@name,'userName')][@type='text']";
        public static string OnlineAccessPasswordStatusDropdown = "XPath;//*[contains(@name,'userStatus')]";
        public static string OnlineAccessTemporaryPasswordActionDropdown = "XPath;//*[contains(@name,'resetAction')]";
        public static string OnlineAccessNewPasswordField = "XPath;//*[@name='password']";
        public static string OnlineAccessConfirmPasswordField = "XPath;//*[@name='passwordVerify']";
        public static string OnlineAccessPasswordHintField = "XPath;//*[contains(@name,'hint')]";
        public static string OnlineAccessSecretWordField = "XPath;//*[contains(@name,'secretWord')]";
        public static string SecretQuestionDropdown = "XPath;//*[contains(@name,'secretQuestion')]";
        public static string SecretQuestionAnswerField = "XPath;//*[contains(@name,'secretAnswer')]";
        public static string TelephoneBankingPINCreateATelephoneBankingPINYesRadioButton = "XPath;//*[contains(@name,'allowPIN')][@value='true']";
        public static string TelephoneBankingPINCreateATelephoneBankingPINNoRadioButton = "XPath;//*[contains(@name,'allowPIN')][@value='false']";
        public static string TelephoneBankingPINNewPINField = "XPath;//*[@name='pin']";
        public static string TelephoneBankingPINConfirmPINField = "XPath;//*[@name='pinVerify']";
        //public static string FormW8TypeDropdown = "XPath;//*[@name='w8FormType']";
        public static string ContinueButton = "XPath;//*[@name='_eventId_submit']";
        public static string CancelButton = "XPath;//*[@name='_eventId_cancel']";
        public static string SubmitButton = "XPath;//*[@name='_eventId_submit']";
        private static string ButtonSubmit="Xpath;//*[@value=Submit']";
        public static string CustomerSuccessMessage = "Xpath;//p[text()='The application was successfully processed.']";
        public static string cbkSubjecttoFATCAWithholding = "Xpath;//input[@name='subjectToFatcaWithholding']";
        public static string drpFATCA1042SReportingChapter4Status = "Xpath;//select[@name='chapter4Status']";
        public static string drpFATCAExemptionCode = "Xpath;//select[@name='fatcaExemptionCode']";
        public static string cbkBeneficialOwners = "Xpath;//input[@name='beneficialOwnersFlag']";
        public static string btnBeneficiaryAdd = "Xpath;//input[@id='addBeneficialOwners']";
        public static string txtGIIN = "Xpath;//input[@name='w8Beneficiary.globalIntermediaryIdNumber']";
        public static string txtGIINCollectionDate = "Xpath;//input[@name='w8Beneficiary.giinCollectionDate']";
        public static string txtGIINVerificationDate = "Xpath;//input[@name='w8Beneficiary.giinVerificationDate']";
        public static string tblCorporateCustomer = "Xpath;//h2[contains(text(),'Corporate Information')]/parent::td/parent::tr/following-sibling::tr/td/table/tbody";
        public static string drpFATCAReportingStatus = "XPath;//*[contains(@name,'fatcaReportingStatus')]";
        public static string LinkCustomerSearch = "XPath;//td[text()='Customer Search']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p[1]";
        public static string buttonBack="Xpath;//*[@value='Back']";
        public static string tableCreateCustomer="Xpath;//*[@id='content']/table/tbody";
        //FATCA details
        private static string drpw8BENEFATCAStatus="Xpath;//*[@name='w8Beneficiary.fatcaStatus']";
        private static string chkboxAppliedFor="Xpath;//*[@name='w8Beneficiary.appliedForGIIN']";
        private static string txtGIINClaimDate="Xpath;//*[@name='w8Beneficiary.giinClaimDate']";
        private static string chkboxSubstantialUSOwners="Xpath;//*[@name='w8Beneficiary.substantialUSOwnersFlag']";
        private static string drpdownLOBCode ="Xpath;//*[@name='limitationOnBenefitsCode']";
        private static string buttonAdd="Xpath;//*[@id='addSubstantialUSOwners']";
        //substantial Owner
        private static string buttonSubstantialOwnerAdd="Xpath;//*[@value='Add']";
        private static string ckbIsthisanOrganization="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.organization']";
        private static string txtOwnerName="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.name']";
        private static string txtTIN="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.taxIdNumber']";
        private static string txtPoO ="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.percentageOfOwnership']";
        private static string chkboxW9onFile="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.w9FormOnFile']";
        private static string txtOwnerAddress ="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.address']";
        private static string txtOwnwerCity ="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.city']";
        private static string drpOwnerCountry="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.country']";
        private static string drpOwnerState="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.state']";
        private static string txtOwnerZipCode="Xpath;//*[@name='w8Beneficiary.substantialUSOwner.zipCode']";


        public virtual void ClickOnContinueButton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ContinueButton))
            {
                appHandle.SelectButton(ContinueButton);

            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ButtonSubmit, 1))
            {

            }
            else
            {
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ, 1))
                {
                    if (appHandle.GetObjectText(MSGOBJ).Contains(Data.Get("Unable to process your request at this time.")))
                    {
                        Report.Fail("Corporate Customer creation can not be completed as :" + appHandle.GetObjectText(MSGOBJ), "testfail", "true", appHandle, true);
                    }

                    else
                    {
                        for (int i = 1; i <= 100; i++)
                        {
                            if (appHandle.GetObjectText(MSGOBJ).Contains(Data.Get("User ID is already in use.")))
                            {
                                this.EnterOnlineAccessDetails();
                                this.EnterTelePhoneBankingPINDetails();
                                appHandle.ClickObjectViaJavaScript(ContinueButton);
                                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton, 3))
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
            }


        }
        public virtual bool CheckCorporateCustomerCreationMessage(string ExpectedMessage)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            bool Result = false;
            if (appHandle.GetObjectText(CustomerSuccessMessage).Equals(ExpectedMessage))
            {
                Result = true;
            }
            else
            {
                Result = false;
            }
            return Result;
        }
        public virtual void ClickOnSubmitButton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton))
            {
                appHandle.SelectButton(SubmitButton);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(LinkCustomerSearch);
        }
        public virtual string EnterCorporateInformation()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string CompanyName = "Corporate" + appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999).ToString();
            string TaxIDNumber = GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"));
            appHandle.Set_field_value(CorporateInformationCompanyNameField, CompanyName);
            appHandle.Set_field_value(CorporateInformationTaxIDNumberField, TaxIDNumber);
            return CompanyName;
        }
        public virtual string GenerateRandomNumberByFormat(string InputFormat, string Delimiter = "-")
        {

            string Result = RandomNumberGenerator.GenerateRandomNumberByFormat(InputFormat, Delimiter);
            return Result;
        }

        public virtual void EnterEmailAndPhoneDetails()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(CorporateTelephonePhoneNumberField, GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_PHONE_NUMBER_FORMAT")));
            appHandle.Set_field_value(PrimaryContactPhoneNumberField, GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_PHONE_NUMBER_FORMAT")));
            appHandle.Set_field_value(PrimaryContactNameField, Data.Get("GLOBAL_ADDLINE1"));
            appHandle.Set_field_value(PrimaryContactEmailField, StartupConfiguration.EnvironmentDetails.UserMailID.ToString());
        }
        public virtual void EnterPrincipalAddress()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string Country = Data.Get("GLOBAL_ADDCOUNTRY");
            string state = Data.Get("GLOBAL_ADDSTATE");
            appHandle.Set_field_value(PrincipalAddressLine1Field, Data.Get("GLOBAL_ADDLINE1"));
            appHandle.Set_field_value(PrincipalAddressLine2Field, Data.Get("GLOBAL_ADDLINE2"));
            appHandle.Set_field_value(PrincipalAddressCityField, Data.Get("GLOBAL_CITY"));
            appHandle.SelectDropdownSpecifiedValue((object)PrincipalAddressCountryDropdown, Country);
            appHandle.SelectDropdownSpecifiedValue((object)PrincipalAddressStateDropdown, state);
            appHandle.Set_field_value(PrincipalAddressZIPCOdeField, Data.Get("GLOBAL_ADDZIP"));
        }
        public virtual void EnterMailingAddress()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string Country = Data.Get("GLOBAL_ADDCOUNTRY");
            string state = Data.Get("GLOBAL_ADDSTATE");
            appHandle.Set_field_value(MailingAddressLine1Field, Data.Get("GLOBAL_ADDLINE1"));
            appHandle.Set_field_value(MailingAddressLine2Field, Data.Get("GLOBAL_ADDLINE2"));
            appHandle.Set_field_value(MailingAddressCityField, Data.Get("GLOBAL_CITY"));
            appHandle.SelectDropdownSpecifiedValue((object)MailingAddressCountryDropdown, Country);
            appHandle.SelectDropdownSpecifiedValue((object)MailingAddressStateDropdown, state);
            appHandle.Set_field_value(MailingAddressZIPCodeField, Data.Get("GLOBAL_ZIPCODE_19355"));
        }

        public virtual void SelectAddressSameAsPrincipalAddressRadioButton(string strYesOrNo)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            strYesOrNo = strYesOrNo.ToUpper();
            if (strYesOrNo.Contains("Yes".ToUpper()))
            {
                appHandle.Set_radiobutton(MailingAddressSaemAsPrincipalPlaceOfBusinessYesRadioButton);
            }
            else
            {
                appHandle.Set_radiobutton(MailingAddressSaemAsPrincipalPlaceOfBusinessNoRadioButton);
            }
        }

        public virtual void SelectAllowOnlineAccessRadioButton(string strYesOrNo)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            strYesOrNo = strYesOrNo.ToUpper();
            if (strYesOrNo.Contains("Yes".ToUpper()))
            {
                appHandle.Set_radiobutton(OnlineAccessAllowOnlineAccessYesRadioButton);
            }
            else
            {
                appHandle.Set_radiobutton(OnlineAccessAllowOnlineAccessNoRadioButton);
            }
        }

        public virtual void EnterOnlineAccessDetails()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string UserID = StartupConfiguration.EnvironmentDetails.UserFirstName;
            string sRandmData = appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999).ToString();
            UserID = UserID.Substring(0, 4) +appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 3).ToString().ToUpper()+ sRandmData;
            appHandle.Set_field_value(OnlineAccessUserIDField, UserID);
            string PasswordStatus = Data.Get("GLOBAL_PASSWORD_STATUS_ACTIVE");
            string TemporaryPasswordAction = Data.Get("GLOBAL_TEMPORARY_PASSWORD_ACTION");
            appHandle.SelectDropdownSpecifiedValue(OnlineAccessPasswordStatusDropdown, PasswordStatus);
            appHandle.SelectDropdownSpecifiedValue(OnlineAccessTemporaryPasswordActionDropdown, TemporaryPasswordAction);
            appHandle.Set_field_value(OnlineAccessNewPasswordField, Data.Get("GLOBAL_ONLINE_ACCESS_PASSWORD"));
            appHandle.Set_field_value(OnlineAccessConfirmPasswordField, Data.Get("GLOBAL_ONLINE_ACCESS_PASSWORD"));
            appHandle.Set_field_value(OnlineAccessPasswordHintField, Data.Get("GLOBAL_PASSWORD_HINT"));
            appHandle.Set_field_value(OnlineAccessSecretWordField, Data.Get("GLOBAL_SECRET_WORD"));
        }

        public virtual void EnterSecretQuestionDetails()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string SecretQuestion = Data.Get("GLOBAL_SECRETQUESTION");
            appHandle.SelectDropdownSpecifiedValue((object)SecretQuestionDropdown, SecretQuestion);
            appHandle.Set_field_value(SecretQuestionAnswerField, Data.Get("GLOBAL_SECRETANSWER"));
        }
        public virtual void SelectCreateATelePhonebankingPINRadioButton(string strYesOrNo)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            strYesOrNo = strYesOrNo.ToUpper();
            if (strYesOrNo.Contains("Yes".ToUpper()))
            {
                appHandle.Set_radiobutton(TelephoneBankingPINCreateATelephoneBankingPINYesRadioButton);
                EnterTelePhoneBankingPINDetails();
            }
            else
            {
                appHandle.Set_radiobutton(TelephoneBankingPINCreateATelephoneBankingPINNoRadioButton);
            }
        }
        public virtual void EnterTelePhoneBankingPINDetails()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(TelephoneBankingPINNewPINField, Data.Get("TEL_PIN_CORP_CUST"));
            appHandle.Set_field_value(TelephoneBankingPINConfirmPINField, Data.Get("TEL_PIN_CORP_CUST"));
        }
        public virtual void EnterFATCADetails()
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle.SelectCheckBox(cbkSubjecttoFATCAWithholding);
                appHandle.SelectDropdownSpecifiedValue(drpFATCAExemptionCode, (string)Data.Get("GLOBAL_FATCAEXEMPTIONCODE_12"));
                appHandle.SelectDropdownSpecifiedValue(drpFATCA1042SReportingChapter4Status, (string)Data.Get("GLOBAL_FATCA_1042S_REPORTING_CHAPTER4_STATUS_INDIVIDUAL"));
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        public virtual void ClickOnBeneficiaryAddButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnBeneficiaryAdd);
                appHandle.ClickObject(btnBeneficiaryAdd);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        public virtual bool VerifyCorporateCustomerCreationSuccess()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_APPLICATION_SUCCESSFULLY_PROCESSED")))
            {
                Result = true;
            }

            return Result;
        }
        public virtual string GetMessageText()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string result = "";
            result = appHandle.GetObjectText(MSGOBJ);
            return result;
        }
        public virtual void VerifyCountryofIncorporationDropdownCreateCorporateCustomerPage(string CountryNames)
        {
            CountryNames = CountryNames + "|";
            string[] arr = CountryNames.Split('|');
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpCorporateInformationCountryofIncorporation);
            if (string.IsNullOrEmpty(arr[1]))
            {
                CountryNames = arr[0];
                appHandle.SelectDropdownSpecifiedValue(drpCorporateInformationCountryofIncorporation, (string)CountryNames);
                if (appHandle.CheckValueInDropdown(drpCorporateInformationCountryofIncorporation, CountryNames))
                {
                    appHandle.ScrollToObject(drpCorporateInformationCountryofIncorporation);
                    Report.Info(CountryNames + " is available in Country of Incorporation dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                }
                else
                {
                    Report.Fail(CountryNames + " is available in Country of Incorporation dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle, true);
                }
            }
            else
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    appHandle.SelectDropdownSpecifiedValue(drpCorporateInformationCountryofIncorporation, (string)arr[i]);
                    if (appHandle.CheckValueInDropdown(drpCorporateInformationCountryofIncorporation, arr[i]))
                    {
                        appHandle.ScrollToObject(drpCorporateInformationCountryofIncorporation);
                        Report.Info(arr[i] + " is available in Country of Incorporation dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                    }
                    else
                    {
                        Report.Fail(arr[i] + " is not available Country of Incorporation dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle, true);
                    }
                }
            }

        }
        public virtual void VerifyPrincipalPlaceofBusinessCountryDropdownCreateCorporateCustomerPage(string CountryNames)
        {
            CountryNames = CountryNames + "|";
            string[] arr = CountryNames.Split('|');

            if (string.IsNullOrEmpty(arr[1]))
            {
                CountryNames = arr[0];
                appHandle.SelectDropdownSpecifiedValue(PrincipalAddressCountryDropdown, (string)CountryNames);
                if (appHandle.CheckValueInDropdown(PrincipalAddressCountryDropdown, CountryNames))
                {
                    appHandle.ScrollToObject(PrincipalAddressCountryDropdown);
                    Report.Info(CountryNames + " is available in Principal Place of Business Country dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                }
                else
                {
                    Report.Fail(CountryNames + " is available in Principal Place of Business Country dropdown  in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle, true);
                }
            }
            else
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    appHandle.SelectDropdownSpecifiedValue(PrincipalAddressCountryDropdown, (string)arr[i]);
                    if (appHandle.CheckValueInDropdown(PrincipalAddressCountryDropdown, arr[i]))
                    {
                        appHandle.ScrollToObject(PrincipalAddressCountryDropdown);
                        Report.Info(arr[i] + " is available in Principal Place of Business Country dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                    }
                    else
                    {
                        Report.Fail(arr[i] + " is not available Principal Place of Business Country dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle, true);
                    }
                }
            }

        }
        public virtual void VerifyMailingAddressCountryDropdownCreateCorporateCustomerPage(string CountryNames)
        {
            this.SelectAddressSameAsPrincipalAddressRadioButton(Data.Get("No"));
            CountryNames = CountryNames + "|";
            string[] arr = CountryNames.Split('|');

            if (string.IsNullOrEmpty(arr[1]))
            {
                CountryNames = arr[0];
                appHandle.SelectDropdownSpecifiedValue(MailingAddressCountryDropdown, (string)CountryNames);
                if (appHandle.CheckValueInDropdown(MailingAddressCountryDropdown, CountryNames))
                {
                    appHandle.ScrollToObject(MailingAddressCountryDropdown);
                    Report.Info(CountryNames + " is available in Mailing Address Country dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                }
                else
                {
                    Report.Fail(CountryNames + " is available in Mailing Address Country dropdown  in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle, true);
                }
            }
            else
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    appHandle.SelectDropdownSpecifiedValue(MailingAddressCountryDropdown, (string)arr[i]);
                    if (appHandle.CheckValueInDropdown(MailingAddressCountryDropdown, arr[i]))
                    {
                        appHandle.ScrollToObject(MailingAddressCountryDropdown);
                        Report.Info(arr[i] + " is available in Mailing Address Country dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                    }
                    else
                    {
                        Report.Fail(arr[i] + " is not available Mailing Address Country dropdown in Create Corporate Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle, true);
                    }
                }
            }

        }
        public virtual void EnterPrincipalAddress_Country_CZ()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            appHandle.Set_field_value(PrincipalAddressLine1Field, Data.Get("CITYCZ") + " Manson");
            appHandle.Set_field_value(PrincipalAddressLine2Field, Data.Get("Prague Building"));
            appHandle.Set_field_value(PrincipalAddressCityField, Data.Get("CITYCZ"));
            appHandle.SelectDropdownSpecifiedValue(PrincipalAddressCountryDropdown, (string)Data.Get("CZ - CZECHIA"));
            appHandle.Set_field_value(PrincipalAddressZIPCOdeField, Data.Get("ZIPCODE_CZ"));
            Report.Info("Principal business address with Country code " + Data.Get("CZ - CZECHIA") + " is entered successfully.", "CZ_Principal_Addr", "true", appHandle);
        }
        public virtual void EnterPrincipalAddress_Country_TF()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            appHandle.Set_field_value(PrincipalAddressLine1Field, Data.Get("CITYTF") + " Manson");
            appHandle.Set_field_value(PrincipalAddressLine2Field, Data.Get("CITYTF") + " Building");
            appHandle.Set_field_value(PrincipalAddressCityField, Data.Get("CITYTF"));
            appHandle.SelectDropdownSpecifiedValue(PrincipalAddressCountryDropdown, (string)Data.Get("TF - FRENCH SOUTHERN TERRITORIES"));
            appHandle.Set_field_value(PrincipalAddressZIPCOdeField, Data.Get("ZIPCODE_TF"));
            Report.Info("Principal business address with Country code " + Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + " is entered successfully.", "FT_Principal_Addr", "true", appHandle);
        }
        public virtual void EnterPrincipalAddress_Country_VA()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            appHandle.Set_field_value(PrincipalAddressLine1Field, Data.Get("CITYVA") + " Manson");
            appHandle.Set_field_value(PrincipalAddressLine2Field, Data.Get("CITYVA") + " Building");
            appHandle.Set_field_value(PrincipalAddressCityField, Data.Get("CITYVA"));
            appHandle.SelectDropdownSpecifiedValue(PrincipalAddressCountryDropdown, (string)Data.Get("VA - HOLY SEE"));
            appHandle.Set_field_value(PrincipalAddressZIPCOdeField, Data.Get("ZIPCODE_VA"));
            Report.Info("Principal business address with Country code " + Data.Get("VA - HOLY SEE") + " is entered successfully.", "VA_Principal_Addr", "true", appHandle);
        }
        public virtual void EnterPrincipalAddress_Country_WF()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            appHandle.Set_field_value(PrincipalAddressLine1Field, Data.Get("CITYWF") + " Manson");
            appHandle.Set_field_value(PrincipalAddressLine2Field, Data.Get("CITYWF") + " Building");
            appHandle.Set_field_value(PrincipalAddressCityField, Data.Get("CITYWF"));
            appHandle.SelectDropdownSpecifiedValue(PrincipalAddressCountryDropdown, (string)Data.Get("WF - WALLIS AND FUTUNA"));
            appHandle.Set_field_value(PrincipalAddressZIPCOdeField, Data.Get("ZIPCODE_WF"));
            Report.Info("Principal business address with Country code " + Data.Get("WF - WALLIS AND FUTUNA") + " is entered successfully.", "WF_Principal_Addr", "true", appHandle);
        }
        public virtual void EnterPrincipalAddress_Country_MK()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            appHandle.Set_field_value(PrincipalAddressLine1Field, Data.Get("CITYMK") + " Manson");
            appHandle.Set_field_value(PrincipalAddressLine2Field, Data.Get("CITYMK") + " Building");
            appHandle.Set_field_value(PrincipalAddressCityField, Data.Get("CITYMK"));
            appHandle.SelectDropdownSpecifiedValue(PrincipalAddressCountryDropdown, (string)Data.Get("MK - NORTH MACEDONIA"));
            appHandle.Set_field_value(PrincipalAddressZIPCOdeField, Data.Get("ZIPCODE_MK"));
            Report.Info("Principal business address with Country code " + Data.Get("MK - NORTH MACEDONIA") + " is entered successfully.", "MK_Principal_Addr", "true", appHandle);
        }
        public virtual void EnterPrincipalAddressByVaildZipCode(string city,string state,string zipCode)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            appHandle.Set_field_value(PrincipalAddressLine1Field, Data.Get("SeaLine1"));
            appHandle.Set_field_value(PrincipalAddressLine2Field, Data.Get("SeaLine2") + " Building");
            appHandle.Set_field_value(PrincipalAddressCityField, city);
            appHandle.SelectDropdownSpecifiedValue(PrincipalAddressCountryDropdown,(string)Data.Get("US - UNITED STATES OF AMERICA"));
            appHandle.SelectDropdownSpecifiedValue(PrincipalAddressStateDropdown, (string)state);
            appHandle.Set_field_value(PrincipalAddressZIPCOdeField, zipCode);
            Report.Info("Principal business address with Vaild ZipCode is entered successfully.", "MK_Principal_Addr", "true", appHandle);
        }
        public virtual void SelectCountryOfIncorporationOtherThanUS(string Country)
        {
            appHandle.WaitUntilElementExists(drpCorporateInformationCountryofIncorporation);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpCorporateInformationCountryofIncorporation,Country);
        }
        public virtual string UpdateW8TypeforCorporate(string W8Type=null)
        {
            appHandle.WaitUntilElementExists(drpW8Type);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpW8Type,W8Type);
            return W8Type;
        }
        public virtual void ClickOnBackButton()
        {
            appHandle.WaitUntilElementExists(buttonBack);
            appHandle.ClickObjectViaJavaScript(buttonBack);
        }
         public virtual bool VerifyCorporateCustomerVerificationPage()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (appHandle.GetObjectText(tableCreateCustomer).Equals(Data.Get("Please verify the following information")))
            {
                Result = true;
            }

            return Result;
        }
        public virtual void UpdateW8BENEdetails(string ClaimDate,string CollectedDate,string VerificationDate,string GIIN=null)
        {
        
            appHandle.WaitUntilElementExists(drpw8BENEFATCAStatus);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpw8BENEFATCAStatus,Data.Get("GLOBAL_FATCASTATUS_REPORTING_MODEL1_FFI"));
            appHandle.Set_field_value(txtGIIN,GIIN);
            appHandle.Set_field_value(txtGIINClaimDate,ClaimDate);
            appHandle.Set_field_value(txtGIINCollectionDate,CollectedDate);
            appHandle.Set_field_value(txtGIINVerificationDate,VerificationDate);
            appHandle.SelectCheckBox(chkboxSubstantialUSOwners);

        }
        public virtual void ClickOnAddButton()
        {
            appHandle.WaitUntilElementExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
        }

        public virtual void UpdateDetailsOfSubstantialOwner()
        {
            string TIN= RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
           appHandle.SelectCheckBox(ckbIsthisanOrganization);
           appHandle.Set_field_value(txtOwnerName,"FIS");
           appHandle.Set_field_value(txtTIN,TIN);
           appHandle.Set_field_value(txtPoO,"100");
           appHandle.SelectCheckBox(chkboxW9onFile);
           appHandle.Set_field_value(txtOwnerAddress,"FIS");
           appHandle.Set_field_value(txtOwnwerCity,"Collegeville");
           appHandle.SelectDropdownSpecifiedValueByPartialText(drpOwnerCountry,(string)Data.Get("US - United States"));
           appHandle.SelectDropdownSpecifiedValueByPartialText(drpOwnerState,(string)Data.Get("PA - PENNSYLVANIA"));
           appHandle.Set_field_value(txtOwnerZipCode,Data.Get("GLOBAL_ZIPCODE_19355"));
       }
        public virtual void ClickOnSubstantialOwnerAddButton()
        {
            appHandle.WaitUntilElementExists(buttonSubstantialOwnerAdd);
            appHandle.ClickObjectViaJavaScript(buttonSubstantialOwnerAdd);
        }
        public virtual string GetObjectValueOfW8Type()
        {
            string W8BENType=appHandle.GetDropdownSelectedValue(drpW8Type);
            return W8BENType;
        }
        public virtual bool ClickOnGIINAppliedForCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chkboxAppliedFor))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(chkboxAppliedFor)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(chkboxAppliedFor);
                        if (appHandle.CheckCheckBoxChecked(chkboxAppliedFor))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(chkboxAppliedFor) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(chkboxAppliedFor);
                        if (appHandle.CheckCheckBoxChecked(chkboxAppliedFor) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }
        






    }
}