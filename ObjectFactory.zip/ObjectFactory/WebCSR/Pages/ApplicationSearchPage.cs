using GTS_OSAF.CoreLibs;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class ApplicationSearchPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string rbtnTaxId = "Xpath;//input[@type='radio'][@value='TAXID']";
        public static string rbtnApplicationId = "Xpath; //input[@type='radio'][@value='APPID']";
        public static string rbtnEmailId = "Xpath;//input[@type='radio'][@value='PEMAIL']";
        public static string txtTaxId = "Xpath;//input[@name='taxIdNumber']";
        
   
    }
}