using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using System;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DomesticPaymentAddPaymentOrderPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string checkboxHoldAutoPlaced = "XPath;//*[contains(text(),'Hold Auto Placed')]/following-sibling::*/descendant::input";
        private static string dropdownAmountCurrency = "XPath;//*[contains(text(),'Amount:')]/following-sibling::*/descendant::select";
        private static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        public static string AdditionalDetailsHoldAutoPlaced = "Name;EFTPAY_HLDAUTO";
        public static string AdditionalDetailsPriorityCheckbox = "Name;EFTPAY_PRI";
        public static string AdditionalDetailsCheckSerialNumber = "Name;EFTPAY_CHKNO";
        public static string AdditionalDetailsSpecificDescription = "Name;EFTPAY_SPECIFIC";
        public static string AmountDetailsAmountField = "Name;EFTPAY_AMOUNT";
        public static string OccurenceEffectiveDate = "Name;EFTPAY_EFD";
        public static string RecipientAccountAccountField = "Name;EFTPAY_RECACCT";
        public static string RecipientAccountInstitutionField = "Name;EFTPAY_RECINST";
        public static string AdditionalDetailsOverrideStopCheckbox = "Name;EFTPAY_OVSTOP";
        public static string AdditionalDetailsAuthorizationReceivedDropDown = "Name;EFTPAY_CIFTYPEACHAUTH";
        public static string AmountDetailsAmountTypeDropDown = "Name;EFTPAY_AMTTYP";
        public static string AdditionalDetailsEconomicActivityCode = "Name;EFTPAY_CONSTANT";
        public static string RecipientAccountAccountType = "Name;EFTPAY_RECTYPE";
        public static string SubmitBtn = "Name;submit";
        private static string ButtonSearchInstitution = "XPath;//*[contains(text(),'Institution')]/following-sibling::*/descendant::a";
        private static string ButtonSearch = "XPath;//*[@value='Search']";
        private static string txtRoutingNumber = "XPath;//*[contains(text(),'Routing Number')]/following-sibling::*/input";
        private static string txtInstitutionName = "XPath;//*[contains(text(),'Institution Name')]/following-sibling::*/input";
        private static string tableBanksFound = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";
        private static string txtRicipientAccount = "XPath;//*[contains(text(),'Account:')]/following-sibling::*/input[@type='text']";
        private static string dropdownAccountType = "XPath;//*[contains(text(),'Account Type')]/following-sibling::*/select";
        private static string txtRicipientName = "XPath;//*[contains(text(),'Recipient Name')]/following-sibling::*/input";
        private static string txtAmount = "XPath;//*[contains(@name,'EFTPAY_AMOUNT')]";
        private static string txtEffectiveDate = "XPath;//*[contains(@name,'EFTPAY_EFD')]";
        private static string checkboxPriority = "XPath;//*[contains(@name,'EFTPAY_PRI')]";
        private static string buttonSubmit = "XPath;//*[contains(@value,'Submit')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string dropdownEcocomicActivityCode = "XPath;//*[contains(text(),'Economic Activity Code')]/following-sibling::*/descendant::select";
        private static string txtSpecificDescription = "XPath;////*[contains(text(),'Specific Description')]/following-sibling::*/descendant::input";
        private static string checkboxIsThisBusinessAccount = "XPath;//*[contains(text(),'Is this a Business Account?')]/following-sibling::*/descendant::input";
        private static string txtInstitution = "XPath;//*[contains(text(),'Institution')]/following-sibling::*/input";
        private static string txtFrequency = "Xpath;//*[@name='EFTPAY_FREQUENCY']";
        private static string txtEndDate ="XPath;//*[@name='EFTPAY_EXPDT']";

        /// <summary>
        /// This method is used to add collection order
        /// </summary>
        /// <returns></returns>     
        /// <param name = "TransferDetails"></param>
        /// TransferDetails[0] = "1"        'RecipientAccountInstitutionField'
        /// TransferDetails[1] = "823648"   'RecipientAccountAccountField'
        /// TransferDetails[2] = "1 - DDA Account"  'RecipientAccountAccountType'
        /// TransferDetails[3] = "1 - Fixed Amount" 'AmountDetailsAmountTypeDropDown'
        /// TransferDetails[4] = "1000" 'AmountDetailsAmountField'
        /// TransferDetails[5] = "02/01/2015" 'OccurenceEffectiveDate'
        /// TransferDetails[6] = "GLOBAL_ON" 'To click the PriorityCheckbox' otherwise TransferDetails[6]=""
        /// TransferDetails[7] = "GLOBAL_ON" 'To click the OverrideStopCheckbox' otherwise TransferDetails[7]=""
        /// TransferDetails[8] = "GLOBAL_ON" 'To click the HoldAutoPlacedCheckbox' otherwise TransferDetails[8]=""
        /// TransferDetails[9] = "21 - DDA Return - Credit" 'EconomicActivityCodeDropDown'
        /// TransferDetails[10] = "Telephone" 'AuthorizationReceivedDropDown'
        /// TransferDetails[11] = "Test" 'SpecificDescription'
        public virtual bool AddCollectionOrder(string[] TransferDetails)
        {
            bool bCheck = false;
            try
            {
                appHandle.Set_field_value(RecipientAccountInstitutionField, TransferDetails[0]);
                appHandle.Set_field_value(RecipientAccountAccountField, TransferDetails[1]);
                appHandle.SelectDropdownSpecifiedValue(RecipientAccountAccountType, TransferDetails[2]);
                appHandle.SelectDropdownSpecifiedValue(AmountDetailsAmountTypeDropDown, TransferDetails[3]);
                appHandle.Set_field_value(AmountDetailsAmountField, TransferDetails[4]);
                appHandle.Set_field_value(OccurenceEffectiveDate, TransferDetails[5]);
                if (TransferDetails[6] == "GLOBAL_ON")
                {
                    appHandle.SelectCheckBox(AdditionalDetailsPriorityCheckbox);
                }
                if (TransferDetails[7] == "GLOBAL_ON")
                {
                    appHandle.SelectCheckBox(AdditionalDetailsOverrideStopCheckbox);
                }
                if (TransferDetails[8] == "GLOBAL_ON")
                {
                    appHandle.SelectCheckBox(AdditionalDetailsHoldAutoPlaced);
                }
                appHandle.SelectDropdownSpecifiedValue(AdditionalDetailsEconomicActivityCode, TransferDetails[9]);
                appHandle.SelectDropdownSpecifiedValue(AdditionalDetailsAuthorizationReceivedDropDown, TransferDetails[10]);
                appHandle.Set_field_value(AdditionalDetailsSpecificDescription, TransferDetails[11]);
                appHandle.SelectButton(SubmitBtn);
                if (appHandle.CheckSuccessMessage(Data.Get("GLOBAL_ADD_ORDER_MSG")))
                {
                    bCheck = true;
                }

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;
        }
        public virtual void ClickOnSearchInstitutionButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ButtonSearchInstitution))
            {
                appHandle.SwitchWindow(SwitchInto.DEFAULT);
                appHandle.ClickObjectViaJavaScript(ButtonSearchInstitution);
                appHandle.SwitchWindow(SwitchInto.WINDOW);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(ButtonSearch);
            }
        }
        public virtual void ClickOnSearchButton()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ButtonSearch))
            {
                appHandle.ClickObjectViaJavaScript(ButtonSearch);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableBanksFound);
            }
        }
        public virtual string SearchInstitutionByRoutingNumber(string RoutingNumber)
        {
            string InstitutionName = "";
            appHandle.Set_field_value(txtRoutingNumber, RoutingNumber);
            ClickOnSearchButton();
            Report.Info(RoutingNumber + " is displayed in Institution Search window.", "institutionname", "true", appHandle);
            InstitutionName = appHandle.GetObjectText(tableBanksFound + "/tr[1]/td[1]");
            appHandle.ClickObjectViaJavaScript(tableBanksFound + "/tr[1]/td[1]");
            appHandle.SwitchWindow(SwitchInto.DEFAULT);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(ButtonSearchInstitution);
            appHandle.Set_field_value(txtInstitution, RoutingNumber);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtRicipientAccount);
            return InstitutionName;
        }
        public virtual string SearchInstitutionByInstitutionName(string InstitutionName)
        {
            string temp = "";
            appHandle.Set_field_value(txtInstitutionName, InstitutionName);
            ClickOnSearchButton();

            Report.Info(InstitutionName + " is displayed in Institution Search window.", "institutionname", "true", appHandle);
            temp = appHandle.GetObjectText(tableBanksFound + "/descendant::*[text()='" + InstitutionName + "']/following-sibling::td[2]");
            appHandle.ClickObjectViaJavaScript(tableBanksFound + "/descendant::*[contains(text(),'" + InstitutionName + "')]");
            appHandle.SwitchWindow(SwitchInto.DEFAULT);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(ButtonSearchInstitution);
            appHandle.Set_field_value(txtInstitution, temp);
            return InstitutionName;
        }
        public virtual void EnterAmountInModifiedOrder(string Amount)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtAmount))
            {
                appHandle.Set_field_value(txtAmount, Amount);
            }
        }
        public virtual void EnterPOOrderDeails(string RecipientAccountNumber, string AccountType, string RicipientName, string Amount, bool IspriorityOnorOff, string EffectiveDate = "", string Currency = "", bool IsThisBusinessAccount = false, bool IsHoldAutoPlacedOnOrOFF = false, string EconomicActivityCode = "", string SpecificDescription = "")
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxIsThisBusinessAccount))
            {
                appHandle.Set_field_value(txtRicipientAccount, RecipientAccountNumber);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccountType, AccountType);
                if (IsThisBusinessAccount)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxIsThisBusinessAccount)) { }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxIsThisBusinessAccount);
                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxIsThisBusinessAccount) == false) { }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxIsThisBusinessAccount);
                    }
                }
                appHandle.Set_field_value(txtRicipientName, RicipientName);
                appHandle.Set_field_value(txtAmount, Amount);
                if (string.IsNullOrEmpty(Currency)) { }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAmountCurrency, Currency);
                }
                if (string.IsNullOrEmpty(EffectiveDate)) { }
                else
                {
                    appHandle.Set_field_value(txtEffectiveDate, EffectiveDate);
                }

                if (IspriorityOnorOff)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxPriority)) { }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxPriority);
                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxPriority) == false) { }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxPriority);
                    }
                }
                if (IsHoldAutoPlacedOnOrOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxHoldAutoPlaced)) { }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxHoldAutoPlaced);
                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxHoldAutoPlaced) == false) { }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxHoldAutoPlaced);
                    }
                }

                if (string.IsNullOrEmpty(EconomicActivityCode)) { }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownEcocomicActivityCode, EconomicActivityCode);
                }
                if (string.IsNullOrEmpty(SpecificDescription)) { }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(txtSpecificDescription, SpecificDescription);
                }

            }

        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);

            }
        }
        public virtual bool VerifyMessageInPaymentOrderPage(string sMessage)
        {
            bool Result = false;

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }
            return Result;
        }

        public static string ApplicationDate = new DomesticPaymentAddPaymentOrderPage().GetApplicationDate();
        public virtual string GetApplicationDate()
        {
            string result = "";

            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }

        public virtual void EnterSPODetails(string RecipientAccountNumber, string AccountType, string RicipientName, string Amount,string StartDate,string Frequency,string EndDate)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtRicipientAccount);
            appHandle.Set_field_value(txtRicipientAccount,RecipientAccountNumber);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccountType,AccountType);
            appHandle.Set_field_value(txtRicipientName,RicipientName);
            appHandle.Set_field_value(txtAmount,Amount);
            appHandle.Set_field_value(txtEffectiveDate,StartDate);
            appHandle.Set_field_value(txtFrequency,Frequency);
            appHandle.Set_field_value(txtEndDate,EndDate);

        }
    }
}