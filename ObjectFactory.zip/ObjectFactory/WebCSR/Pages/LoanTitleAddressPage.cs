using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class LoanTitleAddressPage
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string dropdownAccount = "Xpath;//*[@name='ACN_CID']";

        //Account Title
        public static string txtTitle = "Xpath;//*[@name='ACN_TITLE1']";
        //Mailing Address field
        public static string txtMailAddressLine1 = "Xpath;//*[@name ='ACNADDR_AD1']";
        public static string txtMailAddressLine2 = "Xpath;//*[@name ='ACNADDR_AD2']";
        public static string txtMailCity = "Xpath;//*[@name ='ACNADDR_CITY']";
        public static string dropdownMailCountry = "Xpath;//*[@name ='ACNADDR_CNTRY']";
        public static string dropdownMailState = "Xpath;//*[@name ='ACNADDR_STATE']";
        public static string txtMailZipCode = "Xpath;//*[@name ='ACNADDR_MZIP']";


        //Seasonal Mailing Address field
        public static string txtStartDate = "Xpath;//*[@name='SADDRACN_SADSD']";
        public static string txtEndDate = "Xpath;//*[@name='SADDRACN_SADED']";
        public static string txtAddressLine1="Xpath;//*[@name='SADDRACN_SAD1']";
        public static string txtAddressLine2 = "Xpath;//*[@name='SADDRACN_SAD2']";
        public static string txtAddressLine3 = "Xpath;//*[@name='SADDRACN_SAD3']";
        public static string txtTownship = "Xpath;//*[@name='SADDRACN_SLOC']";
        public static string txtCountry1 = "Xpath;//*[@name='SADDRACN_SCOUNTY']";
        public static string txtCity = "Xpath;//*[@name='SADDRACN_SCITY']";
        public static string dropdownCountry2 = "Xpath;//*[@name='SADDRACN_SCNTRY']";

        public static string dropdownState = "Xpath;//*[@name='SADDRACN_SSTATE']";
        public static string txtZipCode = "Xpath;//*[@name='SADDRACN_SZIP']";

        // off Season Mailing Address
        public static string txtOffAddress1 = "Xpath;//*[@name='SADDRACN_NSAD1']";
        public static string txtOffAddress2 = "Xpath;//*[@name='SADDRACN_NSAD2']";
        public static string txtOffAddress3 = "Xpath;//*[@name='SADDRACN_NSAD3']";
        public static string txtOffTownship = "Xpath;//*[@name='SADDRACN_NSLOC']";
        public static string txtOffCountry = "Xpath;//*[@name='SADDRACN_NSCOUNTY']";
        public static string txtOffCity = "Xpath;//*[@name='SADDRACN_NSCITY']";
        public static string dropdownOffCountry ="Xpath;//*[@name='SADDRACN_NSCNTRY']";
        public static string dropdownOffState ="Xpath;//*[@name='SADDRACN_NSSTATE']";
        public static string txtOffZipCode = "Xpath;//*[@name='SADDRACN_NSZIP']";
        public static string buttonSubmit = "Xpath;//*[@name='submit']";
        public static string buttonCancel ="Xpath;//*[@name='cancel']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";

        private  static string txtCustomerShortName = "Xpath;//input[@name='ACN_LNM']";  
        
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";

        public virtual void SelectAccountFromAccountsDropdown(string AccountNumber)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccount, AccountNumber);
        }


        public virtual void ModifySeasonalMailingAddress(string StartDate,string EndDate,string AddressLine1,string AddressLine2,string City,string Country,string State,string ZipCode)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtStartDate);
            appHandle.Set_field_value(txtStartDate,StartDate);
            appHandle.Set_field_value(txtEndDate,EndDate);
            appHandle.Set_field_value(txtAddressLine1,AddressLine1);
            appHandle.Set_field_value(txtAddressLine2,AddressLine2);
            appHandle.Set_field_value(txtCity,City);
            appHandle.SelectDropdownSpecifiedValue(dropdownCountry2,(string)Country);
            appHandle.SelectDropdownSpecifiedValue(dropdownState,(string)State);
            appHandle.Set_field_value(txtZipCode,ZipCode);
        }

        public virtual void ModifyNonSeasonalMailingAddress(string OffAddressLine1,string OffAddressLine2,string OffCity,string OffCountry,string OffState,string OffZipcode)
        {
            appHandle.Set_field_value(txtOffAddress1,OffAddressLine1);
            appHandle.Set_field_value(txtOffAddress2,OffAddressLine2);
            appHandle.Set_field_value(txtOffCity,OffCity);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownOffCountry,(string)OffCountry);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownOffState,(string)OffState);
            appHandle.Set_field_value(txtOffZipCode,OffZipcode);
        }

        public virtual void DeleteSeasonalMailingAddress(string StartDate,string EndDate,string AddressLine1,string AddressLine2,string City,string ZipCode,int Country = 1,int State = 1)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtStartDate);
            appHandle.Set_field_value(txtStartDate,StartDate);
            appHandle.Set_field_value(txtEndDate,EndDate);
            appHandle.Set_field_value(txtAddressLine1,AddressLine1);
            appHandle.Set_field_value(txtAddressLine2,AddressLine2);
            appHandle.Set_field_value(txtCity,City);
            appHandle.SelectDropdownValueByIndex(dropdownCountry2,Country);
            appHandle.SelectDropdownValueByIndex(dropdownState,State);
            appHandle.Set_field_value(txtZipCode,ZipCode);
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
        }
        public virtual void ClickOnCancelButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCancel))
            {
                appHandle.ClickObjectViaJavaScript(buttonCancel);
            }
           
        }
        public virtual bool ValidateCustomerInfoUpdateMSG()
        {
            bool result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                result = true;
            }
 
            return result;
        }

        public virtual bool VerifySeasonalAddressErrorMSG()
        {
            bool result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("SeasonalAddressErrorMsg")))
            {
                result = true;
            }
 
            return result;
        }
        public virtual bool VerifySeasonalAddressByFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "AddressLine1":
                        if (appHandle.GetSpecifiedObjectAttribute(txtAddressLine1, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "City":
                        if (appHandle.GetSpecifiedObjectAttribute(txtCity, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "Country":
                        if (appHandle.CheckValueInDropdown(dropdownCountry2,expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "State":
                        if (appHandle.CheckValueInDropdown(dropdownState,expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;    

                        case "ZipCode":
                        if (appHandle.GetSpecifiedObjectAttribute(txtZipCode, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;    
        
        
    
                }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }


            return result;
        }
        public virtual bool VerifyNonSeasonalAddressByFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "AddressLine1":
                        if (appHandle.GetSpecifiedObjectAttribute(txtOffAddress1, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "City":
                        if (appHandle.GetSpecifiedObjectAttribute(txtOffCity, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "Country":
                        if (appHandle.CheckValueInDropdown(dropdownOffCountry, "value").Equals(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "State":
                        if (appHandle.CheckValueInDropdown(dropdownOffState, "value").Equals(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;    

                        case "ZipCode":
                        if (appHandle.GetSpecifiedObjectAttribute(txtOffZipCode, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;    
        
        
    
                }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }


            return result;
        }
        public virtual bool VerifyMailingAddressByFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "AddressLine1":
                        if (appHandle.GetSpecifiedObjectAttribute(txtMailAddressLine1, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "City":
                        if (appHandle.GetSpecifiedObjectAttribute(txtMailCity, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "Country":
                        if (appHandle.GetSpecifiedObjectAttribute(dropdownMailCountry, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "State":
                        if (appHandle.GetSpecifiedObjectAttribute(dropdownMailState, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;    

                        case "ZipCode":
                        if (appHandle.GetSpecifiedObjectAttribute(txtMailZipCode, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;    
        
        
    
                }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }


            return result;
        }


        public virtual void EnterCustomerShortName(string CustomerShortName)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCustomerShortName);
            appHandle.Set_field_value(txtCustomerShortName,CustomerShortName);
      
        }


        public virtual bool VerifyMessageTitleAddressPage(string sMessage)
        {
     		bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
		}



    }



        } 





         
    


