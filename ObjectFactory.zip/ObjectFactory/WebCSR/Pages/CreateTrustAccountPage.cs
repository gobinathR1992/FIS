using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class CreateTrustAccountPage
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string buttonSubmit="XPath;//input[@name='_eventId_submit']";
        public static string buttonContinue="XPath;//input[@name='_eventId_continue']";
        public static string txtopeningDate="XPath;//input[@name='accounts[3021][0].openingDate']";
        public static string txtopeningDeposit="XPath;//input[@name='accounts[3021][0].originalAmount']";    


        public virtual void selectRelationshipForTrustee(string relationshipname)
        {
            string RelationshipCodeTable = "XPath;//*[text()='"+relationshipname+"']/ancestor::tr[1]/following-sibling::*[1]/descendant::tbody[1]";
            int count = appHandle.GetRowCountfromList(RelationshipCodeTable);
            for (int a = 1; a <= count; a++)
            {
                string temp = appHandle.GetObjectText(RelationshipCodeTable + "/tr[" + a + "]");
                if (temp.Contains(relationshipname))
                {
                    appHandle.ClickObjectViaJavaScript("XPath;//*[text()='Deposit Account Relationship']/ancestor::tr[1]/following-sibling::*[1]/descendant::tbody[1]/tr[" + a + "]/descendant::input[@type='radio']");
                }
            }            


        }

        public virtual void selectproductnumber(string prodtype)
        {
            string dynobj="XPath;//*[text()='"+prodtype+"']/../preceding-sibling::td/select";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynobj);
            appHandle.SelectDropdownSpecifiedValue(dynobj,"1");
            
        }

        public virtual string create_trust_account(string reltionship,string trustprodtype,string openingdeposit,string openingdate="")
        {
            string dynobj="XPath;//*[contains(text(),'Account Number')]/./following-sibling::td";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObject(buttonSubmit);
            selectRelationshipForTrustee(reltionship);
            appHandle.ClickObject(buttonContinue);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonContinue);
            appHandle.ClickObject(buttonContinue);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonContinue);
            selectproductnumber(trustprodtype);
            appHandle.ClickObject(buttonContinue);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.Set_field_value(txtopeningDate,openingdate);
            appHandle.Set_field_value(txtopeningDeposit,openingdeposit);
            appHandle.ClickObject(buttonSubmit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonContinue);
            appHandle.ClickObject(buttonContinue);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObject(buttonSubmit);
            appHandle.CheckSuccessMessage(Data.Get("GLOBAL_CONFIRMATION_MESSAGE"));
            string trustaccnum=appHandle.GetObjectText(dynobj);
            return trustaccnum.Trim();

        }

    }
}