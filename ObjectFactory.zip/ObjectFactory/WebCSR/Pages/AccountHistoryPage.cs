﻿using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountHistoryPage
    {
        public static WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        //private static string AccountHistoryTab = "Xpath;//td[text()='Account History']";
        //private static string AccountHistoryTable = "Xpath;//table[contains(@id,'history-list')]";
        private static string AccountHistoryTable = "XPath;//table[@id='posted-transactions-list']/tbody";
        //private static string AccountHistoryTable = "history-list";
        private static string AccountHistoryTab = "Xpath;//td[@class='summaryTableHeading'][contains(text(),'Account History')]";
        private static string AccountHistoryHeader = "Xpath;//h1[text()='Account History']";
        //private static string AdvancedSearchImage = "Xpath;//h2/img[@src='/WebCSR-qarellx2/images/arrow-right.png']";
        private static string Advanced_Search_Tab = "Xpath;//h2[contains(text(),'Advanced Search')]";
        private static string TransactionTypeAllRadio = "Xpath;//input[@type='radio'][@name='transactionType'][@value='3']";
        private static string AccountSummaryTab = "Xpath;//td[text()='Account Summary']";
        private static string AccountSummaryHeader = "Xpath;//h1[text()='Account Information']";
        private static string TitleAddressTab = "Xpath;//td[text()='Title/Address']";
        private static string TitleAddressHeader = "Xpath;//h1[text()='Title/Address']";
        private static string InterestTab = "Xpath;//td[text()='Interest']";
        private static string InterestPageHeader = "Xpath;//h1[text()='Balances']";
        private static string PaymentTab = "Xpath;//td[text()='Payment']";
        private static string PaymentPageHeader = "Xpath;//h1[text()='Payment Snapshot']";
        private static string AdjustablePaymentTab = "Xpath;//td[text()='Adjustable Payment/Rate']";
        private static string AdjustablePaymentPageHeader = "Xpath;//h1[text()='Adjustable Rate Calculation']";
        private static string TransactionProcessingTab = "Xpath;//td[text()='Transaction Processing']";
        private static string TransactionProcessingPageHeader = "Xpath;//h1[text()='Transaction Processing']";
        private static string DelinquencyTab = "Xpath;//td[text()='Delinquency']";
        private static string DelinquencyPageHeader = "Xpath;//h1[text()='Payment Performance']";
        private static string CreditCardTab = "Xpath;//td[text()='Credit Card']";
        private static string CreditCardPageHeader = "Xpath;//h2[text()='Credit Card Options']";
        private static string CollateralTab = "Xpath;//td[text()='Collateral']";
        private static string CollateralPageHeader = "Xpath;//h1[text()='Collateral Balances']";
        private static string LoanFeesTab = "Xpath;//td[text()='Loan Fees']";
        private static string LoanFeesPageHeader = "Xpath;//h1[text()='Net Deferred Fees']";
        private static string RenewalTab = "Xpath;//td[text()='Renewal']";
        private static string RenewalPageHeader = "Xpath;//h1[text()='Net Deferred Fees']";
        private static string MaturityTab = "Xpath;//td[text()='Maturity/Payoff']";
        private static string MaturityPageHeader = "Xpath;//h1[text()='Maturity/Payoff']";
        private static string USRegulatoryTab = "Xpath;//td[text()='U.S. Regulatory']";
        private static string USRegulatoryPageHeader = "Xpath;//h1[text()='U.S. Regulatory']";
        private static string CollectionTab = "Xpath;//td[text()='Collections']";
        private static string CollectionPageHeader = "Xpath;//h1[text()='Collections']";
        private static string GeneralTab = "Xpath;//td[text()='Collections']";
        private static string GeneralPageHeader = "Xpath;//h1[text()='Collections']";
        private static string AccountDropdown = "XPath;//td/select[@name='accountNumber']";
        private static string tblAccHistoryAdvSearch = "XPath;//div[@id='history-list_wrapper']";
        private static string tblAccHistoryAdvSearchPopupWindow = "XPath;//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable']/div[2]/table/tbody/tr[3]/td/table/tbody";
        private static string btnHistoryPopupClose = "XPath;//span[text()='close']";
        private static string Submit_Button = "XPath;//input[@value='Submit']";
        private static string txtFromDate = "XPath;//*[@name='fromDate']";
        private static string txtToDate = "Xpath;//*[@name='toDate']";
        private static string TableSearchResults = "XPath;//th[text()='Date']/ancestor::*[@class='dataTables_scrollHead']/following-sibling::*[@class='dataTables_scrollBody']/table/tbody";
        private static string AdvancedSearchImage = "Xpath;//img[@src='/WebCSR-qacrt_gtmlx/images/arrow-right.png']";
        private static string radioNonMonetary = "Xpath;//input[@type='radio'][@name='transactionType'][@value='2']";
        private static string NonMonetary = "Xpath;//input[@type='radio'][@name='transactionType'][@value='2']";
        private static string blockAdvanced = "XPath;//table[@class='contentTable']/descendant::*[@id='advancedSearchBlock']";
        private static string txtConfirmationNumber = "XPath;//*[@name='confNumber']";
        private static string txtSpecificAmount = "XPath;//*[@name='amountSpecific']";
        private static string txtCheckNumber = "XPath;//*[@name='checkSpecific']";
    

        public virtual IList<object> ColumnsInTable(string objTableName)
        {
            //string tableName = "Xpath;id(\"" + objTableName + "\")tr";
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string body = objTableName.Substring(objTableName.LastIndexOf('/') + 1, 5);
            string header = objTableName.Substring(0, objTableName.LastIndexOf('/'));
            IList<object> col = (IList<object>)applicationHandle.GetColumnInTable(header);
            return col;
        }

        public virtual IList<object> RowValue(string objTableName)
        {
            //string tableName = "Xpath;id(\"" + objTableName + "\")";
            //string tableName = objTableName + "//tr";
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            IList<object> row = (IList<object>)applicationHandle.RowValueOFTable(objTableName);
            return row;
        }

        public virtual void NavigateToAccountHistoryPage(string AccNum)
        {
            applicationHandle.SelectObjectByMouse(AccountHistoryTab, MouseAction.CLICK);
            applicationHandle.Wait_for_object(AccountHistoryHeader, 20000);
            applicationHandle.SyncPage();
            applicationHandle.SelectDropdownSpecifiedValue(AccountDropdown, AccNum);
        }
        public virtual void navigate_to_account_history_page()
        {
            applicationHandle.ClickObject(AccountHistoryTab);
            applicationHandle.Wait_for_object(AccountHistoryHeader, 5);
            applicationHandle.SyncPage();
        }
        public virtual void check_specified_data_available_in_table1(string referenceValues)
        {
            //WebCSRPageFactory.WebCSRMasterPage.Check_Specified_Data_Available_In_Table(AccountHistoryTable, referenceValues);    
        }
        public virtual void check_specified_data_available_in_history_table(string referenceValues)
        {
            applicationHandle.ScrollToObject(Submit_Button);
            bool isExists = applicationHandle.CheckSpecifiedDataAvailableInTable(referenceValues, AccountHistoryTable);

            if (isExists)
            {
                Report.Pass("Successfully found the matching entry for reference values: <" + referenceValues + "> in Account History table.", "Account_History_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("No matching entry found for reference values: <" + referenceValues + "> in Account History table.", "Account_History_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }

        }

        public virtual bool check_text_exists_in_table(string referenceValue)
        {
            bool blnExists = applicationHandle.CheckTextExistsInTable(AccountHistoryTable, referenceValue);
            if (blnExists)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public virtual void ClickAdvancedSearch()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            //applicationHandle.ClickObject(AdvancedSearchImage);
            applicationHandle.ClickObject(Advanced_Search_Tab);
            applicationHandle.Wait_for_object(TransactionTypeAllRadio, 10);
        }
        public virtual void SelectTransactionTypeAll()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            applicationHandle.Set_radiobutton(TransactionTypeAllRadio);
            applicationHandle.SyncPage();
        }
        public virtual void ClickSetUpNewAccount(string sAppDate, string sLinkName)
        {
            try
            {
                applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                applicationHandle.SelectLinkInTable(tblAccHistoryAdvSearch, sLinkName, "Date;" + sAppDate + ";Description;" + sLinkName);
                applicationHandle.WaitUntilElementVisible(tblAccHistoryAdvSearchPopupWindow, 20);
                Report.Info("Requested link '" + sLinkName + "' is selected");

            }
            catch (KeyNotFoundException e)
            {
                Report.Info("Requested link '" + sLinkName + "' is not found and following exception logged: " + e.Message);
            }

        }
        public virtual void VerifyNewAccountDetails(string[] sTransactionDetailInfo)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string AccountNumber;
            string ReferenceNumber;
            string Description;
            string DataItem;
            string OldValue;
            string NewValue;
            string PostingDate;
            string UserId;
            string Branch;
            string Location;
            string TransactionComment;

            applicationHandle.GetColumnInTable(tblAccHistoryAdvSearchPopupWindow);
            if (sTransactionDetailInfo[0] != null)
                AccountNumber = sTransactionDetailInfo[0];
            else
                AccountNumber = "";

            if (sTransactionDetailInfo[1] != null)
                ReferenceNumber = sTransactionDetailInfo[1];
            else
                ReferenceNumber = "";

            if (sTransactionDetailInfo[2] != null)
                Description = sTransactionDetailInfo[2];
            else
                Description = "";

            if (sTransactionDetailInfo[3] != null)
                DataItem = sTransactionDetailInfo[3];
            else
                DataItem = "";
            if (sTransactionDetailInfo[4] != null)
                OldValue = sTransactionDetailInfo[4];
            else
                OldValue = "";

            if (sTransactionDetailInfo[5] != null)
                NewValue = sTransactionDetailInfo[5];
            else
                NewValue = "";

            if (sTransactionDetailInfo[6] != null)
                PostingDate = sTransactionDetailInfo[6];
            else
                PostingDate = "";

            if (sTransactionDetailInfo[7] != null)
                UserId = sTransactionDetailInfo[7];
            else
                UserId = "";

            if (sTransactionDetailInfo[8] != null)
                Branch = sTransactionDetailInfo[8];
            else
                Branch = "";

            if (sTransactionDetailInfo[9] != null)
                Location = sTransactionDetailInfo[9];
            else
                Location = "";

            if (sTransactionDetailInfo[10] != null)
                TransactionComment = sTransactionDetailInfo[10];
            else
                TransactionComment = "";

            bool retVal1 = applicationHandle.CheckSuccessMessage(AccountNumber);
            if (retVal1)
            {
                Report.Info("Account number '" + AccountNumber + "' is exist with reference to Account Number:");
            }

            else
            {
                Report.Info("Account number '" + AccountNumber + "' is not exist with reference to Account Number:");
            }
            bool retVal2 = applicationHandle.CheckSuccessMessage(ReferenceNumber);
            if (retVal2)
            {
                Report.Info("ReferenceNumber '" + ReferenceNumber + "' is exist with reference to ReferenceNumber:");
            }

            else
            {
                Report.Info("ReferenceNumber '" + ReferenceNumber + "' is not exist with reference to ReferenceNumber:");
            }
            bool retVal3 = applicationHandle.CheckSuccessMessage(Description);
            if (retVal3)
            {
                Report.Info("Description '" + Description + "' is exist with reference to Description:");
            }

            else
            {
                Report.Info("Description '" + Description + "' is not exist with reference to Description:");
            }
            bool retVal4 = applicationHandle.CheckSuccessMessage(DataItem);
            if (retVal4)
            {
                Report.Info("DataItem '" + DataItem + "' is exist with reference to DataItem:");
            }

            else
            {
                Report.Info("DataItem '" + DataItem + "' is not exist with reference to DataItem:");
            }
            bool retVal5 = applicationHandle.CheckSuccessMessage(OldValue);
            if (retVal5)
            {
                Report.Info("OldValue '" + OldValue + "' is exist with reference to OldValue:");
            }

            else
            {
                Report.Info("OldValue '" + OldValue + "' is not exist with reference to OldValue:");
            }
            bool retVal6 = applicationHandle.CheckSuccessMessage(NewValue);
            if (retVal6)
            {
                Report.Info("NewValue '" + NewValue + "' is exist with reference to NewValue:");
            }

            else
            {
                Report.Info("NewValue '" + NewValue + "' is not exist with reference to NewValue:");
            }
            bool retVal7 = applicationHandle.CheckSuccessMessage(PostingDate);
            if (retVal7)
            {
                Report.Info("PostingDate '" + PostingDate + "' is exist with reference to PostingDate:");
            }

            else
            {
                Report.Info("PostingDate '" + PostingDate + "' is not exist with reference to PostingDate:");
            }
            bool retVal8 = applicationHandle.CheckSuccessMessage(UserId);
            if (retVal8)
            {
                Report.Info("UserId '" + UserId + "' is exist with reference to UserId:");
            }

            else
            {
                Report.Info("UserId '" + UserId + "' is not exist with reference to UserId:");
            }
            bool retVal9 = applicationHandle.CheckSuccessMessage(Branch);
            if (retVal9)
            {
                Report.Info("Branch '" + Branch + "' is exist with reference to Branch:");
            }

            else
            {
                Report.Info("Branch '" + Branch + "' is not exist with reference to Branch:");
            }
            bool retVal10 = applicationHandle.CheckSuccessMessage(Location);
            if (retVal10)
            {
                Report.Info("Location '" + Location + "' is exist with reference to Location:");
            }

            else
            {
                Report.Info("Location '" + Location + "' is not exist with reference to Location:");
            }
            bool retVal11 = applicationHandle.CheckSuccessMessage(TransactionComment);
            if (retVal11)
            {
                Report.Info("TransactionComment '" + TransactionComment + "' is exist with reference to TransactionComment:");
            }

            else
            {
                Report.Info("TransactionComment '" + TransactionComment + "' is not exist with reference to TransactionComment:");
            }
            Thread.Sleep(1000);
            applicationHandle.WaitUntilElementVisible(tblAccHistoryAdvSearchPopupWindow, 20);
            applicationHandle.ClickOnVisibleElement(btnHistoryPopupClose);
        }

        public virtual void NavigateToAccountSummaryPage()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            applicationHandle.SelectTab(AccountSummaryTab);
            applicationHandle.Wait_for_object(AccountSummaryHeader, 20000);
        }
        public virtual void VerifyTabsonAccountSummaryPage()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            applicationHandle.SelectTab(TitleAddressTab);
            applicationHandle.Wait_for_object(TitleAddressHeader, 20000);
            bool TitleHeaderExist = applicationHandle.CheckObjectExist(TitleAddressTab);
            if (TitleHeaderExist)
            {
                Report.Info("Title/Address Page is accessible");
            }
            else
            {
                Report.Info("Title/Address Page is not accessible");
            }
            applicationHandle.SelectTab(InterestTab);
            applicationHandle.Wait_for_object(InterestPageHeader, 20000);
            bool HeaderExist = applicationHandle.CheckObjectExist(InterestPageHeader);
            if (HeaderExist)
            {
                Report.Info("InterestTab Page is accessible");
            }
            else
            {
                Report.Info("InterestTab Page is not accessible");
            }

            applicationHandle.SelectTab(PaymentTab);
            applicationHandle.Wait_for_object(PaymentPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(PaymentPageHeader);
            if (HeaderExist)
            {

                Report.Info("PaymentTab Page is accessible");
            }
            else
            {
                Report.Info("InterestTab Page is not accessible");
            }
            applicationHandle.SelectTab(AdjustablePaymentTab);
            applicationHandle.Wait_for_object(AdjustablePaymentPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(AdjustablePaymentPageHeader);
            if (HeaderExist)
            {

                Report.Info("AdjustablePaymentTab Page is accessible");
            }
            else
            {
                Report.Info("AdjustablePaymentTab Page is not accessible");
            }
            applicationHandle.SelectTab(DelinquencyTab);
            applicationHandle.Wait_for_object(TransactionProcessingPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(TransactionProcessingPageHeader);

            if (HeaderExist)
            {

                Report.Info("DelinquencyTab Page is accessible");
            }
            else
            {
                Report.Info("DelinquencyTab Page is not accessible");
            }
            applicationHandle.SelectTab(DelinquencyTab);
            applicationHandle.Wait_for_object(DelinquencyPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(DelinquencyPageHeader);
            if (HeaderExist)
            {
                Report.Pass("Transaction Processing Page is accessible", "Transaction Processing Page is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("Transaction Processing Page is not accessible", "Transaction Processing Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }

            applicationHandle.SelectTab(DelinquencyTab);
            applicationHandle.Wait_for_object(DelinquencyPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(DelinquencyPageHeader);
            if (HeaderExist)
            {
                Report.Pass("Transaction Processing Page is accessible", "Transaction Processing Page is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("Transaction Processing Page is not accessible", "Transaction Processing Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }

            applicationHandle.SelectTab(CreditCardTab);
            applicationHandle.Wait_for_object(CreditCardPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(CreditCardPageHeader);
            if (HeaderExist)
            {
                //Report.Pass("Credit Card Page is accessible", "Credit Card Page is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB)); 
                Report.Info("CreditCardTab Page is accessible");
            }
            else
            { //Report.Fail("Credit Card Page is not accessible", "Credit Card Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));}  
                Report.Info("CreditCardTab Page is not accessible");
            }
            applicationHandle.SelectTab(CollateralTab);
            applicationHandle.Wait_for_object(CollateralPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(CollateralPageHeader);
            if (HeaderExist)
            {
                //Report.Pass("Collateral Page is accessible", "Collateral Page  is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB)); 
                Report.Info("CollateralTab Page is  accessible");
            }
            else
            {// Report.Fail("Collateral Page Page is not accessible", "Collateral Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));}                
                Report.Info("CollateralTab Page is not accessible");
            }
            applicationHandle.SelectTab(LoanFeesTab);
            applicationHandle.Wait_for_object(LoanFeesPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(LoanFeesPageHeader);
            if (HeaderExist)
            {
                //Report.Pass("Loan Fees Page is accessible", "Loan Fees Page  is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB)); 
                Report.Info("Loan Fees Page is accessible");
            }
            else
            { //Report.Fail("Loan Fees Page is not accessible", "Loan Fees Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));}       
                Report.Info("Loan Fees Page is not accessible");
            }
            applicationHandle.SelectTab(RenewalTab);
            applicationHandle.Wait_for_object(RenewalPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(RenewalPageHeader);
            if (HeaderExist)
            {
                // Report.Pass("Renewal Page is accessible", "Renewal Page  is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB)); 
                Report.Info("Renewal Page is accessible");
            }
            else
            { //Report.Fail("Renewal Page is not accessible", "Renewal Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));}       
                Report.Info("Renewal Page is not accessible");
            }
            applicationHandle.SelectTab(MaturityTab);
            applicationHandle.Wait_for_object(MaturityPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(MaturityPageHeader);
            if (HeaderExist)
            {
                //Report.Pass("Maturity Page is accessible", "Maturity Page  is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB)); 
                Report.Info("Maturity Page is accessible");
            }
            else
            {// Report.Fail("Maturity Page is not accessible", "Maturity Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));}       
                Report.Info("Maturity Page is not accessible");
            }
            applicationHandle.SelectTab(USRegulatoryTab);
            applicationHandle.Wait_for_object(USRegulatoryPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(USRegulatoryPageHeader);
            if (HeaderExist)
            {
                // Report.Pass("US Regulatory Page is accessible", "US Regulatory Page  is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB)); 
                Report.Info("US Regulatory Page is accessible");
            }
            else
            {
                //Report.Fail("US Regulatory Page is not accessible", "US Regulatory Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));}       
                Report.Info("US Regulatory Page is accessible");
            }
            applicationHandle.SelectTab(CollectionTab);
            applicationHandle.Wait_for_object(CollectionPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(CollectionPageHeader);
            if (HeaderExist)
            {
                //Report.Pass("Collection Page is accessible", "Collection Page  is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB)); 
                Report.Info("Collection Page is accessible");
            }
            else
            {// Report.Fail("Collection Page is not accessible", "Collection Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                Report.Info("Collection Page is not accessible");

            }
            applicationHandle.SelectTab(GeneralTab);
            applicationHandle.Wait_for_object(GeneralPageHeader, 20000);
            HeaderExist = applicationHandle.CheckObjectExist(GeneralPageHeader);
            if (HeaderExist)
            {
                Report.Pass("General Page is accessible", "General Page  is accessible", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                Report.Info("General Page is accessible");
            }
            else
            {
                Report.Fail("General Page is not accessible", "General Page access is failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                Report.Info("General Page is not accessible");
            }
        }


        public virtual void ClickLoanAccountMaintenance(string sDate, string sLinkName)
        {
            try
            {
                applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                applicationHandle.SelectLinkInTable(tblAccHistoryAdvSearch, sLinkName, "Date;" + sDate + ";Description;" + sLinkName);
                applicationHandle.WaitUntilElementVisible(tblAccHistoryAdvSearchPopupWindow, 10);
                Report.Info("Requested link '" + sLinkName + "' is selected");

            }
            catch (KeyNotFoundException e)
            {
                Report.Info("Requested link '" + sLinkName + "' is not found. Following exception logged: " + e.Message);
            }
        }
        public virtual void VerifyLoanAccountMaintDetails(string[] sTransactionDetailInfo)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string AccountNumber;
            string ReferenceNumber;
            string Description;
            string DataItem;
            string OldValue;
            string NewValue;
            string PostingDate;
            string UserId;
            string Branch;
            string Location;
            string TransactionComment;

            applicationHandle.GetColumnInTable(tblAccHistoryAdvSearchPopupWindow);
            if (sTransactionDetailInfo[0] != null)
                AccountNumber = sTransactionDetailInfo[0];
            else
                AccountNumber = "";

            if (sTransactionDetailInfo[1] != null)
                ReferenceNumber = sTransactionDetailInfo[1];
            else
                ReferenceNumber = "";

            if (sTransactionDetailInfo[2] != null)
                Description = sTransactionDetailInfo[2];
            else
                Description = "";

            if (sTransactionDetailInfo[3] != null)
                DataItem = sTransactionDetailInfo[3];
            else
                DataItem = "";
            if (sTransactionDetailInfo[4] != null)
                OldValue = sTransactionDetailInfo[4];
            else
                OldValue = "";

            if (sTransactionDetailInfo[5] != null)
                NewValue = sTransactionDetailInfo[5];
            else
                NewValue = "";

            if (sTransactionDetailInfo[6] != null)
                PostingDate = sTransactionDetailInfo[6];
            else
                PostingDate = "";

            if (sTransactionDetailInfo[7] != null)
                UserId = sTransactionDetailInfo[7];
            else
                UserId = "";

            if (sTransactionDetailInfo[8] != null)
                Branch = sTransactionDetailInfo[8];
            else
                Branch = "";

            if (sTransactionDetailInfo[9] != null)
                Location = sTransactionDetailInfo[9];
            else
                Location = "";

            if (sTransactionDetailInfo[10] != null)
                TransactionComment = sTransactionDetailInfo[10];
            else
                TransactionComment = "";

            bool retVal1 = applicationHandle.CheckSuccessMessage(AccountNumber);
            if (retVal1)
            {
                Report.Info("Account number '" + AccountNumber + "' is exist with reference to Account Number:");
            }

            else
            {
                Report.Info("Account number '" + AccountNumber + "' is not exist with reference to Account Number:");
            }
            bool retVal2 = applicationHandle.CheckSuccessMessage(ReferenceNumber);
            if (retVal2)
            {
                Report.Info("ReferenceNumber '" + ReferenceNumber + "' is exist with reference to ReferenceNumber:");
            }

            else
            {
                Report.Info("ReferenceNumber '" + ReferenceNumber + "' is not exist with reference to ReferenceNumber:");
            }
            bool retVal3 = applicationHandle.CheckSuccessMessage(Description);
            if (retVal3)
            {
                Report.Info("Description '" + Description + "' is exist with reference to Description:");
            }

            else
            {
                Report.Info("Description '" + Description + "' is not exist with reference to Description:");
            }
            bool retVal4 = applicationHandle.CheckSuccessMessage(DataItem);
            if (retVal4)
            {
                Report.Info("DataItem '" + DataItem + "' is exist with reference to DataItem:");
            }

            else
            {
                Report.Info("DataItem '" + DataItem + "' is not exist with reference to DataItem:");
            }
            bool retVal5 = applicationHandle.CheckSuccessMessage(OldValue);
            if (retVal5)
            {
                Report.Info("OldValue '" + OldValue + "' is exist with reference to OldValue:");
            }

            else
            {
                Report.Info("OldValue '" + OldValue + "' is not exist with reference to OldValue:");
            }
            bool retVal6 = applicationHandle.CheckSuccessMessage(NewValue);
            if (retVal6)
            {
                Report.Info("NewValue '" + NewValue + "' is exist with reference to NewValue:");
            }

            else
            {
                Report.Info("NewValue '" + NewValue + "' is not exist with reference to NewValue:");
            }
            bool retVal7 = applicationHandle.CheckSuccessMessage(PostingDate);
            if (retVal7)
            {
                Report.Info("PostingDate '" + PostingDate + "' is exist with reference to PostingDate:");
            }

            else
            {
                Report.Info("PostingDate '" + PostingDate + "' is not exist with reference to PostingDate:");
            }
            bool retVal8 = applicationHandle.CheckSuccessMessage(UserId);
            if (retVal8)
            {
                Report.Info("UserId '" + UserId + "' is exist with reference to UserId:");
            }

            else
            {
                Report.Info("UserId '" + UserId + "' is not exist with reference to UserId:");
            }
            bool retVal9 = applicationHandle.CheckSuccessMessage(Branch);
            if (retVal9)
            {
                Report.Info("Branch '" + Branch + "' is exist with reference to Branch:");
            }

            else
            {
                Report.Info("Branch '" + Branch + "' is not exist with reference to Branch:");
            }
            bool retVal10 = applicationHandle.CheckSuccessMessage(Location);
            if (retVal10)
            {
                Report.Info("Location '" + Location + "' is exist with reference to Location:");
            }

            else
            {
                Report.Info("Location '" + Location + "' is not exist with reference to Location:");
            }
            bool retVal11 = applicationHandle.CheckSuccessMessage(TransactionComment);
            if (retVal11)
            {
                Report.Info("TransactionComment '" + TransactionComment + "' is exist with reference to TransactionComment:");
            }

            else
            {
                Report.Info("TransactionComment '" + TransactionComment + "' is not exist with reference to TransactionComment:");
            }
            Thread.Sleep(1000);
            applicationHandle.WaitUntilElementVisible(tblAccHistoryAdvSearchPopupWindow, 20);
            applicationHandle.ClickOnVisibleElement(btnHistoryPopupClose);



        }


        public virtual void ClickLoanAccountMaintenance2(string sLinkName)
        {
            try
            {
                applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                applicationHandle.SelectLinkInLabel(tblAccHistoryAdvSearch, sLinkName);
                applicationHandle.WaitUntilElementVisible(tblAccHistoryAdvSearchPopupWindow, 10);
                Report.Info("Requested link '" + sLinkName + "' is selected");

            }
            catch (KeyNotFoundException e)
            {
                Report.Info("Requested link '" + sLinkName + "' is not found. Following exception logged: " + e.Message);
            }
        }


        public virtual void VerifyLoanAccountMaintDetails2(string[] sTransactionDetailInfo)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string AccountNumber;
            string ReferenceNumber;
            string Description;
            string DataItem;
            string OldValue;
            string NewValue;
            string PostingDate;
            string UserId;
            string Branch;
            string Location;
            string TransactionComment;

            applicationHandle.GetColumnInTable(tblAccHistoryAdvSearchPopupWindow);
            if (sTransactionDetailInfo[0] != null)
                AccountNumber = sTransactionDetailInfo[0];
            else
                AccountNumber = "";

            if (sTransactionDetailInfo[1] != null)
                ReferenceNumber = sTransactionDetailInfo[1];
            else
                ReferenceNumber = "";

            if (sTransactionDetailInfo[2] != null)
                Description = sTransactionDetailInfo[2];
            else
                Description = "";

            if (sTransactionDetailInfo[3] != null)
                DataItem = sTransactionDetailInfo[3];
            else
                DataItem = "";
            if (sTransactionDetailInfo[4] != null)
                OldValue = sTransactionDetailInfo[4];
            else
                OldValue = "";

            if (sTransactionDetailInfo[5] != null)
                NewValue = sTransactionDetailInfo[5];
            else
                NewValue = "";

            if (sTransactionDetailInfo[6] != null)
                PostingDate = sTransactionDetailInfo[6];
            else
                PostingDate = "";

            if (sTransactionDetailInfo[7] != null)
                UserId = sTransactionDetailInfo[7];
            else
                UserId = "";

            if (sTransactionDetailInfo[8] != null)
                Branch = sTransactionDetailInfo[8];
            else
                Branch = "";

            if (sTransactionDetailInfo[9] != null)
                Location = sTransactionDetailInfo[9];
            else
                Location = "";

            if (sTransactionDetailInfo[10] != null)
                TransactionComment = sTransactionDetailInfo[10];
            else
                TransactionComment = "";

            bool retVal1 = applicationHandle.CheckSuccessMessage(AccountNumber);
            if (retVal1)
            {
                Report.Info("Account number '" + AccountNumber + "' is exist with reference to Account Number:");
            }

            else
            {
                Report.Info("Account number '" + AccountNumber + "' is not exist with reference to Account Number:");
            }
            bool retVal2 = applicationHandle.CheckSuccessMessage(ReferenceNumber);
            if (retVal2)
            {
                Report.Info("ReferenceNumber '" + ReferenceNumber + "' is exist with reference to ReferenceNumber:");
            }

            else
            {
                Report.Info("ReferenceNumber '" + ReferenceNumber + "' is not exist with reference to ReferenceNumber:");
            }
            bool retVal3 = applicationHandle.CheckSuccessMessage(Description);
            if (retVal3)
            {
                Report.Info("Description '" + Description + "' is exist with reference to Description:");
            }

            else
            {
                Report.Info("Description '" + Description + "' is not exist with reference to Description:");
            }
            bool retVal4 = applicationHandle.CheckSuccessMessage(DataItem);
            if (retVal4)
            {
                Report.Info("DataItem '" + DataItem + "' is exist with reference to DataItem:");
            }

            else
            {
                Report.Info("DataItem '" + DataItem + "' is not exist with reference to DataItem:");
            }
            bool retVal5 = applicationHandle.CheckSuccessMessage(OldValue);
            if (retVal5)
            {
                Report.Info("OldValue '" + OldValue + "' is exist with reference to OldValue:");
            }

            else
            {
                Report.Info("OldValue '" + OldValue + "' is not exist with reference to OldValue:");
            }
            bool retVal6 = applicationHandle.CheckSuccessMessage(NewValue);
            if (retVal6)
            {
                Report.Info("NewValue '" + NewValue + "' is exist with reference to NewValue:");
            }

            else
            {
                Report.Info("NewValue '" + NewValue + "' is not exist with reference to NewValue:");
            }
            bool retVal7 = applicationHandle.CheckSuccessMessage(PostingDate);
            if (retVal7)
            {
                Report.Info("PostingDate '" + PostingDate + "' is exist with reference to PostingDate:");
            }

            else
            {
                Report.Info("PostingDate '" + PostingDate + "' is not exist with reference to PostingDate:");
            }
            bool retVal8 = applicationHandle.CheckSuccessMessage(UserId);
            if (retVal8)
            {
                Report.Info("UserId '" + UserId + "' is exist with reference to UserId:");
            }

            else
            {
                Report.Info("UserId '" + UserId + "' is not exist with reference to UserId:");
            }
            bool retVal9 = applicationHandle.CheckSuccessMessage(Branch);
            if (retVal9)
            {
                Report.Info("Branch '" + Branch + "' is exist with reference to Branch:");
            }

            else
            {
                Report.Info("Branch '" + Branch + "' is not exist with reference to Branch:");
            }
            bool retVal10 = applicationHandle.CheckSuccessMessage(Location);
            if (retVal10)
            {
                Report.Info("Location '" + Location + "' is exist with reference to Location:");
            }

            else
            {
                Report.Info("Location '" + Location + "' is not exist with reference to Location:");
            }
            bool retVal11 = applicationHandle.CheckSuccessMessage(TransactionComment);
            if (retVal11)
            {
                Report.Info("TransactionComment '" + TransactionComment + "' is exist with reference to TransactionComment:");
            }

            else
            {
                Report.Info("TransactionComment '" + TransactionComment + "' is not exist with reference to TransactionComment:");
            }

            Thread.Sleep(1000);
            applicationHandle.WaitUntilElementVisible(tblAccHistoryAdvSearchPopupWindow, 20);
            applicationHandle.ClickOnVisibleElement(btnHistoryPopupClose);
        }

        public virtual void EnterDetailsForAccountHistory(string AccountNumber, string sFromDate = "", string sToDate = "")

        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(Submit_Button);
            applicationHandle.SelectDropdownSpecifiedValueByPartialText(AccountDropdown, AccountNumber);
            if (!string.IsNullOrEmpty(sFromDate))
            {
                applicationHandle.Set_field_value(txtFromDate, sFromDate);
            }
            if (!string.IsNullOrEmpty(sToDate))
            {
                applicationHandle.Set_field_value(txtToDate, sToDate);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Submit_Button))
            {
                applicationHandle.ClickObjectViaJavaScript(Submit_Button);
            }
        }

        public virtual bool VerifyNoAccountTransactionInSearchTable()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TableSearchResults))
            {
                if (applicationHandle.GetObjectText(TableSearchResults + "/tr[1]/td[1]").Contains(Data.Get("No account transactions found.")))
                {
                    Result = true;
                }
            }
            return Result;
        }

        public virtual bool ValidateCreditedAmount(string CreditedAmount)
        {
            bool flag = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Submit_Button))
            {
                string Xpath = "Xpath;//*[@class='dataTables_scrollBody']/descendant::tbody//td[contains(.,'" + CreditedAmount + "')]";
                string Amount = applicationHandle.GetLabelText(Xpath);
                if (CreditedAmount.Equals(Amount))
                {
                    flag = true;
                }
            }
            return flag;
        }



        public virtual void ClickOnAdvancedSearch()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Advanced_Search_Tab))
            {
                applicationHandle.ClickObjectViaJavaScript(Advanced_Search_Tab);
            }
        }


        public virtual void SelectNonMonetaryAdvancedSearch()
        {
            applicationHandle.ClickObjectViaJavaScript(NonMonetary);
        }

        public virtual bool VerifyDataInAccountHistory(string AccountNumber, string refColumnValuesSemicolonDelimited, string FromDate = "", string ToDate = "", string AdvancedSearchTransactionTypeCriteria = "", string AdvancedSearchTransactionAmountCriteria = "", string AdvancedTransactionOtherTransactionInformationCriteria = "", string AdvancedTransactionSortOrder = "")
        {
            bool Result = false;
            int matchCount = 0;
            refColumnValuesSemicolonDelimited = refColumnValuesSemicolonDelimited + "|";
            string[] arr = refColumnValuesSemicolonDelimited.Split('|');
            applicationHandle.SelectDropdownSpecifiedValueByPartialText(AccountDropdown, AccountNumber);
            if (!string.IsNullOrEmpty(FromDate))
            {
                applicationHandle.Set_field_value(txtFromDate, FromDate);
            }
            if (!string.IsNullOrEmpty(ToDate))
            {
                applicationHandle.Set_field_value(txtToDate, ToDate);
            }
            if (string.IsNullOrEmpty(AdvancedSearchTransactionTypeCriteria) &&
            string.IsNullOrEmpty(AdvancedSearchTransactionAmountCriteria) &&
            string.IsNullOrEmpty(AdvancedTransactionOtherTransactionInformationCriteria) &&
            string.IsNullOrEmpty(AdvancedTransactionSortOrder)) { }
            else
            {
                ClickOnAdvancedSearch();
                SelectAdvanceTransactionBySpecificFilter(AdvancedSearchTransactionTypeCriteria, AdvancedSearchTransactionAmountCriteria, AdvancedTransactionOtherTransactionInformationCriteria, AdvancedTransactionSortOrder);
                applicationHandle.ScrollToObject(Advanced_Search_Tab);
                Report.Info("Advanced search criteria have been entered.", "advancedsearchcriteria", "True", applicationHandle);
                ClickOnAdvancedSearch();
            }
            ClickOnSubmitButton();
            for (int a = 0; a < arr.Length - 1; a++)
            {
                if (Profile7CommonLibrary.VerifyDataInTableByColumnValues(arr[a]))
                {
                    matchCount++;
                }
                if (matchCount == arr.Length - 1)
                {
                    Result = true;
                    break;
                }
            }

            return Result;
        }

        public virtual void SelectAdvanceTransactionBySpecificFilter(string AdvancedSearchTransactionTypeCriteria = "", string AdvancedSearchTransactionAmountCriteria = "", string AdvancedTransactionOtherTransactionInformationCriteria = "", string AdvancedTransactionSortOrder = "")
        {
            if (string.IsNullOrEmpty(AdvancedSearchTransactionTypeCriteria) &&
            string.IsNullOrEmpty(AdvancedSearchTransactionAmountCriteria) &&
            string.IsNullOrEmpty(AdvancedTransactionOtherTransactionInformationCriteria) &&
            string.IsNullOrEmpty(AdvancedTransactionSortOrder)) { }
            else
            {
                string runTimeObj = "";
                string[] arr = null;
                if (!string.IsNullOrEmpty(AdvancedSearchTransactionTypeCriteria))
                {
                    if (AdvancedSearchTransactionTypeCriteria.Contains("|"))
                    {
                        arr = AdvancedSearchTransactionTypeCriteria.Split('|');
                        if (AdvancedSearchTransactionTypeCriteria.Contains("Check Number"))
                        {
                            runTimeObj = "XPath;//table[@class='contentTable']/descendant::*[@id='advancedSearchBlock']/descendant::tbody[1]/descendant::*[contains(text(),'" + arr[0] + "')]/ancestor::td[1]/preceding-sibling::td/input[@type='radio']";
                            applicationHandle.ClickObjectViaJavaScript(runTimeObj);
                            applicationHandle.Set_field_value(txtCheckNumber, arr[1]);
                        }
                        if (AdvancedSearchTransactionTypeCriteria.Contains("Check Range"))
                        {
                            runTimeObj = "XPath;//table[@class='contentTable']/descendant::*[@id='advancedSearchBlock']/descendant::tbody[1]/descendant::*[contains(text(),'" + arr[0] + "')]/preceding-sibling::*[1]/descendant::input[@name='transactionType']";
                            applicationHandle.ClickObjectViaJavaScript(runTimeObj);

                            if (!string.IsNullOrEmpty(arr[1]))
                            {
                                applicationHandle.Set_field_value("XPath;//*[contains(text(),'" + arr[0] + "')]/ancestor::tr/following-sibling::tr/descendant::input[@name='checkFrom']", arr[1]);
                            }
                            if (!string.IsNullOrEmpty(arr[2]))
                            {
                                applicationHandle.Set_field_value("XPath;//*[contains(text(),'" + arr[0] + "')]/ancestor::tr/following-sibling::tr/descendant::input[@name='checkTo']", arr[2]);
                            }
                        }
                    }
                    else
                    {
                        runTimeObj = "XPath;//table[@class='contentTable']/descendant::*[@id='advancedSearchBlock']/descendant::tbody[1]/descendant::*[contains(text(),'" + AdvancedSearchTransactionTypeCriteria + "')]/preceding-sibling::*[1]/descendant::input[@name='transactionType']";
                        applicationHandle.ClickObjectViaJavaScript(runTimeObj);
                    }
                    arr = null;
                }
                if (!string.IsNullOrEmpty(AdvancedSearchTransactionAmountCriteria))
                {
                    if (AdvancedSearchTransactionAmountCriteria.Contains("|"))
                    {
                        arr = AdvancedSearchTransactionAmountCriteria.Split('|');
                        if (AdvancedSearchTransactionAmountCriteria.Contains("Specific Amount"))
                        {
                            runTimeObj = "XPath;//table[@class='contentTable']/descendant::*[@id='advancedSearchBlock']/descendant::tbody[1]/descendant::*[contains(text(),'" + arr[0] + "')]/ancestor::td[1]/preceding-sibling::td/input[@type='radio']";
                            applicationHandle.ClickObjectViaJavaScript(runTimeObj);
                            applicationHandle.Set_field_value(txtSpecificAmount, arr[1]);
                        }

                    }
                    else
                    {
                        runTimeObj = "XPath;//table[@class='contentTable']/descendant::*[@id='advancedSearchBlock']/descendant::tbody[1]/descendant::*[contains(text(),'" + AdvancedSearchTransactionAmountCriteria + "')]/preceding-sibling::*[1]/descendant::input[@name='amountOption']";
                        applicationHandle.ClickObjectViaJavaScript(runTimeObj);
                    }
                }
                if (!string.IsNullOrEmpty(AdvancedTransactionOtherTransactionInformationCriteria))
                {
                    if (AdvancedTransactionOtherTransactionInformationCriteria.Contains("|"))
                    {
                        arr = AdvancedTransactionOtherTransactionInformationCriteria.Split('|');
                        if (AdvancedTransactionOtherTransactionInformationCriteria.Contains("Confirmation Number"))
                        {
                            runTimeObj = "XPath;//table[@class='contentTable']/descendant::*[@id='advancedSearchBlock']/descendant::tbody[1]/descendant::*[contains(text(),'" + arr[0] + "')]/ancestor::td[1]/preceding-sibling::td/input[@type='radio']";
                            applicationHandle.ClickObjectViaJavaScript(runTimeObj);
                            applicationHandle.Set_field_value(txtConfirmationNumber, arr[1]);
                        }
                    }
                    else
                    {
                        runTimeObj = "XPath;//table[@class='contentTable']/descendant::*[@id='advancedSearchBlock']/descendant::tbody[1]/descendant::*[contains(text(),'" + AdvancedTransactionOtherTransactionInformationCriteria + "')]/preceding-sibling::*[1]/descendant::input[@name='otherTransactionOption']";
                        applicationHandle.ClickObjectViaJavaScript(runTimeObj);
                    }
                    arr = null;
                }
                if (!string.IsNullOrEmpty(AdvancedTransactionSortOrder))
                {
                    runTimeObj = "XPath;//table[@class='contentTable']/descendant::*[@id='advancedSearchBlock']/descendant::tbody[1]/descendant::*[contains(text(),'" + AdvancedTransactionSortOrder + "')]/preceding-sibling::*[1]/descendant::input[@name='reverseOrder']";
                    applicationHandle.ClickObjectViaJavaScript(runTimeObj);
                }
            }
        }
        public virtual bool VerifyAccountExistsInAccountDropdown(string AccountNumber)
        {
            bool Result = false;
            string temp = applicationHandle.GetObjectText(AccountDropdown + "/parent::*[1]");
            if (temp.Contains(AccountNumber))
            {
                Result = true;
            }

            return Result;
        }

        public virtual void ClickOnAccountHistoryTransaction(string ColumnValues)
        {
            string TableObjSpecifiedValue = "";
            string[] ColValArr = ColumnValues.Split(new string[] { ";" }, StringSplitOptions.None);
            for (int b = 0; b < ColValArr.Length; b++)
            {
                TableObjSpecifiedValue = TableObjSpecifiedValue + "*[contains(text(),'" + ColValArr[b] + "')]/ancestor::tr[1]/descendant::";
            }
            TableObjSpecifiedValue = "XPath;//" + TableObjSpecifiedValue;
            // TableObjSpecifiedValue = TableObjSpecifiedValue.Substring(0, (TableObjSpecifiedValue.Length - "/descendant::".Length));
            TableObjSpecifiedValue = TableObjSpecifiedValue + "a";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TableObjSpecifiedValue))
            {
                applicationHandle.ScrollToObject(TableObjSpecifiedValue);
                applicationHandle.ClickObjectViaJavaScript(TableObjSpecifiedValue);
            }
        }
        public virtual bool VerifyPOSNEGACRAmount(string label, string CalculatedPOSNEGACR, int Roundoff)
        {
            bool flag = false;
            string Value = "";
            string lblxpath = "Xpath;//*[contains(text(),'" + label + "')]/following-sibling::*";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(lblxpath))
            {
                string values = applicationHandle.GetObjectText(lblxpath);
                string[] PosNegValues = values.Split('/');
                if (!string.IsNullOrEmpty(Roundoff.ToString()))
                {
                    Value = Math.Round(Convert.ToDecimal(CalculatedPOSNEGACR), Roundoff).ToString();
                }
                else
                {
                    Value = CalculatedPOSNEGACR;
                }
                if ((PosNegValues[0].Contains(Value)) && (PosNegValues[1].Contains(Value)))
                {
                    flag = true;
                }
            }
            return flag;
        }
        public virtual bool VerifytabsInAccountInformationPage(string reftabnameSemicolonDelimited)
        {
            bool Result = false ;
            int matchCount = 0;
            reftabnameSemicolonDelimited = reftabnameSemicolonDelimited + ";";
            string[] arr1 = reftabnameSemicolonDelimited.Split(';');
            
            string temp=applicationHandle.GetObjectText("XPath;//h1[contains(text(),'Account Information')]/ancestor::tbody[1]");
            string[]arr=temp.Split(new string[]{"\r\n"},StringSplitOptions.None);
            List<string> tabsList=new List<string>();

            for(int a=0;a<arr.Length-1;a++)
            {
                for (int b = 0; b < arr1.Length-1; b++)
                {
                    tabsList.Add(arr[a].Trim());

                    if(arr[a].Contains(arr1[b]))
                    {
                        matchCount++;
                    }
                }
                if (matchCount == arr1.Length - 1)
                {
                    Result = true;
                    break;
                }
            }
            return Result;
        }
         public virtual void ClosePopup()
        {
            applicationHandle.ScrollToObject(btnHistoryPopupClose);
            applicationHandle.ClickObjectViaJavaScript(btnHistoryPopupClose);
        
        }    

        public virtual void ClickOnLinkInAccountHistoryTable(string sLinkName,string lineno)
        {

            string link = "Xpath;//div[@class= 'dataTables_scrollBody']/descendant::a["+lineno+"]";
            try
            {
                applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                // applicationHandle.SelectLinkInTable(tblAccHistoryAdvSearch, sLinkName,"Date;" + sDate + ";Description;" + sLinkName);
                applicationHandle.ClickObjectViaJavaScript(link);
                Report.Info("Requested link '" + sLinkName + "' is selected");
            }
            catch (KeyNotFoundException e)
            {
                Report.Info("Requested link '" + sLinkName + "' is not found. Following exception logged: " + e.Message);
            }
        }

        public virtual string GetLabelValue(string labelname,string lineno)
        {
            string runtimexpathforlabelvalue = "Xpath;//*[contains(@class,'ui-dialog ui-widget')]/descendant::*/*[@class='contentTable']/tbody/descendant::td[contains(text(),'"+labelname+"')]/following-sibling::td";
            string runtimexpathforlink = "Xpath;//div[@class= 'dataTables_scrollBody']/descendant::a["+lineno+"]";
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.ClickObjectViaJavaScript(runtimexpathforlink);
            applicationHandle.Wait_For_Specified_Time(2);
            string labelvalue = applicationHandle.GetLabelText(runtimexpathforlabelvalue);
            return labelvalue;
        }

    }
}
