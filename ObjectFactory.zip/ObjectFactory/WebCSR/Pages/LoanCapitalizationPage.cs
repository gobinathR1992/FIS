
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages

{
    public class LoanCapitalizationPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtUncapitalizedDeferredInterest = "XPath;//input[@name='LN_DIU']";
        private static string buttonSubmit = "XPath;//input[@name='submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";


        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMessageInCapitalizationPagePage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual void EnterValuesForCapitalizationPageField(string sLabelNameLabelValuePipeDelimited)
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }
        public virtual bool WaitUntilLoanCapitalizationPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtUncapitalizedDeferredInterest))
            {
                result = true;
            }
            return result;
        }




    }

}