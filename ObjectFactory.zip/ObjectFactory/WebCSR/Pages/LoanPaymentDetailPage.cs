using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanPaymentDetailPage
    {
        WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string PaymentDetailHeading="Xpath;//h1[contains(text(),'Payment Detail')]";
        // public static string Date_Of_Last_Payment_Transaction_Field="Xpath;//td[input[@name='LN_LPDT']]";
        // public static string Number_Of_Payments_Satisfied_Field="Xpath;//td[input[@name='LN_CNTCR']]";
        public static string Date_Of_Last_Payment_Transaction_Field="Xpath;//td[contains(text(),'Date of Last Payment Transaction:')]/following-sibling::td";
        public static string Number_Of_Payments_Satisfied_Field="Xpath;//td[contains(text(),'Number of Payments Satisfied')]/following-sibling::td";
        
        private static string Submit_Button = "Xpath;//input[@value='Submit']";
        private static string Cancel_Button = "Xpath;//input[@value='Cancel']";
        

        public virtual void navigate_to_payment_detail_page()
        {
            // WebCSRPageFactory.AccountInformationPage.select_payment_tab();
            // WebCSRPageFactory.LoanPaymentTabPage.select_payment_detail_link();
            applicationHandle.Wait_for_object(Cancel_Button, 2);
        }

        public virtual string get_date_Of_last_payment_transaction_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(Date_Of_Last_Payment_Transaction_Field);;
        }
        public virtual string get_number_of_payments_satisfied_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(Number_Of_Payments_Satisfied_Field);;
        }




    }
}