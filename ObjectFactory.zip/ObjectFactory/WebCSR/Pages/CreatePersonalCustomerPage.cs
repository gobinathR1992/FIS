﻿using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class CreatePersonalCustomerPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);



        // Personal Information section element locators
        public static string FirstName_Field = "Xpath;//tr[td[contains(text(),'First Name')]]//input";
        public static string LastName_Field = "Xpath;//tr[td[contains(text(),'Last Name')]]//input";
       // public static string FullName_Field = "Xpath;//*[@name='customerFullName']";
        public static string TaxID_Field = "Xpath;//tr[td[contains(text(),'Tax ID Number')]]//input";
        public static string DateofBirth_Field = "Xpath;//tr[td[contains(text(),'Date of Birth')]]//input";
        public static string CountryOfCitizenship_DropDown = "Xpath;//select[@name='citizenshipCountry']";
        public static string dropdownCountryOfResidency = "XPath;//select[@name='residencyCountry']";
        // Identification section element locators
        // Passport
        public static string Passport_RadioButton = "Xpath;//tr[td[contains(text(),'Passport')]]//input";
        public static string Passport_Number_Field = "Xpath;//input[@name='passportNumber']";
        public static string CountryOfIssue_Dropdown = "Xpath;//select[@name='passportCountryOfIssue']";
        public static string Passport_IssueDate_Field = "Xpath;//input[@name='passportIssueDate']";
        public static string Passport_ExpireDate_Field = "Xpath;//input[@name='passportExpirationDate']";
        // Driver's License
        public static string DriverLicense_RadioButton = "Xpath;//tr[td[contains(text(),'Driver')]]//input";
        public static string DLNumberField = "Xpath;//input[@name='driversLicenseNumber']";
        public static string DLStateDropDown = "Xpath;//select[@name='driversLicenseState']";
        public static string DLIssueDateField = "Xpath;//input[@name='driversLicenseIssueDate']";
        public static string DLExpireDateField = "Xpath;//input[@name='driversLicenseExpirationDate']";
        // Other
        public static string Other_RadioButton = "Xpath;//tr[td[contains(text(),'Other')]]//input";
        public static string Other_Type_DropDown = "Xpath;//select[@name='otherIdType']";
        public static string Other_Number_Field = "Xpath;//input[@name='otherIdNumber']";
        public static string Other_Issuer_DropDown = "Xpath;//select[@name='otherIdIssuer']";
        public static string Other_IssueDate_Field = "Xpath;//input[@name='otherIdIssueDate']";
        public static string Other_ExpireDate_Field = "Xpath;//input[@name='otherIdExpirationDate']";


        // Email and Phone section element locators
        public static string EmailAndPhone_Email_Field = "Xpath;//input[@name='email']";
        public static string EmailAndPhone_Phone_Field = "Xpath;//input[@name='mainPhoneNumber']";

        // Address | Home Address section element locators
        public static string HomeAddressLine1_Field = "Xpath;//input[@name='mainAddress.addressLine1']";
        public static string HomeAddressLine2_Field = "Xpath;//input[@name='mainAddress.addressLine2']";
        public static string HomeAddressCity_Field = "Xpath;//input[@name='mainAddress.city']";
        public static string HomeAddressCountry_DropDown = "Xpath;//select[@name='mainAddress.country']";
        public static string HomeAddressState_DropDown = "Xpath;//select[@name='mainAddress.state']";
        public static string HomeAddressZipCode_Field = "Xpath;//input[@name='mainAddress.zipCode']";
        public static string HomeYearsAtAddress_DropDown = "Xpath;//select[@name='yearsAtAddress']";
        // Address | Previous Address section element locators
        public static string PreviousAddressLine1_Field = "Xpath;//input[@name='previousAddress.addressLine1']";
        public static string PreviousAddressLine2_Field = "Xpath;//input[@name='previousAddress.addressLine2']";
        public static string PreviousAddressCity_Field = "Xpath;//input[@name='previousAddress.city']";
        public static string PreviousAddressCountry_DropDown = "Xpath;//select[@name='previousAddress.country']";
        public static string PreviousAddressState_DropDown = "Xpath;//select[@name='previousAddress.state']";
        public static string PreviousAddressZipCode_Field = "Xpath;//input[@name='previousAddress.zipCode']";
        // Address | Mailing Address section element locators
        public static string SameAsHomeAddress_Yes_RadioButton = "Xpath;//input[@name ='mailAddressSameAsMain'][@value='true']";
        public static string SameAsHomeAddress_No_RadioButton = "Xpath;//input[@name ='mailAddressSameAsMain'][@value='false']";
        public static string MailingAddressLine1_Field = "Xpath;//input[@name='mailingAddress.addressLine1']";
        public static string MailingAddressLine2_Field = "Xpath;//input[@name='mailingAddress.addressLine2']";
        public static string MailingAddressCity_Field = "Xpath;//input[@name='mailingAddress.city']";
        public static string MailingAddressCountry_DropDown = "Xpath;//select[@name='mailingAddress.country']";
        public static string MailingAddressState_DropDown = "Xpath;//select[@name='mailingAddress.state']";
        public static string MailingAddressZipCode_Field = "Xpath;//input[@name='mailingAddress.zipCode']";

        // Online Access section element locators
        public static string OnlineAccess_Yes_RadioButton = "Xpath;//input[@name ='allowOnlineAccess'][@value='true']";
        public static string OnlineAccess_No_RadioButton = "Xpath;//input[@name ='allowOnlineAccess'][@value='false']";
        public static string OnlineAccess_UserID_Field = "Xpath;//input[@name='userName']";
        public static string OnlineAccess_PasswordStatus_Dropdown = "Xpath;//select[@name='userStatus']";
        public static string OnlineAccess_TemporaryPasswordAction_Dropdown = "Xpath;//select[@name='resetAction']";
        public static string OnlineAccess_NewPassword_Field = "Xpath;//input[@name='password']";
        public static string OnlineAccess_ConfirmPassword_Field = "Xpath;//input[@name='passwordVerify']";
        public static string OnlineAccess_PasswordHint_Field = "Xpath;//input[@name='hint']";
        public static string OnlineAccess_SecretWord_Field = "Xpath;//input[@name='secretWord']";

        // Security section element locators
        public static string SecretQuestion_DropDown = "Xpath;//select[@name='secretQuestion']";
        public static string SecretAnswer_Field = "Xpath;//input[@name='secretAnswer']";

        // Telephone Banking section element locators
        public static string TelephoneBankingPIN_Yes_RadioButton = "Xpath;//input[@name='allowPIN'][@value='true']";
        public static string TelephoneBankingPIN_No_RadioButton = "Xpath;//input[@name='allowPIN'][@value='false']";
        public static string TelephoneBanking_NewPIN_Field = "Xpath;//input[@name='pin']";
        public static string TelephoneBanking_ConfirmPIN_Field = "Xpath;//input[@name='pinVerify']";

        //FATCA section element locators
        public static string drpFATCAReportingStatus = "Xpath;//select[@name='fatcaReportingStatus']";
        public static string cbkSubjecttoFATCAWithholding = "Xpath;//input[@name='subjectToFatcaWithholding']";
        public static string drpFATCAExemptionCode = "Xpath;//select[@name='fatcaExemptionCode']";
        public static string drpFATCAWaiverforReporting = "Xpath;//select[@name='waiverForFatcaReporting']";

        // Warning Message element locators
        public static string txt_TaxID_Warning_Message = "Xpath;//p[contains(text(),'Tax ID is already in use')]";
        public static string txt_UserID_Warning_Message = "Xpath;//p[contains(text(),'User ID is already in use.')]";

        public static string ContinueButton = "Xpath;//input[@value='Continue']";
        public static string CancelButton = "Xpath;//input[@value='Cancel']";
        public static string SubmitButton = "Xpath;//input[@value='Submit']";
        public static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        public static string dropdownGender = "XPath;//select[@name='gender']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        public static string ApplicationDate = new CreatePersonalCustomerPage().GetApplicationDate();
        private static string FirstValidationMessage = "Xpath;//*[contains(text(),'Invalid ZIP code')][1]";
        private static string SecondValidationMessage = "Xpath;//*[contains(text(),'Invalid ZIP code')][2]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";   

        public virtual string GetApplicationDate()
        {
            string result = "";
            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }
        public virtual void set_first_name_field_value(string sFirstName)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ContinueButton))
            {
                appHandle.Set_field_value(FirstName_Field, sFirstName);
            }
        }
        public virtual void set_last_name_field_value(string sLastName)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ContinueButton))
            {
                appHandle.Set_field_value(LastName_Field, sLastName);
            }
        }
        public virtual string get_last_name_field_value()
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            return appHandle.GetElementValue(LastName_Field);
        }
        public virtual void set_tax_id_number_field_value(string sTaxIdNumber)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(TaxID_Field, sTaxIdNumber);
        }
        public virtual string get_tax_id_number_field_value()
        {
            string result = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TaxID_Field))
            {
                result = appHandle.GetElementValue(TaxID_Field);
            }
            return result;
        }
        public virtual void set_date_of_birth_field_value(string sDateOfBirth)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(DateofBirth_Field, sDateOfBirth);
        }
        public virtual void select_country_of_citizenship_dropdown_value(string sCountryOfCitizenship)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(CountryOfCitizenship_DropDown, sCountryOfCitizenship);
        }

        // Identification section | DRIVERS LICENSE.
        public virtual void select_driver_license_radio_button()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DriverLicense_RadioButton))
            {
                appHandle.Set_radiobutton(DriverLicense_RadioButton);
            }
        }
        public virtual void set_driver_license_number_field_value(string sDriverLicenseNumber)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(DLNumberField, sDriverLicenseNumber);
        }
        public virtual void select_driver_license_state_dropdown_value(string sDriverLicenseState)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(DLStateDropDown, sDriverLicenseState);
        }
        public virtual void set_driver_license_issue_date_field_value(string sDriverLicenseIssueDate)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(DLIssueDateField, sDriverLicenseIssueDate);
        }
        public virtual void set_driver_license_expiration_date_field_value(string sDriverLicenseExpirationDate)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(DLExpireDateField, sDriverLicenseExpirationDate);
        }

        // Identification section | PASSPORT.
        public virtual void select_passport_radio_button()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Passport_RadioButton))
            {
                appHandle.Set_radiobutton(Passport_RadioButton);
            }
        }
        public virtual void set_passport_number_field_value(string sPassportNumber)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(Passport_Number_Field, sPassportNumber);
        }
        public virtual void select_passport_country_of_issue_dropdown_value(string sCountryOfIssue)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(CountryOfIssue_Dropdown, sCountryOfIssue);
        }
        public virtual void set_passport_issue_date_field_value(string sIssueDate)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(Passport_IssueDate_Field, sIssueDate);
        }
        public virtual void set_passport_expiration_date_field_value(string sExpirationDate)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(Passport_ExpireDate_Field, sExpirationDate);
        }


        // Identification section | OTHER.
        public virtual void select_other_radio_button()
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Other_RadioButton))
            {
                appHandle.Set_radiobutton(Other_RadioButton);
            }
        }
        public virtual void select_other_type_dropdown_value(string sOtherType)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(Other_Type_DropDown, sOtherType);
        }
        public virtual void set_other_number_field_value(string sOtherNumber)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(Other_Number_Field, sOtherNumber);
        }
        public virtual void select_other_issuer_dropdown_value(string sOtherIssuer)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(Other_Issuer_DropDown, sOtherIssuer);
        }
        public virtual void set_other_issue_date_field_value(string sOtherIssueDate)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(Other_IssueDate_Field, sOtherIssueDate);
        }
        public virtual void set_other_expiration_date_field_value(string sOtherExpirationDate)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(Other_ExpireDate_Field, sOtherExpirationDate);
        }

        // Email and Phone section.
        public virtual void set_email_and_phone_email_field_value(string sEmailandPhoneEmail)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(EmailAndPhone_Email_Field, sEmailandPhoneEmail);
        }
        public virtual void set_email_and_phone_phone_field_value(string sEmailandPhoneEmail)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(EmailAndPhone_Phone_Field, sEmailandPhoneEmail);
        }

        // Address section | HOME ADDRESS.
        public virtual void set_home_address_line_one_field_value(string sHomeAddressLineOne)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(HomeAddressLine1_Field, sHomeAddressLineOne);
        }
        public virtual void set_home_address_line_two_field_value(string sHomeAddressLineTwo)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(HomeAddressLine2_Field, sHomeAddressLineTwo);
        }
        public virtual void set_home_address_city_field_value(string sHomeAddressCity)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(HomeAddressCity_Field, sHomeAddressCity);
        }
        public virtual void select_home_address_country_dropdown_value(string sHomeAddressCountry)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(HomeAddressCountry_DropDown, sHomeAddressCountry);
        }
        public virtual void select_home_address_state_dropdown_value(string sHomeAddressState)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(HomeAddressState_DropDown, sHomeAddressState);
        }
        public virtual void set_home_address_zip_code_field_value(string sHomeAddressZipCode)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(HomeAddressZipCode_Field, sHomeAddressZipCode);
        }
        public virtual void select_home_address_years_at_current_address_dropdown_value(string sHomeAddressYearsAtCurrentAddress)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown, sHomeAddressYearsAtCurrentAddress);
        }
        public virtual string get_years_at_current_address_field_value()
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            return appHandle.GetDropdownSelectedValue(HomeYearsAtAddress_DropDown);
        }

        // Address section | MAILING ADDRESS.
        public virtual void set_radio_button_mailing_address_same_as_home_address_yes()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SameAsHomeAddress_Yes_RadioButton))
            {
                appHandle.Set_radiobutton(SameAsHomeAddress_Yes_RadioButton);
            }
        }
        public virtual void set_radio_button_mailing_address_same_as_home_address_no()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SameAsHomeAddress_No_RadioButton))
            {
                appHandle.Set_radiobutton(SameAsHomeAddress_No_RadioButton);
            }
        }
        public virtual void set_mailing_address_line_one_field_value(string sMailingAddressLineOne)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(MailingAddressLine1_Field, sMailingAddressLineOne);
        }
        public virtual void set_mailing_address_line_two_field_value(string sMailingAddressLineTwo)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(MailingAddressLine2_Field, sMailingAddressLineTwo);
        }
        public virtual void set_mailing_address_city_field_value(string sMailingAddressCity)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(MailingAddressCity_Field, sMailingAddressCity);
        }
        public virtual void select_mailing_address_country_dropdown_value(string sMailingAddressCountry)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(MailingAddressCountry_DropDown, sMailingAddressCountry);
        }
        public virtual void select_mailing_address_state_dropdown_value(string sMailingAddressState)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(MailingAddressState_DropDown, sMailingAddressState);
        }
        public virtual void set_mailing_address_zip_code_field_value(string sMailingAddressZipCode)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(MailingAddressZipCode_Field, sMailingAddressZipCode);
        }

        // Address section | PREVIOUS ADDRESS.
        public virtual void set_previous_address_line_one_field_value(string sPreviousAddressLineOne)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(PreviousAddressLine1_Field, sPreviousAddressLineOne);
        }
        public virtual void set_previous_address_line_two_field_value(string sPreviousAddressLineTwo)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(PreviousAddressLine2_Field, sPreviousAddressLineTwo);
        }
        public virtual void set_previous_address_city_field_value(string sPreviousAddressCity)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(PreviousAddressCity_Field, sPreviousAddressCity);
        }
        public virtual void select_previous_address_country_dropdown_value(string sPreviousAddressCountry)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(PreviousAddressCountry_DropDown, sPreviousAddressCountry);
        }
        public virtual void select_previous_address_state_dropdown_value(string sPreviousAddressState)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(PreviousAddressState_DropDown, sPreviousAddressState);
        }
        public virtual void set_previous_address_zip_code_field_value(string sPreviousAddressZipCode)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(PreviousAddressZipCode_Field, sPreviousAddressZipCode);
        }

        // Online Access.
        public virtual void set_radio_button_allow_online_access_yes()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(OnlineAccess_Yes_RadioButton))
            {
                appHandle.Set_radiobutton(OnlineAccess_Yes_RadioButton);
            }
        }
        public virtual void set_radio_button_allow_online_access_no()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(OnlineAccess_No_RadioButton))
            {
                appHandle.Set_radiobutton(OnlineAccess_No_RadioButton);
            }
        }
        public virtual void set_online_access_user_id_field_value(string sOnlineAccessUserID)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(OnlineAccess_UserID_Field, sOnlineAccessUserID);
        }
        public virtual string get_online_access_user_id_field_value()
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            return appHandle.GetElementValue(OnlineAccess_UserID_Field);
        }
        public virtual void select_online_access_password_status_dropdown_value(string sOnlineAccessPasswordStatus)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(OnlineAccess_PasswordStatus_Dropdown, sOnlineAccessPasswordStatus);
        }
        public virtual void select_online_access_tmporary_password_action_dropdown_value(string sOnlineAccessTemporaryPasswordAction)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(OnlineAccess_TemporaryPasswordAction_Dropdown, sOnlineAccessTemporaryPasswordAction);
        }
        public virtual string get_online_access_tmporary_password_action_field_value()
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            return appHandle.GetDropdownSelectedValue(OnlineAccess_TemporaryPasswordAction_Dropdown);
            //return appHandle.GetElementValue(OnlineAccess_TemporaryPasswordAction_Dropdown);
        }
        public virtual void set_online_access_new_password_field_value(string sOnlineAccessNewPassword)
        {
            if (appHandle.IsObjectEnabled(OnlineAccess_NewPassword_Field))
            {
                appHandle.Wait_for_object(ContinueButton, 3);
                appHandle.Set_field_value(OnlineAccess_NewPassword_Field, sOnlineAccessNewPassword);
            }

        }
        public virtual void set_online_access_confirm_password_field_value(string sOnlineAccessConfirmPassword)
        {
            if (appHandle.IsObjectEnabled(OnlineAccess_ConfirmPassword_Field))
            {
                appHandle.Wait_for_object(ContinueButton, 3);
                appHandle.Set_field_value(OnlineAccess_ConfirmPassword_Field, sOnlineAccessConfirmPassword);
            }
        }
        public virtual void set_online_access_password_hint_field_value(string sOnlineAccessPasswordHint)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(OnlineAccess_PasswordHint_Field, sOnlineAccessPasswordHint);
        }
        public virtual void set_online_access_secret_word_field_value(string sOnlineAccessSecretWord)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(OnlineAccess_SecretWord_Field, sOnlineAccessSecretWord);
        }

        // Security Question and Answer.
        public virtual void select_security_question_dropdown_value(string sSecurityQaestion)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectDropdownSpecifiedValue(SecretQuestion_DropDown, sSecurityQaestion);
        }
        public virtual void set_security_answer_field_value(string sSecurityAnswer)
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.Set_field_value(SecretAnswer_Field, sSecurityAnswer);
        }

        // Telephone Banking
        public virtual void set_telephone_banking_new_pin_field_value(string sTelephoneBankingNewPIN)
        {
            if (appHandle.CheckRadiobuttonSelected(TelephoneBankingPIN_Yes_RadioButton))
            {
                appHandle.Wait_for_object(ContinueButton, 3);
                appHandle.Set_field_value(TelephoneBanking_NewPIN_Field, sTelephoneBankingNewPIN);
            }
        }
        public virtual void set_telephone_banking_confirm_pin_field_value(string sTelephoneBankingConfirmPIN)
        {
            if (appHandle.CheckRadiobuttonSelected(TelephoneBankingPIN_Yes_RadioButton))
            {
                appHandle.Wait_for_object(ContinueButton, 3);
                appHandle.Set_field_value(TelephoneBanking_ConfirmPIN_Field, sTelephoneBankingConfirmPIN);
            }
        }
        public virtual void select_continue_button()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ContinueButton))
            {

                appHandle.ClickObjectViaJavaScript(ContinueButton);

            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton, 1))
            {

            }
            else
            {
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ, 1))
                {
                    if (appHandle.GetObjectText(MSGOBJ).Contains(Data.Get("Unable to process your request at this time.")))
                    {
                        Report.Fail("Personal Customer creation can not be completed as :" + appHandle.GetObjectText(MSGOBJ), "testfail", "true", appHandle, true);
                    }

                    else
                    {
                        for (int i = 1; i <= 10; i++)
                        {
                            if (appHandle.GetObjectText(MSGOBJ).Contains(Data.Get("User ID is already in use.")))
                            {
                                this.enter_online_access_details();
                                this.enter_telephone_banking_details();
                                appHandle.ClickObjectViaJavaScript(ContinueButton);
                                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton, 3))
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }

        public virtual void select_cancel_button()
        {
            appHandle.Wait_for_object(ContinueButton, 3);
            appHandle.SelectButton(CancelButton);
        }
        public virtual void select_submit_button()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton))
            {
                appHandle.SelectButton(SubmitButton);
            }
        }

        public virtual void enter_personal_information_details()
        {
            string CustName = this.GenerateCustomerName();
            string FirstName = CustName.Split(new string[] { " " }, StringSplitOptions.None)[0];
            string LastName = CustName.Split(new string[] { " " }, StringSplitOptions.None)[1];
           // string FullName = CustName.Split(new string[] { " " }, StringSplitOptions.None)[2];

          //  string TaxID = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"), "-");
            string DOB = appHandle.CalculateNewDate(ApplicationDate, "Y", -62);


            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ContinueButton))
            {
                appHandle.Set_field_value(FirstName_Field, FirstName);
                appHandle.Set_field_value(LastName_Field, LastName);
                //appHandle.Set_field_value(FullName_Field, FullName);
              //  appHandle.Set_field_value(TaxID_Field, TaxID);
                appHandle.Set_field_value(DateofBirth_Field, DOB);
                appHandle.SelectDropdownSpecifiedValue(dropdownGender, (string)Data.Get("M - Male"));
                appHandle.SelectDropdownSpecifiedValue(dropdownCountryOfResidency, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                appHandle.SelectDropdownSpecifiedValue(CountryOfCitizenship_DropDown, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                
            }

        }

        public virtual void enter_drivers_license_identification_details()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DriverLicense_RadioButton))
            {
                appHandle.Set_radiobutton(DriverLicense_RadioButton);
            }
            string DrivingLicenseNumber = appHandle.CreateRamdomData(FieldType.NUMERIC, 111111, 999999, 6) + "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DLNumberField))
            {
                appHandle.Set_field_value(DLNumberField, DrivingLicenseNumber);
                appHandle.SelectDropdownSpecifiedValue(DLStateDropDown, (string)Data.Get("FL - Florida"));
                appHandle.Set_field_value(DLIssueDateField, appHandle.CalculateNewDate(ApplicationDate, "Y", -20));
                appHandle.Set_field_value(DLExpireDateField, appHandle.CalculateNewDate(ApplicationDate, "Y", 10));
            }

        }
        public virtual void enter_passport_identification_details()
        {

            string sPassportNumber = appHandle.CreateRamdomData(FieldType.NUMERIC, 111111, 999999, 6) + "";
            select_passport_radio_button();
            appHandle.Set_field_value(Passport_Number_Field, sPassportNumber);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(CountryOfIssue_Dropdown))
            {
                appHandle.SelectDropdownSpecifiedValue(CountryOfIssue_Dropdown, (string)Data.Get("US - UNITED STATES OF AMERICA"));
            }
            appHandle.Set_field_value(Passport_IssueDate_Field, appHandle.CalculateNewDate(ApplicationDate, "Y", -20));
            appHandle.Set_field_value(Passport_ExpireDate_Field, appHandle.CalculateNewDate(ApplicationDate, "Y", 20));


        }
        public virtual void enter_other_identification_details()
        {

            select_other_radio_button();
            appHandle.SelectDropdownSpecifiedValue(Other_Type_DropDown, (string)Data.Get("Employee ID - Employee Identification"));
            appHandle.Set_field_value(Other_Number_Field, appHandle.CreateRamdomData(FieldType.NUMERIC, 11111, 99999, 5) + "");
            appHandle.SelectDropdownSpecifiedValue(Other_Issuer_DropDown, (string)Data.Get("FL - Florida"));
            appHandle.Set_field_value(Other_IssueDate_Field, appHandle.CalculateNewDate(ApplicationDate, "Y", -20));
            appHandle.Set_field_value(Other_ExpireDate_Field, appHandle.CalculateNewDate(ApplicationDate, "Y", 30));


        }

        public virtual void enter_email_and_phone_details()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(EmailAndPhone_Email_Field))
            {
                appHandle.Set_field_value(EmailAndPhone_Email_Field, StartupConfiguration.EnvironmentDetails.UserMailID.ToString());
                appHandle.Set_field_value(EmailAndPhone_Phone_Field, RandomNumberGenerator.GenerateRandomNumberByFormat("XXX-XXX-XXXX", "-"));
            }

        }

        public virtual void enter_home_address_details(string YearsAtCurrentAddress)
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                appHandle.Set_field_value(HomeAddressLine1_Field, Data.Get("GLOBAL_ADDRESS1IN"));
                appHandle.Set_field_value(HomeAddressLine2_Field, Data.Get("SJR-IPARK"));
                appHandle.Set_field_value(HomeAddressCity_Field, Data.Get("GLOBAL_CITY"));
                appHandle.SelectDropdownSpecifiedValue(HomeAddressCountry_DropDown, (string)Data.Get("GLOBAL_ADDCOUNTRY"));
                appHandle.SelectDropdownSpecifiedValue(HomeAddressState_DropDown, (string)Data.Get("GLOBAL_ADDSTATE"));
                appHandle.Set_field_value(HomeAddressZipCode_Field, Data.Get("GLOBAL_POSTALCODEIN"));
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown, YearsAtCurrentAddress);
            }

        }

        public virtual void enter_mailing_address_details()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MailingAddressLine1_Field))
            {
                appHandle.Set_field_value(MailingAddressLine1_Field, Data.Get("123 Street"));
                appHandle.Set_field_value(MailingAddressLine2_Field, Data.Get("GLOBAL_ADDRESS1IN"));
                appHandle.Set_field_value(MailingAddressCity_Field, Data.Get("GLOBAL_CITY_MALVERN"));
                appHandle.SelectDropdownSpecifiedValue(MailingAddressCountry_DropDown, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                appHandle.SelectDropdownSpecifiedValue(MailingAddressState_DropDown, (string)Data.Get("PA - PENNSYLVANIA"));
                appHandle.Set_field_value(MailingAddressZipCode_Field, Data.Get("GLOBAL_ZIPCODE_19355"));
            }

        }

        public virtual void enter_previous_address_details()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(PreviousAddressCountry_DropDown))
            {
                appHandle.Set_field_value(PreviousAddressLine1_Field, Data.Get("456 Street"));
                appHandle.Set_field_value(PreviousAddressLine2_Field, Data.Get("GLOBAL_ADDRESS1IN"));
                appHandle.Set_field_value(PreviousAddressCity_Field, Data.Get("Jacksonville"));
                appHandle.SelectDropdownSpecifiedValue(PreviousAddressCountry_DropDown, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                appHandle.SelectDropdownSpecifiedValue(PreviousAddressState_DropDown, (string)Data.Get("FL - FLORIDA"));
                appHandle.Set_field_value(PreviousAddressZipCode_Field, (string)Data.Get("32256"));
            }


        }
        public virtual void enter_online_access_details()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(OnlineAccess_UserID_Field))
            {
                set_radio_button_allow_online_access_yes();
                string userid = StartupConfiguration.EnvironmentDetails.UserFirstName;
                userid = userid.Substring(0, 4).ToUpper();
                userid = userid +appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 3).ToString().ToUpper()+ appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999, 4) + "";
                appHandle.Set_field_value(OnlineAccess_UserID_Field, userid);
                appHandle.SelectDropdownSpecifiedValue(OnlineAccess_PasswordStatus_Dropdown, (string)Data.Get("GLOBAL_PASSWORD_STATUS_ACTIVE"));
                appHandle.SelectDropdownSpecifiedValue(OnlineAccess_TemporaryPasswordAction_Dropdown, (string)Data.Get("GLOBAL_TEMPORARY_PASSWORD_ACTION_RESET_4"));
                if (appHandle.GetDropdownSelectedValue(OnlineAccess_TemporaryPasswordAction_Dropdown).Equals((string)Data.Get("GLOBAL_TEMPORARY_PASSWORD_ACTION_RESET_4")))
                {
                    appHandle.Set_field_value(OnlineAccess_NewPassword_Field, Data.Get("GLOBAL_ONLINE_ACCESS_PASSWORD"));
                    appHandle.Set_field_value(OnlineAccess_ConfirmPassword_Field, Data.Get("GLOBAL_ONLINE_ACCESS_PASSWORD"));
                }
                appHandle.Set_field_value(OnlineAccess_PasswordHint_Field, Data.Get("GLOBAL_PASSWORD_HINT"));
                appHandle.Set_field_value(OnlineAccess_SecretWord_Field, Data.Get("GLOBAL_SECRET_WORD"));
            }

        }
        public virtual void enter_online_access_security_details(string[] arrOnlineAccessSecurityDetails)
        {

            set_online_access_new_password_field_value(arrOnlineAccessSecurityDetails[0]);
            set_online_access_confirm_password_field_value(arrOnlineAccessSecurityDetails[1]);

        }
        public virtual void enter_security_question_details()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SecretQuestion_DropDown))
            {
                appHandle.SelectDropdownSpecifiedValue(SecretQuestion_DropDown, (string)Data.Get("GLOBAL_SECRETQUESTION"));
                appHandle.Set_field_value(SecretAnswer_Field, Data.Get("GLOBAL_SECRETANSWER"));
            }

        }
        public virtual void enter_telephone_banking_details()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TelephoneBankingPIN_Yes_RadioButton))
            {
                string pin = appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999, 4) + "";
                appHandle.ClickObjectViaJavaScript(TelephoneBankingPIN_Yes_RadioButton);
                appHandle.Set_field_value(TelephoneBanking_NewPIN_Field, pin);
                appHandle.Set_field_value(TelephoneBanking_ConfirmPIN_Field, pin);
            }

        }

        // To check the entered TaxID exists or not
        public virtual bool verify_tax_id_warning_message_element_exist()
        {
            bool blnSuccess = false;
            if (appHandle.IsObjectExists(txt_TaxID_Warning_Message))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }

        // To check the entered User ID exists or not
        public virtual bool verify_user_id_warning_message_element_exist()
        {
            bool blnSuccess = false;
            if (appHandle.IsObjectExists(txt_UserID_Warning_Message))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }

        public virtual string GenerateCustomerName()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string strCustName = "";
            string strFirstName = "";
            string strLastName = "";
            string strFullName = "";
            string strRandomString1 = appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 5).ToString();
            string strRandomString2 = appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 5).ToString();
            string strRandomString3 = appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 5).ToString();

            string strUserName = StartupConfiguration.UserSettings.GLOBAL_USER_NAME;

            if (!strUserName.Contains(" "))
            {
                // strFirstName = strUserName.Substring(0,1).ToUpper() + strUserName.Substring(1,strUserName.Length-1).ToLower() + strRandomString1;
                strFirstName = strUserName.Substring(0, 1).ToUpper() + strUserName.Substring(1, strUserName.Length - 1).ToLower() + strRandomString1;
                strLastName = strUserName.Substring(0, 1).ToUpper() + strUserName.Substring(1, strUserName.Length - 1).ToLower() + strRandomString2;
                strFullName = strUserName.Substring(0, 1).ToUpper() + strUserName.Substring(1, strUserName.Length - 1).ToLower() + strRandomString3;
            }
            else
            {
                string[] arrUserDetails = strUserName.Split(' ');
                strFirstName = arrUserDetails[0].Substring(0, 1).ToUpper() + arrUserDetails[0].Substring(1, arrUserDetails[0].Length - 1).ToLower() + strRandomString1;
                strLastName = arrUserDetails[1].Substring(0, 1).ToUpper() + arrUserDetails[1].Substring(1, arrUserDetails[1].Length - 1).ToLower() + strRandomString2;
            }

            strCustName = strFirstName + " " + strLastName;
            return strCustName;
        }
         public virtual bool VerifyPersonalCustomerCreationSuccess()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {


            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_APPLICATION_SUCCESSFULLY_PROCESSED")))
            {
                Result = true;
            }
            }
            return Result;
        }


        public virtual string GetMessageText()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string result = "";
            result = appHandle.GetObjectText(MSGOBJ);
            return result;
        }
        public virtual void enter_home_address_details_Country_CZ(string YearsAtCurrentAddress)
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                appHandle.Set_field_value(HomeAddressLine1_Field, Data.Get("CITYCZ") + " Manson");
                appHandle.Set_field_value(HomeAddressLine2_Field, Data.Get("Prague Building"));
                appHandle.Set_field_value(HomeAddressCity_Field, Data.Get("CITYCZ"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressCountry_DropDown, (string)Data.Get("CNTRYCZ"));
                appHandle.Set_field_value(HomeAddressZipCode_Field, Data.Get("ZIPCODE_CZ"));
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown, YearsAtCurrentAddress);
                Report.Info("Home address with Country code " + Data.Get("CZ - CZECHIA") + " is entered successfully.", "CZ_Home_Addr", "true", appHandle);
            }

        }
        public virtual void enter_home_address_details_Country_TF(string YearsAtCurrentAddress)
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                appHandle.Set_field_value(HomeAddressLine1_Field, Data.Get("CITYTF") + " Manson");
                appHandle.Set_field_value(HomeAddressLine2_Field, Data.Get("CITYTF") + "Building");
                appHandle.Set_field_value(HomeAddressCity_Field, Data.Get("CITYTF"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressCountry_DropDown, (string)Data.Get("TF - FRENCH SOUTHERN TERRITORIES"));
                appHandle.Set_field_value(HomeAddressZipCode_Field, Data.Get("ZIPCODE_TF"));
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown, YearsAtCurrentAddress);
                Report.Info("Home address with Country code " + Data.Get("TF - FRENCH SOUTHERN TERRITORIES") + " is entered successfully.", "FT_Home_Addr", "true", appHandle);
            }

        }
        public virtual void enter_home_address_details_Country_VA(string YearsAtCurrentAddress)
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                appHandle.Set_field_value(HomeAddressLine1_Field, Data.Get("CITYVA") + " Manson");
                appHandle.Set_field_value(HomeAddressLine2_Field, Data.Get("CITYVA") + "Building");
                appHandle.Set_field_value(HomeAddressCity_Field, Data.Get("CITYVA"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressCountry_DropDown, (string)Data.Get("VA - HOLY SEE"));
                appHandle.Set_field_value(HomeAddressZipCode_Field, Data.Get("ZIPCODE_VA"));
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown, YearsAtCurrentAddress);
                Report.Info("Home address with Country code " + Data.Get("VA - HOLY SEE") + " is entered successfully.", "VA_Home_Addr", "true", appHandle);
            }

        }
        public virtual void enter_home_address_details_Country_MK(string YearsAtCurrentAddress)
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                appHandle.Set_field_value(HomeAddressLine1_Field, Data.Get("CITYMK") + " Manson");
                appHandle.Set_field_value(HomeAddressLine2_Field, Data.Get("CITYMK") + "Building");
                appHandle.Set_field_value(HomeAddressCity_Field, Data.Get("CITYMK"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressCountry_DropDown, (string)Data.Get("MK - NORTH MACEDONIA"));
                appHandle.Set_field_value(HomeAddressZipCode_Field, Data.Get("ZIPCODE_MK"));
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown, YearsAtCurrentAddress);
                Report.Info("Home address with Country code " + Data.Get("MK - NORTH MACEDONIA") + " is entered successfully.", "MK_Home_Addr", "true", appHandle);
            }

        }
        public virtual void enter_home_address_details_Country_WF(string YearsAtCurrentAddress)
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                appHandle.Set_field_value(HomeAddressLine1_Field, Data.Get("CITYWF") + " Manson");
                appHandle.Set_field_value(HomeAddressLine2_Field, Data.Get("CITYWF") + "Building");
                appHandle.Set_field_value(HomeAddressCity_Field, Data.Get("CITYWF"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressCountry_DropDown, (string)Data.Get("WF - WALLIS AND FUTUNA"));
                appHandle.Set_field_value(HomeAddressZipCode_Field, Data.Get("ZIPCODE_WF"));
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown, YearsAtCurrentAddress);
            }

        }

        public virtual void VerifyCountryOfResidencyCreateCustomerPage(string CountryNames)
        {
            CountryNames = CountryNames + "|";
            string[] arr = CountryNames.Split('|');
            bool Result = false;
            if (string.IsNullOrEmpty(arr[1]))
            {
                CountryNames = arr[0];
                appHandle.SelectDropdownSpecifiedValue(dropdownCountryOfResidency, (string)CountryNames);
                if (appHandle.CheckValueInDropdown(dropdownCountryOfResidency, CountryNames))
                {
                    appHandle.ScrollToObject(dropdownCountryOfResidency);
                    Report.Info(CountryNames + " is available in Country of Residency dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                }
                else
                {
                    Report.Fail(CountryNames + " is not available in Country of Residency dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvaluefail", "true", appHandle, true);
                }
            }
            else
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    appHandle.SelectDropdownSpecifiedValue(dropdownCountryOfResidency, (string)arr[i]);
                    if (appHandle.CheckValueInDropdown(dropdownCountryOfResidency, arr[i]))
                    {
                        appHandle.ScrollToObject(dropdownCountryOfResidency);
                        Report.Info(arr[i] + " is available in Country of Residency dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                    }
                    else
                    {
                        Report.Fail(arr[i] + " is not available in Country of Residency dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvaluefail", "true", appHandle, true);
                    }
                }
            }

        }
        public virtual void VerifyCountryofCitizenshipCreateCustomerPage(string CountryNames)
        {
            CountryNames = CountryNames + "|";
            string[] arr = CountryNames.Split('|');
            bool Result = false;
            if (string.IsNullOrEmpty(arr[1]))
            {
                CountryNames = arr[0];
                appHandle.SelectDropdownSpecifiedValue(CountryOfCitizenship_DropDown, (string)CountryNames);
                if (appHandle.CheckValueInDropdown(CountryOfCitizenship_DropDown, CountryNames))
                {
                    appHandle.ScrollToObject(CountryOfCitizenship_DropDown);
                    Report.Info(CountryNames + " is available in Country of Citizenship dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                }
                else
                {
                    Report.Fail(CountryNames + " is not available in Country of Citizenship dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvaluefail", "true", appHandle, true);
                }
            }
            else
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    appHandle.SelectDropdownSpecifiedValue(CountryOfCitizenship_DropDown, (string)arr[i]);
                    if (appHandle.CheckValueInDropdown(CountryOfCitizenship_DropDown, arr[i]))
                    {
                        appHandle.ScrollToObject(CountryOfCitizenship_DropDown);
                        Report.Info(arr[i] + " is available in Country of Citizenship dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                    }
                    else
                    {
                        Report.Fail(arr[i] + " is not available in Country of Citizenship dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvaluefail", "true", appHandle, true);
                    }
                }
            }

        }
        public virtual void VerifyHomeAddressCountryDropdownCreateCustomerPage(string CountryNames)
        {
            CountryNames = CountryNames + "|";
            string[] arr = CountryNames.Split('|');
            bool Result = false;
            if (string.IsNullOrEmpty(arr[1]))
            {
                CountryNames = arr[0];
                appHandle.SelectDropdownSpecifiedValue(HomeAddressCountry_DropDown, (string)CountryNames);
                if (appHandle.CheckValueInDropdown(HomeAddressCountry_DropDown, CountryNames))
                {
                    appHandle.ScrollToObject(HomeAddressCountry_DropDown);
                    Report.Info(CountryNames + " is available in Home Address Country dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                }
                else
                {
                    Report.Fail(CountryNames + " is not available in Home Address Country dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvaluefail", "true", appHandle, true);
                }
            }
            else
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    appHandle.SelectDropdownSpecifiedValue(HomeAddressCountry_DropDown, (string)arr[i]);
                    if (appHandle.CheckValueInDropdown(HomeAddressCountry_DropDown, arr[i]))
                    {
                        appHandle.ScrollToObject(HomeAddressCountry_DropDown);
                        Report.Info(arr[i] + " is available in Home Address Country dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                    }
                    else
                    {
                        Report.Fail(arr[i] + " is not available in Home Address Country dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvaluefail", "true", appHandle, true);
                    }
                }
            }

        }
        public virtual void VerifyMailingAddressCountryDropdownCreateCustomerPage(string CountryNames)
        {
            this.set_radio_button_mailing_address_same_as_home_address_no();
            CountryNames = CountryNames + "|";
            string[] arr = CountryNames.Split('|');
            bool Result = false;
            if (string.IsNullOrEmpty(arr[1]))
            {
                CountryNames = arr[0];
                appHandle.SelectDropdownSpecifiedValue(MailingAddressCountry_DropDown, (string)CountryNames);
                if (appHandle.CheckValueInDropdown(MailingAddressCountry_DropDown, CountryNames))
                {
                    appHandle.ScrollToObject(MailingAddressCountry_DropDown);
                    Report.Info(CountryNames + " is available in Mailing Address Country dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                }
                else
                {
                    Report.Fail(CountryNames + " is not available in Mailing Address Country dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvaluefail", "true", appHandle, true);
                }
            }
            else
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    appHandle.SelectDropdownSpecifiedValue(MailingAddressCountry_DropDown, (string)arr[i]);
                    if (appHandle.CheckValueInDropdown(MailingAddressCountry_DropDown, arr[i]))
                    {
                        appHandle.ScrollToObject(MailingAddressCountry_DropDown);
                        Report.Info(arr[i] + " is available in Mailiing Address Country dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvalue", "true", appHandle);
                    }
                    else
                    {
                        Report.Fail(arr[i] + " is not available in Mailing Address Country dropdown in Create Personal Customer page of Profile WebCSR", "CountryofresidencyCountryvaluefail", "true", appHandle, true);
                    }
                }
            }

        }

        public virtual void enter_home_address_details_invalid(string YearsAtCurrentAddress)
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                appHandle.Set_field_value(HomeAddressLine1_Field, Data.Get("GLOBAL_ADDRESS1IN"));
                appHandle.Set_field_value(HomeAddressLine2_Field, Data.Get("SJR-IPARK"));
                appHandle.Set_field_value(HomeAddressCity_Field, Data.Get("GLOBAL_CITY"));
                appHandle.SelectDropdownSpecifiedValue(HomeAddressCountry_DropDown, (string)Data.Get("GLOBAL_ADDCOUNTRY"));
                appHandle.SelectDropdownSpecifiedValue(HomeAddressState_DropDown, (string)Data.Get("GLOBAL_ADDSTATE"));
                appHandle.Set_field_value(HomeAddressZipCode_Field, Data.Get("GLOBAL_Invalid_POSTALCODEIN"));
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown, YearsAtCurrentAddress);
            }

        }

        public virtual void enter_mailing_address_details_invalid()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MailingAddressLine1_Field))
            {
                appHandle.Set_field_value(MailingAddressLine1_Field, Data.Get("123 Street"));
                appHandle.Set_field_value(MailingAddressLine2_Field, Data.Get("GLOBAL_ADDRESS1IN"));
                appHandle.Set_field_value(MailingAddressCity_Field, Data.Get("GLOBAL_CITY_MALVERN"));
                appHandle.SelectDropdownSpecifiedValue(MailingAddressCountry_DropDown, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                appHandle.SelectDropdownSpecifiedValue(MailingAddressState_DropDown, (string)Data.Get("PA - PENNSYLVANIA"));
                appHandle.Set_field_value(MailingAddressZipCode_Field, Data.Get("GLOBAL_Invalid_POSTALCODEIN"));
            }

        }

        public virtual void enter_previous_address_details_invalid()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(PreviousAddressCountry_DropDown))
            {
                appHandle.Set_field_value(PreviousAddressLine1_Field, Data.Get("456 Street"));
                appHandle.Set_field_value(PreviousAddressLine2_Field, Data.Get("GLOBAL_ADDRESS1IN"));
                appHandle.Set_field_value(PreviousAddressCity_Field, Data.Get("Jacksonville"));
                appHandle.SelectDropdownSpecifiedValue(PreviousAddressCountry_DropDown, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                appHandle.SelectDropdownSpecifiedValue(PreviousAddressState_DropDown, (string)Data.Get("FL - FLORIDA"));
                appHandle.Set_field_value(PreviousAddressZipCode_Field, (string)Data.Get("GLOBAL_Invalid_POSTALCODEIN"));
            }


        }
        public virtual void validate_invalid_postalcode_message()
        {
            appHandle.ClickObjectViaJavaScript(ContinueButton);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(FirstValidationMessage))
            {
                string FirstValidationMessageValue = appHandle.Get_Label_Text(FirstValidationMessage);
                string SecondValidationMessageValue = appHandle.Get_Label_Text(SecondValidationMessage);

                if ((FirstValidationMessageValue.Contains(Data.Get("InvalidZipCodeMessage"))) && (SecondValidationMessageValue.Contains(Data.Get("InvalidZipCodeMessage"))))
                {
                    Report.Pass("Validation of Zip code is successfull", "validate_invalid_postalcode_message", "true", appHandle);
                }
                else
                {
                    Report.Fail("Validation of Zip code is failed", "validate_invalid_postalcode_message", "true", appHandle, true);
                }

            }
        }
        public virtual void enterhomeaddressdetailsZipCodeValid(string city,string state,string zipCode)
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                appHandle.Set_field_value(HomeAddressLine1_Field,Data.Get("Central Real Estate"));
                appHandle.Set_field_value(HomeAddressLine2_Field,Data.Get("456 Street"));
                appHandle.Set_field_value(HomeAddressCity_Field,city);
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressCountry_DropDown,(string)Data.Get("US - UNITED STATES OF AMERICA"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressState_DropDown,(string)state);
                appHandle.Set_field_value(HomeAddressZipCode_Field,zipCode);
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown,"3");

            }

        }
        public virtual void enterhomeaddressdetailsZipCodeInValid(string InvalidZipCode)
        {
            
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                
                appHandle.Set_field_value(HomeAddressLine1_Field,Data.Get("SeaLine1"));
                appHandle.Set_field_value(HomeAddressLine2_Field,Data.Get("SeaLine2"));
                appHandle.Set_field_value(HomeAddressCity_Field,Data.Get("Rio"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressCountry_DropDown,(string)Data.Get("US - UNITED STATES OF AMERICA"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressState_DropDown,(string)Data.Get("PR - PUERTO RICO"));
                appHandle.Set_field_value(HomeAddressZipCode_Field,InvalidZipCode);
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown,"3");

            }

        }


        public virtual void enterhomeaddressdetailswithZipCode(string city, string state,string zipCode,string country ="US - UNITED STATES OF AMERICA")
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressLine1_Field))
            {
                appHandle.Set_field_value(HomeAddressLine1_Field,Data.Get("Central Real Estate"));
                appHandle.Set_field_value(HomeAddressLine2_Field,Data.Get("456 Street"));
                appHandle.Set_field_value(HomeAddressCity_Field,city);
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressCountry_DropDown,(string)country);
                appHandle.SelectDropdownSpecifiedValueByPartialText(HomeAddressState_DropDown,(string)state);
                appHandle.Set_field_value(HomeAddressZipCode_Field,zipCode);
                appHandle.SelectDropdownSpecifiedValue(HomeYearsAtAddress_DropDown,"9");

            }

        }

        public virtual bool VerifyMessageonCreatePersonalCustomerPage(string sMessage)
        {
     		bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
		}


    }
}
