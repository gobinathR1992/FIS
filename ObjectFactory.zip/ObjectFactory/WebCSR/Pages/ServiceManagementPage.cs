using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.Util;
using GTS_OSAF.HelperLibs.DataAdapter;


namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class ServiceManagementPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
               
        public static string linkEstablishedServices="XPath;//a[contains(text(),'Established Services')]";
        public static string buttonRefreshList="XPath;//input[@value='Refresh List']";
        public static string buttonRemoveCMSTAT="XPath;//input[contains(@id,'CMBSTAT-')]";
        public static string buttonRemoveESTAT="XPath;//input[contains(@id,'ESTAT-')]";


        public virtual void PerformOperationsInEstablishedServices()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkEstablishedServices);
            appHandle.ClickObjectViaJavaScript(linkEstablishedServices);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRefreshList);
            appHandle.ClickObjectViaJavaScript(buttonRemoveCMSTAT);
            appHandle.ClickObjectViaJavaScript(buttonRemoveESTAT);
            appHandle.ClickObjectViaJavaScript(buttonRefreshList);

        }
    
    
    }
}