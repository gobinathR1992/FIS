using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class PendingTransferPage
    {
        WebApplication applicationHandle;
        public static string PendingTransferLink="Xpath;//td[text()='Pending Transfers']";
        public static string PendingTramsferElement="Xpath;//h1[text()='Pending Transfers']";
        public static string PendingTransferTable="Xpath;.//*[contains(@class,'ledgerScrollable dataTable')]/tbody";
        public static string submitButton ="Xpath;//input[@name='submit']";
        public static string EditButton="Xpath;//input[@name='edit']";
        public static string PendingTransferAmountField= "Xpath;.//input[@name='EFTPAY_AMOUNT']";
        public static string TransactionUpdateMsg = "XPath;.//*[contains(@class,'info')][contains(.,'The transfer information has been updated.')]";
        public static string DeleteButton="Xpath;.//input[@name='delete']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        public virtual void NavigateToPendingFundsTransferPage()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            applicationHandle.ClickObject(PendingTransferLink);
            applicationHandle.Wait_for_object(PendingTramsferElement,2000);
        }
        public virtual void ModifyPendingTransfer(string date,string amount)
        {
            try{
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            applicationHandle.SelectRadioButtonInTable(PendingTransferTable,date);
            applicationHandle.ClickObject (EditButton);
            applicationHandle.SyncPage();
            applicationHandle.Wait_for_object(PendingTransferAmountField,20000);
            applicationHandle.Set_field_value(PendingTransferAmountField,amount);
            applicationHandle.ClickObject(submitButton);

            }
            catch (Exception e)
            {
               Report.Fail(e.Message, "SelectPendingTransfer Exception", applicationHandle); 
            }
        }
        public virtual void VerifyTransferUpdateMsg()
        {
        try{
          applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);  
          if (applicationHandle.IsObjectExists(TransactionUpdateMsg))
          {
              Report.Pass("Transaction Amount Updated successfully.", "Transaction Amount has been Updated", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
          }
          else
          {
              Report.Fail("Transaction Amount Update Failed", "Transaction Amount has not been Updated", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
          }
        }
        catch (Exception e)
        {
           Report.Fail(e.Message, "VerifyTransferUpdateMsg Exception", applicationHandle);   
        }

        }
        public virtual void DeletePendingTransfer(string date)
       {
         try
        {
        applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);  
        applicationHandle.SelectRadioButtonInTable(PendingTransferTable,date);
        applicationHandle.ClickObject(DeleteButton);
        applicationHandle.SwitchTo(SwitchInto.ALERT);
        applicationHandle.Wait_For_Specified_Time(3);
        applicationHandle.PerformActionOnAlert(PopUpAction.Accept);
        
        }
        catch (Exception e)
        {
           Report.Fail(e.Message, "DeletePendingTransfer Exception", applicationHandle);   
        }
       }
    //VerifyTransactionsInPendingTransfersTable
        public virtual bool VerifyMessagePendingPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (applicationHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

    }
}