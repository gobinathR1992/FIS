using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;
using System.Threading;
using Profile7Automation.Libraries.Helper;
using System;
using System.Linq;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanFeePage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string dropdownAccountNumber = "Xpath;//*[contains(@class,'dataTables_wrapper')]/descendant::tbody";
        private static string TblpaymentList = "Xpath;//*[contains(@id,'scheduledPayments-list_wrapper')]/descendant::tbody";

        private static string buttonEdit="Xpath;//*[@name='edit']";
        public virtual int CountFee()
        {
            int count = appHandle.GetTableRowCount(dropdownAccountNumber);
            return count;
        }
        public virtual void selectdatafromPaymentListTable(string AccountNumber)
        {
            string CDPD = Profile7CommonLibrary.ExtractDataFromDataBase("select CID,CDPD from LNBIL1 where CID = '"+AccountNumber+"' ORDER BY CDPD DESC","CDPD");
            CDPD = CDPD.Split('-')[1] + "/" + CDPD.Split('-')[2] + "/" + CDPD.Split('-')[0];
            appHandle.SelectRadioButtonInTable(TblpaymentList,CDPD);

        }
        public virtual void ClickOnEditButton()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
            }
        }




    }
}