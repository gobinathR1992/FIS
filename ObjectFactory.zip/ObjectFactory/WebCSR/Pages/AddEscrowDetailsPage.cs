using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs; 
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class AddEscrowDetailsPage
    { 
        WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string checkboxEscrow ="Xpath;//*[contains(text(),'Include Escrow')]/ancestor::*[1]/descendant::input[@type='checkbox']";
        private static string buttonSubmit = "Xpath;//*[@value='Submit']";
        private static string buttonCancel = "Xpath;//*[@value='Cancel']";
        private static string MSGOBJ = "Xpath;//div[@class='msg-box']/descendant::p[1]";
        private static string buttonAdd = "Xpath;//*[@value='Add']";        
        private static string dropdownEscrowType = "Xpath;//*[@name='escrowType']";
        private static string dropdownEscrowPayee ="Xpath;//*[@name='transferPayeeId']";
        private static string txtRemittanceDate = "Xpath;//*[@name='remittanceDate']";
        private static string txtRemittanceAmount = "Xpath;//*[@name='remittanceAmount']";
        private static string drpStatus = "Xpath;//*[@name='status']";
        private static string buttonCalculateEscrowPayment = "Xpath;//*[@name='_eventId_calculate']";

        public virtual bool ClickOnIncludeEscorwCheckBox(bool EscrowONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxEscrow))
            {
                if (EscrowONorOFF)
                {
                    if (AppHandle.CheckCheckBoxChecked(checkboxEscrow)) { Result = true; }
                    else
                    {
                        AppHandle.ClickObjectViaJavaScript(checkboxEscrow);
                        if (AppHandle.CheckCheckBoxChecked(checkboxEscrow))
                        { Result = true; }

                    }
                }
                else
                {
                    if (AppHandle.CheckCheckBoxChecked(checkboxEscrow) == false) { Result = true; }
                    else
                    {
                        AppHandle.ClickObjectViaJavaScript(checkboxEscrow);
                        if (AppHandle.CheckCheckBoxChecked(checkboxEscrow) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }

        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                AppHandle.ClickObjectViaJavaScript(buttonAdd);
                
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                AppHandle.ClickObjectViaJavaScript(buttonSubmit);
                
            }
        }
        
        //public virtual void CalculatePeriodicEscrowPayment(string Escrowtype,string Escrowpayee,string remittancedate,string remittanceamt,string status)
        public virtual void CalculatePeriodicEscrowPayment(string EscrowDetailsSemicolonDelimiter)
        {
            ClickOnAddButton();
            string Escrowtype=EscrowDetailsSemicolonDelimiter.Split(';')[0];
            string Escrowpayee=EscrowDetailsSemicolonDelimiter.Split(';')[1];
            string remittanceamt=EscrowDetailsSemicolonDelimiter.Split(';')[2];
            string status=EscrowDetailsSemicolonDelimiter.Split(';')[3];

            if(!string.IsNullOrEmpty(Escrowtype))
            {
                AppHandle.SelectDropdownSpecifiedValueByPartialText(dropdownEscrowType,Escrowtype);
            }
            if(!string.IsNullOrEmpty(Escrowpayee))
            {
                AppHandle.SelectDropdownSpecifiedValueByPartialText(dropdownEscrowPayee,Escrowpayee);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            ClickOnAddButton();
            //AppHandle.Set_field_value(txtRemittanceDate,remittancedate);
            AppHandle.Set_field_value(txtRemittanceAmount,remittanceamt);
            if(!string.IsNullOrEmpty(status))
            {
                AppHandle.SelectDropdownSpecifiedValueByPartialText(drpStatus,status);
            }
            ClickOnSubmitButton();
            ClickOnSubmitButton();
            AppHandle.ClickObjectViaJavaScript(buttonCalculateEscrowPayment);
            ClickOnSubmitButton();

        }         
    }
}