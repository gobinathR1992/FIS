using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class TransactionProcessingPage
    {
        static WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string General_Link = "Xpath;//a[contains(text(),'General')]";
        public static string Overdraft_Processing_Link = "Xpath;//a[contains(text(),'Overdraft Processing')]";
        public static string Investment_Sweep_Link = "Xpath;//a[contains(text(),'Investment Sweep')]";
        public static string NSF_Counters_Link = "Xpath;//a[contains(text(),'NSF Counters')]";
        public static string Negative_Balance_Counters_Link = "Xpath;//a[contains(text(),'Negative Balance Counters')]";
        public static string ATMPOS_Overdraft_Counters_Link = "Xpath;//a[contains(text(),'//a[contains(text(),'POS Overdraft Counters')]')]";
        public static string Return_Item_Counters_Link = "Xpath;//a[contains(text(),'//a[contains(text(),'Return Item Counters')]')]";
        public static string Savings_Incentive_Link = "Xpath;//a[contains(text(),'//a[contains(text(),'Savings Incentive')]')]";
        public static string Target_Balance_Accounts_Link = "Xpath;//a[contains(text(),'//a[contains(text(),'Target Balance Accounts')]')]";
        public static string Cancel_Button = "Xpath;//input[@value='Cancel']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string MSGDIV = "XPath;//div[@class='msg-box']/descendant::div";
        private static string buttonSubmit = "XPath;//input[@name='submit']";
        private static string txtReconcillationFrequency = "XPath;//*[contains(text(),'Reconciliation Frequency')]/following-sibling::td/input";
        private static string txtOffsetDays = "XPath;//*[contains(text(),'Offset Days')]/following-sibling::td/input";
        private static string dropdownAvailableBalanceCalculationCode = "XPath;//*[@name='DEP_BALAVLCODE']";
        private static string dropdownInvestmentSweepEligiblity = "XPAth;//*[@name='DEP_SWPF']";
        private static string dropdownInvestmentSweepType = "XPAth;//*[@name='DEP_SWPOPT']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string dropdownOverdraftOption="Xpath;//*[@name='ACN_ODO']";
        private static string txtTargetAccount = "Xpath;//input[@name='LN_SDTA']";
        private static string txtMaximumNumberofDisbursements = "Xpath;//input[@name='LN_MAXDRCT']";
        private static string chkboxDisbursementScheduleProcessing = "Xpath;//input[@name='LN_DSCHPR']";
        private static string btnAdd = "Xpath;//input[@name='add']";
        private static string txtDisbursementDate = "Xpath;//input[@name='LNDS1_SDD']";
        private static string txtDisbursementAmount = "Xpath;//input[@name='LNDS1_SDA']";
        private static string txtDisbursementDescription = "Xpath;//input[@name='LNDS1_CMT']";
        private static string chkboxAutomaticDisbursement = "Xpath;//input[@name='LNDS1_SDM']";
        
        private static string txtMinimumBalance = "Xpath;//*[@name='DEP_MINBAL']";


        public virtual void select_general_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(General_Link);
            applicationHandle.Wait_for_object(Cancel_Button, 5);
        }

        public virtual void select_overdraft_processing_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Overdraft_Processing_Link);
        }

        public virtual void select_investment_sweep_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Investment_Sweep_Link);
        }

        public virtual void select_nsf_counters_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(NSF_Counters_Link);
        }

        public virtual void select_negative_balance_counters_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Negative_Balance_Counters_Link);
        }

        public virtual void select_atm_pos_overdraft_counters_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(ATMPOS_Overdraft_Counters_Link);
        }

        public virtual void select_return_item_counters_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Return_Item_Counters_Link);
        }

        public virtual void select_savings_incentive_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Savings_Incentive_Link);
        }

        public virtual void select_target_balance_accounts_link()
        {
            applicationHandle.Wait_For_Specified_Time(2);
            applicationHandle.Select_link(Target_Balance_Accounts_Link);

        }

        public virtual void EnterDataInTransactionProcessingLoanAccount(string LabelNamePipeLineInputValue)
        {

            LabelNamePipeLineInputValue = LabelNamePipeLineInputValue + ";";
            string[] arr = LabelNamePipeLineInputValue.Split(';');
            if (arr[1].Equals(string.Empty))
            {
                applicationHandle.Set_field_value("XPath;//*[contains(text(),'" + arr[0].Split('|')[0] + "')]/following-sibling::*/descendant::input", arr[0].Split('|')[1]);
            }
            else
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    applicationHandle.Set_field_value("XPath;//*[contains(text(),'" + arr[i].Split('|')[0] + "')]/following-sibling::*/descendant::input", arr[i].Split('|')[1]);
                }
            }
        }
        public virtual bool VerifyMessageInTransactionProcessingPage(string InputMSGWithPipeDelimiter)
        {
            bool Result = false;
            int count = 0;
            string tempmsg = "";
            int msgcount = applicationHandle.GetRowCountfromList(MSGDIV);
            for (int a = 1; a <= msgcount; a++)
            {
                tempmsg = tempmsg + "%" + applicationHandle.GetObjectText(MSGDIV + "/*[" + a + "]");
            }
            tempmsg = tempmsg.Substring(1, tempmsg.Length - 1);
            InputMSGWithPipeDelimiter = InputMSGWithPipeDelimiter + "|";
            string[] arr = InputMSGWithPipeDelimiter.Split('|');
            if (arr[1].Equals(string.Empty))
            {
                if (tempmsg.Contains(arr[0]))
                {
                    Result = true;
                }
            }
            else
            {
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    if (tempmsg.Contains(arr[i]))
                    {
                        count++;
                    }
                }
                if (count == (arr.Length) - 1)
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                applicationHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual void EnterTransactionAcceptanceInstructions(string sReconcillationFreq = "", string sOffsetDays = "")
        {
            if (string.IsNullOrEmpty(sReconcillationFreq))
            {
                sReconcillationFreq = Data.Get("1MAE");
            }
            if (string.IsNullOrEmpty(sOffsetDays))
            {
                sOffsetDays = Data.Get("GLOBAL_VALUE_1");
            }
            applicationHandle.Set_field_value(txtReconcillationFrequency, sReconcillationFreq);
            applicationHandle.Set_field_value(txtOffsetDays, sOffsetDays);
            Report.Info("Reconcillation frequency and Offset days are entered.", "Transactdata", "true", applicationHandle);
        }
        public virtual void SelectAvailableBalanceCalculationCode(string itemToBeSelected)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAvailableBalanceCalculationCode))
            {
                applicationHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAvailableBalanceCalculationCode, (string)itemToBeSelected);
            }
        }
        public virtual void SelectInvestmetSweepDetail(string InvestmentSweepEligibility, string InvestSweepType)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownInvestmentSweepEligiblity))

            {
                applicationHandle.SelectDropdownSpecifiedValue(dropdownInvestmentSweepEligiblity, InvestmentSweepEligibility);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownInvestmentSweepType);
                applicationHandle.SelectDropdownSpecifiedValue(dropdownInvestmentSweepType, InvestSweepType);
            }
        }
         public virtual void SelectOverdraftOption(string OverdraftOption)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownOverdraftOption))

            {
                applicationHandle.SelectDropdownSpecifiedValue(dropdownOverdraftOption,OverdraftOption);
            }
        }

        public virtual bool VerifySuccessfulUpdateMessageInTransactionProcessingPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (applicationHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual void UpdateTransactionProcessingDisbursementSchedule(string SecondaryAccount, string MaximumNumberOfDisbursements, bool DisbursementScheduleProcessing)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtTargetAccount))
            {
                if (!string.IsNullOrEmpty(txtTargetAccount))
                {
                    applicationHandle.Set_field_value(txtTargetAccount, SecondaryAccount);
                }
                if (!string.IsNullOrEmpty(MaximumNumberOfDisbursements))
                {
                    applicationHandle.Set_field_value(txtMaximumNumberofDisbursements, MaximumNumberOfDisbursements);
                }
                if (DisbursementScheduleProcessing)
                {
                    if (applicationHandle.CheckCheckBoxChecked(chkboxDisbursementScheduleProcessing))
                    {
                        // applicationHandle.ClickObjectViaJavaScript(chkboxDisbursementScheduleProcessing);
                    }
                    else
                    {
                        applicationHandle.ClickObjectViaJavaScript(chkboxDisbursementScheduleProcessing);
                    }
                }
                if (!DisbursementScheduleProcessing)
                {
                    if (applicationHandle.CheckCheckBoxChecked(chkboxDisbursementScheduleProcessing))
                    {
                        applicationHandle.ClickObjectViaJavaScript(chkboxDisbursementScheduleProcessing);
                    }
                    else
                    {
                        // applicationHandle.ClickObjectViaJavaScript(chkboxDisbursementScheduleProcessing);
                    }
                }
            }
        }

        public virtual void AddDisbursementSchedule(string DisbursementDate, string DisbursementAmount, string DisbursementDescription, bool AutomaticDisbursement)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnAdd))
            {
                applicationHandle.ClickObjectViaJavaScript(btnAdd);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDisbursementDate))
                {
                    if (!string.IsNullOrEmpty(DisbursementDate))
                    {
                        applicationHandle.Set_field_value(txtDisbursementDate, DisbursementDate);
                    }
                    if (!string.IsNullOrEmpty(DisbursementAmount))
                    {
                        applicationHandle.Set_field_value(txtDisbursementAmount, DisbursementAmount);
                    }
                    if (!string.IsNullOrEmpty(DisbursementDescription))
                    {
                        applicationHandle.Set_field_value(txtDisbursementDescription, DisbursementDescription);
                    }
                    if (AutomaticDisbursement)
                    {
                        if (applicationHandle.CheckCheckBoxChecked(chkboxAutomaticDisbursement))
                        {
                            // applicationHandle.ClickObjectViaJavaScript(chkboxDisbursementScheduleProcessing);
                        }
                        else
                        {
                            applicationHandle.ClickObjectViaJavaScript(chkboxAutomaticDisbursement);
                        }
                    }
                    if (!AutomaticDisbursement)
                    {
                        if (applicationHandle.CheckCheckBoxChecked(chkboxAutomaticDisbursement))
                        {
                            applicationHandle.ClickObjectViaJavaScript(chkboxAutomaticDisbursement);
                        }
                        else
                        {
                            // applicationHandle.ClickObjectViaJavaScript(chkboxDisbursementScheduleProcessing);
                        }
                    }
                }
            }
        }
        public virtual void UpdateMinimumBalaceinTransactionRestri(string MinBalance)
        {
            applicationHandle.WaitUntilElementExists(txtMinimumBalance);
            applicationHandle.Set_field_value(txtMinimumBalance, MinBalance);
        }




        }

    }
