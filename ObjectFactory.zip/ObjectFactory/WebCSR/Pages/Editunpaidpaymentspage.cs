
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class Editunpaidpaymentspage
    {
        public static string txtUnpaidPrincipal = "XPath;//input[@name='LNBIL1_PE02AD']";
        public static string txtUnpaidInterest = "XPath;//input[@name='LNBIL1_PE01AD']";
    }
}