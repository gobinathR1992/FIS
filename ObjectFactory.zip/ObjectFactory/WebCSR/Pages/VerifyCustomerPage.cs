﻿using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using System;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class VerifyCustomerPage
    {
        WebApplication applicationHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string NextPageDropDownButton = "Name;nextpage";
        public static string VerificationActionGotoDropdown = "Xpath;//select[@name='nextpage']";
        public static string CustomerContactReasonforCustomerSearchDropdown = "Xpath;//select[@name='customerInquiryReason']";
        public static string VerificationActionRadiobutton = "Xpath;//body[@class='main']//tr//tr//tr[1]//td[1]//input[1]";
        public static string CustomerInformationNameTable = "Xpath;//body[@class='main']/table[@id='mainTable']/tbody/tr/td[@id='content']/table/tbody/tr/td/table/tbody/tr/td/form[@name='customerSearchForm']/table[@class='contentTable']/tbody/tr[5]/td[1]/table[1]/tbody[1]/tr[1]/td[1]";
        public static string CustomerInformationTaxIDTable = "Xpath;//body[@class='main']//td[@id='content']//td//td//td//td[1]//table[1]";
        public static string VerifyCustomerPage_SubmitButton = "Xpath;//input[@name='submit']";
        public static string VerifyCustomerPage_CancelButton = "Xpath;//input[@name='cancel']";
        public static string drpVerificationMethod = "Xpath;//select[@name='CIF_ZVALMETH']";

        public static string buttonSubmit="XPath;//input[@name='submit']";

        public virtual void VerificationAction(string actionType)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(NextPageDropDownButton))
            {
            applicationHandle.SelectDropdownSpecifiedValue(NextPageDropDownButton, actionType);
            }

        }

        /// <summary>
        /// This method is select to Create Retirement Plan from dropdown
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.VerifyCustomerPage.SelectCreateRetirementPlanFromDropdown();
        /// </example>
        public virtual void SelectCreateRetirementPlanFromDropdown()
        {
            try
            {
                Report.Info("Selection retirement plan from dropdown");
                string retirementPlan = Data.Get("GLOBAL_CREATE_RETIREMENT_PLAN_ITEM");
                applicationHandle.SelectDropdownSpecifiedValue(NextPageDropDownButton, retirementPlan);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

         /// <summary>
        /// This method is select to Create Retirement Account from dropdown
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.VerifyCustomerPage.SelectRetirementAccountFromDropdown();
        /// </example>
        public virtual void SelectRetirementAccountFromDropdown()
        {
            try
            {
                Report.Info("Selection retirement Account from dropdown");
                string retirementaccount = Data.Get("GLOBAL_CREATE_RETIREMENT_ACCOUNT_ITEM");
                applicationHandle.SelectDropdownSpecifiedValue(NextPageDropDownButton, retirementaccount);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to check verification method exists in verify customer page
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRPageFactory.VerifyCustomerPage.isVerificationMethodExists();
        /// </example>
        public virtual bool isVerificationMethodExists()
        {
            bool bCheck = false;
            try
            {
                applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                bCheck = applicationHandle.IsObjectExists(drpVerificationMethod);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged: " + e);
            }
            return bCheck;
        }

        /// <summary>
        /// This method is used to select verification option
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.VerifyCustomerPage.selectVerificationOption();
        /// </example>
        public virtual void selectVerificationOption(string option="Other")
        {
            try
            {
                applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                applicationHandle.SelectDropdownSpecifiedValue(drpVerificationMethod,option);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged: " + e);
            }
        }

        public virtual void SelectValueFromVerificationDropdown(string value)
        {
            
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(VerificationActionGotoDropdown);
            applicationHandle.SelectDropdownSpecifiedValue(VerificationActionGotoDropdown,value);
       
        }

        public virtual void ClickOnSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            applicationHandle.ClickObjectViaJavaScript(buttonSubmit);


        }

    }
}
