﻿using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using OpenQA.Selenium;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class WebCSRMasterPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string lnk_Basic_Services = "Xpath;//td[contains(text(),'Basic Services')]";
        public static string lnk_Create_Personal_Customer = "Xpath;//td[contains(text(),'Create Personal Customer')]";
        public static string lnkCorporateCustomer = "Xpath;//td[contains(text(),'Create Corporate Customer')]";
        public static string lnkCreateTrustCustomer = "Xpath;//td[contains(text(),'Create Trust Customer')]";

        //CreatePersonalCustomerLink
        public static string btn_Create_Personal_Customer_Continue = "Xpath;//input[@value='Continue']";
        public static string CreatePersonalCustSubmitbtn = "Xpath;//input[@type='submit'][@name='_eventId_submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        public static string CreateAccountSubmitButton = "XPATH;//input[@type='submit'][@name='_eventId_submit']";
        public static string CustomerServiceSubmitButton = "Xpath;//input[@type='submit'][@name='submit']";
        public static string CreateAccountContinueButton = "XPATH;//input[@type='submit'][@name='_eventId_continue']";
        public static string SearchCustomerLink = "Xpath;.//*[contains(@class,'menuSub')][contains(., 'Customer Search')]";
        public static string appdate = "Xpath;//button[@name='logout']/..";
        public static string GeneralAccuntServicesTab = "Xpath;//td[contains(text(),'General Account Services')]";
        public static string AccountVerificationDropdown = "Xpath;//select[@name='ACN_CID']";
        public static string AccountVerificationLink = "Xpath;.//td[contains(text(), 'Account Verification')]";
        public static string btnOverride = "Xpath;//span[@class='ui-button-text'][contains(text(),'Override')]";
        public static string btnCancel = "Xpath;//span[@class='ui-button-text'][contains(text(),'Cancel')]";
        public static string popupAuthorizationWindow = "Xpath;//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-dialog-buttons']";
        public static string tblCustomerInformation = "Xpath;//h1[text()='Customer Information']/parent::td/parent::tr/parent::tbody/parent::table";
        public static string btnSubmit = "name;submit";

        public static string btnContinue = "name;_eventId_continue";
        public static string btnSearch = "Xpath;//input[@name='_eventId_customerSearch']";
        public static string rdbCustomerFound = "Xpath;//input[@name='customerNumber']";
        public static string btnRelease = "Xpath;//input[@value='Release'][@type='submit']";
        public static string btnAdd = "Xpath;//input[@value='Add'][@type='submit']";
        public static string btnEdit = "name;edit";
        public static string btnDelete = "name;delete";
        public static string lnkRevolvingOptions = "Xpath;//a[contains(text(),'Revolving Options')]";
        public static string drpFrequencyInFrequencyCalculator = "Xpath;//form[@name='M']//select[@name='frequency']";
        public static string btnSubmitInFrequencyCalculator = "Xpath;//input[@id='mySubmit']";
        public static string lnkBillingStatement = "Xpath;//a[contains(text(),'Billing Statement')]";
        public static string buttonAdvanced = "Xpath;//button[contains(text(),'Advanced')]";
        public static string linkUnsafe = "XPath;//a[contains(text(),'unsafe')]";
        public static string btnLoginPageSubmit = "XPath;//*[@name='_eventId_submit']";
        public static string btnCustSearchPageSubmit = "XPATH;//INPUT[@value='Submit']";
        public static string linkRateDetermination="XPath;//a[contains(text(),'Rate Determination')]";
        public static string linkDelinquencyoption="XPath;//a[contains(text(),'Delinquency Options')]";
        
        public static string lnkCreateTrustAccount="Xpath;//td[contains(text(),'Create Trust Account')]";
        public virtual void select_create_personal_customer_link()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(lnk_Create_Personal_Customer))
            {
                appHandle.Select_link(lnk_Create_Personal_Customer);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(btn_Create_Personal_Customer_Continue);


        }

        public virtual void select_basic_secivces_menu_link()
        {
            appHandle.ClickObject(lnk_Basic_Services);
            appHandle.Wait_for_object(lnk_Create_Personal_Customer, 3);
            appHandle.ClickObject(lnk_Create_Personal_Customer);
        }

        //Method for Click the Corporate Customer link.
        public virtual void SelectCorporateCustomerLink()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(lnkCorporateCustomer))
            {
                appHandle.Select_link(lnkCorporateCustomer);
            }

            Profile7CommonLibrary.WaitForSpecifiedObjectExists(btn_Create_Personal_Customer_Continue, 10);
        }

        public virtual void SelectTrustCustomerLink()
        {
            appHandle.ClickObject(lnk_Basic_Services);
            appHandle.ClickObject(lnkCreateTrustCustomer, 3);
        }

        public virtual void select_submit_button()
        {
            appHandle.Wait_For_Specified_Time(3);
            appHandle.SelectButton(CreateAccountSubmitButton);
            appHandle.Wait_For_Specified_Time(3);
            Report.Info("Clicked on CreateAccount <Submit> button");
        }

        public virtual void CustomerSubmit()
        {
            appHandle.Wait_For_Specified_Time(5);
            appHandle.SelectButton(CustomerServiceSubmitButton);
            appHandle.Wait_For_Specified_Time(5);
            Report.Info("Clicked on <VerifyCustomerPageSubmit> button");
        }

        public virtual string GetApplicationDate()
        {
            return appHandle.SplitSideString(appHandle.GetLabelText(appdate), "left", 10);
        }

        public virtual void select_continue_button()
        {
            appHandle.SelectButton(CreatePersonalCustSubmitbtn);
            appHandle.Wait_For_Specified_Time(5);
            Report.Info("Clicked on CreatePersonal Customer <Continue> button");
        }

        public virtual void Continue()
        {
            appHandle.SelectButton(CreateAccountContinueButton);
            appHandle.Wait_For_Specified_Time(5);
            Report.Info("Clicked on <Continue> button");
        }

        public virtual void PersonalCustSubmit()
        {
            appHandle.SelectButton(CreatePersonalCustSubmitbtn);
            appHandle.Wait_For_Specified_Time(5);
            Report.Info("Clicked on <Continue> button");
        }

        public static string get_account_number_link(string sAccountNumber)
        {
            string accLink = "Xpath;//td[text()='Account Number']";
            return accLink;
        }

        public virtual bool Check_Specified_Data_Available_In_Table1(string tableName, string referenceValues)
        {
            bool flag = false;
            try
            {
                string[] refValues = referenceValues.Split(';');
                int refValueCount = (refValues.Length) - 1;
                List<int> lstColIndex = new List<int>();
                List<string> lstRefValue = new List<string>();
                string strExpValue = refValues[refValueCount];
                string strExpColumn = refValues[refValueCount - 1];
                IList<object> validRow = new List<object>();

                //WebCSRPageFactory.AccountOverviewPage.select_account_history_tab();
                IList<object> col = WebCSRPageFactory.AccountHistoryPage.ColumnsInTable(tableName);
                appHandle.GetColumnIndexesFromColumnValues(refValues, lstColIndex, lstRefValue, col);

                validRow = FindMatchingRows(tableName, lstColIndex, lstRefValue);
                int colIndex = lstColIndex.Count;
                colIndex = colIndex - 1;
                int val = lstColIndex[colIndex - 1];
                val = lstColIndex[colIndex];
                string columnvalue = GetColumnValueFromTableWithIndex(validRow, "XPATH;.//td[" + lstColIndex[lstColIndex.Count - 1] + "]");
                if (columnvalue != null)
                {
                    if (columnvalue.ToUpper() == strExpValue.ToUpper())
                    {
                        flag = true;
                        Report.Pass("Successfully found the matching entry for reference value: " + referenceValues + "in table <AccountHistoryTable> under column " + strExpColumn, "Account Histroy", "True", appHandle);
                    }
                }
                else
                {
                    Report.Fail("Matching entry not found for reference value: " + referenceValues + "in table <AccountHistoryTable> under column " + strExpColumn, "Account History", "True", appHandle);
                }
            }
            catch (Exception e)
            { Report.Fail(e.Message, "Check_Specified_Data_Available_In_Table Exception", appHandle); }
            return flag;
        }

        private string GetColumnValueFromTableWithIndex(IList<object> validRow, string v)
        {
            if (validRow.Count > 0)
                return appHandle.GetObjectText(v, validRow[0]);
            return null;
        }

        public virtual IList<object> FindMatchingRows(string ObjectTable, List<int> lstColIndex, List<string> lstRefValue)
        {
            IList<object> row = WebCSRPageFactory.AccountHistoryPage.RowValue(ObjectTable);
            int rowCount = row.Count;
            bool bMatch = true;
            List<int> newlstColIndex = new List<int>();
            IList<object> matchingElement = new List<object>();

            for (int i = 0; i < row.Count; i++)
            {
                bMatch = true;
                try
                {
                    for (int j = 0; j < lstColIndex.Count; j++)
                    {
                        string columnValue = appHandle.GetObjectText("XPATH;.//td[" + lstColIndex[j] + "]", row[i]);
                        if (columnValue.ToUpper() != lstRefValue[j].ToUpper())
                        {
                            bMatch = false;
                            break;
                        }
                    }
                    if (bMatch)
                        matchingElement.Add(row[i]);
                }
                catch (Exception e)
                {
                    Report.Info("Following exception logged: " + e.Message);
                }
            }
            return matchingElement;
        }

        public virtual void CloseBrowser()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.CloseApplication(this);
        }

        public virtual void launch_webcsr_url()
        {appHandle.LaunchApplication(Util.BaseURLGenerator.Generate(Data.Get("GLOBAL_WEBCSR_URL_NAME")),"Chrome");
            
            IWebDriver CurrentDriver = (IWebDriver)appHandle.GetWebDriver();

            if (CurrentDriver.Title.Equals("Privacy error"))
            {
                OverComeAdvancedBrowserConn();
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnLoginPageSubmit);
            }


        }

        public virtual void OverComeAdvancedBrowserConn()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdvanced, 2))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdvanced);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkUnsafe, 2))
                {
                    appHandle.ClickObjectViaJavaScript(linkUnsafe);
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnLoginPageSubmit);
                }
            }
        }
        public virtual string SelectAccountLink(string accNum)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string actNum = appHandle.GetLabelText(accNum);
            if (appHandle.IsObjectExists(accNum))
                appHandle.Select_link(accNum);
            return actNum;
        }

        public virtual void launch_web_url()
        {
            appHandle.LaunchApplication("https://web2.atldev.com/WebCSR-qarellx2/");
        }

        public virtual void check_account_verification_link_exist()
        {
            bool ObjExist = appHandle.CheckObjectExist(AccountVerificationLink);
            if (ObjExist)
            {
                Report.Pass("Account Verification Link is available ", "General Account Services", "True", appHandle);
            }
            else
            {
                Report.Fail("Account Verification Link is not available  ", "General Account Services", "True", appHandle);
            }
            appHandle.ClickObject(AccountVerificationLink);
        }

        public virtual void navigate_to_account_verification_page()
        {
            try
            {
                appHandle.SelectDropdownSpecifiedValue(AccountVerificationDropdown, "CON ACCT - 500000002176 - USD");
                appHandle.CheckSuccessMessage("Account passes integrity verification without error.");
                appHandle.SyncPage();
            }
            catch (Exception e)
            { Report.Fail(e.Message, "NavigateToAccountVerificationPage Exception", appHandle); }
        }

        public virtual string CalculateDate(string startdate, string dparam, int numberofDay)
        {
            return appHandle.CalculateNewDate(startdate, dparam, numberofDay);
        }

        // public virtual string get_application_under_test()
        // {
        //     string sApplicationUnderTest = null;
        //     string sProfileRelease = StartupConfiguration.EnvironmentDetails.PROFILE_RELEASE;

        //     switch (sProfileRelease.ToUpper())
        //     {
        //         case "V70":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V70");
        //             break;
        //         case "V72":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V72");
        //             break;
        //         case "V732":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V732");
        //             break;
        //         case "V7321":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V7321");
        //             break;
        //         case "V731":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V731");
        //             break;
        //         case "V73":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V73");
        //             break;
        //         case "V733":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V733");
        //             break;
        //         case "V734":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V734");
        //             break;
        //         case "V741":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V741");
        //             break;
        //         case "V742":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V742");
        //             break;
        //         case "V751":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V751");
        //             break;
        //         case "V752":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V752");
        //             break;
        //         case "V753":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V753");
        //             break;
        //         case "V754":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V754");
        //             break;
        //         case "V755":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V755");
        //             break;
        //         case "V761":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V761");
        //             break;
        //         case "V762":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V762");
        //             break;
        //         case "V763":
        //             sApplicationUnderTest = Data.Get("GLOBAL_PROFILE_RELEASE_V763");
        //             break;
        //     }
        //     return sApplicationUnderTest;
        // }

        /// <summary>
        /// To select link under Tab by clicking on Tab.
        /// <param name= "TabName"></param> 
        /// <param name= "LinkName"></param> 
        /// <returns></returns>
        /// <example>SelectLinkinTab(TabName,LinkName)</example>
        public void SelectLinkinTab(string TabName, string LinkName = null)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle.WaitUntilElementVisible(TabName);
                appHandle.WaitUntilElementClickable(TabName);
                string obj = TabName + "/preceding-sibling::td/img[contains(@src,'open')]";
                if (!(appHandle.IsObjectExists(obj)))
                    appHandle.ClickObject(TabName);
                if (LinkName != null && LinkName != "")
                {
                    appHandle.WaitUntilElementClickable(LinkName);
                    appHandle.Select_link(LinkName);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }

        }

        /// <summary>
        /// To verify Expected Message.
        /// <param name= "Expected Message"></param> 
        /// <returns></returns>
        /// <example>CheckSuccessMessage(message)</example>
        public virtual bool CheckSuccessMessage(string message = null)
        {
            bool bCheck = false;
            try
            {
                if (message != null && message != "")
                    bCheck = appHandle.CheckSuccessMessage(message);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bCheck;
        }

        /// <summary>
        /// To Split the given string with specified delimeter.
        /// <param name= "Main String"></param> 
        /// <param name= "Delimeter"></param>
        /// <returns>string array</returns>
        /// <example>SplitString(sMainString,sDelimeter)</example>
        public string[] SplitString(string sMainString, string sDelimeter)
        {
            string[] arrstrng = null;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                arrstrng = appHandle.SplitString(sMainString, sDelimeter);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return arrstrng;
        }

        /// <summary>
        /// To Calculate New Date.
        /// <param name= "InputDate"></param> 
        /// <param name= "DateParam"></param>
        /// <param name= "NumberofDays"></param>
        /// <returns>string</returns>
        /// <example>CalculateNewDate(sInputDate,sDateParam,iNumberofDays)</example>
        public string CalculateNewDate(string sInputDate, string sDateParam, int iNumberofDays)
        {
            string NewDate = null;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                NewDate = appHandle.CalculateNewDate(sInputDate, sDateParam, iNumberofDays);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return NewDate;
        }
        /// <summary>
        /// To Split right or left of the given string with specified Index.
        /// <param name= "Main String"></param> 
        /// <param name= "Side"></param>
        /// <param name= "Index"></param>
        /// <returns>string</returns>
        /// <example>SplitSideString(sMainString,sSide,iIndex)</example>
        public string SplitSideString(string sMainString, string sSide, int iIndex = 0)
        {
            string NewString = null;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                NewString = appHandle.SplitSideString(sMainString, sSide, iIndex);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return NewString;
        }

        /// <summary>
        /// This method is used to click on override button.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.ClickOnOverrideButton();
        /// </example>
        public virtual void ClickOnOverrideButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnOverride);
                appHandle.WaitUntilElementClickable(btnOverride);
                appHandle.ClickObject(btnOverride);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        /// <summary>
        /// This method is used to click on Cancel button.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.ClickOnCancelButton();
        /// </example>
        public virtual void ClickOnCancelButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnCancel);
                appHandle.WaitUntilElementClickable(btnCancel);
                appHandle.ClickObject(btnCancel);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// To check whether Authorization window exists .
        /// <returns>true/false</returns>
        /// <example>IsAuthorizationWindowExists</example>
        public virtual bool IsAuthorizationWindowExists()
        {
            bool bCheck = false;
            try
            {
                appHandle.WaitUntilElementVisible(popupAuthorizationWindow);
                bCheck = appHandle.IsObjectExists(popupAuthorizationWindow);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;
        }

        /// <summary>
        /// This method is used to check Message exists in Table.
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRMasterPage.CheckMessageExistsInTable(Date;10/11/2010;Description;Debit,tableXpath);
        /// </example>
        public virtual bool CheckMessageExistsInTable(string sRefValue, string sTableName)
        {
            bool bCheck = false;
            try
            {
                if (appHandle.IsObjectExists(sTableName))
                {
                    bCheck = Check_Specified_Data_Available_In_Table1(sRefValue, sTableName);
                }
                else
                {
                    Report.Info("Table name not found.");
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;

        }

        /// <summary>
        /// This method is used to select tab in table.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.SelectTabInTable(TableName, TabName);
        /// </example>
        public virtual void SelectTabInTable(string TableName, string TabName)
        {
            try
            {
                appHandle.WaitUntilElementVisible(TableName);
                appHandle.SelectTabInTable(TableName, TabName);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used to click on submit button.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.ClickOnSubmitButton;
        /// </example>
        public virtual void ClickOnSubmitButton()
        {

            try
            {
                appHandle.WaitUntilElementVisible(btnSubmit);
                appHandle.ClickObject(btnSubmit);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        /// <summary>
        /// This method is used to verify message exists.
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRMasterPage.CheckMessageExists;
        /// </example>
        public virtual bool CheckMessageExists(string msg)
        {
            bool bCheck = false;
            try
            {
                bCheck = appHandle.CheckSuccessMessage(msg);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;
        }
        /// <summary>
        /// This method is used to click on continue button.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.ClickOnContinueButton();
        /// </example>
        public virtual void ClickOnContinueButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnContinue);
                appHandle.ClickObject(btnContinue);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        public virtual void ClickonSearchbutton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(btnSearch);
        }

        public virtual void selectbuttonforcustomerfound()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.WaitUntilElementVisible(rdbCustomerFound);
            appHandle.WaitUntilElementClickable(rdbCustomerFound);
            appHandle.ClickObject(rdbCustomerFound);
        }

        /// <summary>
        /// This method is used to get text .
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.GetFieldValue(AccountInformationPage.txtMaturityInformationAccountTerm);
        /// </example>
        public virtual string GetFieldValue(string FieldName)
        {
            string outputValue = null;
            try
            {
                outputValue = appHandle.GetElementValue(FieldName);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return outputValue;
        }

        /// <summary>
        /// This method is used to get selected dropdown value.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.GetDropdownValue(AccountInformationPage.drpRenewalInformationPrincipalMaturityOption);
        /// </example>
        public virtual string GetDropdownValue(string DropDown)
        {
            string outputValue = null;
            try
            {
                outputValue = appHandle.GetDropdownSelectedValue(DropDown);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return outputValue;
        }
        /// <summary>
        /// This method is used to get checkbox status.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.GetCheckBoxStatus(AccountInformationPage.chkExtendMaturitywithDeposit);
        /// </example>
        public virtual string GetCheckBoxStatus(string CheckBox)
        {
            string outputValue = null;
            try
            {
                bool cbkStatus = appHandle.CheckCheckBoxChecked(CheckBox);
                outputValue = cbkStatus.ToString();
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return outputValue;
        }

        /// <summary>
        /// This method is used to enter specified value in text field.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.SetFieldValue(AccountInformationPage.txtMaturityInformationAccountTerm,"2Y");
        /// </example>
        public virtual void SetFieldValue(string objXpath, string value)
        {
            try
            {
                appHandle.Set_field_value(objXpath, value);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        /// <summary>
        /// This method is used to select specified value from the dropdown.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.SelectDropdownValue(AccountInformationPage.drpRenewalInformationPrincipalMaturityOption,"1 - Pay by Check");
        /// </example>
        public virtual void SelectDropdownValue(string objXpath, string value)
        {
            try
            {
                appHandle.SelectDropdownSpecifiedValue(objXpath, value);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        /// <summary>
        /// This method is used to select and deselect checkbox.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.SelectCheckBox(AccountInformationPage.chkExtendMaturitywithDeposit,"ON");
        /// </example>
        public virtual void SelectCheckBox(string objXpath, string value)
        {
            try
            {
                if (value == "ON")
                    appHandle.Select_CheckBox(objXpath);
                else
                    appHandle.DeSelectCheckBox(objXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        /// <summary>
        /// This method is used to select radio button.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.SetRadioButton(AccountPreferencesPage.rbtnPaperStatements);
        /// </example>
        public virtual void SetRadioButton(string objXpath)
        {
            try
            {
                appHandle.Set_radiobutton(objXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        /// <summary>
        /// This method is used to click an object.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.ClickObject(DepositAccountOverviewPage.tabAccountSummary);
        /// </example>
        public virtual void ClickObject(string xpath)
        {
            try
            {
                appHandle.ClickObject(xpath);

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on Add button.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRMasterPage.ClickOnAddButton;
        /// </example>
        public virtual void ClickOnAddButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnAdd);
                appHandle.ClickObject(btnAdd);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to get xpath for tabs in deposit account overview page.
        /// </summary>
        /// <returns>string</returns> 
        /// <example>
        /// WebCSRMasterPage.GetTabXpath("Term Accounts");
        /// </example>
        public virtual string GetTabXpath(string sTabName)
        {
            string xpath = null;
            try
            {
                xpath = "Xpath;//td[text()='" + sTabName + "']";
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return xpath;
        }

        /// <summary>
        /// This method is used to select link.
        /// </summary>
        /// <returns>string</returns> 
        /// <example>
        /// WebCSRMasterPage.SelectLink(AccountInformationPage.lnkRateDetermination);
        /// </example>
        public virtual void SelectLink(string sLinkName)
        {
            sLinkName="XPath;//*[contains(text(),'"+sLinkName+"')]";
            
            try
            {
                appHandle.Select_link(sLinkName);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to get text based on label.
        /// </summary>
        /// <returns>string</returns> 
        /// <example>
        /// WebCSRMasterPage.GetTextBasedOnLabel("Annual Yield:");
        /// WebCSRMasterPage.GetTextBasedOnLabel("Rate at Last Maturity:");
        public virtual string GetTextBasedOnLabel(string objXpath)
        {
            string OutputValue = null;
            try
            {
                if (appHandle.IsObjectExists(objXpath))
                {
                    appHandle.WaitUntilElementVisible(objXpath);
                    OutputValue = appHandle.GetObjectText(objXpath);
                }
                else
                {
                    Report.Fail("Element not found", "ObjectLabel", "True", appHandle);
                }
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return OutputValue;
        }
        /// <summary>
        /// This method is used to compare two string values.
        /// <param name= "string1"></param> 
        /// <param name= "string2"></param>
        /// <returns>bool</returns> 
        /// <example>WebCSRMasterPage.comparestringvalues("Annual Yield","Annual Yield");<example>
        public virtual bool comparestringvalues(string string1, string string2)
        {
            bool OutputValue = false;
            try
            {
                int valu = string.Compare(string1, string2);
                if (valu == 0)
                    OutputValue = true;
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return OutputValue;
        }


        /// <summary>
        /// This method is used to calculate number of days in a year.
        /// <param name= "Year"></param> 
        /// <returns>int</returns> 
        /// <example>WebCSRMasterPage.CountNumberOfDaysInYear(2018);<example>
        public virtual int CountNumberOfDaysInYear(int Year)
        {
            int days = 0;
            try
            {
                days = appHandle.GetTotalNoOfDaysInYear(Year);
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return days;
        }

        /// <summary>
        /// This method is used to select Radio Button in table.
        /// <param name= "tableXpath"></param> 
        /// <param name= "sColumnValue"></param>
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.comparestringvalues("Annual Yield","Annual Yield");<example>
        public virtual void SelectRadioButtonInTable(string tableXpath, string sColumnValue)
        {
            try
            {
                appHandle.SelectRadioButtonInTable(tableXpath, sColumnValue);
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged: " + e);
            }
        }

        /// <summary>
        /// This method is used to click on release button.
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.ClickOnReleaseButton()<example>

        public virtual void ClickOnReleaseButton()
        {
            try
            {
                appHandle.ClickObject(btnRelease);
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }

        }

        /// <summary>
        /// This method is used to do action on popup button.
        /// <param name= "ActionType"></param>  
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.ActionOnPopButton("OK")<example>
        /// <example>WebCSRMasterPage.ActionOnPopButton("CANCEL")<example>
        public virtual void ActionOnPopButton(string ActionType)
        {
            try
            {
                if (ActionType.ToUpper().Equals("OK"))
                {
                    appHandle.PerformActionOnAlert(PopUpAction.Accept);
                }
                else
                {
                    appHandle.PerformActionOnAlert(PopUpAction.Decline);
                }
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }


        //Method for Verify the Expected valus is there in drop down.
        public virtual bool CheckExpectedValueinDropdown(string DropdownName, string sExpVal)
        {
            bool bcheck = false;
            try
            {
                bcheck = appHandle.CheckValueInDropdown(DropdownName, sExpVal);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;

        }

        /// <summary>
        /// Method for Verify the Object is exists.
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRPageFactory.VerifytheObjectExists();
        /// </example>
        public virtual bool VerifytheObjectExists(string obj1)
        {
            bool bcheck = false;
            try
            {
                {
                    bcheck = appHandle.CheckObjectExist(obj1);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

        //Method for check the edit field valus is Blank.
        public virtual void Checkeditblanktrue(string Objname)
        {
            try
            {
                WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle.CheckEditFieldBlank(Objname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to select radio button in Table
        /// <param name= "table"></param> 
        /// <param name= "refValues"></param> 
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.SetRadioButton(AccountPreferencesPage.rbtnPaperStatements);</example>
        public virtual void SelectRadioButtoninTable(string table, string refValues)
        {
            try
            {
                appHandle.SelectRadioButtonInTable(table, refValues);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to click on Edit button.
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.ClickOnEditButton();</example>
        public virtual void ClickOnEditButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnEdit);
                appHandle.ClickObject(btnEdit);
                appHandle.Wait_For_Specified_Time(2);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to click on Delete button.
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.ClickOnDeleteButton();</example>
        public virtual void ClickOnDeleteButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnDelete);
                appHandle.ClickObject(btnDelete);
                appHandle.Wait_For_Specified_Time(2);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        public virtual void ActionOnPopButton(bool ActionType)
        {
            try
            {
                if (ActionType == true)
                {
                    appHandle.PerformActionOnAlert(PopUpAction.Accept);
                    appHandle.Wait_For_Specified_Time(2);
                }
                else
                {
                    appHandle.PerformActionOnAlert(PopUpAction.Decline);
                    appHandle.Wait_For_Specified_Time(2);
                }

            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

        /// <summary>
        /// This method is used to verify the unchecked checkbox status.
        /// <param name= "sCheckboxXpath"></param> 
        /// <returns>true/false</returns> 
        /// <example>WebCSRMasterPage.VerifyCheckBoxUnchecked(sCheckboxXpath)<example>
        public virtual bool VerifytheCheckBoxUnchecked(string sCheckboxXpath)
        {
            bool CheckboxStatus = true;
            try
            {
                CheckboxStatus = appHandle.CheckCheckBoxUnchecked(sCheckboxXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged: " + e);
            }
            return CheckboxStatus;
        }

        /// <summary>
        /// This method is used to verify the checked checkbox status.
        /// <param name= "sCheckboxXpath"></param> 
        /// <returns>true/false</returns> 
        /// <example>WebCSRMasterPage.VerifytheCheckBoxisChecked(sCheckboxXpath)<example>
        public virtual bool VerifytheCheckBoxisChecked(string sCheckboxXpath)
        {
            bool CheckboxStatus = true;
            try
            {
                CheckboxStatus = appHandle.CheckCheckBoxChecked(sCheckboxXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged: " + e);
            }
            return CheckboxStatus;
        }
        public virtual string GenerateXpathForLabel(string sLabelName)
        {
            string objXpath = null;
            try
            {
                objXpath = System.Web.HttpUtility.HtmlDecode("XPATH;//td[text()='" + sLabelName + "&nbsp;']//following-sibling::td");
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return objXpath;
        }
        public virtual bool CheckObjectExistsByLabel(string sTableName, string sLabelName, ObjType objType)
        {
            bool bExists = false;
            try
            {
                bExists = appHandle.CheckObjectExistByLabel(sTableName, sLabelName, objType);
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return bExists;
        }

        public virtual void WaitUntilValueChanges(int time)
        {
            try
            {
                appHandle.WaitForSpecifiedTime(time);
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

        /// <summary>
        /// This method is used to get date parameters for the given date.
        /// <param name= "Date"></param> 
        /// <returns>string array</returns> 
        /// <example>WebCSRMasterPage.GetDateParameters("12/02/2018");<example>
        public virtual string[] GetDateParameters(string Date)
        {
            string[] dateparms = null;
            try
            {
                dateparms = appHandle.GetDateParameters(Date);
            }
            catch (Exception e) { Report.Info("Exception Logged:" + e); }
            return dateparms;
        }

        /// <summary>
        /// This method is used to get last date of the month.
        /// <param name= "Date"></param> 
        /// <returns>string</returns> 
        /// <example>WebCSRMasterPage.GetMonthLastDate("12/02/2018");<example>
        public virtual string GetMonthLastDate(string Date)
        {
            string Lastdate = null;
            try
            {
                Lastdate = appHandle.GetMonthLastDate(Date);
            }
            catch (Exception e) { Report.Info("Exception Logged:" + e); }
            return Lastdate;
        }

        /// <summary>
        /// This method is used to check leap year.
        /// <param name= "year"></param> 
        /// <returns>bool</returns> 
        /// <example>WebCSRMasterPage.IsLeapYear(2018);<example>
        public virtual bool IsLeapYear(int year)
        {
            bool val = false;
            try
            {
                val = appHandle.IsLeapYear(year);
            }
            catch (Exception e) { Report.Info("Exception Logged:" + e); }
            return val;
        }

        /// <summary>
        /// This method is used to click on link in Table by reference values
        /// <param name= "Table"></param> 
        /// <param name= "Linkname"></param> 
        /// <param name= "RefVals"></param> 
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.SelectLinkInTable(Table,Linkname,RefVals);<example>
        public virtual void SelectLinkInTable(string Table, string Linkname, string RefVals)
        {
            try
            {
                appHandle.WaitUntilElementClickable(Table);
                appHandle.SelectLinkInTable(Table, Linkname, RefVals);
            }
            catch (Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to Check Specified Data Available In Table.
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRMasterPage.CheckSpecifiedDataAvailableInTable(tableXpath, Date;10/11/2010;Description;Debit);
        /// </example>
        public virtual bool CheckSpecifiedDataAvailableInTable(string sRefValue, string sTableName)
        {
            bool bCheck = false;
            try
            {
                if (appHandle.IsObjectExists(sTableName))
                {
                    bCheck = appHandle.CheckSpecifiedDataAvailableInTable(sRefValue, sTableName);
                }
                else
                    Report.Info("Table name not found.");

            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            return bCheck;
        }

        /// <summary>
        /// This method is used to Check Specified Data Not Available In Table.
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebCSRMasterPage.CheckSpecifiedDataAvailableInTable(tableXpath, Date;10/11/2010;Description;Debit);
        /// </example>
        public virtual bool CheckSpecifiedDataNotAvailableInTable(string sTableName, string sRefValue)
        {
            bool bCheck = false;
            try
            {
                if (appHandle.IsObjectExists(sTableName))
                    bCheck = appHandle.CheckSpecifiedDataNotAvailableInTable(sRefValue, sTableName);
                else
                    Report.Info("Table name not found.");
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            return bCheck;
        }

        /// <summary>
        /// This method is used to Get Specified Data Available In Table.
        /// </summary>
        /// <returns>string</returns> 
        /// <example>
        /// string Val = WebCSRMasterPage.GetSpecifiedDataAvailableInTable("Date;10/11/2010;Description",tableXpath);
        /// </example>
        public virtual string GetSpecifiedDataAvailableInTable(string sRefValue, string sTableName)
        {
            string val = null;
            try
            {
                if (appHandle.IsObjectExists(sTableName))
                {
                    val = appHandle.GetSpecifiedDataAvailableInTable(sRefValue, sTableName);
                }
                else
                    Report.Info("Table name not found.");
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            return val;
        }

        public virtual string GenerateXpathForTextbox(string sLabelName)
        {
            string objXpath = null;
            try
            {
              //  objXpath = System.Web.HttpUtility.HtmlDecode("XPATH;//td[text()='" + sLabelName + "&nbsp;']//following-sibling::td/input");
                objXpath = System.Web.HttpUtility.HtmlDecode("XPATH;//*[@class='fieldLabel'][contains(.,'"+ sLabelName +"')]/following-sibling::td/input");
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return objXpath;
        }
        public virtual void reloadWebCSRURL()
        {
            appHandle.LaunchApplication(Util.BaseURLGenerator.Generate(Data.Get("WebCSR"))+"login.do?reload=true","chrome");
            
            if (appHandle.GetTitle().Equals("Privacy error"))
            {
                OverComeAdvancedBrowserConn();
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnLoginPageSubmit);
            }

        }
        public virtual bool VerifyMessageInWebCSRLogin(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }


        public virtual void ClickOnRateDeterminationLink()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkRateDetermination);
            appHandle.ClickObjectViaJavaScript(linkRateDetermination);
        }

        public virtual void ClickOnDelinquencyOptionsLink()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkDelinquencyoption);
            appHandle.ClickObjectViaJavaScript(linkDelinquencyoption);
        }

        public virtual void SelectSublinkOfTab(string sublinkname)
        {
            string dynobj="XPath;//td[@class='tabSub']/*[contains(text(),'"+sublinkname+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynobj);
            appHandle.ClickObjectViaJavaScript(dynobj);

        }
        public virtual void NavigateToCreateTrustAccountPage()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SearchCustomerLink))
            {
                appHandle.ClickObjectViaJavaScript(lnkCreateTrustAccount);
            }
        

    }


    }
}
