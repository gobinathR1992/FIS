using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class PurchasedImpairedLoanPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string buttonAdd="XPath;//input[@name='add']";
        public static string dropdownAccount="XPath;//table[@class='contentTable']/descendant::select[@name='accountNumber']";

        public virtual void UpdateDataForSOPForPurchasedImapiredLaon(string loanaccnum)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccount);
            appHandle.SelectDropdownSpecifiedValue(dropdownAccount,loanaccnum+" - "+loanaccnum);
            


        }





    }
}