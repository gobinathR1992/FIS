using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class Form8966ReportCorrectionPage
    { 
         static WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
         //filecorrecions tab

         public static string drpdownTypeofCorrection ="Xpath;//*[@name='fileCorrectionType']";
         public static string drpdownFileSequence ="Xpath;//*[@name='fileSequence']";

         public static string checkboxAccountno ="Xpath;//*[@value='RELCIF_CID']";
         public static string checkboxTaxid ="Xpath;//*[@value='CIF_TAXID']";
         public static string txtSearchFor ="Xpath;//*[@name='searchTerm']";
         public static string buttonSearch="Xpath;//*[@name='submit']";
         public static string buttonCancel ="Xpath;//*[@name='cancel']";
         public static string tableListofCorrections="Xpath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";
         public static string buttonSubmit = "Xpath;//*[@name='submit']";
         private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
         public static string checkboxAction="Xpath;//*[@id='selectedRecords']";
         public static string drpdownReasonforCorrection="Xpath;//*[@name='fileCorrectionReason']";
         public virtual void EnterFileCorrectionsdetails(string TypeofCorrections,string fileSeq,string Account)
         {
             applicationHandle.WaitUntilElementExists(drpdownTypeofCorrection);
             applicationHandle.SelectDropdownSpecifiedValue(drpdownTypeofCorrection,TypeofCorrections);
             applicationHandle.SelectDropdownSpecifiedValue(drpdownFileSequence,fileSeq);
             applicationHandle.SelectCheckBox(checkboxAccountno);
             applicationHandle.Set_field_value(txtSearchFor,Account);
         }

         public virtual void ClickOnSearch()
         {
             applicationHandle.WaitUntilElementExists(buttonSearch);
             applicationHandle.ClickObjectViaJavaScript(buttonSearch);
         }
         public virtual void SelectCorrectionFileListOrder(string UniqueOrderRefValue)
        {
            applicationHandle.Select_CheckBox(checkboxAction);
            applicationHandle.SelectDropdownByLocation(drpdownTypeofCorrection,UniqueOrderRefValue);
            
        }
        public virtual bool VerifyDatainTableofCorrections(string UniqueOrderRefValue)
        {
            bool Result = false;
            if (applicationHandle.CheckObjectExist(tableListofCorrections,UniqueOrderRefValue) )
            {
                Result =true;
            }
            return Result;

        }
        public virtual void ClickOnSubmit()
         {
             applicationHandle.WaitUntilElementExists(buttonSubmit);
             applicationHandle.ClickObjectViaJavaScript(buttonSubmit);
         }
         public virtual bool VerifyMessageInFormCorrectiosPage(string sMessage)
        {
            bool Result = false;

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (applicationHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual void SelectReasonForCorrection(string Reason)
        {
            applicationHandle.WaitUntilElementExists(checkboxAction);
            applicationHandle.Select_CheckBox(checkboxAction);
            applicationHandle.SelectDropdownSpecifiedValueByPartialText(drpdownReasonforCorrection,Reason);
        }
        








    }
}