using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DomesticPaymentAddPage
    {
       private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string DomesticPaymentAddTypeDropdown = "XPath;//*[contains(text(),'Payment Type')]/following-sibling::*/descendant::select";
private static string ButtonSearchInstitution="XPath;//*[contains(text(),'Institution')]/following-sibling::*/descendant::a";
        /// <summary>
        /// This method is used to select payment type From PaymentDropdown
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DomesticPaymentAddPage.SelectPaymentTypeFromDropDown();
        /// </example>   
        public virtual void SelectPaymentTypeFromDropDown(string PaymentType)
        {
           if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(DomesticPaymentAddTypeDropdown))
             {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DomesticPaymentAddTypeDropdown, PaymentType);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(ButtonSearchInstitution);
            }
        }

    }
}