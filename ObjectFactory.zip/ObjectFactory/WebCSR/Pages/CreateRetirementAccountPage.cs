using GTS_OSAF.CoreLibs;
using System;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateRetirementAccountPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string buttonSubmit="XPath;//input[@name='_eventId_submit']";

        public static string buttonContinue="XPath;//input[@name='_eventId_continue']";
        
        public static string txtContributionAmount="XPath;//input[contains(@name,'originalAmount')]";
        public static string dropdownContributionType="XPath;//select[contains(@name,'contributionType')]";
        public virtual void ClickOnSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);

        }

        public virtual void SelectRetirementAccount(string accountname)
        {
            string dynamicobj="XPath;//a[contains(text(),'"+accountname+"')]/../preceding-sibling::td/select";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynamicobj);
            appHandle.SelectDropdownSpecifiedValue(dynamicobj,"1");
        }

        public virtual void ClickOnContinueButton()
        {
             Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonContinue);
             appHandle.ClickObjectViaJavaScript(buttonContinue);
        }

        public virtual void EnterRetireAccountDetails(string contributionamt,string contributiontype)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtContributionAmount);
            appHandle.Set_field_value(txtContributionAmount,contributionamt);
            appHandle.SelectDropdownSpecifiedValue(dropdownContributionType,contributiontype);
            Report.Info("The Account Details are entered successfully","detailsinfo","True",appHandle);
        }

        public virtual void CheckAccountSuccessMsg(string sucmsg)
        {
            if(appHandle.CheckSuccessMessage(sucmsg))
            {
                Report.Pass("The Retirement Accout is created successfully","accountpass","True",appHandle);
            }
            else
            {
                Report.Fail("The Retirement Accout is not created ","accountFail","True",appHandle);
            }

        }

        public virtual string GetRetirementAccount()
        {
            string retaccnt="";
            string dynobj="XPath;//td[contains(text(),'Account Number')]/following-sibling::td";
            retaccnt=appHandle.GetObjectText(dynobj).Trim();
            return retaccnt;
        }



    }
}
