using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class BillingStatementPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tblBillingStatement = "XPath;//table[@id='statements-list']/tbody";
        public static string tblPaymentListheader = "Xpath;//div[@class='dataTables_scrollHeadInner']//table[@class='ledgerScrollable dataTable no-footer']";
        public static string tblPaymentListbody = "Xpath;//table[@id='scheduledPayments-list']/tbody";

        public virtual void ClickOnBillinDateLink(string Date)
        {
            string DateLink ="Xpath;//a[contains(text(),'"+ Date +"')]";
            appHandle.ClickObjectViaJavaScript(DateLink);

        }
        
    }
}