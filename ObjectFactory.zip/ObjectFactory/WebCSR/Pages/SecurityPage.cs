using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class SecurityPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        protected static string txtUserId = "Xpath;//input[@name='CIFAUTH_USERID1']";
        protected static string txtPasswordHint = "Xpath;//input[@name='CIFAUTH_HINT']";
        protected static string drpPasswordStatus = "Xpath;//select[@name='CIFAUTH_STATUS']";
        protected static string drpTemporaryPasswordAction = "Xpath;//select[@name='resetAction']";
        protected static string drpQuestion = "Xpath;//select[@name='CIFAUTH_QUESTION']";
        protected static string txtNewPassword = "Xpath;//input[@name='newPassword']";
        protected static string txtConfirmPassword = "Xpath;//input[@name='newPasswordVerify']";
        protected static string txtAnswer = "Xpath;//input[@name='CIFAUTHSECURITY_SECRETANSWER']";
        protected static string txtSecretWord = "Xpath;//input[@name='CIFAUTHSECURITY_SECRETWORD']";
        protected static string rbtnAllowOnlineAccessYes = "Xpath;//input[@name ='CIFAUTH_ALLOWONLINEACCESS'][@value='true']";
        protected static string rbtnAllowOnlineAccessNo = "Xpath;//input[@name ='CIFAUTH_ALLOWONLINEACCESS'][@value='false']";
        protected static string lnkMyHome = "Xpath;//a[contains(text(),'My Home')]";
        protected static string lnkAccountList = "Xpath;//a[@class='selected']";

        /// <summary>
        /// This method is used to select radio button for allow online access.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// SecurityPage.SetRadioButtonAllowOnlineAccessYes();
        /// </example>
        public virtual void SetRadioButtonAllowOnlineAccessYes()
        {
            try
            {
                appHandle.WaitUntilElementVisible(rbtnAllowOnlineAccessYes);
                appHandle.Set_radiobutton(rbtnAllowOnlineAccessYes);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
        }

        /// <summary>
        /// This method is used to select radio button for not allowing online access.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// SecurityPage.SetRadioButtonAllowOnlineAccessNo();
        /// </example>
        public virtual void SetRadioButtonAllowOnlineAccessNo()
        {
            try
            {
                appHandle.WaitUntilElementVisible(rbtnAllowOnlineAccessNo);
                appHandle.Set_radiobutton(rbtnAllowOnlineAccessNo);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
        }
        /// <summary>
        /// This method is used to enter user id
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// SecurityPage.SetOnlineAccessUserId("SAMBA3456");
        /// </example>
        public virtual void SetOnlineAccessUserId(string sUserId)
        {
            try
            {
                appHandle.WaitUntilElementVisible(txtUserId);
                appHandle.Set_field_value(txtUserId, sUserId);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
        }
        /// <summary>
        /// This method is used to enter online access details
        /// </summary>
        /// <param name = string[] arrOnlineAccessDetails></param>
        /// <returns></returns> 
        /// <example>
        /// SecurityPage.EnterOnlineAccessDetails(string[] arrOnlineAccessDetails);
        /// </example>
        public virtual void EnterOnlineAccessDetails(string[] arrOnlineAccessDetails)
        {
            try
            {
                Report.Info("Enter Online Access details.");
                appHandle.SelectDropdownSpecifiedValue(drpPasswordStatus, arrOnlineAccessDetails[0]);
                appHandle.SelectDropdownSpecifiedValue(drpTemporaryPasswordAction, arrOnlineAccessDetails[1]);
                appHandle.Set_field_value(txtPasswordHint, arrOnlineAccessDetails[2]);
                appHandle.Set_field_value(txtSecretWord, arrOnlineAccessDetails[3]);
                Report.Info("Online Access details entered.");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        /// <summary>
        /// This method is used get enter user id value
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// SecurityPage.GetOnlineAccessUserId();
        /// </example>
        public virtual string GetOnlineAccessUserId()
        {
            string UserId = "";
            try
            {

                UserId = appHandle.GetElementValue(txtUserId);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged" + e);
            }
            return UserId;
        }
        /// <summary>
        /// This method is used to enter online security details
        /// </summary>
        /// <param name = string[] arrOnlineAccessSecurityDetails></param>
        /// <returns></returns> 
        /// <example>
        /// SecurityPage.EnterOnlineAccessDetails(string[] arrOnlineAccessSecurityDetails);
        /// </example>
        public virtual void EnterOnlineAccessSecurityDetails(string[] arrOnlineAccessSecurityDetails)
        {
            Report.Info("Enter Online Access Security details.");
            try
            {
                appHandle.Set_field_value(txtNewPassword, arrOnlineAccessSecurityDetails[0]);
                appHandle.Set_field_value(txtConfirmPassword, arrOnlineAccessSecurityDetails[1]);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            Report.Info("Online Access Security details entered.");
        }
        /// <summary>
        /// This method is used to enter security question details
        /// </summary>
        /// <param name = string[] arrSecurityQuestionDetails></param>
        /// <returns></returns> 
        /// <example>
        /// SecurityPage.EnterSecurityQuestionDetails(string[] arrSecurityQuestionDetails);
        /// </example>
        public virtual void EnterSecurityQuestionDetails(string[] arrSecurityQuestionDetails)
        {
            Report.Info("Enter Security Question details.");
            appHandle.SelectDropdownSpecifiedValue(drpQuestion, arrSecurityQuestionDetails[0]);
            appHandle.Set_field_value(txtAnswer, arrSecurityQuestionDetails[1]);
            Report.Info("Security Question details entered.");
        }



    }
}
