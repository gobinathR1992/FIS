using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class OverdraftProcessingPage
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtAuthorizedOverdraftLimit = "Xpath;//input[@name = 'DEPAUTHODLIMIT_ODLIMITAMT']";
        public static string txtAuthorizedOverdraftTerm = "Xpath;//input[@name = 'DEPAUTHODLIMIT_ODTERM']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";

        public static string txtNegativeAmountBeforeOverdrawn="xPath;//input[@name='DEP_NSFLIM']";


        public virtual void SelectSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.SelectButton(buttonSubmit);
            
        }

        public virtual bool VerifyMessageOverdraftProcessingPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        
        public virtual bool WaitUntilOverdraftProcessingPageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtAuthorizedOverdraftLimit))
            {
                result = true;
            }

            return result;

        }
        public virtual void AuthorizedOverdraftOptions(string AuthOverLimit , string AuthOverTerm )
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtAuthorizedOverdraftLimit))
            {
                
                if(!string.IsNullOrEmpty(AuthOverLimit))
                {
                appHandle.Set_field_value(txtAuthorizedOverdraftLimit,AuthOverLimit);
                }
                if(!string.IsNullOrEmpty(AuthOverTerm))
                {
                appHandle.Set_field_value(txtAuthorizedOverdraftTerm,AuthOverTerm);
                }
                
                       
            }
        }

        public virtual bool UpdateValueOfNegativeAmountBeforeOverdrawn(string value)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtNegativeAmountBeforeOverdrawn);
            appHandle.Set_field_value(txtNegativeAmountBeforeOverdrawn,value);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }
        

    }
}