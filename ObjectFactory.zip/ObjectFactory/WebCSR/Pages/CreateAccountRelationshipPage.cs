using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using System;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateAccountRelationshipPage
    {
        WebApplication appHandle;
        public static string tblDepositAccountRelationshipTable = "Xpath;//input[@value='A']/../parent::tr/parent::tbody/parent::table";
        public static string tblLoanAccountRelationshipTable = "Xpath;//h2[contains(text(),'Loan')]/..//parent::tr/following-sibling::tr/td/table";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }
                public static string txtRelationshiptypeMsg="Xpath;//h2[contains(text(),'Deposit Account Relationship')]";

        public virtual void SelectNumberofCustomers(string sRelationType, string sNoofcust, int iPosofdrp)
        {
            try
            {
                string obj = System.Web.HttpUtility.HtmlDecode("XPATH;(//td[@class='dataLabel' and text()='" + sRelationType + "&nbsp;']/parent::tr/td/select)[" + iPosofdrp + "]");
                if (AppHandle.IsObjectExists(obj))
                {
                    AppHandle.WaitUntilElementVisible(obj);
                    AppHandle.WaitUntilElementClickable(obj);
                    if (sNoofcust != null && sNoofcust.Trim() != "")
                        AppHandle.SelectDropdownSpecifiedValue(obj, sNoofcust);
                }
                else
                    Report.Fail("Specified dropdown does not exist", "days", "True", AppHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        public virtual void SelectAccountRelationship(string sRelationType)
        {
            try
            {
                string obj = System.Web.HttpUtility.HtmlDecode("XPATH;//td[@class='dataLabel' and text()='" + sRelationType + "&nbsp;']//parent::tr//..//parent::table//parent::td//parent::tr//td//input[@name='relationshipCode']");
                if (AppHandle.IsObjectExists(obj))
                {
                    AppHandle.WaitUntilElementVisible(obj);
                    AppHandle.WaitUntilElementClickable(obj);
                    AppHandle.ClickObject(obj);
                }
                else
                    Report.Fail("Specified Account Relationship does not exist", "days", "True", AppHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        public virtual bool RelationshipPageConfirmation()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Navigating to the Relationship Page.");
            bool bcheck = false;
            if (appHandle.CheckObjectExist(txtRelationshiptypeMsg))
            {
                bcheck = true;
            }
            else
            {
                bcheck = false;
            }
            return bcheck;
        }

    }
}




