using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CustomerInformationSeasonalAddressPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string SeasonalMailingAddressStartDate_Field="Xpath;//input[@name='SADDRCIF_SADSD']";
        public static string SeasonalMailingAddressEndDate_Field="Xpath;//input[@name='SADDRCIF_SADED']";
        public static string SeasonalMailingAddressAddress1Field="Xpath;//input[@name='SADDRCIF_SAD1']";
        public static string SeasonalMailingAddressAddress2_Field="Xpath;//input[@name='SADDRCIF_SAD2']";
        public static string SeasonalMailingAddressAddress3_Field="Xpath;//input[@name='SADDRCIF_SAD3']";
        public static string SeasonalMailingAddressAddressTownship_Field="Xpath;//input[@name='SADDRCIF_SLOC']";
        public static string SeasonalMailingAddressCountyField="Xpath;//input[@name='SADDRCIF_SCOUNTY']";
        public static string SeasonalMailingAddressCity_Field="Xpath;//input[@name='SADDRCIF_SCITY']";
        public static string SeasonalMailingAddressZipCode_Field="Xpath;//input[@name='SADDRCIF_SZIP']";
        public static string OffSeasonMailingAddressAddress1_Field="Xpath;//input[@name='SADDRCIF_NSAD1']";
        public static string OffSeasonMailingAddressAddress2_Field="Xpath;//input[@name='SADDRCIF_NSAD2']";
        public static string OffSeasonMailingAddressAddress3_Field="Xpath;//input[@name='SADDRCIF_NSAD3']";
        public static string OffSeasonMailingAddressTownship_Field="Xpath;//input[@name='SADDRCIF_NSLOC']";
        public static string OffSeasonMailingAddressCounty_Field="Xpath;//input[@name='SADDRCIF_NSCOUNTY']";
        public static string OffSeasonMailingAddressCity_Field="Xpath;//input[@name='SADDRCIF_NSCITY']";
        public static string OffSeasonMailingAddressZipCode_Field="Xpath;//input[@name='SADDRCIF_NSZIP']";
        public static string SeasonalMailingAddressCountry_Dropdown="Xpath;//select[@name='SADDRCIF_SCNTRY']";
        public static string SeasonalMailingAddressState_Dropdown="Xpath;//select[@name='SADDRCIF_SSTATE']";
        public static string OffSeasonMailingAddressCountry_Dropdown="Xpath;//select[@name='SADDRCIF_NSCNTRY']";
        public static string OffSeasonMailingAddressState_Dropdown="Xpath;//select[@name='SADDRCIF_NSSTATE']";
        public static string buttonSubmit="Xpath;//input[@name='submit']";
        public static string DoesthisseasonaladdressbelongtosomeoneelseNo_Radiobutton="Xpath;//input[@name='SADDRCIF_SEASNLADDRNOTCUSTOMERS'][@value='false']";
        public static string DoesthisoffseasonaladdressbelongtosomeoneelseRadiobutton="Xpath;//tr[4]//td[1]//table[1]//tbody[1]//tr[1]//td[2]//table[1]//tbody[1]//tr[1]//td[1]//input[1]";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";

        public virtual void UpdateSeasonalAddressInSeasonalAddressPage(string StartDate,string EndDate,string ZipCode)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(SeasonalMailingAddressStartDate_Field);
            appHandle.Set_field_value(SeasonalMailingAddressStartDate_Field,StartDate);
            appHandle.Set_field_value(SeasonalMailingAddressEndDate_Field,EndDate);
            appHandle.Set_radiobutton(DoesthisseasonaladdressbelongtosomeoneelseNo_Radiobutton);
            appHandle.Set_field_value(SeasonalMailingAddressAddress1Field,Data.Get("GLOBAL_FIS"));
            appHandle.Set_field_value(SeasonalMailingAddressAddress2_Field,Data.Get("SeaLine2"));
            appHandle.Set_field_value(SeasonalMailingAddressCity_Field,Data.Get("Arakans"));
            appHandle.SelectDropdownSpecifiedValueByPartialText(SeasonalMailingAddressCountry_Dropdown,(string)Data.Get("US - UNITED STATES OF AMERICA"));
            appHandle.SelectDropdownSpecifiedValueByPartialText(SeasonalMailingAddressState_Dropdown,(string)Data.Get("AE - Armed Forces Europe"));
            appHandle.Set_field_value(SeasonalMailingAddressZipCode_Field,ZipCode);



        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
        }

        public virtual bool ValidateAddressInfoUpdateMSG()
        {
            bool result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("The seasonal address information has been updated")))
            {
                result = true;
            }

            return result;
        }
        public virtual bool ValidateInvaildZipCodeUpdateMSG(string Msg)
        {
            bool result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals(Msg))
            {
                result = true;
            }

            return result;
        }


    }

}
