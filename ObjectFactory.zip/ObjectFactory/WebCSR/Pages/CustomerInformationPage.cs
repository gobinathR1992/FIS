using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class CustomerInformationPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string IdentityTab = "Xpath;//td[contains(text(),'Identity')]";
        public static string IdentificationLink = "Xpath;//a[text()='Identification']";
        public static string lnkFATCA = "Xpath;//a[text()='FATCA']";
        public static string PassportRadioButton = "Xpath;.//input [@type='radio'][@value='1']";
        public static string PersonalInformation_CustomerStatusChangeDate_Field = "Xpath;//input[@name='CIF_CUSTCHDT']";
        public static string PersonalInformation_TaxIDNumber_Field = "Xpath;//input[@name='CIF_TAXID']";
        public static string PersonalInformation_DOB_Field = "Xpath;//input[@name='CIF_DOB']";
        public static string PersonalInformation_DOD_Field = "Xpath;//input[@name='CIF_DOD']";
        public static string ContactInformation_HomeTelephone_Field = "Xpath;//input[@name='CIF_HPH']";
        public static string ContactInformation_AlternateTelephone_Field = "Xpath;//input[@name='CIF_APH']";
        public static string ContactInformation_BusinessTelephone_Field = "Xpath;//input[@name='CIF_BPH']";
        public static string ContactInformation_Extension_Field = "Xpath;//input[@name='CIF_BPHEXT']";
        public static string ContactInformation_FaxNumber_Field = "Xpath;//input[@name='CIF_FAXNUM']";
        public static string ContactInformation_Email_Field = "Xpath;//input[@name='CIF_EMAIL']";
        public static string PrivacyProtection_RevisedPrivacyNoticeSent_Field = "Xpath;//input[@name='CIF_REVNOTDT']";
        public static string ServicingInformation_Attention_Field = "Xpath;//input[@name='CIF_ATN']";
        public static string PersonalInformation_Currency_Dropdown = "Xpath;//select[@name='CIF_CRCD']";
        public static string PersonalInformation_CustomerStatus_Dropdown = "Xpath;//select[@name='CIF_STAT']";
        public static string PersonalInformation_TaxIDStatus_Dropdown = "Xpath;//select[@name='CIF_W9STAT']";
        public static string drpPersonalInformationMaritalStatus = "Xpath;//select[@name='CIF_MAR']";
        public static string PersonalInformation_Gender_Dropdown = "Xpath;//select[@name='CIF_SEX']";
        public static string PersonalInformation_Education_Dropdown = "Xpath;//select[@name='CIF_EDUC']";
        public static string PersonalInformation_HomeOwnership_Dropdown = "Xpath;//select[@name='CIF_OWN']";
        public static string PersonalInformation_ProofOfDeath_Dropdown = "Xpath;//select[@name='CIF_PROOFOFDEATH']";
        public static string PersonalInformation_LanguagePreference_Dropdown = "Xpath;//select[@name='CIF_LANG']";
        public static string PersonalInformation_FISBank_Dropdown = "Xpath;//select[@name='CIF_HOW']";
        public static string PrivacyProtection_CustomerPrivacy_Dropdown = "Xpath;//select[@name='CIF_PRIV']";
        public static string PrivacyProtection_SolicitationCode_Dropdown = "Xpath;//select[@name='CIF_SOL']";
        public static string ServicingInformation_BranchOfOwnership_Dropdown = "Xpath;//select[@name='CIF_BOO']";
        public static string ServicingInformation_CostCenter_Dropdown = "Xpath;//select[@name='CIF_CC']";
        public static string ServicingInformation_TypeOfCustomer_Dropdown = "Xpath;//select[@name='CIF_CCODE']";
        public static string ServicingInformation_Officer_Dropdown = "Xpath;//select[@name='CIF_CIFOFF']";
        public static string ServicingInformation_AlternateOfficer_Dropdown = "Xpath;//select[@name='CIF_ALTOFF']";
        public static string ServicingInformation_CompanyCode_Dropdown = "Xpath;//select[@name='CIF_CO']";
        public static string ServicingInformation_MailingOption_Dropdown = "Xpath;//select[@name='CIF_MF']";
        public static string ServicingInformation_IBANPreference_Dropdown = "Xpath;//select[@name='CIF_MULTACCTSPERIBANPREF']";
        public static string GeneralHomeTelephoneMobile_Checkbox = "Xpath;//input[@name='ISMOBILENUMBER_HPH']";
        public static string GeneralHomeTelephoneCollectionsConsent_Checkbox = "Xpath;//input[@name='ALLOWCOLLECTIONCALLS_HPH']";
        public static string GeneralHomeTelephoneTelemarketingConsent_Checkbox = "Xpath;//input[@name='ALLOWTELEMARKETCALLS_HPH']";
        public static string GeneralAlternateTelephoneMobile_Checkbox = "Xpath;//input[@name='ISMOBILENUMBER_APH']";
        public static string GeneralAlternateTelephoneTelemarketingConsent_Checkbox = "Xpath;//input[@name='ALLOWTELEMARKETCALLS_APH']";
        public static string GeneralAlternateTelephoneCollectionsConsent_Checkbox = "Xpath;//input[@name='ALLOWCOLLECTIONCALLS_APH']";
        public static string GeneralBusinessTelephoneMobile_Checkbox = "Xpath;//input[@name='ISMOBILENUMBER_BPH']";
        public static string GeneralBusinessTelephoneCollectionsConsent_Checkbox = "Xpath;//input[@name='ALLOWCOLLECTIONCALLS_BPH']";
        public static string GeneralBusinessTelephoneTelemarketingConsent_Checkbox = "Xpath;//input[@name='ALLOWTELEMARKETCALLS_BPH']";
        public static string PrivacyProtectionViewAnnualPrivacyNoticeOnline_Checkbox = "Xpath;//input[@name='CIF_ISANNUALPRIVCYONLINE']";
        public static string PrivacyProtectionDeclineTelemarketing_Checkbox = "Xpath;//input[@name='CIF_MARTEL']";
        public static string PrivacyProtectionDeclineEmail_Checkbox = "Xpath;//input[@name='CIF_MAREM']";
        public static string PrivacyProtectionDeclineDirectMail_Checkbox = "Xpath;//input[@name='CIF_MARDM']";
        public static string PrivacyProtectionExtractstoDataHub_Checkbox = "Xpath;//input[@name='CIF_NODATAHUBEXTRACT']";
        public static string EligibleforAlerts_Checkbox = "Xpath;//input[@name='CIF_ALERT']";
        public static string EligibleforFinancialManagement_checkbox = "Xpath;//input[@name='CIF_PFM']";
        public static string SingleOwnerofTBAandCAHierarchy_Checkbox = "Xpath;//input[@name='CIF_TBACAHSO']";
        public static string txtCustomerInfoupdateMsg = "Xpath;//p[contains(text(),'The customer information has been updated.')]";
        private static string CreditFinancial = "Xpath;//*[contains(text(),'Credit/Financial')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        
        //input [@type="radio"][@value='1']

        public static string SubmitButton = "Xpath;//input[@name='submit']";
        public static string CustomerHistoryServicesHistoryLink = "Xpath;//td[@class='menuSub'][contains(text(),'History')]";
        public static string CustomerHistoryTable = "Xpath;.//*[contains(@class,'dataTables_scroll')]";
        private static string LimitGroupsLabel = "Xpath;//*[text()='Limit Groups']";
        public static string dropdownServicingInformationBranchOfOwnership = "Xpath;//select[@name='CIF_BOO']";
        public static string dropdownServicingInformationCostCenter = "Xpath;//select[@name='CIF_CC']";
        public static string txtContactInformationHomeTelephone = "Xpath;//input[@name='CIF_HPH']";
        //NameTab
        public static string textCompanyName ="Xpath;//*[@name='CIF_NAM']";
        public static string txtTaxIDNumber="XPath;//input[@name='CIF_TAXID']";
        public static string buttonSubmit="XPath;//input[@name='submit']"; 
        private static string txtCity = "Xpath;//input[@name ='CIF_PCITY']";
        public static string Passport_RadioButton = "Xpath;//tr[td[contains(text(),'Passport')]]//input";
        private static string middlename = "xpath;//input[@name='CIF_MNAME']";
        public static string Passport_Number_Field = "Xpath;//input[@name='CIF_PASNUM']";
        public static string CountryOfIssue_Dropdown = "Xpath;//select[@name='CIF_PCI']";
        public static string Passport_IssueDate_Field = "Xpath;//input[@name='CIF_PISDT']";
        public static string Passport_ExpireDate_Field = "Xpath;//input[@name='CIF_PED']";

        public static string txtDateOfBirth="XPath;//input[@name='CIF_DOB']";

        private static string txtCustUserid = "Xpath;//input[@name='CIFAUTH_USERID1']";

        public virtual void UpdateCustomerIdentity()
        {

            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle.SelectTab(IdentityTab);
                appHandle.SyncPage();
                appHandle.Select_link(IdentificationLink);
                appHandle.SyncPage();
                appHandle.Set_radiobutton(PassportRadioButton);
            }
            catch (Exception e)
            {
                Report.Fail(e.Message, "UpdateCustomerIdentity Exception", appHandle);
            }


        }

        //This below method is used for update the marital status of the customer.       
        public virtual void UpdateMaritalStatus(string mStatus)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle.SelectDropdownSpecifiedValue(drpPersonalInformationMaritalStatus, mStatus);

            }
            catch (Exception e)
            {
                Report.Fail(e.Message, "UpdateCustomerIdentity Exception", appHandle);
            }
        }

        // To check the Customer Information updated message is exeists or not..
        public virtual bool VerifyCustomerInformationUpdateMsg()
        {
            bool blnSuccess = false;
            if (appHandle.IsObjectExists(txtCustomerInfoupdateMsg))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }


        public virtual string GetEditValue(string FieldName, string FieldType)
        {
            string outputValue = null;
            try
            {
                switch (FieldType.ToUpper())
                {
                    case "TEXTFIELD":
                        string textField = "Xpath;//*[contains(text(),'" + FieldName + "')]/following-sibling::td/input";
                        outputValue = appHandle.GetElementValue(textField);
                        break;
                    case "DROPDOWN":
                        string drpObject = "Xpath;//*[contains(text(),'" + FieldName + "')]/following-sibling::td/select";
                        outputValue = appHandle.GetDropdownSelectedValue(drpObject);
                        break;
                    case "CHECKBOX":
                        string cbk = "Xpath;//*[contains(text(),'" + FieldName + "')]/following-sibling::td/input[@type='checkbox']";
                        bool cbkStatus = appHandle.CheckCheckBoxChecked(cbk);
                        outputValue = cbkStatus.ToString();
                        break;
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return outputValue;
        }

        public virtual void SelectTab(string tabName)
        {
            try
            {
                string tabXpath = "XPath;//td[text()='" + tabName + "']";
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(tabXpath);
                appHandle.ClickObject(tabXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        public virtual void SelectSubTab(string tabName)
        {
            try
            {
                string tabXpath = "XPath;//*[text()='" + tabName + "']";

                appHandle.ClickObject(tabXpath);

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        public virtual bool VerifyLimitGroupHeaderName()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(LimitGroupsLabel))
            {
                result = true;
            }
            return result;
        }
        public virtual void EnterContactInformation(string HomePhNo = null, string BusinessPhNumber = null, string Extension = null, string FaxNumber = null, string emailId = null)
        {
            try
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(ContactInformation_BusinessTelephone_Field);
                if (string.IsNullOrEmpty(HomePhNo))
                { }
                else
                {
                    appHandle.Set_field_value(ContactInformation_HomeTelephone_Field, HomePhNo);
                }
                if (string.IsNullOrEmpty(BusinessPhNumber))
                {
                    appHandle.Set_field_value(ContactInformation_BusinessTelephone_Field, RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_PHONE_NUMBER_FORMAT"), "-"));
                }
                else
                {
                    appHandle.Set_field_value(ContactInformation_BusinessTelephone_Field, BusinessPhNumber);
                }
                if (string.IsNullOrEmpty(Extension))
                {
                    appHandle.Set_field_value(ContactInformation_Extension_Field, appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999, 4) + "");
                }
                else
                {
                    appHandle.Set_field_value(ContactInformation_Extension_Field, Extension);
                }
                if (string.IsNullOrEmpty(FaxNumber))
                {
                    appHandle.Set_field_value(ContactInformation_FaxNumber_Field, appHandle.CreateRamdomData(FieldType.NUMERIC, 111111111, 999999999, 9) + "" + appHandle.CreateRamdomData(FieldType.NUMERIC, 111, 999, 3) + "");
                }
                else
                {
                    appHandle.Set_field_value(ContactInformation_FaxNumber_Field, FaxNumber);
                }
                if (string.IsNullOrEmpty(emailId))
                {
                    appHandle.Set_field_value(ContactInformation_Email_Field, StartupConfiguration.EnvironmentDetails.UserMailID.ToString());
                }
                else
                {
                    appHandle.Set_field_value(ContactInformation_Email_Field, emailId);
                }
                Report.Info("Customer contact information is entered in Customer Information Page successfully.", "contactinfo", "true", appHandle);
            }
            catch (Exception e)
            {
                Report.Fail("Customer Contact information is not entered successfully due to : " + e.Message);
            }
        }
        public virtual void EnterServicingInformation()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ServicingInformation_CompanyCode_Dropdown))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(ServicingInformation_CompanyCode_Dropdown, (string)Data.Get("GLOBAL_ADDRESS1IN"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(ServicingInformation_MailingOption_Dropdown, (string)Data.Get("Regular"));
                appHandle.SelectDropdownSpecifiedValueByPartialText(ServicingInformation_Officer_Dropdown, (string)Data.Get("Senior Manager"));
                appHandle.Set_field_value(ServicingInformation_Attention_Field, (string)Data.Get("See ID before Cashing Check."));
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton))
            {
                appHandle.ClickObjectViaJavaScript(SubmitButton);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton);
        }
        public virtual bool VerifyCustomerInformationPageLoads()
        {
            return Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton);
        }
        public virtual bool ValidateCustomerInfoUpdateMSG()
        {
            bool result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_CUSTOMER_INFORMATION_UPDATED")))
            {
                result = true;
            }

            return result;
        }

         public virtual bool VerifyObjectEnabled()
       {
           
           bool retBO=appHandle.IsObjectEnabled(dropdownServicingInformationBranchOfOwnership);
           bool retCC=appHandle.IsObjectEnabled(dropdownServicingInformationCostCenter);
           bool homephone=appHandle.IsObjectEnabled(txtContactInformationHomeTelephone);
           if(retBO && !retCC && homephone)
           {
               return true;
           }

           return false;
       }

       public virtual bool VerifyObjectExist()
       {
           
           bool retBO=appHandle.IsObjectExists(dropdownServicingInformationBranchOfOwnership);
           bool retCC=appHandle.IsObjectExists(dropdownServicingInformationCostCenter);
           bool homephone=appHandle.IsObjectEnabled(txtContactInformationHomeTelephone);
           if(retBO && retCC && !homephone)
           {
               return true;
           }

           return false;
       }
        public virtual bool ChecktheAlertCheckboxisEnabled()
        {
            bool CheckboxStatus = false;
            if (appHandle.CheckCheckBoxChecked(EligibleforAlerts_Checkbox))
            {
                CheckboxStatus = true;
            }    
            return CheckboxStatus;
        }
        public virtual void UpdateDateOfDeath(string Date)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(PersonalInformation_DOD_Field);
            appHandle.Set_field_value(PersonalInformation_DOD_Field,Date);
        }
         public virtual string GetTaxid()
        {
            string result = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(PersonalInformation_TaxIDNumber_Field))
            {
                result = appHandle.GetElementValue(PersonalInformation_TaxIDNumber_Field);
            }
            return result;
        }

         public virtual string GetNameOfCustomer()
        {
            string result = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(textCompanyName))
            {
                result = appHandle.GetElementValue(textCompanyName);
            }
            return result;
        }
        public virtual void UpdateTaxIdForCorporateCustomer(bool blank=true)
        {
            if(blank == false)
            {
                appHandle.ClearEditValue(PersonalInformation_TaxIDNumber_Field);
            }
            else
            {
            string TAXID = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton))
            {
                appHandle.ClearEditValue(PersonalInformation_TaxIDNumber_Field);
                appHandle.Set_field_value(PersonalInformation_TaxIDNumber_Field, TAXID);
                this.ClickOnSubmitButton();
                if (WebCSRPageFactory.CreatePersonalCustomerPage.verify_tax_id_warning_message_element_exist())
                {
                    this.UpdateTaxIdForCorporateCustomer(true);
                }
                
            }
            }

        }

        public virtual bool UpdateTaxID(string taxid)
        {

            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtTaxIDNumber);
            int indexlength = appHandle.GetLengthOfText(txtTaxIDNumber);
            for (int i = 0; i <= indexlength - 1; i++)
            {
                appHandle.SendKeyStroke(txtTaxIDNumber, InputKey.Backspace);
            }
            appHandle.Set_field_value(txtTaxIDNumber, taxid);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_CUSTOMER_INFORMATION_UPDATED"));

        }

        public virtual bool WaitUntilCustomerInformationPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(PersonalInformation_TaxIDNumber_Field))
            {
                result = true;
            }

            return result;

        }
        public virtual bool VerifyMessageCustomerInformationPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual void EnterCustomerInformationDetails(string taxid=" ")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(PersonalInformation_TaxIDNumber_Field))
            {
                if(!string.IsNullOrEmpty(taxid))
                {
                    appHandle.Set_field_value(PersonalInformation_TaxIDNumber_Field,taxid);
                }
            }
        }
        public virtual void UpdateTaxId()
        {            
            string TAXID = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"), "-");

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton))
            {
                appHandle.ClearEditValue(PersonalInformation_TaxIDNumber_Field);
                appHandle.Set_field_value(PersonalInformation_TaxIDNumber_Field, TAXID);
                this.ClickOnSubmitButton();
                if (WebCSRPageFactory.CreatePersonalCustomerPage.verify_tax_id_warning_message_element_exist())
                {
                    this.UpdateTaxId();
                }
                
            }

        }
        public virtual void UpdateAddress(string city)
        {
           if(!string.IsNullOrEmpty(city))
                {
                    appHandle.Set_field_value(txtCity,city);
                }
        }
        public virtual void select_passport_radio_button()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Passport_RadioButton))
            {
                appHandle.Set_radiobutton(Passport_RadioButton);
            }
        }
         public virtual void enter_passport_identification_details(string passportno,string issuedate, string expdate)
        {
            select_passport_radio_button();
            appHandle.Set_field_value(Passport_Number_Field, passportno);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(CountryOfIssue_Dropdown))
            {
                appHandle.SelectDropdownSpecifiedValue(CountryOfIssue_Dropdown, (string)Data.Get("GLOBAL_ADDCOUNTRY"));
            }
            appHandle.Set_field_value(Passport_IssueDate_Field, issuedate);
            appHandle.Set_field_value(Passport_ExpireDate_Field, expdate);


        }
        public virtual void UpdateNameInPersonalInfo(string name)
        {
           appHandle.Set_field_value(middlename,name);
        }
        public virtual bool UpdateDOB(string dobval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDateOfBirth);
            appHandle.Set_field_value(txtDateOfBirth,dobval);
            appHandle.SelectDropdownSpecifiedValue(drpPersonalInformationMaritalStatus,"1 - Married");
            appHandle.ClickObject(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_CUSTOMER_INFORMATION_UPDATED"));
        }

        public virtual bool CheckSuccessMessage()
        {
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_CUSTOMER_INFORMATION_UPDATED"));
        }

        
        public virtual void UpdateCustUserid(string CustUserid)
        {
           if(!string.IsNullOrEmpty(CustUserid))
                {
                    appHandle.Set_field_value(txtCustUserid,CustUserid);
                }
        }
            public virtual string GetValueofCustUserid()
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCustUserid);
                string CustUserid=appHandle.GetEditFieldValue(txtCustUserid);
                return CustUserid;
            }


    }
}