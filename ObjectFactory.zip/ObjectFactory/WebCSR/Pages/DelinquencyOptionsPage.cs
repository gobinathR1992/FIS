using System;
using GTS_OSAF.CoreLibs;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class DelinquencyOptionsPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtGeneralMinimumBilledAmountforDelinquency = "Xpath;//input[@name='PRODDFTL_MBLDELQ']";
        public static string cbkSubjecttoProvisionProcessing = "Xpath;//input[@name='PRODCTL_PROVPO']";
        public static string cbkSubjecttoReclasificationProcessing = "Xpath;//input[@name='PRODCTL_DARCPO']";
        public static string cbkSubjecttoReclasificationProcessingifCurrent = "Xpath;//input[@name='PRODCTL_DARCCU']";
        public static string cbkNonAccrualProcessingAutomaticNonAccrual = "Xpath;//input[@name='PRODCTL_ANA']";
        

    }
}