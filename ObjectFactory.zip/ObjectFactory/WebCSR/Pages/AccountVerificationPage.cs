using System;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountVerificationPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string AccountIntegrityMSGOBJ = "XPath;//div[@class='dataTables_scrollHead']/following-sibling::div/descendant::td";
        public static string DropdownAccount = "Xpath;//select[@name='ACN_CID']";

        public static string AccountVerificationTable = "Xpath;//*[@id='verification-error-list_wrapper']";
        public static string drpNextPage = "Name;nextpage";

        /// <summary>
        /// This method is used to select Account From AccountDropdown
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.AccountVerificationPage.selectAccountFromAccountDropdown();
        /// </example>
        public virtual void selectAccountFromAccountDropdown(string accName, string accNumber)
        {
            try
            {
                appHandle.WaitUntilElementVisible(DropdownAccount);
                appHandle.SelectDropdownSpecifiedValue(DropdownAccount, accName + " - " + accNumber);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }
        /// <summary>
        /// This method is used to Verify Integrity Error
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.AccountVerificationPage.VerifyIntegrityError();
        /// </example>
        public virtual bool VerifyIntegrityError()
        {
            bool bCheck = false;
            try
            {
                bCheck = appHandle.CheckTextExistsInTable(AccountVerificationTable, Data.Get("CHECK_INTEGRITY_SUCCESS_MSG"));
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;
        }

        /// <summary>
        /// This method is used to select value from the dropdown.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.AccountVerificationPage.VerificationAction();
        /// </example>
        public virtual void VerificationAction(string actionType)
        {
            Report.Info("Select customer information from drop down");
            try
            {
                appHandle.WaitUntilElementVisible(drpNextPage);
                appHandle.SelectDropdownSpecifiedValue(drpNextPage, actionType);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
        public virtual void SelectAccountFromAccountsDropdown(string AccountNumber)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccount, AccountNumber);
        }
        public virtual bool VerifyAccountInformationIntegrity(string message = "")
        {
            bool Result = false;
            if (!string.IsNullOrEmpty(message))
            {
                appHandle.GetObjectText(AccountIntegrityMSGOBJ).Contains(message);
                {
                    Result = true;
                }
            }
            else
            {
                if (appHandle.GetObjectText(AccountIntegrityMSGOBJ).Equals(Data.Get("CHECK_INTEGRITY_SUCCESS_MSG")))
                {
                    Result = true;
                }
            }
            return Result;
        }
     
}
}