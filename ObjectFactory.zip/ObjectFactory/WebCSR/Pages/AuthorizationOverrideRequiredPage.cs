using GTS_OSAF.CoreLibs;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AuthorizationOverrideRequiredPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtUserId = "Xpath;//input[@id='alluserid']";
        public static string txtPassword = "Xpath;//input[@id='alluserpassword']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string buttonOverride = "XPath;//*[text()='Override']";
        static string UserID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        static string Password = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;

        /// <summary>
        /// This method is used to Enter details in Authorization Popup window.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// AuthorizationOverrideRequiredPage.EnterAuthorizationDetails();
        /// </example>
        public virtual void EnterAuthorizationDetails()
        {
            Report.Info("Enter details in Authorization PopUp window");
            string userId = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
            string Password = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            appHandle.Set_field_value(txtUserId, userId);
            appHandle.Set_field_value(txtPassword, Password);
        }

        public virtual void EnterUserCredentials(string UserID, string Password)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonOverride))
            {
                appHandle.Set_field_value(txtUserId, UserID);
                appHandle.Set_field_value(txtPassword, Password);
            }
        }
        public virtual bool ValidateErrorMessageDueToInValidUserData(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (appHandle.GetObjectText(MSGOBJ).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void ClickOnOverrideButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonOverride))
            {
                appHandle.ClickObjectViaJavaScript(buttonOverride);
            }
        }
         public virtual void EnterUserCredentials()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonOverride))
            {
                appHandle.Set_field_value(txtUserId, UserID);
                appHandle.Set_field_value(txtPassword, Password);
            }
        }
    }
}
