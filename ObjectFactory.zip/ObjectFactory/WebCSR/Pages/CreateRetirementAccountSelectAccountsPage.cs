using GTS_OSAF.CoreLibs;
using System;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateRetirementAccountSelectAccountsPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string txtRetirementAccountSelectAccountsMsg="Xpath;//h2[contains(text(),'Select Accounts')]";

        
        //Below method is for confirm the "Select Accounts" message is there in Retirement Account Page.
        public virtual bool ConfirmRetirementSelectAccountsPage()
        {
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirm the select accounts page while creating Retirement account");
            bool blnSuccess = false;
            if (appHandle.CheckObjectExist(txtRetirementAccountSelectAccountsMsg))
            {
                blnSuccess = true;
            }
            else
            {                
                blnSuccess = false;
            }                
            return blnSuccess;
        }

        /// <summary>
        /// Select the product type in Retirement Account select account spage.
        /// <param name= "product Desc"></param> 
        /// <param name= "noofaccounts"></param> 
        /// <returns>bool</returns>
        /// <example>SelectProductinRetirementSelectAccountsPage(sProductDesc,sNoofaccounts)</example>
        public bool SelectProductinRetirementSelectAccountsPage(string ProductDesc, string Noofaccounts)
        {
            bool bcheck = false;
            try
            {
                WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                string prodType = "XPath;//tr[td[a[text()='" + ProductDesc + "']]]//select";
                if (appHandle.IsObjectExists(prodType))
                {
                    appHandle.WaitUntilElementClickable(prodType);
                    appHandle.SelectDropdownSpecifiedValue(prodType, Noofaccounts);
                    bcheck = true;
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }


        /// <summary>
        /// Method for confirm the specified product is there or not in product selection page.
        /// <param name= "product Desc"></param> 
        /// <returns>bool</returns>
        /// <example>ConfirmProductinRetirementSelectAccountsPage(sProductDesc)</example>
        //Method for confirm the specified product is there or not in product selection page.
        public bool ConfirmProductinRetirementSelectAccountsPage(string ProductDesc)
        {
            bool bcheck = false;
            try
            {
                WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                if (appHandle.CheckObjectExist(ProductDesc))
                {
                    appHandle.WaitUntilElementClickable(ProductDesc);
                    bcheck = true;
                    Report.Info("Specified product is there in product selection page");
                }
                else
                {
                    return false;
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }
    }
}