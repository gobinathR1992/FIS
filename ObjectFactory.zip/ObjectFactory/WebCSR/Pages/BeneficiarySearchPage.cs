using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class BeneficiarySearchPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtBeneficiaryID="Xpath;//input[@name='beneficiaryId']";
        public static string txtLast5digitofBenID="Xpath;//input[@name='lastDigitsOfBeneficiaryId']";
        public static string btnsearch="Xpath;//input[@name='search']";
        public static string btncancel="Xpath;//input[@name='cancel']";

        public static string btnsubmit="Xpath;//input[@name='submit']";
        public static string txtBensearchMsg="Xpath;//h1[contains(text(),'Beneficiary Search')]";
        
        //method for clcik the search button.
        public virtual void ClickonSearchbutton()
        {
            appHandle.SelectButton(btnsearch);
        }

        //method for clcik the Cancel button.
        public virtual void ClickonCancelButton()
        {
            appHandle.SelectButton(btncancel);
        }

        //method for clcik the submit button.
        public virtual void ClickonsubmitButton()
        {
            appHandle.SelectButton(btnsubmit);
        }

        //Method for Navigated to the Beneficiary search page.
        public virtual bool ConfirmBeneficiarySearchPage()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirmed the Beneficiary search page");
            bool blnSuccess = false;
            if (appHandle.CheckObjectExist(txtBensearchMsg))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }

    }
}