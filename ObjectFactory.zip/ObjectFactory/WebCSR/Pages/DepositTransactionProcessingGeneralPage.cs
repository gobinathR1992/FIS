using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DepositTransactionProcessingGeneralPage
    {
        WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string General_Heading = "Xpath;//h1[contains(text(),'General')]";
        public static string Last_Credit_Amount_Field = "Xpath;//td[input[@name='DEP_AMTLC']]";
        public static string Date_Of_Last_Credit_Field = "Xpath;//td[input[@name='DEP_DTLC']]";
        public static string Last_Debit_Amount_Field = "Xpath;//td[contains(text(),'Last Debit Amount')]/following-sibling::td";
        public static string Date_Of_Last_Debit_Field = "Xpath;//td[contains(text(),'Date of Last Debit')]/following-sibling::td";
        public static string Transaction_Acceptance_Instructions_Section_Header = "Xpath;//h2[contains(text(),'Transaction Acceptance Instructions')]";
        public static string txtTransactionRestrictionsMinimumBalance="Xpath;//input[@name='DEP_MINBAL']";
        public static string txtTransactionRestrictionsMaximumBalance="Xpath;//input[@name='ACN_MAXBAL']";
        public static string drpTransactionRestrictionsProcessRestriction="Xpath;//select[@name='DEP_FLG']";

        private static string Submit_Button = "Xpath;//input[@value='Submit']";
        private static string Cancel_Button = "Xpath;//input[@value='Cancel']";
        

        public virtual void navigate_to_transaction_processing_general_page()
        {
            WebCSRPageFactory.AccountInformationPage.select_transaction_processing_tab();
            applicationHandle.Wait_for_object(General_Heading, 2);
        }

        public virtual string get_last_credit_amount_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(Last_Credit_Amount_Field);
        }
        public virtual string get_date_of_last_credit_field_value()
        {
            applicationHandle.Wait_for_object(Submit_Button, 5);
            return applicationHandle.GetObjectText(Date_Of_Last_Credit_Field);
        }

        public virtual string get_last_debit_amount_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            applicationHandle.ScrollToObject(Transaction_Acceptance_Instructions_Section_Header);
            return applicationHandle.GetObjectText(Last_Debit_Amount_Field);
        }
        public virtual string get_date_of_last_debit_field_value()
        {
            applicationHandle.Wait_for_object(Submit_Button, 5);
            applicationHandle.ScrollToObject(Transaction_Acceptance_Instructions_Section_Header);
            return applicationHandle.GetObjectText(Date_Of_Last_Debit_Field);
        }

    }
}