using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class MaturityPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string ckbMaturityInformationNegotiable = "Xpath;//input[@name='DEP_ISNEGOTIABLE']";
        public static string ckbExtendMaturitywithDeposit="Xpath;//input[@name='DEP_MDTEXT']";
        public static string txtMaturityInformationAccountTerm="Xpath;//input[@name='DEP_TRM']";
        public static string txtMaturityInformationMaturityDate="Xpath;//input[@name='ACN_MDT']";
        public static string txtRenewalInformationPartialRenewalAmount="Xpath;//input[@name='DEP_PRENA']";
        public static string txtRenewalInformationAdditionalDepositAmount="Xpath;//input[@name='DEP_ADDNLDEPAMT']";
        public static string drpMaturityAccount="Xpath;//select[@name='ACN_CID']";
        public static string drpMaturityInformationBusinessDateOption="Xpath;//select[@name='DEP_BUSOPT']";
        public static string drpMaturityInformationBusinessDateCalender="Xpath;//select[@name='DEP_NBDC']";
        public static string drpRenewalInformationEarningsRenewalOption="Xpath;//select[@name='DEP_ERO']";
        public static string drpRenewalInformationRateRenewalOption="Xpath;//select[@name='DEP_RRO']";
        public static string drpRenewalInformationRateOptionduringGracePeriod="Xpath;//select[@name='DEP_RATEOPTGRC']";
        public static string drpRenewalInformationGracePeriodOption="Xpath;//select[@name='DEP_GOPT']";
        public static string drpRenewalInformationProductParameterOption="Xpath;//select[@name='DEP_PMO']";
        public static string drpRenewalInformationRenewalDefaultGroup="Xpath;//select[@name='DEP_DFTMDT']";
        public static string drpRenewalInformationResetInterestAvailableonRenewalOption="Xpath;//select[@name='DEP_INTAVLR']";
        public static string drpRenewalInformationPrincipalMaturityOption="Xpath;//select[@name='DEP_RENCD']";
        public static string drpRenewalInformationInterestMaturityOption="Xpath;//select[@name='DEP_IMO']";
        public static string btnSubmit="Xpath;//input[@name='submit']";
        public static string btnCancel="Xpath;//input[@name='cancel']";
               
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        private static string drpRenewalInformationInternalInterestTransferAccount = "Xpath;//*[@name='DEP_INTMATITA']";
        private static string drpRenewalInformationInternalPrincipalTransferAccount = "Xpath;//*[@name='DEP_RACN']";
        private static string MSGOBJ = "Xpath;//*[text()='The information has been updated.']";

         public virtual void SetAccountTerm(string sTerm)
        {
            //Method is for Enter the Account Term Field.
            appHandle.Set_field_value(txtMaturityInformationAccountTerm, sTerm);
            Report.Info("Entered the Account Term");
        }

        public virtual void SetMaturityDate(string sMatDate)
        {
            //Method is for Enter the Maturity Date.
            appHandle.Set_field_value(txtMaturityInformationMaturityDate, sMatDate);
            Report.Info("Entered the Maturity Date");
        }

        public virtual void SelectPrincipalMaturityOption(string sMatOption)
        {
            //Method is for select the principal maturity option
            appHandle.SelectDropdownSpecifiedValue(drpRenewalInformationPrincipalMaturityOption, sMatOption);
            Report.Info("Selected the Principal Maturity Option");
        }

        public virtual void SetAdittionalDepositAmount(string sAddiAmount)
        {
            //Method is for enter the addittional Deposit Amount.
            appHandle.Set_field_value(txtRenewalInformationAdditionalDepositAmount, sAddiAmount);
            Report.Info("Entered the Additiional Deposit Amount.");
            
        }

        public virtual void ClickonSubmitbutton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(btnSubmit);
        }

        public virtual void ClickonCancelbutton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.ClickObject(btnCancel);
        }
public virtual bool VerifyMessageInMaturityPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
public virtual void EnterMaturityOptions(string sTerm= "",string prinMaturityOption = "")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpMaturityAccount))
            {
                if(!string.IsNullOrEmpty(sTerm))
                {
                appHandle.Set_field_value(txtMaturityInformationAccountTerm,sTerm);
                }
                if(!string.IsNullOrEmpty(prinMaturityOption))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpRenewalInformationPrincipalMaturityOption,prinMaturityOption);
                }
            }

        }
        public virtual void MaturityOptionforInternalAcc(string PrincipalMaturityOption, string InternalPrincipalTransferAccount, string InterestMaturityOption, string InternalInterestTransferAccount)
        {
            appHandle.WaitUntilElementExists(drpRenewalInformationPrincipalMaturityOption);
            appHandle.SelectDropdownSpecifiedValue(drpRenewalInformationPrincipalMaturityOption, PrincipalMaturityOption);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpRenewalInformationInterestMaturityOption, InterestMaturityOption);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpRenewalInformationInternalPrincipalTransferAccount, InternalPrincipalTransferAccount);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpRenewalInformationInternalInterestTransferAccount, InternalInterestTransferAccount);
        }
        public virtual void ClickOnSubmit()
        {
            appHandle.ClickObjectViaJavaScript(btnSubmit);
        }

        public virtual bool VerifySuccessMessage()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if ((appHandle.GetObjectText(MSGOBJ)).Equals(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Result = true;
                }
            }
            return Result;
        }

    }


    }


