using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class ChexSystemsDataPage
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string dropdownAccountStatusCodeOverride="XPath;//select[@name='DEPCHEXSYS_ACCTSTATUSCODEOVERRIDE']";  
        public static string buttonSubmit="XPath;//input[@name='submit']";
       
       public static string radiobuttonForcedClosedAccountYes="XPath;//input[@name='DEPCHEXSYS_FORCEDCLOSEDACCT'][@value='yes']";
       public static string radiobuttonPrimaryClosurereasonSuspectFraud="XPath;//input[@name='DEPCHEXSYS_PRIMARYCLOSUREREASON'][@value='7']";
       public static string txtPrincipalChargeOffAmount="XPath;//input[@name='DEPCHEXSYS_PRINCIPALCHARGEOFFAMOUNT']";
       public static string txtFeeChargeOffAmount="XPath;//input[@name='DEPCHEXSYS_FEESCHARGEOFFAMOUNT']";
       public static string dropdownSecondaryClosureReason="XPath;//select[@name='DEPCHEXSYS_SECONDARYCLOSUREREASON']";
       public static string dropdownTertiaryClosureReason="XPath;//select[@name='DEPCHEXSYS_TERTIARYCLOSUREREASON']"; 
        public static string radiobuttonConsumerDispute="XPath;//input[@name='DEPCHEXSYS_CONSUMERDISPUTE'][@value='yes']";
        public static string dropdownReasonforChange="XPath;//select[@name='DEPCHEXSYS_REASONFORCHANGE']";
        public static string dropdownClosureStatusCodeOverride="XPath;//select[@name='DEPCHEXSYS_CLOSURESTATCODEOVR']";

        public static string txtClosureStatusDate="XPath;//input[@name='DEPCHEXSYS_CLOSURESTATUSDATE']";
        public static string txtSettledInFullAmount="XPath;//input[@name='DEPCHEXSYS_AMOUNTSETTLED']";
        public static string dropdownReasonforRemoval="XPath;//select[@name='DEPCHEXSYS_REASONFORREMOVAL']";



        public virtual void SelectValueFromAccountStatusCode(string value="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccountStatusCodeOverride);
            if(string.IsNullOrEmpty(value))
            {
                appHandle.SelectDropdownSpecifiedValueByIndex(dropdownAccountStatusCodeOverride,0);

            }
            else
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownAccountStatusCodeOverride,value);
            }
        }

        public virtual bool ClickOnSubmit()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }


        public virtual bool SetupForChexSystem29(string principalchargeoff,string feechargoffamount,string secclosreason,string tericlosreason)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownSecondaryClosureReason);
            appHandle.ClickObjectViaJavaScript(radiobuttonForcedClosedAccountYes);
            appHandle.ClickObjectViaJavaScript(radiobuttonPrimaryClosurereasonSuspectFraud);
            appHandle.Set_field_value(txtPrincipalChargeOffAmount,principalchargeoff);
            appHandle.Set_field_value(txtFeeChargeOffAmount,feechargoffamount);
            appHandle.SelectDropdownSpecifiedValue(dropdownSecondaryClosureReason,secclosreason);
            appHandle.SelectDropdownSpecifiedValue(dropdownTertiaryClosureReason,tericlosreason);
            return ClickOnSubmit();
        
        }

        public virtual bool SetupForChexSystem29DP2(string reasonforchange,string closstatuscodeoveride,string closstatusdate,string settledfullamount)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownReasonforChange);
            appHandle.ClickObjectViaJavaScript(radiobuttonConsumerDispute);
            appHandle.SelectDropdownSpecifiedValue(dropdownReasonforChange,reasonforchange);
            appHandle.SelectDropdownSpecifiedValue(dropdownClosureStatusCodeOverride,closstatuscodeoveride);
            appHandle.Set_field_value(txtClosureStatusDate,closstatusdate);
            appHandle.Set_field_value(txtSettledInFullAmount,settledfullamount);
            return ClickOnSubmit();

        }

        public virtual bool SelectValueFromReasonForRemovalAndSubmit(string val)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownReasonforRemoval);
            appHandle.SelectDropdownSpecifiedValue(dropdownReasonforRemoval,val);
            return ClickOnSubmit();


        }

    
    }
}