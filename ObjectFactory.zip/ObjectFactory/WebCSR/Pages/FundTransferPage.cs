using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class FundTransferPage
    {

        static WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string TransferFromAccountDropdown = "XPATH;//select[@id='fromID']";
        public static string TransferToAccountDropdown = "XPATH;//select[@id='toID']";
        public static string TransferAmountField = "XPATH;.//input[@name='EFTPAY_AMOUNT']";
        public static string TermsMethodRadioButton = "Xpath;.//input[@name='transferMethod' and @value='1']";
        public static string FundTransferStartDate = "Xpath;.//input[@name='EFTPAY_EFD']";
        public static string submitButton = "Xpath;.//input[@name='submit']";
        public static string TransferFundsVerificationPage = "Xpath;.//h1[text()='Transfer Funds Verification']";

        public static string TransferFundsConfirmationPage = "Xpath;//h1[text()='Transfer Funds Confirmation']";
        public static string TransferFundsLink = "Xpath;//td[text()='Transfer Funds']";
        public static string FundingServicesTab = "Xpath;//td[contains(text(),'Funding Services')]";
        public static string TransferFundsPageElement = "Xpath;.//h1[text()='Transfer Funds']";
        public static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        private static string dropdownFrequency = "XPath;//*[@name='EFTPAY_FREQUENCY']";
        private static string txtTermEndDate = "XPath;//*[@name='EFTPAY_EXPDT']";
        private static string buttonCancelAuthorization = "XPath;//*[text()='Cancel']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string TransactionSuccessMessage = "Xpath;//*[text()='Transfer Details']/ancestor::tr[1]/preceding-sibling::tr/td";
        private static string buttonBack = "XPath;//*[@value='Back']";
        private static string TableContent = "XPAth;//table[@class='contentTable']/tbody";
        public virtual void EnterFundTransferDetails(string FromAccountNo, string ToAccountNo, string Amount, string systemDate="")
        {

            try
            {

                applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                applicationHandle.SelectDropdownSpecifiedValueByPartialText(TransferFromAccountDropdown, FromAccountNo);
                applicationHandle.SelectDropdownSpecifiedValueByPartialText(TransferToAccountDropdown, ToAccountNo);
                applicationHandle.Set_field_value(TransferAmountField, Amount);              
                applicationHandle.ClickObject(submitButton);
                applicationHandle.Wait_for_object(TransferFundsVerificationPage, 20000);
                applicationHandle.ClickObject(submitButton);
                if (applicationHandle.IsObjectExists(TransferFundsConfirmationPage))
                    Report.Pass("Transfer Funds Successful", "Transfer Funds ", "True", applicationHandle);

                else
                {
                    Report.Fail("Transfer Funds Failed", "Transfer Funds Failed", "True", applicationHandle);
                }

            }
            catch (Exception e)
            {
                Report.Fail(e.Message, "EnterFundTransferDetails Exception", applicationHandle);
            }
        }
        public virtual void NavigateToFundsTransferPage()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(FundingServicesTab);
            if(applicationHandle.IsObjectExists(TransferFundsLink))
            {
                applicationHandle.Select_link(TransferFundsLink);            

            }
            else
            {
                applicationHandle.Select_link(FundingServicesTab);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(TransferFundsLink);
                applicationHandle.Select_link(TransferFundsLink);          


            }
            
        }
        public static string ApplicationDate = new CreateTrustCustomerPage().GetApplicationDate();
        public virtual string GetApplicationDate()
        {
            string result = "";
            result = applicationHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }
        public virtual void EnterFundTransferDetails(string FromAccount, string ToAccount, string Amount)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(TransferFromAccountDropdown);
            applicationHandle.SelectDropdownSpecifiedValueByPartialText(TransferFromAccountDropdown, FromAccount);
            applicationHandle.SelectDropdownSpecifiedValueByPartialText(TransferToAccountDropdown, ToAccount);
            applicationHandle.Set_field_value(TransferAmountField, Amount);
            Report.Pass("The Fee Plan was Updated successfully In Deposit Fee Page", "FeePage", "true", applicationHandle);
            
        }
        public virtual void EnterFundTermDetails(string StartDate = null, string Frequency = null, string EndDate = null)
        {
            if (string.IsNullOrEmpty(StartDate))
            {
                StartDate = ApplicationDate;
            }
            if (string.IsNullOrEmpty(EndDate))
            {
                EndDate = "";
            }
            if (string.IsNullOrEmpty(Frequency))
            {
                Frequency = Data.Get("Once");
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TermsMethodRadioButton))
            {
                applicationHandle.ClickObjectViaJavaScript(TermsMethodRadioButton);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(FundTransferStartDate);
                applicationHandle.Set_field_value(FundTransferStartDate, StartDate);
                applicationHandle.SelectDropdownSpecifiedValue(dropdownFrequency, Frequency);
                applicationHandle.Set_field_value(txtTermEndDate, EndDate);
            }
             Report.Pass("The Fee Plan was Updated successfully In Deposit Fee Page", "FeePage", "true", applicationHandle);
        }
        public virtual void ClickOnSubmitBUtton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(submitButton))
            {
                applicationHandle.ClickObjectViaJavaScript(submitButton);
            }
        }
        public virtual void ClickOnSubmitButton_OverrideTransaction()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonBack))
            {
                applicationHandle.ClickObjectViaJavaScript(submitButton);
            }
        }

        public virtual void ClickOnAuthorizationCancelButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCancelAuthorization))
            {
                applicationHandle.ClickObjectViaJavaScript(buttonCancelAuthorization);
            }
        }
        public virtual bool VerifytransactionErrorMessageInFundsTransfer(string inputmessage)
        {
            bool Result = false;
            if (applicationHandle.GetObjectText(MSGOBJ).Equals(inputmessage))
            {
                Result = true;
            }

            return Result;
        }
        public virtual bool VerifySuccessfullTransferFundsMesage()
        {
            bool Result = false;
            if (applicationHandle.GetObjectText(TransactionSuccessMessage).Contains(Data.Get("The funds transfer has been completed. The transaction will process on the transaction date listed below.")))
            {
                Result = true;
            }

            return Result;
        }
 public virtual bool VerifyTransactionConfirmationTable(string LabelNameLabelValuePipeDelimited)
 {

     return Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(TableContent,LabelNameLabelValuePipeDelimited);
 }       
    }
}