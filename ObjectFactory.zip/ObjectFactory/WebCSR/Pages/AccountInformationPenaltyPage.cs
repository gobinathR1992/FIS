using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class AccountInformationPenaltyPage
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);


        public static string dropdownPenaltyMethod="XPath;//select[@name='DEP_POPT']";
        public static string dropdownReductionMethod="XPath;//select[@name='DEP_PRM']";
        public static string checkboxInterestPaidonPartialWithdrawal="XPath;//input[@name='DEP_PIPW']";
        public static string txtPenaltyRate="XPath;//input[@name='DEP_PRATE']";
        public static string buttonSubmit="XPath;//input[@name='submit']";

        public virtual bool UpdatePenaltyDetailsForCDAccount(string penaltymet,string redmeth,string penaltyrate,bool checkboxOnAndOffPartialWithdrawal=true)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownPenaltyMethod);
            appHandle.SelectDropdownSpecifiedValue(dropdownPenaltyMethod,penaltymet);
            appHandle.SelectDropdownSpecifiedValue(dropdownReductionMethod,redmeth);
            if(checkboxOnAndOffPartialWithdrawal)
            {
                if(!appHandle.CheckCheckBoxChecked(checkboxInterestPaidonPartialWithdrawal))
                {
                    appHandle.ClickObjectViaJavaScript(checkboxInterestPaidonPartialWithdrawal);
                }   
            }
            else
            {
                if(appHandle.CheckCheckBoxChecked(checkboxInterestPaidonPartialWithdrawal))
                {
                    appHandle.ClickObjectViaJavaScript(checkboxOnAndOffPartialWithdrawal);
                }
            }

            appHandle.Set_field_value(txtPenaltyRate,penaltyrate);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));


        }


    }
}