using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanCalculationOptionsPage
    {
        WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string Calculation_Options_Link = "Xpath;//td[contains(text(),'Calculation Options')]";        
        public static string Accrual_Calculation_Balance_Field = "Xpath;//tr[td[contains(text(),'Accrual Calculation Balance')]]//td[input[@name='LN_BALINT']]";
        public static string Submit_Button = "Xpath;//input[@value='Submit']";
        public static string Cancel_Button = "Xpath;//input[@value='Cancel']";
        public static string txtDailyCalculationOptionsInterestCalculationPeriodFrequency = "XPath;//input[@name='LN_ICPF']";
        public static string DropdownAccrualCalculationMethod = "Xpath;//select[@name = 'LN_IACM']";
        
        private static string buttonSubmit = "XPath;//input[@name='submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        private static string txtMinimumBalanceToAccrue = "Xpath;//input[@name='LN_MINACR']";
        public virtual string get_accrual_calculation_balance_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(Accrual_Calculation_Balance_Field);
        }
         public virtual void EnterCalculationPageOption(string AccrualMathod )
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownAccrualCalculationMethod))
            {
                applicationHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccrualCalculationMethod,AccrualMathod );

                
            }
        }
        public virtual void EnterCalculationOptions(string MinBalanceToAccrue = "", string InterestCalculationPeriodFrequency = "")
        {
            if (!string.IsNullOrEmpty(MinBalanceToAccrue))
            {
                applicationHandle.Set_field_value(txtMinimumBalanceToAccrue, MinBalanceToAccrue);
            }
            if (!string.IsNullOrEmpty(InterestCalculationPeriodFrequency))
            {
                applicationHandle.Set_field_value(txtDailyCalculationOptionsInterestCalculationPeriodFrequency, InterestCalculationPeriodFrequency);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                applicationHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMessageInLoanCalculationOptionPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (applicationHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }       
        
public virtual void NavigateToInterestCalculationPage()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(Calculation_Options_Link))
            {
            applicationHandle.Select_link(Calculation_Options_Link);
            }
        }


        
    }
}