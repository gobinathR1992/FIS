using GTS_OSAF.CoreLibs;
using System;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateRetirementAccountInformationPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string txtRetirementAccountInformationMsg="Xpath;//td[contains(text(),'Enter the following information for each account s')]"; 
        
        //Below method is for confirm the navigation for Retirement Account Information Page.
        public virtual bool ConfirmRetirementAccountInformationPage()
        {
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirm the Retirement Account Information Page while creating Retirement account");
            bool blnSuccess = false;
            if (appHandle.CheckObjectExist(txtRetirementAccountInformationMsg))
            {
                blnSuccess = true;
            }
            else
            {                
                blnSuccess = false;
            }                
            return blnSuccess;
        }
    }
}
