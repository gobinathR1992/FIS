using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class AccountInformationInterestAccrualPage
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string dropdownAccrualMethod="XPath;//select[@name='DEP_IACM']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public virtual bool SelectValueOfAccrualMethod(string accmethod)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccrualMethod);
            appHandle.SelectDropdownSpecifiedValue(dropdownAccrualMethod,accmethod);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }


    }
}