using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class LoanCommitmentProcessingPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private  static string cbxCommitmentProcessing = "Xpath;//input[@name='LN_CPF']";
        private  static string txtCommitmentLink = "Xpath;//input[@name='LN_CCL']";
		private  static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
		
	public virtual void EnterLoanCommitmentProcessingPageOptions(string CommtPr=" ")
        {
		  try
		  {
		   if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(cbxCommitmentProcessing))
            {
                if(!string.IsNullOrEmpty(CommtPr))
                {
                appHandle.SelectCheckBox(cbxCommitmentProcessing);
                }
                                       
            }
		  }
		  catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
		
		 public virtual void SelectSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            
        }
	   
	    public virtual bool VerifyMessageLoanCommitmentProcessingPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }	
      
    }
}

