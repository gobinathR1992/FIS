using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.Util;
using GTS_OSAF.HelperLibs.DataAdapter;


namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class ServiceItemAssignmentPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string CategoryDropDown = "Xpath;//*[@name='SRVITM_SRVCAT']";
        private static string TypeDropDown = "Xpath;//*[@name='SRVITM_SRVTYP']";
        private static string LocationDropDown = "Xpath;//*[@name='SRVITM_SRVLOC']";
        private static string NoServiceLabel = "Xpath;//*[@class='dataTables_empty']";
        
        public virtual Boolean ValidateNoServiceItemsFound(string ItemToBeSelected)
        {
            Boolean Check = false;
            string[] ArrayValues = ItemToBeSelected.Split('|');
            string CategoryValue = ArrayValues[0];
            string TypeValue = ArrayValues[1];
            string LocationValue = ArrayValues[2];
            
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(CategoryDropDown))
            {
                appHandle.SelectDropdownSpecifiedValue(CategoryDropDown, CategoryValue);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(TypeDropDown))
            {
                appHandle.SelectDropdownSpecifiedValue(TypeDropDown, TypeValue);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(LocationDropDown))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(LocationDropDown, LocationValue);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(NoServiceLabel))
            {
            appHandle.GetLabelText(NoServiceLabel).Contains(Data.Get("ServiceItemAssignmentNoServiceLabel"));
            Check = true;
            }
            return Check;
        }
        
    }
}