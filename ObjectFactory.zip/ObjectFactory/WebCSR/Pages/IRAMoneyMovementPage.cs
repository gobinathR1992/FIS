using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class IRAMoneyMovementPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string DropdownIRAMoneyMovement = "Xpath;//select[@name='EFTPAY_CID']";
        private static string buttonAdd = "Xpath;//*[@value='Add']";
        private static string DropdownPaymentType = "Xpath;//select[@name='paymentType']";
        private static string RadioInternalRegisteredAccount = "XPath;//input[@name='accountSelection'][@value='0']";
        private static string RadioUnRegisteredAccount = "XPath;//input[@name='accountSelection'][@value='1']";
        private static string DropdownRecipientAccount = "Xpath;//select[@name='EFTPAY_RECACCT']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string ContinueButton = "XPath;//*[@value='Continue']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string DropdownAmountype = "Xpath;//select[@name='EFTRSPSDSIGN_AMTTYPE']";
        private static string TxtnAmount = "Xpath;//input[@name='EFTRSPSDSIGN_AMTREQUESTED']";
        private static string DropdownDistributionReasonCode = "Xpath;//select[@name='EFTRSPSDSIGN_REASONCODE']";
        private static string TxtFederalwithholdingFixed = "Xpath;//input[@name='EFTRSPSDSIGN_FEDWHAMT']";
        private static string TxtFederalWitholdingPercentage = "Xpath;//input[@name='EFTRSPSDSIGN_FEDWHPCT']";
        private static string txtEffectiveDate = "Xpath;//input[@name='EFTPAY_EFD']";
        public virtual void EnterRecepientAccountDetails(bool radio, string Account,string Amouttype,string Amount,string distributioncode,string date,string FedWithholdingPer = "",string FedWithholdingFixedAmt = "")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(RadioInternalRegisteredAccount);
            if (radio == true)
            {
                appHandle.ClickObjectViaJavaScript(RadioInternalRegisteredAccount);
            }
            else
            {
                appHandle.ClickObjectViaJavaScript(RadioUnRegisteredAccount);
            }

            if (!string.IsNullOrEmpty(Account))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownRecipientAccount, Account);
            }
            if (!string.IsNullOrEmpty(Amouttype))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAmountype, Amouttype);
            }
            int fedwithholdingperlength = appHandle.GetLengthOfText(TxtnAmount);
            for (int i = 0; i <= fedwithholdingperlength - 1; i++)
            {
                appHandle.SendKeyStroke(TxtnAmount, InputKey.Backspace);
            }
            appHandle.Set_field_value(TxtnAmount, Amount);

            if (!string.IsNullOrEmpty(distributioncode))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownDistributionReasonCode, distributioncode);
            }
            if(!string.IsNullOrEmpty(date))
            {
                appHandle.Set_field_value(txtEffectiveDate,date);
            }
            if (!string.IsNullOrEmpty(FedWithholdingPer))
            {
                appHandle.Set_field_value(TxtFederalWitholdingPercentage, FedWithholdingPer);
            }
            if (!string.IsNullOrEmpty(FedWithholdingFixedAmt))
            {
                appHandle.Set_field_value(TxtFederalwithholdingFixed, FedWithholdingFixedAmt);
            }

        }

        public virtual void SelectIRAMoneyMovemnetAccount(string IRAccount, string plantype)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownIRAMoneyMovement, IRAccount);
            ClickOnAddButton();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownPaymentType);
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownPaymentType, plantype);
            Report.Pass("Enter Account and Plan details", "IRAmoneyMovementStatusPass", "true", appHandle);

        }
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);

            }
        }
        public virtual void SelectSubmitButton()
        {
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }
        public virtual void SelectContinueButton()
        {
            appHandle.ClickObjectViaJavaScript(ContinueButton);
        }
        public virtual bool VerifyMessageAccountInformationResidencyPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
    }
}