
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountSummaryPage
    {
        static WebApplication applicationHandle;
        private static string GeneralTab="Xpath;//td[text()='General']";
        public static string PaymentCalculationLink="Xpath;//a[text()='Payment Calculation']"; 
        private static string CalculationRulesAmortizationCalculationMethodDropdown="Xpath;//select[@name='LN_AMORCALMT']"; 
        private static string PaymentTab="Xpath;//td[text()='Payment']";
        private static string InformationUpdateMsg = "XPath;.//*[contains(@class,'info')][contains(.,'The information has been updated.')]";
        private static string CustomerCodeDropdown="XPath;.//select[@name='ACN_CCODE']";
        private static string SubmitButton="XPath;.//input[@type='submit']";
        private static string TitleTab="Xpath;//td[text()='Title/Address']";
        private static string MailAddress2Filed="XPath;.//input[@name='ACNADDR_AD2']";
        public virtual void ClickOnPaymentTab()
       {
           applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
           applicationHandle.Select_link(PaymentTab);
           applicationHandle.SyncPage();
       }

        public virtual void SelectPaymentCalculationLink()
       {
           applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
           applicationHandle.Select_link(PaymentCalculationLink);
           applicationHandle.SyncPage();
       }
    public virtual void SelectSpecifiedValueFromCalculationRulesAmortizationCalculationMethodDropdown(string AmortizationOption)
       {
           applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
           applicationHandle.SelectDropdownSpecifiedValue(CalculationRulesAmortizationCalculationMethodDropdown,AmortizationOption);

       }

    public virtual void VerifyInformationUpdatedMessage()
    {
       applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
       //applicationHandle.CheckObjectExist(InformationUpdateMsg);
       applicationHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
    }
    public virtual void ClickOnGeneralTab()
    {
        applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        applicationHandle.SelectTab(GeneralTab);
        applicationHandle.SyncPage();
    }
    public virtual void ModifyCustomerCodeOnLoanGeneralPage(string CustomerCode)
    {
        applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        applicationHandle.SelectDropdownSpecifiedValue(CustomerCodeDropdown,CustomerCode);
        applicationHandle.SelectButton(SubmitButton);
        applicationHandle.SyncPage();
    }
    public virtual void ClickOnTitleTab()
    {
        applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        applicationHandle.SelectTab (TitleTab);
        applicationHandle.SyncPage();
    }

    public virtual void ModifyMailingAddressOnAccountSummaryPage(string AddressVal2)
    {
        applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        applicationHandle.Set_field_value(MailAddress2Filed,AddressVal2);
        applicationHandle.ClickObject(SubmitButton);
        applicationHandle.SyncPage();
        
    }
    
    }
}