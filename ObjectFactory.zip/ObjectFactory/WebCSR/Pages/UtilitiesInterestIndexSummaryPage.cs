using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;
using System.Threading;
 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class UtilitiesInterestIndexSummaryPage
    { 

        public static WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string IndexDropdown = "XPath;//select[@name='INDEX1_INDEX']";
        private static string Submit_Button = "XPath;//input[@value='Submit']";
        private static string txtFromDate = "XPath;//*[@name='fromDate']";
        private static string txtToDate = "Xpath;//*[@name='toDate']";


        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Submit_Button))
            {
                applicationHandle.ClickObjectViaJavaScript(Submit_Button);
            }
        }

        public virtual bool VerifyDataInInterestIndexSummary(string refColumnValuesSemicolonDelimited,string index ,string FromDate, string ToDate)
        {
            bool Result = false;
            int matchCount = 0;
            refColumnValuesSemicolonDelimited = refColumnValuesSemicolonDelimited + "|";
            string[] arr = refColumnValuesSemicolonDelimited.Split('|');
            applicationHandle.SelectDropdownSpecifiedValueByPartialText(IndexDropdown, index);
            if (!string.IsNullOrEmpty(FromDate))
            {
                applicationHandle.Set_field_value(txtFromDate, FromDate);
            }
            if (!string.IsNullOrEmpty(ToDate))
            {
                applicationHandle.Set_field_value(txtToDate, ToDate);
            }
            
            ClickOnSubmitButton();
            for (int a = 0; a < arr.Length - 1; a++)
            {
                if (Profile7CommonLibrary.VerifyDataInTableByColumnValues(arr[a]))
                {
                    matchCount++;
                }
                if (matchCount == arr.Length - 1)
                {
                    Result = true;
                    break;
                }
            }

            return Result;
        }

         
    }
}