using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class LoanCalculatorPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string drpType = "Xpath;//select[@name='LN_TYPE']";
		private static string txtDisbursementDate = "XPath;//*[@value='Submit']";
		private static string txtPaymentFrequency = "Xpath;//input[@id='LN_DIST1FRE']";
		private static string txtDateofFirstScheduledPayment = "XPath;//input[@id='LN_DFP']";
		private static string txtPaymentTerm = "Xpath;//input[@name='LN_PTRM']";
		private static string txtLoanAmount = "XPath;//input[@name='LN_AMTREQ']";
		private static string txtAmortizationTerm = "XPath;//input[@name='LN_TRM']";
		private static string txtInterestRate = "XPath;//input[@name='LN_IRN']";
		private static string txtPayment = "XPath;//input[@name='LN_PMTPI']";
        private static string lnkUtilities = "XPath;//td[contains(text(),'Utilities')]";
		private static string lnkLoanCalculator = "XPath;//td[contains(text(),'Loan Calculator')]";
		
		private static string buttonSubmit = "XPath;//input[@name='submit']";
		private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
		
		
		public virtual void EnterLoanCalculatorPageOptions(string Type=" ", string Disbursementdt ="", string PaymentFrequency ="", string DateofFirstScheduledPayment ="" ,string LoanAmount="",string InttRate="", string Payment="" )
        {
		  try
		  {
		   if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDisbursementDate))
            {
                if(!string.IsNullOrEmpty(Type))
                {
                appHandle.SelectDropdownSpecifiedValue(drpType, Type);
                }
				
                if(!string.IsNullOrEmpty(Disbursementdt))
                {
                appHandle.Set_field_value(txtDisbursementDate,Disbursementdt);
                }
				

                if(!string.IsNullOrEmpty(PaymentFrequency))
                {
                appHandle.Set_field_value(txtPaymentFrequency,PaymentFrequency);
                }
				
                if(!string.IsNullOrEmpty(DateofFirstScheduledPayment))
                {
                appHandle.Set_field_value(txtDateofFirstScheduledPayment,DateofFirstScheduledPayment);
                }

                if(!string.IsNullOrEmpty(LoanAmount))
                {
                appHandle.Set_field_value(txtLoanAmount,LoanAmount);
                }
				
                if(!string.IsNullOrEmpty(InttRate))
                {
                appHandle.Set_field_value(txtInterestRate,InttRate);
                }
                
				if(!string.IsNullOrEmpty(Payment))
                {
                appHandle.Set_field_value(txtPayment,Payment);
                }
			 
            }
		  }
		  catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
		
		 public virtual void SelectSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            
        }
	   
	    public virtual bool VerifyMessageLoanCalculatorPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

      	public virtual void SelectLoanCalculatorLink()
        {
            appHandle.WaitUntilElementVisible(lnkUtilities);
            appHandle.WaitUntilElementClickable(lnkUtilities);
            appHandle.Select_link(lnkUtilities);
            appHandle.Wait_For_Specified_Time(5);
            appHandle.WaitUntilElementVisible(lnkLoanCalculator);
            appHandle.WaitUntilElementClickable(lnkLoanCalculator);
            appHandle.Select_link(lnkLoanCalculator);
             
        }

        public virtual bool VerifyAmortizationTerm(string amtterm)
        {
            bool result=false;
            if(appHandle.GetSpecifiedObjectAttribute(txtAmortizationTerm,"value").Contains(amtterm))
                {
                    result=true;
                }
                return result;
        }
	


    }
}

