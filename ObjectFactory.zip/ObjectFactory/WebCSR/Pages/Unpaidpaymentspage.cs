
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class Unpaidpaymentspage
    {
        public static string tblUnpaidPayments = "XPath;//table[@id='scheduledPayments-list']";
    }
}