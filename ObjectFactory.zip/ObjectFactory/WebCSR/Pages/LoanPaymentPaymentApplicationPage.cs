using System;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class LoanPaymentPaymentApplicationPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonSubmit = "XPath;//input[@name='submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        private static string checkboxPreAuthorizedPaymentRequired = "XPAth;//*[contains(text(),'Pre-Authorized Transfer Allowed')]/following-sibling::*/descendant::input";
        private static string txtNumberofDaystoProject = "Xpath;//input[@name='LN_NUMDTP']";
        public virtual bool ClickOnSubmitButton()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
                {
                    result = true;
                }
            }
            return result;
        }
        public virtual bool VerifyMessageInLoanPaymentsPaymentApplicationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void SelectPreAuthorizedTransferAllowed(bool ONOFF, string NumberofDaystoProject)
        {
            if (ONOFF)
            {
                if (appHandle.CheckCheckBoxChecked(checkboxPreAuthorizedPaymentRequired)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxPreAuthorizedPaymentRequired);
                }
            }
            else
            {
                if (!appHandle.CheckCheckBoxChecked(checkboxPreAuthorizedPaymentRequired)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxPreAuthorizedPaymentRequired);
                }
            }
            if (!string.IsNullOrEmpty(NumberofDaystoProject))
            {
                appHandle.Set_field_value(txtNumberofDaystoProject, NumberofDaystoProject);
            }


        }
        public virtual bool WaitUntilPaymentsPaymentApplicationPageLoads()
        {
            return Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxPreAuthorizedPaymentRequired);
        }
        public virtual void SelectAmortizationCalcMethod(string calculationMethod)
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Amortization Calculation Method")+"|"+calculationMethod);
        }
    }
}