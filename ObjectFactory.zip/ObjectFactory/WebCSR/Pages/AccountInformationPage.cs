using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;
using System.Threading;
using Profile7Automation.Libraries.Helper;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountInformationPage
    {
        public static WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string General_Tab = "Xpath;//table[@class='tab']//td[contains(text(),'General')]";
        private static string Payment_Tab = "Xpath;//table[@class='tab']//td[text()='Payment']";
        private static string Interest_Tab = "Xpath;//table[@class='tab']//td[text()='Interest']";
        private static string TransactionProcessing_Tab = "Xpath;//table[@class='tab']//td[text()='Transaction Processing']";
        private static string Submit_Button = "Xpath;//input[@value='Submit']";
        private static string Cancel_Button = "Xpath;//input[@value='Cancel']";
        public static string lnkCollateral = "Xpath;//a[text()='Collateral']";
 public static string txtInterestRatesAnnualDisclosureRate = "XPath;//input[@name='LN_DISAPR']";
        private static string txtEffectiveDisclosureRate = "XPath;//input[@name='LN_EIRN']";

        // Account Information | General Tab element locators
        private static string General_LedgerBalance_Field = "Xpath;//tr[td[contains(text(),'Ledger Balance')]]//td[input[@name='ACN_BAL']]";
        private static string General_AvailableBalance_Field = "Xpath;//tr[td[contains(text(),'Available Balance')]]//td[input[@name='DEP_CSHBLAVL']]";
        private static string General_ComputedBalance_Field = "Xpath;//tr[td[contains(text(),'Computed Balance')]]//td[input[@name='LN_BALCMP']]";
        private static string General_CollectedBalance_Field = "Xpath;//tr[td[contains(text(),'Collected Balance:')]]//td[input[contains(@name,'ACN_BALCOL')]]";
        public static string txtMaturityInformationAccountTerm = "Xpath;//input[@name='DEP_TRM']";
        public static string drpRenewalInformationPrincipalMaturityOption = "Xpath;//select[@name='DEP_RENCD']";
        public static string drpCalculationOptionsAccrualBase = "Xpath;//select[@name='DEP_IRCB']";
        public static string drpCalculationOptionsAccrualMethod = "Xpath;//select[@name='DEP_IACM']";
        public static string txtCalculationOptionsCompoundingFrequency = "Xpath;//input[@name='DEP_ICF']";

        public static string txtRateDeterminationInterestRate = "Xpath;//input[@name='ACN_IRN']";
        public static string drpDisbursementOption = "Xpath;//select[@name='DEP_IOPT']";
        public static string txtDisbursementCheckFrequency = "Xpath;//input[@name='DEP_INTCHKFRE']";
        public static string txtPositiveInterestPostingFrequency = "Xpath;//input[@name='DEP_IPF']";
        public static string lnkRateDetermination = "Xpath;//a[text()='Rate Determination']";
        public static string lnkPayment = "Xpath;//a[text()='Payment']";
        public static string lnkPaymentDetail = "Xpath;//a[text()='Payment Detail']";
        public static string txtPaymentsDueTotalNumberofPayments = "name;LN_ONP";
        public static string lnkAccrual = "Xpath;//a[text()='Accrual']";
        public static string lnkCalculationOptions = "Xpath;//a[text()='Calculation Options']";
        public static string txtAnnualDisclosureRate = "Xpath;//input[@name='LN_DISAPR']";
        public static string txtInterestRate = "Xpath;//input[@name='LN_IRN']";
        public static string txtDailyCalculationOptionsInterestCalculationPeriodFrequency = "Xpath;//input[@name='LN_ICPF']";
        public static string drpRateDeterminationAccount = "Xpath;//select[@name='ACN_CID']";
        public static string txtCalculationOptionsCompoundedNextDate = "Xpath;//input[@name='DEP_INC']";
        public static string lnkWithholding = "Xpath;//a[contains(text(),'Withholding')]";
        public static string tblWithHolding = "Xpath;//h2[contains(text(),'FATCA Withholding')]/parent::td/parent::tr/following-sibling::tr/td/table/tbody";
        private static string txtaddrLine1 = "Xpath;//*[@name='ACNADDR_AD1']";
        private static string txtaddrLine2 = "Xpath;//*[@name='ACNADDR_AD2']";
        private static string txtaddrCity = "Xpath;//*[@name='ACNADDR_CITY']";
        private static string txtaddrCountry = "Xpath;//*[@name='ACNADDR_CNTRY']";
        private static string txtaddrState = "Xpath;//*[@name='ACNADDR_STATE']";
        private static string txtaddrPincode = "Xpath;//*[@name='ACNADDR_MZIP']";
        private static string checkBoxEligibleAsCollateral = "XPath;//*[contains(text(),'Eligible as Collateral')]/following-sibling::*/input";
        private static string NegativeBalanceTransferAccount = "Xpath;//*[@name='LN_TRCID']";
        private static string MSGOBJ = "Xpath;//*[text()='The information has been updated.']";
        private static string FrontMoneyOption = "Xpath;//*[@name='LN_FMO']";
        private static string FrontMoneyAccount = "Xpath;//*[@name='LN_FMA']";
        private static string txtMailingAddressZipCode = "Xpath;//*[@name='ACNADDR_MZIP']";
        private static string dropdownMailingAddressCountry = "Xpath;//*[@name='ACNADDR_CNTRY']";
        private static string dropdownMailingAddressState = "Xpath;//*[@name='ACNADDR_STATE']";
        private static string msgInvalidPinCode = "Xpath;//*[contains(text(),'Invalid ZIP code 99999')]";
        private static string txtPaymentTerm = "Xpath;//*[@name='LN_PTRM']";
        private static string txtMaturityDate = "Xpath;//*[@name='LN_MDT']";
        private static string labelScheduledPaymentNextDate = "Xpath;//*[contains(text(),'Scheduled Payment Next Date')]/following-sibling::td";
        private static string contentTable="XPath;//table[@class='contentTable']/tbody";
        private static string dropDownProductType = "Xpath;//select[@name='ACN_TYPE']";
        private static string Message  = "Xpath;//div[@class='msg-box']/descendant::p";
        private static string txtInterestRateDetermination = "XPath;//input[@name='ACN_IRN']";

        public static string linkOverdraftProcessing="XPath;//td[contains(text(),'Overdraft Processing')]";
        public static string dropdownStatementGroup="XPath;//select[@name='statementGroup']";
        public static string buttonSubmit="XPath;//input[@name='submit']";

        public static string linkAccountActivity="XPath;//a[contains(text(),'Account Activity')]";
        public static string dropdownAccountStatus="XPath;//select[@name='ACN_STAT']";

        public static string dropdownLateChargePlan="XPath;//select[@name='LN_POPT']";
        public static string txtLateChargeGraceDays="XPath;//input[@name='LN_PMTGRC']";
        public static string txtFixedLateChargeAmount="XPath;Fixed Late Charge Amount";

        public static string txtLoanInterestRate="XPath;//input[@name='LN_IRN']";

        public static string tableAmountsDueperDelinquentPeriod="XPath;//table[@id='amounts-due-per-delinquent-period-list']/thead/tr[2]";

        public static string checkboxAcccountPurchased="XPath;//input[@name='LN_PPFLG']";
        public static string linkLoanAccountServices="XPath;//*[contains(text(),'Loan Account Services')]";
        public static string linkPurchasedImpairedLoan="XPath;//td[contains(text(),'Purchased Impaired Loan')]";
        
        public static string dropdownBrnachOfOwnership="XPath;//select[@name='ACN_BOO']";
        
        public virtual void select_interest_tab()
        {
            applicationHandle.ClickObjectViaJavaScript(Interest_Tab);
            //Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpRateDeterminationAccount);

        }

        public virtual void select_payment_tab()
        {
            applicationHandle.ClickObject(Payment_Tab);
           // Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpDisbursementOption);
        }
        public virtual void select_transaction_processing_tab()
        {
            
            applicationHandle.ClickObject(TransactionProcessing_Tab);
            applicationHandle.Wait_For_Specified_Time(3);
            Report.Info("Account Information | Transaction Processing tab selected.");
        }

        public virtual string get_ledger_balance_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(General_LedgerBalance_Field);
        }
        public virtual string get_available_balance_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(General_AvailableBalance_Field);
        }
        public virtual string get_computed_balance_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(General_ComputedBalance_Field);
        }
        public virtual string get_collected_balance_field_value()
        {
            applicationHandle.Wait_for_object(Cancel_Button, 5);
            return applicationHandle.GetObjectText(General_CollectedBalance_Field);
        }

        public virtual bool Validate_MaillingAddr()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtaddrLine1, 30))
            {
                // string str = Data.Get("GLOBAL_ADDRESS1IN")+"!!!!"+Data.Get("SJR-IPARK")+"!!!!"+Data.Get("GLOBAL_CITY")+"!!!!"+Data.Get("GLOBAL_CITY")+"!!!!"+Data.Get("GLOBAL_ADDCOUNTRY")+"!!!!"+Data.Get("GLOBAL_ADDSTATE")+"!!!!"+Data.Get("GLOBAL_POSTALCODEIN");
                // string str1 = applicationHandle.GetObjectText(txtaddrLine1)+"!!!"+applicationHandle.GetObjectText(txtaddrLine2)+"!!!!"+applicationHandle.GetObjectText(txtaddrCity)+"!!!!"+applicationHandle.GetDropdownSelectedValue(txtaddrCountry)+"!!!!"+applicationHandle.GetDropdownSelectedValue(txtaddrState)+"!!!!"+applicationHandle.GetObjectText(txtaddrPincode);
                if ((applicationHandle.GetSpecifiedObjectAttribute(txtaddrLine1, "value").Contains(Data.Get("GLOBAL_ADDRESS1IN")))
                && (applicationHandle.GetSpecifiedObjectAttribute(txtaddrLine2, "value").Contains(Data.Get("SJR-IPARK")))
                && (applicationHandle.GetSpecifiedObjectAttribute(txtaddrCity, "value").Contains(Data.Get("GLOBAL_CITY")))
                && (applicationHandle.GetDropdownSelectedValue(txtaddrCountry).Contains(Data.Get("GLOBAL_ADDCOUNTRY")))
                && (applicationHandle.GetDropdownSelectedValue(txtaddrState).Contains(Data.Get("GLOBAL_ADDSTATE")))
                && (applicationHandle.GetSpecifiedObjectAttribute(txtaddrPincode, "value").Contains(Data.Get("GLOBAL_POSTALCODEIN"))))
                {
                    result = true;
                }



            }
            return result;
        }
        public virtual bool SelectEligibleAsCollateralCheckbox()
        {
            bool Result = false;
            string runtimeCheckprop = applicationHandle.GetSpecifiedObjectAttribute(checkBoxEligibleAsCollateral, Data.Get("checked"));
            if (runtimeCheckprop.Equals("true"))
            { Result = true; }
            else
            {
                applicationHandle.ClickObjectViaJavaScript(checkBoxEligibleAsCollateral);
                Result = true;
            }
            if (Result)
            {
                applicationHandle.ScrollToObject(checkBoxEligibleAsCollateral);
                Report.Info("Eligible as Collateral is selected as YES .", "elligiblecheckboxcollateral", "true", applicationHandle);
            }
            return Result;

        }
        public virtual void ClickOnSubmitBUtton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Submit_Button))
            {
                applicationHandle.ClickObjectViaJavaScript(Submit_Button);
            }
        }
        public virtual void ClickOnMenuAndSubMenu(string MenuValue)
        {
            string[] arr = MenuValue.Split('|');
            string Menu = arr[0];
            string SubMenu = arr[1];
            string MenuXpath = "Xpath;//*[contains(text(),'" + Menu + "')]";
            string SubMenuXpath = "Xpath;//*[contains(text(),'" + SubMenu + "')]";
            bool Counter = true;
            if ((!string.IsNullOrEmpty(Menu)) && (!string.IsNullOrEmpty(SubMenu)))
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(MenuXpath);
                applicationHandle.ClickObjectViaJavaScript(MenuXpath);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubMenuXpath);
                applicationHandle.ClickObjectViaJavaScript(SubMenuXpath);
                Report.Pass("Navigated to selected Menu", "ClickOnMenuAndSubMenu", "true", applicationHandle);
                Counter = false;
            }
            else if ((string.IsNullOrEmpty(Menu)) && (!string.IsNullOrEmpty(SubMenu)))
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubMenuXpath);
                applicationHandle.ClickObjectViaJavaScript(SubMenuXpath);
                Report.Pass("Navigated to selected Menu", "ClickOnMenuAndSubMenu", "true", applicationHandle);
            }
            else if (Counter)
            {
                Report.Fail("Failed to Navigate to selected Menu", "ClickOnMenuAndSubMenu", "true", applicationHandle, true);
            }
        }

        public virtual void NegativeBalanceTransfer(string AccountNumber)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(NegativeBalanceTransferAccount);
            applicationHandle.Set_field_value(NegativeBalanceTransferAccount, AccountNumber);
        }

        public virtual void ClickSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(Submit_Button);
            applicationHandle.ClickObject(Submit_Button);
        }

        public virtual bool VerifyInformationUpdated()
        {
            bool Result = false;
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (applicationHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void ValidatePostalAddressMessage()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtMailingAddressZipCode))
            {
                applicationHandle.ClearEditValue(txtMailingAddressZipCode);
                applicationHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMailingAddressCountry, Data.Get("GLOBAL_IDENTIFICATION_PASSPORT_DETAILS_COUNTRY"));
                applicationHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMailingAddressState, Data.Get("AcctMailingAddressState"));
                applicationHandle.Set_field_value(txtMailingAddressZipCode, Data.Get("GLOBAL_Invalid_POSTALCODEIN"));
                this.ClickSubmitButton();
                string ZipCodeValidationmessage = applicationHandle.Get_Label_Text(msgInvalidPinCode);
                if (ZipCodeValidationmessage.Contains(Data.Get("InvalidZipCodeMessage")))
                {
                    Report.Pass("Invalid Zip Code validated Successfully", "ValidatePostalAddressMessage", "true", applicationHandle);
                }
                else
                {
                    Report.Fail("Not able to validate Invalid Zip Code", "ValidatePostalAddressMessage", "true", applicationHandle, true);
                }
            }
        }

        public virtual void SubTabLink(string LinkToBeSelected)
        {
            string SubMenuXpath = "Xpath;//*[text()='" + LinkToBeSelected + "']";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubMenuXpath))
            {
                applicationHandle.ClickObject(SubMenuXpath);
            }
        }

        public virtual void UpdateLoanFrontMoneyAccountNumber(string AccountNumber)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(FrontMoneyOption))
            {
                applicationHandle.SelectDropdownValueByIndex(FrontMoneyOption, 3);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(FrontMoneyAccount))
            {
                applicationHandle.Set_field_value(FrontMoneyAccount, AccountNumber);
            }
            this.ClickSubmitButton();
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                this.VerifyInformationUpdated();
                Report.Pass("Front Money option and Account added in Commitment Processing Page", "UpdateLoanFrontMoneyAccountNumber", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Front Money option and Account not added in Commitment Processing Page", "UpdateLoanFrontMoneyAccountNumber", "true", applicationHandle, true);
            }
        }
        public virtual void ClickCancelButton()
        {
            applicationHandle.ClickObject(Cancel_Button);
        }

        public virtual void InterestUpdate()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtInterestRate))
            {
                applicationHandle.ClearEditValue(txtInterestRate);
                applicationHandle.Set_field_value(txtInterestRate, Data.Get("InterestRate"));
                this.ClickSubmitButton();
                if(this.VerifyInformationUpdated())
                {
                    Report.Pass("Interest Rate updated Successfully", "InterestUpdate", "true", applicationHandle);
                }
                else
                {
                    Report.Fail("Not able to update Interest Rate", "InterestUpdate", "true", applicationHandle, true);
                }
            }
        }

        public virtual void AddMaturityDetails()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPaymentTerm))
            {
                applicationHandle.Set_field_value(txtPaymentTerm, Data.Get("1Y"));
                this.ClickSubmitButton();
                if(this.VerifyInformationUpdated())
                {
                    Report.Pass("Payment Term in Maturity updated Successfully", "AddMaturityDetails", "true", applicationHandle);
                }
                else
                {
                    Report.Fail("Not able to update Payment Term", "AddMaturityDetails", "true", applicationHandle, true);
                }
            }

        }

        public virtual bool ValidateScheduledPaymentNextDate(string ApplicationDate)
        {
            bool DateComparision = true;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(labelScheduledPaymentNextDate))
            {
                string ScheduledPaymentNextDate = applicationHandle.Get_Label_Text(labelScheduledPaymentNextDate);
            }
            string NewDate = applicationHandle.CalculateNewDate(ApplicationDate,"D",1);
            if(applicationHandle.CompareValue(ApplicationDate, NewDate))
            {
                DateComparision = false;
            }
            return DateComparision;
        }
public virtual bool AccountBalancesAccountInformation(string LabelNameLabelValuePipeDelimited)
{
return Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(contentTable,LabelNameLabelValuePipeDelimited);
}

 public virtual void EnterInterestRates(string InterestRate = "", string AnnualDIsClosureRate = "", string EffectiveDisclosureRate = "")
        {
            if (!string.IsNullOrEmpty(InterestRate))
            {
                applicationHandle.Set_field_value(txtInterestRate, InterestRate);
            }
            if (!string.IsNullOrEmpty(AnnualDIsClosureRate))
            {
                applicationHandle.Set_field_value(txtInterestRatesAnnualDisclosureRate, AnnualDIsClosureRate);
            }
            if (!string.IsNullOrEmpty(EffectiveDisclosureRate))
            {
                applicationHandle.Set_field_value(txtEffectiveDisclosureRate, EffectiveDisclosureRate);
            }
        }
        public virtual void EditGeneralAccountInformation(string ProductType)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropDownProductType))
            {
                applicationHandle.SelectDropdownSpecifiedValue(dropDownProductType, ProductType + " - " + ProductType);
            }

        }
         public virtual bool ValidateValidationMessage(string ValidationMessage)
        {
            bool flag = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(Message))
            {
                if(applicationHandle.GetObjectText(Message).Contains(ValidationMessage))
                {
                    flag = true;
                }
            }
            return flag;
        }

        public virtual void InterestUpdate(string InterestRate)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtInterestRate))
            {
                applicationHandle.ClearEditValue(txtInterestRate);
                applicationHandle.Set_field_value(txtInterestRate, InterestRate);
                this.ClickSubmitButton();
                if (this.VerifyInformationUpdated())
                {
                    Report.Pass("Interest Rate updated Successfully", "InterestUpdate", "true", applicationHandle);
                }
                else
                {
                    Report.Fail("Not able to update Interest Rate", "InterestUpdate", "true", applicationHandle, true);
                }
            }
        }

        public virtual void UpdateInterestRates(string InterestRate)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtLoanInterestRate))
            {
                applicationHandle.ClearEditValue(txtLoanInterestRate);
                applicationHandle.Set_field_value(txtLoanInterestRate, InterestRate);
                this.ClickSubmitButton();
                if (this.VerifyInformationUpdated())
                {
                    Report.Pass("Interest Rate updated Successfully", "InterestUpdate", "true", applicationHandle);
                }
                else
                {
                    Report.Fail("Not able to update Interest Rate", "InterestUpdate", "true", applicationHandle, true);
                }
            }
        }

      
        public virtual void SelectTabInAccountInformation(string tabname)
        {
            string dynobj="XPath;//table[@class='tab']//td[text()='"+tabname+"']";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynobj);
            applicationHandle.ClickObjectViaJavaScript(dynobj);

        }

        public virtual void SelectSubLinkOfTransactionProcessing(string linkname)
        {
            string dynobj="XPath;//a[contains(text(),'"+linkname+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynobj);
            applicationHandle.ClickObjectViaJavaScript(dynobj);


        }

        public virtual bool UpdateStatementGroupVal(string statementgroupval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownStatementGroup);
            applicationHandle.SelectDropdownSpecifiedValue(dropdownStatementGroup,statementgroupval);
            applicationHandle.ClickObjectViaJavaScript(buttonSubmit);
            return applicationHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
               
        
        }

        public virtual bool CheckValueInAccountStatusdropdown(string valuetobechecked)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkAccountActivity);
            applicationHandle.ClickObjectViaJavaScript(linkAccountActivity);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccountStatus);
            bool retval=applicationHandle.CheckValueInDropdown(dropdownAccountStatus,valuetobechecked);
            applicationHandle.SelectDropdownSpecifiedValue(dropdownAccountStatus,"4 - Closed");
            applicationHandle.ClickObjectViaJavaScript(buttonSubmit);
            return applicationHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        
        }

        public virtual bool UpdateValuesOfInDeleinquencyOption(string latechargemethod,string latechargegracedays,string fixedlatechargeamt)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownLateChargePlan);
            applicationHandle.SelectDropdownSpecifiedValue(dropdownLateChargePlan,latechargemethod);
            applicationHandle.Set_field_value(txtLateChargeGraceDays,latechargegracedays);
            applicationHandle.Set_field_value(txtFixedLateChargeAmount,fixedlatechargeamt);
            applicationHandle.ClickObjectViaJavaScript(buttonSubmit);
            bool retval=applicationHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
            return retval;

        }


        public virtual bool CheckTableColumNameForAmountsDueperDelinquentPeriod(string lifecolumnval)
        {
            
            string dyntblobj="XPath;//table[@id='amounts-due-per-delinquent-period-list']/tbody";
            bool resflg=false;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dyntblobj);
            
            string dayspastdue=applicationHandle.GetObjectText(tableAmountsDueperDelinquentPeriod+"/th[1]");
            string life=applicationHandle.GetObjectText(tableAmountsDueperDelinquentPeriod+"/th[9]");
            string principal=applicationHandle.GetObjectText(tableAmountsDueperDelinquentPeriod+"/th[2]");
            string interest=applicationHandle.GetObjectText(tableAmountsDueperDelinquentPeriod+"/th[3]");

            if(dayspastdue.Equals("Days Past Due") && life.Equals("Life") && principal.Equals("Principal") && interest.Equals("Interest"))
            {
                resflg=true;
            }
            else
            {
                resflg=false;
            }

            if(applicationHandle.GetTableCellValue(dyntblobj,1,1).Equals("15"))
            {
                resflg=true;
            }
            else
            {
                resflg=false;
            }

            if(applicationHandle.GetTableCellValue(dyntblobj,1,9).Equals(lifecolumnval))
            {
                resflg=true;
            }
            else
            {
                resflg=false;
            }


            

            return resflg;
        
        
        }


        public virtual string GetCellValueByLable(string lablename)
        {
            string dynobj="XPath;//td[contains(text(),'"+lablename+"')]/following-sibling::td";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynobj);
            return applicationHandle.GetObjectText(dynobj).Trim();
        }

        public virtual bool CheckSuccessMessage()
        {
            return applicationHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }

        public virtual bool SelectCheckboxAccountPurchasedInGeneralTab()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxAcccountPurchased);
            if(!applicationHandle.CheckCheckBoxChecked(checkboxAcccountPurchased))
            {
                applicationHandle.ClickObjectViaJavaScript(checkboxAcccountPurchased);
            }

            applicationHandle.ClickObjectViaJavaScript(buttonSubmit);
            return applicationHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }

        public virtual void NavigateToPurchasedImpairedLaon()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkLoanAccountServices);
            if(applicationHandle.IsObjectExists(linkPurchasedImpairedLoan))
            {
                applicationHandle.ClickObjectViaJavaScript(linkPurchasedImpairedLoan);
            }
            else
            {
                applicationHandle.ClickObjectViaJavaScript(linkLoanAccountServices);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkPurchasedImpairedLoan);
                applicationHandle.ClickObjectViaJavaScript(linkPurchasedImpairedLoan);
            }

        }

        public virtual string SelectValueFromBranchOfOwnerShipInGenralTab(int index)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownBrnachOfOwnership);
            applicationHandle.SelectDropdownSpecifiedValueByIndex(dropdownBrnachOfOwnership,index);
            applicationHandle.ClickObjectViaJavaScript(buttonSubmit);
            return applicationHandle.GetDropdownSelectedValue(dropdownBrnachOfOwnership);
        }


       
    }
}