using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;
using System.Threading;
using Profile7Automation.Libraries.Helper;
using System;
using System.Linq;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanCorrectionsPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string dropdownAccountNumber = "Xpath;//select[@name='ACN_CID']";
        private static string TableContent = "XPath;//table[@class='contentTable']/tbody";
        private static string btnSubmit = "Xpath;//input[@name='submit']";
        private static string errormsg = "Xpath;//div[@id='core-error-box']/div/p";
        
        public virtual void SelectAccountFromDropdown(string accountnumber)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccountNumber))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccountNumber,accountnumber);
            }
        }
        public virtual bool SelectLoanCorrectionProcess(string CorrectionProcessbyDelimiter)
        {
            int counter = 0;
            bool flag = false;
            string tempText = "";
            string CorrectionTable = "Xpath;//table[@cellspacing='2']/tbody";
            int rowsCount = appHandle.GetRowCountfromList(CorrectionTable);
            var stringList = CorrectionProcessbyDelimiter.Split('|').ToList();
            foreach (var item in stringList)
            {
                string LoanCorrectionOption = item.ToString();
                for (int i = 1; i <= rowsCount; i++)
                {
                    tempText = appHandle.GetObjectText(CorrectionTable + "/tr[" + i + "]");
                    if (tempText.Contains(LoanCorrectionOption))
                    {
                        appHandle.ClickObjectViaJavaScript(CorrectionTable + "/tr[" + i + "]/descendant::input[1]");
                        this.ClickSubmitButton();
                        counter = counter+1;
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            if(stringList.Count() == counter)
            {
                flag = true;
            }
            else
            {
                flag = false;
            }
            return flag;
        }

        public virtual void ClickSubmitButton()
        {
            appHandle.ClickObject(btnSubmit);
            this.ValidateErrorMessage();
        }

        public virtual void ValidateErrorMessage()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(errormsg))
            {
                string ErrorMessage = appHandle.Get_Label_Text(errormsg);
                if ((ErrorMessage.Contains(Data.Get("ErrorMessage1"))) || (ErrorMessage.Contains(Data.Get("ErrorMessage2"))) || (ErrorMessage.Contains(Data.Get("ErrorMessage3"))))
                {
                    Report.Pass("Error message's validated successfully", "ValidateErrorMessage", "true", appHandle);
                }
                else
                {
                    Report.Fail("Not able to validate error message's", "ValidateErrorMessage", "true", appHandle, true);
                }
            }
        }
    }
}