using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class DelinquencyPaymentPerformancePage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string tableContent = "XPath;//table[@class='contentTable']/tbody";

        private static string dropdownAccount = "XPath;//select[@name='ACN_CID']";

        public virtual bool WaitDelinquencyPaymentPerformancePageLoads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccount))
            {
                result = true;
            }
            return result;
        }
    }
}