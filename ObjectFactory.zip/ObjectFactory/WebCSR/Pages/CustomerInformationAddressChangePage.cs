using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CustomerInformationAddressChangePage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string HomeAddressAddress1_Field = "Xpath;//input[@name='CIF_PAD1']";
        public static string HomeAddressAddress2_Field = "Xpath;//input[@name='CIF_PAD2']";
        public static string HomeAddressAddress3_Field = "Xpath;//input[@name='CIF_PAD3']";
        public static string HomeAddressAddressCounty_Field = "Xpath;//input[@name='CIF_PCOUNTY']";
        public static string HomeAddressAddressTownship_Field = "Xpath;//input[@name='CIF_PLOC']";
        public static string HomeAddressCity_Field = "Xpath;//input[@name='CIF_PCITY']";
        public static string HomeAddressZipCode_Field = "Xpath;//input[@name='CIF_PZIP']";
        public static string HomeAddressCountry_Dropdown = "Xpath;//select[@name='CIF_PCNTRY']";
        public static string HomeAddressState_Dropdown = "Xpath;//select[@name='CIF_PSTATE']";
        public static string MailingAddressAddress1_Field = "Xpath;//input[@name='CIF_MAD1']";
        public static string MailingAddressAddress2_Field = "Xpath;//input[@name='CIF_MAD2']";
        public static string MailingAddressAddress3_Field = "Xpath;//input[@name='CIF_MAD3']";
        public static string MailingAddressAddressTownship_Field = "Xpath;//input[@name='CIF_MLOC']";
        public static string MailingAddressCity_Field = "Xpath;//input[@name='CIF_MCITY']";
        public static string MailingAddressCounty_Field = "Xpath;//input[@name='CIF_MCOUNTY']";
        public static string MailingAddressCountry_Dropdown = "Xpath;//select[@name='CIF_MCNTRY']";
        public static string MailingAddressState_Dropdown = "Xpath;//select[@name='CIF_MSTATE']";
        public static string MailingAddressZipCode_Field = "Xpath;//input[@name='CIF_MZIP']";
        public static string PreviousAddressAddress1_Field = "Xpath;//input[@name='CIF_PRAD1']";
        public static string PreviousAddressAddress2_Field = "Xpath;//input[@name='CIF_PRAD2']";
        public static string PreviousAddressAddress3_Field = "Xpath;//input[@name='CIF_PRAD3']";
        public static string PreviousAddressTownship_Field = "Xpath;//input[@name='CIF_PRLOC']";
        public static string PreviousAddressCounty_Field = "Xpath;//input[@name='CIF_PRCOUNTY']";
        public static string PreviousAddressZipCode_Field = "Xpath;//input[@name='CIF_PRZIP']";
        public static string PreviousAddressCity_Field = "Xpath;//input[@name='CIF_PRCITY']";
        public static string PreviousAddressCountry_Dropdown = "Xpath;//select[@name='CIF_PRCNTRY']";
        public static string PreviousAddressState_Dropdown = "Xpath;//select[@name='CIF_PRSTATE']";
        public static string EffectiveDatesFutureDate_Field = "Xpath;//input[@name='effectiveDate']";
        public static string EffectiveDatesExpirationDate_Field = "Xpath;//input[@name='expirationDate']";
        public static string AddressChangeAccounts_Table = "Xpath;//td[@id='content']//tr[13]";
        public static string AddressChangeHomeAddress_Table = "Xpath;//body[@class='main']//tr//tr//tr//tr[2]//td[1]//table[1]";
        public static string SelectDeselectAllLink = "Xpath;//a[contains(text(),'Select/Deselect All')]";
        public static string Sameashomeaddress_No_Radio_button = "Xapth;//input[@name ='mailAddressSameAsMain'][@value='N']";
        public static string Doesthisaddressbelongtosomeoneelse_No_Radio_button = "Xapth;//input[@name='CIF_MAILADDRNOTCUSTOMERS'][@value='false']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";

        public static string submit_button = "Xpath;//input[@name='submit']";
        public static string cancel_button = "Xpath;//input[@name='cancel']";

        public virtual void UpdateHomeAddressZipCode(string ZipCode)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(HomeAddressZipCode_Field);
            appHandle.Set_field_value(HomeAddressZipCode_Field, ZipCode);
        }

        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(submit_button))
            {
                appHandle.ClickObjectViaJavaScript(submit_button);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(submit_button);
        }

        public virtual bool ValidateAddressInfoUpdateMSG()
        {
            bool result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("The address information has been updated.")))
            {
                result = true;
            }

            return result;
        }
        public virtual bool ValidateInvaildZipCodeUpdateMSG(string Msg)
        {
            bool result = false;
            if (appHandle.GetObjectText(MSGOBJ).Equals(Msg))
            {
                result = true;
            }

            return result;
        }

        public virtual void UpdateMailingAddressInAddress()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MailingAddressAddress1_Field);
            appHandle.Set_radiobutton(Sameashomeaddress_No_Radio_button);
            appHandle.Set_radiobutton(Doesthisaddressbelongtosomeoneelse_No_Radio_button);
            appHandle.Set_field_value(MailingAddressAddress1_Field,Data.Get("GLOBAL_FIS"));
            appHandle.Set_field_value(MailingAddressAddress2_Field,Data.Get("SeaLine2"));
            appHandle.Set_field_value(MailingAddressCity_Field,Data.Get("FPO"));
            appHandle.SelectDropdownSpecifiedValueByPartialText(MailingAddressCountry_Dropdown,(string)Data.Get("US - UNITED STATES OF AMERICA"));
            appHandle.SelectDropdownSpecifiedValueByPartialText(MailingAddressState_Dropdown,(string)Data.Get("CT - CONNECTICUT"));
            appHandle.Set_field_value(MailingAddressZipCode_Field,Data.Get("VaildZIPCT"));



        }
        public virtual void UpdatePreviousAddressInAddressPage(string ZipCode)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(PreviousAddressAddress1_Field);
            appHandle.Set_field_value(PreviousAddressAddress1_Field,Data.Get("GLOBAL_FIS"));
            appHandle.Set_field_value(PreviousAddressAddress2_Field,Data.Get("SeaLine2"));
            appHandle.Set_field_value(PreviousAddressCity_Field,Data.Get("Arakans"));
            appHandle.SelectDropdownSpecifiedValueByPartialText(PreviousAddressCountry_Dropdown,(string)Data.Get("US - UNITED STATES OF AMERICA"));
            appHandle.SelectDropdownSpecifiedValueByPartialText(PreviousAddressState_Dropdown,(string)Data.Get("AE - Armed Forces Europe"));
            appHandle.Set_field_value(PreviousAddressZipCode_Field,ZipCode);



        }



    }

}