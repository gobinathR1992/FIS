using System.Threading;
using System;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

 
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page] 
    public class AdjustablePaymentCalculationPage
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public static string txtChangeFrequency="XPath;//input[@name='LN_PCFRE']";

        public virtual bool EnterValueForChangeFrequency(string changefreqval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtChangeFrequency);
            appHandle.Set_field_value(txtChangeFrequency,changefreqval);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }


    }
}