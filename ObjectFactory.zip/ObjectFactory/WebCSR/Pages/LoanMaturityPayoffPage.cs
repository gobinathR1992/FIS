using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages

{
    public class LoanMaturityPayoffPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtMaturityPaymentTerm = "XPath;//input[@name='LN_PTRM']";
        public static string txtMaturityDate = "Xpath;//td[@class='data']//input[@name='LN_MDT']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        private static string txtSmallBalanceDebitThreshold = "Xpath;//input[@name='LN_DBT']";
        private static string chkboxItemAmortizationSBTEFDPeriod = "Xpath;//input[@name='LN_SBTNOAMO']";
        private static string chkboxSuspendIntAccrSBTEFD = "Xpath;//input[@name='LN_SBTNOACR']";
        private static string txtSmallBalanceCreditThreshold = "Xpath;//input[@name='LN_CBT']";

        public virtual void EnterPayTerm(string PayTerm)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtMaturityPaymentTerm))
            {
                appHandle.Set_field_value(txtMaturityPaymentTerm, PayTerm);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMessageInLoanMaturityPayoffPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual void EnterDebitThreshold(string Amount = "", string Term = "")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSmallBalanceDebitThreshold))
            {
                // appHandle.Set_field_value(txtSmallBalanceDebitThreshold, Amount);
                // appHandle.ClickObjectViaJavaScript(chkboxSuspendIntAccrSBTEFD);
                // appHandle.ClickObjectViaJavaScript(chkboxItemAmortizationSBTEFDPeriod);
                if (!string.IsNullOrEmpty(Amount))
                {
                    appHandle.Set_field_value(txtSmallBalanceDebitThreshold, Amount);
                }
                if (!string.IsNullOrEmpty(Term))
                {
                    appHandle.Set_field_value(txtMaturityPaymentTerm, Term);
                }
            }

        }
        public virtual void EnterCreditThreshold(string SmallBalanceCreditThreshold)
        {
            if (!string.IsNullOrEmpty(SmallBalanceCreditThreshold))
            {
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtSmallBalanceCreditThreshold))
                {
                    appHandle.Set_field_value(txtSmallBalanceCreditThreshold, SmallBalanceCreditThreshold);
                    // appHandle.ClickObjectViaJavaScript(chkboxSuspendIntAccrSBTEFD);
                    // appHandle.ClickObjectViaJavaScript(chkboxItemAmortizationSBTEFDPeriod);
                    // appHandle.ClickObjectViaJavaScript(chkboxIncludePayoffDateFlagCheckbox);
                }
            }
        }

    }

}