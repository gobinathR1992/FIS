﻿using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountOverviewPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string accountOverviewTab = "Xpath;//td[@class='summaryTableHeading'][contains(text(),'Account History')]";
        private static string accountSummaryTab = "Xpath;//td[@class='summaryTableHeading'][contains(text(),'Account Summary')]";
        private static string AccountHistoryTab = "Xpath;//td[@class='summaryTableHeading'][contains(text(),'Account History')]";
        private static string Account_Dropdown = "Xpath;//select[@name='ACN_CID']";
        private static string Submit_Button = "Xpath;//input[@value='Submit']";
        private static string Cancel_Button = "Xpath;//input[@value='Cancel']";
        private static string tabTransactionAccountInformation = "XPath;//table[contains(@class,'tab')]/descendant::td[text()='Transaction Processing']";
        private static string linkAggregateAvailableBalance = "XPath;//*[contains(text(),'Aggregate Available Balance')]/following-sibling::*/a";
        private static string tableContent = "XPath;//table[@class='contentTable']/tbody";
        private static string linkBalalncesDialogClose = "XPath;//*[text()='Account Available Balance Calculation']/ancestor::table/ancestor::div[1]/preceding-sibling::div/descendant::a";
        private static string tableBalancesContentTable = "Xpath;//*[text()='Account Available Balance Calculation']/ancestor::table/tbody";
        public static string linkCustomerServices = "XPath;//td[contains(text(),'Customer Services')]";
        public static string linkStatementGroups = "XPath;//td[contains(text(),'Statement Groups')]";
        public static string linkFundingServices = "XPath;//td[contains(text(),'Funding Services')]";
        public static string linkExternalAccounts = "XPath;//td[contains(text(),'External Accounts')]";
        private static string drpdownPrincipalMaturityOption = "Xpath;//select[@name='DEP_RENCD']";
        private static string drpdownExternalPrincipalTransferAccount = "Xpath;//select[@name='DEP_PRIMATETS']";
        private static string drpdownInterestMaturityOption = "Xpath;//select[@name='DEP_IMO']";
        private static string drpdownExternalInterestTransferAccount = "Xpath;//select[@name='DEP_INTMATETS']";
        private static string btnSubmit = "Xpath;//input[@name='submit']";
        private static string MSGOBJ = "Xpath;//*[text()='The information has been updated.']";
        private static string tableobject = "XPath;//*[@class='contentTable']/tbody/descendant::tbody";
        private static string PermanentHolds = "XPath;//*[contains(text(),'Permanent Holds')]/following-sibling::*/descendant::*[1]";
        private static string AccountAvailableBal = "XPath;//*[contains(text(),'Account Available Balance:')]/following-sibling::*[1]";




        static GTS_OSAF.CoreLibs.WebApplication applicationHandle;



        public static string linkCustomerServicesnew = "XPath;//*[contains(text(),'Customer Services')]";
        public static string linkServiceManagment = "XPath;//td[contains(text(),'Service Management')]";



        public virtual void select_account_summary_tab()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(accountSummaryTab))
            {
                appHandle.ClickObjectViaJavaScript(accountSummaryTab);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(tabTransactionAccountInformation);
            }
        }
        public virtual void select_account_history_tab()
        {
            appHandle.ClickObject(AccountHistoryTab);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(Submit_Button);
            Report.Info("Account History selected.");
        }
        public virtual void ClickOnAggregateAvailableBalance()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkAggregateAvailableBalance))
            {
                appHandle.ClickObjectViaJavaScript(linkAggregateAvailableBalance);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkBalalncesDialogClose);
            }
        }
        public virtual bool VerifyDatainBalancesTable(string labelnamepipelabelvalue)
        {
            bool result = false;

            if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableBalancesContentTable, labelnamepipelabelvalue))
            {
                result = true;
            }
            return result;
        }
        public virtual void CloseBalancesDialogBox()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkBalalncesDialogClose))
            {
                appHandle.ClickObjectViaJavaScript(linkBalalncesDialogClose);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkAggregateAvailableBalance);
            }
        }
        public virtual void SelectAccountSummaryTab()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(accountSummaryTab))
            {
                appHandle.ClickObjectViaJavaScript(accountSummaryTab);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(tabTransactionAccountInformation);
            }
        }
        public virtual void ClickOnExternalAccountsLink()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkFundingServices);
            appHandle.ClickObjectViaJavaScript(linkFundingServices);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkExternalAccounts);
            appHandle.ClickObjectViaJavaScript(linkExternalAccounts);
        }

        public virtual void UpdateTermAccountsMaturityDetails(string PrincipalMaturityOption, string ExternalPrincipalTransferAccount, string InterestMaturityOption, string ExternalInterestTransferAccount)
        {
            string value = "FISCAL CREDIT UNION - accountvalue - DDA";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpdownPrincipalMaturityOption);
            appHandle.SelectDropdownSpecifiedValue(drpdownPrincipalMaturityOption, PrincipalMaturityOption);
            appHandle.SelectDropdownSpecifiedValue(drpdownExternalPrincipalTransferAccount, value.Replace("accountvalue", ExternalPrincipalTransferAccount));
            appHandle.SelectDropdownSpecifiedValue(drpdownInterestMaturityOption, InterestMaturityOption);
            appHandle.SelectDropdownSpecifiedValue(drpdownExternalInterestTransferAccount, value.Replace("accountvalue", ExternalInterestTransferAccount));
        }

        public virtual void ClickOnSubmit()
        {
            appHandle.ClickObjectViaJavaScript(btnSubmit);
        }

        public virtual bool VerifySuccessMessage()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if ((appHandle.GetObjectText(MSGOBJ)).Equals(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Result = true;
                }
            }
            return Result;
        }

        public virtual void ClickOnStatementGroupLink()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkCustomerServices);
            appHandle.ClickObjectViaJavaScript(linkCustomerServices);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkStatementGroups);
            Report.Info("The link statment group exists", "rtu", "True", appHandle);
            appHandle.ClickObjectViaJavaScript(linkStatementGroups);


        }



        public virtual void ClickOnCustomerServicesServiceManagmentLink()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkCustomerServicesnew);
            appHandle.ClickObjectViaJavaScript(linkCustomerServicesnew);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkServiceManagment);
            appHandle.ClickObjectViaJavaScript(linkServiceManagment);

        }
        public virtual bool CheckAccountNumberInAccountOverviewPage(string AccountNumber)
        {
            bool result = false;
            result = Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableobject, "Account Number" + "|" + AccountNumber);
            return result;
        }
        public virtual string GetAvailableBal(string AccountNumber)
        {
            string val = "";

            if (CheckAccountNumberInAccountOverviewPage(AccountNumber))
            {
                val = appHandle.GetObjectText(AccountAvailableBal);
            }
            return val;
        }
        public virtual string GetHoldAmt(string AccountNumber)
        {
            string val = "";
            if (CheckAccountNumberInAccountOverviewPage(AccountNumber))
            {
                val = appHandle.GetObjectText(PermanentHolds);
            }
            return val;
        }
        public virtual bool CheckHoldAmtMoreThanAvailableBalAmount(string AccountNumber)
        {
            bool result = false;
            string avblamt = appHandle.GetObjectText(AccountAvailableBal);
            string permanentholdamt = appHandle.GetObjectText(PermanentHolds);
            if (Convert.ToDouble(permanentholdamt) > Convert.ToDouble(avblamt))
            {
                result = true;
            }
            return result;
        }



    }
}