using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using System;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class BeneficialOwnersInformationProviderPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtFirstName = "Xpath;//input[@name='beneficialOwner.informationProviderFirstName']";
        public static string txtLastName = "Xpath;//input[@name='beneficialOwner.informationProviderLastName']";
        public static string txtTitle = "Xpath;//input[@name='beneficialOwner.informationProviderTitle']";

        public virtual void EnterBasicDetails()
        {
            try
            {
              string[] BasicDetails = Data.Get("GLOBAL_BENEFICIARY_1");
              appHandle.Set_field_value(txtFirstName,BasicDetails[0]);
              appHandle.Set_field_value(txtLastName,BasicDetails[1]);
              appHandle.Set_field_value(txtTitle,"CEO");
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

    }
}