using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountNotesPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        
        public static string dropdownAccount="XPath;//select[@name='NOTES_CID']";

        public static string buttonAdd="XPath;//input[@name='add']";
        public static string buttonEdit="XPath;//input[@name='edit']";
        public static string buttonDelete="XPath;//input[@name='delete']";
        public static string txtDescription="XPath;//input[@name='NOTES_DESC']";
        public static string txtExpirationDate="XPath;//input[@name='NOTES_EXP']";
        public static string txtNotes="XPath;//textarea[@name='NOTES_NOTES']";

        public static string buttonSubmit="XPath;//input[@name='submit']";

        public virtual void SelectAccount(string accountno)
        {
            string accno="COMMACCNUM - "+accountno+" - USD";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccount);
            appHandle.SelectDropdownSpecifiedValue(dropdownAccount,accno);
        }

        public virtual void ClickOnAddButton()
        {
             Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
             appHandle.ClickObjectViaJavaScript(buttonAdd);
        }

        public virtual bool EnterDetailsOfNotes(string description,string expdate,string notes)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.Set_field_value(txtDescription,description);
            appHandle.Set_field_value(txtExpirationDate,expdate);
            appHandle.Set_field_value(txtNotes,notes);
            Report.Info("Notes details are entered successfully","notesinfo","True",appHandle);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            bool retop=appHandle.CheckSuccessMessage(Data.Get("NotesSuccessMsg"));
            return retop;

        }


        
    }
}