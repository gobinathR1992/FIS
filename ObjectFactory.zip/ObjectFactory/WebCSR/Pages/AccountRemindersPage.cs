using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AccountRemindersPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtAccountReminderDescription = "Xpath;//textarea[@name='TIKLACN_FT']";
        public static string txtAccountReminderFrequency="Xpath;//input[@name='TIKLACN_ARF']";
        public static string txtAccountReminderNextOccurrence="Xpath;//input[@name='TIKLACN_ARND']";
        public static string txtAccountReminderExpirationDate="Xpath;//input[@name='TIKLACN_EXPD']";
        public static string drpAccountReminderAccount="Xpath;//select[@name='TIKLACN_CID']";
        public static string drpAccountReminderReason="Xpath;//select[@name='TIKLACN_RRC']";
        public static string GeneralAccountServicesAccountRemindersLink="Xpath;//tr[@id='s4']//td//table//tbody//tr//td[@class='menuSub'][contains(text(),'Reminders')]";
        public static string GeneralAccServicesLink="Xpath;//td[contains(text(),'General Account Services')]";
        public static string btnAdd="Xpath;//input[@name='add']";


        public virtual void SelectAccountRemindersLink()
        {
            appHandle.WaitUntilElementVisible(GeneralAccServicesLink);
            appHandle.WaitUntilElementClickable(GeneralAccServicesLink);
            appHandle.Select_link(GeneralAccServicesLink);
            appHandle.Wait_For_Specified_Time(5);
            appHandle.WaitUntilElementVisible(GeneralAccountServicesAccountRemindersLink);
            appHandle.WaitUntilElementClickable(GeneralAccountServicesAccountRemindersLink);
            appHandle.Select_link(GeneralAccountServicesAccountRemindersLink);
             
        }
    

        public virtual void select_account_in_AccountRemaninders(string accName, string accNumber) 
        {         
             appHandle.SelectDropdownSpecifiedValue(drpAccountReminderAccount, accName+"-"+accNumber); 
     
        }

        public virtual void clicktheADDButtoninAccountReminderspage()
        {
           appHandle.SelectButton(btnAdd);
        }

        public virtual void set_frequency_field_value(string sFrequency)
        {
            appHandle.Set_field_value(txtAccountReminderFrequency, sFrequency);
        }
        public virtual void set_NextOccurrence_field_value(string sNextOccurrence)
        {
            appHandle.Set_field_value(txtAccountReminderNextOccurrence, sNextOccurrence);
        }
        public virtual void select_Reason_dropdown_value(string sReason)
        {
            appHandle.SelectDropdownSpecifiedValue(drpAccountReminderReason, sReason);
        }
         public virtual void set_Description_field_value(string sDescription)
        {
            appHandle.Set_field_value(txtAccountReminderDescription, sDescription);
        }
        

    }

}
