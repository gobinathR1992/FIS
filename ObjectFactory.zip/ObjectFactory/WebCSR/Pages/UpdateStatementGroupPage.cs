using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class UpdateStatementGroupPage
    {
        WebApplication appHandle;
        public static string txtNextDate = "Xpath;//input[@name='CMBGRP_SNDT']";
        public static string txtStatementFrequency = "Xpath;//input[@name='CMBGRP_SFRE']";
        public static string btnSubmit = "Xpath;//input[@type='submit'][@value='Submit']";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To Click on Submit button in UpdateStatementGroupPage.
        /// <param></param> 
        /// <returns></returns>
        /// <example>ClickOnEditStatementGroupSubmitButton()</example>
        public void ClickOnEditStatementGroupSubmitButton()
        {
            try
            {
                AppHandle.WaitUntilElementVisible(btnSubmit);
                AppHandle.WaitUntilElementClickable(btnSubmit);
                AppHandle.SelectButton(btnSubmit);
                AppHandle.WaitUntilElementVisible(StatementGroupPage.btnStatementAdd);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To enter value in Frequency Feild in UpdateStatementGroupPage.
        /// <param name = "Frequency Value"></param> 
        /// <returns></returns>
        /// <example>SetFrequencyInEditStatementGroup(Freq)</example>
        public void SetFrequencyInEditStatementGroup(string Freq)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(txtStatementFrequency);
                AppHandle.WaitUntilElementClickable(txtStatementFrequency);
                AppHandle.Set_field_value(txtStatementFrequency, Freq);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To enter value in Next Date Feild in UpdateStatementGroupPage.
        /// <param name = "NxtDate Value"></param> 
        /// <returns></returns>
        /// <example>SetNextDateInEditStatementGroup(NxtDate)</example>
        public void SetNextDateInEditStatementGroup(string NxtDate)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(txtNextDate);
                AppHandle.WaitUntilElementClickable(txtNextDate);
                AppHandle.Set_field_value(txtNextDate, NxtDate);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To fetch value from Next Date Feild in UpdateStatementGroupPage.
        /// <param></param> 
        /// <returns>string</returns>
        /// <example>GetValuefromNextDateInEditStatementGroup()</example>
        public virtual string GetValuefromNextDateInEditStatementGroup()
        {
            string bval = null;
            try
            {
                AppHandle.WaitUntilElementVisible(txtNextDate);
                AppHandle.WaitUntilElementClickable(txtNextDate);
                bval = AppHandle.GetElementValue(txtNextDate);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bval;
        }

        /// <summary>
        /// To fetch value from frequency Feild in UpdateStatementGroupPage.
        /// <param></param> 
        /// <returns>string</returns>
        /// <example>GetValuefromFrequencyInEditStatementGroup()</example>
        public virtual string GetValuefromFrequencyInEditStatementGroup()
        {
            string bval = null;
            try
            {
                AppHandle.WaitUntilElementVisible(txtStatementFrequency);
                AppHandle.WaitUntilElementClickable(txtStatementFrequency);
                bval = AppHandle.GetElementValue(txtStatementFrequency);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bval;
        }
    }
}