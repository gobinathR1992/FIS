using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;
using System.Threading;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class UtilityExceptionProcessingPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string drpTransactionDate = "XPath;//select[@name='defaultDate']";
        private static string drpTransactionSource = "XPath;//select[@name='defaultSource']";
        private static string drpBranch = "XPath;//select[@name='defaultBranch']";
        private static string drpStatus = "XPath;//select[@name='defaultStatus']";
        private static string drpCustomer = "XPath;//select[@name='customerNumber']";
        private static string checkBoxAccountDetails = "XPath;//input[@type ='checkbox']";
        private static string dropdownReturnReason = "XPath;//select[@name='returnReason']";
        private static string dropdownDescision = "XPath;//div[@class='dataTables_scrollBody']/descendant::select[1]";
        private static string buttonReview = "XPath;//*[@value ='Review']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string btnContinue = "XPath;//input[@name='_eventId_continue']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string dropdownReturnFeeAction = "XPath;//*[@name='returnFeeAction']";

        string ExceptionProcessingTable = "XPath;//*[@class='ledger']";
        public virtual void SelectSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }

        }
        public virtual void SelectReviewButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonReview))
            {
                appHandle.ClickObjectViaJavaScript(buttonReview);
            }
        }
        public virtual void ClickOnContinueButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnContinue))
            {
                appHandle.ClickObjectViaJavaScript(btnContinue);
            }
        }

        public virtual bool VerifyMessageInExceptionProcessingPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual void EnterExceptionProcessingSearchPageDetails(string TransactionSource, string Transactiondate, string Branch, string status, string customer)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpTransactionDate))
            {
                if (!string.IsNullOrEmpty(Transactiondate))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpTransactionDate, Transactiondate);
                }
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpTransactionSource))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpTransactionSource, TransactionSource);
                }
                if (!string.IsNullOrEmpty(Branch))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpBranch, Branch);
                }
                if (!string.IsNullOrEmpty(status))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpStatus, status);
                }
                if (!string.IsNullOrEmpty(customer))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpCustomer, customer);
                }
            }
        }

        public virtual bool SelectExceptionCheckbox(bool AccountDetailsONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkBoxAccountDetails))
            {
                if (AccountDetailsONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkBoxAccountDetails)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkBoxAccountDetails);
                        if (appHandle.CheckCheckBoxChecked(checkBoxAccountDetails))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkBoxAccountDetails) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkBoxAccountDetails);
                        if (appHandle.CheckCheckBoxChecked(checkBoxAccountDetails) == false) { Result = true; }
                    }
                }
            }

            return Result;

        }
        public virtual void SelectDecisiondropdown(string AccountNumber, string value)
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownDescision, value);

        }
        public virtual bool ExceptionProcessingConfirmation(string ExceptionProcessing)
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownReturnReason))
            {
                if (!string.IsNullOrEmpty(ExceptionProcessing))
                {
                    appHandle.SelectDropdownSpecifiedValue(dropdownReturnReason, ExceptionProcessing);
                    if (appHandle.CheckSelectedValueExistsInDropdown(dropdownReturnReason, ExceptionProcessing))
                    {
                        result = true;
                    }
                }
            }
            return result;
        }
        public virtual void ExceptionProcessingConfirmation(string ExceptionProcessing, string Fee = null)
        {
            if (!string.IsNullOrEmpty(ExceptionProcessing))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownReturnReason, ExceptionProcessing);
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownReturnFeeAction, Fee);

                }
            
        }
        public virtual bool VerifyExceptionProcessingStatusBeforeProcessing(string customerName)
        {
            int headercount = 0;
            int n = 0;
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ExceptionProcessingTable))
            {
                headercount = appHandle.GetRowCountfromList(ExceptionProcessingTable + "/thead/tr");
            }
            for (int a = 1; a <= headercount; a++)
            {
                if (appHandle.GetObjectText(ExceptionProcessingTable + "/thead/tr/th[" + a + "]").Trim().Equals(Data.Get("Incomplete")))
                {
                    n = a;
                }
            }
            string Incomplete_Value = appHandle.GetObjectText(ExceptionProcessingTable + "/descendant::*[contains(text(),'" + customerName + "')]/ancestor::tr[1]/td[" + n + "]");
            if (!Incomplete_Value.Equals(Data.Get("GLOBAL_VALUE_ZERO")))
            {
                Result = true;
            }
            return Result;
        }
        public virtual bool VerifyExceptionProcessingStatusAfterProcessing(string customerName)
        {
            int headercount = 0;
            int n = 0;
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ExceptionProcessingTable))
            {
                headercount = appHandle.GetRowCountfromList(ExceptionProcessingTable + "/thead/tr");
            }
            for (int a = 1; a <= headercount; a++)
            {
                if (appHandle.GetObjectText(ExceptionProcessingTable + "/thead/tr/th[" + a + "]").Trim().Equals(Data.Get("Incomplete")))
                {
                    n = a;
                }
            }
            string Incomplete_Value = appHandle.GetObjectText(ExceptionProcessingTable + "/descendant::*[contains(text(),'" + customerName + "')]/ancestor::tr[1]/td[" + n + "]");
            if (Incomplete_Value.Equals(Data.Get("GLOBAL_VALUE_ZERO")))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void EnterExceptionProcessingSearchPageDetails(string Transactiondate,string Branch,string status,string customer)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpTransactionDate))
            {
                if(!string.IsNullOrEmpty(Transactiondate))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpTransactionDate,Transactiondate);
                }
                
                if(!string.IsNullOrEmpty(Branch))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpBranch,Branch);
                }
                if(!string.IsNullOrEmpty(status))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpStatus,status);
                }
                if(!string.IsNullOrEmpty(customer))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpCustomer,customer);
                }
            }
        }

    }
}
