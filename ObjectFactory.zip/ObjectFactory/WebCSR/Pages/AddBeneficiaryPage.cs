using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AddBeneficiaryPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string BtnUsePrimaryOwnerAddress = "Xpath;//input[@name='usePrimary']";
        public static string drpClassification = "Xpath;//select[@name='BENEFICIARYINFO_CLASSIFICATION']";
        public static string ckbInvalidforFDICInsurance = "Xpath;//input[@name='BENEFICIARYINFO_ISINVALIDFORFDICINSURANCE']";
        public static string txtCustomerNumberFDIC370Reporting = "Xpath;//input[@name='BENEFICIARYINFO_CIFFORFDIC370REPORTING']";
        public static string txtTaxIDNumber = "Xpath;//input[@name='BENEFICIARYINFO_TAXID']";
        public static string txtFirstName = "Xpath;//input[@name='BENEFICIARYINFO_FIRSTNAME']";
        public static string txtMiddleName = "Xpath;//input[@name='BENEFICIARYINFO_MIDDLENAME']";
        public static string txtLastName = "Xpath;//input[@name='BENEFICIARYINFO_LASTNAME']";
        public static string txtMothersMaidenname = "Xpath;//input[@name='BENEFICIARYINFO_MAIDENNAME']";
        public static string txtDOB = "Xpath;//input[@name='BENEFICIARYINFO_DATEOFBIRTH']";
        public static string drpCountryofCitizenship = "Xpath;//select[@name='BENEFICIARYINFO_CITIZENSHIP']";
        public static string txtEntityName = "Xpath;//input[@name='BENEFICIARYINFO_ENTITYNAME']";
        public static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        public static string txtContactFirstName = "Xpath;//input[@name='BENEFICIARYINFO_ENTITY_FIRSTNAME']";
        public static string txtContactLastName = "Xpath;//input[@name='BENEFICIARYINFO_ENTITY_LASTNAME']";
        public static string txtAddressLine1 = "Xpath;//input[@name='BENEFICIARYINFO_ADDRESSLINE1']";
        public static string txtAddressLine2 = "Xpath;//input[@name='BENEFICIARYINFO_ADDRESSLINE2']";
        public static string txtAddressLine3 = "Xpath;//input[@name='BENEFICIARYINFO_ADDRESSLINE3']";
        public static string txtTownship = "Xpath;//input[@name='BENEFICIARYINFO_LOCALE']";
        public static string txtCounty = "Xpath;//input[@name='BENEFICIARYINFO_COUNTY']";
        public static string txtcity = "Xpath;//input[@name='BENEFICIARYINFO_CITY']";
        public static string drpCountry = "Xpath;//select[@name='BENEFICIARYINFO_COUNTRY']";
        public static string drpState = "Xpath;//select[@name='BENEFICIARYINFO_STATE']";
        public static string txtZIPCode = "Xpath;//input[@name='BENEFICIARYINFO_ZIPCODE']";
        public static string txtTelephone = "Xpath;//input[@name='BENEFICIARYINFO_TELEPHONE']";
        public static string drpRelationship = "Xpath;//select[@name='ACCTBENDTL_BENREL']";
        public static string drpType = "Xpath;//select[@name='ACCTBENDTL_BENTYPE']";
        public static string txtPercentage = "Xpath;//input[@name='ACCTBENDTL_BENPCT']";
        public static string drpIdentificationType = "Xpath;//select[@name='BENEFICIARYINFO_OTHERIDTYPE']";
        public static string txtIdentificationNumber = "Xpath;//input[@name='BENEFICIARYINFO_OTHERIDNUMBER']";
        public static string txtIdentificationIssuer = "Xpath;//input[@name='BENEFICIARYINFO_OTHERIDISSUEDBY']";
        public static string txtIdentificationIssueDate = "Xpath;//input[@name='BENEFICIARYINFO_OTHERIDISSUEDATE']";
        public static string txtIdentificationExpirationDate = "Xpath;//input[@name='BENEFICIARYINFO_OTHERIDEXPIRATIONDATE']";
        public static string txtAddbeneciaryMsg = "Xpath;//h2[contains(text(),'Add Beneficiary')]";
        private static string button_Add_Beneficiary_Customer_beneficiaries = "XPath;//*[@value='Add']";
        private static string buttonSubmit = "XPath;//*[@name='submit']";
        private static string tableBeneficiaryList="XPath;//*[@id='beneficiaries-list_wrapper']";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string buttonEdit="Xpath;//*[@Value='Edit']";
        private static string txtBenePercentage = "Xpath;//*[@name='CIFBENDTL_BENPCT']";
        private static string chkboxInvaildforFDICIsurance = "Xpath;//*[@name='BENEFICIARYINFO_ISINVALIDFORFDICINSURANCE']";
        private static string drpdownBeneType = "Xpath;//*[@name='CIFBENDTL_BENTYPE']";
        private static string CheckboxNonContingent = "Xpath;//input[@name= 'CIFBENDTL_FDICNONCONTINGENTINT']";
        
        //Method for Navigated to the Add Beneficiary page.
        public virtual bool ConfirmAddBeneficiaryPage()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirmed the Add Beneficiary page");
            bool blnSuccess = false;
            if (appHandle.CheckObjectExist(txtAddbeneciaryMsg))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }
        public virtual bool EnterBeneficiaryDetails(int NumberOfBeneficiaries, string BeneficiaryClassificationType, string Country = "US - UNITED STATES OF AMERICA",string PercentageContribution = "",string identificationtype="",string identificationnumber="",string issuer="",string issuedate="",string expirydate =" ",string TaxIDIndividual="")
        {
            bool Result = false;
            string FirstName = "";
            string LastName = "";
            //string TaxIDIndividual = "";
            string TaxIDCharity = "";
            int counter = 0;

            int Pecentagevalue = (int)100 / NumberOfBeneficiaries;
            string percentageContribution = Pecentagevalue.ToString();

            for (int i = 1; i <= NumberOfBeneficiaries; i++)
            {

                appHandle.ClickObjectViaJavaScript(button_Add_Beneficiary_Customer_beneficiaries);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpClassification);
                if (BeneficiaryClassificationType.Equals(Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL")))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpClassification, (string)Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"));
                    appHandle.Set_field_value(txtTaxIDNumber, TaxIDIndividual);
                    FirstName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[0].Trim();
                    LastName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[1].Trim();
                    appHandle.Set_field_value(txtFirstName, FirstName);
                    appHandle.Set_field_value(txtLastName, LastName);
                    appHandle.Set_field_value(txtDOB, appHandle.CalculateNewDate(ApplicationDate, "Y", -45));
                    switch (Country)
                    {
                        case "CZ - CZECHIA":
                            appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("CZ - CZECHIA"));
                            break;
                        case "US - UNITED STATES OF AMERICA":
                            appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                            break;
                        case "TF - FRENCH SOUTHERN TERRITORIES":
                            appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("TF - FRENCH SOUTHERN TERRITORIES"));
                            break;
                        case "VA - HOLY SEE":
                            appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("VA - HOLY SEE"));
                            break;
                        case "WF - WALLIS AND FUTUNA":
                            appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("WF - WALLIS AND FUTUNA"));
                            break;
                        case "MK - NORTH MACEDONIA":
                            appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("MK - NORTH MACEDONIA"));
                            break;
                    }
                }

                if (BeneficiaryClassificationType.Equals(Data.Get("NC - Non-Profit or Charity")))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpClassification, (string)Data.Get("NC - Non-Profit or Charity"));
                    FirstName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[0].Trim();
                    LastName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[1].Trim();
                    TaxIDCharity = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
                    appHandle.Set_field_value(txtTaxIDNumber, TaxIDCharity);
                    appHandle.Set_field_value(txtEntityName, FirstName + LastName);
                    appHandle.Set_field_value(txtContactFirstName, FirstName);
                    appHandle.Set_field_value(txtContactLastName, LastName);

                }
                switch (Country)
                {
                    case "CZ - CZECHIA":
                        appHandle.Set_field_value(txtAddressLine1, Data.Get("CITYCZ") + " Trust");
                        appHandle.Set_field_value(txtAddressLine2, Data.Get("CITYCZ") + " Building");
                        appHandle.Set_field_value(txtcity, Data.Get("CITYCZ"));
                        appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("CZ - CZECHIA"));
                        appHandle.Set_field_value(txtZIPCode, Data.Get("ZIPCODE_CZ"));
                        break;
                    case "US - UNITED STATES OF AMERICA":
                        appHandle.Set_field_value(txtAddressLine1, Data.Get("National Trust"));
                        appHandle.Set_field_value(txtAddressLine2, Data.Get("456 Street"));
                        appHandle.Set_field_value(txtcity, Data.Get("Jacksonville"));
                        appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                        appHandle.SelectDropdownSpecifiedValue(drpState, (string)Data.Get("FL - FLORIDA"));
                        appHandle.Set_field_value(txtZIPCode, Data.Get("32256"));
                        break;
                    case "TF - FRENCH SOUTHERN TERRITORIES":
                        appHandle.Set_field_value(txtAddressLine1, Data.Get("CITYTF") + " Trust");
                        appHandle.Set_field_value(txtAddressLine2, Data.Get("CITYTF") + " Building");
                        appHandle.Set_field_value(txtcity, Data.Get("CITYTF"));
                        appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("TF - FRENCH SOUTHERN TERRITORIES"));
                        appHandle.Set_field_value(txtZIPCode, Data.Get("ZIPCODE_TF"));
                        break;
                    case "VA - HOLY SEE":
                        appHandle.Set_field_value(txtAddressLine1, Data.Get("CITYVA") + " Trust");
                        appHandle.Set_field_value(txtAddressLine2, Data.Get("CITYVA") + " Building");
                        appHandle.Set_field_value(txtcity, Data.Get("CITYVA"));
                        appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("VA - HOLY SEE"));
                        appHandle.Set_field_value(txtZIPCode, Data.Get("ZIPCODE_VA"));
                        break;
                    case "WF - WALLIS AND FUTUNA":
                        appHandle.Set_field_value(txtAddressLine1, Data.Get("CITYWF") + " Trust");
                        appHandle.Set_field_value(txtAddressLine2, Data.Get("CITYWF") + " Building");
                        appHandle.Set_field_value(txtcity, Data.Get("CITYWF"));
                        appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("WF - WALLIS AND FUTUNA"));
                        appHandle.Set_field_value(txtZIPCode, Data.Get("ZIPCODE_WF"));
                        break;
                    case "MK - NORTH MACEDONIA":
                        appHandle.Set_field_value(txtAddressLine1, Data.Get("CITYMK") + " Trust");
                        appHandle.Set_field_value(txtAddressLine2, Data.Get("CITYMK") + " Building");
                        appHandle.Set_field_value(txtcity, Data.Get("CITYMK"));
                        appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("MK - NORTH MACEDONIA"));
                        appHandle.Set_field_value(txtZIPCode, Data.Get("ZIPCODE_MK"));
                        break;
                }

                appHandle.Set_field_value(txtTelephone, RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_PHONE_NUMBER_FORMAT"), "-"));
                appHandle.SelectDropdownSpecifiedValue(drpRelationship, (string)Data.Get("NR - No Relation"));
                appHandle.SelectDropdownSpecifiedValue(drpType, (string)Data.Get("P - PRIMARY"));
                if(!string.IsNullOrEmpty(PercentageContribution))
                {
                    appHandle.Set_field_value(txtPercentage, PercentageContribution);
                }
                else
                {
                    appHandle.Set_field_value(txtPercentage, percentageContribution);
                }  
                appHandle.SelectDropdownSpecifiedValue(drpIdentificationType, (string)Data.Get("DL - Driver's License"));
                appHandle.Set_field_value(txtIdentificationNumber, appHandle.CreateRamdomData(FieldType.NUMERIC, 111111, 999999, 6) + "");
                switch (Country)
                {
                    case "CZ - CZECHIA":
                        appHandle.Set_field_value(txtIdentificationIssuer, Data.Get("CITYCZ"));
                        break;
                    case "US - UNITED STATES OF AMERICA":
                        appHandle.Set_field_value(txtIdentificationIssuer, Data.Get("FL - FLORIDA"));
                        break;
                    case "TF - FRENCH SOUTHERN TERRITORIES":
                        appHandle.Set_field_value(txtIdentificationIssuer, Data.Get("CITYTF"));
                        break;
                    case "VA - HOLY SEE":
                        appHandle.Set_field_value(txtIdentificationIssuer, Data.Get("CITYVA"));
                        break;
                    case "WF - WALLIS AND FUTUNA":
                        appHandle.Set_field_value(txtIdentificationIssuer, Data.Get("CITYWF"));
                        break;
                    case "MK - NORTH MACEDONIA":
                        appHandle.Set_field_value(txtIdentificationIssuer, Data.Get("CITYMK"));
                        break;
                }
                if(!string.IsNullOrEmpty(identificationtype))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpIdentificationType,identificationtype);
                appHandle.Set_field_value(txtIdentificationNumber,identificationnumber);
                appHandle.Set_field_value(txtIdentificationIssuer,issuer);
                appHandle.Set_field_value(txtIdentificationIssueDate, issuedate);
                appHandle.Set_field_value(txtIdentificationExpirationDate, expirydate);
                }
                else
                {
                    appHandle.Set_field_value(txtIdentificationIssueDate, appHandle.CalculateNewDate(ApplicationDate, "Y", -20));
                    appHandle.Set_field_value(txtIdentificationExpirationDate, appHandle.CalculateNewDate(ApplicationDate, "Y", 10));
                }
                ClickOnSubmitButton();
                if (VerifyMSGInBeneficiaryPage(Data.Get("The beneficiary has been added.")) || VerifyMSGInBeneficiaryPage("Total beneficiary percentage for the Primary beneficiaries is not equal to 100%."))
                {
                    counter++;
                }
                TaxIDIndividual = "";
                TaxIDCharity = "";
                FirstName = "";
                LastName = "";
            }
            if (counter == NumberOfBeneficiaries)
            {
                Result = true;
            }

            return Result;
        }

        public virtual string GenerateCustomerName()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string strCustName = "";
            string strFirstName = "";
            string strLastName = "";
            string strRandomString1 = appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 5).ToString();
            string strRandomString2 = appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 5).ToString();

            string strUserName = StartupConfiguration.UserSettings.GLOBAL_USER_NAME;

            if (!strUserName.Contains(" "))
            {
                // strFirstName = strUserName.Substring(0,1).ToUpper() + strUserName.Substring(1,strUserName.Length-1).ToLower() + strRandomString1;
                strFirstName = strUserName.Substring(0, 1).ToUpper() + strUserName.Substring(1, strUserName.Length - 1).ToLower() + strRandomString1;
                strLastName = strUserName.Substring(0, 1).ToUpper() + strUserName.Substring(1, strUserName.Length - 1).ToLower() + strRandomString2;
            }
            else
            {
                string[] arrUserDetails = strUserName.Split(' ');
                strFirstName = arrUserDetails[0].Substring(0, 1).ToUpper() + arrUserDetails[0].Substring(1, arrUserDetails[0].Length - 1).ToLower() + strRandomString1;
                strLastName = arrUserDetails[1].Substring(0, 1).ToUpper() + arrUserDetails[1].Substring(1, arrUserDetails[1].Length - 1).ToLower() + strRandomString2;
            }

            strCustName = strFirstName + " " + strLastName;
            return strCustName;
        }
        public static string ApplicationDate = new AddBeneficiaryPage().GetApplicationDate();
        public virtual string GetApplicationDate()
        {
            string result = "";
            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMSGInBeneficiaryPage(string inputMSG)
        {
            bool result = false;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Contains(inputMSG))
            {
                result = true;
            }
            return result;
        }
        public virtual void EnterBeneficiaryDetailswithInvaildZipCode(int NumberOfBeneficiaries, string BeneficiaryClassificationType, string ZipCode)
        {
            bool Result = false;
            string FirstName = "";
            string LastName = "";
            string TaxIDIndividual = "";
            string TaxIDCharity = "";
            string Issuer = "USA";
            int counter = 0;

            int Pecentagevalue = (int)100 / NumberOfBeneficiaries;
            string percentageContribution = Pecentagevalue.ToString();

            for (int i = 1; i <= NumberOfBeneficiaries; i++)
            {

                appHandle.ClickObjectViaJavaScript(button_Add_Beneficiary_Customer_beneficiaries);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpClassification);
                if (BeneficiaryClassificationType.Equals(Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL")))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpClassification, (string)Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"));
                    FirstName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[0].Trim();
                    LastName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[1].Trim();
                    TaxIDIndividual = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"), "-");
                    appHandle.Set_field_value(txtTaxIDNumber, TaxIDIndividual);
                    appHandle.Set_field_value(txtFirstName, FirstName);
                    appHandle.Set_field_value(txtLastName, LastName);
                    appHandle.Set_field_value(txtDOB, appHandle.CalculateNewDate(ApplicationDate, "Y", -45));
                    appHandle.SelectDropdownSpecifiedValue(drpCountryofCitizenship, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                }

                if (BeneficiaryClassificationType.Equals(Data.Get("NC - Non-Profit or Charity")))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpClassification, (string)Data.Get("NC - Non-Profit or Charity"));
                    FirstName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[0].Trim();
                    LastName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[1].Trim();
                    TaxIDCharity = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
                    appHandle.Set_field_value(txtTaxIDNumber, TaxIDCharity);
                    appHandle.Set_field_value(txtEntityName, FirstName + LastName);
                    appHandle.Set_field_value(txtContactFirstName, FirstName);
                    appHandle.Set_field_value(txtContactLastName, LastName);

                }
                appHandle.Set_field_value(txtAddressLine1, Data.Get("SeaLine1"));
                appHandle.Set_field_value(txtAddressLine2, Data.Get("SeaLine2"));
                appHandle.Set_field_value(txtcity, Data.Get("GLOBAL_CITY_MALVERN"));
                appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                appHandle.SelectDropdownSpecifiedValue(drpState, (string)Data.Get("NE - NEBRASKA"));
                appHandle.Set_field_value(txtZIPCode, ZipCode);
                appHandle.Set_field_value(txtTelephone, RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_PHONE_NUMBER_FORMAT"), "-"));
                appHandle.SelectDropdownSpecifiedValue(drpRelationship, (string)Data.Get("SP - Spouse"));
                appHandle.SelectDropdownSpecifiedValue(drpType, (string)Data.Get("P - PRIMARY"));
                appHandle.Set_field_value(txtPercentage, percentageContribution);
                appHandle.SelectDropdownSpecifiedValue(drpIdentificationType, (string)Data.Get("DL - Driver's License"));
                appHandle.Set_field_value(txtIdentificationNumber, appHandle.CreateRamdomData(FieldType.NUMERIC, 111111, 999999, 6) + "");
                appHandle.Set_field_value(txtIdentificationIssuer, Issuer);
                appHandle.Set_field_value(txtIdentificationIssueDate, appHandle.CalculateNewDate(ApplicationDate, "Y", -20));
                appHandle.Set_field_value(txtIdentificationExpirationDate, appHandle.CalculateNewDate(ApplicationDate, "Y", 10));
                ClickOnSubmitButton();
            }

        }

        public virtual string GetBeneficiaryID(int rownumber)
        {
            string BeneficiaryID="";

            BeneficiaryID=(string)appHandle.GetTableCellValue(tableBeneficiaryList,rownumber,2);

            return BeneficiaryID;
        }
        public virtual string GetFirstNameofBeneficiary(string BeneID)
        {
            appHandle.SelectRadioButtonInTable(tableBeneficiaryList,BeneID);
            appHandle.ClickObjectViaJavaScript(buttonEdit);
            string result = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtFirstName))
            {
                result = appHandle.GetElementValue(txtFirstName);
            }
            return result;


        }
        public virtual string GetLastNameofBeneficiary(string BeneID)
        {
            appHandle.SelectRadioButtonInTable(tableBeneficiaryList,BeneID);
            appHandle.ClickObjectViaJavaScript(buttonEdit);
            string result = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtLastName))
            {
                result = appHandle.GetElementValue(txtLastName);
            }
            return result;


        }
        public virtual string GetTaxidofBeneficiary(string BeneID)
        {
            appHandle.SelectRadioButtonInTable(tableBeneficiaryList,BeneID);
            appHandle.ClickObjectViaJavaScript(buttonEdit);
            string result = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtTaxIDNumber))
            {
                result = appHandle.GetElementValue(txtTaxIDNumber);
            }
            return result;


        }
        public virtual string EnterBeneficiaryDetailsforTrustCustomer(string BeneficiaryClassificationType, string percentageContribution, bool OnorOFF,bool NonContingentCheckBoxONOFF)
        {
            bool Result = false;
            string FirstName = "";
            string LastName = "";
            string TaxIDIndividual = "";
            string TaxIDCharity = "";
            string Issuer = "Government";

            appHandle.ClickObjectViaJavaScript(button_Add_Beneficiary_Customer_beneficiaries);
            this.ClickonInvalidforFDICInsuranceCheckbox(OnorOFF);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpClassification);

            switch (BeneficiaryClassificationType)
            {
                case "I - Individual":
                    if (BeneficiaryClassificationType.Equals(Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL")))
                    {
                        appHandle.SelectDropdownSpecifiedValue(drpClassification, (string)Data.Get("GLOBAL_CLASSIFICATION_TYPE_INDIVIDUAL"));
                        TaxIDIndividual = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"), "-");
                        appHandle.Set_field_value(txtTaxIDNumber, TaxIDIndividual);
                        FirstName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[0].Trim();
                        LastName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[1].Trim();
                        appHandle.Set_field_value(txtFirstName, FirstName);
                        appHandle.Set_field_value(txtLastName, LastName);
                        appHandle.Set_field_value(txtDOB, appHandle.CalculateNewDate(ApplicationDate, "Y", -18));
                        appHandle.SelectDropdownSpecifiedValue(drpCountryofCitizenship, (string)Data.Get("US - UNITED STATES OF AMERICA"));
                    }

                    break;

                case "O - Other":
                    if (BeneficiaryClassificationType.Equals(Data.Get("O - Other")))
                    {
                        appHandle.SelectDropdownSpecifiedValue(drpClassification, (string)Data.Get("O - Other"));
                        FirstName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[0].Trim();
                        LastName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[1].Trim();
                        TaxIDIndividual = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
                        appHandle.Set_field_value(txtTaxIDNumber, TaxIDIndividual);
                        appHandle.Set_field_value(txtEntityName, FirstName + LastName);
                        appHandle.Set_field_value(txtContactFirstName, FirstName);
                        appHandle.Set_field_value(txtContactLastName, LastName);
                    }
                    break;

                case "NC - Non-Profit or Charity":
                        if (BeneficiaryClassificationType.Equals("NC - Non-Profit or Charity"))
                        {
                        appHandle.SelectDropdownSpecifiedValue(drpClassification, (string)Data.Get("NC - Non-Profit or Charity"));
                        FirstName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[0].Trim();
                        LastName = this.GenerateCustomerName().Split(new string[] { " " }, StringSplitOptions.None)[1].Trim();
                        TaxIDIndividual = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
                        appHandle.Set_field_value(txtTaxIDNumber, TaxIDIndividual);
                        appHandle.Set_field_value(txtEntityName, FirstName + LastName);
                        appHandle.Set_field_value(txtContactFirstName, FirstName);
                        appHandle.Set_field_value(txtContactLastName, LastName);
                        }
                        break;

               }
            
            appHandle.Set_field_value(txtAddressLine1, Data.Get("SeaLine1"));
            appHandle.Set_field_value(txtAddressLine2, Data.Get("SeaLine2"));
            appHandle.Set_field_value(txtcity, Data.Get("GLOBAL_CITY_MALVERN"));
            appHandle.SelectDropdownSpecifiedValue(drpCountry, (string)Data.Get("US - UNITED STATES OF AMERICA"));
            appHandle.SelectDropdownSpecifiedValue(drpState, (string)Data.Get("NE - NEBRASKA"));
            appHandle.Set_field_value(txtZIPCode, Data.Get("VaildZIPNE"));
            appHandle.SelectDropdownSpecifiedValue(drpdownBeneType, (string)Data.Get("P - PRIMARY"));
            this.ClickonNonContingentCheckBox(NonContingentCheckBoxONOFF);
            appHandle.Set_field_value(txtBenePercentage, percentageContribution);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpIdentificationType,"PPT");
            appHandle.Set_field_value(txtIdentificationNumber, appHandle.CreateRamdomData(FieldType.NUMERIC, 111111111, 999999999, 9) + "");
            appHandle.Set_field_value(txtIdentificationIssuer, Issuer);
            appHandle.Set_field_value(txtIdentificationIssueDate, appHandle.CalculateNewDate(ApplicationDate, "Y", -3));
            appHandle.Set_field_value(txtIdentificationExpirationDate, appHandle.CalculateNewDate(ApplicationDate, "Y", 20));
            ClickOnSubmitButton();
            return TaxIDIndividual;
        }
        public virtual void ClickonInvalidforFDICInsuranceCheckbox(bool FDICOnorOFF = true, string Reporting1099Exemption = "")
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chkboxInvaildforFDICIsurance))
            {
                if (FDICOnorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(chkboxInvaildforFDICIsurance)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(chkboxInvaildforFDICIsurance);
                        if (appHandle.CheckCheckBoxChecked(chkboxInvaildforFDICIsurance))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(chkboxInvaildforFDICIsurance) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(chkboxInvaildforFDICIsurance);
                        if (appHandle.CheckCheckBoxChecked(chkboxInvaildforFDICIsurance) == false) { Result = true; }
                    }
                }
            }
        }
            public virtual void ClickonNonContingentCheckBox(bool NonContingentCheckBoxONOFF=true)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chkboxInvaildforFDICIsurance))
            {
                if (NonContingentCheckBoxONOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(CheckboxNonContingent)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(CheckboxNonContingent);
                        if (appHandle.CheckCheckBoxChecked(CheckboxNonContingent))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(CheckboxNonContingent) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(CheckboxNonContingent);
                        if (appHandle.CheckCheckBoxChecked(CheckboxNonContingent) == false) { Result = true; }
                    }
                }
            }

       
        }
        public virtual void SelectBeneficiaryInBeneficiaryTable(string UniqueOrderRefValue)
        {
            appHandle.SelectRadioButtonInTable(tableBeneficiaryList, UniqueOrderRefValue);
            
        }
        public virtual string GetEntityNameofBeneficiary(string BeneID)
        {
            appHandle.SelectRadioButtonInTable(tableBeneficiaryList,BeneID);
            appHandle.ClickObjectViaJavaScript(buttonEdit);
            string result = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtEntityName))
            {
                result = appHandle.GetElementValue(txtEntityName);
            }
            return result;
        
        }
        public virtual void DeleteBeneficiaryForSpecifiedAccountnumber(string Benid)
        {
            string inputRadioButtonXPath = "Xpath;//input[@name='beneficiaryIdSequence'][@value='"+Benid+"']";

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(inputRadioButtonXPath))
            {
                appHandle.ClickObjectViaJavaScript(inputRadioButtonXPath);
            }
                        
        }



    }
}