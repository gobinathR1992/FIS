using System;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    [Page]
    public class LoanAccountServicesProjectedActivityPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string dropdownAccount = "XPath;//*[@name='ACN_CID']";
        private static string txtProjectThroughDate = "XPath;//*[contains(text(),'Project Through Date')]/following-sibling::*/descendant::input";
        private static string buttonSubmit = "XPath;//input[@name='submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        private static string tableHeaderProjectedActivityTable = "XPath;//*[contains(@class,'dataTables_scrollHead')]/descendant::th[text()='Date']";
        private static string tableContent = "XPath;//table[@class='contentTable']/tbody";
        private static string txtEffectiveDate = "XPath;//input[@name = 'effectiveDate']";
        private static string txtNewIntRate = "XPath;//input[@name = 'newInterestRate']";
        private static string tablebodyProjectedActivityTable = "XPath;//table[@class='ledgerScrollable dataTable']/tbody";
        public virtual void EnterDataToRetrieveProjectedActivity(string AccountNumber, string ProjectedThroughDate)
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccount))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccount, AccountNumber);
                appHandle.Set_field_value(txtProjectThroughDate, ProjectedThroughDate);
            }

        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMessageInLoanAccountServicesProjectedActivityPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VeriyProjectedActivityDetailsByLabelnameLabelValue(string sLabelNamePipeDelimitedLabelValue)
        {
            bool Result = false;
            sLabelNamePipeDelimitedLabelValue = sLabelNamePipeDelimitedLabelValue + ";";
            int matchcount = 0;
            string[] arr = sLabelNamePipeDelimitedLabelValue.Split(';');
            for (int a = 0; a < arr.Length - 1; a++)
            {
                if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableContent, arr[a]))
                {
                    matchcount++;
                }
                if (matchcount == arr.Length - 1)
                {
                    Result = true;
                    break;
                }
            }

            return Result;
        }
        public virtual void EnterEFDRateChangeOption(string EffDate, string fixedRateType, string NewIntRate)
        {
            if (!string.IsNullOrEmpty(EffDate))
            {
                appHandle.Set_field_value(txtEffectiveDate, EffDate);
            }
            string seleceFixedRateType = "Xpath;//input[@value='" + fixedRateType + "']";
            appHandle.WaitUntilElementVisible(seleceFixedRateType);
            appHandle.Set_radiobutton(seleceFixedRateType);

            if (!string.IsNullOrEmpty(NewIntRate))
            {
                appHandle.Set_field_value(txtNewIntRate, NewIntRate);
            }

        }
        public virtual string CalculateBorrowerTotal()
        {
            string Result = "";
            double totInt = 0;
            int rowCount = appHandle.GetRowCountfromList(tablebodyProjectedActivityTable);
            for (int y = 1; y <= rowCount; y++)
            {
                string temp = appHandle.GetObjectText(tablebodyProjectedActivityTable + "/tr[" + y + "]/td[4]");
                totInt = totInt + Convert.ToDouble(temp);
            }
            Result = totInt.ToString();
            Result = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Result);
            return Result;
        }

    }
}