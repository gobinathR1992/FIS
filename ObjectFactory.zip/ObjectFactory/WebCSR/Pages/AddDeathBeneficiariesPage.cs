using GTS_OSAF.CoreLibs;
using System;
using GTS_OSAF.HelperLibs.Reporter;
namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class AddDeathBeneficiariesPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string drpBeneficiaryType = "Name;plan.beneficiaries[0].type";
        public static string txtName = "Name;plan.beneficiaries[0].name";
        public static string txtTaxId = "Name;plan.beneficiaries[0].taxIdNumber";
        public static string txtDateOfBirth = "Name;plan.beneficiaries[0].dateOfBirth";
        public static string drpRelationshiptoOwner = "Name;plan.beneficiaries[0].relationship";
        public static string txtPercentage = "Name;plan.beneficiaries[0].percentage";
        public static string rbtnAddressSameAsOwner = "Xpath;//input[@name='plan.beneficiaries[0].mailingAddressSameAsOwner'][@value='true']";
        public static string rbtnEligibleforFairMarketVlaueCalculationRadiobuttonTrue = "Xpath;//input[@name='plan.beneficiaries[0].eligibleForFairMarketValueCalc'][@value='true']";
        public static string rbtnEligibleforFairMarketVlaueCalculationRadiobuttonFalse = "Xpath;//input[@name='plan.beneficiaries[0].eligibleForFairMarketValueCalc'][@value='false']";
        /// <summary>
        /// This method is used to Enter death beeneficiaries Details.
        /// </summary>
        /// <returns></returns> 
        /// DeathBeneficiariesDetails[0] = "PRIMARY"  'Death Beneficiary 1 Type
        /// DeathBeneficiariesDetails[1] =  "Ravi"  ''Death Beneficiary 1 Name
        /// DeathBeneficiariesDetails[2] = "456-92-7195"  ''Death Beneficiary 1 Tax ID
        /// DeathBeneficiariesDetails[3] = "01/01/1969"  ''Death Beneficiary 1 Date Of Birth
        /// DeathBeneficiariesDetails[4] = "Brother"  ''Death Beneficiary 1 Relationship to Owner
        /// DeathBeneficiariesDetails[5] = "100.00000"  ''Death Beneficiary 1 Percentage
        /// DeathBeneficiariesDetails[6] = GLOBAL_FALSE ''Death Beneficiary 1 Eligible for Fair Market Value Calculation
        /// DeathBeneficiariesDetails[7] = "GLOBAL_ON" 'To click the OverrideStopCheckbox' otherwise TransferDetails[7]=""
        /// DeathBeneficiariesDetails[8] = GLOBAL_TRUE  ''Death Beneficiary 1  Address Same As Owner
        /// <example>
        /// WebCSRPageFactory.DomesticPaymentAddPage.SelectPaymentTypeFromDropDown();
        /// </example>           
        public virtual void EnterDeathBeneficiariesDetails(string[] DeathBeneficiariesDetails)
        {
            try
            {
                appHandle.SelectDropdownSpecifiedValue(drpBeneficiaryType, DeathBeneficiariesDetails[0]);
                appHandle.Set_field_value(txtName, DeathBeneficiariesDetails[1]);
                appHandle.Set_field_value(txtTaxId, DeathBeneficiariesDetails[2]);
                appHandle.Set_field_value(txtDateOfBirth, DeathBeneficiariesDetails[3]);
                appHandle.SelectDropdownSpecifiedValue(drpRelationshiptoOwner, DeathBeneficiariesDetails[4]);
                appHandle.Set_field_value(txtPercentage, DeathBeneficiariesDetails[5]);
                if (DeathBeneficiariesDetails[6] == "true")
                {
                    appHandle.Set_radiobutton(rbtnEligibleforFairMarketVlaueCalculationRadiobuttonTrue);
                }
                else
                {
                    appHandle.Set_radiobutton(rbtnEligibleforFairMarketVlaueCalculationRadiobuttonFalse);
                }
                appHandle.Set_radiobutton(rbtnAddressSameAsOwner);
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }
    }
}