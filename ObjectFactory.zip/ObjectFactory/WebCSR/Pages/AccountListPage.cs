using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
//using GTS_OSAF.CoreLibs.Internal;
//using GTS_OSAF.CoreLibs.Web.ToolFactory.Internal;
using GTS_OSAF.HelperLibs.Reporter;
using OpenQA.Selenium;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{

    public class AccountListPage
    {
        static WebApplication webHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string pageHeader = "XPath;//h1[text()='Account List']";
        private static string ViewAccountDetail_Dropdown = "XPath;//select[@name='accountNumber']";
        private static string InstalmentLoanTable = "XPath;//table[@class='contentTable']/tbody";
        public static string imgBalancesTable = "Xpath;//table[@id='deposit-accounts-DDA']//img";
        public static string tblBalances = "Xpath;//div[@id='core-modal-dialog']//table[@class='contentTable']";
        public static string tblCheckHolds="Xpath;//div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable']//tr[7]";
        public static string tblAvailableBalanceCalculation="Xpath;//body[@class='main']/div[@class='ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable']/div[@id='core-modal-dialog']/table[@class='contentTable']/tbody/tr[5]";

        public virtual void waitForAccountListPage()
        {
            webHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            webHandle.WaitUntilElementVisible(pageHeader);
            Report.Info("Account List Page");
        }
        public virtual void SelectAccountInTable(string accountNumber, string sRefVal)
        {
            webHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            webHandle.SelectLinkInTable(InstalmentLoanTable, accountNumber, sRefVal);
            Report.Info("Account number " + accountNumber + "is selected in table.");
        }

        internal void SelectAccount(string accNumber)
        {
            webHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            webHandle.ClickObject("LinkText;" + accNumber);
            Report.Info("Account number " + accNumber + "is selected in .");
        }
        internal void select_account_number1(string sStdProdNum, string sAcctNumber)
        {
            string strAcctNumber = null;
            switch (sStdProdNum)
            {
                case "100":
                    {
                        strAcctNumber = "WASH - " + sAcctNumber;
                        break;
                    }
                case "200":
                    {
                        strAcctNumber = "ESC - " + sAcctNumber;
                        break;
                    }
                case "300":
                    {
                        strAcctNumber = "SAV - " + sAcctNumber;
                        break;
                    }
                case "350":
                    {
                        strAcctNumber = "CD - " + sAcctNumber;
                        break;
                    }
                case "400":
                    {
                        strAcctNumber = "DDA - " + sAcctNumber;
                        break;
                    }
                case "470":
                    {
                        strAcctNumber = "DBD - " + sAcctNumber;
                        break;
                    }
                case "500":
                    {
                        strAcctNumber = "LN - " + sAcctNumber;
                        break;
                    }
                case "590":
                    {
                        strAcctNumber = "DM - " + sAcctNumber;
                        break;
                    }
                case "600":
                    {
                        strAcctNumber = "RC - " + sAcctNumber;
                        break;
                    }
                case "650":
                    {
                        strAcctNumber = "CC - " + sAcctNumber;
                        break;
                    }
                case "700":
                    {
                        strAcctNumber = "MTG - " + sAcctNumber;
                        break;
                    }
                case "800":
                    {
                        strAcctNumber = "COM - " + sAcctNumber;
                        break;
                    }
                case "900":
                    {
                        strAcctNumber = "CBL - " + sAcctNumber;
                        break;
                    }
            }
            webHandle.Wait_for_object(ViewAccountDetail_Dropdown, 10);
            webHandle.SelectDropdownSpecifiedValue(ViewAccountDetail_Dropdown, strAcctNumber);
            webHandle.Wait_For_Specified_Time(3);
            Report.Info("Account Number " + sAcctNumber + " is selected.");
        }
        internal void select_account_number(string sAcctNumber)
        {
            int cnt = 0;
            int itemindex = 0;
           // IWebLibrary tool = null;
            IWebElement dropdownElement = null;
            //tool = (IWebLibrary)WebToolFactory.GetToolReference();
          //  dropdownElement = (IWebElement)tool.FindElement(ViewAccountDetail_Dropdown);
            System.Collections.ObjectModel.ReadOnlyCollection<IWebElement> optionElements = dropdownElement.FindElements(By.TagName("option"));
            foreach (IWebElement option in optionElements)
            {
                cnt++;
                String textContent = option.Text;
                if (textContent.Contains(sAcctNumber))
                {
                    itemindex = cnt;
                    break;
                }
            }
            webHandle.SelectDropdownValueByIndex(ViewAccountDetail_Dropdown, itemindex);
            webHandle.Wait_For_Specified_Time(5);
            Report.Info("Account Number " + sAcctNumber + " is selected.");
        }

        /// <summary>
        /// This method is select to link in table
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.AccountListPage.selectAccountFromAccountDropdown();
        /// </example>
        public virtual void SelectApplicationLinkInTable(string sTableName, string sApplicationLink, string sRefVal)
        {
            webHandle.SelectLinkInTable(sTableName, sApplicationLink, sRefVal);
        }

        /// <summary>
        /// This method is click on Balances table Image.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.AccountListPage.ClickOnBalancesImg();
        /// </example>
        public virtual void ClickOnBalancesImg()
        {
            try{
                webHandle.WaitUntilElementVisible(imgBalancesTable);
                webHandle.ClickObject(imgBalancesTable);
            }
            catch(Exception e)
            {
                Report.Info("Exception logged : "+e);
            }
        }

        /// <summary>
        /// This method is used to check column exists in Balance table.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.AccountListPage.CheckColumnExistsInTable();
        /// </example>
        public virtual bool CheckColumnExistsInTable(string sTableName, string sColumnName)
        {
         bool bCheck = false;
         try{
         bCheck = webHandle.CheckSpecifiedColumnExistsInTable(sTableName, sColumnName);
         }
         catch(Exception e)
         {
           Report.Info("Exception logged : "+e);  
         }
         return bCheck;

        }

        public virtual bool CheckvalueExistsinTable(string sTableName, string sColumnName, string sColumnValue)
        {
         bool bCheck = false;
         try{
         bCheck = webHandle.CheckSpecifiedDataAvailableInTable(sColumnValue, sTableName);
         }
         catch(Exception e)
         {
           Report.Info("Exception logged : "+e);  
         }
         return bCheck;

        }


    }
}