using System;
using System.Collections.Generic;
using Profile7Automation.Libraries.Util;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class BeneficiariesPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpAccount = "Xpath;//select[@name='ACCTBENDTL_CID']";
        public static string btnAdd = "Xpath;//input[@name='add']";
        public static string btnLinkBeneficiary = "Xpath;//input[@name='linkBeneficiary']";

        /// <summary>
        /// This method is used to select Account From AccountDropdown
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.AccountVerificationPage.selectAccountFromAccountDropdown();
        /// </example>
        public virtual void selectAccountFromDropdown(string AccountNumber)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpAccount))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpAccount, AccountNumber);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnAdd);
        }

        //Method for click the Add button in Beneficiary page.
        public virtual void ClickAddButton()
        {
            appHandle.ClickObjectViaJavaScript(btnAdd);
        }

        /// <summary>
        /// This method is used to Get the data from table.
        /// </summary>
        /// <returns>string</returns> 
        /// <example>
        /// BeneficiaryPage.GetValuefromTable();
        public virtual string GetValuefromBeneficiaryTable(string sRefVals)
        {
            string OutputValue = null;
            try
            {
                string obj = System.Web.HttpUtility.HtmlDecode("XPath;//th[text()='Beneficiary ID']/following::table");
                if (appHandle.IsObjectExists(obj))
                {
                    appHandle.WaitUntilElementVisible(obj);
                    OutputValue = appHandle.GetSpecifiedDataAvailableInTable(sRefVals, obj);
                }
                else
                {
                    Report.Fail("Element not found", "True", appHandle);
                }
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return OutputValue;
        }

        //Method for check value from Beneficiary Table.
        public virtual bool CheckValuefromBeneficiaryTable(string sRefVals)
        {
            bool OutputValue1 = false;
            try
            {
                string obj1 = System.Web.HttpUtility.HtmlDecode("XPath;//th[text()='Beneficiary ID']/following::table");
                if (appHandle.IsObjectExists(obj1))
                {
                    appHandle.WaitUntilElementVisible(obj1);
                    OutputValue1 = appHandle.CheckSpecifiedDataAvailableInTable(sRefVals, obj1);
                }
                else
                {
                    Report.Fail("Element not found", "True", appHandle);
                }
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return OutputValue1;

        }

    }
}