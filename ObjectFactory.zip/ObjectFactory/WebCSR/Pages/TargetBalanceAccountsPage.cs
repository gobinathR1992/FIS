using System.Collections.Generic;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Helper;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class TargetBalanceAccountsPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpTargetBalanceAccountsAccount="Xpath;//select[@name='ACN_CID']";
        public static string drpTargetBalanceAccountsProcessingOption="Xpath;//select[@name='DEP_TBAOPT']";
        public static string drpTargetBalanceAccountsBalanceBase="Xpath;//select[@name='DEP_TBATFRBB']";
        public static string txtTargetBalanceAccountsThresholdAmount="Xpath;//input[@name='DEP_TBATHRAMT']";
        public static string txtTargetBalanceAccountsStartDate="Xpath;//input[@name='DEP_TBASTDT']";
        public static string txtTargetBalanceAccountsExpirationDate="Xpath;//input[@name='DEP_TBAENDDT']";
        public static string ckbTargetBalanceAccountsAllowtoOverdrawConcentrationAccount="Xpath;//input[@name='DEP_TBAOVRDRAW']";
        public static string ckbTargetBalanceAccountsTransferHolds="Xpath;//input[@name='DEP_TBAHOLD']";

        public virtual void selectprocessingoption(string sPOption)
        {
            appHandle.SelectDropdownSpecifiedValue(drpTargetBalanceAccountsProcessingOption, sPOption);
    
        }
        public virtual void selectaccount(string sAccount)
        {
            appHandle.SelectDropdownSpecifiedValue(drpTargetBalanceAccountsAccount, sAccount);
        }
        public virtual void selectbalancebase(string sBalancebase)
        {
            appHandle.SelectDropdownSpecifiedValue(drpTargetBalanceAccountsBalanceBase, sBalancebase);
        }
        public virtual void settheDates(string sStartDate, string sExpdate)
        {
            appHandle.Set_field_value(txtTargetBalanceAccountsStartDate, sStartDate);
            appHandle.Set_field_value(txtTargetBalanceAccountsExpirationDate, sExpdate);
        }
        
        public virtual void settheThresholdAmount(string sThresholdAmount)
        {
            appHandle.Set_field_value(txtTargetBalanceAccountsThresholdAmount, sThresholdAmount);
        }

    }
}
