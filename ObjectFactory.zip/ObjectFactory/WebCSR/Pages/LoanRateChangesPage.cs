using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class LoanRateChangesPage
    {
        WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tableRateChange="XPath;//table[@id='rate-changes-list']/tbody";

        public virtual bool CheckDataInRateChangeTable(string valuesdelimtedbyPipeDelim)
        {
            bool resflg=false;
            string[] val=valuesdelimtedbyPipeDelim.Split('|');
            for(int i=0;i<val.Length;i++)
            {
                if(applicationHandle.CheckTextExistsInTable(tableRateChange,val[i]))
                {
                    resflg=true;
                }
            }

            return resflg;
        }


        
    }
}