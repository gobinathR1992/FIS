using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.BusinessFunctions;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class MakerAndCheckerLitePage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string makerCheckerLiteMenu="Xpath;//td[text()='Maker Checker Lite']";
        public static string myActivityQueue="Xpath;//table[@class='tab']/tbody/tr/td[text()='My Activity Queue']";
        //private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        //private static string Submit_Button = "Xpath;//input[@value='Submit']";

        
        
        public virtual void OpenMakerCheckerLiteMenu()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(makerCheckerLiteMenu))
            {
            appHandle.ClickObject(makerCheckerLiteMenu);
            }
        }

        public virtual void OpenMyActivityQueue()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(myActivityQueue))
            {
            appHandle.ClickObject(myActivityQueue);
            }
        }
        
    }
}