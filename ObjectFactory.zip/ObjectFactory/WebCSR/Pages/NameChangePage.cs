using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class NameChangePage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtLastname="XPath;//input[@name='CIF_LNM']";

        public virtual string GetCustomerastName()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtLastname);
            return appHandle.GetEditFieldValue(txtLastname);

        }
            
    }    
}


