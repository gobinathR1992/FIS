using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class StatementGroupPage
    {
        static WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tblStatementGroupAction = "Xpath;//table[@class='contentTable']//div[contains(@id,'statement-groups-list')]";
        public static string btnStatementEdit = "Xpath;//input[@name='edit'][contains(@onclick,'statementGroupEdit')]";
        public static string btnStatementAdd = "Xpath;//input[@name='add'][contains(@onclick,'statementGroupAdd')]";
        public static string btnSubmit = "Xpath;//input[@name='add'][@value ='Submit']";
        private static string txtFrequency ="Xpath;//input[@name='CMBGRP_SFRE']";
        private static string txtNextdate = "Xpath;//input[@name='CMBGRP_SNDT']";
        private static string txtAddress = "Xpath;//input[@name='CMBGRP_ADDR']";
        //public static string btnSubmit = "Xpath;//input[@name='edit'][@type='submit']";
        WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);        
        public static string tableStatementGroup="XPath;//table[@id='statement-groups-list']/tbody";
        public static string buttonEdit="XPath;//input[@name='edit']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";  
        
        
        /// <summary>
        /// To select statement group in StatementGroupPage.
        /// <param name= "statement group"></param> 
        /// <returns></returns>
        /// <example>SelectStatementGroup(sgroup)</example>
        public void SelectStatementGroup(string sgroup)
        {
            string obj = "Xpath;//table[@class='contentTable']//div[contains(@id,'statement-groups-list')]//input[@type='radio'][@value='" + sgroup + "']";
            AppHandle.WaitUntilElementVisible(tblStatementGroupAction);
            AppHandle.ClickObject(obj);
         
        }

        /// <summary>
        /// To Click on Edit button in StatementGroupPage.
        /// <param></param> 
        /// <returns></returns>
        /// <example>ClickOnStatementGroupEditButton()</example>
        public void ClickOnStatementGroupEditButton()
        {
            try
            {
                AppHandle.WaitUntilElementVisible(btnStatementEdit);
                AppHandle.WaitUntilElementClickable(btnStatementEdit);
                AppHandle.SelectButton(btnStatementEdit);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to click on submit button.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// StatementGroupPage.ClickOnSubmitButton;
        /// </example>
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                AppHandle.ClickObjectViaJavaScript(buttonSubmit);

            }
        }
        
        public virtual void AddStatementGroup(string Frequency, string NextDate, string AccountNumber, bool Selected = false, bool AccountSummary = false)
        {
            AppHandle.ClickObjectViaJavaScript(btnStatementAdd);
            string SelectedXpath = "Xpath;//td[contains(text(),'"+AccountNumber+"')]/preceding-sibling::td/input[@type='checkbox']";
            string SummaryAccountXpath = "Xpath;//td[contains(text(),'"+AccountNumber+"')]/following-sibling::td/input[@type='checkbox']";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtFrequency))
            {
            if(!string.IsNullOrEmpty(Frequency))
            {
                AppHandle.Set_field_value(txtFrequency, Frequency);
            }
            if(!string.IsNullOrEmpty(NextDate))
            {
                AppHandle.Set_field_value(txtNextdate, NextDate);
            }
            if(!string.IsNullOrEmpty(AccountNumber))
            {
                AppHandle.Set_field_value(txtAddress, AccountNumber);
            }
            if((Selected) && (AppHandle.IsObjectExists(SelectedXpath)))
            {
                AppHandle.ClickObjectViaJavaScript(SelectedXpath);
            }
            
            if((AccountSummary) && (AppHandle.IsObjectExists(SummaryAccountXpath)))
            {
                AppHandle.ClickObjectViaJavaScript(SummaryAccountXpath);
            }
            
            }
        }
        public virtual void ClickOnSubmit()
        {
            AppHandle.ClickObjectViaJavaScript(btnSubmit);
        }


        public virtual void EditStatementGroup(string Frequency,string NextDate)
        {
            if(!string.IsNullOrEmpty(Frequency))
            {
                AppHandle.Set_field_value(txtFrequency,Frequency);
            }
            if(!string.IsNullOrEmpty(NextDate))
            {
                AppHandle.Set_field_value(txtNextdate,NextDate);
            }
        }   


        public virtual void SelectStatementGroupFromTable(string statementgroupval)
        {
            appHandle.SelectRadioButtonInTable(tableStatementGroup,"1");
            appHandle.ClickObjectViaJavaScript(buttonEdit);

        }
    }
}