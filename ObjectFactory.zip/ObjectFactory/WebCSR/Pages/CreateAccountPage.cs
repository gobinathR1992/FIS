﻿using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class CreateAccountPage
    {
        static WebApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string SubmitButton = "XPATH;//INPUT[@value='Submit']";
        private static string SingleAccountRadiobutton = "XPath;//input[@type='radio'][@value='A']";
        private static string SingleLoanAccountRadiobutton = "XPath;//input[@type='radio'][@value='1']";
        private static string NoofProductDropdown = "XPath;products[2741]";
        //private static string ProductDropdown = "Name;products[1568]";
        private string relationType = "Xpath;//input[@type='radio'][@value='A']";
        private string jointrelationType = "Xpath;//input[@type='radio'][@value='B']";
        private static string AccountNumber = "Xpath;.//*[@class='fieldLabel'][contains(.,'Account Number')]/following-sibling::td";
        private static string txtPackageMsg = "Xpath;//h2[contains(text(),'Select Package')]";
        private static string txtSelectAccountsMsg = "Xpath;//h2[contains(text(),'Select Accounts')]";
        private static string txtFirstName = "Xpath;//input[@name='firstName']";
        private static string txtLastName = "Xpath;//input[@name='lastName']";
        private static string txtEmail = "Xpath;//input[@name='email']";
        string sScheduledDepositAmount = "Xpath;//input[contains(@id,'accounts')]";
        private static string dropdownCompanyCode = "Xpath;//*[@name='companyCode']";
        private static string buttonSubmit = "XPath;//input[@name='_eventId_submit']";
        private static string buttonContinue = "XPath;//input[@name='_eventId_continue']";
        private static string tableDepositAccountRelationship = "XPath;//*[text()='Deposit Account Relationship']/ancestor::tr[1]/following-sibling::tr[1]/descendant::tbody[1]";
        private static string tableLoanAccountRelationship = "XPath;//*[text()='Loan Account Relationship']/ancestor::tr[1]/following-sibling::tr[1]/descendant::tbody[1]";
        private static string tableContent = "XPath;//*[@class='contentTable']";
        private static string ButttonCustomerSearch = "XPath;//*[@name='_eventId_search']";
        private static string txtSearchfor = "Xpath;//input[@type='text'][@name='searchTerm']";
        private static string radiobuttonCustomerSearch = "XPath;//input[@type='radio'][@value='customerNumber']";
        private static string radiobuttonCustomerFound = "XPath;//*[@class='dataTables_scrollBody']/descendant::input[@type='radio']";
        private static string tablecellOneCustomerFound = "XPath;//*[@class='dataTables_scrollBody']/descendant::td[1]";
        private static string txtAccountName = tableContent + "/descendant::table[@cellspacing='2'][1]/descendant::td[contains(text(),'Account Name')]/following-sibling::*/descendant::input[1]";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string dropdownViewAccountDetail = "XPath;//select[@name='accountNumber']";
        private static string linkAccountRelationshipAccountSummaryPage = "XPath;//td[contains(text(),'Account Relationship')]/following-sibling::td/a";
        private static string labelCustomerNumber = "XPath;//td[contains(text(),'Customer Number')]/following-sibling::td";
        private static string labelAccountNumberAccountSummaryPage = "XPath;//td[contains(text(),'Account Number')]/following-sibling::td";
        private static string buttonCollateralEdit = "XPath;//*[@class='contentTable']/descendant::h2[contains(text(),*)][1]/ancestor::tr[1]/following-sibling::tr[1]/descendant::td[contains(text(),'Collateral Type')]/following-sibling::td/input";
        private static string txtLoanCollateralAddrLine1 = "XPath;//input[@name='address.addressLine1']";
        private static string txtLoanCollateralAddrLine2 = "XPath;//input[@name='address.addressLine2']";
        private static string txtLoanCollateralCity = "XPath;//input[@name='address.city']";
        private static string dropdownLoanCollateralCountry = "XPath;//select[@name='address.country']";
        private static string dropdownLoanCollateralState = "XPath;//select[@name='address.state']";
        private static string txtLoanCollateralAddrZIPCode = "XPath;//input[@name='address.zipCode']";
        private static string txtLoanCollateralCurrentApprisalValue = "XPath;//input[@name='currentValue']";
        private static string dropdownLoanCollateralCurrencyCode = "XPath;//select[@name='currencyCode']";
        private static string txtAccountNumberPledgedCollateral = "XPath;//*[contains(text(),'Account Number')]/following-sibling::*/input[@type='text']";
        private static string checkboxMayBeReleasedPledgedCollateral = "XPAth;//*[contains(text(),'May Be Released')]/following-sibling::*/input[@type='checkbox']";
        private static string buttonSearchPledgedAccount = "XPath;//*[contains(text(),'Account Number')]/following-sibling::*/descendant::*[@type='image']";
        private static string radiobuttonCustomerNumberPledgedAccountSearch = "XPath;//*[contains(text(),'Customer Number')]/preceding-sibling::*/descendant::input";
        private static string txtSeachForPledgedAccount = "XPath;//*[contains(@name,'searchTerm')]";
        private static string txtFixedPledgedAmount = "Xpath;//*[contains(@name,'fixedPledgedAmount')]";
        private static string tableobject = "XPath;//*[@class='contentTable']/tbody";
        // public virtual void SelectRelationship()
        // {
        //     applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //     Report.Info("Select account relationship type");
        //     applicationHandle.Set_radiobutton(SingleAccountRadiobutton);
        // }

        // public virtual void SelectRelationship(string relationType )
        // {
        //     applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //     Report.Info("Select account relationship type");
        //     string relation = RelationShip(relationType);
        //     applicationHandle.Set_radiobutton(relation);
        // }

        // public virtual string RelationShip(string RelationType)
        // {
        //     switch (RelationType.ToUpper())
        //     {
        //         case "SINGLE":
        //             return relationType;
        //         case "JOINT ":
        //             return jointrelationType;

        //     }
        //     return null;
        // }

        // public virtual void ProdAccountClass(string ProdClass,string sRelationType)
        // {
        //     applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //     sRelationType = sRelationType.ToUpper();
        //     if (ProdClass.ToUpper().Equals("DEPOSIT"))
        //     {
        //         switch (sRelationType)
        //         {
        //             case "SINGLE":
        //             {
        //                applicationHandle.ClickObject(SingleAccountRadiobutton);
        //                break;
        //             }
        //             case "JOINT":
        //             {
        //                break;
        //             }
        //         }
        //     }
        //     else if (ProdClass.ToUpper().Equals("LOAN"))
        //     {
        //         switch (sRelationType)
        //         {
        //             case "SINGLE":
        //             {
        //                 applicationHandle.ClickObject(SingleLoanAccountRadiobutton);
        //                 break;  
        //             }
        //         }
        //     }


        // }
        // public virtual void select_account_relationship(string ProdClass,string sRelationType)
        // {
        //     applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //     sRelationType = sRelationType.ToUpper();
        //     if (ProdClass.ToUpper().Equals("DEPOSIT"))
        //     {
        //         switch (sRelationType)
        //         {
        //             case "SINGLE":
        //             {
        //                applicationHandle.ClickObject(SingleAccountRadiobutton);
        //                break;
        //             }
        //             case "JOINT":
        //             {
        //                break;
        //             }
        //         }
        //     }
        //     else if (ProdClass.ToUpper().Equals("LOAN"))
        //     {
        //         switch (sRelationType)
        //         {
        //             case "SINGLE":
        //             {
        //                 applicationHandle.ClickObject(SingleLoanAccountRadiobutton);
        //                 break;  
        //             }
        //         }
        //     }
        //}

        //This below method is confirmed the package page is exists while navigating to account creation.
        public virtual bool ConfirmPackagePage()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirm the Package page exists while creating account");
            bool blnSuccess = false;
            if (applicationHandle.CheckObjectExist(txtPackageMsg))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }

        //This below method is confirmed the selected accounts page is exists while navigating to account creation.  

        public virtual bool ConfirmSelectAccountsPage()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirm the select accounts page exists while creating account");
            bool blnSuccess = false;
            if (applicationHandle.CheckObjectExist(txtSelectAccountsMsg))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }

        // public virtual void SelectProduct(string noofaccounts)
        // {
        //     applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //     Report.Info("Select no of accounts for the product");
        //     applicationHandle.SelectDropdownSpecifiedValue(NoofProductDropdown, noofaccounts);

        // }

        // public virtual void SelectProduct(string productType, string noofaccounts)
        // {
        //     applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //     Report.Info("Select no of accounts for the product");
        //     //string prodType= "XPath;//table[@class='contentTable']/tbody/tr[4]/td/table/tbody/tr/td/a[.//text()='"+productType+"']/../../td[3]/select[1]";
        //     string prodType = "XPath;//tr[td[a[contains(text(),'" + productType + "')]]]//select[1]";
        //     applicationHandle.Wait_for_object(prodType, 5);
        //     applicationHandle.SelectDropdownSpecifiedValue(prodType,noofaccounts);
        // }

        public virtual void AccountDetails(string accType, string productType, string indexNo, string[] accDetails)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            string accName = "Xpath;//tr[td[contains(text(),'Account Name')]]//input[1]";
            string accAmount = "Xpath;//tr[td[contains(text(),'Amount:')]]//input[1]";
            string accTerm = "Xpath;//tr[td[contains(text(),'Term')]]//input[1]";
            string accCurrencyCode = "Xpath;//tr[td[contains(text(),'Currency Code')]]//select[1]";
            string sDisbursmentDate = "Xpath;//tr[td[contains(text(),'Disbursement Date')]]//input[1]";
            string accPaymentFrequency = "Xpath;//tr[td[contains(text(),'Payment Frequency:')]]//input[@type='text']";
            string accCollateralType = "Xpath;//tr[td[contains(text(),'Collateral Type:')]]//select[1]";
            string sAcctOpeningDate = "Xpath;//tr[td[contains(text(),'Opening Date')]]//input[1]";
            string sAcctOpeningAmount = "Xpath;//tr[td[contains(text(),'Opening Deposit')]]//input[1]";
            //string sAccountPurpose = "Xpath;//tr[td[contains(text(),'Account Purpose')]]//select[1]";
            string sFundingDepositAccount = "Xpath;//tr[td[contains(text(),'Funding Deposit Account')]]//select[1]";

            switch (accType.ToUpper())
            {
                case "LOAN":
                    applicationHandle.Wait_for_object(accName, 5);
                    applicationHandle.Set_field_value(accName, accDetails[0]);
                    applicationHandle.Set_field_value(accAmount, accDetails[1]);
                    applicationHandle.Set_field_value(accTerm, accDetails[2]);
                    applicationHandle.SelectDropdownSpecifiedValue(accCurrencyCode, accDetails[3]);
                    if (!string.IsNullOrEmpty(accDetails[4]))
                    {
                        applicationHandle.Set_field_value(sDisbursmentDate, accDetails[4]);
                    }

                    applicationHandle.Set_field_value(accPaymentFrequency, accDetails[5]);
                    if (accDetails[7] != null)
                    {
                        applicationHandle.SelectDropdownSpecifiedValue(accCollateralType, accDetails[7]);
                    }

                    // To set Collateral Type value base on Standard Product Type.
                    // if(applicationHandle.IsObjectExists(aAcctCollateralType_ForProdType_500))
                    // {
                    //     applicationHandle.SelectDropdownSpecifiedValue(aAcctCollateralType_ForProdType_500, accDetails[7]);    
                    // }
                    // else if (applicationHandle.IsObjectExists(aAcctCollateralType_ForProdType_600))
                    // {
                    //     applicationHandle.SelectDropdownSpecifiedValue(aAcctCollateralType_ForProdType_600, accDetails[7]);    
                    // }else if (applicationHandle.IsObjectExists(aAcctCollateralType_ForProdType_700))
                    // {
                    //     applicationHandle.SelectDropdownSpecifiedValue(aAcctCollateralType_ForProdType_700, accDetails[7]);    
                    // }




                    break;
                case "DEPOSIT":
                    //Details of  Deposit account information field names
                    // string[] GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES  =  new string[11];
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [0] = "DepositAccountNameField";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [1] = "DepositAccountOpeningDateField";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [2] = "DepositAccountOpeningDepositField";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [3] = "DepositAccountCurrencyCodeDropdown";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [4] = "DepositAccountFundingAccountDropdown";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [5] = "DepositAccountCorrespondentDropdown";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [6] = "DepositAccountTermField";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [7] = "DepositAccountTermDropdown";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [8] = "AccountsOverrideButton";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [9] = "DepositAccountAdvisorField";
                    // GLOBAL_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES [10] = "ScheduledDepositAmountField";

                    //string productTypeNum = null;
                    // if (productType.Contains("100"))
                    // {
                    //     productTypeNum = "100";
                    // }
                    // else if (productType.Contains("200"))
                    // {
                    //     productTypeNum = "200";
                    // }
                    // else if (productType.Contains("300"))
                    // {
                    //     productTypeNum = "300";
                    // }else if (productType.Contains("350"))
                    // {
                    //     productTypeNum = "350";
                    // }
                    // else if (productType.Contains("400"))
                    // {
                    //     productTypeNum = "400";
                    // }
                    // else if (productType.Contains("470"))
                    // {
                    //     productTypeNum = "470";
                    // }
                    //string accOpeningDate = "Name;accounts[" + productType + "][" + indexNo + "].openingDate";
                    // string sOpeningAmount = "Xpath;//input[contains(@name,'accounts[" + productTypeNum + "][" + indexNo +"].originalAmount')]";
                    // string sAcctOpeningDate = "Xpath;//input[contains(@name,'accounts[" + productTypeNum + "][" + indexNo + "].openingDate";
                    // string sTerm = "Xpath;//input[contains(@name,'accounts[" + productTypeNum + "][" + indexNo + "].term";
                    applicationHandle.Wait_for_object(accName, 5);
                    if (!string.IsNullOrEmpty(accDetails[0]))
                    {
                        if (applicationHandle.IsObjectExists(accName))
                        {
                            applicationHandle.Set_field_value(accName, accDetails[0]);
                        }
                    }
                    if (!string.IsNullOrEmpty(accDetails[1]))
                    {
                        if (applicationHandle.IsObjectExists(sAcctOpeningDate))
                        {
                            applicationHandle.Set_field_value(sAcctOpeningDate, accDetails[1]);
                        }
                    }
                    if (!string.IsNullOrEmpty(accDetails[2]))
                    {
                        if (applicationHandle.IsObjectExists(sAcctOpeningAmount))
                        {
                            applicationHandle.Set_field_value(sAcctOpeningAmount, accDetails[2]);
                        }
                    }
                    if (!string.IsNullOrEmpty(accDetails[3]))
                    {
                        if (applicationHandle.IsObjectExists(accCurrencyCode))
                        {
                            applicationHandle.SelectDropdownSpecifiedValue(accCurrencyCode, accDetails[3]);
                        }
                    }
                    if (!string.IsNullOrEmpty(accDetails[6]))
                    {
                        if (applicationHandle.IsObjectExists(accTerm))
                        {
                            applicationHandle.Set_field_value(accTerm, accDetails[6]);
                        }
                    }
                    if (!string.IsNullOrEmpty(accDetails[4]))
                    {
                        if (applicationHandle.IsObjectExists(sFundingDepositAccount))
                        {
                            applicationHandle.SelectDropdownSpecifiedValue(sFundingDepositAccount, accDetails[4]);
                        }

                    }
                    if (!string.IsNullOrEmpty(accDetails[7]))
                    {
                        if (applicationHandle.IsObjectExists(sScheduledDepositAmount))
                        {
                            applicationHandle.Set_field_value(sScheduledDepositAmount, accDetails[7]);
                        }
                    }

                    break;
                case "CD":
                    applicationHandle.Set_field_value(accTerm, accDetails[2]);
                    break;
            }
        }

        public virtual string AccountInfo()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            string actNum = applicationHandle.GetLabelText(AccountNumber);
            return actNum;
        }

        public virtual void EnterDetailsforNewCustomerInfo(string sFName, string sLName, string sEmail)
        {

            //Method to Enter the First name, Last Name and Email details.
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.Set_field_value(txtFirstName, sFName);
            appHandle.Set_field_value(txtLastName, sLName);
            appHandle.Set_field_value(txtEmail, sEmail);
            Report.Info("Entered the First Name, Last Name and Email fields details in Create Account Page.");
        }

        /// <summary>
        /// To Select Button by Index in CreateAccountCustomerSearchPage
        /// <param name="Button Name"></param>
        /// <param name="Index"></param>
        /// <returns></returns>
        /// <example>SelectButtonbyIndexinCreateAccountCustomerSearchPage("New Persona",1)</example>
        /// <example>SelectButtonbyIndexinCreateAccountCustomerSearchPage("Search",2)</example>
        public virtual void SelectButtonbyIndexinCreateAccountCustomerSearchPage(string ButtonName, int Index)
        {
            try
            {
                string obj = "Xpath;(//input[@value='" + ButtonName + "'])[" + Index.ToString() + "]";
                appHandle.WaitUntilElementVisible(obj);
                appHandle.WaitUntilElementClickable(obj);
                appHandle.SelectButton(obj);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.SelectButton(buttonSubmit);
            }
        }
        public virtual void SelectRelationshipRadiobutton_AccountCreation(string RelationType, int optioncounter1 = 0, int optionalcounter2 = 0)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableDepositAccountRelationship + "/tr[1]/descendant::input[@type='radio']"))
            {
                int index = 0, index1 = 0;
                string[] arr = null;
                string temprelationtype = "";
                int optionalcountTotal = 0;
                int flag = 2; string temp = "", temp1 = "";
                bool Execute = false;
                if (RelationType.Contains("|"))
                {
                    arr = RelationType.Split(new string[] { "|" }, StringSplitOptions.None);
                    temprelationtype = arr[0];
                    optionalcountTotal = arr.Length - 1;
                }
                else
                {
                    temprelationtype = RelationType;
                }
                string temp3 = "";
                for (int a = 1; a <= appHandle.GetRowCountfromList(tableContent + "/tbody"); a++)
                {
                    temp3 = appHandle.GetObjectText(tableContent + "/tbody/tr[" + a + "]");
                    if (temp3.Contains("Deposit Account Relationship"))
                    {
                        if (appHandle.GetObjectText(tableContent + "/tbody/tr[" + (a + 1) + "]").Contains(temprelationtype))
                        {
                            flag = 1;
                            Execute = true;
                            break;
                        }

                    }
                    else
                    {
                        if (temp3.Contains("Loan Account Relationship"))
                        {
                            if (appHandle.GetObjectText(tableContent + "/tbody/tr[" + (a + 1) + "]").Contains(temprelationtype))
                            {
                                flag = 0;
                                Execute = true;
                                break;
                            }
                        }

                    }
                    if (a == appHandle.GetRowCountfromList(tableContent + "/tbody"))
                    {
                        break;
                    }
                }

                if (Execute == false)
                {
                    Report.Fail("Account creation can not be completed as the specified relationship i.e. " + temprelationtype + " is not present in relationship page", "true", appHandle, true);
                }
                else
                {
                    if (flag == 1)
                    {
                        Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableDepositAccountRelationship);
                        int rowscount = appHandle.GetRowCountfromList(tableDepositAccountRelationship);
                        for (int i = 1; i <= rowscount; i++)
                        {
                            temp = appHandle.GetObjectText(tableDepositAccountRelationship + "/tr[" + i + "]");

                            if (temp.Trim().Contains(temprelationtype.Trim()))
                            {
                                index = i;
                                flag = 1;
                                break;
                            }

                        }
                    }

                    if (flag == 0)
                    {

                        int rowscount1 = appHandle.GetRowCountfromList(tableLoanAccountRelationship);
                        for (int j = 1; j <= rowscount1; j++)
                        {
                            temp1 = appHandle.GetObjectText(tableLoanAccountRelationship + "/tr[" + j + "]");
                            if (temp1.Trim().Contains(temprelationtype.Trim()))
                            {
                                index1 = j;
                                break;
                            }

                        }
                    }

                    if (index != 0)
                    {
                        appHandle.ClickObjectViaJavaScript(tableDepositAccountRelationship + "/tr[" + index + "]/descendant::input[@type='radio']");
                        if (optionalcountTotal != 0)
                        {
                            for (int k = 1; k <= optionalcountTotal; k++)
                            {
                                appHandle.SelectDropdownSpecifiedValue(tableDepositAccountRelationship + "/tr[" + index + "]/descendant::input[@type='radio']/ancestor::td[1]/following-sibling::td[1]/descendant::select[" + k + "]", arr[k]);
                            }
                        }

                        Report.Info("Account relationship is selected.", "relationshipacctcreation", "true", appHandle);
                    }

                    if (index1 != 0)
                    {
                        appHandle.ClickObjectViaJavaScript(tableLoanAccountRelationship + "/tr[" + index1 + "]/descendant::input[@type='radio']");
                        if (optionalcountTotal != 0)
                        {
                            for (int s = 1; s <= optionalcountTotal; s++)
                            {
                                appHandle.SelectDropdownSpecifiedValue(tableLoanAccountRelationship + "/tr[" + index1 + "]/descendant::input[@type='radio']/ancestor::td[1]/following-sibling::td[1]/descendant::select[" + s + "]", arr[s]);
                            }
                        }

                        Report.Info("Account relationship is selected.", "relationshipacctcreation", "true", appHandle);
                    }
                }

            }
        }

        public virtual void ClickOnContinueButton()
        {
//  string tempText = appHandle.GetObjectText(tableobject);

//             if (tempText.Contains(Data.Get("Anticipated Run")))
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonContinue))
            {
                appHandle.ClickObjectViaJavaScript(buttonContinue);
            }
        }
        public virtual bool VerifyOwnerPageLoadsAccountCreation()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonContinue))
            {
                result = true;
            }
            return result;
        }
        public virtual void UpdateOwnerDetails(string RelationType, string CustomerNumbersForAdditionalOwnerAddition = "")
        {
            string temprelationtype = "";
            int tempcount = 0;

            if (!CustomerNumbersForAdditionalOwnerAddition.Contains("|"))
            {
                tempcount = 1;
            }
            else
            {
                tempcount = CustomerNumbersForAdditionalOwnerAddition.Split(new string[] { "|" }, StringSplitOptions.None).Length;
            }

            string[] arr = null;
            if (RelationType.Contains("|"))

            {
                arr = RelationType.Split(new string[] { "|" }, StringSplitOptions.None);
                temprelationtype = arr[0].Trim();
            }
            else
            {
                temprelationtype = RelationType;
            }
            switch (temprelationtype)
            {
                case "Single":
                    break;
                case "Joint (Or)":
                    this.SelectCustomerInOwnerPage(CustomerNumbersForAdditionalOwnerAddition);
                    break;
                case "Joint with primary borrower":
                    this.SelectCustomerInOwnerPage(CustomerNumbersForAdditionalOwnerAddition);
                    break;
            }

        }
        public virtual void SelectCustomerInOwnerPage(string CustNames)
        {
            int tempcount = 0;
            if (!CustNames.Contains("|"))
            {
                tempcount = 1;
            }
            else
            {
                tempcount = CustNames.Split(new string[] { "|" }, StringSplitOptions.None).Length;
            }
            if (CustNames.Contains("|"))
            {

                for (int j = 0; j <= tempcount - 1; j++)
                {
                    appHandle.ClickObjectViaJavaScript(tableContent + "/tbody/descendant::*[@class='summaryTableHeading'][" + (j + 2) + "]/ancestor::tr[1]/following-sibling::tr/descendant::*[@name='_eventId_customerSearch']");
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonCustomerSearch))
                    {
                        appHandle.ClickObjectViaJavaScript(radiobuttonCustomerSearch);
                        appHandle.Set_field_value(txtSearchfor, CustNames.Split(new string[] { "|" }, StringSplitOptions.None)[j]);
                        appHandle.ClickObjectViaJavaScript(ButttonCustomerSearch);
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonCustomerFound))
                        {

                            appHandle.ClickObjectViaJavaScript(radiobuttonCustomerFound);
                        }

                        this.VerifyOwnerPageLoadsAccountCreation();

                        Report.Info("Additional Customer data is entered", "Additionalcustadd", "true", appHandle);
                    }
                }
            }
            else
            {
                appHandle.ClickObjectViaJavaScript(tableContent + "/tbody/descendant::*[@class='summaryTableHeading'][2]/ancestor::tr[1]/following-sibling::tr/descendant::*[@name='_eventId_customerSearch']");
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonCustomerSearch))
                {
                    appHandle.ClickObjectViaJavaScript(radiobuttonCustomerSearch);
                    appHandle.Set_field_value(txtSearchfor, CustNames);
                    appHandle.ClickObjectViaJavaScript(ButttonCustomerSearch);
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonCustomerFound))
                    {

                        appHandle.ClickObjectViaJavaScript(radiobuttonCustomerFound);
                    }
                    string x = appHandle.GetObjectText(tablecellOneCustomerFound);
                    this.VerifyOwnerPageLoadsAccountCreation();
                    Report.Info("Additional Customer data is entered", "Additionalcustadd", "true", appHandle);
                }
            }
        }
        public virtual void SelectProductAndNumberOfAccounts(string Productname, int NumberOfAccounts)
        {
            string prodLinkObj = "XPath;//a[contains(text(),'" + Productname.Trim() + "')]";
            string NumberOfAcctDropdown = prodLinkObj + "/ancestor::tr[1]/descendant::td/select[1]";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(NumberOfAcctDropdown))
            {
                appHandle.SelectDropdownSpecifiedValue(NumberOfAcctDropdown, NumberOfAccounts + "");
                Report.Info("Product type and number of accounts are entered.", "prodacctnumber", "true", appHandle);
            }
        }
        public virtual void EnterAccountDetails(string AccountDetails = "", int numberofEntries = 1, string ProductType = "")
        {
            string temptext = "";
            string temp = "", FieldName = "";
            string[] arr = null;
            bool stat = false;

            temp = appHandle.GetSpecifiedObjectAttribute(txtAccountName, "value").Replace(" ", string.Empty);

            // appHandle.Set_field_value(tableContent + "/descendant::table[@cellspacing='2'][" + j + "]/descendant::td[contains(text(),'Account Name')]/following-sibling::*/descendant::input[1]", temp+"|"+j+"");
            if (numberofEntries == 1)
            {
                if (AccountDetails.Split('|').Length - 1 == 1)
                {
                    appHandle.Set_field_value(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + AccountDetails.Split('|')[0].Trim() + "')]/following-sibling::td/input[1]", AccountDetails.Split('|')[1].Trim());
                }
                // appHandle.Set_field_value(txtAccountName, temp + "-1");
            }
            // else
            // {
            //     for (int j = 1; j <= numberofEntries; j++)
            //     {
            //         appHandle.Set_field_value(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'Account Name')]/following-sibling::td/input[1]", temp + "-" + j + "");


            //     }
            // }
            if (string.IsNullOrEmpty(AccountDetails))
            {
                appHandle.Set_field_value(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'Account Name')]/following-sibling::td/input[1]", temp + "-1");
                Report.Info("Account Details are entered successfully.", "dataentry", "true", appHandle);

            }
            else
            {
                if (AccountDetails.Contains(";"))
                {

                    arr = AccountDetails.Split(new string[] { ";" }, StringSplitOptions.None);
                    for (int i = 0; i < arr.Length; i++)
                    {


                        FieldName = arr[i].Split('|')[0];
                        if (temptext.Contains(FieldName + "-Done"))
                        {
                            continue;
                        }

                        stat = this.AccountDetailMultipleEntry(FieldName, AccountDetails, numberofEntries, ProductType);
                        if (stat)
                        {
                            temptext = temptext + "#" + FieldName + "-Done";
                        }

                    }
                }
                else
                {
                    appHandle.Set_field_value(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/input[1]", AccountDetails.Split('|')[1].Trim());
                }
                Report.Info("Account Details are entered successfully.", "dataentry", "true", appHandle);

            }

        }
        public virtual void SelectDropdownValueByAttributeValue(string dropdownobj, string itemtobeselected)
        {
            int optionscount = appHandle.GetRowCountfromList(dropdownobj);
            string temp = "";
            for (int i = 1; i <= optionscount; i++)
            {
                temp = appHandle.GetSpecifiedObjectAttribute(dropdownobj, "value");
                if (temp.Contains(itemtobeselected))
                {
                    appHandle.SelectDropdownSpecifiedValueByIndex(dropdownobj, i);
                    break;
                }
            }
        }


        public virtual bool AccountDetailMultipleEntry(string FieldName, string AccountDetails, int numberofentries, string ProductType)
        {
            string inputtoenter = "";
            bool entered = false;
            int enteredcount = 0;
            string buttonCollateralEditRunTime = "";
            string currentValueRealEstateMortgage = "";

            string temp = appHandle.GetSpecifiedObjectAttribute(txtAccountName, "value").Replace(" ", string.Empty);

            string[] arr = AccountDetails.Split(new string[] { ";" }, StringSplitOptions.None);


            for (int x = 0; x < arr.Length; x++)
            {


                if (arr[x].Contains(FieldName))
                {
                    if (entered) { }
                    else
                    {
                        if (numberofentries > 1)
                        {
                            for (int j = 1; j <= numberofentries; j++)
                            {

                                if (AccountDetails.Split(new string[] { FieldName }, StringSplitOptions.None).Length - 1 > 1)
                                {
                                    for (int y = 0; y < arr.Length; y++)
                                    {
                                        if (arr[y].Contains(FieldName))
                                        {
                                            inputtoenter = inputtoenter + ";" + arr[y];
                                        }
                                    }
                                    inputtoenter = inputtoenter.Substring(1, inputtoenter.Length - 1);
                                    for (int z = 0; z < inputtoenter.Split(';').Length; z++)
                                    {
                                        if (inputtoenter.Split(';')[z].Split('|')[1].Contains(Data.Get("BLANK")))
                                        {
                                            appHandle.Set_field_value(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/descendant::input[1]", "");
                                            enteredcount++;
                                            j++;
                                            continue;
                                        }
                                        if (string.IsNullOrEmpty(inputtoenter.Split(';')[z].Split('|')[1].Trim()))
                                        {
                                            enteredcount++;
                                            j++;
                                            continue;
                                        }
                                        if (FieldName.Equals(Data.Get("Currency Code")))
                                        {
                                            appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)inputtoenter.Split(';')[z].Split('|')[1].Trim());
                                            enteredcount++;
                                            j++;
                                        }
                                        else if (FieldName.Equals(Data.Get("Funding Deposit Account"))
                                        || FieldName.Equals(Data.Get("Internal Source Account")))
                                        {
                                            this.SelectDropdownValueByAttributeValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)inputtoenter.Split(';')[z].Split('|')[1].Trim());
                                            enteredcount++;
                                            j++;
                                        }
                                        else if (FieldName.Equals(Data.Get("Collateral Type")))
                                        {
                                            if (inputtoenter.Contains("##"))
                                            {

                                                currentValueRealEstateMortgage = inputtoenter.Split(';')[z].Split('|')[1].Split(new string[] { "##" }, StringSplitOptions.None)[1];

                                            }
                                            if ((inputtoenter.Split(';')[z].Split('|')[1].Trim().Contains(Data.Get("10 - Real Estate Property"))))
                                            {
                                                appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)Data.Get("10 - Real Estate Property"));
                                                buttonCollateralEditRunTime = tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr[1]/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/input[1]";
                                                this.EnterDetailsForRealEstateCollateral(buttonCollateralEditRunTime, currentValueRealEstateMortgage);
                                                enteredcount++;
                                                j++;
                                            }
                                            else if ((inputtoenter.Split(';')[z].Split('|')[1].Trim().Contains(Data.Get("70 - Pledged Accounts"))))
                                            {
                                                appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)Data.Get("70 - Pledged Accounts"));
                                                buttonCollateralEditRunTime = tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr[1]/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/input[1]";
                                                this.EnterDetailsForPledgedAccountsCollateral(buttonCollateralEditRunTime, currentValueRealEstateMortgage);
                                                enteredcount++;
                                                j++;
                                            }
                                            else
                                            {
                                                appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)Data.Get("0 - Unsecured"));
                                                enteredcount++;
                                                j++;
                                            }
                                        }

                                        else
                                        {
                                            appHandle.Set_field_value(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][" + j + "]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/input[1]", inputtoenter.Split(';')[z].Split('|')[1].Trim());
                                            enteredcount++;
                                            j++;
                                        }

                                    }
                                    for (int k = 1; k <= inputtoenter.Split(';').Length; k++)
                                    {
                                        j--;
                                    }
                                    if (enteredcount == inputtoenter.Split(';').Length)
                                    {
                                        entered = true;
                                        break;
                                    }
                                }
                                else
                                {
                                    if (FieldName.Equals(Data.Get("Currency Code")))
                                    {
                                        appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)arr[x].Split('|')[1].Trim());

                                        entered = true;
                                        break;
                                    }
                                    else if (FieldName.Equals(Data.Get("Funding Deposit Account"))
                                        || FieldName.Equals(Data.Get("Internal Source Account")))
                                    {
                                        this.SelectDropdownValueByAttributeValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)arr[x].Split('|')[1].Trim());
                                        entered = true;
                                        break;
                                    }
                                    else if (FieldName.Equals(Data.Get("Collateral Type")))
                                    {
                                        if (arr[x].Contains("##"))
                                        {
                                            currentValueRealEstateMortgage = arr[x].Split(new string[] { "##" }, StringSplitOptions.None)[1];
                                            arr[x] = inputtoenter.Split(new string[] { "##" }, StringSplitOptions.None)[0];
                                        }
                                        if (arr[x].Split('|')[1].Trim().Equals(Data.Get("10 - Real Estate Property")))
                                        {
                                            appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)arr[x].Split('|')[1].Trim());
                                            buttonCollateralEditRunTime = tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr[1]/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/input[1]";
                                            this.EnterDetailsForRealEstateCollateral(buttonCollateralEditRunTime, currentValueRealEstateMortgage);
                                            entered = true;
                                            break;
                                        }
                                        else if (arr[x].Split('|')[1].Trim().Equals(Data.Get("70 - Pledged Accounts")))
                                        {
                                            appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)arr[x].Split('|')[1].Trim());
                                            buttonCollateralEditRunTime = tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr[1]/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/input[1]";
                                            this.EnterDetailsForPledgedAccountsCollateral(buttonCollateralEditRunTime, currentValueRealEstateMortgage);
                                            entered = true;
                                            break;
                                        }

                                        else
                                        {
                                            appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)Data.Get("0 - Unsecured"));
                                            entered = true;
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        appHandle.Set_field_value(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/*[1]", arr[x].Split('|')[1].Trim());
                                        entered = true;
                                        break;
                                    }
                                }
                            }

                        }
                        else
                        {
                            if (FieldName.Equals(Data.Get("Currency Code")))
                            {
                                appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)arr[x].Split('|')[1].Trim());
                                entered = true;
                            }
                            else if (FieldName.Equals(Data.Get("Funding Deposit Account"))
                               || FieldName.Equals(Data.Get("Internal Source Account")))
                            {
                                this.SelectDropdownValueByAttributeValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)arr[x].Split('|')[1].Trim());
                                entered = true;
                                break;
                            }
                            else if (FieldName.Equals(Data.Get("Collateral Type")))
                            {
                                if (arr[x].Contains("##"))
                                {
                                    currentValueRealEstateMortgage = arr[x].Split(new string[] { "##" }, StringSplitOptions.None)[1];
                                    arr[x] = arr[x].Split(new string[] { "##" }, StringSplitOptions.None)[0];
                                }
                                if (arr[x].Split('|')[1].Trim().Equals(Data.Get("10 - Real Estate Property")))
                                {
                                    appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)arr[x].Split('|')[1].Trim());
                                    buttonCollateralEditRunTime = tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr[1]/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/input[1]";
                                    this.EnterDetailsForRealEstateCollateral(buttonCollateralEditRunTime, currentValueRealEstateMortgage);
                                    entered = true;
                                    break;
                                }
                                else if (arr[x].Split('|')[1].Trim().Equals(Data.Get("70 - Pledged Accounts")))
                                {
                                    appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)arr[x].Split('|')[1].Trim());
                                    buttonCollateralEditRunTime = tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr[1]/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/input[1]";
                                    this.EnterDetailsForPledgedAccountsCollateral(buttonCollateralEditRunTime, currentValueRealEstateMortgage);
                                    entered = true;
                                    break;
                                }


                                else
                                {
                                    appHandle.SelectDropdownSpecifiedValue(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/select[1]", (string)Data.Get("0 - Unsecured"));
                                    entered = true;
                                    break;
                                }
                            }
                            else

                            {
                                
                                appHandle.Set_field_value(tableContent + "/descendant::h2[contains(text(),'" + ProductType + "')][1]/ancestor::tr[1]/following-sibling::tr/descendant::td[contains(text(),'" + FieldName + "')]/following-sibling::td/descendant::input[1]", arr[x].Split('|')[1].Trim());
                                entered = true;
                            }
                        }
                    }
                }
            }

            return entered;
        }
        public virtual bool VerifyAccountCreationSuccess()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_APPLICATION_SUCCESSFULLY_PROCESSED")))
            {
                Result = true;
            }

            return Result;
        }
        public virtual void LoadAccountSummary(string AccountNumber, int numberOfAccounts = 1)
        {

            string temp = "";
            string[] arr = null;
            int selectioncount = 0;

            int optionscount = appHandle.GetRowCountfromList(dropdownViewAccountDetail);
            for (int i = 1; i <= optionscount; i++)
            {
                temp = appHandle.GetSpecifiedObjectAttribute(dropdownViewAccountDetail + "/option[" + i + "]", "value");
                if (AccountNumber.Contains("-"))
                {
                    arr = AccountNumber.Split('-');
                    for (int j = 0; j < arr.Length; j++)
                    {
                        if (temp.Equals(arr[j]))
                        {
                            appHandle.SelectDropdownValueByIndex(dropdownViewAccountDetail, i);
                            if (VerifyAccountSummaryPageLoads())
                            {
                                if (appHandle.GetObjectText(labelAccountNumberAccountSummaryPage).Equals(arr[j]))
                                {
                                    selectioncount++;
                                    Report.Pass(arr[j] + " is loaded successfully", "accountsummaryload", "true", appHandle);
                                }
                            }

                        }
                        if (selectioncount == arr.Length)
                        {
                            break;
                        }
                    }

                }
                else
                {
                    if (temp.Equals(AccountNumber))
                    {
                        appHandle.SelectDropdownValueByIndex(dropdownViewAccountDetail, i);
                        if (VerifyAccountSummaryPageLoads())
                        {
                            if (appHandle.GetObjectText(labelAccountNumberAccountSummaryPage).Equals(AccountNumber))
                            {
                                Report.Pass(AccountNumber + " is loaded successfully", "accountsummaryload", "true", appHandle);
                                break;
                            }
                        }
                    }
                }
            }
        }
        public virtual string GetAccountNumbersFromApplicationSuccessPage(int numberOfAccounts = 1)
        {
            List<string> accountsList = new List<string>();
            string AccountNumber = "";
            if (numberOfAccounts > 1)
            {
                for (int x = 1; x <= numberOfAccounts; x++)
                {
                    accountsList.Add(appHandle.GetObjectText(tableContent + "/descendant::td[contains(text(),'Account Number')][" + x + "]/following-sibling::td[1]"));
                }
                AccountNumber = string.Join("-", accountsList);
            }
            else if (numberOfAccounts == 1)
            {
                AccountNumber = appHandle.GetObjectText(tableContent + "/descendant::td[contains(text(),'Account Number')][1]/following-sibling::td[1]");
            }

            return AccountNumber;
        }
        public virtual bool VerifyAccountSummaryPageLoads()
        {
            bool res = Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkAccountRelationshipAccountSummaryPage);
            return res;
        }
        public virtual bool VerifyCustomerNumberForAcctCreation(string customerNumber)
        {
            bool result = false;
            if (appHandle.GetObjectText(labelCustomerNumber).Equals(customerNumber))
            {
                result = true;
            }
            return result;
        }

        public virtual void EnterDetailsForRealEstateCollateral(string buttonCollateralEditRunTime, string currentValueRealEstateMortgage, int numberOFAccounts = 1)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCollateralEditRunTime);
            appHandle.ClickObjectViaJavaScript(buttonCollateralEditRunTime);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.Set_field_value(txtLoanCollateralAddrLine1, Data.Get("Central Real Estate"));
            appHandle.Set_field_value(txtLoanCollateralAddrLine2, Data.Get("456 Street"));
            appHandle.Set_field_value(txtLoanCollateralCity, Data.Get("Jacksonville"));
            appHandle.SelectDropdownSpecifiedValue(dropdownLoanCollateralCountry, (string)Data.Get("US - UNITED STATES OF AMERICA"));
            appHandle.SelectDropdownSpecifiedValue(dropdownLoanCollateralState, (string)Data.Get("FL - FLORIDA"));
            appHandle.Set_field_value(txtLoanCollateralAddrZIPCode, Data.Get("32256"));
            appHandle.Set_field_value(txtLoanCollateralCurrentApprisalValue, currentValueRealEstateMortgage);
            Report.Info("Collateral Type - Real Estate details are entered .", "realestatedata", "true", appHandle);
            this.ClickOnSubmitButton();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCollateralEdit);
        }
        public virtual void EnterDetailsForPledgedAccountsCollateral(string buttonCollateralEditRunTime, string PledgedAccountNumber)
        {
            string CustomerNumber = PledgedAccountNumber.Split(':')[1];
            string AccountNumber = PledgedAccountNumber.Split(':')[0];
            string AmountToBePledged = PledgedAccountNumber.Split(':')[2];
            string runtimeSearchRadioButton = "XPath;//*[contains(@id,'accounts-list')]/descendant::*[contains(text(),'" + AccountNumber + "')]/preceding-sibling::*/input[@type='radio']";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCollateralEditRunTime);
            appHandle.ClickObjectViaJavaScript(buttonCollateralEditRunTime);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearchPledgedAccount))
            {
                appHandle.ClickObjectViaJavaScript(buttonSearchPledgedAccount);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(radiobuttonCustomerNumberPledgedAccountSearch);
                appHandle.ClickObjectViaJavaScript(radiobuttonCustomerNumberPledgedAccountSearch);
                appHandle.Set_field_value(txtSeachForPledgedAccount, CustomerNumber);
                appHandle.ClickObjectViaJavaScript(ButttonCustomerSearch);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(runtimeSearchRadioButton);
                Report.Info("Pledged Customer number and account number is searched.", "pledgedcustaccount", "true", appHandle);
                appHandle.ClickObjectViaJavaScript(runtimeSearchRadioButton);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearchPledgedAccount);
            }
            appHandle.Set_field_value(txtFixedPledgedAmount, AmountToBePledged);
            appHandle.ClickObjectViaJavaScript(checkboxMayBeReleasedPledgedCollateral);
            Report.Info("Collateral Type - Pledged Account details are entered .", "realestatedata", "true", appHandle);
            this.ClickOnSubmitButton();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCollateralEdit);
        }


    }
}

