﻿using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Util;
using Profile7Automation.Libraries.Util;
using System;

using System.Windows.Forms;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class LoginWindow
    {
        private static Object tellerLoginWindowName = "jp2launcher;Teller Authentication";
        private static string buttonMaximize = "Name=Maximize;ControlType=Button;AutomationId=Maximize";
        private static string WindowTellerHome = "jp2launcher;Profile Teller";
        private static Object UserID = "Text=User ID:;ClassName=Edit";
        private static Object Password = "Text=Password:;ClassName=Edit";
        private static string LoginBtn = "Text=Login;ClassName=Button";
        private static string OkBtn = "Text=OK;ClassName=Button";
        private static string Branch = "ControlType=Edit";
        private static Object AllowBtn = "Allow";
        private static string ButtonQuit = "Text=Quit;ClassName=Button";
        public static Object SecurityWindow = "Internet Explorer Security";

        // Following two lines are commented as Image files need to be taken from Rajib
        //  public static Object RunBtn = GTS_OSAF.TestBase.GetImagePath("SecurityWarning_RunButton.PNG");
        // public static Object WarningCheckBox = GTS_OSAF.TestBase.GetImagePath("SecurityWarningCheckBox.PNG");
        Object SecurityWarningWindowName = "jp2launcher;Security Warning";
        // Object ButtonSecurityWarningContinue=
        private static string SecurityTitleBar = "Name=Security Warning;ControlType=TitleBar";
        private static WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);

        public virtual bool Login(String userId, String password, String branch = "")
        {
            bool Result = false;
            string applnName = StartupConfiguration.EnvironmentDetails.TellerApplicationName;
 
            string sBaseURL = BaseURLGenerator.Generate(applnName);
            string TellerURL = applicationHandle.GetJavaPath() + @"\Bin\javaws.exe" + "\"" + " " + sBaseURL;
            applicationHandle.RunCommandLineCode(TellerURL);

            if (Profile7CommonLibrary.WaitUntilWindowLoads((string)SecurityWarningWindowName))
            {
                SendKeys.SendWait("{TAB}");
                SendKeys.SendWait("{TAB}");
                SendKeys.SendWait("{ENTER}");
            }
                       bool LoginWindowLoaded = false;
            do
            {
                LoginWindowLoaded = Profile7CommonLibrary.WaitUntilWindowLoads((string)tellerLoginWindowName);
            }
            while (LoginWindowLoaded == false);
 
            applicationHandle.SetFieldValue(UserID, userId);
            applicationHandle.SetFieldValue(Password, password);
            applicationHandle.ClickObeject(LoginBtn);

            bool flag = true;
            try
            {
                do
                {

                    flag = (bool)applicationHandle.GetObjectProperty(LoginBtn, ObjectProperty.IsEnable);
                   if(flag){ applicationHandle.ClickObeject(LoginBtn);}
                }
                while (flag == true);
            }
            catch (Exception e) { };

            bool SelectBranchWindowLoaded = false;
            do
            {
                SelectBranchWindowLoaded = Profile7CommonLibrary.WaitUntilWindowLoads((string)tellerLoginWindowName);
            }
            while (SelectBranchWindowLoaded == false);
            applicationHandle.WaitForObject(OkBtn, 12);
            if (string.IsNullOrEmpty(branch))
            {
                branch = Data.Get("GLOBAL_BRANCH");
                applicationHandle.SetFieldValue(Branch, branch);
            }
            else
            {
                applicationHandle.SetFieldValue(Branch, branch);
            }
            applicationHandle.SelectButton(OkBtn);
            bool AppLaunched = false;
            AppLaunched = false;
            do
            {
                AppLaunched = Profile7CommonLibrary.WaitUntilWindowLoads(WindowTellerHome);
            }
            while (AppLaunched == false);

            Result = AppLaunched;

            return Result;
}
        public virtual bool VerifyPresenceOfProfileTellerWindow()
        {
            bool result = false;
            result = applicationHandle.Launch_Application(WindowTellerHome, 5, false, true);
            return result;
        }
    }
}
