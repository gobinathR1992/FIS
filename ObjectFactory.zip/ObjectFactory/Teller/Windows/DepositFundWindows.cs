﻿using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Threading;
using Profile7Automation.Libraries.Util;
using System.Windows.Forms;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class DepositFundWindows
    {

        static WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private string tellerWindowName = "jp2launcher;" + "Profile Teller";
        private string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
        private string tabTransactionList = "Control Type=TabItem;Text=Transaction List";
        private string tableHeaderTransactionList = "Control Type=HeaderItem;Name=Base Eq Amount";
        private static string txtAccountNumber = "ClassName=Edit;AutomationId=1001;Name=Account Number";
        private static string AmountText = "ClassName=Edit;Index=1";
        private static string txtDepositAmount = "ClassName=Edit;Text=Deposit Amount: ";
        private static string AccBalance = "ClassName=Static;ClassName=Text;Index=23";
        private static String Window = "Print Receipt";
        private static Object YesBtn = "ClassName=Button;Text=Yes";
        private static Object NoBtn = "ClassName=Button;Text=No";
        //private static String AccountName = "ClassName=Text;Text=Account Name:";
        Object screenShotName1 = "TellerdepositScreen";
        Object screenShotName2 = "TellerScreenAfterDeposit";
        private static string txtFundsCurrency = "ClassName=Edit;Index=2";
        private static string dropdownTransactionCurrency = "ClassName=ComboBox;Index=1";
        private static string txtDepositAmountCurrency = "ClassName=Edit;Index=4";
        public static string buttonRedFlag = "Text=Deposit Amount: ;LabelRelationShip=" + LabelRelationShip.NthSibling + ";3";
        public static string imgRedFlag = "Control Type=ControlType.Button;AutomationId=200680";
        public static string txtNotes = "ControlType=Document;Index=0";
        public static string buttonOK = "Text=OK";
        private static string TransactionDetailWindow = "jp2launcher;Transaction Detail";
        private static string dropdownReasonCode1 = "ControlType=ComboBox;Index=0";
        private static string dropdownReasonCode2 = "ControlType=ComboBox;Index=2";
        private static string TabChecks = "ControlType=TabItem;Text=Checks";
        private static string labelContributioncode = "AutomationId=265148;Name=Contribution Code";
        private static string labelMilitaryCombatZone = "AutomationId=265146;Name=Military Combat Zone";
        private static string labelBeneficiary = "Beneficiary";
        private static string txtWithholdingPercentage = "ControlType=Edit;Index=1";


        public virtual void DepositFund(string AccountNo, string Amount)
        {

            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);

            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                applicationHandle.ClickObeject(MasterWindow.btnstatus);
                applicationHandle.Sendkeys("{F1}");
                Thread.Sleep(3000);
                applicationHandle.SetFieldValue(txtAccountNumber, AccountNo);
                applicationHandle.Sendkeys("{TAB}");
                applicationHandle.SetFieldValue(AmountText, Amount);
                applicationHandle.SetFieldValue(txtDepositAmount, Amount);
                Report.Info("Information added to screen", screenShotName1, "True", applicationHandle);
                applicationHandle.Sendkeys("{F12}");
                Thread.Sleep(2000);
                applicationHandle.PerformActionOnDialogWindow(Window, NoBtn, new GTS_OSAF.CoreLibs.Action(ActionToPerform.Click));
                Thread.Sleep(6);
                Report.Pass("Transaction posted", screenShotName2, "True", applicationHandle);
            }
            else
            {
                Report.Fail("Unable to launch application");
                throw new Exception("Unable to launch application");
            }
        }

        public virtual void enter_teller_deposit_details(string sEffectiveDate, string[] arrActionEntries)
        {
            //applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);

            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                // string sTellerApplnDate = TellerPageFactory.MasterWindow.get_pd_teller_application_date();
                // if (! sTellerApplnDate.Equals(sEffectiveDate))
                // {
                //     TellerPageFactory.MasterWindow.set_effective_date(sEffectiveDate);
                //     Report.Info("Changed the Effective Date.");
                // }
                applicationHandle.Wait_For_Specified_Time(1);
                applicationHandle.ClickObeject(MasterWindow.btnstatus);
                applicationHandle.Sendkeys("{F1}");
                applicationHandle.IsObjectExists(txtDepositAmount);
                applicationHandle.SetFieldValue(txtAccountNumber, arrActionEntries[0]);
                //applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("TAB"));
                applicationHandle.Sendkeys("{TAB}");
                applicationHandle.SetFieldValue(AmountText, arrActionEntries[1]);
                applicationHandle.SetFieldValue(txtDepositAmount, arrActionEntries[3]);
                Report.Info("Information added to screen", screenShotName1, "True", applicationHandle);

                string sBalanceValue = applicationHandle.GetTextFromField(AccBalance.ToString());
                if (sBalanceValue.Equals("0.00"))
                {
                    Report.Info("Transaction is balanced.");
                }
                else
                {
                    Report.Info("Transaction is not balanced.");
                }
            }
            else
            {
                Report.Fail("Unable to launch application");
                throw new Exception("Unable to launch application");
            }
        }
        public virtual bool EnterDepositFundDetails(string AccountNumber, string Amount, string Currency = "", bool IsOverride = false)
        {
            bool Result = false;
            bool x = Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName);
            Profile7CommonLibrary.VerifyWindowObjectExists(txtAccountNumber);
            applicationHandle.SetFieldValue(txtAccountNumber, AccountNumber);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation);
            applicationHandle.SetFieldValue(AmountText, Amount);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Text=USD", Currency, false);

            }
            Profile7CommonLibrary.VerifyWindowObjectExists(txtDepositAmount);
            applicationHandle.SetFieldValue(txtDepositAmount, Amount);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;
        }
        public virtual bool VerifyDepositFundTabClosedAfterTransaction()
        {
            bool x = applicationHandle.Launch_Application(tellerWindowName);

            bool Result = false;
            try
            {
                if (Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation))
                {
                    Result = true;
                }
            }
            catch (Exception e)
            {
                Result = false;
            }
            return Result;
        }

        public virtual void ClickOnRedFlag()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            Profile7CommonLibrary.VerifyWindowObjectExists(buttonRedFlag);
            applicationHandle.ClickObeject(buttonRedFlag);

        }
        public virtual void EnterWithHoldingDetails(string taxrate="")
        {
            if (applicationHandle.IsObjectExists(buttonRedFlag))
            {
                ClickOnRedFlag();
                if(!string.IsNullOrEmpty(taxrate))
                {
                    applicationHandle.SetFieldValue(txtWithholdingPercentage, taxrate);
                }
                string randdata = applicationHandle.CreateRamdomData(FieldType.NUMERIC, 100, 999).ToString();
                applicationHandle.SetFieldValue(txtNotes, "Note" + randdata);
                applicationHandle.ClickObeject(buttonOK);
            }
        }

        public virtual bool EnterIRAContributionTransactionDetails(string AccountNumber, string ContrCode1, string ContrCode2, string Amount1, string Amount2)
        {
            bool Result = false;
            Profile7CommonLibrary.WaitUntilWindowLoads(TransactionDetailWindow);
            applicationHandle.SelectDropdownSpecifiedValue(dropdownReasonCode1, ContrCode1);
            string runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode1, ObjectProperty.AutomationId);
            runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";4", ObjectProperty.AutomationId);
            applicationHandle.ClickObeject("Text=Forward by small amount");
            applicationHandle.SelectContextMenuItem("Text=Forward by small amount", true, "Scroll Here");
            applicationHandle.SetFieldValue("AutomationId=" + runtimeAutoID, Amount1);
            runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.NthSibling + ";2", ObjectProperty.AutomationId);
            applicationHandle.ClickObeject("AutomationId=" + runtimeAutoID);
            applicationHandle.ClickObeject("Text=Back by small amount");
            applicationHandle.SelectContextMenuItem("Text=Back by small amount", true, "Scroll Here");
            applicationHandle.SelectDropdownSpecifiedValue(dropdownReasonCode2, ContrCode2);
            runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode2, ObjectProperty.AutomationId);
            if (ContrCode2.Equals(Data.Get("120 - Postponed Contribution")))
            {
                string yearpart = applicationHandle.GetDateParameters(Profile7CommonLibrary.GetApplicationDate())[2];
                applicationHandle.SetFieldValue("AutomationId=" + (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";3", ObjectProperty.AutomationId), yearpart);
            }
            applicationHandle.ClickObeject("Text=Forward by small amount");
            applicationHandle.SelectContextMenuItem("Text=Forward by small amount", true, "Scroll Here");
            runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode2, ObjectProperty.AutomationId);

            if (ContrCode2.Equals(Data.Get("120 - Postponed Contribution")))
            {
                applicationHandle.SetFieldValue("AutomationId=" + (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";5", ObjectProperty.AutomationId), Data.Get("USA"));
            }

            applicationHandle.SetFieldValue("AutomationId=" + (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";4", ObjectProperty.AutomationId), Amount2);
            applicationHandle.SetFieldValue(txtNotes, "Notes for IRA contribution for Account Number : " + AccountNumber);
            applicationHandle.ClickObeject(buttonOK);
            if (Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName))
            {
                Result = true;
            }
            return Result;
        }
        public virtual bool EnterCheckDepositFundDetails(string AccountNumber, string Amount, string Currency = "", string RTNumber = "", string CheckType = "")
        {
            bool Result = false;
            bool x = Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName);
            Profile7CommonLibrary.VerifyWindowObjectExists(txtAccountNumber);
            applicationHandle.SetFieldValue(txtAccountNumber, AccountNumber);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation);
            Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName);
            applicationHandle.ClickObeject(TabChecks);

            applicationHandle.SetFieldValue(AmountText, Amount);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Text=USD", Currency, false);

            }
            Profile7CommonLibrary.VerifyWindowObjectExists(txtDepositAmount);
            applicationHandle.SetFieldValue(txtDepositAmount, Amount);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void ClickRedFlagForCheckTransaction()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            string buttonRedFlag = "Text=Amount;LabelRelationShip=" + LabelRelationShip.Parent;
            buttonRedFlag = (string)applicationHandle.GetObjectProperty(buttonRedFlag, ObjectProperty.AutomationId);
            buttonRedFlag = (string)applicationHandle.GetObjectProperty("AutomationId=" + buttonRedFlag + ";LabelRelationShip=" + LabelRelationShip.NextSibling, ObjectProperty.AutomationId);
            buttonRedFlag = (string)applicationHandle.GetObjectProperty("AutomationId=" + buttonRedFlag + ";LabelRelationShip=" + LabelRelationShip.NextChild, ObjectProperty.AutomationId);
            buttonRedFlag = (string)applicationHandle.GetObjectProperty("AutomationId=" + buttonRedFlag + ";LabelRelationShip=" + LabelRelationShip.NextChild, ObjectProperty.AutomationId);
            buttonRedFlag = (string)applicationHandle.GetObjectProperty("AutomationId=" + buttonRedFlag + ";LabelRelationShip=" + LabelRelationShip.NthSibling + ";2", ObjectProperty.AutomationId);
            applicationHandle.ClickObeject("AutomationId=" + buttonRedFlag);

        }
        public virtual bool EnterIRAContributionMultiTransactionDetails(string AccountNumber, string ContributionCodePipeDelimited, string AmountPipeDelimited)
        {
            bool Result = false;
            int n=1;
            int DropdownIndex = 0;
            string runtimeAutoID = "";
            string dropdownReasonCode = "";
            ContributionCodePipeDelimited = ContributionCodePipeDelimited + "|";
            AmountPipeDelimited = AmountPipeDelimited + "|";
            Profile7CommonLibrary.WaitUntilWindowLoads(TransactionDetailWindow);

            string[] ContrArr = ContributionCodePipeDelimited.Split('|');
            string[] AmountArr = AmountPipeDelimited.Split('|');
            if (ContrArr.Length == AmountArr.Length)
            {
                for (int a = 0; a < ContrArr.Length - 1; a++)
                {
                    dropdownReasonCode = "ControlType=ComboBox;Index=" + DropdownIndex;
                    applicationHandle.SelectDropdownSpecifiedValue(dropdownReasonCode, ContrArr[a]);

                    runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode, ObjectProperty.AutomationId);
                    if (ContrArr[a].Equals(Data.Get("120 - Postponed Contribution")))
                    {
                        string yearpart = applicationHandle.GetDateParameters(Profile7CommonLibrary.GetApplicationDate())[2];
                        applicationHandle.SetFieldValue("AutomationId=" + (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";3", ObjectProperty.AutomationId), yearpart);
                    }
                    if (ContrArr[a].Equals(Data.Get("120 - Postponed Contribution")))
                    {
                        applicationHandle.SetFieldValue("AutomationId=" + (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";5", ObjectProperty.AutomationId), Data.Get("USA"));
                    }
                    runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";4", ObjectProperty.AutomationId);
                    applicationHandle.ClickObeject("Text=Forward by small amount");
                    applicationHandle.SelectContextMenuItem("Text=Forward by small amount", true, "Scroll Here");
                    applicationHandle.SetFieldValue("AutomationId=" + runtimeAutoID, AmountArr[a]);
                    runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.NthSibling + ";2", ObjectProperty.AutomationId);


                    if (n != AmountArr.Length - 1)
                    {
                        applicationHandle.ClickObeject("AutomationId=" + runtimeAutoID);
                        applicationHandle.ClickObeject("Text=Forward by small amount;Index=0");
                        applicationHandle.SelectContextMenuItem("Text=Forward by small amount;Index=0", true, "Scroll Here");
                        applicationHandle.ClickObeject("Text=Back by small amount");
                        applicationHandle.SelectContextMenuItem("Text=Back by small amount", true, "Scroll Here");
                        DropdownIndex = DropdownIndex + 2;
                    }
                    n++;
                }
            }
            applicationHandle.SetFieldValue(txtNotes, "Notes for IRA contribution for Account Number : " + AccountNumber);
            applicationHandle.ClickObeject(buttonOK);
            if (Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName))
            {
                Result = true;
            }
            return Result;
        }
     

    }
}
