using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class PostTransaction
    {
        public WindowsApplication appHandle;
        private Object tellerWindowName = "jp2launcher;" + "Profile Teller " + StartupConfiguration.EnvironmentDetails.TellerVersion;
        private static Object PostTransactionImage = "PostTransaction.PNG";

        /// <summary>
        /// To post the transaction in Teller window.
        /// </summary>
        /// <param name="isPost"></param>
        public virtual void PostTellerTransaction(bool isPost = true)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            ApplicationInstance instance = new ApplicationInstance(appHandle);
            if (isPost== true)
            {
                appHandle.ClickObjectByImage(PostTransactionImage,MouseClick.LeftClick);
                Report.Pass("Transaction Posted successfully");
            }
        }
    }
}