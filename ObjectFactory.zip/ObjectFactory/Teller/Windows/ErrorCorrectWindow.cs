using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System;
using System.Linq;
using System.Windows.Forms;
using TestStack.White.InputDevices;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class ErrorCorrectWindow
    {
        static WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private string tellerWindowName = "jp2launcher;" + "Profile Teller " + StartupConfiguration.EnvironmentDetails.TellerVersion;

        //private static string DepositAmount =  "Text=Deposit Amount: ;ControlType=Edit";
        //private static string AcctInfo =  "ClassName=Static;ControlType=Text;Index=23";
        private static string ErrorCorrect_Window = "Error Correct";
        private static string ErrorCorrectObj = "ClassName=SysListView32";
        private static string Post_Button = "ControlType=Button;Text=Post";
        private static string Cancel_Button = "ControlType=Button;Text=Cancel";
        private static string ErrorCorrectConfirm_Window = "Error Correct";
        private static string Yes_Button = "ControlType=Button;Text=Yes";
        //private static string No_Button = "ControlType=Button;Text=No";
        private string OverrideWindowName = "Authorization Override Required";
        //private string OverrideWindow_UserIDField = "ControlType=Edit;Name=Password;Index=0";
        private string OverrideWindow_PasswordField = "ControlType=Edit;Name=Password;Index=1";
        //private string OverrideWindow_CancelButton = "ControlType=Button;Text=Cancel";
        private static string OkButton = "ControlType=Button;Text=OK";

        private string ErrorCorrectionButton = "ControlType=Button;Text=Error Correct<Alt+7>";
        public virtual bool errorcorrect_teller_transaction_false(string SelectionInfo, string OverrideFlag)
        {
            bool blnSuccess = false;
            string[] arrSelection;
            arrSelection = SelectionInfo.Split(';');

            string sTransactionCode = arrSelection[0];
            string sAccountNumber = arrSelection[1];
            string sAmount = arrSelection[2];

            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            // ApplicationInstance instance = new ApplicationInstance(applicationHandle);
            if (Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName))
            {
                try
                {
                    applicationHandle.Wait_For_Specified_Time(2);
                    applicationHandle.Sendkeys("%7");
                    applicationHandle.IsWindowObjExist(tellerWindowName, ErrorCorrect_Window, Cancel_Button);
                    applicationHandle.PerformActionOnGrid(ErrorCorrectObj, SelectionInfo);
                    blnSuccess = false;
                }
                catch (System.Exception)
                {
                    applicationHandle.PerformActionOnDialogWindow(ErrorCorrect_Window,
                                                                            Cancel_Button,
                                                                            new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                    blnSuccess = true;
                }
            }
            return blnSuccess;
        }

        public virtual bool errorcorrect_teller_transaction(string SelectionInfo, string OverrideFlag)
        {
            bool blnSucsess = false;

            string[] arrSelection;
            arrSelection = SelectionInfo.Split(';');

            string sTransactionCode = arrSelection[0];
            string sAccountNumber = arrSelection[1];
            string sAmount = arrSelection[2];

            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            // ApplicationInstance instance = new ApplicationInstance(applicationHandle);
            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                applicationHandle.Wait_For_Specified_Time(2);
                applicationHandle.Sendkeys("%7");
                applicationHandle.IsWindowObjExist(tellerWindowName, ErrorCorrect_Window, Cancel_Button);
                applicationHandle.PerformActionOnGrid(ErrorCorrectObj, SelectionInfo);

                bool blnErrorCorrectWindowExists = applicationHandle.IsWindowObjExist(tellerWindowName,
                                                                    ErrorCorrect_Window,
                                                                    Post_Button);
                if (blnErrorCorrectWindowExists)
                {
                    // Click on Post button on Error Correct window.
                    applicationHandle.PerformActionOnDialogWindow(ErrorCorrect_Window,
                                                                        Post_Button,
                                                                        new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                    // Click on Yes button on Error Correct confirmation window.
                    applicationHandle.Wait_For_Specified_Time(5);
                    applicationHandle.Sendkeys("{ENTER}");
                    applicationHandle.Wait_For_Specified_Time(10);
                    applicationHandle.PerformActionOnDialogWindow(ErrorCorrect_Window,
                                                                Cancel_Button,
                                                                new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                    blnSucsess = true;
                }
                else
                {
                    Report.Info("Error Correct child window is not displayed.");
                    blnSucsess = false;
                }
            }
            else
            {
                blnSucsess = false;
                Report.Fail("Unable to Post Transaction.");
                throw new Exception("Unable to Post Transaction.");
            }
            return blnSucsess;
        }
        public virtual void ClickOnErrorCorrectionButton()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            applicationHandle.ClickObeject(ErrorCorrectionButton);
        }
        public virtual bool CheckIfPostButtonEnabled()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Error Correct");
            bool SelectedTran = false;
            for (int i = 1; i <= 200; i++)
            {
                try
                {
                    SelectedTran = (bool)applicationHandle.GetObjectProperty("Text=Post", ObjectProperty.IsEnable);
                    if (SelectedTran)
                    {
                        SelectedTran = true;
                        break;
                    }
                    else
                    {
                        SelectedTran = false;
                        break;
                    }
                }
                catch (Exception e) { };
            }

            return SelectedTran;
        }
        public virtual string EnterErrorCorrectDetails(string TranDetailsPipeDelimited)
        {
            int counter = 0;
            int n = 2;
            string SelectedTransactions = "";
            string temp = "";
            string temp1 = "";
            int matchcount = 0;
            string temppostseq = "";
            string acctnum = "";
            string temp2 = "";
            string temp3 = "";
            string temp4 = "";
            string MainGridautoid = "";
            bool errorwindowloaded = false;
            do
            {
                errorwindowloaded = Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Error Correct");
            }
            while (errorwindowloaded == false);

            TranDetailsPipeDelimited = TranDetailsPipeDelimited + "|";
            string[] arr = TranDetailsPipeDelimited.Split('|');
            for (int q = 0; q < arr.Length - 1; q++)
            {
                if (arr[q].Contains("."))
                {
                    continue;
                }
                if (arr[q].All(char.IsDigit) &&
                     arr[q].Length > 10)
                {
                    acctnum = arr[q].Trim();
                }
            }

            bool IsAccountFound = false;
            try
            {
                if (!string.IsNullOrEmpty(acctnum))
                {

                    if (((string)applicationHandle.GetObjectProperty("Text=" + acctnum, ObjectProperty.Name)).Equals(acctnum))
                    {
                        IsAccountFound = true;
                    }
                }
            }
            catch (Exception e)
            {
                IsAccountFound = false;
            }
            if (IsAccountFound)
            {


                if (string.IsNullOrEmpty((string)applicationHandle.GetObjectProperty("AutomationId=" + "SmallIncrement;Index=0", ObjectProperty.AutomationId))) { }
                else
                {
                    applicationHandle.ClickObeject("AutomationId=" + "SmallIncrement;Index=0");
                    applicationHandle.SelectContextMenuItem("AutomationId=" + "SmallIncrement;Index=0", true, "Scroll Here");
                }

                string PostSeq = (string)applicationHandle.GetObjectProperty("Text=" + acctnum + ";LabelRelationShip=" + LabelRelationShip.ParentsPreviousSibling, ObjectProperty.Name);
                MainGridautoid = (string)applicationHandle.GetObjectProperty("Text=Header" + ";LabelRelationShip=" + LabelRelationShip.Parent, ObjectProperty.AutomationId);

                bool postseqfound = false;
                do
                {

                    for (int b = 1; b <= 9; b++)
                    {
                        temp = temp + " " + (string)applicationHandle.GetObjectProperty("Text=" + PostSeq + "" + ";LabelRelationShip=" + LabelRelationShip.NthNextSiblingKthChild + ";1;" + b + "", ObjectProperty.Name);
                    }
                    

                    if (temp.Trim().Split(new string[] { " " }, StringSplitOptions.None)[2].Trim().Equals(Data.Get("GLACCOUNT")))
                    {
                        temp2 = temp.Trim();
                        for (int a = 1; a <= 9; a++)
                        {
                            temp1 = temp1 + " " + (string)applicationHandle.GetObjectProperty("Text=" + PostSeq + "" + ";LabelRelationShip=" + LabelRelationShip.NthChild + ";" + a + "", ObjectProperty.Name);
                        }
                        temp = temp1.Trim();
                    }

                    for (int c = 0; c < arr.Length - 1; c++)
                    {
                        if (arr[c].Contains("."))
                        {
                            string tempamt = arr[c].Trim();
                            arr[c] = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(tempamt);
                        }
                        if (arr[c].All(char.IsDigit) &&
                         arr[c].Length < 10)
                        {
                            string tempamt1 = arr[c].Trim();
                            arr[c] = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(tempamt1);
                        }
                        if (temp.Trim().Contains(arr[c]))
                        {
                            matchcount++;
                        }
                        if (matchcount == arr.Length - 1)
                        {
                            postseqfound = true;
                            break;
                        }
                    }
                    if (matchcount == arr.Length - 1)
                    {
                        postseqfound = true;
                        if (string.IsNullOrEmpty(temp1))
                        {
                            for (int a = 1; a <= 9; a++)
                            {
                                temp1 = temp1 + " " + (string)applicationHandle.GetObjectProperty("Text=" + PostSeq + "" + ";LabelRelationShip=" + LabelRelationShip.NthChild + ";" + a + "", ObjectProperty.Name);
                            }
                        }
                        if (!string.IsNullOrEmpty(temp2))
                        {
                            temp = temp2.Trim() + " | " + temp1.Trim();
                        }
                        else
                        {
                            temp = temp1.Trim() + " | " + temp.Trim();
                        }
                        break;
                    }
                    else
                    {
                        // applicationHandle.ClickObeject("Text="+PostSeq);
                        temppostseq = (string)applicationHandle.GetObjectProperty("Text=" + PostSeq + ";LabelRelationShip=" + LabelRelationShip.NthSibling + ";" + n + "", ObjectProperty.Name);
                        PostSeq = temppostseq;
                        if (string.IsNullOrEmpty(PostSeq))
                        {
                            break;
                        }
                        temp = "";
                        temp1 = "";
                        temp2 = "";
                        matchcount = 0;
                    }

                }
                while (postseqfound == false);

                if (postseqfound)
                {
                    applicationHandle.ClickObeject("Text=" + PostSeq + "" + ";LabelRelationShip=" + LabelRelationShip.NthNextSiblingKthChild + ";1;1");
                    temp3 = (string)applicationHandle.GetObjectProperty("AutomationId=" + MainGridautoid + ";LabelRelationShip=" + LabelRelationShip.NthSiblingMthChildKthChild + ";1;2;2", ObjectProperty.Name);
                    temp4 = (string)applicationHandle.GetObjectProperty("AutomationId=" + MainGridautoid + ";LabelRelationShip=" + LabelRelationShip.NthSiblingMthChildKthChild + ";1;2;3", ObjectProperty.Name);
                    string temp5 = temp3 + temp4;
                    if (this.CheckIfPostButtonEnabled() && temp5.Contains(acctnum))
                    {
                        SelectedTransactions = temp;
                    }
                }
            }
            else
            {
                Report.Fail(acctnum + " is not present in the Error correct Window.", "acctnotfound", "True", applicationHandle);
            }
            return SelectedTransactions;
        }
        public virtual void ClickOnCancelButton()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Error Correct");
            if (Profile7CommonLibrary.VerifyWindowObjectExists(Cancel_Button))
            {
                applicationHandle.ClickObeject(Cancel_Button);
            }
        }
        public virtual bool ClickOnPostButton()
        {
            bool Result = false;
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Error Correct");
            if (Profile7CommonLibrary.VerifyWindowObjectExists(Post_Button))
            {
                applicationHandle.ClickObeject(Post_Button);
            }
            if (applicationHandle.Launch_Application("Error Correct", 200, true, true))
            {
                if (Profile7CommonLibrary.WaitForWindowObjectByText(Data.Get("Continue to perform error corrections on the selected transactions?")))
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual void ClickOnYesButton()
        {
            applicationHandle.Launch_Application("Error Correct", 200, true, true);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(Yes_Button))
            {
                applicationHandle.ClickObeject(Yes_Button);
            }
        }



    }
}
