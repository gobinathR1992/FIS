﻿using System;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;
using System.Windows.Forms;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class WithdrawFundsWindow
    {
        private static WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private string tellerWindowName = "jp2launcher;" + "Profile Teller";
        //private static Object AccountNumber =  "ClassName=ComboBox";
        //private static Object CashOut =  "ControlType=Edit;Text=Cash Out: ";
        //private static Object WithdrawalAmount =  "ControlType=Edit;Name=Withdrawal Amount: ";
        private static Object AccountNumber = "ControlType=Edit;Index=0";
        private static Object CashOut = "Text=Cash Out: ;ControlType=Edit";        //"ControlType=Edit;Index=0";
        private static Object WithdrawalAmount = "Text=Withdrawal Amount: ;ControlType=Edit";      //"ControlType=Edit;Index=1";
        private static Object AccBalance = "ClassName=Static;ControlType=Text;Index=22";
        private static Object Type = "Text=Type: ;ControlType=ComboBox";
        Object screenShotName1 = "TellerWihdrawlScreen";
        Object screenShotName2 = "TellerScreenAfteWinthdrawl";
        private static string txtAccountNumber = "ClassName=Edit;AutomationId=1001;Name=Account Number";
        private static string TransactionDetailWindow = "jp2launcher;Transaction Detail";
        private static string txtCashOut = "ClassName=Edit;Index=1";
        private static string txtWithdrawAmount = "ClassName=Edit;Index=3";
        private static string txtFundsCurrency = "ClassName=Edit;Index=2";
        private string tabTransactionList = "Control Type=TabItem;Text=Transaction List";
        private string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
        private string tableHeaderTransactionList = "Control Type=HeaderItem;Name=Base Eq Amount";
        public static string txtNotes = "ControlType=Document;Index=0";
        public static string buttonOK = "Text=OK";
        private static string ButtonPlusSignLeg1 = "Text=Type" + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSiblingKthChild + ";1;2";
        public static string buttonRedFlag="Text=Withdrawal Amount: ;LabelRelationShip="+LabelRelationShip.NthSibling+";3";
        
        public virtual void WithDrawFund(string accountNo, string amount, string type)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            applicationHandle.Launch_Application(tellerWindowName);
            //applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("{F2}"));
            applicationHandle.Sendkeys("{F2}");
            Thread.Sleep(3);
            applicationHandle.SelectDropdownSpecifiedValue(Type, type);
            applicationHandle.SetFieldValue(AccountNumber, accountNo);
            //applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("{TAB}"));
            applicationHandle.Sendkeys("{TAB}");
            applicationHandle.SetFieldValue(CashOut, amount);
            applicationHandle.SetFieldValue(WithdrawalAmount, amount);
            Report.Info("Information added to screen", screenShotName1, applicationHandle);
            //applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("{F12}"));
            applicationHandle.Sendkeys("{F12}");
            Thread.Sleep(6);
            Report.Pass("Transaction posted", screenShotName2, applicationHandle);
        }
        public virtual void enter_teller_withdraw_details(string sEffectiveDate, string[] arrActionEntries)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);

            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                // string sTellerApplnDate = TellerPageFactory.MasterWindow.get_pd_teller_application_date();
                // if (! sTellerApplnDate.Equals(sEffectiveDate))
                // {
                //     TellerPageFactory.MasterWindow.set_effective_date(sEffectiveDate);
                //     Report.Info("Changed the Effective Date.");
                // }dotnet 
                applicationHandle.Wait_For_Specified_Time(1);
                applicationHandle.Sendkeys("{F2}");
                applicationHandle.IsObjectExists(WithdrawalAmount);
                applicationHandle.SetFieldValue(AccountNumber, arrActionEntries[0]);
                applicationHandle.SetFieldValue(CashOut, arrActionEntries[1]);
                applicationHandle.SetFieldValue(WithdrawalAmount, arrActionEntries[2]);
                Report.Info("Information added to screen", screenShotName1, applicationHandle);

                string sBalanceValue = applicationHandle.GetTextFromField(AccBalance.ToString());

                if (sBalanceValue.Equals("0.00"))
                {
                    Report.Info("Transaction is balanced.");
                }
                else
                {
                    Report.Info("Transaction is not balanced.");
                }
            }
            else
            {
                Report.Fail("Unable to launch application");
                throw new Exception("Unable to launch application");
            }
        }
        public virtual bool EnterWithdrawFundsDetails(string AccountNumber, string Amount, string Currency = "", bool IsOverride = false)
        {
            bool Result = false;
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            bool x = Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName);
            Profile7CommonLibrary.VerifyWindowObjectExists(txtAccountNumber);
            applicationHandle.SetFieldValue(txtAccountNumber, AccountNumber);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation);
            applicationHandle.SetFieldValue(txtCashOut, Amount);
            if (Currency.Equals(Data.Get("USD"))) { }
            else
            {
                applicationHandle.SetFieldValue(txtFundsCurrency, Currency);
                applicationHandle.ClickObeject(txtFundsCurrency);
                SendKeys.SendWait("{ENTER}");
            }
            Profile7CommonLibrary.VerifyWindowObjectExists(txtWithdrawAmount);
            applicationHandle.SetFieldValue(txtWithdrawAmount, Amount);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;
        }
        public virtual bool VerifyWithdrawFundsTabClosedAfterTransaction()
        {
            bool x = applicationHandle.Launch_Application(tellerWindowName);
            string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
            bool Result = false;
            try
            {
                if (Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation))
                {
                    Result = true;
                }
            }
            catch (Exception e)
            {
                Result = false;
            }
            return Result;
        }
        public virtual void ClickOnRedFlag()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");  
            Profile7CommonLibrary.VerifyWindowObjectExists(buttonRedFlag);
            applicationHandle.ClickObeject(buttonRedFlag);

        }
        public virtual string GetWithdrawAmount()
        {
            string Amount1 = applicationHandle.GetLabelText("ClassName=Edit;Index=3");
            return Amount1;
        }
        public virtual bool EnterWithdrawFundsNewAmount(string NewAmount,string Currency = "")
        {
            bool Result = false;
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            bool x = Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName);
            Profile7CommonLibrary.VerifyWindowObjectExists(txtAccountNumber);
            applicationHandle.SetFieldValue(txtCashOut, NewAmount);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation);
            if (Currency.Equals(Data.Get("USD"))) { }
            else
            {
                applicationHandle.SetFieldValue(txtFundsCurrency, Currency);
                applicationHandle.ClickObeject(txtFundsCurrency);
                SendKeys.SendWait("{ENTER}");
            }
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;
        }
        public virtual bool EnterIRADistributionMultiTransactionDetails(string AccountNumber, string DistributionCodePipeDelimited, string AmountPipeDelimited, string RSPFederalAmtPipeDelimited="", string RSPStateAmtPipeDelimited="")
        {
            bool Result = false;
            int n=1;
            int DropdownIndex = 0;
            string runtimeAutoID = "";
            string dropdownReasonCode = "";
            DistributionCodePipeDelimited = DistributionCodePipeDelimited + "|";
            AmountPipeDelimited = AmountPipeDelimited + "|";
            Profile7CommonLibrary.WaitUntilWindowLoads(TransactionDetailWindow);

            string[] ContrArr = DistributionCodePipeDelimited.Split('|');
            string[] AmountArr = AmountPipeDelimited.Split('|');
            string[] FederalAmtArray = RSPFederalAmtPipeDelimited.Split('|');
            string[] stateArray = RSPStateAmtPipeDelimited.Split('|');
            if (ContrArr.Length == AmountArr.Length)
            {
                for (int a = 0; a < ContrArr.Length - 1; a++)
                {
                    dropdownReasonCode = "ControlType=ComboBox;Index=" + DropdownIndex;
                    applicationHandle.SelectDropdownSpecifiedValue(dropdownReasonCode, ContrArr[a]);

                    runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode, ObjectProperty.AutomationId);
                    runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";3", ObjectProperty.AutomationId);
                    applicationHandle.ClickObeject("Text=Forward by small amount");
                    applicationHandle.SelectContextMenuItem("Text=Forward by small amount", true, "Scroll Here");
                    applicationHandle.SetFieldValue("AutomationId=" + runtimeAutoID, AmountArr[a]);

                    if (!string.IsNullOrEmpty(RSPFederalAmtPipeDelimited))
                    {                    
                    runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode, ObjectProperty.AutomationId);
                    runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";1", ObjectProperty.AutomationId);
                    applicationHandle.ClickObeject("Text=Forward by small amount");
                    applicationHandle.SelectContextMenuItem("Text=Forward by small amount", true, "Scroll Here");
                    applicationHandle.SetFieldValue("AutomationId=" + runtimeAutoID, FederalAmtArray[a]);

                    runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode, ObjectProperty.AutomationId);
                    runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";2", ObjectProperty.AutomationId);
                    applicationHandle.SetFieldValue("AutomationId=" + runtimeAutoID, stateArray[a]);

                    runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode, ObjectProperty.AutomationId);
                    runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";3", ObjectProperty.AutomationId);
                    applicationHandle.SetFieldValue("AutomationId=" + runtimeAutoID, AmountArr[a]);
                    }
                    // runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode, ObjectProperty.AutomationId);
                    // runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";3", ObjectProperty.AutomationId);
                    // applicationHandle.SetFieldValue("AutomationId=" + runtimeAutoID, AmountArr[a]);
                    runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.NthSibling + ";1", ObjectProperty.AutomationId);
                
                    if (n != AmountArr.Length - 1)
                    {
                        applicationHandle.ClickObeject("AutomationId=" + runtimeAutoID);
                        applicationHandle.ClickObeject("Text=Forward by small amount;Index=0");
                        applicationHandle.SelectContextMenuItem("Text=Forward by small amount;Index=0", true, "Scroll Here");
                        applicationHandle.ClickObeject("Text=Back by small amount");
                        applicationHandle.SelectContextMenuItem("Text=Back by small amount", true, "Scroll Here");
                        DropdownIndex = DropdownIndex + 1;
                    }
                    n++;                    
                }
            }
            applicationHandle.SetFieldValue(txtNotes, "Notes for IRA Distribution for Account Number : " + AccountNumber);
            applicationHandle.ClickObeject(buttonOK);
            if (Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName))
            {
                Result = true;
            }
            return Result;
        }




    }
}
