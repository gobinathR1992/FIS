using GTS_OSAF.CoreLibs;
using System;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class ReverseTransactions
    {
        static WindowsApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private static string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        private string tellerWindowName = "jp2launcher;" + "Profile Teller";
        private string tabTransactionList = "Control Type=TabItem;Text=Transaction List";
        private static string txtAccountNumber = "Text=Account Number" + ";LabelRelationShip=" + LabelRelationShip.NthNextSiblingKthChild + ";1;1";
        private static string txtFromDate = "ControlType=Edit;Text=From Date";
        private static string txtToDate = "ControlType=Edit;Text=To Date";
        private static string dropdownTransactionType = "ControlType=ComboBox;Index=1";
        private static string txtAccountNumberLeg2 = "Text=?" + ";LabelRelationShip=" + LabelRelationShip.NthPreviousSiblingChild + ";1";
        private static string txtAmount = "Text=?" + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild + ";1";
        private static string buttonRun = "ControlType=Button;Text=Run";
        private static string dropdownCurrency = "ControlType=ComboBox;Text=USD";
        private string tableHeaderTransactionList = "Control Type=HeaderItem;Name=Base Eq Amount";
        private static string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
        public virtual bool EnterReverseTransactionsDetails(string AccountNumber, string TransactionCode, string TransactionToBeSelectedPipeDelimited, string Amount, string FromDate = "", string ToDate = "", string Currency = "")
        {
            bool Result = false;
            int n = 1;
            string SelectedTran = "";
            int colcount = 0;
            string temp = "";
            string colnames = "";
            string tempseq = "";
            string Seq = "";
            int matchcount = 0;
            TransactionToBeSelectedPipeDelimited = TransactionToBeSelectedPipeDelimited + "|";
            string[] arr = TransactionToBeSelectedPipeDelimited.Split('|');
     Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName);
            appHandle.SetFieldValue(txtAccountNumber, AccountNumber);

            if (!string.IsNullOrEmpty(FromDate))
            {
                Profile7CommonLibrary.VerifyWindowObjectExists(txtFromDate);
                appHandle.SetFieldValue(txtFromDate, FromDate);
            }
            if (!string.IsNullOrEmpty(ToDate))
            {
                Profile7CommonLibrary.VerifyWindowObjectExists(txtToDate);
                appHandle.SetFieldValue(txtToDate, ToDate);
            }
            if (Profile7CommonLibrary.VerifyWindowObjectExists(buttonRun))
            {
                appHandle.ClickObeject(buttonRun);
            }
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation))
            {
                if ((bool)appHandle.GetObjectProperty("ControlType=Button;Text=Run", ObjectProperty.IsEnable))
                {
                    Seq = (string)appHandle.GetObjectProperty("Text=" + UID + ";LabelRelationShip=" + LabelRelationShip.Parent, ObjectProperty.Name);
                }
            }
            if (string.IsNullOrEmpty(Seq))
            {
                Result = false;
            }
            else
            {
                do
                {
                    colnames = (string)appHandle.GetObjectProperty("Text=" + Seq + ";LabelRelationShip=" + LabelRelationShip.NthChild + ";" + n + "", ObjectProperty.Name);
                    n++;
                    if (string.IsNullOrEmpty(colnames))
                    {
                        colcount = n - 1;
                    }
                }

                while (!string.IsNullOrEmpty(colnames));
                n = 1;
                temp = "";
                bool SeqFound = false;
                do
                {
                    for (int a = 1; a <= colcount; a++)
                    {
                        temp = temp + " " + (string)appHandle.GetObjectProperty("Text=" + Seq + "" + ";LabelRelationShip=" + LabelRelationShip.NthChild + ";" + a + "", ObjectProperty.Name);

                    }


                    for (int c = 0; c < arr.Length - 1; c++)
                    {

                        if (temp.Trim().Contains(arr[c]))
                        {
                            matchcount++;
                        }
                        if (matchcount == arr.Length - 1)
                        {
                            SeqFound = true;
                            break;
                        }
                    }
                    if (matchcount == arr.Length - 1)
                    {
                        SeqFound = true;
                        temp = temp.Trim();
                        break;
                    }
                    else
                    {
                       
                        tempseq = (string)appHandle.GetObjectProperty("Text=" + Seq + ";LabelRelationShip=" + LabelRelationShip.NthSibling + ";" + n + "", ObjectProperty.Name);
                        Seq = tempseq;
                        temp = "";
                        matchcount = 0;
                        if (string.IsNullOrEmpty(Seq))
                        {
                            break;
                        }
                    }

                }
                while (SeqFound == false);
                if (SeqFound)
                {
                    Result = true;
                    appHandle.ClickObeject("Text=" + Seq + "" + ";LabelRelationShip=" + LabelRelationShip.NthChild + ";1;1");
                    SelectedTran = temp;
                }
            }
            if (Result)
            {
                appHandle.SetFieldValue(dropdownTransactionType, TransactionCode);
                appHandle.SetFieldValue(txtAccountNumberLeg2, Data.Get("GLACCOUNT"));
                if (string.IsNullOrEmpty(Currency))
                {
                    {
                        Currency = Data.Get("USD");
                    }
                }
                if (!Currency.Contains(Data.Get("USD")))
                {
                    appHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Text=USD", Currency, false);
                }
                appHandle.SetFieldValue(txtAmount, Amount);
                Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
                appHandle.ClickObeject(tabTransactionList);
            }
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;
        }

        public virtual bool VerifyReverseTransactionsTabClosedAfterTransaction()
        {
           // bool x = appHandle.Launch_Application(tellerWindowName);
            
            bool Result = false;
            try
            {
                if (Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation))
                {
                    Result = true;
                }
            }
            catch (Exception e)
            {
                Result = false;
            }
            return Result;
        }
    }
}