﻿using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Threading;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class TransactionCodeSearchwindow
    {
        public WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private string TransactionCodeSearchDialog = "jp2launcher;Transaction Code Search";
        private string TransactionDescriptionCheckbox = "ControlType=check box;Name=Transaction Description:";
        private string TransactionCodeClassCheckbox = "ControlType=check box;Name=Transaction Code Class:";
        private string TransactionCodeGroupCheckbox = "ControlType=check box;Name=Transaction Code Group:";
        private string TransactionCodeCheckbox = "ControlType=check box;Name=Transaction Code:";
        private string TransactionCodeTypeCheckbox = "ControlType=check box;Name=Transaction Code Type:";
        private static string SearchButton = "ControlType=Button;Text=Search";
        private static string OkButton = "ControlType=Button;Text=OK";
        private static string CancelButton = "ControlType=Button;Text=Cancel";
        private static string TransactionCodeSearchList = "ClassName=SysListView32;ControlType=DataGrid";
        private static string CloseButton = "ControlType=Button;Text=Close";



        /// <summary>
        /// To search Transaction Code from Advance transaction window.
        /// </summary>
        /// <param name="transactionDetails"></param>
        /// <example>
        /// <code>
        /// transactionDetails ="CD"
        /// transactionDetails ="ACHDD"
        /// Application.Teller.TransactionCodeSearchwindow(transactionDetails);
        /// </code>
        /// </example>
        public virtual void enter_transaction_code_search(string transactionDetails)
        {

            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);

            if (applicationHandle.Launch_Application(TransactionCodeSearchDialog))

                try
                {
                    string sSearch = "Transaction Code";
                    string transactioncodesearchcheckbox = "ControlType=check box;Name=" + sSearch + ":";
                    string transactioncodesearchfield = "ControlType=check box;Name=" + sSearch + ":;LabelRelationShip=" + LabelRelationShip.NextSibling;
                    applicationHandle.PerformActionOnDialogWindow(TransactionCodeSearchDialog, transactioncodesearchcheckbox, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                    applicationHandle.PerformActionOnDialogWindow(TransactionCodeSearchDialog, transactioncodesearchfield, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.SetText, transactionDetails));
                    applicationHandle.PerformActionOnDialogWindow(TransactionCodeSearchDialog, SearchButton, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                    applicationHandle.PerformActionOnDialogWindow(TransactionCodeSearchDialog, TransactionCodeSearchList, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.SelectRowInGrid));
                    applicationHandle.PerformActionOnDialogWindow(TransactionCodeSearchDialog, OkButton, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                    Thread.Sleep(6);
                    Report.Info("Transaction search: Code found");
                }
                catch (Exception e)
                {

                    throw new Exception(e.Message);
                }
        }
    }
















}
