using System;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class LoanPaymentWindow
    {

        static WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private Object tellerWindowName = "jp2launcher;" + "Profile Teller";
        private static Object LoanPayment_Account = "ClassName=ComboBox;Index=2";
        private static string txtAccountNumber = "ClassName=Edit;AutomationId=1001;Index=2";
        //private static Object LoanPayment_CashIn = "ControlType=Edit;Index=1";
        // private static Object LoanPayment_Account = "ControlType=Edit;Index=2";
        // private static Object LoanPayment_Account = "ControlType=Edit;Index=3";
        private static string LoanPayment_Amount = "ClassName=Edit;Index=4";
        private static string LoanPayment_CashIn = "Text=Cash In: ;ControlType=Edit";
        //private static Object Status = "Name=Status";
        //private static String Window = "Print Receipt";
        //private static Object YesBtn = "ControlType=Button;Text=Yes";
        //private static Object NoBtn = "ControlType=Button;Text=No";
        private static string AcctBalance = "ClassName=Static;Index=24";

        private string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
        Object screenShotName1 = "TellerLoanPaymentScreen";
        Object screenShotName2 = "TellerScreenLoanPayment";
        private string tabTransactionList = "Control Type=TabItem;Text=Transaction List";
        private string tableHeaderTransactionList = "Control Type=HeaderItem;Name=Base Eq Amount";
        public virtual void enter_loan_payment_details(string[] arrActionEntries, string sEffectiveDate = null)
        {
            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                string sTellerApplnDate = TellerPageFactory.MasterWindow.get_pd_teller_application_date();
                if (sEffectiveDate != null)
                    if (!sTellerApplnDate.Equals(sEffectiveDate))
                    {
                        TellerPageFactory.MasterWindow.set_effective_date(sEffectiveDate);
                        Report.Info("Changed the Effective Date.");
                    }
                applicationHandle.ClickObeject(MasterWindow.btnstatus);
                applicationHandle.Sendkeys("{F4}");
                applicationHandle.WaitForObject(LoanPayment_Account, 5);
                applicationHandle.SetFieldValue(LoanPayment_Account, arrActionEntries[3]);
                applicationHandle.Sendkeys("{TAB}");
                applicationHandle.WaitForObject(LoanPayment_Amount, 5);
                applicationHandle.SetFieldValue(LoanPayment_Amount, arrActionEntries[2]);
                applicationHandle.SetFieldValue(LoanPayment_CashIn, arrActionEntries[5]);

                string sBalanceValue = applicationHandle.GetTextFromField(AcctBalance);

                if (sBalanceValue.Equals("0.00"))
                {
                    Report.Info("Transaction is balanced.");
                }
                else
                {
                    Report.Info("Transaction is not balanced.");
                }
            }
            else
            {
                Report.Fail("Unable to launch application");
                throw new Exception("Unable to launch application");
            }
        }

        // public virtual void post_teller_details(string sOverride)
        // {
        //     if (applicationHandle.Launch_Application(tellerWindowName))
        //     {
        //         applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        //         applicationHandle.Wait_For_Specified_Time(3);
        //         applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("F12"));
        //     }
        //     else
        //     {
        //         Report.Fail("Unable to Post Transaction.");
        //         throw new Exception("Unable to Post Transaction.");
        //     }
        //}
        public virtual string get_loan_payment_amount_value(string[] arrActionEntries)
        {
            string sAmountValue = null;
            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                applicationHandle.Wait_For_Specified_Time(2);
                //applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("F4"));
                applicationHandle.ClickObeject(MasterWindow.btnstatus);
                applicationHandle.Sendkeys("{F4}");
                applicationHandle.WaitForObject(LoanPayment_Amount, 5);
                applicationHandle.SetFieldValue(LoanPayment_Account, arrActionEntries[3]);
                // applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("TAB"));
                applicationHandle.Sendkeys("{TAB}");
                applicationHandle.WaitForObject(LoanPayment_Amount, 5);
                sAmountValue = applicationHandle.GetLabelText(LoanPayment_Amount.ToString());
            }
            return sAmountValue;
        }
        public virtual bool EnterLoanPaymentDetails(string AccountNumber, string Amount, bool Override = false)
        {
            bool Result = false;
            bool x = Profile7CommonLibrary.WaitUntilWindowLoads((string)tellerWindowName);
            Profile7CommonLibrary.VerifyWindowObjectExists(LoanPayment_CashIn);
            applicationHandle.SetFieldValue(LoanPayment_CashIn, Amount);
            applicationHandle.SetFieldValue(txtAccountNumber, AccountNumber);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation);
            Profile7CommonLibrary.VerifyWindowObjectExists(LoanPayment_Amount);
            applicationHandle.SetFieldValue(LoanPayment_Amount, Amount);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;
        }

        public virtual bool VerifyLoanPaymentTabClosedAfterTransaction()
        {
            bool x = applicationHandle.Launch_Application(tellerWindowName);
            string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
            bool Result = false;
            try
            {
                if (Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation))
                {
                    Result = true;
                }
            }
            catch (Exception e)
            {
                Result = false;
            }
            return Result;
 
        }



    }
}
