using GTS_OSAF.CoreLibs;
using System;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class TransactionAnalysisWindow
    {
        private static WindowsApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private static string YesBtn = "ControlType=Button;Text=Yes";
        public virtual void ClickOnYesButtonOnSaveResourceDialog()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Save Resource");
            appHandle.ClickObeject(YesBtn);
        }
        public virtual void ClickOnSpecifiedTab(string TabName)
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Transaction Analysis");
            appHandle.ClickObeject("Text=" + TabName);
        }
          }
}