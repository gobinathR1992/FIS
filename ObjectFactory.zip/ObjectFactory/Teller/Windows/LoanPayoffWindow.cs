using System;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
// using System.Windows.Automation;
using TestStack.White.UIItems;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class LoanPayoffWindow
    {

        static WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private string tellerWindowName = "jp2launcher;" + "Profile Teller";
        private string TransactionDetailsWindow = "jp2launcher;Transaction Detail";
        private string TranDetailWindow = "Transaction Detail";
        private static string OkButton = "ControlType=Button;Text=OK";
        private static Object LoanPayment_Account = "ClassName=ComboBox;Index=2";
        private static string txtAccountNumber = "ClassName=Edit;AutomationId=1001;Index=2";
        private static string LoanPayoff_Amount = "ClassName=Edit;Index=4";
        private static string LoanPayoff_CashIn = "Text=Cash In: ;ControlType=Edit";
        private string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
        private string tabTransactionList = "Control Type=TabItem;Text=Transaction List";
        private string tableHeaderTransactionList = "Control Type=HeaderItem;Name=Base Eq Amount";
        private string buttonFlag = "ControlType=Button;Index=2";
        private static string comboboxCloseOutReason = "ControlType=ComboBox";

        public virtual bool EnterLoanPayoffDetails(string AccountNumber, string Amount, bool Override = false, string currency = "", string CloseOutReason = "")
        {
            if (string.IsNullOrEmpty(CloseOutReason))
            {
                CloseOutReason = Data.Get("3 - Unhappy with Service");
            }
            bool Result = false;
            bool x = applicationHandle.Launch_Application(tellerWindowName);
            Profile7CommonLibrary.VerifyWindowObjectExists(LoanPayoff_CashIn);
            applicationHandle.SetFieldValue(LoanPayoff_CashIn, Amount);
            applicationHandle.SetFieldValue(txtAccountNumber, AccountNumber);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation);
            Profile7CommonLibrary.VerifyWindowObjectExists(LoanPayoff_Amount);
            applicationHandle.SetFieldValue(LoanPayoff_Amount, Amount);


            Profile7CommonLibrary.VerifyWindowObjectExists("Text=USD;ClassName=ComboBox;Index=3;LabelRelationShip=" + LabelRelationShip.NextSibling);
            applicationHandle.ClickObeject("Text=USD;ClassName=ComboBox;Index=3;LabelRelationShip=" + LabelRelationShip.NextSibling);
            if (applicationHandle.Launch_Application(TransactionDetailsWindow, 50, false, true))
            {
                Profile7CommonLibrary.VerifyWindowObjectExists(comboboxCloseOutReason);
                applicationHandle.PerformActionOnDialogWindow(TranDetailWindow, comboboxCloseOutReason, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.DropDownSelect, CloseOutReason));
                applicationHandle.PerformActionOnDialogWindow(TranDetailWindow, OkButton, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
            }
            Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation);
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;
        }

        public virtual bool VerifyLoanPayoffTabClosedAfterTransaction()
        {
            bool x = applicationHandle.Launch_Application(tellerWindowName);
            string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
            bool Result = false;
            try
            {
                if (Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation))
                {
                    Result = true;
                }
            }
            catch (Exception e)
            {
                Result = false;
            }
            return Result;
        }



    }
}
