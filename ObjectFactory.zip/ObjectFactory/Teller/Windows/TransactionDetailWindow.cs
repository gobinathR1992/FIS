﻿using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Util;
using Profile7Automation.Libraries.Util;
using System;
using System.Windows.Forms;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class TransactionDetailWindow
    {

        public static WindowsApplication windowsApplication = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        public static string txtContributionCode = "ControlType=ComboBox;Index=0";
        public static string txtNotes = "ControlType=Document;Index=0";
        public static string buttonOK = "Text=OK";
        private static string dropdownContributionCode = "ClassName=ComboBox;Index=0";
        public static string dropdownDistributionCode = "ClassName=ComboBox;index=0";
        private static string DistributionCodePickerWindow = "Transaction Detail";
        private static string DistributionCombobox = "ControlType=ComboBox;Index=0";
        private static string CheckTypeCombobox = "ControlType=ComboBox;Index=1";
        private static string txtpostonedcontribution = "ClassName=Edit;Index=1";
        private static string txtFedDesigDisasteArea = "ClassName=Edit;Index=3";
        private static string TranDetailWindow = "jp2launcher;Transaction Detail";
        public static string txtRSPFederalWithholdingAmount = "ClassName=Edit;Index=0";
        public static string txtRSPStateWithholdingAmount = "ClassName=Edit;Index=1";
        WebApplication webApplication=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        
        public virtual void EnterTransactionDetails(string contributionCode)
        {
            
            string randdata=webApplication.CreateRamdomData(FieldType.NUMERIC,100,999).ToString();
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Transaction Detail");
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownContributionCode);
            windowsApplication.SelectDropdownSpecifiedValue(dropdownContributionCode, contributionCode);
            windowsApplication.SetFieldValue(txtNotes, "Note" + randdata);
            windowsApplication.ClickObeject(buttonOK);
        }

        public virtual void EnterDistributionTransactionDetails(string distributionCode)
        {
            WebApplication webApplication = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string randdata = webApplication.CreateRamdomData(FieldType.NUMERIC, 100, 999).ToString();
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Transaction Detail");
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownDistributionCode);
            windowsApplication.SelectDropdownSpecifiedValue(dropdownDistributionCode, distributionCode);
            SendKeys.SendWait("{TAB}");
            windowsApplication.SetFieldValue(txtNotes, "Note" + randdata);
            windowsApplication.ClickObeject(buttonOK);
        }

        public virtual void EnterCheckTransactionDetails(string RTNumber = "", string CheckType = "")
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Transaction Detail");
            if (string.IsNullOrEmpty(RTNumber))
            {
                RTNumber = Data.Get("0 - Local");
            }
            if (string.IsNullOrEmpty(CheckType))
            {
                CheckType = Data.Get("3 - Hold Based on R & T Number");
            }
            windowsApplication.SelectDropdownSpecifiedValue(dropdownDistributionCode, RTNumber);
            windowsApplication.SelectDropdownSpecifiedValue(CheckTypeCombobox, CheckType);
            SendKeys.SendWait("{TAB}");
            windowsApplication.SetFieldValue(txtNotes, "RT Number : " + RTNumber + ", Check Type : " + CheckType);
            windowsApplication.ClickObeject(buttonOK);
        }
        public virtual void Enter120ContributionTransactionDetails(string contributioncode, string value1,string value2)
        {
            Profile7CommonLibrary.WaitUntilWindowLoads(TranDetailWindow);
            string randdata=webApplication.CreateRamdomData(FieldType.NUMERIC,100,999).ToString();
            windowsApplication.SelectDropdownSpecifiedValue(dropdownContributionCode, contributioncode);
            string runtimeAutoID = (string)windowsApplication.GetObjectProperty(dropdownContributionCode, ObjectProperty.AutomationId);
            runtimeAutoID = (string)windowsApplication.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";4", ObjectProperty.AutomationId);
            windowsApplication.ClickObeject("Text=Forward by small amount");
            windowsApplication.SelectContextMenuItem("Text=Forward by small amount", true, "Scroll Here");
            windowsApplication.SetFieldValue(txtpostonedcontribution, value1);
            windowsApplication.SetFieldValue(txtFedDesigDisasteArea, value2);
            SendKeys.SendWait("{TAB}");
            windowsApplication.SetFieldValue(txtNotes,"Note"+randdata);
            windowsApplication.ClickObeject(buttonOK);

        }    

        // public virtual bool VerifyRSPFederalStateFieldsNotExists(string DistributionCode)
        // {
        //     WebApplication webApplication = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //     string randdata = webApplication.CreateRamdomData(FieldType.NUMERIC, 100, 999).ToString();
        //     Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Transaction Detail");
        //     Profile7CommonLibrary.VerifyWindowObjectExists(dropdownDistributionCode);
        //     windowsApplication.SelectDropdownSpecifiedValue(dropdownDistributionCode, DistributionCode);
        //     SendKeys.SendWait("{TAB}");
         
        //     bool Result = false;
        //     if(Profile7CommonLibrary.VerifyWindowObjectExists(txtRSPFederalWithholdingAmount)==false)
        //     {
        //         if(Profile7CommonLibrary.VerifyWindowObjectExists(txtRSPStateWithholdingAmount)==false)
        //         {
        //             Result = true;
                    
        //         }
        //     }
        //     // if(Result)
        //     // {
        //     //     Report.Pass("RSP State Withholding Amount and RSP Federal Withholding Amount are not displayed.", "Transactionpass", "true", applicationHandle);
        //     // }
        //     // else
        //     // {
        //     //     Report.Fail("RSP State Withholding Amount and RSP Federal Withholding Amount are still displaying.", "TransactionFail", "True", applicationHandle);
        //     // }
        //     windowsApplication.SetFieldValue(txtNotes, "Note" + randdata); 
        //     windowsApplication.ClickObeject(buttonOK);
        //     return Result;         
        // }  



    }
}
