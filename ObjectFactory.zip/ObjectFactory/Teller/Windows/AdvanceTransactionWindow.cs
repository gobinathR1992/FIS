using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using GTS_CORE.CoreLibs;
//using GTS_CORE.HelperLibs.Reporter;
using System.Threading;
using Profile7Automation.Libraries.Util;
using System.Windows.Forms;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class AdvanceTransactionWindow : MasterWindow
    {
        public WindowsApplication appHandle;
        private Object tellerWindowName = "jp2launcher;" + "Profile Teller " + StartupConfiguration.EnvironmentDetails.TellerVersion;
        private static Object AdvanceTransactionComboBox = "ClassName=ComboBox";
        private static Object AdvanceTransactionAmountField = "ClassName=Edit";
        private static Object AddImage = "AddImage.PNG";
        private static object SearchImage = "SearchImage.PNG";
        private static string dropdownTransactionType = "ControlType=ComboBox;Index=0";
        private static string TransactionDetailWindow = "jp2launcher;Transaction Detail";
        private static string dropdownCloseOutReason = "ControlType=ComboBox;Index=0";
        private static string txtNotes = "ControlType=Document;Index=0";
        private static string dropdownTransactionType1 = "ControlType=ComboBox;Index=3";
        private static string buttonOK = "Text=OK";
        private static string txtAccountNumberLeg1 = "ControlType=Edit;Index=2";
        private static string txtAccountNumberLeg2 = "ControlType=Edit;Index=6";
        private static string txtAmountLeg2 = "ControlType=Edit;Index=7";
        private static string txtAmountLeg1 = "ControlType=Edit;Index=3";
        private string tabTransactionList = "Control Type=TabItem;Text=Transaction List";
        private string tableHeaderTransactionList = "Control Type=HeaderItem;Name=Base Eq Amount";
        private static string ButtonPlusSignLeg1 = "Text=Type" + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSiblingKthChild + ";1;2";
        static int itemIndex;
        MasterWindow mw = new MasterWindow();
        PostTransaction pt = new PostTransaction();
        private static string dropdownReasonCode1 = "ControlType=ComboBox;Index=0";
        private static string dropdownReasonCode2 = "ControlType=ComboBox;Index=1";
        TransactionCodeSearchwindow transactionCodeSearchwindow = new TransactionCodeSearchwindow();

        /// <summary>
        /// To post transaction using Advance transaction window.
        /// </summary>
        /// <param name="transactionDetails"></param>
        /// <param name="effectiveDate"></param>
        /// <param name="isPost"></param>
        /// <example>
        /// <code>
        /// Ex: 1 - For single transaction.
        /// string[] TRANSACTIONDETAILS = new string[5];
        /// TRANSACTIONDETAILS[0] = "SD - SAV Deposit;CI - Cash-In"; /Transaction Type
        /// TRANSACTIONDETAILS[1] = "300000139981;3362"; / Account Number
        /// TRANSACTIONDETAILS[2] = "1000;1000"; / Amount
        /// TRANSACTIONDETAILS[3] = "USD;USD"; / Currency Type (optional)
        /// TRANSACTIONDETAILS[4] = "";
        /// string effectiveDate = "11/11/2012"; / effective date (Optional)
        /// bool isPosting = true; / If user want to post the transaction pass 'true' else pass 'false' for not posting.
        /// Application.Teller.AdvanceTransaction(TRANSACTIONDETAILS,effectiveDate,false);
        /// 
        /// Ex: 2 - For multiple transaction.
        /// string[] TRANSACTIONDETAILS = new string[5];
        /// TRANSACTIONDETAILS[0] = "SD - SAV Deposit;SD - SAV Deposit;CI - Cash-In"; /Transaction Type
        /// TRANSACTIONDETAILS[1] = "300000139981;300000139982;3362"; / Account Number
        /// TRANSACTIONDETAILS[2] = "1000;1000;2000"; / Amount
        /// TRANSACTIONDETAILS[3] = "USD;USD;USD"; / Currency Type (optional)
        /// TRANSACTIONDETAILS[4] = "";
        /// string effectiveDate = "11/11/2012"; / effective date (Optional)
        /// bool isPosting = true; / If user want to post the transaction pass 'true' else pass 'false' for not posting.
        /// Application.Teller.AdvanceTransaction(TRANSACTIONDETAILS,effectiveDate,false);
        /// </code>
        /// </example>
        public virtual void AdvanceTransaction(string[] transactionDetails, string effectiveDate, bool isPost = true)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            ApplicationInstance instance = new ApplicationInstance(appHandle);
            try
            {
                string[] transTypes = appHandle.SplitString(transactionDetails[0], ";");
                string[] transAccounts = appHandle.SplitString(transactionDetails[1], ";");
                string[] transAmounts = appHandle.SplitString(transactionDetails[2], ";");
                string[] transCurrency = null;
                if (transactionDetails[3].Contains(";"))
                {
                    transCurrency = appHandle.SplitString(transactionDetails[3], ";");
                }
                if (appHandle.Launch_Application(tellerWindowName))
                {
                    appHandle.Sendkeys(appHandle.GetSpecialKey("F9"));
                    Thread.Sleep(3000);
                    if (!effectiveDate.Equals(""))
                    {
                        mw.set_effective_date(effectiveDate);
                    }
                    if (transCurrency != null)
                        EnterAdvanceTransactionDetails(transTypes, transAccounts, transAmounts, transCurrency);
                    else
                        EnterAdvanceTransactionDetails(transTypes, transAccounts, transAmounts);
                    if (isPost == true)
                    {
                        pt.PostTellerTransaction(isPost);
                        Thread.Sleep(3000);
                    }
                }
                else
                {
                    Report.Fail("Unable to launch application");
                }

            }
            catch (IndexOutOfRangeException e)
            {
                throw new Exception(e.Message);
            }

        }

        private void EnterAdvanceTransactionDetails(string[] transTypes, string[] transAccounts, string[] transAmounts, string[] transCurrency = null)
        {
            int comboboxCount, editboxCount, AddCount;
            AddCount = 1;
            for (int i = 0; i < transTypes.Length; i++)
            {
                comboboxCount = appHandle.FindElements(AdvanceTransactionComboBox).Length;
                editboxCount = appHandle.FindElements(AdvanceTransactionAmountField).Length;
                if (transCurrency != null)
                    EnterValuesInARow(transTypes[i], transAccounts[i], transAmounts[i], comboboxCount, editboxCount, transCurrency[i]);
                else
                    EnterValuesInARow(transTypes[i], transAccounts[i], transAmounts[i], comboboxCount, editboxCount);
                if (AddCount < transTypes.Length)
                {
                    appHandle.ClickObjectByImage(AddImage, MouseClick.LeftClick);
                    AddCount++;
                }
            }
        }

        private void EnterValuesInARow(string transType, string transAccount, string transAmount, int comboboxCount, int editboxCount, string transCurrency = null)
        {
            if (transCurrency != null)
            {
                appHandle.SetFieldValue(AdvanceTransactionComboBox + ";Index=" + (comboboxCount - 1) + "", transCurrency);
            }
            appHandle.SetFieldValue(AdvanceTransactionComboBox + ";Index=" + (comboboxCount - 3) + "", transType);
            appHandle.SetFieldValue(AdvanceTransactionComboBox + ";Index=" + (comboboxCount - 2) + "", transAccount);
            appHandle.SetFieldValue(AdvanceTransactionAmountField + ";Index=" + (editboxCount - 1), transAmount);
        }



        /// <summary>
        /// To post transaction using Advance transaction window.
        /// </summary>
        /// <param name="transactionDetails"></param>
        /// <param name="effectiveDate"></param>
        /// <param name="isPost"></param>
        /// <example>
        /// <code>
        /// Ex: 1 - For single transaction.
        /// string[] TRANSACTIONDETAILS = new string[5];
        /// TRANSACTIONDETAILS[0] = "SD"; /Transaction Type
        /// TRANSACTIONDETAILS[1] = "300000139981;3362"; / Account Number
        /// TRANSACTIONDETAILS[2] = "1000;1000"; / Amount
        /// TRANSACTIONDETAILS[3] = "USD;USD"; / Currency Type (optional)
        /// TRANSACTIONDETAILS[4] = "";
        /// string effectiveDate = "11/11/2012"; / effective date (Optional)
        /// bool isPosting = true; / If user want to post the transaction pass 'true' else pass 'false' for not posting.
        /// Application.Teller.AdvanceTransaction(TRANSACTIONDETAILS,effectiveDate,false);
        /// 
        /// Ex: 2 - For multiple transaction.
        /// string[] TRANSACTIONDETAILS = new string[5];
        /// TRANSACTIONDETAILS[0] = "SD;SD;CI"; /Transaction Type
        /// TRANSACTIONDETAILS[1] = "300000139981;300000139982;3362"; / Account Number
        /// TRANSACTIONDETAILS[2] = "1000;1000;2000"; / Amount
        /// TRANSACTIONDETAILS[3] = "USD;USD;USD"; / Currency Type (optional)
        /// TRANSACTIONDETAILS[4] = "";
        /// string effectiveDate = "11/11/2012"; / effective date (Optional)
        /// bool isPosting = true; / If user want to post the transaction pass 'true' else pass 'false' for not posting.
        /// Application.Teller.AdvanceTransactionbyCodeSearch(TRANSACTIONDETAILS,effectiveDate,false);
        /// </code>
        /// </example>
        public virtual void AdvanceTransactionbyCodeSearch(string[] transactionDetails, string effectiveDate, bool isPost = true)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            ApplicationInstance instance = new ApplicationInstance(appHandle);
            try
            {
                string[] transTypes = appHandle.SplitString(transactionDetails[0], ";");
                string[] transAccounts = appHandle.SplitString(transactionDetails[1], ";");
                string[] transAmounts = appHandle.SplitString(transactionDetails[2], ";");
                string[] transCurrency = null;
                if (transactionDetails[3].Contains(";"))
                {
                    transCurrency = appHandle.SplitString(transactionDetails[3], ";");
                }
                if (appHandle.Launch_Application(tellerWindowName))
                {
                    appHandle.Sendkeys(appHandle.GetSpecialKey("F9"));
                    Thread.Sleep(3000);
                    if (!effectiveDate.Equals(""))
                    {
                        mw.set_effective_date(effectiveDate);
                    }

                    appHandle.ClickObjectByImage(SearchImage, MouseClick.LeftClick);




                    if (transCurrency != null)
                        EnterAdvanceTransactionDetailsByCodeSearch(transTypes, transAccounts, transAmounts, transCurrency);
                    else
                        EnterAdvanceTransactionDetailsByCodeSearch(transTypes, transAccounts, transAmounts);
                    if (isPost == true)
                    {
                        pt.PostTellerTransaction(isPost);
                        Thread.Sleep(3000);
                    }
                }
                else
                {
                    Report.Fail("Unable to launch application");
                }

            }
            catch (IndexOutOfRangeException e)
            {
                throw new Exception(e.Message);
            }

        }


        private void EnterAdvanceTransactionDetailsByCodeSearch(string[] transTypes, string[] transAccounts, string[] transAmounts, string[] transCurrency = null)
        {
            int comboboxCount, editboxCount, AddCount;
            AddCount = 1;
            for (int i = 0; i < transTypes.Length; i++)
            {
                comboboxCount = appHandle.FindElements(AdvanceTransactionComboBox).Length - 1;
                editboxCount = appHandle.FindElements(AdvanceTransactionAmountField).Length;
                if (transCurrency != null)
                {
                    transactionCodeSearchwindow.enter_transaction_code_search(transTypes[i]);
                    EnterValuesInRowwithouttransactioncodes(transAccounts[i], transAmounts[i], comboboxCount, editboxCount, transCurrency[i]);
                }
                else
                    transactionCodeSearchwindow.enter_transaction_code_search(transTypes[i]);
                EnterValuesInRowwithouttransactioncodes(transAccounts[i], transAmounts[i], comboboxCount, editboxCount);
                if (AddCount < transTypes.Length)
                {
                    appHandle.ClickObjectByImage(AddImage, MouseClick.LeftClick);
                    AddCount++;
                }
            }
        }

        private void EnterValuesInRowwithouttransactioncodes(String transAccount, string transAmount, int comboboxCount, int editboxCount, string transCurrency = null)
        {
            if (transCurrency != null)
            {
                appHandle.SetFieldValue(AdvanceTransactionComboBox + ";Index=" + (comboboxCount - 1) + "", transCurrency);
            }
            appHandle.SetFieldValue(AdvanceTransactionComboBox + ";Index=" + (comboboxCount - 2) + "", transAccount);
            appHandle.SetFieldValue(AdvanceTransactionAmountField + ";Index=" + (editboxCount - 1), transAmount);
        }
        
        public virtual bool EnterLoanPayOffAdvanceTransactionsDetails(string AccountNumber, string GLTransactionCode, string AccountProdSpecificTransactionCode, string Amount, string Currency = "", string CloseOutReason = "")
        {
            bool Result = false;
            if (string.IsNullOrEmpty(Amount)) { }
            else
            {
                Amount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Amount);
            }
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType);
            applicationHandle.SetFieldValue(dropdownTransactionType, AccountProdSpecificTransactionCode);
            applicationHandle.SetFieldValue(txtAccountNumberLeg1, AccountNumber);
            txtAmountLeg1 = "Text=" + AccountNumber + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            applicationHandle.SetFieldValue(txtAmountLeg1, Amount);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=2", Currency, false);

            }
            if (string.IsNullOrEmpty(CloseOutReason))
            {
                CloseOutReason = Data.Get("3 - Unhappy with Service");
            }

            applicationHandle.ClickObeject("Text=" + Amount + ";LabelRelationShip=" + LabelRelationShip.NthSibling + ";2");
            Profile7CommonLibrary.WaitUntilWindowLoads(TransactionDetailWindow);
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownCloseOutReason);
            applicationHandle.SelectDropdownSpecifiedValue(dropdownCloseOutReason, CloseOutReason);
            SendKeys.SendWait("{TAB}");
            applicationHandle.SetFieldValue(txtNotes, "Notes for : " + AccountNumber);
            applicationHandle.ClickObeject(buttonOK);

            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            applicationHandle.ClickObeject(ButtonPlusSignLeg1);
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType1);
            applicationHandle.SetFieldValue(dropdownTransactionType1, GLTransactionCode);

            applicationHandle.SetFieldValue(txtAccountNumberLeg2, Data.Get("GLACCOUNT"));
            txtAmountLeg2 = "Text=" + Data.Get("GLACCOUNT") + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            applicationHandle.SetFieldValue(txtAmountLeg2, Amount);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=5", Currency, false);

            }
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;

        }


        public virtual bool VerifyAdvancedTransactionTabClosedAfterTransaction()
        {
            string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
            bool Result = false;
            try
            {
                if (Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation))
                {
                    Result = true;
                }
            }
            catch (Exception e)
            {
                Result = false;
            }
            return Result;

        }

        public virtual bool EnterLoanDisbursementAdvanceTransactionsDetails(string AccountNumber, string GLTransactionCode, string AccountProdSpecificTransactionCode, string Amount, string Currency = "")
        {
            bool Result = false;
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType, 50);
            applicationHandle.SetFieldValue(dropdownTransactionType, AccountProdSpecificTransactionCode);
            Amount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Amount);
            applicationHandle.SetFieldValue(txtAccountNumberLeg1, AccountNumber);
            txtAmountLeg1 = "Text=" + AccountNumber + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            applicationHandle.SetFieldValue(txtAmountLeg1, Amount);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=2", Currency, false);

            }
            applicationHandle.ClickObeject(ButtonPlusSignLeg1);
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType1);

            applicationHandle.SetFieldValue(dropdownTransactionType1, GLTransactionCode);
            applicationHandle.SetFieldValue(txtAccountNumberLeg2, Data.Get("GLACCOUNT"));
            txtAmountLeg2 = "Text=" + Data.Get("GLACCOUNT") + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            applicationHandle.SetFieldValue(txtAmountLeg2, Amount);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=5", Currency, false);

            }
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);

            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;

        }
        public virtual bool AdvanceTransactions(string AccountNumber, string glnumber, string accountcode, string GLTransactionCode, string Amount, string Currency = "")
        {
            bool Result = false;
            applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType, 50);
            applicationHandle.SetFieldValue(dropdownTransactionType, accountcode);
            Amount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Amount);
            applicationHandle.SetFieldValue(txtAccountNumberLeg1, AccountNumber);
            txtAmountLeg1 = "Text=" + AccountNumber + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            applicationHandle.SetFieldValue(txtAmountLeg1, Amount);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=2", Currency, false);

            }
            applicationHandle.ClickObeject(ButtonPlusSignLeg1);
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType1);

            applicationHandle.SetFieldValue(dropdownTransactionType1, GLTransactionCode);
            applicationHandle.SetFieldValue(txtAccountNumberLeg2, glnumber);
            txtAmountLeg2 = "Text=" + glnumber + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            applicationHandle.SetFieldValue(txtAmountLeg2, Amount);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=5", Currency, false);

            }
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);

            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;

        }
        public virtual bool EnterDepositAccountCloseOutAdvanceTransactionsDetails(string AccountNumber, string GLTransactionCode, string AccountProdSpecificTransactionCode, string Amount, string Currency = "", string CloseOutReason = "")
        {
            return EnterLoanPayOffAdvanceTransactionsDetails(AccountNumber, GLTransactionCode, AccountProdSpecificTransactionCode, Amount, Currency, CloseOutReason);
        }

        public virtual bool EnterDetailsIRADistributionAdvancedTransactions(string AccountNumber, string GLTransactionCode, string AccountProdSpecificTransactionCode, string Amount, string ContrCode1, string ContrCode2, string Amount1, string Amount2, string Currency = "")
        {
            bool Result = false;

            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType);
            applicationHandle.SetFieldValue(dropdownTransactionType, AccountProdSpecificTransactionCode);
            applicationHandle.SetFieldValue(txtAccountNumberLeg1, AccountNumber);
            txtAmountLeg1 = "Text=" + AccountNumber + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            string txtAmountLeg1AutoID = (string)applicationHandle.GetObjectProperty(txtAmountLeg1, ObjectProperty.AutomationId);
            string RedFlag="AutomationId="+txtAmountLeg1AutoID+ ";LabelRelationShip=" + LabelRelationShip.NthSibling+";2";
            applicationHandle.SetFieldValue(txtAmountLeg1, Amount);
            applicationHandle.ClickObeject(RedFlag);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=2", Currency, false);

            }
            EnterIRADistributionTransactionDetailsWindow(AccountNumber, ContrCode1, ContrCode2, Amount1, Amount2);
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            applicationHandle.ClickObeject(ButtonPlusSignLeg1);
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType1);
            applicationHandle.SetFieldValue(dropdownTransactionType1, GLTransactionCode);

            applicationHandle.SetFieldValue(txtAccountNumberLeg2, Data.Get("GLACCOUNT"));
            txtAmountLeg2 = "Text=" + Data.Get("GLACCOUNT") + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            applicationHandle.SetFieldValue(txtAmountLeg2, Amount);
            if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=5", Currency, false);

            }
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;
        }

        public virtual bool EnterIRADistributionTransactionDetailsWindow(string AccountNumber, string ContrCode1, string ContrCode2, string Amount1, string Amount2)
        {
            bool Result = false;
            Profile7CommonLibrary.WaitUntilWindowLoads(TransactionDetailWindow);
            applicationHandle.SelectDropdownSpecifiedValue(dropdownReasonCode1, ContrCode1);
            string runtimeAutoID = (string)applicationHandle.GetObjectProperty(dropdownReasonCode1, ObjectProperty.AutomationId);
            runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";3", ObjectProperty.AutomationId);
            applicationHandle.ClickObeject("Text=Forward by small amount");
            applicationHandle.SelectContextMenuItem("Text=Forward by small amount", true, "Scroll Here");
            applicationHandle.SetFieldValue("AutomationId=" + runtimeAutoID, Amount1);
            runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.NextSibling, ObjectProperty.AutomationId);
            applicationHandle.ClickObeject("AutomationId=" + runtimeAutoID);
            applicationHandle.ClickObeject("Text=Back by small amount");
            applicationHandle.SelectContextMenuItem("Text=Back by small amount", true, "Scroll Here");
            applicationHandle.SelectDropdownSpecifiedValue(dropdownReasonCode2, ContrCode2);
            runtimeAutoID=(string)applicationHandle.GetObjectProperty(dropdownReasonCode2, ObjectProperty.AutomationId);
            applicationHandle.ClickObeject("Text=Forward by small amount");
            applicationHandle.SelectContextMenuItem("Text=Forward by small amount", true, "Scroll Here");
          
            runtimeAutoID = (string)applicationHandle.GetObjectProperty("AutomationId=" + runtimeAutoID + ";LabelRelationShip=" + LabelRelationShip.ParentsNthSibling + ";3", ObjectProperty.AutomationId);
            applicationHandle.SetFieldValue("AutomationId=" + runtimeAutoID, Amount2);
            applicationHandle.SetFieldValue(txtNotes, "Notes for IRA Distribution for Account Number : " + AccountNumber);
            if (CheckIfOKButtonEnabled())
            {
                Report.Info("IRA distribution transactions are entered for account number : " + AccountNumber, "transdetail", "True", applicationHandle);
            }


            applicationHandle.ClickObeject(buttonOK);
            if (Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller"))
            {
                Result = true;
            }
            return Result;
        }
        public virtual bool CheckIfOKButtonEnabled()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads(TransactionDetailWindow);
            bool Result = false;
            for (int i = 1; i <= 200; i++)
            {
                try
                {
                    Result = (bool)applicationHandle.GetObjectProperty(buttonOK, ObjectProperty.IsEnable);
                    if (Result)
                    {
                        Result = true;
                        break;
                    }
                    else
                    {
                        Result = false;
                        break;
                    }
                }
                catch (Exception e) { };
            }

            return Result;
        }


        public virtual bool EnterDetailsIRAContributionAdvancedTransactions(string AccountNumber, string GLTransactionCode, string AccountProdSpecificTransactionCode, string Amount, string ContributionCodePipeDelimited, string AmountPipeDelimited,string Currency = "")
        {
            bool Result = false;

            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType);
            applicationHandle.SetFieldValue(dropdownTransactionType, AccountProdSpecificTransactionCode);
            applicationHandle.SetFieldValue(txtAccountNumberLeg1, AccountNumber);
            txtAmountLeg1 = "Text=" + AccountNumber + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            string txtAmountLeg1AutoID = (string)applicationHandle.GetObjectProperty(txtAmountLeg1, ObjectProperty.AutomationId);
            string RedFlag="AutomationId="+txtAmountLeg1AutoID+ ";LabelRelationShip=" + LabelRelationShip.NthSibling+";2";
            applicationHandle.SetFieldValue(txtAmountLeg1, Amount);
            applicationHandle.ClickObeject(RedFlag);
            if (string.IsNullOrEmpty(Currency))
            {
                Currency = Data.Get("USD");
                
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=2", Currency, false);

            }
            TellerPageFactory.DepositFundWindows.EnterIRAContributionMultiTransactionDetails(AccountNumber, ContributionCodePipeDelimited, AmountPipeDelimited);
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            applicationHandle.ClickObeject(ButtonPlusSignLeg1);
            Profile7CommonLibrary.VerifyWindowObjectExists(dropdownTransactionType1);
            applicationHandle.SetFieldValue(dropdownTransactionType1, GLTransactionCode);
            applicationHandle.SetFieldValue(txtAccountNumberLeg2, Data.Get("GLACCOUNT"));
            txtAmountLeg2 = "Text=" + Data.Get("GLACCOUNT") + ";LabelRelationShip=" + LabelRelationShip.ParentsNextSiblingChild;
            applicationHandle.SetFieldValue(txtAmountLeg2, Amount);
             if (string.IsNullOrEmpty(Currency))
            {
                {
                    Currency = Data.Get("USD");
                }
            }
            if (!Currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SelectDropdownSpecifiedValue("Type=ComboBox;Index=5", Currency, false);

            }
            Profile7CommonLibrary.VerifyWindowObjectExists(tabTransactionList);
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;

         }

        

    }
}