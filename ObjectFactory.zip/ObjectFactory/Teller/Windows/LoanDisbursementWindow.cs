﻿using System;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using System.Windows.Forms;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class LoanDisbursementWindow
    {

        static WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private Object tellerWindowName = "jp2launcher;" + "Profile Teller ";
        private static string Account = "ClassName=ComboBox;Index=1";
        private static string txtAccountNumber = "ClassName=Edit;AutomationId=1001";
        private static string txtCashOutCurrency = "ClassName=Edit;Index=1";

        //private static Object AmountVal = "ClassName=Edit;Index=4";
        // private static Object DisbursementAmount = "ClassName=Edit;Index=1";
        private static Object DisbursementAmount = "ClassName=Edit;Index=2";
        private static string txtCashOut = "Name=Cash Out:;ControlType=Edit";
        private static Object Status = "Name=Status";
        private static String Window = "Print Receipt";
        private static Object YesBtn = "ControlType=Button;Text=Yes";
        private static Object NoBtn = "ControlType=Button;Text=No";
        private static string AmountText = "ClassName=Edit;Index=2";
        private string tabTransactionList = "Control Type=TabItem;Text=Transaction List";
        private string tableHeaderTransactionList = "Control Type=HeaderItem;Name=Base Eq Amount";
        private string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
        private static string AccBalance = "ClassName=Static;ControlType=Text;Index=23";
        //Object F12 = KeyboardInput.SpecialKeys.F12;
        //Object TAB = KeyboardInput.SpecialKeys.TAB;
        Object screenShotName1 = "TellerLoanDisbursementScreen";
        Object screenShotName2 = "TellerScreenLoanDisbursement";


        public virtual void DisburseFund(string AccountNo, string Amount)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                applicationHandle.Wait_For_Specified_Time(2);
                applicationHandle.ClickObeject(MasterWindow.btnstatus);
                applicationHandle.Sendkeys("{F5}");
                applicationHandle.WaitForObject(Account, 10);
                applicationHandle.SetFieldValue(Account, AccountNo);
                applicationHandle.WaitForObject(DisbursementAmount, 10);
                applicationHandle.SetFieldValue(DisbursementAmount, Amount);
                applicationHandle.Sendkeys("{TAB}");
                applicationHandle.Wait_For_Specified_Time(3);
                applicationHandle.SetFieldValue(txtCashOut, Amount);
                applicationHandle.Sendkeys("{F12}");
                string VAl = applicationHandle.GetTextFromField(AccBalance);
                if (VAl.Equals("0.00"))
                {
                    applicationHandle.Wait_For_Specified_Time(2);
                    applicationHandle.Sendkeys("{F12}");
                    //applicationHandle.SelectButton(Status);
                }
                else
                {
                    {
                        Report.Info("Transaction is not balanced.");
                    }
                }
                // Report.Info("Information added to screen", screenShotName1, "True", applicationHandle);


                if (applicationHandle.IsWindowExists(Window))
                    applicationHandle.PerformActionOnDialogWindow(Window, NoBtn, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                applicationHandle.Wait_For_Specified_Time(6);
                Report.Pass("Information added to screen", screenShotName2, "True", applicationHandle);
            }
            else
            {
                Report.Fail("Unable to launch application");
                throw new Exception("Unable to launch application");
            }

        }

        public virtual void enter_loan_disbursement_details(string sEffectiveDate, string[] arrActionEntries)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);

            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                string sTellerApplnDate = TellerPageFactory.MasterWindow.get_pd_teller_application_date();
                if (!sTellerApplnDate.Equals(sEffectiveDate))
                {
                    TellerPageFactory.MasterWindow.set_effective_date(sEffectiveDate);
                    Report.Info("Changed the Effective Date.");
                }
                applicationHandle.Wait_For_Specified_Time(2);
                //applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("F5"));
                applicationHandle.ClickObeject(MasterWindow.btnstatus);
                applicationHandle.Sendkeys("{F5}");
                applicationHandle.WaitForObject(Account, 10);
                applicationHandle.SetFieldValue(Account, arrActionEntries[2]);
                //applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("TAB"));
                applicationHandle.Sendkeys("{TAB}");
                applicationHandle.WaitForObject(DisbursementAmount, 10);
                applicationHandle.SetFieldValue(DisbursementAmount, arrActionEntries[1]);
                applicationHandle.SetFieldValue(txtCashOut, arrActionEntries[4]);
                Report.Info("Information added to screen", screenShotName1, "True", applicationHandle);

                string sBalanceValue = applicationHandle.GetTextFromField(AccBalance);

                if (sBalanceValue.Equals("0.00"))
                {
                    Report.Info("Transaction is balanced.");
                }
                else
                {
                    Report.Info("Transaction is not balanced.");
                }
            }
            else
            {
                Report.Fail("Unable to launch application");
                throw new Exception("Unable to launch application");
            }
        }

        public virtual bool EnterLoanDisbursementDetails(string AccountNumber, string Amount, bool IsOverride = false,string currency = "")
        {
            bool Result = false;
            bool x = Profile7CommonLibrary.WaitUntilWindowLoads((string)tellerWindowName);
            Profile7CommonLibrary.VerifyWindowObjectExists(txtCashOut);
                  
            Profile7CommonLibrary.VerifyWindowObjectExists(Account);
            applicationHandle.SetFieldValue(Account, AccountNumber);
            SendKeys.SendWait("{TAB}");
            Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation);
            applicationHandle.SetFieldValue(AmountText,Amount);
            applicationHandle.SetFieldValue(txtCashOut, Amount);
            if (string.IsNullOrEmpty(currency))
            {
                {
                    currency = Data.Get("USD");
                }
            }
            if (!currency.Contains(Data.Get("USD")))
            {
                applicationHandle.SetFieldValue(txtCashOutCurrency, currency);
                applicationHandle.ClickObeject(txtCashOutCurrency);
                SendKeys.SendWait("{ENTER}");
            }
            
            applicationHandle.ClickObeject(tabTransactionList);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(tableHeaderTransactionList))
            {
                Result = true;
            }
            return Result;

        }
        public virtual bool VerifyLoanDisbursementTabClosedAfterTransaction()
        {
      //  bool x = applicationHandle.Launch_Application(tellerWindowName);
            string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
            bool Result = false;
            try
            {
                if (Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation))
                {
                    Result = true;
                }
            }
            catch (Exception e)
            {
                Result = false;
            }
            return Result;
        }

    }
}
