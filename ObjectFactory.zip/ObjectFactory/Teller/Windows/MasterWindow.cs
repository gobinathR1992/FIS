﻿using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Windows.Forms;
using Profile7Automation.Libraries.Util;
using System.Globalization;

namespace Profile7Automation.ObjectFactory.Teller.Windows
{
    public class MasterWindow
    {
        public static WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private string tellerWindowName = "jp2launcher;" + "Profile Teller";
        private static string Transactions = "Text=Transactions";
        private static string ChangeEffectiveDate = "ControlType=Button;Text=Change Effective Date<Alt+3>";

        private string EffectiveDateDialog = "jp2launcher;Effective Date";
        private string OverrideWindowName = "Authorization Override Required";
        private static string OverrideWindow = "jp2launcher;Authorization Override Required";
        private string OverrideWindow_UserIDField = "ControlType=Edit;Name=Password;Index=0";
        private string OverrideWindow_PasswordField = "ControlType=Edit;Name=Password;Index=1";
        private string OverrideWindow_CancelButton = "ControlType=Button;Text=Cancel";
        private static string DatePickerWindow = "Effective Date";
        private static string monthCombobox = "ControlType=ComboBox";
        private static string monthLIstItem = "ControlType=ListItem;Name=December";
        private static string daySpinner = "ControlType=Spinner;Index=0";
        //"ClassName=msctls_updown32;Index=0";
        private static string yearSpinner = "ControlType=Spinner;Index=1";         //"ClassName=msctls_updown32;Index=1";
        private static string OkButton = "ControlType=Button;Text=OK";
        private static string SystemDate = "ClassName=Static;ControlType=Text;Index=9";
        private static string Window = "Print Receipt";
        private static string YesBtn = "ControlType=Button;Text=Yes";
        private static string NoBtn = "ControlType=Button;Text=No";
        string screenShotName2 = "TellerScreenLoanDisbursement";
        string windowPrintReceipt = "jp2launcher;Print Receipt";
        string WindowAuditPrintReceipt = "jp2launcher;Audit Trail Printing";
        string windowProgressInformation = "jp2launcher;Progress Information";
        private static string buttonQuit = "ControlType=Button;Text=Quit<Ctrl+Alt+Q>";
        private static string SecurityTitleBar = "Name=Security Warning;ControlType=TitleBar";
        public static string btnstatus = "Text=Status";
        private static string OKBtn = "ClassName=Button;Text=OK";
        private static string buttonAnalyzeTransactions = "Text=" + "Analyze Transactions<Alt+2>";
        private static string ButtonPostTransactions = "Text=Post Transactions<F12>";
        private string tabCustomerInformation = "Control Type=TabItem;Text=Customer Information";
        static string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        static string PWD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
        public virtual void set_effective_date(string sEffectiveDate)
        {
            WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            string AutoId2 = "";
            string TreeParent = "";
            string CurrentPostingDate = "";

            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;" + "Profile Teller");
            TreeParent = (string)applicationHandle.GetObjectProperty("Text=Account Information" + ";LabelRelationShip=" + LabelRelationShip.NthParent + ";3", ObjectProperty.AutomationId);
            AutoId2 = (string)applicationHandle.GetObjectProperty("AutomationId=" + TreeParent + ";LabelRelationShip=" + LabelRelationShip.NthNextSiblingKthChild + ";1;11", ObjectProperty.AutomationId);
            CurrentPostingDate = (string)applicationHandle.GetObjectProperty("AutomationId=" + AutoId2, ObjectProperty.Name);
            applicationHandle.ClickObeject(ChangeEffectiveDate);

            if (Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Effective Date"))
            {
                string[] dateARR = sEffectiveDate.Split('/');
                string month = dateARR[0];
                string day = dateARR[1];
                string year = dateARR[2];
                string sMonthName = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(Int32.Parse(month));
                string ApplicationDate = CurrentPostingDate;
                string YearPartCurrentAppDate = applicationHandle.GetDateParameters(ApplicationDate)[2].Trim();
                string AutoId1 = "";
                AutoId1 = (string)applicationHandle.GetObjectProperty("ControlType=ComboBox" + ";LabelRelationShip=" + LabelRelationShip.NthSibling + ";2", ObjectProperty.AutomationId);
                AutoId2 = (string)applicationHandle.GetObjectProperty("AutomationId=" + AutoId1 + ";LabelRelationShip=" + LabelRelationShip.NthChildKthChild + ";1;2", ObjectProperty.AutomationId);

                int numberOfClicks = 0;
                if (Int32.Parse(year) < Int32.Parse(YearPartCurrentAppDate))
                {
                    numberOfClicks = Int32.Parse(YearPartCurrentAppDate) - Int32.Parse(year);
                    AutoId1 = AutoId2;

                }
                if (Int32.Parse(year) > Int32.Parse(YearPartCurrentAppDate))
                {
                    numberOfClicks = Int32.Parse(year) - Int32.Parse(YearPartCurrentAppDate);
                    AutoId1 = (string)applicationHandle.GetObjectProperty("AutomationId=" + AutoId2 + ";LabelRelationShip=" + LabelRelationShip.PreviousSibling, ObjectProperty.AutomationId);
                }
                if (Int32.Parse(year) == Int32.Parse(YearPartCurrentAppDate)) { }

                if (day.Substring(0, 1).Equals("0"))
                {
                    day = day.Substring(1, 1);
                }
                applicationHandle.SelectDropdownSpecifiedValue("ControlType=ComboBox", sMonthName);
                if (numberOfClicks >= 1)
                {

                    for (int a = 1; a <= numberOfClicks; a++)
                    {
                        applicationHandle.ClickObeject("AutomationId=" + AutoId1 + ";Index=1");
                    }
                }
                if (Int32.Parse(day) == Int32.Parse(applicationHandle.GetDateParameters(ApplicationDate)[1])) { }
                else
                {
                    applicationHandle.ClickObeject("ClassName=Static;Text=" + day);
                }
                Report.Info("Effective date is selected as : " + sEffectiveDate, "EffectiveDateUpdate", "True", applicationHandle);
                applicationHandle.ClickObeject("Text=OK");
                Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;" + "Profile Teller");
                Profile7CommonLibrary.VerifyWindowObjectExists(tabCustomerInformation);

            }
        }

        public virtual string get_pd_teller_application_date()
        {
            string sSytemDate = null;
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                applicationHandle.Wait_For_Specified_Time(2);
                applicationHandle.ClickObeject(btnstatus);
                sSytemDate = applicationHandle.GetTextFromField(SystemDate);
            }
            return sSytemDate;
        }

        public virtual void post_teller_details()
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                applicationHandle.ClickObeject(btnstatus);
                applicationHandle.Sendkeys("{F12}");
                applicationHandle.Wait_For_Specified_Time(5);
                if (applicationHandle.IsWindowExists(Window))
                    applicationHandle.PerformActionOnDialogWindow(Window, NoBtn, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                Report.Pass("Transaction posted", screenShotName2, "True", applicationHandle);
            }
            else
            {
                Report.Fail("Unable to Post Transaction.");
                throw new Exception("Unable to Post Transaction.");
            }
        }

        public virtual void post_teller_details(string sOverride)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                applicationHandle.Sendkeys("{F12}");
                applicationHandle.PerformActionOnDialogWindow(Window, NoBtn, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));

                if (sOverride.ToUpper().Equals("YES"))
                {
                    bool blnExists = applicationHandle.IsWindowObjExist(tellerWindowName.ToString(),
                                                                    OverrideWindowName.ToString(),
                                                                    OverrideWindow_PasswordField.ToString());
                    if (blnExists)
                    {
                        teller_authorization_override_required_details();
                    }
                    else
                    {
                        Report.Pass("Transaction posted", screenShotName2, "True", applicationHandle);
                    }
                }
            }
            else
            {
                Report.Fail("Unable to Post Transaction.");
                throw new Exception("Unable to Post Transaction.");
            }
        }
        public virtual void post_teller_details_override_yes()
        {
            string sPassword = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                applicationHandle.Sendkeys("{F12}");
                applicationHandle.Wait_For_Specified_Time(5);
                applicationHandle.PerformActionOnDialogWindow(Window, NoBtn, new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                applicationHandle.Wait_For_Specified_Time(2);

                string sTellerUserClass = Data.Get("GLOBAL_PROFILE_TELLERUSRCLASS");

                if (sTellerUserClass.ToUpper().Equals("YES"))
                {
                    // Enter the supervisor User ID and Password to override the restriction.
                    // GLOBAL_USER_CLASS_SPV
                    // GLOBAL_SPV_USERID
                    // GLOBAL_SPV_PASSWORD
                }
                else
                {
                    // Enter Password field value on Authorization Override Required window.
                    applicationHandle.PerformActionOnDialogWindow(OverrideWindowName.ToString(),
                                                                    OverrideWindow_PasswordField,
                                                                    new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.SetText, sPassword));
                    applicationHandle.Sendkeys("{TAB}");
                    // Click on Ok button on Authorization Override Required window.
                    applicationHandle.PerformActionOnDialogWindow(OverrideWindowName.ToString(),
                                                                    OkButton,
                                                                    new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                    Report.Pass("Transaction posted", screenShotName2, "True", applicationHandle);
                }
            }
            else
            {
                Report.Fail("Unable to Post Transaction.");
                throw new Exception("Unable to Post Transaction.");
            }
        }


        public virtual void teller_authorization_override_required_details()
        {
            string sPassword = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
            if (applicationHandle.Launch_Application(tellerWindowName))
            {
                string sTellerUserClass = Data.Get("GLOBAL_PROFILE_TELLERUSRCLASS");
                if (sTellerUserClass.ToUpper().Equals("YES"))
                {
                    // Enter the supervisor User ID and Password to override the restriction.
                    // GLOBAL_USER_CLASS_SPV
                    // GLOBAL_SPV_USERID
                    // GLOBAL_SPV_PASSWORD
                }
                else
                {
                    // Enter Password field value on Authorization Override Required window.
                    applicationHandle.PerformActionOnDialogWindow(OverrideWindowName.ToString(),
                                                                    OverrideWindow_PasswordField,
                                                                    new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.SetText, sPassword));
                    //applicationHandle.Sendkeys(applicationHandle.GetSpecialKey("{TAB}"));
                    applicationHandle.Sendkeys("{TAB}");
                    // Click on Ok button on Authorization Override Required window.
                    applicationHandle.PerformActionOnDialogWindow(OverrideWindowName.ToString(),
                                                                    OkButton,
                                                                    new GTS_OSAF.CoreLibs.Action(GTS_OSAF.CoreLibs.ActionToPerform.Click));
                    Report.Pass("Transaction posted", screenShotName2, "True", applicationHandle);
                }
            }
            else
            {
                Report.Fail("Unable to enter the Authorization Override Required details.");
                throw new Exception("Unable to enter the Authorization Override Required details.");
            }
        }


        internal void errorcorrect_teller_transaction(string SelectionInfo, string OverrideFlag)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);

            string[] arrSelection;
            arrSelection = SelectionInfo.Split(';');
            string sTransactionCode = arrSelection[0];
            string sAccountNumber = arrSelection[1];
            string sAmount = arrSelection[2];

            bool blnSuccess = TellerPageFactory.ErrorCorrectWindow.errorcorrect_teller_transaction(SelectionInfo, OverrideFlag);

            if (blnSuccess)
            {
                Report.Pass("Transaction found for Transaction Code: <" + sTransactionCode + ">, Account: <" + sAccountNumber + "> and Amount: <" + sAmount + ">.", "Transaction_Error_Correction", "True", applicationHandle);
            }
            else
            {
                Report.Fail("Transaction not found for Transaction Code: <" + sTransactionCode + ">, Account: <" + sAccountNumber + "> and Amount: <" + sAmount + ">.", "Transaction_Error_Correction", "True", applicationHandle);
            }

        }
        internal void errorcorrect_teller_transaction_false(string SelectionInfo, string OverrideFlag)
        {
            applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);

            string[] arrSelection;
            arrSelection = SelectionInfo.Split(';');

            string sTransactionCode = arrSelection[0];
            string sAccountNumber = arrSelection[1];
            string sAmount = arrSelection[2];

            bool blnSuccess = TellerPageFactory.ErrorCorrectWindow.errorcorrect_teller_transaction(SelectionInfo, OverrideFlag);

            if (blnSuccess)
            {
                Report.Pass("Transaction not found for Transaction Code: <" + sTransactionCode + ">, Account: <" + sAccountNumber + "> and Amount: <" + sAmount + ">.", "Transaction_Error_Correction", "True", applicationHandle);
            }
            else
            {
                Report.Fail("Transaction found for Transaction Code: <" + sTransactionCode + ">, Account: <" + sAccountNumber + "> and Amount: <" + sAmount + ">.", "Transaction_Error_Correction", "True", applicationHandle);
            }
        }

        /// <summary>
        /// This method is used to compare two string values.
        /// <param name= "string1"></param> 
        /// <param name= "string2"></param>
        /// <returns>bool</returns> 
        /// <example>WebCSRMasterPage.comparestringvalues("Annual Yield","Annual Yield");<example>
        public virtual bool comparestringvalues(string string1, string string2)
        {
            bool OutputValue = false;
            try
            {
                int valu = string.Compare(string1, string2);
                if (valu == 0)
                    OutputValue = true;
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return OutputValue;
        }
        public virtual void PostTransactions(bool Override = false, string MessageToVerifyOnOverride = "", bool SubmitOverrideOrCancel = true)
        {
            bool LoginWindowLoaded = Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            bool flag = true;
            if (Profile7CommonLibrary.VerifyWindowObjectExists(ButtonPostTransactions))
            {
                applicationHandle.ClickObeject(ButtonPostTransactions);
                if (Override)
                {
                    Profile7CommonLibrary.WaitUntilWindowLoads(OverrideWindow);

                    if (!string.IsNullOrEmpty(MessageToVerifyOnOverride))
                    {
                        VerifyTextInDialogWindow(OverrideWindowName, MessageToVerifyOnOverride);
                    }
                    if (SubmitOverrideOrCancel)
                    {
                        Profile7CommonLibrary.VerifyWindowObjectExists(OverrideWindow_UserIDField);
                        applicationHandle.SetFieldValue(OverrideWindow_UserIDField, UID);
                        applicationHandle.SetFieldValue(OverrideWindow_PasswordField, PWD);
                        applicationHandle.ClickObeject(OKBtn);
                    }
                    else
                    {
                        Profile7CommonLibrary.VerifyWindowObjectExists(OverrideWindow_UserIDField);
                        applicationHandle.ClickObeject(OverrideWindow_CancelButton);
                    }
                    Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
                }

                if (applicationHandle.Launch_Application(windowPrintReceipt, 10, false, true))
                {
                    Profile7CommonLibrary.WaitUntilWindowLoads(windowPrintReceipt);
                    Profile7CommonLibrary.VerifyWindowObjectExists(YesBtn);
                    Report.Info("Confirmation message for printing  transaction receipt  is displayed", "posttransaction", "true", applicationHandle);
                    applicationHandle.ClickObeject(NoBtn);
                    Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
                }
                if (applicationHandle.Launch_Application(WindowAuditPrintReceipt, 10, false, true))
                {
                    Profile7CommonLibrary.WaitUntilWindowLoads(WindowAuditPrintReceipt);
                    Profile7CommonLibrary.VerifyWindowObjectExists(YesBtn);
                    Report.Info("Confirmation message for printing  window audit receipt  is displayed", "posttransaction", "true", applicationHandle);
                    applicationHandle.ClickObeject(NoBtn);
                    Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
                }
                if (applicationHandle.Launch_Application(windowProgressInformation, 10, false, true))
                {
                    do
                    {
                        Profile7CommonLibrary.WaitUntilWindowLoads(windowProgressInformation);
                    }
                    while (flag == true);

                }
            }
            else
            {
                Report.Fail("Post Transactions button is not enabled.", "posttransactionsfailed", "True", applicationHandle);
            }
            
        }
        public virtual void Quit_Teller()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName);
            if (Profile7CommonLibrary.VerifyWindowObjectExists(buttonQuit))
            {
                applicationHandle.ClickObeject(buttonQuit);

            }
        }
        public virtual void SelectTransaction(int TransactionOccurenceNumber)
        {
            string TractionOccurence = TransactionOccurenceNumber + "";
            Profile7CommonLibrary.VerifyWindowObjectExists(ChangeEffectiveDate);
            string AutoId1 = "";
            string AutoId2 = "";
            string AutoId3 = "";
            string AutoId4 = "";
            string AutoId5 = "";
            string TransactionID = "";
            AutoId1 = (string)applicationHandle.GetObjectProperty("Text=Account Information" + ";LabelRelationShip=" + LabelRelationShip.NthParent + ";2", ObjectProperty.AutomationId);
            AutoId2 = (string)applicationHandle.GetObjectProperty("AutomationId=" + AutoId1 + ";LabelRelationShip=" + LabelRelationShip.NextChild, ObjectProperty.AutomationId);
            AutoId3 = (string)applicationHandle.GetObjectProperty("AutomationId=" + AutoId2 + ";LabelRelationShip=" + LabelRelationShip.NextSibling, ObjectProperty.AutomationId);
            AutoId4 = (string)applicationHandle.GetObjectProperty("AutomationId=" + AutoId3 + ";LabelRelationShip=" + LabelRelationShip.NextChild, ObjectProperty.AutomationId);
            AutoId5 = (string)applicationHandle.GetObjectProperty("AutomationId=" + AutoId4 + ";LabelRelationShip=" + LabelRelationShip.NextChild, ObjectProperty.AutomationId);
            TransactionID = (string)applicationHandle.GetObjectProperty("AutomationId=" + AutoId5 + ";LabelRelationShip=" + LabelRelationShip.NthChildKthChild + ";" + TractionOccurence + ";1", ObjectProperty.AutomationId);
            Profile7CommonLibrary.VerifyWindowObjectExists("AutomationId=" + TransactionID);
            applicationHandle.ClickObeject("AutomationId=" + TransactionID);
            Profile7CommonLibrary.WaitUntilWindowLoads(tellerWindowName);
        }
        public virtual void ClickOnAnalyseTransactionsButton()
        {
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            applicationHandle.ClickObeject(buttonAnalyzeTransactions);

        }
        public virtual void VerifyTextInDialogWindow(string WindowName, string refTextToVerify)
        {
            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            refTextToVerify = refTextToVerify + "|";
            arr = refTextToVerify.Split('|');
            for (int b = 0; b < arr.Length - 1; b++)
            {
                temp = temp + " , " + string.Join(" , ", arr[b].Split('|')) + " is verified successfully in  " + WindowName + " window.";

            }
            msg = temp.Substring(3, temp.Length - 3);
            failmsg = msg.Replace(" is ", " is not ");

            bool Result = false;
            int counter = 0;
            arr = refTextToVerify.Split('|');
            applicationHandle.Launch_Application("jp2launcher;" + WindowName);
            for (int r = 0; r < arr.Length - 1; r++)
            {
                if (Profile7CommonLibrary.VerifyWindowObjectExists("ClassName=Static;Text=" + arr[r].Trim(), 1))
                {
                    counter++;
                }
                if (counter == arr.Length - 1)
                {
                    Result = true;
                    break;
                }
            }
            if (Result)
            {
                Report.Pass(msg, "windowtextvalidation", "True", applicationHandle);
            }
            else
            {
                Report.Fail(failmsg, "windowtextvalidationFail", "True", applicationHandle);
            }
        }


    }
}

