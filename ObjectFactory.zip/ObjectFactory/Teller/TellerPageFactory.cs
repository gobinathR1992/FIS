﻿using GTS_OSAF.Config;
using Profile7Automation.ObjectFactory.Teller.Windows;
using Spring.Aop.Framework;

namespace Profile7Automation.ObjectFactory.Teller
{
    public static class TellerPageFactory
    {
        public static MasterWindow MasterWindow { get => (MasterWindow)ClassRegister.Get(typeof(MasterWindow)); }
        public static DepositFundWindows DepositFundWindows { get => (DepositFundWindows)ClassRegister.Get(typeof(DepositFundWindows)); }
        public static LoginWindow LoginWindow { get => (LoginWindow)ClassRegister.Get(typeof(LoginWindow)); }
        public static WithdrawFundsWindow WithdrawFundsWindow { get => (WithdrawFundsWindow)ClassRegister.Get(typeof(WithdrawFundsWindow)); }
        public static LoanDisbursementWindow LoanDisbursementWindow { get => (LoanDisbursementWindow)ClassRegister.Get(typeof(LoanDisbursementWindow)); }
        public static LoanPaymentWindow LoanPaymentWindow { get => (LoanPaymentWindow)ClassRegister.Get(typeof(LoanPaymentWindow)); }
        public static ErrorCorrectWindow ErrorCorrectWindow { get => (ErrorCorrectWindow)ClassRegister.Get(typeof(ErrorCorrectWindow)); }
        public static AdvanceTransactionWindow AdvanceTransactionWindow { get => (AdvanceTransactionWindow)ClassRegister.Get(typeof(AdvanceTransactionWindow)); }
        public static PostTransaction PostTransaction { get => (PostTransaction)ClassRegister.Get(typeof(PostTransaction)); }
        public static TransactionCodeSearchwindow TransactionCodeSearchwindow { get => (TransactionCodeSearchwindow)ClassRegister.Get(typeof(TransactionCodeSearchwindow)); }
        public static TransactionDetailWindow TransactionDetailWindow { get => (TransactionDetailWindow)ClassRegister.Get(typeof(TransactionDetailWindow)); }
        public static LoanPayoffWindow LoanPayoffWindow { get => (LoanPayoffWindow)ClassRegister.Get(typeof(LoanPayoffWindow)); }
        public static ReverseTransactions ReverseTransactions { get => (ReverseTransactions)ClassRegister.Get(typeof(ReverseTransactions)); }
        public static TransactionAnalysisWindow TransactionAnalysisWindow { get => (TransactionAnalysisWindow)ClassRegister.Get(typeof(TransactionAnalysisWindow)); }

    
        

    }


}
