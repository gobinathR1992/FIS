using System.Diagnostics;
using GTS_OSAF.Config;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Spring.Aop.Framework;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [DebuggerStepThrough]
    public class WebAdminPageFactory
    {


        public static WebAdminLoginPage WebAdminLoginPage { get => (WebAdminLoginPage)ClassRegister.Get(typeof(WebAdminLoginPage)); }
        public static WebAdminMasterPage WebAdminMasterPage { get => (WebAdminMasterPage)ClassRegister.Get(typeof(WebAdminMasterPage)); }
        public static WebAdminPackagesPage WebAdminPackagesPage { get => (WebAdminPackagesPage)ClassRegister.Get(typeof(WebAdminPackagesPage)); }
        public static WebAdminPackageGroupsPage WebAdminPackageGroupsPage { get => (WebAdminPackageGroupsPage)ClassRegister.Get(typeof(WebAdminPackageGroupsPage)); }
        public static WebAdminPackageGeneralInformationPage WebAdminPackageGeneralInformationPage { get => (WebAdminPackageGeneralInformationPage)ClassRegister.Get(typeof(WebAdminPackageGeneralInformationPage)); }
        public static GeneralTableManagementPage GeneralTableManagementPage { get => (GeneralTableManagementPage)ClassRegister.Get(typeof(GeneralTableManagementPage)); }
        public static AddPackageGroupsPage AddPackageGroupsPage { get => (AddPackageGroupsPage)ClassRegister.Get(typeof(AddPackageGroupsPage)); }
        public static WebAdminProductFactoryPage WebAdminProductFactoryPage { get => (WebAdminProductFactoryPage)ClassRegister.Get(typeof(WebAdminProductFactoryPage)); }
        public static WebAdminProductCopyPage WebAdminProductCopyPage { get => (WebAdminProductCopyPage)ClassRegister.Get(typeof(WebAdminProductCopyPage)); }
        public static WebAdminProductOfferConfigurationPage WebAdminProductOfferConfigurationPage { get => (WebAdminProductOfferConfigurationPage)ClassRegister.Get(typeof(WebAdminProductOfferConfigurationPage)); }
        public static WebAdminAddProductOfferPage WebAdminAddProductOfferPage { get => (WebAdminAddProductOfferPage)ClassRegister.Get(typeof(WebAdminAddProductOfferPage)); }
        public static WebAdminProductsGeneralPage WebAdminProductsGeneralPage { get => (WebAdminProductsGeneralPage)ClassRegister.Get(typeof(WebAdminProductsGeneralPage)); }
        public static WebAdminProductsTransactionProcessingPage WebAdminProductsTransactionProcessingPage { get => (WebAdminProductsTransactionProcessingPage)ClassRegister.Get(typeof(WebAdminProductsTransactionProcessingPage)); }
        public static WebAdminProductsCommonPage WebAdminProductsCommonPage { get => (WebAdminProductsCommonPage)ClassRegister.Get(typeof(WebAdminProductsCommonPage)); }
        public static AdministrationCenterPage AdministrationCenterPage { get => (AdministrationCenterPage)ClassRegister.Get(typeof(AdministrationCenterPage)); }
        public static UserclassAddPage UserclassAddPage { get => (UserclassAddPage)ClassRegister.Get(typeof(UserclassAddPage)); }
        public static UserClassModifyPage UserClassModifyPage { get => (UserClassModifyPage)ClassRegister.Get(typeof(UserClassModifyPage)); }
        public static UserListPage UserListPage { get => (UserListPage)ClassRegister.Get(typeof(UserListPage)); }
        public static UserModifyPage UserModifyPage { get => (UserModifyPage)ClassRegister.Get(typeof(UserModifyPage)); }
        public static ServiceFeePlanListPage ServiceFeePlanListPage { get => (ServiceFeePlanListPage)ClassRegister.Get(typeof(ServiceFeePlanListPage)); }
        public static PlanParametersPage PlanParametersPage { get => (PlanParametersPage)ClassRegister.Get(typeof(PlanParametersPage)); }
        public static CopyServiceFeePlanPage CopyServiceFeePlanPage { get => (CopyServiceFeePlanPage)ClassRegister.Get(typeof(CopyServiceFeePlanPage)); }
        public static ServiceFeePlanEffectDateListPage ServiceFeePlanEffectDateListPage { get => (ServiceFeePlanEffectDateListPage)ClassRegister.Get(typeof(ServiceFeePlanEffectDateListPage)); }
        public static RateScheduleListPage RateScheduleListPage { get => (RateScheduleListPage)ClassRegister.Get(typeof(RateScheduleListPage)); }
        public static IndexListPage IndexListPage { get => (IndexListPage)ClassRegister.Get(typeof(IndexListPage)); }
        public static IndexEffectiveDatesListPage IndexEffectiveDatesListPage { get => (IndexEffectiveDatesListPage)ClassRegister.Get(typeof(IndexEffectiveDatesListPage)); }
        public static RelationshipCodePage RelationshipCodePage { get => (RelationshipCodePage)ClassRegister.Get(typeof(RelationshipCodePage)); }
        public static RelationshipCodesListPage RelationshipCodesListPage { get => (RelationshipCodesListPage)ClassRegister.Get(typeof(RelationshipCodesListPage)); }
        public static TransactionCodeConfigurationPage TransactionCodeConfigurationPage { get => (TransactionCodeConfigurationPage)ClassRegister.Get(typeof(TransactionCodeConfigurationPage)); }
        public static TransactionCodeCopyPage TransactionCodeCopyPage { get => (TransactionCodeCopyPage)ClassRegister.Get(typeof(TransactionCodeCopyPage)); }
        public static MiscellaneousFieldsPage MiscellaneousFieldsPage { get => (MiscellaneousFieldsPage)ClassRegister.Get(typeof(MiscellaneousFieldsPage)); }
        public static ProcessingControlOptionsPage ProcessingControlOptionsPage { get => (ProcessingControlOptionsPage)ClassRegister.Get(typeof(ProcessingControlOptionsPage)); }
        public static ProcessingOptionsPage ProcessingOptionsPage { get => (ProcessingOptionsPage)ClassRegister.Get(typeof(ProcessingOptionsPage)); }
        public static TransactionCodeAuthorizationPage TransactionCodeAuthorizationPage { get => (TransactionCodeAuthorizationPage)ClassRegister.Get(typeof(TransactionCodeAuthorizationPage)); }
        public static IndexAddPage IndexAddPage { get => (IndexAddPage)ClassRegister.Get(typeof(IndexAddPage)); }
        public static RateScheduleEffectiveDatesListPage RateScheduleEffectiveDatesListPage { get => (RateScheduleEffectiveDatesListPage)ClassRegister.Get(typeof(RateScheduleEffectiveDatesListPage)); }
        public static RateScheduleEffectiveDateRateModifyPage RateScheduleEffectiveDateRateModifyPage { get => (RateScheduleEffectiveDateRateModifyPage)ClassRegister.Get(typeof(RateScheduleEffectiveDateRateModifyPage)); }
        public static RateScheduleEffectiveDateRateAddPage RateScheduleEffectiveDateRateAddPage { get => (RateScheduleEffectiveDateRateAddPage)ClassRegister.Get(typeof(RateScheduleEffectiveDateRateAddPage)); }
        public static UserClassListPage UserClassListPage { get => (UserClassListPage)ClassRegister.Get(typeof(UserClassListPage)); }
        public static ReportDetailPage ReportDetailPage { get => (ReportDetailPage)ClassRegister.Get(typeof(ReportDetailPage)); }
        public static TermAccountsPenaltyPage TermAccountsPenaltyPage { get => (TermAccountsPenaltyPage)ClassRegister.Get(typeof(TermAccountsPenaltyPage)); }
        public static TermAccountsMaturityRenewalPage TermAccountsMaturityRenewalPage { get => (TermAccountsMaturityRenewalPage)ClassRegister.Get(typeof(TermAccountsMaturityRenewalPage)); }
        public static OverdraftAuthorizedPage OverdraftAuthorizedPage { get => (OverdraftAuthorizedPage)ClassRegister.Get(typeof(OverdraftAuthorizedPage)); }
        public static RateScheduleAddPage RateScheduleAddPage { get => (RateScheduleAddPage)ClassRegister.Get(typeof(RateScheduleAddPage)); }
        public static WebAdminDepositRateDeterminationPage WebAdminDepositRateDeterminationPage { get => (WebAdminDepositRateDeterminationPage)ClassRegister.Get(typeof(WebAdminDepositRateDeterminationPage)); }
        public static NewAccountspage NewAccountspage { get => (NewAccountspage)ClassRegister.Get(typeof(NewAccountspage)); }
        public static RevolvingCreditPaymentPage RevolvingCreditPaymentPage { get => (RevolvingCreditPaymentPage)ClassRegister.Get(typeof(RevolvingCreditPaymentPage)); }
        public static AccrualUserExitDefinitionsListPage AccrualUserExitDefinitionsListPage { get => (AccrualUserExitDefinitionsListPage)ClassRegister.Get(typeof(AccrualUserExitDefinitionsListPage)); }
        public static AddAccrualUserExitDefinitionPage AddAccrualUserExitDefinitionPage { get => (AddAccrualUserExitDefinitionPage)ClassRegister.Get(typeof(AddAccrualUserExitDefinitionPage)); }
        public static ExemptionPlanListPage ExemptionPlanListPage { get => (ExemptionPlanListPage)ClassRegister.Get(typeof(ExemptionPlanListPage)); }
        public static AddExemptionPlanParametersPage AddExemptionPlanParametersPage { get => (AddExemptionPlanParametersPage)ClassRegister.Get(typeof(AddExemptionPlanParametersPage)); }
        public static AddCategoryItemsCategory1itemsPage AddCategoryItemsCategory1itemsPage { get => (AddCategoryItemsCategory1itemsPage)ClassRegister.Get(typeof(AddCategoryItemsCategory1itemsPage)); }
        public static EditFeeScheduleParametersPage EditFeeScheduleParametersPage { get => (EditFeeScheduleParametersPage)ClassRegister.Get(typeof(EditFeeScheduleParametersPage)); }
        public static PlanFeesPage PlanFeesPage { get => (PlanFeesPage)ClassRegister.Get(typeof(PlanFeesPage)); }
        public static LoanRenewalProcessingPage LoanRenewalProcessingPage { get => (LoanRenewalProcessingPage)ClassRegister.Get(typeof(LoanRenewalProcessingPage)); }
        public static DepositInterestCalculationPage DepositInterestCalculationPage { get => (DepositInterestCalculationPage)ClassRegister.Get(typeof(DepositInterestCalculationPage)); }
        public static DepositPostingOptionsPage DepositPostingOptionsPage { get => (DepositPostingOptionsPage)ClassRegister.Get(typeof(DepositPostingOptionsPage)); }
        public static LoanRateDeterminationPage LoanRateDeterminationPage { get => (LoanRateDeterminationPage)ClassRegister.Get(typeof(LoanRateDeterminationPage)); }
        public static PaymentApplicationPage PaymentApplicationPage { get => (PaymentApplicationPage)ClassRegister.Get(typeof(PaymentApplicationPage)); }
        public static EscrowAnalysisPage EscrowAnalysisPage { get => (EscrowAnalysisPage)ClassRegister.Get(typeof(EscrowAnalysisPage)); }
        public static LoanTransactionProcessingPage LoanTransactionProcessingPage { get => (LoanTransactionProcessingPage)ClassRegister.Get(typeof(LoanTransactionProcessingPage)); }
        public static UserAddPage UserAddPage { get => (UserAddPage)ClassRegister.Get(typeof(UserAddPage)); }
        public static TableConfigurationCurrencyCodesPage TableConfigurationCurrencyCodesPage { get => (TableConfigurationCurrencyCodesPage)ClassRegister.Get(typeof(TableConfigurationCurrencyCodesPage)); }
        public static WebAdminProductStatementsPage WebAdminProductStatementsPage { get => (WebAdminProductStatementsPage)ClassRegister.Get(typeof(WebAdminProductStatementsPage)); }
        public static ProfileReportsPage ProfileReportsPage { get => (ProfileReportsPage)ClassRegister.Get(typeof(ProfileReportsPage)); }
        public static DepositRateDeterminationPage DepositRateDeterminationPage { get => (DepositRateDeterminationPage)ClassRegister.Get(typeof(DepositRateDeterminationPage)); }
        public static USRegulatoryRegulatoryPage USRegulatoryRegulatoryPage { get => (USRegulatoryRegulatoryPage)ClassRegister.Get(typeof(USRegulatoryRegulatoryPage)); }
        public static LoanMaturityProcessingPage LoanMaturityProcessingPage { get => (LoanMaturityProcessingPage)ClassRegister.Get(typeof(LoanMaturityProcessingPage)); }
        public static LoanUSRegulatoryPage LoanUSRegulatoryPage { get => (LoanUSRegulatoryPage)ClassRegister.Get(typeof(LoanUSRegulatoryPage));}
        public static DepositTransactionCodePage DepositTransactionCodePage { get => (DepositTransactionCodePage)ClassRegister.Get(typeof(DepositTransactionCodePage));}
        public static ReportCriteriaPage ReportCriteriaPage { get => (ReportCriteriaPage)ClassRegister.Get(typeof(ReportCriteriaPage));}
        public static AddServiceFeePlanPage AddServiceFeePlanPage { get => (AddServiceFeePlanPage)ClassRegister.Get(typeof(AddServiceFeePlanPage));}
        public static TableConfigurationInterestMatrixesPage TableConfigurationInterestMatrixesPage { get => (TableConfigurationInterestMatrixesPage)ClassRegister.Get(typeof(TableConfigurationInterestMatrixesPage)); }
		public static TableConfigurationInstitutionVariablesPage TableConfigurationInstitutionVariablesPage { get => (TableConfigurationInstitutionVariablesPage)ClassRegister.Get(typeof(TableConfigurationInstitutionVariablesPage)); }
		public static InvestmentSweepPage InvestmentSweepPage { get => (InvestmentSweepPage)ClassRegister.Get(typeof(InvestmentSweepPage)); }
        public static TransactionProcessingPaymentSystemPage TransactionProcessingPaymentSystemPage { get => (TransactionProcessingPaymentSystemPage)ClassRegister.Get(typeof(TransactionProcessingPaymentSystemPage)); } 
	    public static ContextFieldListPage ContextFieldListPage { get => (ContextFieldListPage)ClassRegister.Get(typeof(ContextFieldListPage)); }
		public static EditUserClassPage EditUserClassPage { get => (EditUserClassPage)ClassRegister.Get(typeof(EditUserClassPage)); }
		public static TableConfigurationRatesSchedulePage TableConfigurationRatesSchedulePage { get => (TableConfigurationRatesSchedulePage)ClassRegister.Get(typeof(TableConfigurationRatesSchedulePage)); }
		public static ContextAndFieldPage ContextAndFieldPage { get => (ContextAndFieldPage)ClassRegister.Get(typeof(ContextAndFieldPage)); }
        public static ProcedurePage ProcedurePage { get => (ProcedurePage)ClassRegister.Get(typeof(ProcedurePage)); }
        public static TransactionCodesPage TransactionCodesPage { get => (TransactionCodesPage)ClassRegister.Get(typeof(TransactionCodesPage)); }
        public static CopyUserClassPermissionPage CopyUserClassPermissionPage { get => (CopyUserClassPermissionPage)ClassRegister.Get(typeof(CopyUserClassPermissionPage)); }
        public static CopyUserClassPage CopyUserClassPage { get => (CopyUserClassPage)ClassRegister.Get(typeof(CopyUserClassPage)); }
        public static MaximumUserClassLimitsPage MaximumUserClassLimitsPage { get => (MaximumUserClassLimitsPage)ClassRegister.Get(typeof(MaximumUserClassLimitsPage)); }
        public static AddUserClassPage AddUserClassPage { get => (AddUserClassPage)ClassRegister.Get(typeof(AddUserClassPage)); }
        public static WebAdminGeneralLedgerPage WebAdminGeneralLedgerPage { get => (WebAdminGeneralLedgerPage)ClassRegister.Get(typeof(WebAdminGeneralLedgerPage));}               
		public static InstitutionVariablePage InstitutionVariablePage { get => (InstitutionVariablePage)ClassRegister.Get(typeof(InstitutionVariablePage)); }        
        public static GeneralLedgerAccountPage GeneralLedgerAccountPage { get => (GeneralLedgerAccountPage)ClassRegister.Get(typeof(GeneralLedgerAccountPage)); }       

        public static AddProductServicesPage AddProductServicesPage { get => (AddProductServicesPage)ClassRegister.Get(typeof(AddProductServicesPage)); }

        public static GeneralPage GeneralPage { get => (GeneralPage)ClassRegister.Get(typeof(GeneralPage)); }

        public static CalculationPage CalculationPage { get => (CalculationPage)ClassRegister.Get(typeof(CalculationPage)); }
        
        public static DelinquencyOptionssPage DelinquencyOptionssPage { get => (DelinquencyOptionssPage)ClassRegister.Get(typeof(DelinquencyOptionssPage)); }
        public static DelinquencyCountersDaysPage DelinquencyCountersDaysPage { get => (DelinquencyCountersDaysPage)ClassRegister.Get(typeof(DelinquencyCountersDaysPage)); }
        public static DelinquencyNoticeOffsetDaysPage DelinquencyNoticeOffsetDaysPage { get => (DelinquencyNoticeOffsetDaysPage)ClassRegister.Get(typeof(DelinquencyNoticeOffsetDaysPage)); }
        public static TransactionCodePaymentsPage TransactionCodePaymentsPage { get => (TransactionCodePaymentsPage)ClassRegister.Get(typeof(TransactionCodePaymentsPage)); }
        public static DelinquencyNoticeSelectionPage DelinquencyNoticeSelectionPage { get => (DelinquencyNoticeSelectionPage)ClassRegister.Get(typeof(DelinquencyNoticeSelectionPage)); }
        public static LoanFeePlanTransactionCodesPage LoanFeePlanTransactionCodesPage { get => (LoanFeePlanTransactionCodesPage)ClassRegister.Get(typeof(LoanFeePlanTransactionCodesPage));}
        public static LoanFeePlanIdentificationPage LoanFeePlanIdentificationPage { get => (LoanFeePlanIdentificationPage)ClassRegister.Get(typeof(LoanFeePlanIdentificationPage));}
        public static ProductServiceFeesPage ProductServiceFeesPage { get => (ProductServiceFeesPage)ClassRegister.Get(typeof(ProductServiceFeesPage));}
        public static FeeScheduleParametersPage FeeScheduleParametersPage { get => (FeeScheduleParametersPage)ClassRegister.Get(typeof(FeeScheduleParametersPage));}
        public static USRegulatoryRegulatory2Page USRegulatoryRegulatory2Page { get => (USRegulatoryRegulatory2Page)ClassRegister.Get(typeof(USRegulatoryRegulatory2Page));}
        public static LoanPaymentCalculationPage LoanPaymentCalculationPage { get => (LoanPaymentCalculationPage)ClassRegister.Get(typeof(LoanPaymentCalculationPage)); } 

        public static LoanInterestCalculationPage LoanInterestCalculationPage { get => (LoanInterestCalculationPage)ClassRegister.Get(typeof(LoanInterestCalculationPage));}
        public static InstitutionVariableDepositPage InstitutionVariableDepositPage { get => (InstitutionVariableDepositPage)ClassRegister.Get(typeof(InstitutionVariableDepositPage));}
        public static PaymentCalculationAdjustablePaymentPage PaymentCalculationAdjustablePaymentPage { get => (PaymentCalculationAdjustablePaymentPage)ClassRegister.Get(typeof(PaymentCalculationAdjustablePaymentPage));}
        public static PaymentCalculationOptionsPage PaymentCalculationOptionsPage { get => (PaymentCalculationOptionsPage)ClassRegister.Get(typeof(PaymentCalculationOptionsPage));}
        public static GeneralLedgerSetCodeListPage GeneralLedgerSetCodeListPage { get => (GeneralLedgerSetCodeListPage)ClassRegister.Get(typeof(GeneralLedgerSetCodeListPage));}
        
        public static DepositProductServiceFeesPage DepositProductServiceFeesPage { get => (DepositProductServiceFeesPage)ClassRegister.Get(typeof(DepositProductServiceFeesPage));}

         public static FDIC370Page FDIC370Page { get => (FDIC370Page)ClassRegister.Get(typeof(FDIC370Page)); }
         public static FundsAvailabilityPage FundsAvailabilityPage { get => (FundsAvailabilityPage)ClassRegister.Get(typeof(FundsAvailabilityPage)); }
        public static ApplyHoldandRestrictAccess ApplyHoldandRestrictAccess {get => (ApplyHoldandRestrictAccess)ClassRegister.Get(typeof(ApplyHoldandRestrictAccess));}
        public static DepositInsuranceCalculation DepositInsuranceCalculation {get => (DepositInsuranceCalculation)ClassRegister.Get(typeof(DepositInsuranceCalculation));}
        public static FunctionProcessingStatusPage FunctionProcessingStatusPage {get => (FunctionProcessingStatusPage)ClassRegister.Get(typeof(FunctionProcessingStatusPage));}
        public static TableConfigurationRelationshipCodesPage TableConfigurationRelationshipCodesPage { get => (TableConfigurationRelationshipCodesPage)ClassRegister.Get(typeof(TableConfigurationRelationshipCodesPage)); }
        public static AddServiceFeeTransactionCodeGroupPage AddServiceFeeTransactionCodeGroupPage { get => (AddServiceFeeTransactionCodeGroupPage)ClassRegister.Get(typeof(AddServiceFeeTransactionCodeGroupPage));} 

        public static LoanInterestCapitalizedInterestProcessingPage LoanInterestCapitalizedInterestProcessingPage { get => (LoanInterestCapitalizedInterestProcessingPage)ClassRegister.Get(typeof(LoanInterestCapitalizedInterestProcessingPage));}                               
    }
}