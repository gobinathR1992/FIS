using System;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminProductCopyPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //10/10/2018
        private static string NewType = "Xpath;//input[@name='toProductType']";
        //  private static string Nickname = "name;toProductNickname";
        private static string Description = "name;toProductDescription";
        //private static string GeneralLedgerSetCode= "name;toProductDescription";
        private static string SubmitButton = "XPATH;//INPUT[@value='Submit']";
        private static string productExistMsg = "XPATH;.//*[@class='error'][contains(.,'already exists')]";
        private static string productCreationSuccessMsg = "XPATH;.//*[@class='msg-box'][contains(.,'The product has been copied')]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        
        public virtual string CopyProductDetails(string CopyTo)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string ProductNo = "6800";         //RandomNumberGenerator.Generate();
            appHandle.Set_field_value(NewType, ProductNo);
            appHandle.Set_field_value(Description, CopyTo);
            appHandle.ClickObject(SubmitButton);
            appHandle.SyncPage();
            Thread.Sleep(2000);
            while (appHandle.IsObjectExists(productExistMsg))
            {
                ProductNo = RandomNumberGenerator.Generate();
                ProductNo = ProductNo.Substring(0, ProductNo.Length - 1);
                appHandle.Set_field_value(NewType, ProductNo);
                appHandle.Set_field_value(Description, CopyTo);
                appHandle.ClickObject(SubmitButton);
                appHandle.SyncPage();
                Thread.Sleep(2000);
            }
            if (appHandle.IsObjectExists(productCreationSuccessMsg))
            {
                Report.Info("CopyProductDetails was Successful");
                return ProductNo;
            }
            else
            {
                Report.Info("CopyProductDetails was not Successful");
                return null;
            }


        }
        //10/10/2018

        public virtual void EnterProductCopyDetails(string NewProdNumber)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(NewType))
            {
                appHandle.Set_field_value(NewType, NewProdNumber);
                appHandle.Set_field_value(Description, NewProdNumber);
            }

        }

        public virtual bool ClickOnSubmitButton()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton))
            {
                appHandle.ClickObjectViaJavaScript(SubmitButton);
            }

            return Result;
        }
        public virtual bool VerifyMessageProductCopyPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool IsProdExistsMsg()
        {
            bool Result = false;
            try
            {
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX, 1))
                {
                    if (appHandle.GetObjectText(MSGBOX).Contains("already exists"))
                    {
                        Result = true;
                    }
                }
            }
            catch (Exception e) { }
            return Result;
        }
    }
}