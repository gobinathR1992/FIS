
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class EscrowAnalysisPage
    {

        public static string txtAnalysisOptionsEscrowAnalysisDateOffsetDays = "Xpath;//input[@name='PRODDFTL_ANOFF']";
        public static string txtAnalysisOptionsEscrowAnalysisFrequency = "Xpath;//input[@name='PRODDFTL_ANFRE']";
        public static string chkAnalysisOptionsPerformAnalysis = "Xpath;//input[@name='PRODDFTL_AFLG']";
        
    }
}
