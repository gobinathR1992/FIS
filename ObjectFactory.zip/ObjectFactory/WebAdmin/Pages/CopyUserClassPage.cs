using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class CopyUserClassPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtNewUserClass="XPath;//input[@name='newUserClass']";
        public static string txtDescription="XPath;//input[@name='SCAU0_DESC']";
        public static string buttonSubmit="XPath;//input[@name='submit']";


        public virtual string EnterValuesForNewUserClass()
        {
            string errmsg="XPath;//*[contains(text(),'Record already exists in table SCAU0.')]";
            string uclassname=appHandle.CreateRamdomData(FieldType.NUMERIC,1000,9999).ToString();            
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.Set_field_value(txtNewUserClass,uclassname);
            appHandle.Set_field_value(txtDescription,uclassname);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage("Record already exists in table SCAU0."))
            {
                uclassname=appHandle.CreateRamdomData(FieldType.NUMERIC,1000,9999).ToString();            
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
                appHandle.Set_field_value(txtNewUserClass,uclassname);
                appHandle.Set_field_value(txtDescription,uclassname);
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            Report.Info("The User Class Details are entered successfully","uclasspass","True",appHandle);
            return uclassname;


        }





    }

}
