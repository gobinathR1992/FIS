using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class WebAdminProductStatementsPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonSubmit = "Xpath;//input[@value='Submit']";
        private static string checkboxSuppressBalancePrint = "XPath;//*[@name='PRODCTL_BALSUP']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p[1]";
        
        public static string txtGeneralInformationFrequency="XPath;//input[@name='PRODDFTD_SFRE']";
        public static string checkboxCombinedStatements="XPath;//input[@name='PRODDFTD_CMBSTAT']";
        public static string checkboxCurrentOrPriorStmtBillingPeriod="XPath;//input[@name='PRODCTL_CPSBOPT']";
        public static string dropdownSummaryCategory="XPath;//select[@name='PRODCTL_STMSUM']";
        
        public static string buttonSubmitnew="XPath;//input[@name='submit']";
        
        public static string checkboxEstatements="XPath;//input[@name='PRODDFTD_ESTAT']";
        
        public static string checkboxPrint="XPath;//input[@name='PRODDFTD_SMET']";
        
        
        
        public virtual bool ClickOnSuppressBalancePrintCheckbox(bool ONorOFF)
        {
            bool Result = false;
           if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxSuppressBalancePrint))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxSuppressBalancePrint)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxSuppressBalancePrint);
                        if (appHandle.CheckCheckBoxChecked(checkboxSuppressBalancePrint))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxSuppressBalancePrint) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxSuppressBalancePrint);
                        if (appHandle.CheckCheckBoxChecked(checkboxSuppressBalancePrint) == false){ Result = true; }
                    }
                }
            }
           
            return Result;
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyMessageInWebAdminProductStatementsPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (appHandle.GetObjectText(MSGOBJ).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void EnterStatementFrequency(string  Frequency)
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Frequency")+"|"+Frequency) ;
        }


        public virtual bool UpdateDataInStatementsTab(string summarycatval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownSummaryCategory);
            appHandle.Set_field_value(txtGeneralInformationFrequency,"1MAE");
            appHandle.SelectDropdownSpecifiedValue(dropdownSummaryCategory,summarycatval);
            if(!appHandle.CheckCheckBoxChecked(checkboxCombinedStatements))
            {
                appHandle.ClickObjectViaJavaScript(checkboxCombinedStatements);
            }
            if(!appHandle.CheckCheckBoxChecked(checkboxCurrentOrPriorStmtBillingPeriod))
            {
                appHandle.ClickObjectViaJavaScript(checkboxCurrentOrPriorStmtBillingPeriod);
            }

            appHandle.ClickObjectViaJavaScript(buttonSubmitnew);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }

        public virtual bool UpdateDataForStatementTab()       
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxCombinedStatements);
            if(!appHandle.CheckCheckBoxChecked(checkboxCombinedStatements))
            {
                appHandle.ClickObjectViaJavaScript(checkboxCombinedStatements);
            }
            if(!appHandle.CheckCheckBoxChecked(checkboxEstatements))
            {
                appHandle.ClickObjectViaJavaScript(checkboxEstatements);
            }

            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }

        public virtual bool EnterValueInGeneralInformationFrequencgField(string freqval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtGeneralInformationFrequency);
            appHandle.Set_field_value(txtGeneralInformationFrequency,freqval);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
 
        }

        public virtual bool EnterDataForFreqAndSelectChecboxForPrintComStatebillPer(string frqval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtGeneralInformationFrequency);
            appHandle.Set_field_value(txtGeneralInformationFrequency,frqval);
            if(!appHandle.CheckCheckBoxChecked(checkboxPrint))
                appHandle.ClickObjectViaJavaScript(checkboxPrint);
            if(!appHandle.CheckCheckBoxChecked(checkboxCombinedStatements))
                appHandle.ClickObjectViaJavaScript(checkboxCombinedStatements);
            if(!appHandle.CheckCheckBoxChecked(checkboxCurrentOrPriorStmtBillingPeriod))
                appHandle.ClickObjectViaJavaScript(checkboxCurrentOrPriorStmtBillingPeriod);
            
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        
        }

    }
}