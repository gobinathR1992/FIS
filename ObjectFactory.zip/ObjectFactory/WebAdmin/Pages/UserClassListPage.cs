using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class UserClassListPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtUserClassListMsg="Xpath;//h1[contains(text(),'Userclass List')]";
        public static string buttonCopy="XPath;//input[@name='copy']";
        public static string tableUserClassList="XPath;//table[contains(@class,'ledgerScrollable dataTable')]/tbody[@role='alert']";
        public static string buttonEdit="XPath;//input[@name='edit']";        
        public static string buttonAdd="XPath;//input[@name='add']";        
        public static string tabUserClassMaintainance="XPath;//table[@class='tab']/descendant::td[contains(text(),'Userclass Maintenance')]";
        public static string checkboxSecureUserClass="XPath;//input[@name='SCAU0_SECUCLS']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public static string tabUserClassPermisssion="XPath;//td[contains(text(),'Userclass Permissions')]";
        public static string checkboxSelfEntitlement="XPath;//input[@name='SCAU0_ENTITLEMENTFLAG']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";        
        
        public virtual bool ConfirmUserClassListPage()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("User Class List Page");
            bool bCheck = false;
            if (appHandle.CheckObjectExist(txtUserClassListMsg))
            {
                bCheck = true;
            }
            else
            {                
                bCheck = false;
            }                
            return bCheck;
        }

        public virtual bool CheckUserclassfound(string sUserClassName)
        {
               bool bCheck = false;
               string UclassVal1 = "XPath;//*[text()='" + sUserClassName + "']";
               string UclassVal2 = appHandle.GetObjectText(UclassVal1).Trim();

               if (UclassVal1.Trim() == UclassVal2.Trim())
               {
               bCheck = true;
               }
              return bCheck;
        }

        public virtual void SelectUserClassFromTable(string userclass)
        {
            string dynamicobj="XPath;//td[text()='"+userclass+"']/preceding-sibling::td/input";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit);
            appHandle.ClickObjectViaJavaScript(dynamicobj);
            appHandle.ClickObjectViaJavaScript(buttonEdit);
        }

        public virtual void SelectSelfEntitlementCheckbox()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxSelfEntitlement);
            appHandle.ClickObjectViaJavaScript(checkboxSelfEntitlement);
        }

        public virtual void ClickOnSubmitbutton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }

        public virtual bool CheckSuccessMessage(string msg)
        {
            string dynamicmsg="XPath;//*[contains(text(),'"+msg+"')]";
            if(appHandle.GetObjectText(dynamicmsg).Equals(msg))
            {
                return   true;         
                
            }
            else
            {
                return false;

            }
            
            

        }

        public virtual void CopyExistingUserClass(string userclass)
        {
            string dynamicobj="XPath;//td[text()='"+userclass+"']/preceding-sibling::td/input";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCopy);
            appHandle.ClickObjectViaJavaScript(dynamicobj);
            appHandle.ClickObjectViaJavaScript(buttonCopy);
            Report.Info("The Existing Userclass is copied successfully","uclasscopy","True",appHandle);
                     
            
        }

        public virtual bool CheckSuccessMessageForCopyClass()
        {
             Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCopy);
             return appHandle.CheckSuccessMessage(Data.Get("UserClassCopyMsg"));

        }

        public virtual void ClickOnTabUserClassPermission()
        {
            appHandle.ClickObjectViaJavaScript(tabUserClassPermisssion);
        }

        public virtual void CheckNegaivtiveScenarioForScriptCopyUserclassAndAllPermissions002another(string newuserclass,string copyclass)
        {
            string dynobj="XPath;//*[contains(text(),'"+newuserclass+"')]/preceding-sibling::td/input";
            string dynobj1="XPath;//*[contains(text(),'"+copyclass+"')]/preceding-sibling::td/input";
            
            
            appHandle.ClickObjectViaJavaScript(tabUserClassMaintainance);
            appHandle.ClickObjectViaJavaScript(dynobj);
            appHandle.ClickObjectViaJavaScript(buttonEdit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxSecureUserClass);
            appHandle.ClickObjectViaJavaScript(checkboxSecureUserClass);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage("The userclass has been modified."))
            {
                Report.Pass("The expected message exist in application","app123","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message does not exist in application","app1234","True",appHandle);

            }

            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(dynobj1);
            appHandle.ClickObjectViaJavaScript(buttonEdit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxSecureUserClass);
            appHandle.ClickObjectViaJavaScript(checkboxSecureUserClass);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage("The userclass has been modified."))
            {
                Report.Pass("The expected message exist in application","app123","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message does not exist in application","app1234","True",appHandle);

            }

            appHandle.ClickObjectViaJavaScript(tabUserClassPermisssion);


        }

        public virtual void ClickOnAddButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
        }
        public virtual void SelectUSerClassFromUserList(string UserID)
        {
            appHandle.ClickObjectViaJavaScript("XPath;//*[text()='" + UserID + "']/preceding-sibling::td/input");
        }
        public virtual void EnterDataInUserMaintenancePage(string sLabelNameLabelValuePipeDelimited)
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
            ClickOnSubmitbutton();
        }      
        public virtual bool VerifyMessageInWebAdminUserPage()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("MsgUserClassModified")))                
                {

                    Result = true;
                }
            }

            return Result;
        }



    }
}
