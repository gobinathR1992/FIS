using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class LoanFeePlanIdentificationPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtFeePlan = "name;feePlan";
        public static string txtDateFeeActive = "name;dateAvailable";
        public static string cbkEarlyPaymentPayoffFee = "name;contractReductionFeeType";
        private static string buttonAdd = "Xpath;//*[@value='Add']";
        private static string txtDescription = "Xpath;//input[@name ='text']";
        public static string buttonSubmit = "XPath;//input[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonEdit = "Xpath;//*[@value = 'Edit']";
        private static string buttonDelete = "Xpath;//*[@value = 'Delete']";
        private static string buttonContinue = "Xpath;//*[@value = 'Continue']";
        private static string txtHistComment = "Xpath;//input[@name='histDesc']";
        private static string drpfeeassesment = "Xpath;//select[@name='feeComputationAssessMeth']";
        private static string txtfrequency = "Xpath;//input[@name='feeComputationAssessFreq']";
        private static string drpfeeassesmentmtg = "Xpath;//select[@name='mtgLnFeeDRTranCode']";
        private static string drpincreaseadjustmtg = "Xpath;//select[@name='feeIncrAdjTranCodeMTG']";
        private static string drpdecreaseadjustmtg = "Xpath;//select[@name='mtgLnFeeCRTranCode']";
        private static string drpfeeassesmentConsumer = "Xpath;//select[@name='consumerLnFeeDRTranCode']";
        private static string drpincreaseadjustConsumer = "Xpath;//select[@name='feeIncrAdjTranCodeLN']";
        private static string drpdecreaseadjustConsumer = "Xpath;//select[@name='consumerLnFeeCRTranCode']";

        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);

            }
        }

        public virtual bool EnterOperationDetails(string OperationDetailsSemecolonDelimited)
        {
            bool result = false;
            int matchcount = 0;
            OperationDetailsSemecolonDelimited = OperationDetailsSemecolonDelimited + ";";
            string[] arr = OperationDetailsSemecolonDelimited.Split(';');
            for (int c = 0; c < arr.Length - 1; c++)
            {
                string runtimeXpathforOperation = "Xpath;//select[@name='operation[" + c + "]']";
                string runtimeXpathforPercent = "Xpath;//input[@name='percent[" + c + "]']";
                string runtimeXpathOfPaymentElementorAccountData = "Xpath;//input[@name='paymentOrAccountData[" + c + "]']";

                string operation = arr[c].Split('|')[0];
                string percent = arr[c].Split('|')[1];
                string details = arr[c].Split('|')[2];

                if (!string.IsNullOrEmpty(operation))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(runtimeXpathforOperation, operation);                    
                }
                if (!string.IsNullOrEmpty(percent))
                {
                    appHandle.Set_field_value(runtimeXpathforPercent, percent);
                }
                if (!string.IsNullOrEmpty(details))
                {
                    appHandle.Set_field_value(runtimeXpathOfPaymentElementorAccountData, details);
                }
                result = true;
                matchcount++;
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }
            return result;
        }


        public virtual string EnterRecordsForAddLoanFeePlan(string date, bool PayoffFeeONOFF = false, string HistoryCommentatAssessment = "", string FeeAssessmentMethod = "", string FeeAssesmetRuleSemecolondelimited = "", string FeeCalculationDetailsSemecolnDelimited = "", string TransactionCodegroup = "", string feeassesment = "", string increaseadjust = "", string decreaseadjust = "", string transactioncodesemicolondelimitd = "", string InComeDeferralOptionsSemecolnDelimited = "",string OperationDetailsSemecolonDelimited = "",string GLAccountLinkagesandOffsetTransactions="")
        {
            ClickOnAddButton();
            string LoanFeesplan = "LFG" + appHandle.CreateRamdomData(FieldType.NUMERIC, 100, 999, 3) + "";
            appHandle.Set_field_value(txtFeePlan, LoanFeesplan);
            appHandle.Set_field_value(txtDescription, LoanFeesplan);
            appHandle.Set_field_value(txtDateFeeActive, date);
            if (!PayoffFeeONOFF)
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Early Payment/Payoff Fee") + "|" + Data.Get("OFF"));
            }
            else
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Early Payment/Payoff Fee") + "|" + Data.Get("GLOBAL_ON"));
            }
            Report.Info("Loan Fee Plan Details Entered",true,appHandle);
            appHandle.ClickObjectViaJavaScript(buttonContinue);
            appHandle.Wait_For_Specified_Time(5);
            if (PayoffFeeONOFF == false)
            {
                appHandle.Set_field_value(txtHistComment, LoanFeesplan);
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpfeeassesment, FeeAssessmentMethod);
                if (FeeAssessmentMethod == "1 - Frequency")
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(FeeAssesmetRuleSemecolondelimited);
                }
                else if(FeeAssessmentMethod == "3 - Billing")
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(FeeAssesmetRuleSemecolondelimited);
                }
                Report.Info("Loan Fee Plan Rules Details Entered",true,appHandle);
                appHandle.ClickObjectViaJavaScript(buttonContinue);
                if(!string.IsNullOrEmpty(FeeCalculationDetailsSemecolnDelimited))
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(FeeCalculationDetailsSemecolnDelimited);
                }        
                if(!string.IsNullOrEmpty(OperationDetailsSemecolonDelimited))
                {
                    EnterOperationDetails(OperationDetailsSemecolonDelimited);
                }                        
                Report.Info("Loan Fee Plan Calculation Details Entered",true,appHandle);
                appHandle.ClickObjectViaJavaScript(buttonContinue);
                if (TransactionCodegroup == "Mortgage Loan Group")
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpfeeassesmentmtg, feeassesment);
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpincreaseadjustmtg, increaseadjust);
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpdecreaseadjustmtg, decreaseadjust);
                }
                else if (TransactionCodegroup == "Consumer Loan Group")
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpfeeassesmentConsumer, feeassesment);
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpincreaseadjustConsumer, increaseadjust);
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpdecreaseadjustConsumer, decreaseadjust);
                }
                if(!string.IsNullOrEmpty(GLAccountLinkagesandOffsetTransactions))
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(GLAccountLinkagesandOffsetTransactions);
                }
                if(!string.IsNullOrEmpty(transactioncodesemicolondelimitd))
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(transactioncodesemicolondelimitd);
                }               
                Report.Info("Loan Fee Plan Transaction Code Details Entered",true,appHandle);
                appHandle.ClickObjectViaJavaScript(buttonContinue);
                if(!string.IsNullOrEmpty(InComeDeferralOptionsSemecolnDelimited))
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(InComeDeferralOptionsSemecolnDelimited);
                }
            }
            Report.Info("Loan Fee Plan Deferred Income Details Entered",true,appHandle);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return LoanFeesplan;
        }
        public virtual bool VerifyMessageInLoanFeePlanIdentificationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

    }
}