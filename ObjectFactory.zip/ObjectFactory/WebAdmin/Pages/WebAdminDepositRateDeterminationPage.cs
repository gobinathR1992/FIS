
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminDepositRateDeterminationPage
    {

        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
       
       
        public static string txtFixedRateNominalRate = "Xpath;//*[contains(text(),'Nominal Rate')]/parent::td/following-sibling::td/descendant::input";
        public static string DropdownVariableRateIndex = "Xpath;//*[contains(text(),'Adjustable Rate')]/ancestor::tr[1]/following-sibling::tr[1]/descendant::td/descendant::select[1]";
        public static string txtVariableRateChangeFrequencyField = "Xpath;//input[@name='PRODDFTD_INTFRE']";
        public static string drpFixedRateRateSchedule = "Xpath;//select[@name='PRODDFTD_SCH']"; 
        public static string txtPromotionalRateRateField = "XPath;//input[@name='PRODDFTD_TRATE']";
        public static string txtPromotionalRateExpirationDate = "XPath;//input[@name='PRODDFTD_TREXD']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
         private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string txtAdjustableRateLimitsMaximumRate = "Xpath;//input[@name='PRODDFTD_INTMX']";
        private static string txtAdjustableRateLimitsMinimumRate = "Xpath;//input[@name='PRODDFTD_INTMN']";
        private static string txtAdjustableRatePositiveInterestSpread = "Xpath;//input[@name='PRODDFTD_INTSPRP']";
        private static string txtAdjustableRateInterestSpread = "Xpath;//input[@name='PRODDFTD_INTSPR']";
        private static string dropdownMatrix = "Xpath;//select[@name='PRODDFTD_INTMAT']";
        private static string txtUnAuthNegIntSpread = "Xpath;//input[@name='PRODDFTD_INTSPRU']";
        private static string txtAuthNegIntSpread = "Xpath;//input[@name='PRODDFTD_INTSPRA']";
        public virtual bool WaitUntilRateDeterminationPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtFixedRateNominalRate))
            {
                result = true;
            }

            return result;

        }
        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }

         public virtual bool VerifyMessageDepositRateDeterminationPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void SetEditValue(string sfieldname, string sfieldvalue)
        {
            try
            {
                appHandle.WaitUntilElementVisible(sfieldname);
                appHandle.WaitUntilElementClickable(sfieldname);
                appHandle.Set_field_value(sfieldname, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
        public virtual void EnterRateDeterminationOptions(string FixedRate= "" , string VariableRateIndex = "", string ChangeFrequency = "", string AdjustableRateLimitsMaximumRateField = "", string VariableRateLimitsMinimumRateField = "", string AdjustableRatePositiveInterestSpreadField = "", string AdjustableRateInterestSpreadField = "",string matrix = "",string UnAuthNegSpread="",string AuthNegSpread="")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownVariableRateIndex))
            {
                int indexlength = appHandle.GetLengthOfText(txtFixedRateNominalRate);
                for(int i=0;i<=indexlength-1;i++)
                {
                    appHandle.SendKeyStroke(txtFixedRateNominalRate, InputKey.Backspace);
                }
                appHandle.Set_field_value(txtFixedRateNominalRate,FixedRate);
                if(!string.IsNullOrEmpty(VariableRateIndex))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownVariableRateIndex, VariableRateIndex);
                }
                
                if(!string.IsNullOrEmpty(ChangeFrequency))
                {
                appHandle.Set_field_value(txtVariableRateChangeFrequencyField,ChangeFrequency);
                }
                if(!string.IsNullOrEmpty(AdjustableRateLimitsMaximumRateField))
                {
                    appHandle.Set_field_value(txtAdjustableRateLimitsMaximumRate, AdjustableRateLimitsMaximumRateField);
                    
                }         
                if(string.IsNullOrEmpty(AdjustableRateLimitsMaximumRateField))
                {
                    appHandle.ClearEditValue(txtAdjustableRateLimitsMaximumRate);            
                }         
                
                if(!string.IsNullOrEmpty(VariableRateLimitsMinimumRateField))
                {
                    appHandle.Set_field_value(txtAdjustableRateLimitsMinimumRate, VariableRateLimitsMinimumRateField);   
                }                 
                if(string.IsNullOrEmpty(VariableRateLimitsMinimumRateField))
                {
                    appHandle.ClearEditValue(txtAdjustableRateLimitsMinimumRate);            
                }
                if(!string.IsNullOrEmpty(AdjustableRatePositiveInterestSpreadField))
                {
                    appHandle.Set_field_value(txtAdjustableRatePositiveInterestSpread, AdjustableRatePositiveInterestSpreadField);   
                }  
                if(!string.IsNullOrEmpty(AdjustableRateInterestSpreadField))
                {
                    appHandle.Set_field_value(txtAdjustableRateInterestSpread, AdjustableRateInterestSpreadField);   
                } 
                if(!string.IsNullOrEmpty(matrix))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMatrix,matrix);
                }
                if(!string.IsNullOrEmpty(UnAuthNegSpread))
                {
                    appHandle.Set_field_value(txtUnAuthNegIntSpread,UnAuthNegSpread);
                }
                if(!string.IsNullOrEmpty(AuthNegSpread))
                {
                    appHandle.Set_field_value(txtAuthNegIntSpread,AuthNegSpread);
                }
            }        
        
        }        
    }
}
