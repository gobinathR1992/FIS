using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class AddServiceFeePlanPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string feeplandesc;

        public static string txtServiceFeePlan="XPath;//input[@name='FEEPLN_PLAN']";
        public static string txtEffectiveDate="XPath;//input[@name='FEEPLN_FEEDT']";
        public static string txtPlanDescription="XPath;//input[@name='FEEPLN_DESC']";
        public static string dropdownPlanType="XPath;//select[@name='FEEPLN_PLTP']";
        public static string dropdownBalUsedForFeeComputaion="XPath;//select[@name='FEEPLN_FEEBAL']";
        public static string txtBaseFeeAmount="XPath;//input[@name='FEEPLN_BASE']";

        public static string buttonsubmit="XPath;//input[@name='submit']";
        public static string buttonEdit="XPath;//input[@name='edit']";
        public static string ckbConvertAmountField="XPath;//*[@name='FEEPLN_CURFLG']";
        public static string dropdownBaseCurrency ="XPath;//*[@name='FEEPLN_PLANCUR']";
        public static string dropdownExchangeRate ="XPath;//*[@name='FEEPLN_PLANEXC']";
        public static string dropdownFeeBalanceRoundingMethod="XPath;//select[@name='FEEPLN_FEEBALRM']";
        private static string checkboxConvertAmountFields = "XPath;//*[contains(text(),'Convert Amount Fields:')]/ancestor::*[1]/following-sibling::*/input";
        private static string checkboxDailyFeeSubjecttoRegulationDD = "XPath;//*[contains(text(),'Daily Fee Subject to Regulation DD:')]/ancestor::*[1]/following-sibling::*/input";
        public static string textfeeplanmsg="XPath;//*[contains(text(),'The effective date')]";
        public static string drpBalanceRoundingOpt = "XPath;//select[@name='FEEPLN_FEEBALRM']";
        public static string dropdownPlanFeeCategory="XPath;//select[@name='FEESRV_FEECAT']";

        public virtual string EnterDetailsOfServiceFeePlan(string inputvalues, string ServicePlanDesc,string  EfffectiveDate,bool convtAmtfield,string basecurrency,string exchangerate,bool subjtoRegulationDD)
        {
            string[] inputdata = inputvalues.Split(';');
            string ServiceFeePlan = appHandle.CreateRamdomData(FieldType.NUMERIC, 1000, 9999).ToString();
            if (string.IsNullOrEmpty(ServicePlanDesc))
            {
                ServicePlanDesc = "FeePlanVal" + ServiceFeePlan;
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtServiceFeePlan);
            appHandle.Set_field_value(txtServiceFeePlan, ServiceFeePlan);
            appHandle.Set_field_value(txtPlanDescription, ServicePlanDesc);
            appHandle.Set_field_value(txtEffectiveDate, inputdata[0]);
            appHandle.SelectDropdownSpecifiedValue(dropdownPlanType, inputdata[1]);
            appHandle.SelectDropdownSpecifiedValue(dropdownBalUsedForFeeComputaion, inputdata[2]);
            appHandle.Set_field_value(txtBaseFeeAmount, inputdata[3]);
            //appHandle.SelectDropdownSpecifiedValueByPartialText(drpBalanceRoundingOpt,inputdata[4]);
            if (convtAmtfield)
            {
                if (appHandle.CheckCheckBoxChecked(checkboxConvertAmountFields)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxConvertAmountFields);
                }
            }
            else
            {
                if (appHandle.CheckCheckBoxChecked(checkboxConvertAmountFields))
                { 
                    appHandle.ClickObjectViaJavaScript(checkboxConvertAmountFields); 
                }
                else { }
            }
            if(convtAmtfield==true)
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBaseCurrency,basecurrency);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownExchangeRate,exchangerate);
            }
            if (subjtoRegulationDD)
            {
                if (appHandle.CheckCheckBoxChecked(checkboxDailyFeeSubjecttoRegulationDD)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxDailyFeeSubjecttoRegulationDD);
                }

            }
            else
            {
                if (appHandle.CheckCheckBoxChecked(checkboxDailyFeeSubjecttoRegulationDD)) 
                { 
                    appHandle.ClickObjectViaJavaScript(checkboxDailyFeeSubjecttoRegulationDD); 
                }
                else { }
            }
        Report.Pass("Service Fee parameter details added", "lookuppass", "True", appHandle);
        return ServiceFeePlan;
        
        }

        public virtual void ClickSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonsubmit);
            appHandle.ClickObjectViaJavaScript(buttonsubmit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit);

        }

        public virtual bool CheckSuccessMsgForFeePlan(string feemsg)
        {

            string actmsg = appHandle.GetObjectText(textfeeplanmsg);
            if (actmsg.Equals(feemsg))
            {
                return true;
            }

            return false;
        }
        public virtual void SelectBaseCurrency(string Currency)
        {
            appHandle.WaitUntilElementExists(ckbConvertAmountField);
            appHandle.SelectCheckBox(ckbConvertAmountField);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBaseCurrency,Currency);
        }

        public virtual string GetServicePlanValue()
        {
            return AddServiceFeePlanPage.feeplandesc;
        }

        public virtual bool VerifyServiceFeePlanCreated()
        {
            string feeplan = GetServicePlanValue();
            string dynamicobj = "XPath;//*[contains(text(),'" + feeplan + "')]";
            if (appHandle.IsObjectExists(dynamicobj))
            {
                return true;
            }
            return false;

        }


        public virtual string CreateServiceFeePlanNew(string effdate,string plantype,string balusedforcomp,string basefeeamont,string balroundmethod="")
        {
            string servicefeeplan="";
            string feesuccessmsg = Data.Get("GLOBAL_SERVICEFEE_CREATED_MSG");
            servicefeeplan = appHandle.CreateRamdomData(FieldType.NUMERIC, 1000, 9999).ToString();
            servicefeeplan="FeePlan"+servicefeeplan;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtServiceFeePlan);
            appHandle.Set_field_value(txtServiceFeePlan,servicefeeplan);
            appHandle.Set_field_value(txtEffectiveDate,effdate);
            appHandle.Set_field_value(txtPlanDescription,servicefeeplan);
            appHandle.SelectDropdownSpecifiedValue(dropdownPlanType,plantype);
            appHandle.SelectDropdownSpecifiedValue(dropdownBalUsedForFeeComputaion,balusedforcomp);
            if(!string.IsNullOrEmpty(balroundmethod))
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownFeeBalanceRoundingMethod,balroundmethod);
            }
            appHandle.Set_field_value(txtBaseFeeAmount,basefeeamont);
            appHandle.ClickObject(buttonsubmit);
            if(appHandle.CheckSuccessMessage(feesuccessmsg))
            {
                return  servicefeeplan; 
            }   

            return "false";

        }
        public virtual void SelectServiceFeePlanFeesCategory(string category)
        {
            appHandle.SelectDropdownSpecifiedValue(dropdownPlanFeeCategory,category);
        }

        public virtual void EnterDetailsOfServiceFeePlanFees(string LabelNameLabelValueSemiPipeDelimited)
        {

            if(!string.IsNullOrEmpty(LabelNameLabelValueSemiPipeDelimited))
            {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(LabelNameLabelValueSemiPipeDelimited);
            }
        }         









    }
}