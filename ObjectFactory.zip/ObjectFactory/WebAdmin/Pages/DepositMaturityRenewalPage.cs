using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
 

{
    [Page] 
    public class DepositMaturityRenewalPage
    { 
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string txtMaturityInformationTermField = "Xpath;//input[@name='PRODDFTD_TRM']";
        public static string dropdownPrincipalMaturityOption = "Xpath;//select[@name='PRODDFTD_RENCD']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        
        public virtual bool WaitUntilMaturityRenewalPageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownPrincipalMaturityOption))
            {
                result = true;
            }

            return result;

        }
        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage, 5);
        }
        public virtual bool VerifyMessageDepositMaturityRenewalPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void EnterDepositMaturityRenewalOptions(string mTerm = " " , string prinMaturityOption = " ")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownPrincipalMaturityOption))
            {
                if (!string.IsNullOrEmpty(mTerm))
                {
                    appHandle.Set_field_value(txtMaturityInformationTermField, mTerm);
                }
                if(!string.IsNullOrEmpty(prinMaturityOption))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownPrincipalMaturityOption, prinMaturityOption);
                }
                                
            }
        }
    }
}