using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Threading;
using System;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class ReportDetailPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string imgLastArrow="Xpath;//img[@src='images/arrow-last.gif']";


        public virtual void ClicktheLastRowImg()
        {
            appHandle.WaitUntilElementVisible(imgLastArrow);
            appHandle.ClickObject(imgLastArrow);
        }
        
        public virtual string GetthePageNumberinReportDetailpage()
         {
            string PageNumobj=null;
            try
            {
               PageNumobj = "XPath;//img[@src='images/arrow-next.gif']/preceding::a[1]";
                
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return PageNumobj;
        }
        
    }
}
