using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using System;
using System.Threading;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.BusinessFunctions.Applications;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class NewAccountspage
    {
     public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtCreditlimitdetailmaximumcreditlimit = "Xpath;//input[@name='PRODDFTL_MAXBAL']";
        private static string chkCommitmentProcessing = "Xpath;//input[@name='PRODDFTL_CPF']";
		private static string chkCommitmentBilling = "Xpath;//input[@name='PRODDFTL_CBF']";
		private static string chkCommitmentDelinquency = "Xpath;//input[@name='PRODDFTL_CDF']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
		public virtual void UpdateCommitmentOptions(string CmtProcessing="", string CmtBilling="", string CmtDelinquency="")
        {
            
		  try
		  {
		   if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chkCommitmentProcessing))
            {
                if(!string.IsNullOrEmpty(CmtProcessing))
                {
                appHandle.SelectCheckBox(chkCommitmentProcessing);
                }                          
            }
		
		   if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chkCommitmentBilling))
            {
                if(!string.IsNullOrEmpty(CmtBilling))
                {
                appHandle.SelectCheckBox(chkCommitmentBilling);
                }                          
            }
			
			  if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chkCommitmentDelinquency))
            {
                if(!string.IsNullOrEmpty(CmtDelinquency))
                {
                appHandle.SelectCheckBox(chkCommitmentDelinquency);
                }                          
            }
			
		  }
		  catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
			
        }
		
		 public virtual void SelectSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            
        }
	   
	    public virtual bool VerifyMessageNewAccountsPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

    }
}
