using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class AccrualUserExitDefinitionsListPage
    {
        public static WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string btnAdd="Xpath;//input[@name='add']";
        public static string txtAccrualListMSG="Xpath;//h1[contains(text(),'Accrual User Exit Definitions List')]";
        public static string btnEdit="Xpath;//input[@name='edit']";
        public static string tblAccrualUserList="Xpath;//table[@id='accrual_user_exit_definitions_list']";
        public static string btnDelete="Xpath;//input[@name='delete']";

        
        //Method for Click the Add Button.
        public virtual void ClickAddButton()
        {
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            AppHandle.SelectButton(btnAdd);
            Thread.Sleep(2000);
            Report.Info("Add button is clicked.");
        }

        //Method for Click the EDit Button.
        public virtual void ClickEditButton()
        {
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            AppHandle.SelectButton(btnEdit);
            Thread.Sleep(1000);
            Report.Info("Edit button is clicked.");
        }

        //Method for Click the EDit Button.
        public virtual void ClickDeleteButton()
        {
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            AppHandle.SelectButton(btnDelete);
            Thread.Sleep(1000);
            Report.Info("Delete button is clicked.");
        }


    }
}