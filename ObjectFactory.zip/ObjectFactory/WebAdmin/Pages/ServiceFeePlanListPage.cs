using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class ServiceFeePlanListPage
    {
       public  WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string btnAddServiceFeePlan = "name;add";
        public static string btnCopyServiceFeePlan = "XPath;//input[@value ='Copy'][contains(@onclick,'copyServiceFeePlanForm')]";
        public static string tblActionServiceFeePlanList = "XPath;//table[@class='contentTable']//div[contains(@id,'service-fee-plan-list')]";
        public static string btnEditServiceFeePlan = "XPath;//input[@name='edit'][contains(@onclick,'effectiveDateList')]";

        public static string tableFeePlan="XPath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";
        private static string tableProducts = "XPath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
       // public WebApplication appHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }


        public static string buttonEdit="XPath;//input[@name='edit'][@value='Edit']";
        public static string buttonCopy="XPath;//input[@name='edit'][@value='Copy']";

        public static string buttonAdd="XPath;//input[@name='add']";

        /// <summary>
        /// To Click on Add button in ServiceFeePlanListPage.
        /// <param></param> 
        /// <returns></returns>
        /// <example>ClickOnAddServiceFeePlanButton()</example>
        public void ClickOnAddServiceFeePlanButton()
        {
            try
            {
                appHandle.WaitUntilElementClickable(btnAddServiceFeePlan);
                appHandle.ClickObject(btnAddServiceFeePlan);
                appHandle.WaitUntilElementClickable(PlanParametersPage.txtSericeFeePlan);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To Click on Copy button in ServiceFeePlanListPage.
        /// <param></param> 
        /// <returns></returns>
        /// <example>ClickOnCopyServiceFeePlanButton()</example>
        public void ClickOnCopyServiceFeePlanButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnCopyServiceFeePlan);
                appHandle.WaitUntilElementClickable(btnCopyServiceFeePlan);
                appHandle.SelectButton(btnCopyServiceFeePlan);
                appHandle.WaitUntilElementClickable(CopyServiceFeePlanPage.txtCopyTo);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To verify Service Fee Plan Exists in ServiceFeePlanListPage.
        /// <param name= Service Plan Name></param> 
        /// <returns></returns>
        /// <example>CheckServiceFeePlanExistsinActionTable(SRefVal)</example>
        public virtual bool CheckServiceFeePlanExistsinActionTable(string SRefVal)
        {
            bool bcheck = false;
            try
            {
                appHandle.WaitUntilElementVisible(tblActionServiceFeePlanList);
                appHandle.WaitUntilElementClickable(tblActionServiceFeePlanList);
                //bcheck = appHandle.CheckSpecifiedDataAvailableInTable(SRefVal, tblActionServiceFeePlanList);
                bcheck = appHandle.CheckTextExistsInTable(tblActionServiceFeePlanList, SRefVal);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

        /// <summary>
        /// To select Service Fee Plan in ServiceFeePlanListPage.
        /// <param name= Service Plan Name></param> 
        /// <returns></returns>
        /// <example>SelectServiceFeePlaninActionTable(sfplnname)</example>
        public void SelectServiceFeePlaninActionTable(string sfplnname)
        {
            try
            {
                string obj = "XPath;//table[@class='contentTable']//div[contains(@id,'service-fee-plan-list')]//input[@type='radio'][@value='" + sfplnname + "']";
                appHandle.WaitUntilElementVisible(tblActionServiceFeePlanList);
                appHandle.WaitUntilElementClickable(tblActionServiceFeePlanList);
                appHandle.ClickObject(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To Click on Edit button in ServiceFeePlanListPage.
        /// <param></param> 
        /// <returns></returns>
        /// <example>ClickOnEditServiceFeePlanButton()</example>
        public void ClickOnEditServiceFeePlanButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnEditServiceFeePlan);
                appHandle.WaitUntilElementClickable(btnEditServiceFeePlan);
                appHandle.SelectButton(btnEditServiceFeePlan);
                appHandle.Wait_For_Specified_Time(4);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        public virtual void ClickEditButton()
        {
             Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit); 
             appHandle.ClickObjectViaJavaScript(buttonEdit);
        }

        public virtual void SelectFeePlanFromFeePlanTable(string feelplandescval)
        {
            // Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableFeePlan);
            // Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);  
            // appHandle.SelectRadioButtonInTable(tableFeePlan,feelplandescval);
            string runtimexpathforServicefeeplan = tableProducts+"/descendant::td[text()='"+feelplandescval+"']/ancestor::*[1]/td/input";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableProducts + "/descendant::td[1]/input"))
            {
                appHandle.ClickObjectViaJavaScript(runtimexpathforServicefeeplan);
            }
        }

        public virtual void ClickOnAddButton()
        {
            WebApplication appHandle1=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd); 
            appHandle1.ClickObjectViaJavaScript(buttonAdd);
        }
        public virtual bool VerifyMessageInPlanFeesPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }


        
    }

}