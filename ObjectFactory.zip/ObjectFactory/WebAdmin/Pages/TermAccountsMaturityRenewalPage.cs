using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class TermAccountsMaturityRenewalPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtterm="XPath;//input[@name='PRODDFTD_TRM']";
        public static string txtMaturityDate="Xpath;//input[@name='PRODDFTD_MDT']";
        public static string txtBusinessDateOption="Xpath;//select[@name='PRODDFTD_BUSOPT']";
        public static string drpBusinessDateCalender="Xpath;//select[@name='PRODDFTD_NBDC']";
        public static string drpPrincipalmatrutiOption="XPath;//select[@name='PRODDFTD_RENCD']";
        public static string drpPrincipalCheckType="Xpath;//select[@name='PRODCTL_CKMDT']";
        public static string drpInterestMaturityOption="XPath;//select[@name='PRODDFTD_IMO']";
        public static string drpInterestCheckType="Xpath;//select[@name='PRODCTL_CKINT']";
        public static string ckbAnticpatedEarningsCheck="Xpath;//input[@name='PRODCTL_AEC']";
        public static string txtPreMaturityGraceDays="Xpath;//input[@name='PRODDFTD_ADDNLDEPGRC']";
        public static string drpAdditionalDepositHoldOption="Xpath;//select[@name='PRODCTL_ADDNLDEPHLD']";
        public static string txtRenewalGraceDays="Xpath;//input[@name='PRODCTL_GRCDYS']";
        public static string drpRateOptionDurongGracePeriod="Xpath;//select[@name='PRODDFTD_RATEOPTGRC']";
        public static string drpGracePeriodInterestProcessingOption="Xpath;//select[@name='PRODDFTD_GOPT']";
        public static string ckbExtendMaturityWithDeposit="Xpath;//input[@name='PRODDFTD_MDTEXT']";
        public static string txtDepositGracePeriod="Xpath;//input[@name='PRODDFTD_DGRACE']";
        public static string txtCloseoutBalanceTransferAccount="Xpath;//input[@name='PRODCTL_CLTRACN']";
        public static string ckbNegotiable="Xpath;//input[@name='PRODDFTD_ISNEGOTIABLE']";
        public static string drpResetAvailableInterestDividendDropdown="Xpath;//select[@name='PRODDFTD_INTAVLR']";
        public static string drpDefaultGroup="Xpath;//select[@name='PRODDFTD_DFTMDT']";
        public static string drpRateDetermination="Xpath;//select[@name='PRODDFTD_RRO']";
        public static string drpEarningsDetermination="Xpath;//select[@name='PRODDFTD_ERO']";
        public static string drpProductParameterModification="Xpath;//select[@name='PRODDFTD_PMO']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public virtual bool UpdateValuesInMaturityInformationSection(string termval,string prinmatoptval,string intmatoptval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpPrincipalmatrutiOption);
            appHandle.Set_field_value(txtterm,termval);
            appHandle.SelectDropdownSpecifiedValue(drpPrincipalmatrutiOption,prinmatoptval);
            appHandle.SelectDropdownSpecifiedValue(drpInterestMaturityOption,intmatoptval);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
 
        }
    }
}