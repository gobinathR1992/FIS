using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class RelationshipCodesListPage
    {
        WebApplication appHandle;
        public static string tblRelationshipCodesList = "XPath;//div[contains(@id,'relationship-codes-list')][contains(@class,'dataTables')]";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To Click on Page No. in Relationship Codes List Page.
        /// <param name = "PageNo"></param> 
        /// <returns></returns>
        /// <example>ClickonPageNoinRelationshipCodesListPage("1")</example>
        public virtual void ClickonPageNoinRelationshipCodesListPage(string PageNo)
        {
            try
            {
                string obj = "XPath;//a[contains(text(),'" + PageNo + "')]";
                AppHandle.WaitUntilElementVisible(tblRelationshipCodesList);
                AppHandle.WaitUntilElementClickable(tblRelationshipCodesList);
                AppHandle.ClickObject(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To check Page No. Exists in Relationship Codes List Page.
        /// <param name = "PageNo"></param> 
        /// <returns>bool</returns>
        /// <example>bool val = CheckPageNoExistsinRelationshipCodesListPage("1")</example>
        public virtual bool CheckPageNoExistsinRelationshipCodesListPage(string PageNo)
        {
            bool bcheck = false;
            try
            {
                string obj = "XPath;//a[contains(text(),'" + PageNo + "')]";
                AppHandle.WaitUntilElementVisible(tblRelationshipCodesList);
                AppHandle.WaitUntilElementClickable(tblRelationshipCodesList);
                bcheck = AppHandle.IsObjectExists(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

        /// <summary>
        /// To check Relationship Code Exists in RelationshipCodesListTable.
        /// <param name = "Code"></param> 
        /// <returns>bool</returns>
        /// <example>bool val = CheckRelationshipCodeExistsinRelationshipCodesListTable("12")</example>
        public virtual bool CheckRelationshipCodeExistsinRelationshipCodesListTable(string Code)
        {
            bool bcheck = false;
            try
            {
                string obj = "XPath;//div[contains(@id,'relationship-codes-list')][contains(@class,'dataTables')]//input[@name='selectedRelationshipCode'][@value='" + Code + "']";
                AppHandle.WaitUntilElementVisible(tblRelationshipCodesList);
                AppHandle.WaitUntilElementClickable(tblRelationshipCodesList);
                bcheck = AppHandle.IsObjectExists(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

        /// <summary>
        /// To select Relationship Code in RelationshipCodesListTable.
        /// <param name = "Code"></param> 
        /// <returns></returns>
        /// <example>SelectRelationshipCodeinRelationshipCodesListTable("15")</example>
        public virtual void SelectRelationshipCodeinRelationshipCodesListTable(string Code)
        {
            try
            {
                string obj = "XPath;//div[contains(@id,'relationship-codes-list')][contains(@class,'dataTables')]//input[@name='selectedRelationshipCode'][@value='" + Code + "']";
                AppHandle.WaitUntilElementVisible(tblRelationshipCodesList);
                AppHandle.WaitUntilElementClickable(tblRelationshipCodesList);
                AppHandle.ClickObject(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

    }

}