using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Threading;
using System.Collections.Generic;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class ProcessingControlOptionsPage
    {
        WebApplication appHandle;
        public static string cbkProcessingControlOptionsAffectsEscrowRemittances = "Name;TRN_PCFL11";
        public static string cbkProcessingControlOptionsAllowBankLevelTransactions = "Name;TRN_PCFL40";
        public static string cbkProcessingControlOptionsCloseAccountAndProhibitFurtherProcessing = "Name;TRN_PCFL5";
        public static string cbkProcessingControlOptionsConsiderBalPoolPaymentApprovalPath = "Name;TRN_PCFD49";
        public static string cbkProcessingControlOptionsConsiderComputedMinBal = "Name;TRN_PCFD31";
        public static string cbkProcessingControlOptionsConsiderTransactionServiceFee = "Name;TRN_PCFD10";
        public static string cbkProcessingControlOptionsConsiderEarlyPaymentPenalty = "Name;TRN_PCFL23";
        public static string cbkProcessingControlOptionsConsiderWithdrawalforRegulationD = "Name;TRN_PCFD38";
        public static string cbkProcessingControlOptionsDisableRegCCProcessing = "Name;TRN_PCFD36";
        public static string cbkProcessingControlOptionsDoNotCalculatePenaltyOnNoticeAccounts = "Name;TRN_PCFD6";
        public static string cbkProcessingControlOptionsDoNotUpdatePriorTaxYearBuckets = "Name;TRN_PCFD35";
        public static string cbkProcessingControlOptionsIncludeBuydownFee = "Name;TRN_PCFL49";
        public static string cbkProcessingControlOptionsNonbookTransaction = "Name;TRN_PCFD45";
        public static string cbkProcessingControlOptionsPledgedDepositTransaction = "Name;TRN_PCFD30";
        public static string cbkProcessingControlOptionsPrintToPassbook = "Name;TRN_PCFD46";
        public static string cbkProcessingControlOptionsProcessInterestRateBuydown = "Name;TRN_PCFL48";
        public static string cbkProcessingControlOptionsPromptForBudgetCode = "Name;TRN_PCFL21";
        public static string cbkProcessingControlOptionsReduceResidualInterest = "Name;TRN_PCFD8";
        public static string cbkProcessingControlOptionsReduceUncollectedFees = "Name;TRN_PCFD43";
        public static string cbkProcessingControlOptionsRegCCCashTransaction = "Name;TRN_PCFD37";
        public static string cbkProcessingControlOptionsRestateServiceFee = "Name;TRN_PCFD13";
        public static string cbkProcessingControlOptionsRestrictLoanOverdraftTransfer = "Name;TRN_PCFD15";
        public static string cbkProcessingControlOptionsServiceFeesAtCloseout = "Name;TRN_PCFD9";
        public static string cbkProcessingControlOptionsUpdateCountersAmountsConsiderRestriction = "Name;TRN_PCFL4";
        public static string cbkProcessingControlOptionsUpdateInterestAdjustment = "Name;TRN_PCFL13";
        public static string cbkProcessingControlOptionsUpdateLastCustomerContactDate = "Name;TRN_PCFL2";
        public static string cbkProcessingControlOptionsUpdateTransactionCodeCounter = "Name;TRN_PCFD1";
        public static string cbkProcessingControlOptionsUseNegativeInterestFields = "Name;TRN_PCFD23";
        public static string cbkProcessingControlOptionsValueDateToNextAccrualCalculationDate = "Name;TRN_PCFD21";
        public static string cbkProcessingControlOptionsWithholdingAdjustmentsRetirementProducts = "Name;TRN_PCFD4";
        public static string txtProcessingControlOptionsTransactionDesc = "Name;TRN_DES";
        public static string drpProcessingControlOptionsConsiderMMDALimitations = "Name;TRN_PCFD3";
        public static string drpProcessingControlOptionsGroup = "Name;TRN_GRP";
        public static string drpProcessingControlOptionsPromptForCheckNumber = "Name;TRN_PCFD7";
        public static string drpProcessingControlOptionsSavingsIncentiveTransfer = "Name;TRN_PCFD44";
        public static string drpProcessingControlOptionsUpdateNonResidentAlienColumns = "Name;TRN_PCFD32";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To enter value in Edit Feild in ProcessingControlOptionsPage.
        /// <param name = "Feild Name"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetEditValue(sfieldname,sfieldvalue)</example>
        public virtual void SetEditValue(string sfieldname, string sfieldvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sfieldname);
                AppHandle.WaitUntilElementClickable(sfieldname);
                AppHandle.Set_field_value(sfieldname, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select dropdown value in ProcessingControlOptionsPage.
        /// <param name = "dropdown Name"></param> 
        /// <param name = "dropdown Value"></param> 
        /// <returns></returns>
        /// <example>SelectDropdownValue(sdrpname,sdrpvalue)</example>
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sdrpname);
                AppHandle.WaitUntilElementClickable(sdrpname);
                AppHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
        /// <summary>
        /// To select checkbox on in ProcessingControlOptionsPage.
        /// <param name = "checkbox"></param> 
        /// <returns></returns>
        /// <example>SelectCheckboxOn(schkname)</example>
        public virtual void SelectCheckboxOn(string schkname)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(schkname);
                AppHandle.WaitUntilElementClickable(schkname);
                AppHandle.Select_CheckBox(schkname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select checkbox off in ProcessingControlOptionsPage.
        /// <param name = "checkbox"></param> 
        /// <returns></returns>
        /// <example>SelectCheckboxOff(schkname)</example>
        public virtual void SelectCheckboxOff(string schkname)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(schkname);
                AppHandle.WaitUntilElementClickable(schkname);
                AppHandle.DeSelectCheckBox(schkname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To Enter Details in ProcessingControlOptionsPage
        /// <param name="lstPCOGFlddetails"></param>
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.txtProcessingControlOptionsTransactionDesc  + "|field|CD Increase W/H Prior Yr"); 
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.cbkProcessingControlOptionsProcessInterestRateBuydown  + "|checkbox|on");
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.cbkProcessingControlOptionsPromptForBudgetCode  + "|checkbox|off");
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.drpProcessingControlOptionsConsiderMMDALimitations  + "|dropdown|MMDA third party checks");
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.drpProcessingControlOptionsGroup  + "|dropdown|Certificates");
        /// <returns></returns>
        /// <example>EnterDetailsinProcessingControlOptionsPage(lstPCOGFlddetails)</example>
        public virtual void EnterDetailsinProcessingControlOptionsPage(List<string> lstPCOGFlddetails)
        {
            try
            {
                string[] arrserplnDetails = new string[3];
                for (int i = 0; i < lstPCOGFlddetails.Count; i++)
                {
                    arrserplnDetails = AppHandle.SplitString(lstPCOGFlddetails[i], "|"); //separator
                    switch (arrserplnDetails[1].ToUpper())
                    {
                        case "FIELD":
                            WebAdminPageFactory.ProcessingControlOptionsPage.SetEditValue(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "DROPDOWN":
                            WebAdminPageFactory.ProcessingControlOptionsPage.SelectDropdownValue(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "CHECKBOX":
                            if (arrserplnDetails[2].ToUpper() == "ON")
                                WebAdminPageFactory.ProcessingControlOptionsPage.SelectCheckboxOn(arrserplnDetails[0]);
                            else
                                WebAdminPageFactory.ProcessingControlOptionsPage.SelectCheckboxOff(arrserplnDetails[0]);
                            break;
                    }
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
    }
}
