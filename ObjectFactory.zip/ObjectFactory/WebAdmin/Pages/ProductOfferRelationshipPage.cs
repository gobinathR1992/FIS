using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class ProductOfferRelationshipPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        WebAdminProductOfferConfigurationPage objWebAdminProductOfferConfigurationPage = new WebAdminProductOfferConfigurationPage();
        //private static string RelationshipTable = "XPath;//div[@class='dataTables_scrollBody']//table";
        //private static string RelationshipTable = "Xpath;.//table[@class='ledgerScrollable dataTable']";
        private static string RelationshipTable = "Xpath;//div[contains(@id,'relationship-forms-list_wrapper')]";

        private static string SubmitButton="XPath;//input[@name='submit']";
        private static string RelationshipModifiedMsg="XPath;.//div[@class='info'][contains(.,'for the product type has been modified.')]";
         
         
        public virtual bool add_relationship_code_webcsr_channel(string sProductNumberClassDropdown, string sProductGroupDropdown, string sProductNumber)
        {
            
            try
            {
                // Navigate to Product Offer Relationship page.
                objWebAdminProductOfferConfigurationPage.NavigatetoProductOfferConfigurationPage();
                objWebAdminProductOfferConfigurationPage.SelectChannel(Data.Get("GLOBAL_PRODUCT_OFFER_CHANNEL_WEBCSR"));
                objWebAdminProductOfferConfigurationPage.select_product_from_product_list_table(sProductNumber);
                objWebAdminProductOfferConfigurationPage.ClickRelationshipButton();

                string [] arr_Deposit_Relationship_code = { "Relationship Code;" + Data.Get("GLOBAL_WEBADMIN_RELATIONSHIP_CODE_SINGLE_DEPOSIT"),
                                                    "Relationship Code;" + Data.Get("GLOBAL_WEBADMIN_RELATIONSHIP_CODE_JOINT_DEPOSIT")};

                // string [] arr_Loan_Relationship_code = {  "Relationship Code;" + Data.Get("GLOBAL_RELATIONSHIP_INDIVIDUAL_LOAN"),
                //                                     "Relationship Code;" + Data.Get("GLOBAL_RELATIONSHIP_JOINT_LOAN")};
                string [] arr_Loan_Relationship_code = {  "Description;" + Data.Get("GLOBAL_RELATIONSHIP_INDIVIDUAL_LOAN"),
                                                    "Description;" + Data.Get("GLOBAL_RELATIONSHIP_JOINT_LOAN")};

                // Check the Relationship checkbox for DEPOSIT Account Class.
                if (sProductNumberClassDropdown == Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"))
                {
                    if (sProductGroupDropdown.Equals(Data.Get("GLOBAL_DEBITBALANCEDEPOSIT_GROUP")))
                    {
                        appHandle.SelectCheckBoxInTable(RelationshipTable, "NO");
                    }
                    else
                    {
                        for (int i=0; i<arr_Deposit_Relationship_code.Length; i++)
                        {
                            if (arr_Deposit_Relationship_code[i] != null)
                            {
                                appHandle.SelectCheckBoxInTable(RelationshipTable, arr_Deposit_Relationship_code[i]);
                            }
                        }                        
                    }

                }

                // Check the Relationship checkbox for LOAN Account Class.
                if (sProductNumberClassDropdown == Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS"))
                {
                    for (int i=0; i<arr_Loan_Relationship_code.Length; i++)
                    {
                        if (arr_Loan_Relationship_code[i] != null)
                        {
                            appHandle.SelectCheckBoxInTable(RelationshipTable, arr_Loan_Relationship_code[i] );
                        }
                    }
                }

                appHandle.ClickObject(SubmitButton);
                appHandle.SyncPage();
                if (appHandle.IsObjectExists(RelationshipModifiedMsg))
                {
                    //Report.Pass("Successfully added the Relationship Code in WebCSR channel.", "Relationship Modified successfully", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                    return true;
                }
                else
                {
                    //Report.Fail("Failed to Add the Relationship Code in WebCSR channel.", "Relationship Modified Failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                    return false;
                }
            }
            catch (Exception e)
            {
                Report.Fail(e.Message, "AddRelationship Exception", appHandle);
                return false;
            }
        }

        public virtual bool add_relationship_code_webclient_channel(string sProductNumberClassDropdown, string sProductGroupDropdown, string sProductNumber)
        {
            try
            {
                // Navigate to Product Offer Relationship page.
                objWebAdminProductOfferConfigurationPage.NavigatetoProductOfferConfigurationPage();
                objWebAdminProductOfferConfigurationPage.SelectChannel(Data.Get("GLOBAL_PRODUCT_OFFER_CHANNEL_WEBCLIENT"));
                objWebAdminProductOfferConfigurationPage.select_product_from_product_list_table(sProductNumber);
                objWebAdminProductOfferConfigurationPage.ClickRelationshipButton();

                string [] arr_Deposit_Relationship_code = {  "Relationship Code;" + Data.Get("GLOBAL_WEBADMIN_RELATIONSHIP_CODE_SINGLE_DEPOSIT"),
                                                            "Relationship Code;" + Data.Get("GLOBAL_WEBADMIN_RELATIONSHIP_CODE_JOINT_DEPOSIT")};

                string [] arr_Loan_Relationship_code = {  "Description;" + Data.Get("GLOBAL_RELATIONSHIP_INDIVIDUAL_LOAN"),
                                                            "Description;" + Data.Get("GLOBAL_RELATIONSHIP_JOINT_LOAN")};

                // Check the Relationship checkbox for DEPOSIT Account Class.
                if (sProductNumberClassDropdown.Equals(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS")))
                {
                    if (sProductGroupDropdown.Equals(Data.Get("GLOBAL_DEBITBALANCEDEPOSIT_GROUP")))
                    {
                        appHandle.SelectCheckBoxInTable(RelationshipTable, "NO");
                    }
                    else
                    {
                        for (int i=0; i<arr_Deposit_Relationship_code.Length; i++)
                        {
                            if (arr_Deposit_Relationship_code[i] != null)
                            {
                                appHandle.SelectCheckBoxInTable(RelationshipTable, arr_Deposit_Relationship_code[i] );
                            }
                        }                        
                    }
                }

                // Check the Relationship checkbox for LOAN Account Class.
                if (sProductNumberClassDropdown.Equals(Data.Get("GLOBAL_LOAN_ACCOUNT_CLASS")))
                {
                    for (int i=0; i<arr_Loan_Relationship_code.Length; i++)
                    {
                        if (arr_Loan_Relationship_code[i] != null)
                        {
                            appHandle.SelectCheckBoxInTable(RelationshipTable, arr_Loan_Relationship_code[i] );
                        }
                    }
                }
                appHandle.ClickObject(SubmitButton);
                appHandle.SyncPage();
                if (appHandle.IsObjectExists(RelationshipModifiedMsg))
                {
                    //Report.Pass("Successfully added the Relationship Code in WebClient channel.", "Relationship Modified successfully", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                    return true;
                }
                else
                {
                    //Report.Fail("Failed to Add the Relationship Code in WebClient channel.", "Relationship Modified Failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                    return false;
                }
            }
            catch (Exception e)
            {
                Report.Fail(e.Message, "AddRelationship Exception", appHandle);
                return false;
            }
        }








        
        
    }
}