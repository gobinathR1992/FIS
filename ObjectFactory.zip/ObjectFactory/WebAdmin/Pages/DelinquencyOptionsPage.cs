using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class DelinquencyOptionssPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtDaysDelinquenttoRestrictAdvances="XPath;//input[@name='PRODDFTL_DDRA']";
        public static string txtMinimumBilledAmountforDelinquency="XPath;//input[@name='PRODDFTL_MBLDELQ']";
        public static string txtPaymentsDelinquentoRestrictAllTransactions="XPath;//input[@name='PRODDFTL_PMTDELQR']";
        public static string txtDaysDelinquenttoNonaccrual="XPath;//input[@name='PRODDFTL_ANPP']";
        public static string dropdownLateCahrgeMethod="XPath;//select[@name='PRODDFTL_POPT']";
        public static string txtLateChargeGraceDays="XPath;//input[@name='PRODDFTL_PMTGRC']";
        public static string txtFixedLateChargeAmount="XPath;//input[@name='PRODDFTL_FLCA']";

        public static string buttonSubmit="XPath;//input[@name='submit']";

        public static string dropdownLateChargeBusinessDayOption="XPath;//select[@name='PRODDFTL_LCBO']";

        public static string checkboxAutomaticNonaccrual="XPath;//input[@name='PRODCTL_ANA']";
        public static string dropdownNonaccrualGeneralLedgerSetCode="XPath;//select[@name='PRODCTL_NAGL']";

        public static string checkboxSubjecttoProvisionProcessing="XPath;//input[@name='PRODCTL_PROVPO']";
        public static string chekcboxSubjecttoReclasificationProcessing="XPath;//input[@name='PRODCTL_DARCPO']";

        public static string dropdownPrincipalVarianceOption="XPath;//input[@name='PRODDFTL_PVO']";
        
        public static string txtPaymentTolerancePercentage="XPath;//input[@name='PRODDFTL_PAYTOLP']";
        
        public static string checkboxSubjecttorovisionProcessing="XPath;//input[@name='PRODCTL_PROVPO']";
        public static string checkboxSubjecttoReclassificationProcessing="XPath;//input[@name='PRODCTL_DARCPO']";
        public static string checkboxSubjecttoReclassificationfCurrent="XPath;//input[@name='PRODCTL_DARCCU']";

        public virtual void ClickOnLink(string linkname)
        {
            string dynobjlink="XPath;//a[contains(text(),'"+linkname+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynobjlink);
            appHandle.ClickObjectViaJavaScript(dynobjlink);


        }


        public virtual bool EnterDetailsForOptions(string latechargemethod6)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDaysDelinquenttoNonaccrual);
            appHandle.Set_field_value(txtDaysDelinquenttoRestrictAdvances,"5");
            appHandle.Set_field_value(txtMinimumBilledAmountforDelinquency,"10");
            appHandle.Set_field_value(txtPaymentsDelinquentoRestrictAllTransactions,"1");
            appHandle.Set_field_value(txtDaysDelinquenttoNonaccrual,"31");
            appHandle.SelectDropdownSpecifiedValue(dropdownLateCahrgeMethod,latechargemethod6);
            appHandle.Set_field_value(txtLateChargeGraceDays,"1D");
            appHandle.Set_field_value(txtFixedLateChargeAmount,"5");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
            
        }


        public virtual bool EnterOptionsDetailsForTDSetup(string bussinessdayoption,string NonaccrualGeneralLedgerSetCode="",string PrincipalVarianceOptionval="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDaysDelinquenttoNonaccrual);
            appHandle.Set_field_value(txtDaysDelinquenttoRestrictAdvances,"30");
            appHandle.Set_field_value(txtMinimumBilledAmountforDelinquency,"10");
            appHandle.Set_field_value(txtLateChargeGraceDays,"0D");
            appHandle.Set_field_value(txtFixedLateChargeAmount,"50");
            appHandle.SelectDropdownSpecifiedValue(dropdownLateChargeBusinessDayOption,bussinessdayoption);
            appHandle.ClickObjectViaJavaScript(checkboxAutomaticNonaccrual);
            if(!string.IsNullOrEmpty(NonaccrualGeneralLedgerSetCode))
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownNonaccrualGeneralLedgerSetCode,NonaccrualGeneralLedgerSetCode);
            }
            else
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownNonaccrualGeneralLedgerSetCode,"600N - NONACCRUAL G/L SET CODE FOR TYPE 600");
            }
            appHandle.Set_field_value(txtDaysDelinquenttoNonaccrual,"90");
            if(!appHandle.CheckCheckBoxChecked(checkboxSubjecttoProvisionProcessing))
            {
                appHandle.ClickObjectViaJavaScript(checkboxSubjecttoProvisionProcessing);
            }
            if(!appHandle.CheckCheckBoxChecked(chekcboxSubjecttoReclasificationProcessing))
            {

                appHandle.ClickObjectViaJavaScript(chekcboxSubjecttoReclasificationProcessing);
            }
            if(!string.IsNullOrEmpty(PrincipalVarianceOptionval))
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownPrincipalVarianceOption,PrincipalVarianceOptionval);
            }

            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));         
   

        }


        public virtual bool EnterDetails()
        {
            WebAdminPageFactory.DelinquencyOptionssPage.ClickOnLink("Options");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDaysDelinquenttoRestrictAdvances);
            appHandle.Set_field_value(txtDaysDelinquenttoRestrictAdvances,"1");
            appHandle.SelectDropdownSpecifiedValue(dropdownPrincipalVarianceOption,"Variance May Offset Delinquency");
            appHandle.Set_field_value(txtFixedLateChargeAmount,"50");
            appHandle.Set_field_value(txtDaysDelinquenttoNonaccrual,"36");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }

        public virtual bool UpdateValueForPaymentTolerancePercentageField(string tolerancevalue)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPaymentTolerancePercentage);
            appHandle.Set_field_value(txtPaymentTolerancePercentage,tolerancevalue);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));          

        }

        public virtual bool EnterDetailsInProvisionOrClassification(bool provprocessing,bool reclassprocess,bool reclassprocessifcurrent)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxSubjecttoProvisionProcessing);
            if( (provprocessing==true) && appHandle.CheckCheckBoxUnchecked(checkboxSubjecttorovisionProcessing))
            {
                appHandle.ClickObjectViaJavaScript(checkboxSubjecttorovisionProcessing);
            }
            if(reclassprocess==true && appHandle.CheckCheckBoxUnchecked(checkboxSubjecttoReclassificationProcessing))
            {
                appHandle.ClickObjectViaJavaScript(checkboxSubjecttoReclassificationProcessing);
            }
            if(reclassprocessifcurrent==true && appHandle.CheckCheckBoxUnchecked(checkboxSubjecttoReclassificationfCurrent))
            {
                appHandle.ClickObjectViaJavaScript(checkboxSubjecttoReclassificationfCurrent);
            }

            appHandle.ClickObjectViaJavaScript(buttonSubmit);

            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }


    }
}