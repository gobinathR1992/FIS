using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class PaymentCalculationOptionsPage
    {
        WebApplication apphandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpCalculationOptionsInterestDeterminationPoint = "XPath;//select[@name='PRODDFTL_IDP']";
        public static string chkCalculationOptionsFullPeriodtoFirstPayment = "XPath;//input[@name='PRODCTL_FPF']";
        public static string txtcalculationoptionsbillingoffsetdays = "XPath;//input[@name='PRODDFTL_BLOFF']";
        public static string drpCalculationOptionsPaymentCalculationMethod = "XPath;//select[@name='PRODDFTL_PCM']";

        public static string txtAmortizationTerm="XPath;//input[@name='PRODDFTL_TRM']";
        public static string checkboxFullPeriodtoFirstPayment="XPath;//input[@name='PRODCTL_FPF']";
        public static string txtPaymentFrequency="XPath;//input[@name='PRODDFTL_DIST1FRE']";
        public static string dropdownPaymentCalculationMethod="XPath;//select[@name='PRODDFTL_PCM']";
        public static string checkboxConsiderInterestAccrualMethodforPaymentCalculation="XPath;//input[@name='PRODDFTL_PIACM']";
        public static string dropdownAmortizationCalculationMethod="XPath;//select[@name='PRODDFTL_AMORCALMT']";

        public static string dropdownPaymentRecalculationMethod="XPath;//select[@name='PRODDFTL_PMRECLMT']";
        public static string dropdownAdjustmentsAfterInterestRateChange="XPath;//select[@name='PRODDFTL_APIRAOPT']";

        public static string buttonSubmit="XPath;//input[@name='submit']";

        public virtual bool EnterDetailsInPaymentCalculation()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtAmortizationTerm);
            apphandle.Set_field_value(txtAmortizationTerm,"15D");
            if(apphandle.CheckCheckBoxChecked(checkboxFullPeriodtoFirstPayment))
            {
                apphandle.ClickObjectViaJavaScript(checkboxFullPeriodtoFirstPayment);
            }
            apphandle.Set_field_value(txtPaymentFrequency,"3DA");
            apphandle.SelectDropdownSpecifiedValue(dropdownPaymentCalculationMethod,"15N - Amortized, Accrued Interest No On-Line Bills");
            if(apphandle.CheckCheckBoxChecked(checkboxConsiderInterestAccrualMethodforPaymentCalculation))
            {
                apphandle.ClickObjectViaJavaScript(checkboxConsiderInterestAccrualMethodforPaymentCalculation);
            }
            apphandle.SelectDropdownSpecifiedValue(dropdownAmortizationCalculationMethod,"");
            apphandle.SelectDropdownSpecifiedValue(dropdownPaymentRecalculationMethod,"");
            apphandle.SelectDropdownSpecifiedValue(dropdownAdjustmentsAfterInterestRateChange,"");
            apphandle.ClickObjectViaJavaScript(buttonSubmit);
            return apphandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }

         public virtual void EnterDetailsForPaymentCalculation(string EnterDetailsInPaymentCalculationSemecolonDelimited)
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(EnterDetailsInPaymentCalculationSemecolonDelimited);
        }



    
    
    }

}