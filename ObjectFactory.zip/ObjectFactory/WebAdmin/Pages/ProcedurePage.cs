using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class ProcedurePage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string dropdownAuthorizationBasedOn="XPath;//select[@name='procedureAuthorizationForm.authorizationBasedOn']";
        public static string dropdownUserClass="XPath;//select[@name='procedureAuthorizationForm.userClass']";
        public static string dropdownType="XPath;//select[@name='procedureAuthorizationForm.procedureTypeForUserclass']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public static string dropdowntypemrpc="XPath;//select[@name='procedureAuthorizationForm.procedureTypeForProcedure']";
        
        public static string buttonAuthorize="XPath;//input[@value='Authorize']";
        public static string linkSelectDeselectAllAuth = "Xpath;//*[@id='selectDeselectAllAuth']";
        public static string linkSelectDeselectAllLog = "Xpath;//*[@id='selectDeselectAllLog']";
        public static string checkboxMRPCServiceClassDriverAccess = "Xpath;//*[@name='procedureAuthorizationForm.serviceClassAuthorization.selected']";


        public virtual void EnterDetailsForProcedure()
        {

            string mrpc003="XPath;//*[contains(text(),'^MRPC003')]/preceding-sibling::td/input[@name='procedureAuthorizationForm.procedureAuthorization[13].selected']";
            string radobj="XPath;//*[contains(text(),'~PbsServiceNMSP0')]/preceding-sibling::td/input";
            string radobj1="XPath;//*[contains(text(),'^MRPC003')]/preceding-sibling::td/input";


            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAuthorizationBasedOn);
            appHandle.SelectDropdownSpecifiedValue(dropdownAuthorizationBasedOn,"Userclass");
            appHandle.SelectDropdownSpecifiedValue(dropdownUserClass,"MANAGER");
            appHandle.SelectDropdownSpecifiedValue(dropdownType,"Service Classes");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage("Procedure Authorization completed."))
            {
                Report.Pass("The Expected message exist in application","existpass1","True",appHandle);

            }
            else
            {
                Report.Fail("The Expected message not exist in application","existfail1","True",appHandle);

            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAuthorizationBasedOn);

            appHandle.SelectDropdownSpecifiedValue(dropdownAuthorizationBasedOn,"Userclass");
            appHandle.SelectDropdownSpecifiedValue(dropdownUserClass,"MANAGER");
            appHandle.SelectDropdownSpecifiedValue(dropdownType,"MRPC");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(mrpc003);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage("Procedure Authorization completed."))
            {
                Report.Pass("The Expected message exist in application","existpass","True",appHandle);
            }
            else
            {
                Report.Fail("The Expected message not exist in application","existfail","True",appHandle);
   
            }

            if(appHandle.IsObjectEnabled(dropdownAuthorizationBasedOn))
            {
                Report.Pass("The object is enabled in application","enablepass","True",appHandle);
            }
            else
            {
                Report.Fail("The object is not enabled in application","enablefail","True",appHandle);

            }

            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem("Security Configuration|Set Permissions");
            WebAdminPageFactory.ContextAndFieldPage.SelectTabInContextFieldPage("Procedure");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAuthorizationBasedOn);
            appHandle.SelectDropdownSpecifiedValue(dropdownAuthorizationBasedOn,"Procedure");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdowntypemrpc);
            appHandle.SelectDropdownSpecifiedValue(dropdowntypemrpc,"Service Classes");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAuthorize);
            appHandle.ClickObjectViaJavaScript(radobj);
            appHandle.ClickObjectViaJavaScript(buttonAuthorize);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage("Procedure Authorization completed."))
            {
                Report.Pass("The expected message exist in application","msg013pass","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message not exist in application","msg013fail","True",appHandle);

            }
            appHandle.IsObjectEnabled(dropdownAuthorizationBasedOn);
            appHandle.SelectDropdownSpecifiedValue(dropdownAuthorizationBasedOn,"Procedure");
            appHandle.SelectDropdownSpecifiedValue(dropdowntypemrpc,"MRPC");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAuthorize);
            appHandle.ClickObjectViaJavaScript(radobj1);
            appHandle.ClickObjectViaJavaScript(buttonAuthorize);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage("Procedure Authorization completed."))
            {
                Report.Pass("The expected message exist in the application","pass34","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message not exist in the application","fail34","True",appHandle);

            }
            
            if(appHandle.IsObjectEnabled(dropdownAuthorizationBasedOn))
            {
                Report.Pass("The Object is enabled in the application","enbpass25","True",appHandle);
            }
            else
            {
                Report.Fail("The Object is not enabled in the application","enbpass26","True",appHandle);

            }


        }


        public virtual void SelectValueFromAuthorizationdropdown(string value)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAuthorizationBasedOn);
            appHandle.SelectDropdownSpecifiedValue(dropdownAuthorizationBasedOn,value);
            Report.Info("The value is selected from dropdown","rpv","True",appHandle);
        }

        public virtual bool CheckDropdownvalueexist(string value)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownUserClass);
            return appHandle.CheckValueInDropdown(dropdownUserClass,value);
    
        }
        public virtual void SetPermissionforUserclass(string Userclass)
        {
            appHandle.WaitUntilElementExists(dropdownAuthorizationBasedOn);
            appHandle.SelectDropdownSpecifiedValue(dropdownAuthorizationBasedOn,"Userclass");
            appHandle.SelectDropdownSpecifiedValue(dropdownUserClass,Userclass);
            appHandle.SelectDropdownSpecifiedValue(dropdownType,"MRPC");
            appHandle.SelectCheckBox(checkboxMRPCServiceClassDriverAccess);
            appHandle.ClickObjectViaJavaScript(linkSelectDeselectAllAuth);
            appHandle.ClickObjectViaJavaScript(linkSelectDeselectAllLog);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage("Procedure Authorization completed."))
            {
                Report.Pass("The UserClass Permission is Set in Procedure Authorization Page.","Procedurepage","True",appHandle);
            }
            else
            {
                Report.Fail("The UserClass Permission is not Set in Procedure Authorization Page.","Procedurepagefails","True",appHandle,true);

            }
            
                      

        }






    }
}