using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class TermAccountsPenaltyPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string ckbPayInterestonPartialWithdrawal="Xpath;//input[@name='PRODDFTD_PIPW']";
        public static string drpPenaltyMethod="Xpath;//select[@name='PRODDFTD_POPT']";
        public static string txtPenaltyRate="xpath;//input[@name='PRODDFTD_PRATE']";
        public static string drpPenaltyIndex="Xpath;//select[@name='PRODDFTD_PINDEX']";
        public static string txtAssessmentDays="Xpath;//input[@name='PRODDFTD_PDYS']";
        public static string drpPenaltyRateSchedule="Xpath;//select[@name='PRODDFTD_PRS']";
        public static string drpPenaltyReductionMethod="Xpath;//select[@name='PRODDFTD_PRM']";
        public static string txtPenaltyThreshold="Xpath;//input[@name='PRODDFTD_PTHRESH']";
        public static string txtExpirationTerm="Xpath;//input[@name='PRODDFTD_PXTRM']";
        public static string txtPercentageofInterestDividend="Xpath;//input[@name='PRODDFTD_PINT']";
        

    }
}