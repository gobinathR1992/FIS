
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class RevolvingCreditPaymentPage
    {

        public static string txtRevolvingCreditPaymentMinimumFinanceCharge = "Xpath;//input[@name='PRODDFTL_MFCB']";
        
    }
}
