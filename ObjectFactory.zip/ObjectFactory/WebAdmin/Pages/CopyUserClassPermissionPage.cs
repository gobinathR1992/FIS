using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class CopyUserClassPermissionPage
    {
        WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        

        public static string dropdwonFrom="XPath;//select[@name='userClassFrom']";
        public static string dropdwonTo="XPath;//select[@name='userClassTo']";
        public static string buttonsubmit="XPath;//input[@name='submit']";
        public static string linkDeselectAll="XPath;//a[@id='deselectall']";
        public static string linkselectAll="XPath;//a[@id='selectall']";

        public static string checkboxUTBLDENLIMUC="XPath;//input[@value='UTBLDENLIMUC - Userclass Denomination Limits']";
        public static string checkboxUTBLMASKAUT="XPath;//input[@value='UTBLMASKAUT - Mask Authorization']";
        public static string checkboxUTBLCNTXTAUT="XPath;//input[@value='UTBLCNTXTAUT - Context Authorization']";

        public static string buttonCancel="XPath;//input[@name='cancel']";
        public virtual bool EnterDetailsForUserClassPermisssion(string fromclass,string toclass,string datatobeselectedseperatedbydelimsemicoln)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdwonFrom);
            
            appHandle.SelectDropdownSpecifiedValue(dropdwonFrom,fromclass);
            appHandle.SelectDropdownSpecifiedValue(dropdwonTo,toclass);

            appHandle.ClickObjectViaJavaScript(linkDeselectAll);

            appHandle.WaitForSpecifiedTime(3);
            string[] totitmes=datatobeselectedseperatedbydelimsemicoln.Split(';');
            for(int i=0;i<totitmes.Length;i++)
            {
                string dynamicobj="XPath;//*[contains(text(),'"+totitmes[i]+"')]/preceding-sibling::td/input";
                appHandle.ClickObjectViaJavaScript(dynamicobj);
                appHandle.WaitForSpecifiedTime(2);

            }

            appHandle.ClickObjectViaJavaScript(buttonsubmit);
            if(appHandle.IsObjectEnabled(buttonsubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonsubmit);

            }

            return appHandle.CheckSuccessMessage(Data.Get("MsgUserClassPermission"));


        }


        public virtual void ClickOnLinkBasedOnName(string linkname)
        {
            string dynamicobj="XPath;//a[contains(text(),'"+linkname+"')]";
            string dynamicobj1="XPath;//table[@class='tab']/descendant::td[contains(text(),'Userclass Permissions')]";
           
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynamicobj1);
            appHandle.ClickObjectViaJavaScript(dynamicobj1);
            
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdwonFrom);
            appHandle.ClickObjectViaJavaScript(dynamicobj);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonsubmit);

        }

        public virtual void CheckNegaivtiveScenarioForScriptCopyUserclassAndAllPermissions002(string fromuserclass,string touserclass)
        {

            string dynamicobj1="XPath;//input[@value='UTBLCNTXTAUT - Context Authorization']";
            string dynamicobj2="XPath;//input[@value='SCATBL3 - SCA Menu - Userclass Level']";
            string dynamicobj3="XPath;//input[@value='UTBLMASKAUT - Mask Authorization']";
            string dynamicobj4="XPath;//input[@value='UTBLDENLIMUC - Userclass Denomination Limits']";
            string dynamicobj5="XPath;//*[contains(text(),'Please select at least one permission.')]";

            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdwonTo);
            appHandle.SelectDropdownSpecifiedValue(dropdwonTo,touserclass);
            appHandle.ClickObjectViaJavaScript(buttonsubmit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdwonTo);
            appHandle.CheckSuccessMessage("We could not process your request.");
            if(appHandle.CheckSuccessMessage("From is required."))
            {
                Report.Info("The expected message exist in application","exppass","True",appHandle);
            }

            appHandle.SelectDropdownSpecifiedValue(dropdwonTo,"");
            appHandle.SelectDropdownSpecifiedValue(dropdwonFrom,fromuserclass);
            appHandle.ClickObjectViaJavaScript(buttonsubmit);

            appHandle.CheckSuccessMessage("We could not process your request.");
            if(appHandle.CheckSuccessMessage("To is required."))
            {
                Report.Info("The expected message exist in application","exppass12","True",appHandle);
            }

            appHandle.SelectDropdownSpecifiedValue(dropdwonTo,fromuserclass);
            appHandle.SelectDropdownSpecifiedValue(dropdwonFrom,fromuserclass);
            appHandle.ClickObjectViaJavaScript(buttonsubmit);

            appHandle.CheckSuccessMessage("We could not process your request.");
            if(appHandle.CheckSuccessMessage("From and To userclasses should be different."))
            {
                Report.Info("The expected message exist in application","exppass123","True",appHandle);
            }

            bool ret1=appHandle.CheckCheckBoxChecked(dynamicobj1);
            bool ret2=appHandle.CheckCheckBoxChecked(dynamicobj2);
            bool ret3=appHandle.CheckCheckBoxChecked(dynamicobj3);
            if(ret1 && ret2 && ret3)
            {
                Report.Pass("The checkbox are selected in userclass permission","chkpass","True",appHandle);
            }
            else
            {
                Report.Fail("The checkbox are deselected in userclass permission","chkfail","True",appHandle);

            }

            appHandle.SelectDropdownSpecifiedValue(dropdwonFrom,"");
            appHandle.SelectDropdownSpecifiedValue(dropdwonTo,touserclass);
            
            appHandle.ClickObjectViaJavaScript(linkDeselectAll);

            appHandle.ClickObjectViaJavaScript(buttonsubmit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdwonTo);

            string acttext=appHandle.GetObjectText(dynamicobj5);

            if(acttext.Equals("Please select at least one permission."))
            {
                Report.Pass("The Expected message exist in application","edpass","True",appHandle);
            }
            else
            {
                Report.Fail("The Expected message not exist in application","edfail","True",appHandle);

            }       

        }


        public virtual void OperationsForCopyUserclassAndAllPermissions002(string newclass,string copyclass)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdwonTo);
            appHandle.SelectDropdownSpecifiedValue(dropdwonFrom,newclass);
            appHandle.WaitForSpecifiedTime(2);
            appHandle.SelectDropdownSpecifiedValue(dropdwonTo,copyclass);
            appHandle.WaitForSpecifiedTime(2);

            //appHandle.ClickObjectViaJavaScript(checkboxUTBLCNTXTAUT);
            //appHandle.ClickObjectViaJavaScript(checkboxUTBLDENLIMUC);
            //appHandle.ClickObjectViaJavaScript(checkboxUTBLMASKAUT);

            appHandle.ClickObjectViaJavaScript(buttonsubmit);
            if(appHandle.CheckSuccessMessage("Userclass Permissions have been copied."))
            {
                Report.Pass("The expected message exist in application","rt","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message does not exist in application","rtfail","True",appHandle);

            }

            bool v1=appHandle.IsObjectEnabled(dropdwonFrom);
            bool v2=appHandle.IsObjectEnabled(dropdwonTo);
            bool v3=appHandle.IsObjectEnabled(buttonsubmit);
            bool v4=appHandle.IsObjectEnabled(buttonCancel);

            if(!v1 && !v2 && !v3 && v4)
            {
                Report.Pass("The object are enabled in application","lp","True",appHandle);
            }
            else
            {
                Report.Fail("The object are disabled in application","lp1","True",appHandle);

            }

            appHandle.ClickObjectViaJavaScript(buttonCancel);
            bool v5=appHandle.IsObjectEnabled(dropdwonFrom);
            bool v6=appHandle.IsObjectEnabled(dropdwonTo);
            bool v7=appHandle.IsObjectEnabled(buttonsubmit);
            bool v8=appHandle.IsObjectEnabled(buttonCancel);

            if(v5 && v6 && v7 && v8)
            {
                Report.Pass("The object are enabled in application","op","True",appHandle);
            }
            else
            {
                Report.Fail("The object are disabled in application","op","True",appHandle);

            }


            appHandle.SelectDropdownSpecifiedValue(dropdwonFrom,copyclass);
            bool a1=appHandle.CheckCheckBoxChecked(checkboxUTBLCNTXTAUT);
            bool a2=appHandle.CheckCheckBoxChecked(checkboxUTBLDENLIMUC);
            if(a1 && a2)
            {
                Report.Pass("The Checkbox are checked in copy userclass permission page","op","True",appHandle);
            }
            else
            {
                Report.Fail("The Checkbox are unchecked in copy userclass permission page","op1","True",appHandle);

            }

            appHandle.ClickObjectViaJavaScript(buttonCancel);
            appHandle.SelectDropdownSpecifiedValue(dropdwonFrom,newclass);
            appHandle.SelectDropdownSpecifiedValue(dropdwonTo,copyclass);
            appHandle.ClickObjectViaJavaScript(buttonsubmit);
            appHandle.ClickObjectViaJavaScript(buttonCancel);

            appHandle.SelectDropdownSpecifiedValue(dropdwonFrom,newclass);
            appHandle.SelectDropdownSpecifiedValue(dropdwonTo,copyclass);
            bool b1=appHandle.CheckCheckBoxChecked(checkboxUTBLMASKAUT);
            bool b2=appHandle.CheckCheckBoxChecked(checkboxUTBLCNTXTAUT);
            if(b1 && b2)
            {
                Report.Pass("The checkbox are selected in copy user class permission page","okl","True",appHandle);
            }
            else
            {
                Report.Fail("The checkbox are not selected in copy user class permission page","okl2","True",appHandle);

            }



        }
        public virtual bool CopyPermissionfromOneUserClasstoAnother(string fromclass,string toclass)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdwonFrom);
            
            appHandle.SelectDropdownSpecifiedValue(dropdwonFrom,fromclass);
            appHandle.SelectDropdownSpecifiedValue(dropdwonTo,toclass);

            appHandle.ClickObjectViaJavaScript(buttonsubmit);
            if(appHandle.IsObjectEnabled(buttonsubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonsubmit);

            }

            return appHandle.CheckSuccessMessage(Data.Get("MsgUserClassPermission"));


        }



        

        
    }
}