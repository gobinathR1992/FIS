using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.Util;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class ContextFieldListPage
    {

        static  WebApplication appHandle= ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); 

        public static string dropdownContext="XPath;//select[@name='contextId']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public static string buttonAdd="XPath;//input[@name='add']";
        public static string buttonDelete="XPath;//input[@name='delete']";
        public static string tableContextFields="XPath;//table[@id='contextFields']/tbody";
        public static string txtTableName="XPath;//input[@name='records[0].form.UTBLCNTXTFLD_TABLENAME']";
        public static string txtColumnName="XPath;//input[@name='records[0].form.UTBLCNTXTFLD_COLUMNNAME']";
        public static string dropdownMinimumPermisssion="XPath;//select[@name='records[0].form.UTBLCNTXTFLD_MINIMUMPERM']";

        public static string txtTableNamesecond="XPath;//input[@name='records[1].form.UTBLCNTXTFLD_TABLENAME']";
        public static string txtColumnNamesecond="XPath;//input[@name='records[1].form.UTBLCNTXTFLD_COLUMNNAME']";
        public static string dropdownMinimumPermisssionSecond="XPath;//Select[@name='records[1].form.UTBLCNTXTFLD_MINIMUMPERM']";

        public static string txtTableNamethird="XPath;//input[@name='records[2].form.UTBLCNTXTFLD_TABLENAME']";
        public static string txtColumnNamethird="XPath;//input[@name='records[2].form.UTBLCNTXTFLD_COLUMNNAME']";
        public static string dropdownMinimumPermisssionthird="XPath;//Select[@name='records[2].form.UTBLCNTXTFLD_MINIMUMPERM']";



        public virtual void SelectValueFromContextDropDown(string val)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownContext);
            appHandle.SelectDropdownSpecifiedValue(dropdownContext,val);
        }   

        public virtual void CheckNegativeScenariosSet()
        {
            bool resfound=false;
            string dynamictableobj="//td[contains(text(),'No fields found for this context.')]";

            string errmsg="No fields found for this context.";
            string dropdownvalcontext=Data.Get("ContextRuleCustomerPersonalGeneralTab");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownContext);
            appHandle.SelectDropdownSpecifiedValue(dropdownContext,"Rule Set Modify");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            string acttxt=appHandle.GetObjectText(dynamictableobj);           
            appHandle.SelectDropdownSpecifiedValue(dropdownContext,"Customer-Personal-General Tab");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            
            int noofrows=appHandle.GetRowCountfromList(tableContextFields);
            int j=noofrows;
            for(int i=1;i<=noofrows;i++)
            {
                
                string tempobj="XPath;//table[@id='contextFields']/tbody/tr["+i+"]/td[1]/input[@type='checkbox']";
                if(appHandle.IsObjectExists(tempobj))
                {
                    resfound=true;
                    appHandle.ClickObjectViaJavaScript(tempobj);    
                }            
            
            }

            if(resfound==true)
            {
                appHandle.ClickObjectViaJavaScript(buttonDelete);
                appHandle.SwitchTo(SwitchInto.ALERT);            
                appHandle.PerformActionOnAlert(PopUpAction.Accept);
                appHandle.SwitchTo(SwitchInto.DEFAULT);
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }

            appHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtTableName);
            appHandle.Set_field_value(txtTableName,Data.Get("TableCIF"));
            appHandle.Set_field_value(txtColumnName,Data.Get("ColumnNameStat"));
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            bool val1=appHandle.CheckSuccessMessage(Data.Get("ErrMinimumPermissionRequired"));
            if(val1)
            {
                Report.Pass("The expected message present in application "+Data.Get("ErrMinimumPermissionRequired"),"pass1","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message not present in application "+Data.Get("ErrMinimumPermissionRequired"),"fail1","True",appHandle);
            }
            appHandle.Set_field_value(txtTableName,"");
            appHandle.Set_field_value(txtColumnName,Data.Get("ColumnNameStat"));
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssion,"Full Access");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage(Data.Get("ErrMsgTableNameRequired")))
            {
                Report.Pass("The expected message present in application "+Data.Get("ErrMsgTableNameRequired"),"pass2","True",appHandle);

            }
            else
            {
                Report.Fail("The expected message not present in application "+Data.Get("ErrMsgTableNameRequired"),"fail2","True",appHandle);

            }

            appHandle.Set_field_value(txtTableName,Data.Get("TableCIF"));
            appHandle.Set_field_value(txtColumnName,"");
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssion,"Full Access");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage(Data.Get("ErrMsgColumnNameRequired")))
            {
                Report.Pass("The expected message present in application "+Data.Get("ErrMsgColumnNameRequired"),"pass3","True",appHandle);

            }
            else
            {
                Report.Fail("The expected message present in application "+Data.Get("ErrMsgColumnNameRequired"),"fail3","True",appHandle);
            }

            appHandle.Set_field_value(txtTableName,Data.Get("TableCIF"));
            appHandle.Set_field_value(txtColumnName,Data.Get("ColumnNameStat"));
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssion,"Full Access");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The expected message present in application "+Data.Get("GLOBAL_INFORMATION_UPDATED"),"pass4","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message not present in application "+Data.Get("GLOBAL_INFORMATION_UPDATED"),"fail4","True",appHandle);
            }

            appHandle.ClickObjectViaJavaScript(buttonAdd);
            appHandle.Set_field_value(txtTableNamesecond,Data.Get("TableCIF")+"Invalid");
            appHandle.Set_field_value(txtColumnNamesecond,Data.Get("ColumnNameStat"));
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssionSecond,"Full Access");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage(Data.Get("ErrMsgTableNameInvalid")))
            {
                Report.Pass("The expected message present in application "+Data.Get("ErrMsgTableNameInvalid"),"pass5","True",appHandle);
            }
            else
            {
                 Report.Fail("The expected message not present in application "+Data.Get("ErrMsgTableNameInvalid"),"fail5","True",appHandle);
            }

            
            appHandle.Set_field_value(txtTableNamesecond,Data.Get("TableCIF"));
            appHandle.Set_field_value(txtColumnNamesecond,Data.Get("ColumnNameStat")+"Invalidcolumn");
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssionSecond,"Full Access");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage(Data.Get("ErrMsgColumnNameInvalid")))
            {
                Report.Pass("The expected message present in application "+Data.Get("ErrMsgColumnNameInvalid"),"pass6","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message not present in application "+Data.Get("ErrMsgColumnNameInvalid"),"fail6","True",appHandle);
            }

            appHandle.Set_field_value(txtTableNamesecond,Data.Get("TableCIF"));
            appHandle.Set_field_value(txtColumnNamesecond,"CC");
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssionSecond,"Full Access");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);            
            if(appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The expected message present in application "+Data.Get("GLOBAL_INFORMATION_UPDATED"),"pass7","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message not present in application "+Data.Get("GLOBAL_INFORMATION_UPDATED"),"fail7","True",appHandle);
            }

            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssionSecond,"View Access");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);            
            if(appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The expected message present in application "+Data.Get("GLOBAL_INFORMATION_UPDATED"),"pass8","True",appHandle);

            }
            else
            {
                Report.Fail("The expected message present in application "+Data.Get("GLOBAL_INFORMATION_UPDATED"),"fail8","True",appHandle);

            }


            appHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtTableNamethird);
            appHandle.Set_field_value(txtTableNamethird,Data.Get("TableCIF"));
            appHandle.Set_field_value(txtColumnNamethird,Data.Get("ColumnNameStat"));
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssionthird,"Full Access");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            if(appHandle.CheckSuccessMessage(Data.Get("ErrMsgRecordAlreadyExist")))
            {
                Report.Pass("The expected message present in application "+Data.Get("ErrMsgRecordAlreadyExist"),"pass9","True",appHandle);

            }
            else
            {
                Report.Fail("The expected message not present in application "+Data.Get("ErrMsgRecordAlreadyExist"),"fail9","True",appHandle);
            }

            appHandle.ClickObjectViaJavaScript(buttonDelete);
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.PerformActionOnAlert(PopUpAction.Verify,Data.Get("ErrMsgSelectAnElement"));
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);

            appHandle.ClickObjectViaJavaScript("XPath;//table[@id='contextFields']/tbody/tr[2]/td[1]/input[@type='checkbox']");
            appHandle.ClickObjectViaJavaScript(buttonDelete);
            appHandle.SwitchTo(SwitchInto.ALERT);            
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);

            resfound=false;

        }  

        public virtual bool EnterValuesForContextNameCustomerPersonalGenralTab()
        {
            bool rowfound=false;
            string dynamicobj="XPath;//table[@id='contextFields']/tbody/tr";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownContext);
            appHandle.SelectDropdownSpecifiedValue(dropdownContext,"Customer Services");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);

           

            appHandle.ClickObjectViaJavaScript(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtTableNamethird);
            appHandle.Set_field_value(txtTableName,Data.Get("TableCIF"));
            appHandle.Set_field_value(txtColumnName,Data.Get("ColumnNameCC"));
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssion,"View Access");

            appHandle.Set_field_value(txtTableNamesecond,Data.Get("TableCIF"));
            appHandle.Set_field_value(txtColumnNamesecond,Data.Get("ColumnNameBOO"));
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssionSecond,"View Access");

            appHandle.Set_field_value(txtTableNamethird,Data.Get("TableCIF"));
            appHandle.Set_field_value(txtColumnNamethird,Data.Get("ColumnNameHPH"));
            appHandle.SelectDropdownSpecifiedValue(dropdownMinimumPermisssionthird,"No Access");

            Report.Info("The Information has been entered for Customer Personal Genral Tab","Genpass","True",appHandle);

            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }

        public virtual void DeleteEntriesFromContextTable()
        {
            bool isflg=false;
            string obj1="XPath;//table[@id='contextFields']/tbody/tr[";//[1]/td[1]/input";
            string obj="XPath;//table[@id='contextFields']/tbody/tr";
            int noofrows=appHandle.GetRowCountfromList(obj);
            for(int i=1;i<=3;i++)
            {
                isflg=true;
                appHandle.SelectDropdownSpecifiedValue(obj1+(i)+"]/td[5]/select","Full Access");

            }

            if(isflg==true)
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownContext);
            }
            


            
            
            for(int i=1;i<=3;i++)
            {
                isflg=true;
                appHandle.ClickObjectViaJavaScript(obj1+(i)+"]/td[1]/input");


            }

            if(isflg==true)
            {
            appHandle.ClickObjectViaJavaScript(buttonDelete);
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            }

            


        }


        public virtual void Performprerequisitestep()
        {
            string dynamicobj="XPath;//table[@id='contextFields']/tbody";
            SelectValueFromContextDropDown("Customer Services");
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            int row=appHandle.GetRowCountfromList(dynamicobj);
            if(row>1)
            {
                for(int i=1;i<=row;i++)
                {
                    string dropdownobj=dynamicobj+"/tr["+i+"]/td[5]/select";
                    appHandle.SelectDropdownSpecifiedValue(dropdownobj,"Full Access");

                }

                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                appHandle.CheckSuccessMessage("The information has been updated.");

            }

            if(row>1)
            {

                for(int i=1;i<=row;i++)
                {
                    string checkboxobj=dynamicobj+"/tr["+i+"]/td[1]/input";
                    appHandle.ClickObjectViaJavaScript(checkboxobj);

                }

                appHandle.ClickObjectViaJavaScript(buttonDelete);
                appHandle.SwitchTo(SwitchInto.ALERT);
                appHandle.PerformActionOnAlert(PopUpAction.Accept);
                appHandle.SwitchTo(SwitchInto.DEFAULT);
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                appHandle.CheckSuccessMessage("The information has been updated.");
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit); 
            }       

        
        
        
        
        }
        
    }
}