using System;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class LoanInterestCalculationPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpCalculationAnnualPercentageRateCalculationMethod = "XPath;//select[@name='PRODDFTL_APRMTHD']";             
        private static string drpAccrualCalculationMethod="XPath;//*[@name='PRODDFTL_IACM']";
        public static string drpAccrualCalculationBalanceOption = "XPath;//select[@name='PRODDFTL_ICPA']";
        public static string txtMinimumBalanceToAccrue = "XPath;//input[@name='PRODDFTL_MINACR']";
        public static string drpInterestRateDisclosureMethod = "XPath;//select[@name='PRODDFTL_IACF']";
        public static string drpcalculationnominalinterestratecalculationmethod = "XPath;//select[@name='PRODCTL_IRNCALMT']";
        public static string drpAccountingAccrualCalculationMethod = "XPath;//select[@name='PRODCTL_AACM']";

        private static string ckbCalculateInterest="Xpath;//*[@name='PRODCTL_PPIF']";
        private static string drpInterestCalculationOption="XPath;//*[@name='PRODDFTL_PPICO']";
        private static string drpInterestColletionMethod="XPath;//*[@name='PRODDFTL_ODIO']";
        
        private static string btn_Submit = "xpath;//input[@value='Submit']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p[1]";


        public virtual void UpdateAccuralCalculationMethod(string CalculationMethod)
        {
            appHandle.WaitUntilElementExists(drpAccrualCalculationMethod);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpAccrualCalculationMethod,CalculationMethod);
        }
        public virtual void ClickOnSubmit()
        {
            appHandle.WaitUntilElementExists(btn_Submit);
            appHandle.ClickObjectViaJavaScript(btn_Submit);

        }
         public virtual bool VerifyMessageInWebAdminLoanInterestCalculationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (appHandle.GetObjectText(MSGOBJ).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool ClickOnCalculateInterestCheckbox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbCalculateInterest))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(ckbCalculateInterest)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbCalculateInterest);
                        if (appHandle.CheckCheckBoxChecked(ckbCalculateInterest))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(ckbCalculateInterest) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbCalculateInterest);
                        if (appHandle.CheckCheckBoxChecked(ckbCalculateInterest) == false){ Result = true; }
                    }
                }
            }
            return Result;
        }

        public virtual void UpdateCalculationandColletionMethod(string CalculationOption,string CollectionMethod)
        {
            appHandle.WaitUntilElementExists(drpInterestCalculationOption);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpInterestCalculationOption,CalculationOption);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpInterestColletionMethod,CollectionMethod);
        }
        public virtual void EnterInterestCalculationOptions(string sAccrualCalcMethod, string sAccrualCalcBalOpt, string sMinBalToAccrue, string AccountingAccrCalMethod, bool ckbCalInt, string InterestRateDisclosureMethod, string calculationnominalinterestratecalculationmethod, string InterestColletionMethod)
        {
                if (!string.IsNullOrEmpty(sAccrualCalcMethod))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpAccrualCalculationMethod, sAccrualCalcMethod);
                }
                if (!string.IsNullOrEmpty(sAccrualCalcBalOpt))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpAccrualCalculationBalanceOption, sAccrualCalcBalOpt);
                }
                if (!string.IsNullOrEmpty(sMinBalToAccrue))
                {
                    appHandle.Set_field_value(txtMinimumBalanceToAccrue, sMinBalToAccrue);
                }
                if (!string.IsNullOrEmpty(AccountingAccrCalMethod))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpAccountingAccrualCalculationMethod, AccountingAccrCalMethod);
                }
                if (ckbCalInt)
                {
                    if (appHandle.CheckCheckBoxChecked(ckbCalculateInterest)) {  }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbCalculateInterest);
                        if (appHandle.CheckCheckBoxChecked(ckbCalculateInterest))
                        {  }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(ckbCalculateInterest) == false) {  }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbCalculateInterest);
                        if (appHandle.CheckCheckBoxChecked(ckbCalculateInterest) == false){  }
                    }
                }
                if(InterestRateDisclosureMethod=="")
                {
                    appHandle.SelectDropdownSpecifiedValue(drpInterestRateDisclosureMethod,InterestRateDisclosureMethod);
                }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpInterestRateDisclosureMethod, InterestRateDisclosureMethod);
                }
                if(calculationnominalinterestratecalculationmethod=="")
                {
                    appHandle.SelectDropdownSpecifiedValue(drpcalculationnominalinterestratecalculationmethod,calculationnominalinterestratecalculationmethod);
                }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpcalculationnominalinterestratecalculationmethod, calculationnominalinterestratecalculationmethod);
                }
                if(InterestColletionMethod=="")
                {
                    appHandle.SelectDropdownSpecifiedValue(drpInterestColletionMethod,InterestColletionMethod);
                }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpInterestColletionMethod, InterestColletionMethod);
                }

        }        


    }

}