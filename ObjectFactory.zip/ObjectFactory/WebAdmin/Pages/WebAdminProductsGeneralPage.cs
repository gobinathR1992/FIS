using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class WebAdminProductsGeneralPage
    {

        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txt_General_Information_Description_Field = "XPath;//tr[td[label[contains(@for,'PRODCTL_DES')]]]//input";
        public static string txt_General_Information_Start_Date_Field = "xpath;//tr[td[label[contains(text(),'Start Date')]]]//input";
        public static string txtGeneralInformationNickNameField = "Xpath;//input[@name='PRODDFTD_ACCTNAME']";
        public static string btn_Submit = "xpath;//input[@value='Submit']";
        public static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        public static string lnkRateDetermination = "Xpath;//a[text()='Rate Determination']";
        public static string ChkBillingStatementProducePrintedBill = "Xpath;//input[@name='PRODDFTL_BMET']";
        public static string lnkPostingOptions = "Xpath;//a[text()='Posting Options']";
        public static string lnkCalculation = "Xpath;//a[text()='Calculation']";
        public static string lnkPenality = "Xpath;//a[text()='Penalty']";
        private static string dropdownAvailableBalCalcCode = "XPath;//*[contains(text(),'Available Balance Calculation Code')]/ancestor::*[1]/following-sibling::*/descendant::select";
        private static string chckboxEgilibilityForCardProcessing = "Xpath;//*[@name='PRODDFTD_CRDIND']";
        private static string checkboxOriginalIssueDiscount="XPath;//*[contains(text(),'Original Issue Discount')]/ancestor::*[1]/following-sibling::*/descendant::*[1]";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonSubmit = "XPath;//*[@value='submit']";
        public virtual void set_description_field_value(string sDescription)
        {
            appHandle.Wait_for_object(txt_General_Information_Description_Field, 3);
            appHandle.Set_field_value(txt_General_Information_Description_Field, sDescription);
        }
        public virtual void set_start_date_field_value(string sStartDate)
        {
            appHandle.Wait_for_object(txt_General_Information_Start_Date_Field, 3);
            appHandle.Set_field_value(txt_General_Information_Start_Date_Field, sStartDate);
        }
        public virtual void select_submit_button()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btn_Submit))
            {
                appHandle.SelectButton(btn_Submit);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX);
        }
  
        public virtual bool CheckPackageSuccessMessage(string inputMessage)
        {
            bool Result = false;
            if (appHandle.GetObjectText(sSuccessMessage).Equals(inputMessage))
            {
                Result = true;
            }
            else
            {
                Result = false;
            }
            return Result;
        }
        public virtual void SelectAvailableBalanceCalculationCode(string itemToBeSelected)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAvailableBalCalcCode))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAvailableBalCalcCode, itemToBeSelected);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            select_submit_button();
        }
        public virtual bool VerifyMessageWebAdminProductGeneralPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool ClickOnEligibleForCardProcessingCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chckboxEgilibilityForCardProcessing))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(chckboxEgilibilityForCardProcessing)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(chckboxEgilibilityForCardProcessing);
                        if (appHandle.CheckCheckBoxChecked(chckboxEgilibilityForCardProcessing))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(chckboxEgilibilityForCardProcessing) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(chckboxEgilibilityForCardProcessing);
                        if (appHandle.CheckCheckBoxChecked(chckboxEgilibilityForCardProcessing) == false) { Result = true; }
                    }
                }
            }
            return Result;


        }
         public virtual bool ClickOnOriginalIssueDiscountCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxOriginalIssueDiscount))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxOriginalIssueDiscount)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxOriginalIssueDiscount);
                        if (appHandle.CheckCheckBoxChecked(checkboxOriginalIssueDiscount))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxOriginalIssueDiscount) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxOriginalIssueDiscount);
                        if (appHandle.CheckCheckBoxChecked(checkboxOriginalIssueDiscount) == false) { Result = true; }
                    }
                }
            }
            return Result;
           

        }
        public virtual bool WaitUntilDepositProductGeneralPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtGeneralInformationNickNameField))
            {
                result = true;
            }

            return result;

        }
        public virtual void EnterDepositProdGeneralOptions(string depositProdGeneraloptionssemecolondelemited="" )
        {

            if(!string.IsNullOrEmpty(depositProdGeneraloptionssemecolondelemited))
            {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(depositProdGeneraloptionssemecolondelemited);
            }
        }        
    }
}