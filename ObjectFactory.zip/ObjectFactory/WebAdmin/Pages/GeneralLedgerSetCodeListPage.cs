using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Threading;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class GeneralLedgerSetCodeListPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string dropdownProductClass="XPath;//select[@name='productClass']";
        public static string dropdownProductGroup="XPath;//select[@name='productGroup']";
        public static string buttonSearch="XPath;//input[@name='search']";
        public static string buttonAdd="XPath;//input[@name='add']";
        public static string buttonEdit="XPath;//input[@name='edit']";

        public static string txtGeneralLedgeSetCode="XPath;//input[@name='UTBLGLSC_GLSC']";
        public static string txtDescription="XPath;//input[@name='UTBLGLSC_DESC']";
       
        public static string dropdownBalanceSheetAccountsPrincipalBalance="XPath;//select[@name='UTBLGLSC_LGL1']";
        public static string dropdownBalanceSheetAccountsNegativePrincipalBalance="XPath;//select[@name='UTBLGLSC_LGLNB']";
        public static string dropdownBalanceSheetAccountsUndisbursedPrincipal="XPath;//select[@name='UTBLGLSC_LGL4']";
        public static string dropdownBalanceSheetAccountsVATonAccruedInterestReceivable="XPath;//select[@name='UTBLGLSC_LGLVATINTR']";
        public static string dropdownBalanceSheetAccountsLateChargeRecivable="XPath;//select[@name='UTBLGLSC_LGL3']";
        public static string dropdownBalanceSheetAccountsMiscellaneousChargeReceivable="XPath;//select[@name='UTBLGLSC_LGL5']";
        public static string dropdownBalanceSheetAccountsEscrowSuspence="XPath;//select[@name='UTBLGLSC_LGL6']";
        public static string dropdownBalanceSheetAccountsUnappliedFunds="XPath;//select[@name='UTBLGLSC_LGL8']";
        public static string dropdownBalanceSheetAccountsLoanLossReserve="XPath;//select[@name='UTBLGLSC_LGLLR']";
        public static string dropdownBalanceSheetAccountsPrincipalRecovery="XPath;//select[@name='UTBLGLSC_LGL10']";
        
        public static string dropdownIncomeStatementAccountsInterestIncome="XPath;//select[@name='UTBLGLSC_LGLI']";
        public static string dropdownIncomeStatementAccountsLateChargeIncome="XPath;//select[@name='UTBLGLSC_LGLL']";
        public static string dropdownIncomeStatementAccountsMiscellaneousIncome="XPath;//select[@name='UTBLGLSC_LGLVATPENI']";
        public static string dropdownIncomeStatementAccountsEarlyPaymentPenaltyIncome="XPath;//select[@name='UTBLGLSC_LGLP']";
        public static string dropdownIncomeStatementAccountsVATonEarlyPaymentPenaltyIncome="XPath;UTBLGLSC_LGLVATPENI";

        
        
        
        
        public static string dropdownContractuallyRequiredPaymentReceivable="XPath;//select[@name='UTBLGLSC_CONTREQPMTRCVBL']";
        public static string dropdownAccretableYield="XPath;//select[@name='UTBLGLSC_ACCRETYLD']";
        public static string dropdownAccretableInterestIncome="XPath;//select[@name='UTBLGLSC_ACCRETINTINC']";
        public static string dropdownContractuallyRequiredPaymentReceivableOffset="XPath;//select[@name='UTBLGLSC_CONTREQPMTRCVBLOFFSET']";
        
        public static string dropdownLoanLossAllowance="XPath;";
        public static string dropdownProvisionforLoanLossesIncrease="XPath;";
        public static string dropdownProvisionforLoanLossesDecrease="XPath;";
        
        public static string dropdownNonaccretableYield="XPath;//select[@name='UTBLGLSC_NONACCRETYLD']";

        public static string dropdwonProvisionforLoanLossesDecrease="XPath;//select[@name='UTBLGLSC_PROV4LNLOSSDEC']";
        public static string buttonSubmit="XPath;//input[@name='submit']";

        public virtual void EnterDetailsForProdClassAndProdGroup(string prodnum)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownProductClass);
            appHandle.SelectDropdownSpecifiedValue(dropdownProductClass,"L - Loan Accounts");
            appHandle.SelectDropdownSpecifiedValue(dropdownProductGroup,"MTG - Mortgage Loans");
            appHandle.ClickObjectViaJavaScript(buttonSearch);
            Report.Info("The Product class and product group details entered","pgp","True",appHandle);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtGeneralLedgeSetCode);

            appHandle.Set_field_value(txtGeneralLedgeSetCode,prodnum);
            appHandle.Set_field_value(txtDescription,prodnum);

        }

        public virtual void addvaluestodropdownset1(string gl1,string gl2,string gl3,string gl4,string gl5)
        {

            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsPrincipalBalance,gl1+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsNegativePrincipalBalance,gl2+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsUndisbursedPrincipal,gl3+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsVATonAccruedInterestReceivable,gl4+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsLateChargeRecivable,gl5+" - "+Data.Get("GLDesc"));
        }
        public virtual void advaluestodropdownset2(string gl1,string gl2,string gl3,string gl4,string gl5)
        {        
            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsMiscellaneousChargeReceivable,gl1+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsEscrowSuspence,gl2+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsUnappliedFunds,gl3+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsLoanLossReserve,gl4+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownBalanceSheetAccountsPrincipalRecovery,gl5+" - "+Data.Get("GLDesc"));

        }    

        public virtual void advaluestodropdownset3(string gl1,string gl2,string gl3,string gl4,string gl5)
        {
            appHandle.SelectDropdownSpecifiedValue(dropdownIncomeStatementAccountsInterestIncome,gl1+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownIncomeStatementAccountsLateChargeIncome,gl2+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownIncomeStatementAccountsMiscellaneousIncome,gl3+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownIncomeStatementAccountsEarlyPaymentPenaltyIncome,gl4+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownIncomeStatementAccountsVATonEarlyPaymentPenaltyIncome,gl5+" - "+Data.Get("GLDesc"));
        }

        public virtual void advaluestodropdownset4(string gl1,string gl2,string gl3,string gl4,string gl5,string gl6,string gl7,string gl8)
        { 
            appHandle.SelectDropdownSpecifiedValue(dropdownContractuallyRequiredPaymentReceivable,gl1+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownNonaccretableYield,gl2+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownAccretableYield,gl3+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownAccretableInterestIncome,gl4+" - "+Data.Get("GLDesc"));

            appHandle.SelectDropdownSpecifiedValue(dropdownContractuallyRequiredPaymentReceivableOffset,gl5+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownLoanLossAllowance,gl6+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdownProvisionforLoanLossesIncrease,gl7+" - "+Data.Get("GLDesc"));
            appHandle.SelectDropdownSpecifiedValue(dropdwonProvisionforLoanLossesDecrease,gl8+" - "+Data.Get("GLDesc"));
            
        }

        public virtual bool ClickOnSubmit()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLSetCodeSuccess"));

        }


        

        
    }
}