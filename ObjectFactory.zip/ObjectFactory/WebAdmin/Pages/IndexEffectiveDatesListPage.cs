using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class IndexEffectiveDatesListPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string tableIndexList = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";



       /// <summary>
        /// This method is used to select specified Effective Date in IndexEffectiveDatesList Table
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.IndexEffectiveDatesListPage.SelectEffectiveDateForIndex();
        /// </example> 
        public void SelectEffectiveDateForIndex(string sEffectiveDate)
        {
            try{
            string tblIndexEffectiveDatesList = "Xpath;//input[@value='"+sEffectiveDate+"']";
            appHandle.WaitUntilElementVisible(tblIndexEffectiveDatesList);
            appHandle.Set_radiobutton(tblIndexEffectiveDatesList);
            }catch(Exception e)
            {
                Report.Info("Exception logged : "+e);
            }
        } 

        

        public virtual string GetColumnHeaderNameByColumnNumberInIndexList(int ColNum)
        {
            string headername = "";
            string runtimeObj = tableIndexList + "/ancestor::*[@class='dataTables_scrollBody']/preceding-sibling::div/descendant::thead/tr[1]/th[" + ColNum + "]";
            headername = appHandle.GetObjectText(runtimeObj).Trim();
            return headername;
        }

        public virtual bool ModifyRatesInInterestIndex(string TiredIndexRateDetails, string EffectiveDate = "", bool IsAnticipatedRun = true, bool IsRunAtDayEnd = true)
        {
            
            if (!IsAnticipatedRun)
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Anticipated Run") + "|" + Data.Get("OFF"));
            }
            else
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Anticipated Run") + "|" + Data.Get("GLOBAL_ON"));
            }
            if (!IsRunAtDayEnd)
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Run at Dayend") + "|" + Data.Get("OFF"));
            }
            else
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Run at Dayend") + "|" + Data.Get("GLOBAL_ON"));
            }
            
            string temp = "";
            bool DataEntered = false;
            int numberofDataToEnterPerRow = 0;
            int RecordCount = 0;
            TiredIndexRateDetails = TiredIndexRateDetails + ";";
            string[] arr = TiredIndexRateDetails.Split(';');
            int rowscount = appHandle.GetRowCountfromList(tableIndexList);
            for (int c = 0; c < arr.Length - 1; c++)
            {
                for (int a = 1; a <= rowscount; a++)
                {
                    if (arr[c].Contains("|"))
                    {
                        numberofDataToEnterPerRow = arr[c].Split('|').Length;
                    }
                    else { numberofDataToEnterPerRow = 1; }

                    for (int b = 1; b <= numberofDataToEnterPerRow; b++)
                    {
                        string runtimeobj = tableIndexList + "/tr[" + a + "]/td[" + (b + 1) + "]/descendant::input" ;
						int indexlength = appHandle.GetLengthOfText(runtimeobj);
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runtimeobj))
                        {
							for(int i=0;i<=indexlength-1;i++)	
							{
								appHandle.SendKeyStroke(runtimeobj, InputKey.Backspace);
							}
							//appHandle.Set_field_value(tableIndexList + "/tr[" + a + "]/td[" + (b + 1) + "]/descendant::input", arr[c].Split('|')[b - 1]);

                            appHandle.Set_field_value(tableIndexList + "/tr[" + a + "]/td[" + (b + 1) + "]/descendant::input", arr[c].Split('|')[b - 1]);

                            temp = temp + " , " + this.GetColumnHeaderNameByColumnNumberInIndexList(b + 1) + " in level : " + a + " is entered as :" + arr[c].Split('|')[b - 1];
                            RecordCount++;
                            if (RecordCount == arr[c].Split('|').Length)
                            {
                                DataEntered = true;
                                RecordCount = 0;
                                break;
                            }
                        }
                        else
                        {
                            DataEntered = false;
                        }
                    }
                    c++;
                    if (c == arr.Length - 1)
                    {
                        if (DataEntered)
                        {
                            temp = temp.Substring(3, temp.Length - 3).Trim();
                            Report.Info(temp, "tieredratesenter", "True", appHandle);
                        }
                        break;
                    }
                    else { continue; }

                }
                if (c == arr.Length - 1) { break; } else { continue; }
            }
            return DataEntered;
        }
       

    }
}