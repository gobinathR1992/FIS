using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Profile7Automation.Libraries.Util;
using OpenQA.Selenium;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class TransactionCodesPage
    {
        WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string dropdownTransactionCodeClass="XPath;//select[@name='transactionCodeClass']";
        public static string dropdownTransactionCodeGroup="XPath;//select[@name='transactionCodeGroup']";
        public static string buttonSearch="XPath;//input[@name='search']";
        public static string buttonAuthorize="XPath;//input[@name='authorize']";
        public virtual void EnterDetailsofTransactionCodes(string codeclass,string codegroup)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownTransactionCodeClass);
            appHandle.SelectDropdownSpecifiedValue(dropdownTransactionCodeClass,codeclass);
            appHandle.SelectDropdownSpecifiedValue(dropdownTransactionCodeGroup,codegroup);
            Report.Info("The details are entered in transaction code page","uio","True",appHandle);
        }

        public virtual void ClickOnSearchButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearch);
            appHandle.ClickObjectViaJavaScript(buttonSearch);
        }

        public virtual void SelectRadiobuttonBasedonTrancode(string codename)
        {
            string tblobj="XPath;//table[@class='ledgerScrollable dataTable']/tbody/descendant::td[contains(text(),'"+codename+"')]/preceding-sibling::td/input";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tblobj);
            appHandle.ClickObjectViaJavaScript(tblobj);
        }

        public virtual void ClickOnAuthorizebutton()
        {
            appHandle.ClickObjectViaJavaScript(buttonAuthorize);
        }
    
        public virtual void EnterDataByLabelNameInTransactionCodePage(string strLabelNamePipeDelimitedLabelValuecolonDelimited)
        {
            string tagname = "";
            strLabelNamePipeDelimitedLabelValuecolonDelimited = strLabelNamePipeDelimitedLabelValuecolonDelimited + ";";
            string[] arr = strLabelNamePipeDelimitedLabelValuecolonDelimited.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                if (arr[a].Contains("|"))
                {
                    string LabelName = arr[a].Split('|')[0].Trim();
                    string labelvalues = arr[a].Split('|')[1].Trim();
                    string[] values = labelvalues.Split(':');


                    string debitval = values[0].Trim(' ');
                    string creditval = values[1].Trim(' ');

                    string DebitRunTimeObj = "XPath;//*[contains(text(),'" + LabelName + "')]/following-sibling::td[1]/*";
                    string CreditRunTimeObj = "XPath;//*[contains(text(),'" + LabelName + "')]/following-sibling::td[2]/*";

                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DebitRunTimeObj))
                    {
                        try
                        {
                            IWebElement obj = (IWebElement)appHandle.FindElement(DebitRunTimeObj);
                            tagname = obj.TagName;
                            if (tagname.Trim().ToUpper().Equals("SELECT"))
                            {
                                if (!string.IsNullOrEmpty(debitval))
                                {
                                    appHandle.SelectDropdownSpecifiedValueByPartialText(DebitRunTimeObj, debitval);
                                }
                                if (!string.IsNullOrEmpty(creditval))
                                {
                                    appHandle.SelectDropdownSpecifiedValueByPartialText(CreditRunTimeObj, creditval);
                                }
                            }
                        }

                        catch (Exception e) { }
                    }
                }

            }
        }
    
    }

}