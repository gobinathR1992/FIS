using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class CalculationPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string linkRateDetermination="XPath;//a[contains(text(),'Rate Determination')]";
        public static string linkCapitalizedInterestProcessing="XPath;//a[contains(text(),'Capitalized Interest Processing')]";


        public virtual void ClickOnLink(string linkname)
        {
            
            string dynobjlink="XPath;//a[contains(text(),'"+linkname+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkRateDetermination);
            appHandle.ClickObjectViaJavaScript(dynobjlink);

        }


    }
}