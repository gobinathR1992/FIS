using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;
using GTS_OSAF;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class UserAddPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string txtAddUserUserID = "XPath;//input[@name='SCAU_UID']";
        private static string txtAddUserUserFullName = "Xpath;//input[@name='agentName']";
        private static string AddUserUsersCustomerNumberField = "Xpath;//input[@name='SCAU_ACN']";
        private static string AddUserEmailAddressField = "Xpath;//input[@name='USERSECUREDDATA_EMAILADDRESS']";
        private static string AvailableUserclassAddExplanatoryDisplayField = "Xpath;//select[@name='eligibleUserClasses']";
        private static string AvailableUserclassRemoveExplanatoryDisplayField = "Xpath;//select[@name='selectedUserClasses']";
        private static string txtPasswordMaintenancePassword = "Xpath;//input[@name='USERSECUREDDATA_ENCRYPTEDPWDOLD']";
        private static string txtPasswordMaintenanceConfirmPassword = "Xpath;//input[@name='passwordVerify']";
        private static string ReturnItemLimitsLedgerBalanceLimitField = "Xpath;//input[@name='SCAU_RETBALLIM']";
        private static string ReturnItemLimitsUncollectedBalanceLimitField = "Xpath;//input[@name='SCAU_RETCOLLIM']";
        private static string ReturnItemLimitsWaiveFeeLimitField = "Xpath;//input[@name='SCAU_RETFEELIM']";
        private static string txtOnlineTellersOverallCashMaximum = "Xpath;//input[@name='SCAU_OACMAX']";
        private static string txtOnlineTellersOverallCashMinimum = "XPath;//input[@name='SCAU_OACMIN']";
        private static string BatchTellersOverdraftRetriesField = "XPath;//input[@name='SCAU_ODPRET']";
        private static string BatchTellersNumberofRetriesField = "Xpath;//input[@name='SCAU_MARTY']";
        private static string DropdownAddUserUserclass = "Xpath;//select[@name='userClass']";
        private static string AddUserProxyUserTypeDropdown = "Xpath;//select[@name='SCAU_PROXY']";
        private static string DropdownAddUserBranchCode = "Xpath;//select[@name='SCAU_BRCD']";
        private static string DropdownAddUserUserLanguage = "Xpath;//select[@name='SCAU_LANG']";
        private static string PasswordMaintenanceManualRevokeReasonDropdown = "Xpath;//select[@name='USERSECUREDDATA_MANUALREVOKEDREASON']";
        private static string DropdownOnlineTellersTransactionSuspenceCredit = "Xpath;//select[@name='SCAU_TSCR']";
        private static string DropdownOnlineTellersTransactionSuspenceDebit = "XPath;//select[@name='SCAU_TSDR']";
        private static string DropdownOnlineTellersCashOverageGeneralLedger = "Xpath;//select[@name='SCAU_CSOVR']";
        private static string DropdownOnlineTellersCashShortageGeneralLedger = "Xpath;//select[@name='SCAU_CSSHRT']";
        private static string DropdownBatchTellersReconcilingOffsetCredit = "XPath;//select[@name='SCAU_ROCR']";
        private static string DropdownBatchTellersReconcilingOffsetDebit = "XPath;//select[@name='SCAU_RODR']";
        private static string DropdownBatchTellersOverdraftProtection = "XPath;//select[@name='SCAU_ODP']";
        private static string DropdownBatchTellersRejectHandling = "XPath;//select[@name='SCAU_BATREJ']";
        private static string DropdownBatchTellersReportTeller = "Xpath;//select[@name='SCAU_RTUID']";
        private static string DropdownBatchTellersTransactionSortOption = "XPath;//select[@name='SCAU_TRNSRT']";
        private static string AddUserPreventDirectSignonCheckbox = "Xpath;//input[@name='SCAU_NOSIGNON']";
        private static string AddUserNotifyPasswordExpirationbyEmailCheckbox = "Xpath;//input[@name='USERSECUREDDATA_NOTIFYPWDEXPIRYBYEMAIL']";
        private static string PasswordMaintenanceRevokeManuallyCheckbox = "Xpath;//input[@name='USERSECUREDDATA_ISMANUALLYREVOKED']";
        private static string ReturnItemLimitsBranchRestrictionCheckbox = "Xpath;//input[@name='SCAU_RETBRCD']";
        private static string OnlineTellersLimittoEMUCurrenciesCheckbox = "Xpath;//input[@name='SCAU_EMULIM']";
        private static string OnlineTellersPMingAllowedCheckbox = "Xpath;//input[@name='SCAU_TPM']";
        private static string BatchTellersSameDayRetryCheckbox = "Xpath;//input[@name='SCAU_SDRTY']";
        private static string TableheaderUserList = "XPath;//*[@class='dataTables_scrollHeadInner']/descendant::thead/tr";
        private static string TableBodyUserList = "XPath;//*[@class='dataTables_scrollBody']/table/tbody";
        private static string buttonAdd = "XPath;//input[@name='add']";
        private static string buttonSubmit = "XPath;//*[@name='requestAuthorization']";
        private static string dropdownOnlineTellersPostingEnvironment = "XPath;//*[@name='SCAU_CURRENV']";
        private static string txtAgentAuthorization = "XPath;//*[@name='agentAuthorization']";
        private static string buttonAgentAuthorizationSubmit = "XPath;//*[text()='Submit']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        public static string txtUserID = "XPath;//*[@name='userId']";
        private static string tableListOfUsers = "XPath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";
        private static string buttonList = "Xpath;//*[@value='List']";
        private static string buttonEdit = "Xpath;//*[@name='edit']";
        private static string tableContent = "Xpath;//table[@class='contentTable']/tbody";
        private static string dropdownBranchCode = "XPath;//select[@name='SCAU_BRCD']";
        public static string buttonSearchRestrictedCustomer="Xpath;//*[@name='SCAU_ACN']/following-sibling::*/descendant::img";
        public static string radiobtnSearchCustomerNumber ="Xpath;//*[@value='CIF_ACN']";
        public static string radiobtnSearchTaxid ="Xpath;//*[@value='CIF_TAXID']";
        public static string txtSearchFor ="Xpath;//*[@name='searchTerm']";
        public static string buttonSearch ="Xpath;//*[@value='Search']";
        public static string txtRestrictedCustomer ="Xpath;//*[@name='restrictedCustomers[0]']";

        private static string tableCustomerFound = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";

        public virtual bool VerifyIfUserIDExistsInUsersList(string UserID)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists("XPath;//*[text()='" + UserID + "']"))
            {
                Result = true;
            }
            return Result;
        }
        public virtual List<string> GetUsersList()
        {
            string tempHeaderName = "";
            string tempUser = "";
            int HeaderNumber = 0;
            List<string> UsersList = new List<string>();
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(TableheaderUserList);
            int headersCount = appHandle.GetRowCountfromList(TableheaderUserList);
            for (int i = 1; i <= headersCount; i++)
            {
                tempHeaderName = appHandle.GetObjectText(TableheaderUserList + "/th[" + i + "]");
                if (tempHeaderName.Equals(Data.Get("User")))
                {
                    HeaderNumber = i;
                    break;
                }
            }
            int UsersCount = appHandle.GetRowCountfromList(TableBodyUserList);
            for (int j = 1; j <= UsersCount; j++)
            {
                tempUser = appHandle.GetObjectText(TableBodyUserList + "/tr[" + j + "]/td[" + HeaderNumber + "]");
                UsersList.Add(tempUser);
            }
            return UsersList;
        }
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
                
            }
        }
        public virtual string GenerateRandomUserID()
        {

            string UserID = "";
            // appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999, 4) + "";
            // this.VerifyIfUserIDExistsInUsersList(UserID);
            for (int i = 1; i <= 10; i++)
            {
                UserID = appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999, 4) + "";
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
                {
                    if (!appHandle.IsObjectExists("XPath;//*[text()='" + UserID + "']"))
                    {
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
            }

            return UserID;
        }
        public virtual string EnterUserDetails(string Userid, string userclassname)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.Set_field_value(txtAddUserUserID, Userid);
            string UserName = StartupConfiguration.UserSettings.UserName;
            appHandle.Set_field_value(txtAddUserUserFullName, UserName);
            appHandle.SelectDropdownSpecifiedValue(DropdownAddUserUserclass, userclassname);
            appHandle.SelectDropdownSpecifiedValue(DropdownAddUserUserLanguage, (string)Data.Get("English"));
            appHandle.Set_field_value(txtPasswordMaintenancePassword, Data.Get("GLOBAL_WEBADMIN_USER_PASSWORD"));
            appHandle.Set_field_value(txtPasswordMaintenanceConfirmPassword, Data.Get("GLOBAL_WEBADMIN_USER_PASSWORD"));
            appHandle.SelectDropdownSpecifiedValue(DropdownOnlineTellersTransactionSuspenceCredit, (string)Data.Get("30100 - Teller Transaction Suspense Account"));
            appHandle.SelectDropdownSpecifiedValue(DropdownOnlineTellersTransactionSuspenceDebit, (string)Data.Get("30100 - Teller Transaction Suspense Account"));
            appHandle.SelectDropdownSpecifiedValue(dropdownOnlineTellersPostingEnvironment, (string)Data.Get("GLOBAL_SINGLE_OR_MULTICURRENCY_POSTING_ENVIORNMENT"));
            appHandle.SelectDropdownSpecifiedValue(DropdownOnlineTellersCashOverageGeneralLedger, (string)Data.Get("30100 - Teller Transaction Suspense Account"));
            appHandle.SelectDropdownSpecifiedValue(DropdownOnlineTellersCashShortageGeneralLedger, (string)Data.Get("30100 - Teller Transaction Suspense Account"));
            appHandle.Set_field_value(txtOnlineTellersOverallCashMaximum, Data.Get("GLOBAL_AMOUNT_REQUESTED_50K"));
            appHandle.Set_field_value(txtOnlineTellersOverallCashMinimum, Data.Get("GLOBAL_AMOUNT_100"));
            appHandle.SelectDropdownSpecifiedValue(DropdownBatchTellersReconcilingOffsetCredit, (string)Data.Get("30100 - Teller Transaction Suspense Account"));
            appHandle.SelectDropdownSpecifiedValue(DropdownBatchTellersReconcilingOffsetDebit, (string)Data.Get("30100 - Teller Transaction Suspense Account"));
            appHandle.SelectDropdownSpecifiedValue(DropdownBatchTellersOverdraftProtection, (string)Data.Get("Do Not Invoke Overdraft Protection"));
            appHandle.SelectDropdownSpecifiedValue(DropdownBatchTellersRejectHandling, (string)Data.Get("Reject failed batch transactions on an individual basis"));

            return Userid;
        }
        public virtual void ClickOnSubmitbutton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual void ClickOnAgentAuthorizationSubmitbutton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAgentAuthorizationSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonAgentAuthorizationSubmit);
            }
        }

        public virtual void EnterAgentAuthorization()
        {
            string pwd = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtAgentAuthorization))
            {
                appHandle.Set_field_value(txtAgentAuthorization, pwd);
            }
        }
        public virtual bool VerifyUserCreationSuccess(string userID)
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Equals("User " + userID + " has been created."))
            {
                Result = true;
            }

            return Result;
        }
        public virtual bool VerifyUserModificationSuccess(string userID)
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Equals("User " + userID + " has been modified."))
            {
                Result = true;
            }

            return Result;
        }
        public virtual void SelectUSerIDfromUserList(string UserID)
        {
            if(appHandle.GetTitle().Contains("User List"))
            {
            this.ClickOnListbutton();
            }
            appHandle.ClickObjectViaJavaScript("XPath;//*[text()='" + UserID + "']/preceding-sibling::td/input");
        }

        public virtual bool VerifyRecordExistsMessage()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Contains(Data.Get("GLOBAL_RECORD_ALREADY_EXIST_MESSAGE")))
            {
                Report.Info(appHandle.GetObjectText(MSGOBJ) + " is AvailableUserclassAddExplanatoryDisplayField", "recordexist", "true", appHandle);
                Result = true;
            }
            return Result;

        }
        public virtual void SelectBatchTellersReConcilingOffset()
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownBatchTellersReconcilingOffsetCredit, Data.Get("11110 - Cash"));
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownBatchTellersReconcilingOffsetDebit, Data.Get("11110 - Cash"));

        }
        public virtual void EnterPasswords()
        {
            appHandle.Set_field_value(txtPasswordMaintenancePassword, Data.Get("Test@321"));
            appHandle.Set_field_value(txtPasswordMaintenanceConfirmPassword, Data.Get("Test@321"));
        }
        public virtual void VerifyDataFromUserIDTable(string UserDetails)
        {
            appHandle.WaitUntilElementExists(tableListOfUsers);
            Profile7CommonLibrary.VerifyDataInTableByColumnValues(UserDetails);
        }


        public virtual void EnterUserID(string UserID)
        {
            appHandle.WaitUntilElementExists(txtUserID);
            appHandle.Set_field_value(txtUserID, UserID);
        }
        public virtual void ClickOnListbutton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonList))
            {
                appHandle.ClickObjectViaJavaScript(buttonList);
            }
        }
        public virtual void ClickOnListButton()
        {
            appHandle.WaitUntilElementExists(buttonList);
            appHandle.ClickObjectViaJavaScript(buttonList);
        }
        public virtual void SelectUserInUserList(string UniqueOrderRefValue)
        {
            appHandle.SelectRadioButtonInTable(tableListOfUsers, UniqueOrderRefValue);

        }


        public virtual bool ClickOnPMingAllowedCheckbox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(OnlineTellersPMingAllowedCheckbox))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(OnlineTellersPMingAllowedCheckbox)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(OnlineTellersPMingAllowedCheckbox);
                        if (appHandle.CheckCheckBoxChecked(OnlineTellersPMingAllowedCheckbox))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(OnlineTellersPMingAllowedCheckbox) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(OnlineTellersPMingAllowedCheckbox);
                        if (appHandle.CheckCheckBoxChecked(OnlineTellersPMingAllowedCheckbox) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }
        public virtual void ClickOnEditButton()
        {
            appHandle.WaitUntilElementExists(buttonEdit);
            appHandle.ClickObjectViaJavaScript(buttonEdit);
        }

        public virtual void SelectBranchCode()
        {
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBranchCode,Data.Get("GLOBAL_BRANCH_CODE"));
        }

        public virtual bool VerifyTableDataByLabelNameLabelValue(string sLabelNameLabelValuePipeDelimited)
        {
            bool Result = false;
            if (Profile7CommonLibrary.VerifyTableDataByLableNameLabelValue(tableContent, sLabelNameLabelValuePipeDelimited))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void ClickOnSearchRestrictedCustomerButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearchRestrictedCustomer))
            {
                appHandle.SwitchWindow(SwitchInto.DEFAULT);
                appHandle.ClickObjectViaJavaScript(buttonSearchRestrictedCustomer);
                appHandle.SwitchWindow(SwitchInto.WINDOW);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearch);
            }
        }
        public virtual void ClickOnSearchButton()
        {

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearch))
            {
                appHandle.ClickObjectViaJavaScript(buttonSearch);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableCustomerFound);
            }
        }

         public virtual string SearchCustomerByCustomerNumber(string CustomerNumber)
        {
            string temp = "";
            appHandle.Set_radiobutton(radiobtnSearchCustomerNumber);
            appHandle.Set_field_value(txtSearchFor, CustomerNumber);
            ClickOnSearchButton();

            Report.Info(CustomerNumber + " is displayed in Restricted Customer Search window.", "Customersearch", "true", appHandle);
            temp = appHandle.GetObjectText(tableCustomerFound + "/descendant::*[text()='" + CustomerNumber + "']");
            appHandle.ClickObjectViaJavaScript(tableCustomerFound + "/descendant::*[contains(text(),'" + CustomerNumber + "')]");
            appHandle.SwitchWindow(SwitchInto.DEFAULT);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearchRestrictedCustomer);
            appHandle.Set_field_value(txtRestrictedCustomer, temp);
            return CustomerNumber;
        }
        public virtual void UpdateBranchCode(string BranchCode)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownAddUserBranchCode);
            appHandle.SelectDropdownSpecifiedValue(DropdownAddUserBranchCode,BranchCode);

        }


    

    }
}
