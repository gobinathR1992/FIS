using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminAddProductOfferPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        //private static string ChannelDropdown = "XPath;.//Select[@name='UTBLOFFER_CHANID']";
        private static string ProductTypeDropDown = "XPath;.//select[@name='UTBLOFFER_TYPE']";
        private static string StartDateField = "XPath;.//input[@name='UTBLOFFER_SDATE']";
        private static string ExpirationDateField = "XPath;.//input[@name='UTBLOFFER_EDATE']";        
        private static string ProductDescriptionField = "XPath;//input[@name='UTBLOFFER_PRODDESC']";       
        private static string URLField = "XPath;//input[@name='UTBLOFFER_URL']";
        private static string DefaultValuesField = "XPath;//input[@name='UTBLOFFER_DVAL']";
        private static string CreationMethodCheckBox = "XPath;//input[@name='UTBLOFFER_CM']";
        private static string AllowDebitsforChannelCheckBox = "XPath;//input[@name='UTBLOFFER_DR']";
        private static string AllowCreditsforChannelCheckBox = "XPath;//input[@name='UTBLOFFER_CR']";
         private static string SubmitButton = "XPath;//input[@type='submit']";
         private static string ProductOfferSuccesMessage = "XPath;//div[@class='info'][contains(.,'Product has been added to the offer table')]";
                
        public virtual bool OfferProduct(string CopiedProductname,string CopyProductName,string startdate,string expirationdate)
        {
           appHandle.Wait_for_object(SubmitButton, 5);
           appHandle.SelectDropdownSpecifiedValue(ProductTypeDropDown,CopiedProductname);
           appHandle.Set_field_value(StartDateField,startdate);
           appHandle.Set_field_value(ExpirationDateField,expirationdate);
           appHandle.Set_field_value(ProductDescriptionField,CopyProductName);
           appHandle.Set_field_value(URLField,"#");
           appHandle.Set_field_value(DefaultValuesField,"1");
           appHandle.Select_CheckBox(CreationMethodCheckBox);
           appHandle.Select_CheckBox(AllowDebitsforChannelCheckBox);
           appHandle.Select_CheckBox(AllowDebitsforChannelCheckBox);
           appHandle.Select_CheckBox(AllowCreditsforChannelCheckBox);
           appHandle.ClickObject(SubmitButton);
           appHandle.SyncPage();
           if (appHandle.IsObjectExists(ProductOfferSuccesMessage))
           {
               return true;
           }
           return false;

          
        }
    }
}