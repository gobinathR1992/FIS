using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Collections.Generic;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class RateScheduleEffectiveDateRateAddPage
    {
        WebApplication appHandle;
        public static string tblRateScheduleEffectiveDate = "XPath;//div[contains(@id,'rate-schedule-forms-list')]";
        public static string txtRateScheduleEffectiveDate = "XPath;//input[contains(@name,'effectiveDate')]";
        public static string txtRateScheduleEffectiveDateMinimumBalance = "XPath;//input[contains(@name,'minimumBalance')]";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// This method is used to Get Elements Count With Same Xpath
        /// <param name = "Xpath"></param> 
        /// <returns>int</returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.GetElementsCountWithSameXpath("XPath;//input[contains(@name,'effectiveDate')]");
        /// </example> 
        public virtual int GetElementsCountWithSameXpath(string XPath)
        {
            int i = 0;
            bool bcheck = false;
            try
            {
                do
                {
                    i++;
                    string[] arrDetails = AppHandle.SplitString(XPath, ";");
                    string obj = "XPath;(" + arrDetails[1] + ")[" + i + "]";
                    bcheck = AppHandle.IsObjectExists(obj);
                } while (bcheck);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            int val = i - 1;
            return val;
        }

        /// <summary>
        /// This method is used to Enter Days for specified Row in RateScheduleEffectiveDateTable.
        /// <param name = "Days"></param> 
        /// <param name = "Row"></param> 
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.EnterDaysforSpecifiedRow("30",1);
        /// </example> 
        public void EnterDaysforSpecifiedRow(string sDays, int Row)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(tblRateScheduleEffectiveDate);
                AppHandle.WaitUntilElementClickable(tblRateScheduleEffectiveDate);
                string obj = "XPath;//input[@name='rateScheduleForms[" + Row + "].termTier']";
                if (AppHandle.IsObjectExists(obj))
                    AppHandle.Set_field_value(obj, sDays);
                else
                    Report.Fail("Specified field doesnot exists", "days", "True", appHandle);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to Enter Rates for specified Row in RateScheduleEffectiveDateTable.
        /// <param name = "Rate"></param> 
        /// <param name = "Row"></param> 
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.EnterDaysforSpecifiedRow("1.500",1);
        /// </example> 
        public void EnterRatesforSpecifiedRow(string sRate, int Row)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(tblRateScheduleEffectiveDate);
                AppHandle.WaitUntilElementClickable(tblRateScheduleEffectiveDate);
                string obj = "XPath;//input[@name='rateScheduleForms[" + Row + "].rate']";
                if (AppHandle.IsObjectExists(obj))
                    AppHandle.Set_field_value(obj, sRate);
                else
                    Report.Fail("Specified field doesnot exists", "days", "True", appHandle);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to Modify Rate for specified Day value in RateScheduleEffectiveDateTable.
        /// <param name = "Days"></param> 
        /// <param name = "Rate"></param> 
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.ModifyRateforSpecifiedDayValue("7","5.00000");
        /// </example> 
        public void ModifyRateforSpecifiedDayValue(string sDays, string Rate)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(tblRateScheduleEffectiveDate);
                AppHandle.WaitUntilElementClickable(tblRateScheduleEffectiveDate);
                string obj = "XPath;//input[contains(@name,'termTier')][@value='" + sDays + "']/parent::td/following-sibling::td/input";
                if (AppHandle.IsObjectExists(obj))
                    AppHandle.Set_field_value(obj, Rate);
                else
                    Report.Fail("Specified field doesnot exists", "days", "True", appHandle);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to Add a new Rate or to Modify Existing Rate for specified Day value in RateScheduleEffectiveDateTable.
        /// <param name="lstRateCredentials"></param>'
        /// lstAddIndxdetails.Add("7;3.75000");'--> ("Days;Rate")
        /// lstAddIndxdetails.Add("90;4.85000");' Pass like this if you need Modify a rate for a specified Day value
        /// lstAddIndxdetails.Add("345;5.85000;Add"); ' Pass like this if you need add a new rate in new row
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.AddandModifyRates(lstRateCredentials);
        /// </example> 
        public void AddandModifyRates(List<string> lstRateCredentials)
        {
            bool bcheck = false;
            int val = 0;
            try
            {
                for (int i = 0; i < lstRateCredentials.Count; i++)
                {
                    string[] arrDetails = new string[3];
                    arrDetails = AppHandle.SplitString(lstRateCredentials[i], ";"); //separator
                    if (arrDetails.Length > 2)
                    {
                        if ((arrDetails[2].ToUpper()).Equals("ADD"))
                        {
                            while (!bcheck)
                            {
                                val = GetElementsCountWithSameXpath("XPath;//input[contains(@name,'termTier')][@value!='']");
                                bcheck = true;
                            }
                            EnterDaysforSpecifiedRow(arrDetails[0], val);
                            EnterRatesforSpecifiedRow(arrDetails[1], val);
                            val++;
                        }
                    }
                    else
                        ModifyRateforSpecifiedDayValue(arrDetails[0], arrDetails[1]);
                }
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        public virtual void AddRateScheduleEffectiveDate(string Effectivedate, string MinBalance, string[] Ratecredentials)
        {
            try
            {
                AppHandle.Set_field_value(txtRateScheduleEffectiveDate, Effectivedate);
                AppHandle.Set_field_value(txtRateScheduleEffectiveDateMinimumBalance,MinBalance);
                string[] RatesArray = null;
                int rowCount = 0;
                for(int i=3; i<Ratecredentials.Length; i++)
                {
                    RatesArray  = Ratecredentials[i].Split(':');
                    EnterDaysforSpecifiedRow(RatesArray[0],rowCount);
                    EnterRatesforSpecifiedRow(RatesArray[1], rowCount);
                    rowCount = rowCount + 1;    
                }
                
                
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }
    }
}