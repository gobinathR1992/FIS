using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class DepositInterestCalculationPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string DropdownAccrualBase = "Xpath;//select[@name='PRODDFTD_IRCB']";
        public static string DropdownAccrualMethod = "XPath;//*[contains(text(),'Accrual Base')]/ancestor::tr[1]/following-sibling::tr[1]/descendant::*[contains(text(),'Accrual Method')]/ancestor::td[1]/following-sibling::*/descendant::select";
        public static string DropdownMinimumBalanceAccrueOption = "Xpath;//select[@name='PRODDFTD_MINOPT']";
        public static string drpDailyCalculationAccrualBase = "Xpath;//select[@name='PRODDFTD_IRCB']";
        public static string drpDailyCalculationAccrualMethod = "Xpath;//select[@name='PRODDFTD_IACM']";
        public static string drpDailyCalculationMinimumBalanceAccrualOption = "Xpath;//select[@name='PRODDFTD_MINOPT']";
        public static string drpDailyCalculationAvailableInterest = "Xpath;//select[@name='PRODDFTD_IAF']";
        private static string txtDailyCalculationMinimumBalancetoAccrueField = "Xpath;//input[@name='PRODDFTD_MINACR']";
        private static string txtDailyCalculationMaximumBalancetoAccrueField = "Xpath;//input[@name='PRODDFTD_MAXACR']";
        private static string txtStartDate = "XPath;//*[@name='UTBLOFFER_SDATE']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
private static string txtDailyCalculationCompundingFrequencyField = "Xpath;//input[@name='PRODDFTD_ICF']";
        private static string checkboxAllowNegativeInterestRate = "XPath;//*[contains(text(),'Allow Negative Interest Rate')]/ancestor::*[1]/following-sibling::*/descendant::input";
        private static string dropdownAccrualOptionMethod = "XPath;//*[contains(text(),'Accrual Option')]/ancestor::*[1]/following-sibling::*/descendant::select";
        private static string dropdownPostingOption = "XPath;//*[contains(text(),'Posting Option')]/ancestor::*[1]/following-sibling::*/descendant::select";
        private static string txtPostingFrequency = "XPath;//*[contains(text(),'Posting Frequency')]/ancestor::*[1]/following-sibling::*/descendant::input";
        private static string checkboxPostZeroNetInterest = "XPath;//*[contains(text(),'Post Zero Net Interest')]/ancestor::*[1]/following-sibling::*/descendant::input";
        private static string dropdownMinimumNegativeInterestChargeOption = "XPath;//*[contains(text(),'Minimum Negative Interest Charge Option')]/ancestor::*[1]/following-sibling::*/descendant::select";
        private static string txtMinimumNegativeInterestChargeAmount = "XPath;//*[contains(text(),'Minimum Negative Interest Charge Amount')]/ancestor::*[1]/following-sibling::*/descendant::input";
        private static string dropdownNegativeAccountBalanceOption = "Xpath;//*[contains(text(),'Negative Account Balance Option')]/ancestor::*[1]/following-sibling::*/descendant::select";
        private static string dropdownVATonInterestCalculationOption = "XPath;//*[contains(text(),'VAT on Interest Calculation Option')]/ancestor::*[1]/following-sibling::*/descendant::select";
        private static string chkboxFastRecalculation = "Xpath;//input[@name='PRODCTL_SAVDBDA']";
        public static string dropdownAccrualbase="XPath;//select[@name='PRODDFTD_IRCB']";
        public static string dropdownAccrualMethod="XPath;//select[@name='PRODDFTD_IACM']";
        public static string txtMinimumBalanceToAccrue="XPath;//input[@name='PRODDFTD_MINACR']";
        public static string txtCompoundingFrequency="XPath;//input[@name='PRODDFTD_ICF']";
        public static string checkboxFastRecalculation="XPath;//input[@name='PRODCTL_SAVDBDA']";
        public static string buttonSubmitnew="XPath;//input[@name='submit']";
        private static string checkboxAccPosIntOnNegBal = "Xpath;//input[@name='PRODDFTD_ISNEGRATEONNEGBALALLOWED']";
        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage, 5);
        }
        public virtual bool CheckPackageSuccessMessage(string inputMessage)
        {
            bool Result = false;
            if (appHandle.GetObjectText(sSuccessMessage).Equals(inputMessage))
            {
                Result = true;
            }
            else
            {
                Result = false;
            }
            return Result;
        }
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                appHandle.WaitUntilElementVisible(sdrpname);
                appHandle.WaitUntilElementClickable(sdrpname);
                appHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
        public virtual bool VerifyMessageDepositInterestCalculationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool ClickOnEditButton()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtStartDate))
                {
                    result = true;
                }
            }
            return result;
        }
        public virtual bool WaitUntilInterestPageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownAccrualBase))
            {
                result = true;
            }

            return result;

        }
        public virtual void EnterInterestAccrualOptions(string BaseOption, string MethodOption, string MinBal = "", string MinBalAccrualOption = "", string MaxBal = "", bool FastRecalculation = false, string AvailableInterest = "",string CompFreq="")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownAccrualBase))
            {
                if(BaseOption=="")
                {
                    appHandle.SelectDropdownSpecifiedValue(DropdownAccrualBase,BaseOption);
                }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccrualBase, BaseOption);
                }
                if (!string.IsNullOrEmpty(MethodOption))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccrualMethod, MethodOption);
                    
                }
                if (!string.IsNullOrEmpty(MinBal))
                {
                    appHandle.Set_field_value(txtDailyCalculationMinimumBalancetoAccrueField, MinBal);
                }
                if (!string.IsNullOrEmpty(MinBalAccrualOption))
                {
                    if(MinBalAccrualOption.ToLower().Contains("deselect"))
                    {
                        appHandle.SelectDropdownSpecifiedValueByIndex(drpDailyCalculationAvailableInterest, 0);
                    }
                    else
                    {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownMinimumBalanceAccrueOption, MinBalAccrualOption);
                    }
                }
                if (!string.IsNullOrEmpty(MaxBal))
                {
                    appHandle.Set_field_value(txtDailyCalculationMaximumBalancetoAccrueField, MaxBal);
                }
                if(FastRecalculation)
                {
                    appHandle.CheckCheckBoxChecked(chkboxFastRecalculation);
                   appHandle.ClickObjectViaJavaScript(chkboxFastRecalculation); 
                   
                }
                if(!string.IsNullOrEmpty(AvailableInterest))
                {
                    if(AvailableInterest.ToLower().Contains("deselect"))
                    {
                        appHandle.SelectDropdownSpecifiedValueByIndex(drpDailyCalculationAvailableInterest, 0);
                    }
                    else
                    {
                        appHandle.SelectDropdownSpecifiedValue(drpDailyCalculationAvailableInterest, AvailableInterest);
                    }
                }
                if (!string.IsNullOrEmpty(CompFreq))
                {
                    appHandle.Set_field_value(txtDailyCalculationCompundingFrequencyField, CompFreq);
                }


            }
        }
        public virtual void UpdateDailyCalculationAccrualBase(string aBase)
        {
            if (appHandle.WaitForObjectEnabled(drpDailyCalculationAccrualBase))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpDailyCalculationAccrualBase, aBase);
            }
        }
        public virtual void UpdateDailyCalculationAccrualMethod(string aMethod)
        {
            if (appHandle.WaitForObjectEnabled(drpDailyCalculationAccrualMethod))
            {
                appHandle.SelectDropdownSpecifiedValue(drpDailyCalculationAccrualMethod, aMethod);
            }
        }

        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX);
            }
        }
        public virtual bool VerifyMessageInInterestCalculationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void EnterDataInterestNegativeInterestNegativeInterestSection(bool AllowNegativeInterestRate = false, string AccrualOption = "", string PostingOption = "", string PostingFrequency = "", bool PostZeroNetInterest = false, string MinimumNegativeInterestChargeOption = "", string MinimumNegativeInterestChargeAmount = "", string NegativeAccountBalanceOption = "", string VATonInterestCalculationOption = "",bool AccPosIntOnNegBal = false)
        {
            if (AllowNegativeInterestRate)
            {
                if (appHandle.CheckCheckBoxChecked(checkboxAllowNegativeInterestRate)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxAllowNegativeInterestRate);
                }

            }
            else
            {
                if (appHandle.CheckCheckBoxChecked(checkboxAllowNegativeInterestRate)) { appHandle.ClickObjectViaJavaScript(checkboxAllowNegativeInterestRate); }
                else { }
            }
            if (!string.IsNullOrEmpty(AccrualOption)) { appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownAccrualOptionMethod, (string)AccrualOption); }
            if (!string.IsNullOrEmpty(PostingOption)) { appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownPostingOption, (string)PostingOption); }
            if (!string.IsNullOrEmpty(PostingFrequency)) { appHandle.Set_field_value(txtPostingFrequency, PostingFrequency); }
            if (PostZeroNetInterest)
            {
                if (appHandle.CheckCheckBoxChecked(checkboxPostZeroNetInterest)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxPostZeroNetInterest);
                }

            }
            else
            {
                if (appHandle.CheckCheckBoxChecked(checkboxPostZeroNetInterest)) { appHandle.ClickObjectViaJavaScript(checkboxPostZeroNetInterest); }
                else { }
            }
            if (!string.IsNullOrEmpty(MinimumNegativeInterestChargeOption))
            { 
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMinimumNegativeInterestChargeOption, (string)MinimumNegativeInterestChargeOption); 
            }
            if (!string.IsNullOrEmpty(MinimumNegativeInterestChargeAmount)) 
            { 
                appHandle.Set_field_value(txtMinimumNegativeInterestChargeAmount, MinimumNegativeInterestChargeAmount); 
            }
            if (!string.IsNullOrEmpty(NegativeAccountBalanceOption)) 
            { 
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownNegativeAccountBalanceOption, (string)NegativeAccountBalanceOption); 
            }
            if (!string.IsNullOrEmpty(VATonInterestCalculationOption)) 
            { 
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownVATonInterestCalculationOption, (string)VATonInterestCalculationOption); 
            }

            if (AccPosIntOnNegBal)
            {
                if (appHandle.CheckCheckBoxChecked(checkboxAccPosIntOnNegBal)) 
                { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxAccPosIntOnNegBal);
                }

            }
            else
            {
                if (appHandle.CheckCheckBoxChecked(checkboxAccPosIntOnNegBal)) 
                { 
                    appHandle.ClickObjectViaJavaScript(checkboxAccPosIntOnNegBal); 
                }
                else 
                { }
            }
            
        }


        public virtual bool WaitUntilNegativeInterestPageLoads()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void UpdateMinimumBalance(string MinBalAmt)
        {
            if (appHandle.WaitForObjectEnabled(txtDailyCalculationMinimumBalancetoAccrueField))
            {
                appHandle.Set_field_value(txtDailyCalculationMinimumBalancetoAccrueField, MinBalAmt);
            }
        }
        

        public virtual bool UpdateDataInInterestTabForTDSetup(string accrualbase,string accrualmethod)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccrualMethod);
            appHandle.SelectDropdownSpecifiedValue(DropdownAccrualBase,accrualbase);
            appHandle.SelectDropdownSpecifiedValue(dropdownAccrualMethod,accrualmethod);
            appHandle.Set_field_value(txtMinimumBalanceToAccrue,"0.00");
            appHandle.Set_field_value(txtCompoundingFrequency,"1MAE");
            if(!appHandle.CheckCheckBoxChecked(checkboxFastRecalculation))
            {
                appHandle.ClickObjectViaJavaScript(checkboxFastRecalculation);
            }
            appHandle.ClickObjectViaJavaScript(buttonSubmitnew);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAccrualMethod);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        
        }

        public virtual void SelectSpecifiedSublinkInInterestTab(string sublinkname)
        {
            string dynsublink="XPath;//td[@class='tabSub']/a[contains(text(),'"+sublinkname+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dynsublink);
            appHandle.ClickObjectViaJavaScript(dynsublink);

        }

        public virtual bool EnterValueInDailyCalculationCompoundingFrequencyField(string comfreqval,string accrualmethod="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCompoundingFrequency);
            appHandle.Set_field_value(txtCompoundingFrequency,comfreqval);
            if(!string.IsNullOrEmpty(accrualmethod))
            {
                appHandle.SelectDropdownSpecifiedValue(DropdownAccrualMethod,accrualmethod);
            }

            appHandle.ClickObjectViaJavaScript(buttonSubmitnew);            
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        
        }
    }
}