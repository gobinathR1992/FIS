using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.Util;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class TransactionCodeCopyPage
    {
        WebApplication appHandle;
        public static string txtTransactionCodeCopyTo = "XPath;//input[@name='toTransactionCode']";
        public static string drpTransactionCodeGroup = "XPath;//select[@name='transactionCodeGroup']";
        private static string tableProducts = "XPath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";

        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To enter value in Copy To Edit Feild in CopyTransactionCodePage.
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetEditValueinCoptToField(sfieldvalue)</example>
        public virtual void SetEditValueinCoptToField(string sfieldvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(txtTransactionCodeCopyTo);
                AppHandle.WaitUntilElementClickable(txtTransactionCodeCopyTo);
                AppHandle.Set_field_value(txtTransactionCodeCopyTo, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To check Transaction Code Exists Mgs in CopyTransactionCodePage.
        /// <param name = "Code"></param> 
        /// <returns>bool</returns>
        /// <example>bool val = CheckTransactionCodeExistsMgsinCopyTransactionCodePage("DPC")</example>
        public virtual bool CheckTransactionCodeExistsMgsinCopyTransactionCodePage(string Code)
        {
            bool bcheck = false;
            try
            {
                string obj = "XPath;//div[@class='error']//p[contains(text(),'"+Code+" already exists')]";
                AppHandle.Wait_For_Specified_Time(3);
                bcheck = AppHandle.IsObjectExists(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

        public virtual void selecttransactioncode(string transactioncode)
        {
            string runtimexpathfortransactioncode = tableProducts+"/descendant::td[text()='"+transactioncode+"']/ancestor::*[1]/td/input";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableProducts + "/descendant::td[1]/input"))
            {
                appHandle.ClickObjectViaJavaScript(runtimexpathfortransactioncode);
            }
            
        }
    }

}