using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs; 
using Profile7Automation.Libraries.Util;

 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class ProductServiceFeesPage
    { 
         WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
         private static string txtMaxDailyFeeForReturnItem="Xpath;//*[@name='PRODDFTD_RETMXFEE']";
         private static string txtMaxDailyFeeForPaidItem="Xpath;//*[@name='PRODDFTD_PDMXFEE']";
         private static string drpFeePlan ="Xpath;//*[@name='PRODDFTD_FEEPLN']";
         private static string txtFeeFrequency ="Xpath;//*[@name='PRODDFTD_SCFRE']";
         private static string drpFeeOption ="Xpath;//*[@name='PRODDFTD_FEEOPT']";
         private static string buttonSubmit = "XPath;//*[@Value='Submit']"; 
         private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
         private static string drpServiceChargeCode="Xpath;//*[@name='PRODDFTD_SCC']";
         private static string drpTaxPlanGroup ="Xpath;//*[@name='PRODDFTD_CTFGRP']";


         public virtual void UpdateDailyFee(string FeeforReturn,string FeeforPaid,string FeeFrequency,string FeeOption,string ServiceFeeCode,string TaxPlanGroup="",string FeePlan="")
         {
             appHandle.WaitUntilElementExists(txtMaxDailyFeeForReturnItem);
             appHandle.Set_field_value(txtMaxDailyFeeForReturnItem,FeeforReturn);
             appHandle.Set_field_value(txtMaxDailyFeeForPaidItem,FeeforPaid);
             appHandle.SelectDropdownSpecifiedValueByPartialText(drpFeePlan,FeePlan);
             appHandle.Set_field_value(txtFeeFrequency,FeeFrequency);
             appHandle.SelectDropdownSpecifiedValueByPartialText(drpFeeOption,FeeOption);
             appHandle.SelectDropdownSpecifiedValueByPartialText(drpServiceChargeCode,ServiceFeeCode);
             appHandle.SelectDropdownSpecifiedValueByPartialText(drpTaxPlanGroup,TaxPlanGroup);

         }

         public virtual void Clickonsubmit()
         {
             if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }

         }
         public virtual bool VerifyMessageInServiceFeePage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
    }
}