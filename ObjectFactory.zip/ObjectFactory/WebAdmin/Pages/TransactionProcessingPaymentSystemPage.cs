using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs; 
using Profile7Automation.Libraries.Util;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using GTS_OSAF.HelperLibs.DataAdapter;


 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class TransactionProcessingPaymentSystemPage
    { 
        WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtMinmumDaysRequiredForPaymentOrder = "Xpath;//*[@name='CUVAR_MINPAY']";
        public static string txtMinimunDaysOriginateCollectionOrder = "Xpath;//*[@name='CUVAR_MINCOL']";
        public static string txtMaximumDaysFutureDatePaymentOrder ="Xpath;//*[@name='CUVAR_MAXPAY']";
        public static string checkboxDebitAuthorization ="Xpath;//*[@name='CUVAR_DEBAUT']";
        public static string buttonSubmit = "Xpath;//*[@name='submit']";
        public static string buttonCancel = "Xpath;//*[@name='cancel']";
        public static string MSGOBJ = "Xpath;//div[@class='msg-box']/descendant::p[1]";
        private static string txtMaxNumberofDisbursment = "Xpath;//input[@name ='PRODDFTL_MAXDRCT']";

        public virtual void UpdateMinimumDaysReqForPaymentOrder(string Order)
        {
            AppHandle.WaitUntilElementExists(txtMinmumDaysRequiredForPaymentOrder);
            AppHandle.Set_field_value(txtMinmumDaysRequiredForPaymentOrder,Order);
            
        }         
        public virtual void ClickOnSubmit()
        {
            AppHandle.WaitUntilElementExists(buttonSubmit);
            AppHandle.ClickObjectViaJavaScript(buttonSubmit);
        }

        public virtual bool VerifyMessageInWebAdminPaymentSystemPage()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (AppHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_INFORMATION_UPDATED")))                
                {

                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool ClickOnDebitAuthorizationCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxDebitAuthorization))
            {
                if (ONorOFF)
                {
                    if (AppHandle.CheckCheckBoxChecked(checkboxDebitAuthorization)) { Result = true; }
                    else
                    {
                        AppHandle.ClickObjectViaJavaScript(checkboxDebitAuthorization);
                        if (AppHandle.CheckCheckBoxChecked(checkboxDebitAuthorization))
                        { Result = true; }

                    }
                }
                else
                {
                    if (AppHandle.CheckCheckBoxChecked(checkboxDebitAuthorization) == false) { Result = true; }
                    else
                    {
                        AppHandle.ClickObjectViaJavaScript(checkboxDebitAuthorization);
                        if (AppHandle.CheckCheckBoxChecked(checkboxDebitAuthorization) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }
        public virtual void EnterDisbursmentProcessingOption()
        {
            AppHandle.Set_field_value(txtMaxNumberofDisbursment, Data.Get("GLOBAL_VALUE_1"));
        }
        public virtual void UpdateMinimumDaysOriginateCollectionOrder(string OrderDays)
        {
            AppHandle.WaitUntilElementExists(txtMinimunDaysOriginateCollectionOrder);
            AppHandle.Set_field_value(txtMinimunDaysOriginateCollectionOrder,OrderDays);
            
        }
    }
}