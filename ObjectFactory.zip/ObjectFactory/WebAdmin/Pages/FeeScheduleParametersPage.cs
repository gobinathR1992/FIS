using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class FeeScheduleParametersPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string tableTieredList = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";
        public static string btnEdit = "Xpath;//input[@name='edit']";
        public static string tblFeeScheduleParameters = "Xpath;//table[@id='fee-schedule-list']";
        public static string txtFeeScheduleMSG = "Xpath;//h1[contains(text(),'Fee Schedule Parameters')]";
        private static string txtFeeSchedule = "XPath;//*[contains(text(),'Fee Schedule:')]/ancestor::*[1]/following-sibling::*/descendant::input";
        private static string txtDesc = "XPath;//*[contains(text(),'Description:')]/ancestor::*[1]/following-sibling::*/descendant::input";
        private static string txtEffectiveDate = "XPath;//*[contains(text(),'Effective Date:')]/ancestor::*[1]/following-sibling::*/descendant::input[1]";
        private static string dropdownTypeOfSchedule = "XPath;//*[contains(text(),'Type of Schedule:')]/ancestor::*[1]/following-sibling::*/descendant::select";
        private static string txtCustomerProgram = "XPath;//*[contains(text(),'Custom Program:')]/ancestor::*[1]/following-sibling::*/descendant::input";
        private static string dropdownTypeOfTier = "XPath;//*[contains(text(),'Type of Tier:')]/ancestor::*[1]/following-sibling::*/descendant::select";

        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonAdd = "Xpath;//*[@value='Add']";
        private static string buttonEdit = "Xpath;//*[@value='Edit']";
        private static string buttonCopy = "Xpath;//*[@value='Copy']";
        private static string buttonDelete = "Xpath;//*[@value='Delete']";
        private static string tableFeeScheduleParameter = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";
        private static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        public static string ApplicationDate = new FeeScheduleParametersPage().GetApplicationDate();
        public virtual string GetApplicationDate()
        {
            string result = "";
            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }

        public virtual bool ConfirmFeeScheduleParametersPage()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirmed the Fee Schedule Parameters");
            bool blnSuccess = false;
            if (appHandle.CheckObjectExist(txtFeeScheduleMSG))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            }
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual bool VerifyFeeScheduleExists()
        {
            bool result = false;

            if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("Record already exists in table")))
            {
                result = true;
            }
            return result;
        }
        public virtual string EnterServiceFeeScheduleDetails(string TypeOfSchedule, string TypeOfTier, string TierValuesPipeDemilited, string Description = "", string FeeSchedule = "", string EffectiveDate = "", string CustomProgram = "")
        {
            if (string.IsNullOrEmpty(FeeSchedule))
            {
                FeeSchedule = (string)appHandle.CreateRamdomData(FieldType.ALPHABETS, 11111, 99999, 5);
                FeeSchedule=FeeSchedule.ToUpper();
            }
            if (string.IsNullOrEmpty(Description))
            {
                Description = FeeSchedule;
            }
            if (string.IsNullOrEmpty(EffectiveDate))
            {
                EffectiveDate = ApplicationDate;
            }
            if (string.IsNullOrEmpty(CustomProgram))
            { }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.Set_field_value(txtFeeSchedule, FeeSchedule);
                appHandle.Set_field_value(txtDesc, Description);
                appHandle.Set_field_value(txtEffectiveDate, EffectiveDate);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownTypeOfSchedule, TypeOfSchedule);
                appHandle.Set_field_value(txtCustomerProgram, CustomProgram);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownTypeOfTier, TypeOfTier);
                EnterDataInTieredList(TierValuesPipeDemilited);
            }
            return FeeSchedule;
        }

        public virtual bool EnterDataInTieredList(string TierValuesPipeDemilited)
        {
            string temp = "";
            bool DataEntered = false;
            int numberofDataToEnterPerRow = 0;
            int RecordCount = 0;
            TierValuesPipeDemilited = TierValuesPipeDemilited + ";";
            string[] arr = TierValuesPipeDemilited.Split(';');
            int rowscount = appHandle.GetRowCountfromList(tableTieredList);
            for (int c = 0; c < arr.Length - 1; c++)
            {
                for (int a = 1; a <= rowscount; a++)
                {
                    if (arr[c].Contains("|"))
                    {
                        numberofDataToEnterPerRow = arr[c].Split('|').Length;
                    }
                    else { numberofDataToEnterPerRow = 1; }

                    for (int b = 1; b <= numberofDataToEnterPerRow; b++)
                    {
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableTieredList + "/tr[" + a + "]/td[" + (b) + "]/descendant::input"))
                        {
                            appHandle.Set_field_value(tableTieredList + "/tr[" + a + "]/td[" + (b) + "]/descendant::input", arr[c].Split('|')[b - 1]);

                            temp = temp + " , " + this.GetColumnHeaderNameByColumnNumberInIndexList(b) + " in level : " + a + " is entered as :" + arr[c].Split('|')[b - 1];
                            RecordCount++;
                            if (RecordCount == arr[c].Split('|').Length)
                            {
                                DataEntered = true;
                                RecordCount = 0;
                                break;
                            }
                        }
                        else
                        {
                            DataEntered = false;
                        }
                    }
                    c++;
                    if (c == arr.Length - 1)
                    {
                        if (DataEntered)
                        {
                            temp = temp.Substring(3, temp.Length - 3).Trim();
                            Report.Info(temp, "tieredratesenter", "True", appHandle);
                        }
                        break;
                    }
                    else { continue; }

                }
                if (c == arr.Length - 1) { break; } else { continue; }
            }
            return DataEntered;
        }
        public virtual string GetColumnHeaderNameByColumnNumberInIndexList(int ColNum)
        {
            string headername = "";
            string runtimeObj = tableTieredList + "/ancestor::*[@class='dataTables_scrollBody']/preceding-sibling::div/descendant::thead/tr[1]/th[" + ColNum + "]";
            headername = appHandle.GetObjectText(runtimeObj).Trim();
            return headername;
        }
        public virtual bool VerifyFeeScheduleInList(string FeeSchedule)
        {
            bool Result = false;
           try
           {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableFeeScheduleParameter);
            string temp = appHandle.GetObjectText(tableFeeScheduleParameter);
            string[] arr = temp.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            if (Array.Find(arr, element => element.Trim().StartsWith(FeeSchedule)).Contains(FeeSchedule.Trim()))
            {
                Result = true;
            }
           }
           catch(Exception e){};
            return Result;
        }
       
public virtual void EnterFeeScheduleOnFeeExistsMessage(string FeeSchedule)
{
     
      appHandle.Set_field_value(txtFeeSchedule, FeeSchedule);
}
    }
}


