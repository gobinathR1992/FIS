using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Collections.Generic;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class MaximumUserClassLimitsPage
    {
        WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string buttonAdd="XPath;//input[@value='Add']";
        public static string buttonEdit="XPath;//input[@value='Edit']";
        public static string buttonDelete="XPath;//input[@value='Delete']";

        public static string dropdwonCurrencyCode="XPath;//select[@name='content:service:CRCD']";
        public static string dropdownUserClass="XPath;//select[@name='content:service:UCLS']";
        public static string txtDebitAmount="XPath;//input[@name='content:service:MAXDR']";

        public static string txtCreditAmount="XPath;//input[@name='content:service:MAXCR']";
        public static string buttonSubmit="XPath;//input[@name='content:service:_idJsp38']";
        
        public static string buttonSubmitfortableUTBLMXUCLS2="XPath;//input[@name='content:service:_idJsp47']";
        public static string dropdownTransactionGroup="XPath;//select[@name='content:service:GRP']";
        
        
        
        
        
        
        public virtual bool EnterRecordsForTableUTBLMXUCLS1(string columnvaluesseperatedbydelimsemicolon)
        {                       
            
            string currencycode=columnvaluesseperatedbydelimsemicolon.Split(';')[0];
            string userclass=columnvaluesseperatedbydelimsemicolon.Split(';')[1];
            string maxdebitamt=columnvaluesseperatedbydelimsemicolon.Split(';')[2];
            string maxcreditamt=columnvaluesseperatedbydelimsemicolon.Split(';')[3];
            string dynamicobj="XPath;//span[contains(text(),'"+userclass.Split('-')[0].Trim()+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.SelectDropdownSpecifiedValue(dropdwonCurrencyCode,currencycode);
            appHandle.SelectDropdownSpecifiedValue(dropdownUserClass,userclass);
            appHandle.Set_field_value(txtDebitAmount,maxdebitamt);
            appHandle.Set_field_value(txtCreditAmount,maxcreditamt);
            Report.Info("The details are entered successfully","detpass","True",appHandle);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.IsObjectExists(dynamicobj);

        }

        public virtual bool EnterRecordsForTableUTBLMXUCLS2(string columnvaluesseperatedbydelimsemicolon)
        {                       
            
            string currencycode=columnvaluesseperatedbydelimsemicolon.Split(';')[0];
            string userclass=columnvaluesseperatedbydelimsemicolon.Split(';')[1];
            string transactiongroup=columnvaluesseperatedbydelimsemicolon.Split(';')[2];
            string maxdebitamt=columnvaluesseperatedbydelimsemicolon.Split(';')[3];
            string maxcreditamt=columnvaluesseperatedbydelimsemicolon.Split(';')[4];
            string dynamicobj="XPath;//span[contains(text(),'"+userclass.Split('-')[0].Trim()+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdwonCurrencyCode);
            appHandle.SelectDropdownSpecifiedValue(dropdwonCurrencyCode,currencycode);
            appHandle.SelectDropdownSpecifiedValue(dropdownUserClass,userclass);
            appHandle.SelectDropdownSpecifiedValue(dropdownTransactionGroup,transactiongroup);
            appHandle.Set_field_value(txtDebitAmount,maxdebitamt);
            appHandle.Set_field_value(txtCreditAmount,maxcreditamt);
            Report.Info("The details are entered successfully","detpass","True",appHandle);
            appHandle.ClickObjectViaJavaScript(buttonSubmitfortableUTBLMXUCLS2);
            return appHandle.IsObjectExists(dynamicobj);

        }
        
    }

}