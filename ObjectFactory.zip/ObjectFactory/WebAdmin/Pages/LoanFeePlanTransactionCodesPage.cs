using System;
using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class LoanFeePlanTransactionCodesPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpCommercialLoanGroupFeeAssessment = "name;commercialLnFeeDRTranCode";
        public static string drpCommercialLoanGroupIncreaseAdjustment = "name;feeIncrAdjTranCodeCOM";
        public static string drpCommercialLoanGroupDecreaseAdjustment = "name;commercialLnFeeCRTranCode";
        public static string drpMortgageLoanGroupFeeAssessment = "name;mtgLnFeeDRTranCode";
        public static string drpMortgageLoanGroupIncreaseAdjustment = "name;feeIncrAdjTranCodeMTG";
        public static string drpMortgageLoanGroupDecreaseAdjustment = "name;mtgLnFeeCRTranCode";
        public static string drpConsumerLoanGroupFeeAssessment = "name;consumerLnFeeDRTranCode";
        public static string drpConsumerLoanGroupIncreaseAdjustment = "name;feeIncrAdjTranCodeLN";
        public static string drpConsumerLoanGroupDecreaseAdjustment = "name;consumerLnFeeCRTranCode";
        public static string drpCreditBalanceLoanGroupFeeAssessment = "name;cRBalLnFeeIncrTC";
        public static string drpCreditBalanceLoanGroupIncreaseAdjustment = "name;feeIncrAdjTranCodeCBL";
        public static string drpCreditBalanceLoanGroupDecreaseAdjustment = "name;cRBalLnFeeDecrTranCode";
        public static string drpRCLoanGroupFeeAssessment = "name;revolvingLnFeeDRTranCode";
        public static string drpRCLoanGroupIncreaseAdjustment ="name;feeIncrAdjTranCodeRC";
        public static string drpRCLoanGroupDecreaseAdjustment = "name;revolvingLnFeeCRTranCode";
        public static string drpDemandLoanGroupFeeAssessment = "name;demandLnFeeDRTranCode";
        public static string drpDemandLoanGroupIncreaseAdjustment = "name;feeIncrAdjTranCodeDM";
        public static string drpDemandLoanGroupDecreaseAdjustment = "name;demandLnFeeCRTranCode";
        public static string drpFeeReceivableGLAccount = "name;gLFeeReceivableAcct";
        public static string drpFeeIncomeGLAccount = "name;gLFeeIncomeAcct";
        private static string buttonAdd ="Xpath;//*[@value='Add']";
        private static string  txtLoanFeesTransCodeGrp = "Xpath;//input[@name ='trnGroup']";
        private static string txtDescription = "Xpath;//input[@name ='description']";
        public static string buttonSubmit="XPath;//input[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonEdit = "Xpath;//*[@value = 'Edit']";
        private static string buttonDelete = "Xpath;//*[@value = 'Delete']";
        private static string txtloanfeegrp = "Xpath;//input[@name = 'feeGroup']";
        private static string PageCellObj = "XPath;//*[@class='contentTable']/descendant::tr/following-sibling::tr/descendant::a/ancestor::td[1]";
        private static string txtavailabledate = "XPath;//input[@name='dateAvailable']";
        private static string startdate = "Xpath;//input[@name='startDate']";
        private static string enddate = "Xpath;//input[@name='endDate']";

        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
                
            }
        }

        public virtual string EnterRecordsForTableUTBLTRNGRPLT(string Description,string columnvaluesseperatedbydelimsemicolon)
        {
            ClickOnAddButton();
            string LoanFeesTransCodeGrp = "LFTCG"+appHandle.CreateRamdomData(FieldType.NUMERIC, 100, 999, 3) + "";
            appHandle.Set_field_value(txtLoanFeesTransCodeGrp,LoanFeesTransCodeGrp);
            appHandle.Set_field_value(txtDescription,Description);
            columnvaluesseperatedbydelimsemicolon = columnvaluesseperatedbydelimsemicolon + ";";
            string[] arr1 = columnvaluesseperatedbydelimsemicolon.Split(';');
                                   
            for (int i=0;i<=arr1.Length-1;i++)
            {
                string transactioncode = "Xpath;//select[@name = 'trnCode["+i+"]']";
                appHandle.SelectDropdownSpecifiedValue(transactioncode,arr1[i]);
            }
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            //return appHandle.IsObjectExists(LoanFeesTransCodeGrp);
            return LoanFeesTransCodeGrp;              


        }
         public virtual bool VerifyMessageInLoanFeePage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;  
        }

        public virtual void VerifyValueIsSelectInTransactionFeeTable(string code)
        {
            int TotReportPageCount = GetNumberOfPagesInTable();
            if(TotReportPageCount ==0)
            {
                SelectTranCodeFromTable(code);
            }
            else
            {
                for (int b = 1; b <= TotReportPageCount; b++)
                {
                    ClickOnPageLinkByPageNumber(b);                 
                    string temp=appHandle.GetObjectText("XPath;//*[@class='contentTable']/tbody/descendant::tbody");
                    string[]arr=temp.Split(new string[]{"\r\n"},StringSplitOptions.None);
                    List<string> tabsList=new List<string>();

                    for(int a=0;a<arr.Length-1;a++)
                    {
                        tabsList.Add(arr[a].Trim());
                        if(arr[a].Contains(code))
                        {
                            SelectTranCodeFromTable(code);
                        }
                   
                    }
                    break;
                }
            }   
                    
        }

        public virtual void SelectTranCodeFromTable(string trancode)
        {
            
            string runTimeObj = "XPath;//*[@type='radio'][@value='" + trancode + "']";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runTimeObj))
            {
                appHandle.ClickObjectViaJavaScript(runTimeObj);
            }
        }
        public virtual void ClickOnEditButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
                
            }
        }
        public virtual void ModifyRecordsForTableUTBLTRNGRPLT(string columnvaluesseperatedbydelimsemicolon)
        {
            columnvaluesseperatedbydelimsemicolon = columnvaluesseperatedbydelimsemicolon + ";";
            string[] arr1 = columnvaluesseperatedbydelimsemicolon.Split(';');
                                   
            for (int i=0;i<=arr1.Length-1;i++)
            {
                string transactioncode = "Xpath;//select[@name = 'trnCode["+i+"]']";
                appHandle.SelectDropdownSpecifiedValue(transactioncode,arr1[i]);
            }
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }
         public virtual void ClickOnDeleteButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonDelete))
            {
                appHandle.ClickObjectViaJavaScript(buttonDelete);
                
            }
        }
        public virtual string EnterRecordsForTableUTBLLNFEEGRP(string columnvaluesseperatedbydelimsemicolon)
        {
            ClickOnAddButton();
            string LoanFeesplan =  "LFG"+appHandle.CreateRamdomData(FieldType.NUMERIC, 100, 999, 3) + "";
            appHandle.Set_field_value(txtloanfeegrp,LoanFeesplan);
            appHandle.Set_field_value(txtDescription,LoanFeesplan);
            columnvaluesseperatedbydelimsemicolon = columnvaluesseperatedbydelimsemicolon + ";";
            string[] arr1 = columnvaluesseperatedbydelimsemicolon.Split(';');
                                   
            for (int i=0;i<=arr1.Length-1;i++)
            {
                string feeplan = "Xpath;//select[@name = 'feeTyp["+i+"]']";
                appHandle.SelectDropdownSpecifiedValue(feeplan,arr1[i]);
            }
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            //return appHandle.IsObjectExists(LoanFeesTransCodeGrp);
            return LoanFeesplan;              


        }
        public virtual void ModifyRecordsForTableUTBLLNFEEGRP(string columnvaluesseperatedbydelimsemicolon)
        {
            string LoanFeesplan =  "LFG"+appHandle.CreateRamdomData(FieldType.NUMERIC, 100, 999, 3) + "";
            columnvaluesseperatedbydelimsemicolon = columnvaluesseperatedbydelimsemicolon + ";";
            string[] arr1 = columnvaluesseperatedbydelimsemicolon.Split(';');
            appHandle.Set_field_value(txtDescription,LoanFeesplan);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }
       public virtual string GetPageHeader()
        {
            string pageheader = appHandle.GetObjectText("Xpath;//H1[contains(text(),'')]");
            return pageheader;
        }

        public virtual int GetNumberOfPagesInTable()
        {
            int PageCount = 0;
            string temp = appHandle.GetObjectText(PageCellObj);
            if(temp =="")
            {
                PageCount = 0;
            }
            else{
            temp = temp.Trim();
            string max = temp.Split(' ')[temp.Split(' ').Length - 1];
            if (max.Contains("."))
            {
                max = max.Replace(".", string.Empty);
            }
            PageCount = Convert.ToInt32(max);
            }
            return PageCount;
        }

        public virtual void ClickOnPageLinkByPageNumber(int pageNumber)
        {
            string pagenumber=pageNumber+"";
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(PageCellObj))
            {
                appHandle.ClickObjectViaJavaScript(PageCellObj+"/descendant::*[contains(text(),'"+pagenumber+"')]");
            }
        }
        public virtual void AddDetailsForEscrowType(string columnvaluesseperatedbydelimsemicolon,string date)
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(columnvaluesseperatedbydelimsemicolon);
            appHandle.Set_field_value(txtavailabledate,date);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }
        public virtual void AddDetailsForEscrowPayeeDefinition(string columnvaluesseperatedbydelimsemicolon)
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(columnvaluesseperatedbydelimsemicolon);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }


        public virtual void AddDetailsForLNPAS2(string columnvaluesseperatedbydelimsemicolon,string sdate,string edate="")
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(columnvaluesseperatedbydelimsemicolon);
            appHandle.Set_field_value(startdate,sdate);
            if(!string.IsNullOrEmpty(edate))
            {
                appHandle.Set_field_value(enddate,edate);
            }
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }

         public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                
            }
        }
      
     }
}