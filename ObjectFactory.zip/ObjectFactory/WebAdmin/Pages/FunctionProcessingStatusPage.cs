using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class FunctionProcessingStatusPage
        {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string tableTieredList = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";
        private static string DropdownFunction = "XPath;//select[@name = 'functionName']";
        private static string buttonSubmit = "XPath;//input[@value='Submit']";
        public static string ExtractTable="Xpath;.//*[contains(@class,'dataTables_scroll')]";
        private static string btnHistoryPopupClose = "XPath;//span[text()='close']";
       
        public virtual void ClickOnTableExtractLink(string LinkName)
        {
        appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        appHandle.SelectLinkInLabel(ExtractTable,LinkName);
          
        }

         public virtual string GetLabelValue(string labelname)
        {
            string runtimexpathforlabelvalue = "Xpath;//*[contains(@class,'ui-dialog ui-widget')]/descendant::*/*[@class='contentTable']/tbody/descendant::label[contains(text(),'"+labelname+"')]/following::td[1]";
            appHandle.Wait_For_Specified_Time(2);
            appHandle.ClickObjectViaJavaScript(runtimexpathforlabelvalue);
            appHandle.Wait_For_Specified_Time(2);
            string labelvalue = appHandle.GetLabelText(runtimexpathforlabelvalue);
            return labelvalue;
        }
        public virtual string SearchforFunction(string function,string LinkName,string labelName)
        {
            string time = "";
            appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownFunction,function);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            Report.Info(function+"generated.",true);
            ClickOnTableExtractLink(LinkName);
            appHandle.Wait_For_Specified_Time(5);
            time = GetLabelValue(labelName);
            return time;
        }
         public virtual void ClosePopup()
        {
            appHandle.ScrollToObject(btnHistoryPopupClose);
            appHandle.ClickObjectViaJavaScript(btnHistoryPopupClose);
        
        }    
    }
}