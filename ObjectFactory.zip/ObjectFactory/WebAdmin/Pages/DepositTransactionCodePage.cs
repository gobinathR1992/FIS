using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class DepositTransactionCodePage
    { 
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string dropdownNegativeAccruedInterestDebit = "Xpath;//select[@name = 'PRODCTL_DRADNA']";
        public static string dropdownNegativeAccruedInterestCredit = "Xpath;//select[@name = 'PRODCTL_CRADNA']";
        public static string dropdownUnauthorizedAccruedInterestDebit = "Xpath;//select[@name = 'PRODCTL_DRNEGACRUA']";
        public static string dropdownUnauthorizedAccruedInterestCredit = "Xpath;//select[@name = 'PRODCTL_CRNEGACRUA']";

        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string AdjustmentsResidualInterestDebitDropdown = "Xpath;//select[@name='PRODCTL_DRADRES']";
        private static string AdjustmentsResidualInterestCreditDropdown = "Xpath;//select[@name='PRODCTL_CRADRES']";
        private static string AdjustmentsNegativeAIOnPositiveBalanceDebitDropdown = "Xpath;//select[@name='PRODCTL_DRADJNEGINTPOSBAL']";
        private static string AdjustmentsNegativeAIOnPositiveBalanceCreditDropdown = "Xpath;//select[@name='PRODCTL_CRADJNEGINTPOSBAL']";
        private static string AdjustmentsPositiveAIOnNegativeBalanceDebitDropdown = "Xpath;//select[@name='PRODCTL_DRADJPOSINTNEGBAL']";
        private static string AdjustmentsPositiveAIOnNegativeBalanceCreditDropdown = "Xpath;//select[@name='PRODCTL_CRADJPOSINTNEGBAL']";
        private static string AdjustmentsInterestAvailableNotCreditedDropdown = "Xpath;//select[@name='PRODCTL_DRIANC']";
        public static string dropdownGeneralPurposeDebitDebit = "Xpath;//select[@name = 'PRODCTL_DRTRGP']";
        public static string dropdownunInsurePrincipal = "Xpath;//select[@name = 'PRODCTL_DRADJUNINSPRINCIPAL']";
        public static string dropdownBackOfficeUninsuredPositiveAccruedInterestDebit = "Xpath;//select[@name = 'PRODCTL_DRADJUNINSPOSACR']";
        public static string dropdownBackOfficeUninsuredPositiveAccruedInterestCredit = "Xpath;//select[@name = 'PRODCTL_CRADJUNINSPOSACR']";
        public static string dropdownBackOfficeUninsuredNegAccIntonPosBalCredit = "Xpath;//select[@name = 'PRODCTL_CRADJUNINSNEGACRNEGINT']";
        public static string dropdownBackOfficeUninsuredNegAccIntCredit = "Xpath;//select[@name = 'PRODCTL_CRADJUNINSNEGACR']";
        public static string dropdownBackOfficeUninsuredPosIntAccOnNegBalCredit = "Xpath;//select[@name = 'PRODCTL_DRADJUNINSPOSACRNEGINT']";
        public static string dropdownBackOfficeUninsuredUncollIntCredit = "Xpath;//select[@name = 'PRODCTL_CRADJUNINSUNCACR']";
        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }

          public virtual bool VerifyMessageDepositTransactionCodeAdjustmentPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        
        public virtual bool WaitUntilTransactionCodeAdjustmentPageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownNegativeAccruedInterestDebit))
            {
                result = true;
            }

            return result;

        }
        public virtual bool WaitUntilTransactionCodeBackOfficePageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownGeneralPurposeDebitDebit))
            {
                result = true;
            }

            return result;

        }

        public virtual void EnterTransactionCodeAdjustmentDetails(string NegAcrIntDebit = " " , string NegAcrIntCredit = " ", string UnAcrIntDebit = " " , string UnAcrIntCredit = " " )
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownNegativeAccruedInterestDebit))
            {
                if(!string.IsNullOrEmpty(NegAcrIntDebit))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownNegativeAccruedInterestDebit, NegAcrIntDebit);
                }
                if(!string.IsNullOrEmpty(NegAcrIntCredit))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownNegativeAccruedInterestCredit, NegAcrIntCredit);
                }
                if(!string.IsNullOrEmpty(UnAcrIntDebit))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownUnauthorizedAccruedInterestDebit, UnAcrIntDebit);
                }
                if(!string.IsNullOrEmpty(UnAcrIntCredit))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownUnauthorizedAccruedInterestCredit, UnAcrIntCredit);
                }
                       
            }
        }

        public virtual void EnterTransactionCodeAdjustmentDetails(string NegAcrIntDebit = "" , string NegAcrIntCredit = "", string UnAcrIntDebit = "" , string UnAcrIntCredit = "", string AdjustmentsResidualInterestDebit = "", string AdjustmentsResidualInterestCredit = "", string AdjustmentsNegativeAIOnPositiveBalanceDebit = "", string AdjustmentsNegativeAIOnPositiveBalanceCredit = "", string AdjustmentsPositiveAIOnNegativeBalanceDebit = "", string AdjustmentsPositiveAIOnNegativeBalanceCredit = "", string AdjustmentsInterestAvailableNotCredited = "")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownNegativeAccruedInterestDebit))
            {
                if(!string.IsNullOrEmpty(NegAcrIntDebit))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownNegativeAccruedInterestDebit, NegAcrIntDebit);
                }
                if(!string.IsNullOrEmpty(NegAcrIntCredit))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownNegativeAccruedInterestCredit, NegAcrIntCredit);
                }
                if(!string.IsNullOrEmpty(UnAcrIntDebit))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownUnauthorizedAccruedInterestDebit, UnAcrIntDebit);
                }
                if(!string.IsNullOrEmpty(UnAcrIntCredit))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownUnauthorizedAccruedInterestCredit, UnAcrIntCredit);
                }
                if (!string.IsNullOrEmpty(AdjustmentsResidualInterestDebit))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(AdjustmentsResidualInterestDebitDropdown, AdjustmentsResidualInterestDebit);
                }
                if (!string.IsNullOrEmpty(AdjustmentsResidualInterestCredit))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(AdjustmentsResidualInterestCreditDropdown, AdjustmentsResidualInterestCredit);
                }
                if (!string.IsNullOrEmpty(AdjustmentsNegativeAIOnPositiveBalanceDebit))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(AdjustmentsNegativeAIOnPositiveBalanceDebitDropdown, AdjustmentsNegativeAIOnPositiveBalanceDebit);
                }
                if (!string.IsNullOrEmpty(AdjustmentsNegativeAIOnPositiveBalanceCredit))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(AdjustmentsNegativeAIOnPositiveBalanceCreditDropdown, AdjustmentsNegativeAIOnPositiveBalanceCredit);
                }
                if (!string.IsNullOrEmpty(AdjustmentsPositiveAIOnNegativeBalanceDebit))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(AdjustmentsPositiveAIOnNegativeBalanceDebitDropdown, AdjustmentsPositiveAIOnNegativeBalanceDebit);
                }
                if (!string.IsNullOrEmpty(AdjustmentsPositiveAIOnNegativeBalanceCredit))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(AdjustmentsPositiveAIOnNegativeBalanceCreditDropdown, AdjustmentsPositiveAIOnNegativeBalanceCredit);
                }
                if (!string.IsNullOrEmpty(AdjustmentsInterestAvailableNotCredited))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(AdjustmentsInterestAvailableNotCreditedDropdown, AdjustmentsInterestAvailableNotCredited);
                }
            }
        }


        public virtual void EnterTransactionCodeBackOfficeDetails(string unInsurePrincipal = "" , string BackOfficeUninsuredPositiveAccruedInterestDebit = "", string BackOfficeUninsuredPositiveAccruedInterestCredit = "" , string BackOfficeUninsuredNegAccIntonPosBalCredit = "", string BackOfficeUninsuredNegAccIntCredit = "", string BackOfficeUninsuredPosIntAccOnNegBalCredit = "", string BackOfficeUninsuredUncollIntCredit = "" )
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownunInsurePrincipal))
            {
                if(!string.IsNullOrEmpty(unInsurePrincipal))
                {
                appHandle.SelectDropdownSpecifiedValue(dropdownunInsurePrincipal, unInsurePrincipal);
                }
                if(!string.IsNullOrEmpty(BackOfficeUninsuredPositiveAccruedInterestDebit))
                {
                appHandle.SelectDropdownSpecifiedValue(dropdownBackOfficeUninsuredPositiveAccruedInterestDebit, BackOfficeUninsuredPositiveAccruedInterestDebit);
                }
                if(!string.IsNullOrEmpty(BackOfficeUninsuredPositiveAccruedInterestCredit))
                {
                appHandle.SelectDropdownSpecifiedValue(dropdownBackOfficeUninsuredPositiveAccruedInterestCredit, BackOfficeUninsuredPositiveAccruedInterestCredit);
                }
                if(!string.IsNullOrEmpty(BackOfficeUninsuredNegAccIntonPosBalCredit))
                {
                appHandle.SelectDropdownSpecifiedValue(dropdownBackOfficeUninsuredNegAccIntonPosBalCredit, BackOfficeUninsuredNegAccIntonPosBalCredit);
                }
                if (!string.IsNullOrEmpty(BackOfficeUninsuredNegAccIntCredit))
                {
                    appHandle.SelectDropdownSpecifiedValue(dropdownBackOfficeUninsuredNegAccIntCredit, BackOfficeUninsuredNegAccIntCredit);
                }
                if (!string.IsNullOrEmpty(BackOfficeUninsuredPosIntAccOnNegBalCredit))
                {
                    appHandle.SelectDropdownSpecifiedValue(dropdownBackOfficeUninsuredPosIntAccOnNegBalCredit, BackOfficeUninsuredPosIntAccOnNegBalCredit);
                }
                if (!string.IsNullOrEmpty(BackOfficeUninsuredUncollIntCredit))
                {
                    appHandle.SelectDropdownSpecifiedValue(dropdownBackOfficeUninsuredUncollIntCredit, BackOfficeUninsuredUncollIntCredit);
                }
            }
        }

    }
}