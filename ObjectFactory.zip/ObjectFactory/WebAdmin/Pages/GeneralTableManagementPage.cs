using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Threading;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class GeneralTableManagementPage
    {
        WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string TableNameField = "XPath;//input[@name='searchField']";
        public static string btnSeach = "XPath;//input[@name='search'][@type='submit']";
        public static string SubmitButton = "XPath;//input[@name='submit']";
        public static string TableList = "XPath;//table[contains(@id,'tables-list')]/tbody";
        public static string txtPaymentDueActionGridPaymentGrid = "Xpath;//input[@name='paymentGridTable']";
        public static string txtPaymentDueActionGridPaymentGridDescription = "Xpath;//input[@name='tableDescription']";
        public static string drpPaymentDueActionGridProductGroup = "Xpath;//select[@name='productGroup']";
        public static string txtPaymentDueStatusStartDate = "Xpath;//input[@name='startDate']";
        public static string drpPaymentDueActionGridPaymentDueStatusBasis = "Xpath;//select[@name='applicableDueStatus']";
        public static string txtPaymentDueActionGridPartialPayments1 = "Xpath;//input[@name='paymentGridDefinitions[0].partialPayments']";
        public static string txtPaymentDueActionGridPartialPayments2 = "Xpath;//input[@name='paymentGridDefinitions[1].partialPayments']";
        public static string txtPaymentDueActionGridPartialPayments3 = "Xpath;//input[@name='paymentGridDefinitions[2].partialPayments']";
        public static string txtPaymentDueActionGridPartialPayments4 = "Xpath;//input[@name='paymentGridDefinitions[3].partialPayments']";
        public static string txtPaymentDueActionGridFullPayments1 = "Xpath;//input[@name='paymentGridDefinitions[0].fullPayments']";
        public static string txtPaymentDueActionGridFullPayments2 = "Xpath;//input[@name='paymentGridDefinitions[1].fullPayments']";
        public static string txtPaymentDueActionGridFullPayments3 = "Xpath;//input[@name='paymentGridDefinitions[2].fullPayments']";
        public static string txtPaymentDueActionGridFullPayments4 = "Xpath;//input[@name='paymentGridDefinitions[3].fullPayments']";
        private static string tableObj = "Xpath;//*[@class='contentTable']";
        private static string txtRegionCode = "Xpath;//input[@name='regionCode']";
        private static string txtDescription = "Xpath;//input[@name='description']";
        private static string txtApply1098CutoffOption = "Xpath;//select[@name='apply1098CutoffOpt']";
        private static string txtApply1099INTCutoffOption = "Xpath;//select[@name='apply1099INTCutoffOpt']";
        private static string txtTaxID = "Xpath;//input[@name='taxIDUsedForIRSRpting']";
        private static string txtAddr1 = "Xpath;//input[@name='addrLine1UsedForIRSRpting']";
        private static string txtCity = "Xpath;//input[@name='cityUsedForIRSRpting']";
        private static string txtCountry = "Xpath;//select[@name='cntryCodeUsedForIRSRpting']";
        private static string txtState = "Xpath;//select[@name='stUsedforIRSRpting']";
        private static string txtZipCode = "Xpath;//input[@name='zipCodeUsedForIRSRpting']";
        private static string txtFeeAmount="XPath;//*[@name='content:service:FEEAMT']";
        private static string txtTerm ="XPath;//*[@name='content:service:TERM']";
        private static string ValidationMessage1 = "Xpath;//div[@id='core-error-box']//p[1]";
        private static string ValidationMessage2 = "Xpath;//div[@id='core-error-box']//p[2]";
        private static string ValidationMessage3 = "Xpath;//div[@id='core-error-box']//p[3]";
        private static string ValidationMessage4 = "Xpath;//div[@id='core-error-box']//p[4]";
        private static string MsgObj = "Xpath;//div[@class='msg-box']/descendant::p";
        private static string btnAddRegionCode = "Xpath;//input[@name='add']";
        public static string GeneralMgtSubmitButton = "Xpath;//input[@name='btnSubmit']";
        public static string txtTableName = "XPath;//input[@name='searchField']";
        public static string buttonSearch = "XPath;//input[@name='search']";
        public static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string buttonEdit = "Xpath;//*[@value = 'Edit']";
        public static string buttonAdd = "XPath;//input[@value='Add']";
        public static string buttonDelete = "XPath;//input[@value='Delete']";
        private static string txtCardBIN = "Xpath;//*[@name='content:service:BIN']";
        private static string txtCardDescription = "Xpath;//*[@name='content:service:FMDESC']";
        private static string buttonSubmitInCardBin = "Xpath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        //CRDTYP table
        private static string txtCardType = "Xpath;//*[@name='content:service:CARDTYPE']";
        private static string txtCardTypeDescription = "Xpath;//*[@name='content:service:DESC']";
        private static string txtDailyWithDrawalLimit = "Xpath;//*[@name='content:service:DLYLMT']";
        private static string txtCardnoGenerationSubRoutine = "Xpath;//*[@name='content:service:CMSGEN']";
        private static string drpCardTypeNumber = "Xpath;//*[@name='content:service:BIN']";
        private static string txtRenewalOffSetPeriod="Xpath;//*[@name='content:service:RNWOFF']";
        private static string txtRenewalReportOffsetPeriod="Xpath;//*[@name='content:service:RNWROFF']";
        private static string drpCreationStatus="Xpath;//*[@name='content:service:CRTNSTAT']";
        //UTBLSTATID
        private static string txtStateIDNo="Xpath;//*[@name='content:service:STATID']";
        private static string txtStateIDDescription="Xpath;//*[@name='content:service:DES']";        
        public static string dropdownTablename="XPath;//select[@name='content:service:FID']";
        public static string txtDescriptionnew="XPath;//input[@name='content:service:DESC']";
        public static string txtNumberOfDaysToSave="XPath;//input[@name='content:service:SVDYS']";
        public static string txtDateKeyColumnName="XPath;//input[@name='content:service:DTKEY']";
        public static string txtDateFormat="XPath;//input[@name='content:service:DTFMT']";
        public static string buttonSubmitAddpurgeFiles="XPath;//input[@value='Submit']";
        public static string txtWithholdingpercentage="XPath;//input[@name='withholdingPercentage']";
        public static string checkboxFederalwithholdingindicator="XPath;//input[@name='withholdingIndicator']";
        public static string txtRSPWithholdingpercentage="XPath;//input[@name='content:service:PCT']";
        public static string tablecrdtyp = "XPath;//*[contains(@id,'content:service:data')]/descendant::tbody";
        private static string buttonRecompileAll = "XPath;//input[@name='all']";

        private static string drpInterestandResidentRSPWithholdingSchedule = "XPath;//select[@name='withholdingSchedule']";
        public static string txtInterestandResidentRSPWithholdingFixedAmount="XPath;//input[@name='withholdingFixedAmount']";
        public static string tableUTBLRSP ="Xpath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";
        public static string dropdownProductType="XPath;//select[@id='content:service:TYPE']";
        public static string dropdownTransferType="XPath;//select[@id='content:service:ITEM']";
        public static string txtTransferTypeDescription="XPath;//input[@id='content:service:DESC']";
        public static string txtEscPayeeID="XPath;//input[@name='escrowPayee']";
        public static string dropdownEscType="XPath;//select[@name='escrowType']";
        public static string txtEscPayeeDescription="XPath;//input[@name='payeeDescription']";
        public static string txtFrequencyFromBorrower="XPath;//input[@name='frequencyFromBorrower']";
        public static string txtFrequencyToEscrowPayee="XPath;//input[@name='frequencyToEscrowPayee']";
        public static string txtNextRemittanceDate="XPath;//input[@name='nextRemittanceDate']";
        public static string txtToDepositAccount="XPath;//input[@name='depositAccount']";
        public static string txtEscType="XPath;//input[@name='escrowTypes']";
        public static string txtEscDescription="XPath;//input[@name='description']";
        public static string txtEscAvailableDate="XPath;//input[@name='dateAvailable']";
        public static string dropdownEscCategory="XPath;//select[@name='escrowProductType']";
        public static string txtEscDepositProduct="XPath;//input[@name='acctTypeCode']";
        public static string checkboxPrivateMortgageInsurance="XPath;//input[@name='privateMtgIns']";
          
        public virtual void EnterTableName(string TableName)
        {
            AppHandle.Set_field_value(TableNameField, TableName);
        }

        public virtual void ClickOnSearchButton()
        {
            AppHandle.SelectButton(btnSeach);
            Thread.Sleep(1000);
        }

        public virtual bool ClickSubmitButton()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                AppHandle.ClickObjectViaJavaScript(buttonSubmit);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
                {
                    Result = true;
                }
            }
            return Result;
        }

        public virtual void SelectPackageTableRadioButton(string ReferenceText)
        {
            AppHandle.SelectRadioButtonInTable(TableList, ReferenceText);
        }
        public virtual void SearchTableName(string TableName)
        {
            EnterTableName(TableName);
            ClickOnSearchButton();
            ValidateTableDescription();
        }
        public virtual void ValidateTableDescription()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(GeneralMgtSubmitButton))
            {
                Profile7CommonLibrary.VerifyDataInTableByColumnValues(Data.Get("Region Code User Table"));
                if (Profile7CommonLibrary.VerifyDataInTableByColumnValues(Data.Get("Region Code User Table")))
                {
                    Report.Pass("Region Code Details retrieved successfully", "ValidateTableDescription", "true", AppHandle);
                }
                else
                {
                    Report.Fail("Failed to retrieve Region code details", "ValidateTableDescription", "true", AppHandle, true);
                }
            }
            AppHandle.SelectRadioButtonInTable(TableList, "UTBLREGION");
            AppHandle.ClickObjectViaJavaScript(GeneralMgtSubmitButton);
        }

        public virtual void ValidateAddRegion()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnAddRegionCode))
            {
                AppHandle.ClickObjectViaJavaScript(btnAddRegionCode);
                ValidateAddRegionLabelsandTextFields();
                AddRegionValidationMessages();

            }
        }
        public virtual bool ValidateAddRegionLabelsandTextFields()
        {
            bool labelcounter = false;
            bool fieldcounter = false;
            bool Validationcounter = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtRegionCode))
            {
                if ((AppHandle.CheckTextExistsInTable(tableObj, Data.Get("Region Code"))) && (AppHandle.CheckTextExistsInTable(tableObj, Data.Get("Description")))
                && (AppHandle.CheckTextExistsInTable(tableObj, Data.Get("Apply 1098 Cutoff Option"))) && (AppHandle.CheckTextExistsInTable(tableObj, Data.Get("Apply 1099-INT Cutoff Option"))) &&
                (AppHandle.CheckTextExistsInTable(tableObj, Data.Get("Tax ID"))) && (AppHandle.CheckTextExistsInTable(tableObj, Data.Get("Address"))) &&
                (AppHandle.CheckTextExistsInTable(tableObj, Data.Get("City"))) && (AppHandle.CheckTextExistsInTable(tableObj, Data.Get("Country"))) && (AppHandle.CheckTextExistsInTable(tableObj, Data.Get("State/Province"))) && (AppHandle.CheckTextExistsInTable(tableObj, Data.Get("ZIP Code"))))
                {
                    labelcounter = true;
                }
                if ((AppHandle.IsObjectExists(txtRegionCode)) && (AppHandle.IsObjectExists(txtDescription)) && (AppHandle.IsObjectExists(txtApply1098CutoffOption)) && (AppHandle.IsObjectExists(txtApply1099INTCutoffOption)) &&
                (AppHandle.IsObjectExists(txtTaxID)) && (AppHandle.IsObjectExists(txtAddr1)) && (AppHandle.IsObjectExists(txtCity)) && (AppHandle.IsObjectExists(txtCountry)) &&
                (AppHandle.IsObjectExists(txtState)) && (AppHandle.IsObjectExists(txtZipCode)))
                {
                    fieldcounter = true;
                }
                if ((labelcounter == true) && (fieldcounter == true))
                {
                    Validationcounter = true;
                }
            }
            return Validationcounter;
        }
        public virtual void AddRegionValidationMessages()
        {
            AppHandle.Set_field_value(txtTaxID, Data.Get("GLOBAL_Invalid_POSTALCODEIN"));
            AppHandle.SelectDropdownSpecifiedValueByPartialText(txtCountry, Data.Get("GLOBAL_IDENTIFICATION_PASSPORT_DETAILS_COUNTRY"));
            AppHandle.Set_field_value(txtZipCode, Data.Get("GLOBAL_Invalid_POSTALCODEIN"));
            ClickSubmitButton();
            ValidationMessages(true);
            AppHandle.SelectDropdownSpecifiedValueByPartialText(txtState, Data.Get("GLOBAL_DLSTATE"));
            AppHandle.Set_field_value(txtZipCode, "");
            ClickSubmitButton();
            ValidationMessages(false);
            CreateRegionCode();
            SuccessMessageValidation();
        }
        public virtual void ValidationMessages(bool input)
        {
            if (input)
            {
                if ((AppHandle.GetObjectText(ValidationMessage1).Equals(Data.Get("RegionCodeValidationMessage"))) &&
                    (AppHandle.GetObjectText(ValidationMessage2).Equals(Data.Get("DescriptionValidationMessage"))) &&
                    (AppHandle.GetObjectText(ValidationMessage3).Equals(Data.Get("TaxIdValidationMessage"))) &&
                    (AppHandle.GetObjectText(ValidationMessage4).Equals(Data.Get("IRSValidationMessage"))))
                {
                    Report.Pass("Validation of warning Messages for RegionCode, Description, TaxID, IRS successfull", "ValidationMessages", "true", AppHandle);
                }
                else
                {
                    Report.Fail("Validation of warning messages failed", "ValidationMessages", "true", AppHandle, true);
                }
            }
            else
            {
                if ((AppHandle.GetObjectText(ValidationMessage4).Contains(Data.Get("ZipValidationMessage"))))
                {
                    Report.Pass("Validation of warning Messages for Zip Code successfull", "ValidationMessages", "true", AppHandle);
                }
                else
                {
                    Report.Fail("Validation of warning messages failed", "ValidationMessages", "true", AppHandle, true);
                }
            }
        }
        public virtual void CreateRegionCode()
        {
            string RegionCode = AppHandle.CreateRamdomData(FieldType.ALPHANUMERICS, 111111, 999999, 4).ToString();
            string TAXID = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"), "-");
            AppHandle.Set_field_value(txtRegionCode, RegionCode);
            AppHandle.Set_field_value(txtDescription, Data.Get("RegionCodeDescription"));

            AppHandle.SelectDropdownSpecifiedValueByPartialText(txtApply1098CutoffOption, Data.Get("UseOptionfromCustomerVariables"));
            AppHandle.SelectDropdownSpecifiedValueByPartialText(txtApply1099INTCutoffOption, Data.Get("UseOptionfromCustomerVariables"));
            AppHandle.Set_field_value(txtTaxID, TAXID);
            AppHandle.Set_field_value(txtAddr1, Data.Get("GLOBAL_ADDRESS1IN"));
            AppHandle.Set_field_value(txtCity, Data.Get("GLOBAL_CITYIN"));
            AppHandle.SelectDropdownSpecifiedValueByPartialText(txtCountry, Data.Get("GLOBAL_COUNTRYIN"));
            AppHandle.SelectDropdownSpecifiedValueByPartialText(txtState, Data.Get("GLOBAL_STATEIN"));
            AppHandle.Set_field_value(txtZipCode, Data.Get("GLOBAL_POSTALCODEIN"));
            ClickSubmitButton();

        }

        public virtual void SuccessMessageValidation()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MsgObj))
            {
                AppHandle.ClickObject(MsgObj);
            }
        }

        public virtual void SelectTableFromGeneralTableManagment(string tablename)
        {

            string dynamicobj = "XPath;//td[contains(text(),'" + tablename + "')]/preceding-sibling::td/input";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtTableName);
            AppHandle.Set_field_value(txtTableName, tablename);
            AppHandle.ClickObjectViaJavaScript(buttonSearch);
            AppHandle.ClickObjectViaJavaScript(dynamicobj);
            Report.Info("The Table is selected from general table management table", "tblpass", "True", AppHandle);
            AppHandle.ClickObjectViaJavaScript(buttonSubmit);
        }
        public virtual string AddNewCardBin(string Desc="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(buttonAdd);
            string BinNo = AppHandle.CreateRamdomData(FieldType.NUMERIC, 100000, 999999).ToString();
            AppHandle.WaitUntilElementExists(txtCardBIN);
            AppHandle.Set_field_value(txtCardBIN, BinNo);
            if(string.IsNullOrEmpty(Desc))
            {
                AppHandle.Set_field_value(txtCardDescription, Desc);
            }
            else
            {
                AppHandle.Set_field_value(txtCardDescription, "BIN for MasterCard Gold card");
            }
            
            Report.Info("New Card Bin Record is created in Card Bin Page", "cardsbin", "true", AppHandle);
            return BinNo;
        }
        public virtual string AddCardTypeInCRDTYP(string BinNo,string WDLimit,string FeeAmt="",string Term="",string RenewalPeriod=null,string RenewalReportPeriod=null,string CreationStatus=null)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(buttonAdd);
            string CardType = AppHandle.CreateRamdomData(FieldType.NUMERIC, 100000, 999999).ToString();
            AppHandle.WaitUntilElementExists(txtCardType);
            AppHandle.Set_field_value(txtCardType,CardType);
            AppHandle.Set_field_value(txtCardTypeDescription,"DebitCard");
            AppHandle.Set_field_value(txtDailyWithDrawalLimit,WDLimit);
            AppHandle.SelectDropdownSpecifiedValueByPartialText(drpCardTypeNumber,BinNo);
            AppHandle.Set_field_value(txtCardnoGenerationSubRoutine,"STANDARD");
            AppHandle.Set_field_value(txtFeeAmount,FeeAmt);
            AppHandle.Set_field_value(txtTerm,Term);
            AppHandle.Set_field_value(txtRenewalOffSetPeriod,RenewalPeriod);
            AppHandle.Set_field_value(txtRenewalReportOffsetPeriod,RenewalReportPeriod);
            AppHandle.SelectDropdownSpecifiedValueByPartialText(drpCreationStatus,CreationStatus);
            Report.Info("New Card Type Record is created in Card Type Page","cardtype","true",AppHandle);
            return CardType;        
            

        }
        public virtual void ClickSubmitButtonForCard()
        {
            AppHandle.ClickObjectViaJavaScript(buttonSubmitInCardBin);
            Report.Info("Submit button is clicked.");
        }

        public virtual bool ClickOnAddButton()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                AppHandle.ClickObjectViaJavaScript(buttonAdd);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
                {
                    Result = true;
                }
            }
            return Result;
        }

        public virtual string EnterPermanentHoldCode()
        {
            string PermHoldCodeNumber = "";
            string temp = "";
            bool flag = false;
            if (ClickOnAddButton())
            {
                temp = (int)AppHandle.CreateRamdomData(FieldType.NUMERIC, 11, 99, 2) + "";
                string RandomDESC = (string)AppHandle.CreateRamdomData(FieldType.ALPHABETS, 1111, 9999, 4);
                RandomDESC = RandomDESC.ToUpper();
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Perm Hold Code Number") + "|" + temp + ";" + Data.Get("Description") + "|" + RandomDESC + temp);
                if (ClickSubmitButton())
                {
                    flag = true;
                }
            }
            if (flag)
            {
                PermHoldCodeNumber = temp;
            }
            return PermHoldCodeNumber;
        }
        public virtual string AddStateIDNo()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(buttonAdd);
            string StateIDNo = AppHandle.CreateRamdomData(FieldType.NUMERIC, 10, 99).ToString();
            AppHandle.WaitUntilElementExists(txtStateIDNo);
            AppHandle.Set_field_value(txtStateIDNo, StateIDNo);
            AppHandle.Set_field_value(txtStateIDDescription, "State Identification");
            Report.Info("New State ID Record is created in State ID Number Page", "StateID", "true", AppHandle);
            return StateIDNo;


        }




        public virtual bool EnterDetailsForAddPurgeFiles(string tablename,string description,string noofdaystosave,string datekeyval,string dateformat)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownTablename);
            AppHandle.SelectDropdownSpecifiedValue(dropdownTablename,tablename);
            AppHandle.Set_field_value(txtDescriptionnew,description);
            AppHandle.Set_field_value(txtNumberOfDaysToSave,noofdaystosave);
            AppHandle.Set_field_value(txtDateKeyColumnName,datekeyval);
            AppHandle.Set_field_value(txtDateFormat,dateformat);
            Report.Info("The data entered in general table management","gtmp","True",AppHandle);
            AppHandle.ClickObjectViaJavaScript(buttonSubmitAddpurgeFiles);
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public virtual bool VerifyRecordUTBLKILLAddedAlreadyAndDelete(string recordname)
        {
            string tblobj="XPath;//table[@id='content:service:data']/tbody/descendant::span[contains(text(),'"+recordname+"')]";
            string tblobj1="XPath;//table[@id='content:service:data']/tbody";
            if(AppHandle.GetObjectText(tblobj).Equals(recordname))
            {
                AppHandle.SelectRadioButtonInTable(tblobj1,recordname);
                AppHandle.ClickObjectViaJavaScript(buttonDelete);
                AppHandle.SwitchTo(SwitchInto.ALERT);
                AppHandle.PerformActionOnAlert(PopUpAction.Accept);
                AppHandle.SwitchTo(SwitchInto.DEFAULT);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            }

            return true;
        }

        public virtual bool UpdateWithholdPercentageForSpecificWithCalcMethod(string tablename,string withcalmethod,string withholdperval, string InterestandResidentRSPWithholdingSchedule, string InterestandResidentRSPWithholdingFixedAmount)
        {
            string dynobjwithholdcalmethod="XPath;//*[contains(text(),'"+withcalmethod+"')]/preceding-sibling::td/input";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(TableNameField);
            AppHandle.Set_field_value(TableNameField,tablename);
            AppHandle.ClickObjectViaJavaScript(btnSeach);
            SelectTableFromGeneralTableManagment(tablename);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(dynobjwithholdcalmethod);
            AppHandle.ClickObjectViaJavaScript(buttonEdit);
            AppHandle.Set_field_value(txtWithholdingpercentage,withholdperval);

            if(InterestandResidentRSPWithholdingSchedule=="")
            {
                AppHandle.SelectDropdownSpecifiedValue(drpInterestandResidentRSPWithholdingSchedule,InterestandResidentRSPWithholdingSchedule);
            }
            else
            {
                AppHandle.SelectDropdownSpecifiedValueByPartialText(drpInterestandResidentRSPWithholdingSchedule, InterestandResidentRSPWithholdingSchedule);
            }            
            if (!string.IsNullOrEmpty(InterestandResidentRSPWithholdingFixedAmount))
            {
                AppHandle.Set_field_value(txtInterestandResidentRSPWithholdingFixedAmount, InterestandResidentRSPWithholdingFixedAmount);
            }            
            AppHandle.ClickObjectViaJavaScript(buttonSubmitAddpurgeFiles);
            return AppHandle.CheckSuccessMessage(Data.Get("Successmsgwithholdcalcmethod"));

        }

        public virtual bool UpdateRetirementSavingbasedonplantype(string tablename,string plantype,string plandescription)
        {
            string dynobjwithholdcalmethod="XPath;//*[starts-with(text(),'"+plandescription+"')]/preceding-sibling::td[starts-with(text(),'"+plantype+"')]/preceding-sibling::td/input";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(TableNameField);
            AppHandle.Set_field_value(TableNameField,tablename);
            AppHandle.ClickObjectViaJavaScript(btnSeach);
            SelectTableFromGeneralTableManagment(tablename);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.SelectRadioButtonInTable(tableUTBLRSP, plandescription);
            AppHandle.ClickObjectViaJavaScript(buttonEdit);
            if(!AppHandle.CheckCheckBoxChecked(checkboxFederalwithholdingindicator))
                AppHandle.ClickObjectViaJavaScript(checkboxFederalwithholdingindicator);
            AppHandle.ClickObjectViaJavaScript(buttonSubmitAddpurgeFiles);
            return AppHandle.CheckSuccessMessage(Data.Get("SuccessmsgRetirementplan"));

        }

        public virtual void UpdateRetirementPlanSchdulerate(string tablename,string description,string RSPwithholdpercentageval,string indexnumofradiobtn)
        {
            string dynobjwithholdcalmethod="XPath;//*[contains(text(),'"+description+"')]/ancestor::*[1]/td/input";
            string dynobjschident="XPath;//table[@id='content:service:data']/descendant::input[@type='radio']["+indexnumofradiobtn+"]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(TableNameField);
            AppHandle.Set_field_value(TableNameField,tablename);
            AppHandle.ClickObjectViaJavaScript(btnSeach);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnSeach);
            AppHandle.ClickObjectViaJavaScript(dynobjwithholdcalmethod);
            AppHandle.ClickObjectViaJavaScript(buttonSubmit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit);
            AppHandle.ClickObjectViaJavaScript(dynobjschident);
            AppHandle.ClickObjectViaJavaScript(buttonEdit);
            AppHandle.Set_field_value(txtRSPWithholdingpercentage,RSPwithholdpercentageval);
            Report.Info("The Data entered for retirement plan for RSP withhold percentage","thgimg","True",AppHandle);
            AppHandle.ClickObjectViaJavaScript(buttonSubmit);
        }
            


        public virtual string AddNewCardBin(string BinNo,string Desc="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(buttonAdd);
            AppHandle.WaitUntilElementExists(txtCardBIN);
            AppHandle.Set_field_value(txtCardBIN, BinNo);
            if(!string.IsNullOrEmpty(Desc))
            {
                AppHandle.Set_field_value(txtCardDescription, Desc);
            }
            else
            {
                AppHandle.Set_field_value(txtCardDescription, "BIN for MasterCard Gold card");
            }
            
            Report.Info("New Card Bin Record is created in Card Bin Page", "cardsbin", "true", AppHandle);
            return BinNo;
        }

        public virtual void EnterInvalidBinNumber(string InvalidBin,string Desc="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(buttonAdd);
            AppHandle.WaitUntilElementExists(txtCardBIN);
            AppHandle.Set_field_value(txtCardBIN, InvalidBin);
            if(string.IsNullOrEmpty(Desc))
            {
                AppHandle.Set_field_value(txtCardDescription, Desc);
            }
            else
            {
                AppHandle.Set_field_value(txtCardDescription, "BIN for MasterCard Gold card");
            }
            
                       
        }
         public virtual bool VerifyMessageInstitutionVariable(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (AppHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual bool SearchCardTypeFromTable(string cardtype)
        {
            bool Result = false;
            string CardTypeRadiobutton = tablecrdtyp+"/descendant::td[span='" +cardtype+"']/ancestor::*[1]/td/input";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(CardTypeRadiobutton))
            {
                AppHandle.ClickObjectViaJavaScript(CardTypeRadiobutton);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                Result = true;
            }
            return Result;
        }


        public virtual bool ClickOnEditButton()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                AppHandle.ClickObjectViaJavaScript(buttonEdit);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
                {
                    Result = true;
                }
            }
            return Result;
        }

        public virtual string AddCardType(string sLabelNameLabelValuePipeDelimited)
        {
            string CardType = "MC_"+AppHandle.CreateRamdomData(FieldType.NUMERIC, 100, 999).ToString();
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue("Card Type:|"+CardType+";Description:|"+CardType+";"+sLabelNameLabelValuePipeDelimited);
            Report.Pass("Enter Card Details in CRDTYP page", "CardManagementpage1", "true", AppHandle); 
            ClickSubmitButtonForCard();
            return CardType;        
            
        }
        public virtual void RecomipleAll()
        {
            AppHandle.ClickObjectViaJavaScript(buttonRecompileAll);
            AppHandle.Wait_For_Specified_Time(5);
        }

        public virtual string AddEscPayee(string EscCode, string RemittanceDate, string WashAccount)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(buttonAdd);
            string escpayee = AppHandle.CreateRamdomData(FieldType.NUMERIC, 10000, 99999, 5).ToString();
            AppHandle.WaitUntilElementExists(txtEscPayeeID);
            AppHandle.Set_field_value(txtEscPayeeID, escpayee);
            AppHandle.SelectDropdownSpecifiedValueByPartialText(dropdownEscType, EscCode);
            AppHandle.Set_field_value(txtEscPayeeDescription, EscCode +"Escro Payee");
           AppHandle.Set_field_value(txtFrequencyFromBorrower, "30DA");
            AppHandle.Set_field_value(txtFrequencyToEscrowPayee, "30DA");
            AppHandle.Set_field_value(txtNextRemittanceDate, RemittanceDate);
            AppHandle.Set_field_value(txtToDepositAccount, WashAccount);
            ClickSubmitButton();
            Report.Info("New Escrow Payee is created", "escpayee", "true", AppHandle);
            return escpayee;

        }

        public virtual void AddEscGRP(string EscProductType, string EscCode)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(buttonAdd);
            AppHandle.WaitUntilElementExists(dropdownProductType);
            AppHandle.SelectDropdownSpecifiedValueByPartialText(dropdownProductType, EscProductType);
            AppHandle.SelectDropdownSpecifiedValueByPartialText(dropdownTransferType, EscCode);
            AppHandle.Set_field_value(txtTransferTypeDescription, "Private Insurance");
            ClickSubmitButton();
            Report.Info("Product added to ESCGRP", "escGrp", "true", AppHandle);
            
        }

        public virtual string AddEscType(string dateAvailable)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            AppHandle.ClickObjectViaJavaScript(buttonAdd);
            string EscType = AppHandle.CreateRamdomData(FieldType.ALPHABETS, 10, 99, 5).ToString();
            AppHandle.WaitUntilElementExists(txtEscType);
            AppHandle.Set_field_value(txtEscType, EscType);
            AppHandle.Set_field_value(txtEscDescription, "Private Insurance");
            AppHandle.Set_field_value(txtEscAvailableDate, dateAvailable);
            AppHandle.SelectDropdownSpecifiedValue(dropdownEscCategory,"Insurance");
            AppHandle.Set_field_value(txtEscDepositProduct, "200");
            if(!AppHandle.CheckCheckBoxChecked(checkboxPrivateMortgageInsurance))
                AppHandle.ClickObjectViaJavaScript(checkboxPrivateMortgageInsurance);
            ClickSubmitButton();
            Report.Info("New Escrow Type is created", "esctype", "true", AppHandle);
            return EscType;

        }


        
    }
}