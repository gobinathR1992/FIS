using System;
using System.Collections.Generic;
using System.Threading;
using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class DepositAccountEFDRateChangePage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string drpAccount = "Xpath;//select[@name='ACN_CID']";
        private static string txtEffectiveDate = "Xpath;//input[@name='effectiveDate']";
        private static string txtInterestRate = "Xpath;//input[@name='ACN_IRN']";
        private static string btnSubmit = "Xpath;//input[@name='submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";

        /// <summary>
        /// This method is used to select Account From AccountDropdown
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebCSRPageFactory.DepositAccountProductTransferPage.selectAccountFromDropdown();
        /// </example>
        public virtual void selectAccountFromDropdown(string accName)
        {
            try
            {
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpAccount))
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpAccount, accName);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        public virtual bool EnterEFDRateChangeOption(string accName, string EffDate, string InterestRate)
        {
            
            this.selectAccountFromDropdown(accName);
            if (!string.IsNullOrEmpty(EffDate))
            {
                appHandle.Set_field_value(txtEffectiveDate, EffDate);
            }
            if (!string.IsNullOrEmpty(InterestRate))
            {
                appHandle.Set_field_value(txtInterestRate, InterestRate);
            }
            this.Submit();
            return VerifySuccessMessage();
        }

        public virtual void Submit()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnSubmit))
            {
                appHandle.ClickObjectViaJavaScript(btnSubmit);
            }
        }

        public virtual bool VerifySuccessMessage()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Result = true;
                }
            }
            return Result;
        }

    }
}