using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class AddExemptionPlanParametersPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtExemptionPlanName="Xpath;//input[@name='exemptionPlanName']";
        public static string txtEffectiveDate="Xpath;//input[@name='effectiveDate']";
        public static string ckbCategory1Items="Xpath;//input[@name='category1']";
        public static string ckbCategory3Items="Xpath;//input[@name='category3']";
        public static string ckbCategory4Items="Xpath;//input[@name='category4']";
        public static string txtFullExemptionBalance="Xpath;//input[@name='fullExemptionBalance']";
        public static string txtNumberofFreeReducedItems="Xpath;//input[@name='numberOfFreeItems']";
        public static string txtFreeReducedItemBasis="Xpath;//input[@name='freeItemsBasis']";
        public static string drpBalanceBase="Xpath;//select[@name='balanceBase']";
        public static string txtAddPlanParametersMsg="Xpath;//h1[contains(text(),'Add Exemption Plan Parameters')]";
        public static string btnContinue="Xpath;//input[@name='_eventId_submit']";

    

       //Method for Confirm the Add Exemption Plan Parameters Page.
        public virtual bool ConfirmAddExemptionPlanParametersPage()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirmed the Add Accrual User Exit Definition");
            bool blnSuccess = false;
            if (appHandle.CheckObjectExist(txtAddPlanParametersMsg))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }

        //Method for click the continue button.
        public virtual void ClickonContinue()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.SelectButton(btnContinue);
            Thread.Sleep(2000);
            Report.Info("Continue button is clicked.");
        }

    }
}