using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class InstitutionVariableDepositPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtBackupWithholdingPercentage = "XPath;//input[@name='CUVAR_BWPCT']";

        public virtual string GetBackupWithholdingPercentageValue()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtBackupWithholdingPercentage);
            string BackupWithholdingPercentageval = appHandle.GetEditFieldValue(txtBackupWithholdingPercentage);
            return BackupWithholdingPercentageval;
        }

    }
}