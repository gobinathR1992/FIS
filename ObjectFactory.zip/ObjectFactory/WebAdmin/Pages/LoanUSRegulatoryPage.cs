using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class LoanUSRegulatoryPage
    { 
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string dropdownReportingExemption = "Xpath;//select[@name ='PRODDFTL_IRSEXM']";
        public static string dropdownFDICOTCPrimariyReporting = "Xpath;//select[@name ='PRODDFTL_LFPC']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";

        public virtual bool VerifyMessageLoanUSRegulatoryOptionPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        

        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }
         public virtual bool WaitUntilLoanUSRegulatoryPageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownReportingExemption))
            {
                result = true;
            }

            return result;

        }
        public virtual void EnterUSRegulatoryPageOptions(string PrimaryReportingCode)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownReportingExemption))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownFDICOTCPrimariyReporting, PrimaryReportingCode);
                                      
            }
        }
        
    }
}