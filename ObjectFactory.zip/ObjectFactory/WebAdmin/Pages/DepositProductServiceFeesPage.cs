using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class DepositProductServiceFeesPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string dropdownfeePlan="XPath;//select[@name='PRODDFTD_FEEPLN']";

        public static string txtFeeFrequency="XPath;//input[@name='PRODDFTD_SCFRE']";
        public static string dropdownFeeOption="XPath;//select[@name='PRODDFTD_FEEOPT']";
        public static string txtATMPOSoverdraftlimitfee="XPath;//input[@name='PRODDFTD_ODLIMTHRAMT']";     

        public static string buttonSubmit="XPath;//input[@name='submit']";

        public virtual bool EnterDetailsForServiceFeePage(string feeplan,string feefrequency,string feeoption,string atmposval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownfeePlan);
            appHandle.SelectDropdownSpecifiedValue(dropdownfeePlan,feeplan);
            appHandle.Set_field_value(txtFeeFrequency,feefrequency);
            appHandle.SelectDropdownSpecifiedValue(dropdownFeeOption,feeoption);
            appHandle.Set_field_value(txtATMPOSoverdraftlimitfee,atmposval);
            appHandle.ClickObject(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }


    }
}