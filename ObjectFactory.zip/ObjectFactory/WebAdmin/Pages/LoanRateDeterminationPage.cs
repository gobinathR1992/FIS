using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class LoanRateDeterminationPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtFixedRateNominalRate = "XPath;//input[@name='PRODDFTL_IRN']";
        public static string drpAdjustableRateIndex = "XPath;//select[@name='PRODDFTL_INDEX']";
        public static string txtAdjustableRateChangeFrequency = "XPath;//input[@name='PRODDFTL_INTFRE']";
        public static string txtAdjustableRateInterestSpread = "XPath;//input[@name='PRODDFTL_INTSPR']";
        public static string txtAdjustableRateLimitsMaximumRate = "Xpath;//input[@name='PRODDFTL_INTMX']";
        public static string txtAdjustableRateLimitsInterestRateCeiling = "Xpath;//input[@name='PRODCTL_INTC']";
        public static string txtAdjustableRateLimitsInterestRateFloor = "Xpath;//input[@name='PRODCTL_INTF']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        
        public static string dropdownAdjustableRateIndex="XPath;//select[@name='PRODDFTL_INDEX']";
        public static string txtAdjustableRateReviewOffsetdays="XPath;//input[@name='PRODDFTL_INTOFF']";
        

        public virtual bool WaitUntilRateDeterminationPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtFixedRateNominalRate))
            {
                result = true;
            }

            return result;

        }

        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }

         public virtual bool VerifyMessageDepositRateDeterminationPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual void EnterRateDeterminationOptions(string FixedRate= "" , string VariableRateIndex = "", string ChangeFrequency = "",string ratedeterminationoptionssemecolondelemited="" )
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpAdjustableRateIndex))
            {
                int indexlength = appHandle.GetLengthOfText(txtFixedRateNominalRate);
                for(int i=0;i<=indexlength-1;i++)
                {
                    appHandle.SendKeyStroke(txtFixedRateNominalRate, InputKey.Backspace);
                }
                appHandle.Set_field_value(txtFixedRateNominalRate,FixedRate);
                if(!string.IsNullOrEmpty(VariableRateIndex))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpAdjustableRateIndex, VariableRateIndex);
                }
                
                if(!string.IsNullOrEmpty(ChangeFrequency))
                {
                appHandle.Set_field_value(txtAdjustableRateChangeFrequency,ChangeFrequency);
                }                       
            }
            if(!string.IsNullOrEmpty(ratedeterminationoptionssemecolondelemited))
            {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(ratedeterminationoptionssemecolondelemited);
            }
        }

        public virtual bool EnterRateDeterminationDetails(string rateval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.Set_field_value(txtFixedRateNominalRate,rateval);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));


        }

        public virtual bool UpdateDataInAdjustableRateSectionOfInterestTab(string indexval,string interestreviewoffsetdaysval,string changefrequency,string fixedratenominalrate="")
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownAdjustableRateIndex);
            appHandle.SelectDropdownSpecifiedValue(dropdownAdjustableRateIndex,indexval);
            appHandle.Set_field_value(txtAdjustableRateReviewOffsetdays,interestreviewoffsetdaysval);
            appHandle.Set_field_value(txtAdjustableRateChangeFrequency,changefrequency);
            if(string.IsNullOrEmpty(fixedratenominalrate))
            {
                appHandle.Set_field_value(txtFixedRateNominalRate,"");
            }
            else
            {
                appHandle.Set_field_value(txtFixedRateNominalRate,fixedratenominalrate);
            }
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }



    }

}