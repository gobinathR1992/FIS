using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class RateScheduleListPage
    {
        protected static string InterestRateScheduleListTable = "XPath;//div[contains(@id,'rate-list')]";
        private static WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// This method is used to select specified RateScheduleName in RateScheduleList Table
        /// <param name = "RateScheduleName"></param> 
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.SelectSpecifiedRateScheduleName();
        /// </example> 
        public void SelectSpecifiedRateScheduleName(string sRateScheduleName)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(InterestRateScheduleListTable);
                AppHandle.WaitUntilElementClickable(InterestRateScheduleListTable);
                string obj = "XPath;//input[@name='rateSchedule'][@value='" + sRateScheduleName + "']";
                AppHandle.Set_radiobutton(obj);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to check specified RateScheduleName exists in RateScheduleList Table
        /// <param name = "RateScheduleName"></param> 
        /// <returns>bool</returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.CheckSpecifiedRateScheduleExists(sRateScheduleName);
        /// </example> 
        public virtual bool CheckSpecifiedRateScheduleExists(string sRateScheduleName)
        {
            bool bcheck = false;
            try
            {
                AppHandle.WaitUntilElementVisible(InterestRateScheduleListTable);
                AppHandle.WaitUntilElementClickable(InterestRateScheduleListTable);
                string obj = "XPath;//input[@name='rateSchedule'][@value='" + sRateScheduleName + "']";
                bcheck = AppHandle.IsObjectExists(obj);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            return bcheck;
        }
    }
}