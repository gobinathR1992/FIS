using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class DelinquencyNoticeSelectionPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        
        public static string txtDaysDelinquentforNoticeCategory1="XPath;//input[@name='PRODCTL_DNC1']";
        public static string txtDaysDelinquentforNoticeCategory2="XPath;//input[@name='PRODCTL_DNC2']";
        public static string txtDaysDelinquentforNoticeCategory3="XPath;//input[@name='PRODCTL_DNC3']";
        public static string txtDaysDelinquentforNoticeCategory4="XPath;//input[@name='PRODCTL_DNC4']";
        public static string txtDaysDelinquentforNoticeCategory5="XPath;//input[@name='PRODCTL_DNC5']";
        public static string buttonSubmit="XPath;//input[@name='submit']";


        public virtual bool EnterNoticeSelectionDetailsInDelinquencyForTDSetup(string val1,string val2,string val3,string val4,string val5)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDaysDelinquentforNoticeCategory1);
            appHandle.Set_field_value(txtDaysDelinquentforNoticeCategory1,val1);
            appHandle.Set_field_value(txtDaysDelinquentforNoticeCategory2,val2);
            appHandle.Set_field_value(txtDaysDelinquentforNoticeCategory3,val3);
            appHandle.Set_field_value(txtDaysDelinquentforNoticeCategory4,val4);
            appHandle.Set_field_value(txtDaysDelinquentforNoticeCategory5,val5);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }


    }
}