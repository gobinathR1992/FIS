using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class InstitutionVariablePage
    { 
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string DropdownInterestPostingOption = "Xpath;//select[@name='CUVAR_INTPOS']"; 
        public static string DropdownAccountSelectionforBackupWitholding = "Xpath;//select[@name='CUVAR_BACKUPWHDEFAULTOPT']";         
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string checkboxACHStopRemoval = "Xpath;//input[@name = 'CUVAR_ACHDISABLESTOPREM']";
        private static string txtFATCAWithholdingPercentage="Xpath;//*[@name='CUVAR_FATCAWTHRATE']";
        private static string txtCity="Xpath;//*[@name='CUVAR_CCITY']";
        private static string drpdownCountry="Xpath;//*[@name='CUVAR_CCNTRY']";
        private static string drpdownState ="Xpath;//*[@name='CUVAR_CSTATE']";
        private static string txtZipCode ="Xpath;//*[@name='CUVAR_CZIP']";
        private static string txtTelephone ="Xpath;//*[@name='CUVAR_TELEPHONE']";
        private static string txtCompanyShortName="XPath;//*[@name='CUVAR_CO']";
        private static string drpdownFilerCategory="Xpath;//*[@name='CUVAR_FRM8966FILERCATEGORY']";

        public static string txtFinancialYearEnd="XPath;//input[@name='CUVAR_FINYE']";
        public static string txtTaxYearEnd="XPath;//input[@name='CUVAR_TAXYE']";
        public static string checkboxNetDistributionswithWithholding="XPath;//input[@name='CUVAR_RPANET']";
        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }

         public virtual bool VerifyMessageInstitutionVariable(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void EnterInterestProcessingOption(string sLabelNameLabelValuePipeDelimited )
        {

            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
            // if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownInterestPostingOption))
            // {
            
            //     if(!string.IsNullOrEmpty(INTPOS))
            //     {
            //     appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownInterestPostingOption, INTPOS);
            //     }
                
            //     if(!string.IsNullOrEmpty(BACKUPWHDEFAULTOPT))
            //     {
            //     appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownAccountSelectionforBackupWitholding, BACKUPWHDEFAULTOPT);
            //     }
                             
                       
            // }
        }
        public virtual bool ClickonACHStopRemovalCheckbox(bool ACHStopRemovalONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxACHStopRemoval))
            {
                if (ACHStopRemovalONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxACHStopRemoval)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxACHStopRemoval);
                        if (appHandle.CheckCheckBoxChecked(checkboxACHStopRemoval))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxACHStopRemoval) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxACHStopRemoval);
                        if (appHandle.CheckCheckBoxChecked(checkboxACHStopRemoval) == false) { Result = true; }
                    }
                }
            }
            return Result;
        }

            public virtual string GetValueofTaxAndFinYearEndAndUpdateInInstitutionTab(string appdate)
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtFinancialYearEnd);
                string finend=appHandle.GetEditFieldValue(txtFinancialYearEnd);
                string taxend=appHandle.GetEditFieldValue(txtTaxYearEnd);
                appHandle.Set_field_value(txtFinancialYearEnd,appdate);
                appHandle.Set_field_value(txtTaxYearEnd,appdate);
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                return finend+";"+taxend;
            }

            public virtual bool UpdateTaxYearEndAndFinYearEnd(string finyearend,string taxyearend)
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtFinancialYearEnd);
                appHandle.Set_field_value(txtFinancialYearEnd,finyearend);
                appHandle.Set_field_value(txtTaxYearEnd,taxyearend);
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

            }
           

        
        public virtual void EnterWitholdingPercentage(string Percentage)
        {
            appHandle.WaitUntilElementExists(txtFATCAWithholdingPercentage);
            appHandle.Set_field_value(txtFATCAWithholdingPercentage,Percentage);

        }
        public virtual void UpdateInstitutionDemographics(string City,string Country,string State,string ZipCode,string Telephone)
        {
            appHandle.WaitUntilElementExists(txtCity);
            appHandle.Set_field_value(txtCity,City);
            appHandle.SelectDropdownSpecifiedValue(drpdownCountry,(string)Country);
            appHandle.SelectDropdownSpecifiedValue(drpdownState,(string)State);
            appHandle.Set_field_value(txtZipCode,ZipCode);
            appHandle.Set_field_value(txtTelephone,Telephone);

        }
        public virtual string GetCompanyShortName()
        {
            string result = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCompanyShortName))
            {
                result = appHandle.GetElementValue(txtCompanyShortName);
            }
            return result;

        }
        public virtual void UpdateFilerCategoryforFORM8966(string FilerCategory)
        {
            appHandle.WaitUntilElementExists(drpdownFilerCategory);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownFilerCategory,FilerCategory);
        }

        public virtual bool ClickOnCheckboxNetDistributionswithWithholdingInRetirementtab()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxNetDistributionswithWithholding);
            if(appHandle.CheckCheckBoxChecked(checkboxNetDistributionswithWithholding))
            {
                appHandle.ClickObject(checkboxNetDistributionswithWithholding);
            }
            appHandle.ClickObject(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }



    }
}