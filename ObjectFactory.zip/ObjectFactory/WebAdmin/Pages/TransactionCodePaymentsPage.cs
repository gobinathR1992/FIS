using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class TransactionCodePaymentsPage
    {
        WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string dropdownDebitPrincipalVariancePosting="XPath;//select[@name='PRODCTL_DRTRPV']";
        public static string dropdownCreditCreditPrincipalVariancePosting="XPath;//select[@name='PRODCTL_CRTRPV']";
        public static string buttonSubmit="XPath;//input[@name='submit']";


        public virtual bool EnterDetailsforPayments(string debitprincipalvarpost,string credprincipalvarpost)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownDebitPrincipalVariancePosting);
            appHandle.SelectDropdownSpecifiedValue(dropdownDebitPrincipalVariancePosting,debitprincipalvarpost);
            appHandle.SelectDropdownSpecifiedValue(dropdownCreditCreditPrincipalVariancePosting,credprincipalvarpost);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }


    }

}