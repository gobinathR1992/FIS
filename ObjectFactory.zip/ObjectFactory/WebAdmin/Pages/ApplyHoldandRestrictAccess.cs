using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;


 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class ApplyHoldandRestrictAccess
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonRun="XPath;//input[@name='submit']";
        private static string dropdownHoldtype = "XPath;//select[@name='promptForms[0].propertyKey']";
        public virtual void ClickOnRunButton()
        {
            
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRun))
            {
                //string ApplicationDate = Profile7CommonLibrary.GetApplicationDate();
                appHandle.ClickObjectViaJavaScript(buttonRun);
                //File = "FDIC370-"+appHandle.GetDateParameters(ApplicationDate)[2]+"-"+appHandle.GetDateParameters(ApplicationDate)[0]+"-"+appHandle.GetDateParameters(ApplicationDate)[1]+"-"+appHandle.ReplaceString(Profile7CommonLibrary.GetApplicationTime(),":","")+"-Account.txt"; ;
                
            }
           
        }

            public virtual void EnterHoldTypefromOption(string holdtype)
            {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownHoldtype))
            {
                if(!string.IsNullOrEmpty(holdtype))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownHoldtype,holdtype);
                }
            }

        }
    }
}



         
