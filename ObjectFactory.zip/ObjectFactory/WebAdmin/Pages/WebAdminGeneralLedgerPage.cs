using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.Util;
using System.Collections.Generic;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminGeneralLedgerPage
    {

        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string drpDownGeneralLedgerAccountType = "Xpath;//select[@name='generalLedgerType']";
        private static string btnAdd = "Xpath;//input[@name='add']";
        private static string lblGeneralLedgerAccount = "Xpath;//*[@class='fieldLabel'][contains(.,'General Ledger Account')]/following-sibling::td/input";
        private static string drpdwnGeneralLedgerAccountType = "Xpath;//*[@class='fieldLabel'][contains(.,'General Ledger Account Type')]/following-sibling::td/select";
        private static string lblDescription = "Xpath;//*[@class='fieldLabel'][contains(.,'Description')]/following-sibling::td/input";
        private static string chkBoxBaseLedgerAccountOnly = "Xpath;//*[@class='fieldLabel'][contains(.,'Base Ledger Account Only')]/following-sibling::td/input";
        private static string btnSubmit = "Xpath;//input[@name='submit']";
        private static string drpDownProductClass = "Xpath;//select[@name='productClass']";
        private static string drpDownProductGroup = "Xpath;//select[@name='productGroup']";
        private static string btnSearch = "Xpath;//input[@name='search']";
        private static string LabelGeneralLedgerSetCode = "Xpath;//*[@class='fieldLabel'][contains(.,'General Ledger Set Code')]/following-sibling::td/input";
        private static string LabelDescription = "Xpath;//*[@class='fieldLabel'][contains(.,'Description')]/following-sibling::td/input";
        private static string drpDownPrincipalBalance = "Xpath;//select[@name='UTBLGLSC_DGL1']";
        private static string drpDownNegativePrincipalBalance = "Xpath;//select[@name='UTBLGLSC_DGLNB']";
        private static string drpDownUnauthorizedNegativePrincipalBalance = "Xpath;//select[@name='UTBLGLSC_DGLUNANB']";
        private static string drpDownAccruedInterest = "Xpath;//select[@name='UTBLGLSC_DGL2']";
        private static string drpDownAccruedInterestonAuthorizedNegativeBalance = "Xpath;//select[@name='UTBLGLSC_DGLNI']";
        private static string drpDownAccruedInterestonUnauthorizedNegativeBalance = "Xpath;//select[@name='UTBLGLSC_DGLUNANI']";
        private static string drpDownEscrowSuspense = "Xpath;//select[@name='UTBLGLSC_DGL5']";
        private static string drpDownFederalWithholding = "Xpath;//select[@name='UTBLGLSC_DGL4']";
        private static string drpDownFATCAWithholding = "Xpath;//select[@name='UTBLGLSC_DGLFATCAWTH']";
        private static string drpDownUncreditedAvailableInterest = "Xpath;//select[@name='UTBLGLSC_DGLIANC']";
        private static string drpDownResidualInterest = "Xpath;//select[@name='UTBLGLSC_DGLRI']";
        private static string drpDownTaxonNegativeInterest = "Xpath;//select[@name='UTBLGLSC_DGLNTX']";
        private static string drpDownInterestExpense = "Xpath;//select[@name='UTBLGLSC_DGLI']";
        private static string drpDownInterestIncomeNegativeBalance = "Xpath;//select[@name='UTBLGLSC_DGLII']";
        private static string drpDownPenaltyIncome = "Xpath;//select[@name='UTBLGLSC_DGL3']";
        private static string drpDownServiceFeeIncome = "Xpath;//select[@name='UTBLGLSC_DGLF']";
        private static string drpDownAccruedInterestNegativeRate = "Xpath;//select[@name='UTBLGLSC_DEPNEGACCRINTPOSBAL']";
        private static string drpDownInterestExpenseNegativeRate = "Xpath;//select[@name='UTBLGLSC_DEPINTEXPENSENEGBAL']";
        private static string drpDownInterestIncomeNegativeRate = "Xpath;//select[@name='UTBLGLSC_DEPINTINCOMEPOSBAL']";
        private static string drpDownAccruedInterestonNegativeBalanceNegativeRate = "Xpath;//select[@name='UTBLGLSC_DEPPOSACCRINTNEGBAL']";
        private static string drpDownAccruedInterestonUncollected = "Xpath;//select[@name='UTBLGLSC_DGLUNC']";
        private static string drpDownAccruedInterestonAvailableInterest = "Xpath;//select[@name='UTBLGLSC_DGLAI']";
        private static string drpDownStateWithholding = "Xpath;//select[@name='UTBLGLSC_DGLSTWH']";
        private static string msgAccountCreated = "Xpath;//*[@class='msg-box']/descendant::p";

        public virtual string CreateGLAccount(string Account, int NumberofAccounts, bool flag = false)
        {
            List<string> AccountList = new List<string>();
            for (int i = 0; i < NumberofAccounts;)
            {
                string sRandomValue = RandomNumberGenerator.Generate();
                sRandomValue = sRandomValue.Substring(0, sRandomValue.Length - 1);

                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpDownGeneralLedgerAccountType))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpDownGeneralLedgerAccountType, Account);
                    appHandle.ClickObjectViaJavaScript(btnAdd);
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(lblGeneralLedgerAccount))
                    {
                        appHandle.Set_field_value(lblGeneralLedgerAccount, sRandomValue);
                        appHandle.Set_field_value(lblDescription, sRandomValue);
                        appHandle.SelectDropdownSpecifiedValue(drpdwnGeneralLedgerAccountType, Account);

                        if (flag == true)
                        {
                            appHandle.ClickObjectViaJavaScript(chkBoxBaseLedgerAccountOnly);
                        }
                        string GLAccountNumber = appHandle.Get_Label_Text(lblGeneralLedgerAccount);
                        appHandle.ClickObjectViaJavaScript(btnSubmit);
                        if (this.ValidateGeneralLedgerAccountSuccess())
                        {
                            i++;
                            AccountList.Add(GLAccountNumber);
                        }
                    }
                }
            }
            string combindedAccounts = string.Join("-", AccountList);
            return combindedAccounts;
        }

        public virtual string CreateSetCodes(string ProductClass, string ProductGroup, string BalanceDetailswithSemecolonDelimited)
        {
            string SetCode = "";
   
            string sRandomValue = RandomNumberGenerator.Generate();
            sRandomValue = sRandomValue.Substring(0, sRandomValue.Length - 1);
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpDownProductClass))
            {
                appHandle.SelectDropdownSpecifiedValue(drpDownProductClass, ProductClass);
                appHandle.SelectDropdownSpecifiedValue(drpDownProductGroup, ProductGroup);
                appHandle.ClickObjectViaJavaScript(btnSearch);
            }
            appHandle.ClickObjectViaJavaScript(btnAdd);
            appHandle.Set_field_value(LabelGeneralLedgerSetCode, sRandomValue);
            appHandle.Set_field_value(LabelDescription, sRandomValue);
            
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(BalanceDetailswithSemecolonDelimited);
            Report.Info("GL setcode details are entered",true,appHandle);
            this.ClickOnSubmit();
            if(this.ValidateGeneralLedgerSetCodeSuccess())
            {
                
                SetCode = sRandomValue;
            }
            else
            {
            
            }
            return SetCode;
        }

        public virtual void ClickOnSubmit()
        {
            appHandle.ClickObjectViaJavaScript(btnSubmit);
        }

        public virtual void ValidateSuccessMessage()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(""))
            {

            }
        }
        public virtual bool ValidateGeneralLedgerAccountSuccess()
        {
            bool flag = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(msgAccountCreated))
            {
                if (appHandle.Get_Label_Text(msgAccountCreated).Contains(Data.Get("GLAccountSuccess")))
                {
                    flag = true;
                }
                else if (appHandle.Get_Label_Text(msgAccountCreated).Contains(Data.Get("GLAccountFailure")))
                {
                    flag = false;
                }
            }
            return flag;
        }

        public virtual bool ValidateGeneralLedgerSetCodeSuccess()
        {
            bool flag = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(msgAccountCreated))
            {
                if (appHandle.Get_Label_Text(msgAccountCreated).Contains(Data.Get("GLSetCodeSuccess")))
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            return flag;
        }
    }
}