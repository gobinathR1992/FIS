using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Collections.Generic;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class MiscellaneousFieldsPage
    {
        WebApplication appHandle;
        public static string txtTransactionDescription = "XPath;//input[@name='TRN_DES']";
        public static string drpGroup = "XPath;//select[@name='TRN_GRP']";
        public static string drpField1Name = "XPath;//select[@name='TRN_MFVAR1']";
        public static string txtField1Description = "XPath;//input[@name='TRN_MFDSC1']";
        public static string chkField1Required = "XPath;//input[@name='TRN_MFREQ1']";
        public static string txtField1Table = "XPath;//input[@name='TRN_MFTBL1']";
        public static string txtField1Default = "XPath;//input[@name='TRN_MFDFT1']";
        public static string drpField1FunctionQuery = "XPath;//select[@name='TRN_MFQRY1']";
        public static string txtField1MisPreProcessor = "XPath;//input[@name='TRN_MFPRE1']";
        public static string txtField1MisPostProcessor = "XPath;//input[@name='TRN_MFPP1']";
        public static string drpField2Name = "XPath;//select[@name='TRN_MFVAR2']";
        public static string txtField2Description = "XPath;//input[@name='TRN_MFDSC2']";
        public static string chkField2Required = "XPath;//input[@name='TRN_MFREQ2']";
        public static string txtField2Table = "XPath;//input[@name='TRN_MFTBL2']";
        public static string txtField2Default = "XPath;//input[@name='TRN_MFDFT2']";
        public static string drpField2FunctionQuery = "XPath;//select[@name='TRN_MFQRY2']";
        public static string txtField2MisPreProcessor = "XPath;//input[@name='TRN_MFPRE2']";
        public static string txtField2MisPostProcessor = "XPath;//input[@name='TRN_MFPP2']";
        public static string drpField3Name = "XPath;//select[@name='TRN_MFVAR3']";
        public static string txtField3Description = "XPath;//input[@name='TRN_MFDSC3']";
        public static string chkField3Required = "XPath;//input[@name='TRN_MFREQ3']";
        public static string txtField3Table = "XPath;//input[@name='TRN_MFTBL3']";
        public static string txtField3Default = "XPath;//input[@name='TRN_MFDFT3']";
        public static string drpField3FunctionQuery = "XPath;//select[@name='TRN_MFQRY3']";
        public static string txtField3MisPreProcessor = "XPath;//input[@name='TRN_MFPRE3']";
        public static string txtField3MisPostProcessor = "XPath;//input[@name='TRN_MFPP3']";
        public static string drpField4Name = "XPath;//select[@name='TRN_MFVAR4']";
        public static string txtField4Description = "XPath;//input[@name='TRN_MFDSC4']";
        public static string chkField4Required = "XPath;//input[@name='TRN_MFREQ4']";
        public static string txtField4Table = "XPath;//input[@name='TRN_MFTBL4']";
        public static string txtField4Default = "XPath;//input[@name='TRN_MFDFT4']";
        public static string drpField4FunctionQuery = "XPath;//select[@name='TRN_MFQRY4']";
        public static string txtField4MisPreProcessor = "XPath;//input[@name='TRN_MFPRE4']";
        public static string txtField4MisPostProcessor = "XPath;//input[@name='TRN_MFPP4']";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To enter value in Edit Feild in MiscellaneousFieldsPage.
        /// <param name = "Feild Name"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetEditValue(sfieldname,sfieldvalue)</example>
        public virtual void SetEditValue(string sfieldname, string sfieldvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sfieldname);
                AppHandle.WaitUntilElementClickable(sfieldname);
                AppHandle.Set_field_value(sfieldname, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select dropdown value in MiscellaneousFieldsPage.
        /// <param name = "dropdown Name"></param> 
        /// <param name = "dropdown Value"></param> 
        /// <returns></returns>
        /// <example>SelectDropdownValue(sdrpname,sdrpvalue)</example>
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sdrpname);
                AppHandle.WaitUntilElementClickable(sdrpname);
                AppHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
        /// <summary>
        /// To select checkbox on in MiscellaneousFieldsPage.
        /// <param name = "checkbox"></param> 
        /// <returns></returns>
        /// <example>SelectCheckboxOn(schkname)</example>
        public virtual void SelectCheckboxOn(string schkname)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(schkname);
                AppHandle.WaitUntilElementClickable(schkname);
                AppHandle.Select_CheckBox(schkname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select checkbox off in MiscellaneousFieldsPage.
        /// <param name = "checkbox"></param> 
        /// <returns></returns>
        /// <example>SelectCheckboxOff(schkname)</example>
        public virtual void SelectCheckboxOff(string schkname)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(schkname);
                AppHandle.WaitUntilElementClickable(schkname);
                AppHandle.DeSelectCheckBox(schkname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To Enter Details in MiscellaneousFieldsPage
        /// <param name="lstMisFlddetails"></param>
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.txtTransactionDescription + "|field|CD Decr Uncollected Int Accrued"); 
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.txtField1Table + "|field|Teller Comment"); 
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.txtField2Description + "|field|Teller Comment"); 
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.chkField4Required + "|checkbox|on");
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.chkField2Required + "|checkbox|off");
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.drpGroup + "|dropdown|Certificates");
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.drpField1Name + "|dropdown|Teller Comment");
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.drpField2Name + "|dropdown|Teller Comment");
        /// <returns></returns>
        /// <example>EnterDetailsinMiscellaneousFieldsPage(lstMisFlddetails)</example>
        public virtual void EnterDetailsinMiscellaneousFieldsPage(List<string> lstMisFlddetails)
        {
            try
            {
                string[] arrserplnDetails = new string[3];
                for (int i = 0; i < lstMisFlddetails.Count; i++)
                {
                    arrserplnDetails = AppHandle.SplitString(lstMisFlddetails[i], "|"); //separator
                    switch (arrserplnDetails[1].ToUpper())
                    {
                        case "FIELD":
                            WebAdminPageFactory.MiscellaneousFieldsPage.SetEditValue(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "DROPDOWN":
                            WebAdminPageFactory.MiscellaneousFieldsPage.SelectDropdownValue(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "CHECKBOX":
                            if (arrserplnDetails[2].ToUpper() == "ON")
                                WebAdminPageFactory.MiscellaneousFieldsPage.SelectCheckboxOn(arrserplnDetails[0]);
                            else
                                WebAdminPageFactory.MiscellaneousFieldsPage.SelectCheckboxOff(arrserplnDetails[0]);
                            break;
                    }
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

    }

}