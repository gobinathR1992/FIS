using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;



namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class TransactionCodeConfigurationPage
    {
        WebApplication appHandle;
        public static string drpTransactionCodeClass = "XPath;//select[@name='transactionCodeClass']";
        public static string drpTransactionCodeGroup = "XPath;//select[@name='transactionCodeGroup']";
        public static string tblTransactionCodesList = "XPath;//div[contains(@id,'transaction-code-list')][contains(@class,'dataTables')]";
        //ServiceFee
        public static string drpServiceFee ="XPath;//select[@name='PRODCTL_DRTRSC']";
        public static string drpATMPOSOverdraftFee = "XPath;//select[@name='PRODCTL_DRAPOD']";

        public static string buttonSubmit="Xpath;//*[@name='submit']";

        public static string MSGOBJ = "Xpath;//div[@class='msg-box']/descendant::p[1]";

        public static string miscfeeamt = "Xpath;//select[@name='PRODCTL_ODTC1']";

        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To select dropdown value in RelationshipCodePage.
        /// <param name = "dropdown Name"></param> 
        /// <param name = "dropdown Value"></param> 
        /// <returns></returns>
        /// <example>SelectDropdownValue(sdrpname,sdrpvalue)</example>
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sdrpname);
                AppHandle.WaitUntilElementClickable(sdrpname);
                AppHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select Transaction Code in TransactionCodesListTable.
        /// <param name = "Code"></param> 
        /// <returns></returns>
        /// <example>SelectTransactionCodeinTransactionCodesListTable("DPC")</example>
        public virtual void SelectTransactionCodeinTransactionCodeTable(string Code)
        {
            try
            {
                string obj = "XPath;//div[contains(@id,'transaction-code-list')][contains(@class,'dataTables')]//input[@name='TRN_ETC'][@value='" + Code + "']";
                AppHandle.WaitUntilElementVisible(tblTransactionCodesList);
                AppHandle.WaitUntilElementClickable(tblTransactionCodesList);
                AppHandle.ClickObject(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To check Transaction Code Exists in TransactionCodesListTable.
        /// <param name = "Code"></param> 
        /// <returns>bool</returns>
        /// <example>bool val = CheckTransactionCodeExistsinTransactionCodesListTable("DPC")</example>
        public virtual bool CheckTransactionCodeExistsinTransactionCodeTable(string Code)
        {
            bool bcheck = false;
            try
            {
                string obj = "XPath;//div[contains(@id,'transaction-code-list')][contains(@class,'dataTables')]//input[@name='TRN_ETC'][@value='" + Code + "']";
                AppHandle.WaitUntilElementVisible(tblTransactionCodesList);
                AppHandle.WaitUntilElementClickable(tblTransactionCodesList);
                bcheck = AppHandle.IsObjectExists(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }
        public virtual void UpdateServiceFeeDetails(string Servicefee,string ATMOverdraftFee,string MiscFee="")
        {
            AppHandle.WaitUntilElementVisible(drpServiceFee);
            AppHandle.WaitUntilElementClickable(drpServiceFee);
            AppHandle.SelectDropdownSpecifiedValueByPartialText(drpServiceFee,Servicefee);
            AppHandle.SelectDropdownSpecifiedValueByPartialText(drpATMPOSOverdraftFee,ATMOverdraftFee);
            AppHandle.SelectDropdownSpecifiedValueByPartialText(miscfeeamt,MiscFee);


        }
        public virtual void ClickOnSubmit()
        {
            AppHandle.WaitUntilElementExists(buttonSubmit);
            AppHandle.ClickObjectViaJavaScript(buttonSubmit);
        }
        public virtual bool VerifyMessageInWebAdminTransactionCodePage()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (AppHandle.GetObjectText(MSGOBJ).Equals(Data.Get("GLOBAL_INFORMATION_UPDATED")))                
                {

                    Result = true;
                }
            }

            return Result;
        }

        


    }


    }

