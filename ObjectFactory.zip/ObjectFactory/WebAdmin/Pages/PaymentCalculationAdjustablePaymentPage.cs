using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class PaymentCalculationAdjustablePaymentPage
    {
        WebApplication apphandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string dropdownPaymentChangeMethod="XPath;//select[@name='PRODDFTL_PCHM']";
        public static string txtChangeoffsetdays="XPath;//input[@name='PRODDFTL_PCOFF']";
        public static string txtChangeFrequency="XPath;//input[@name='PRODDFTL_PCFRE']";
        public static string buttonSubmit="XPath;//input[@name='submit']";


        public virtual bool UpdateDataInAdjustablePaymentOfPaymentCalculation(string paymentchangemethod,string offsetdays,string changefrequency)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownPaymentChangeMethod);
            apphandle.SelectDropdownSpecifiedValue(dropdownPaymentChangeMethod,paymentchangemethod);
            apphandle.Set_field_value(txtChangeoffsetdays,offsetdays);
            apphandle.Set_field_value(txtChangeFrequency,changefrequency);
            apphandle.ClickObjectViaJavaScript(buttonSubmit);
            return apphandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

                

        }




    
    
    }

}