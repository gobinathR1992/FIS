using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminMasterPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        RandomNumberGenerator RandomNumberGenerator;
        public static string SecurityConfigurationLink = "Xpath;.//*[contains(@class,'menuGroupHeading')][contains(., 'Security Configuration')]";
        public static string ProductFactoryLink = "Xpath;.//*[contains(@class,'menuGroupHeading')][contains(., 'Product Factory')]";
        public static string ProductsLink = "Xpath;.//*[contains(@class,'menuSub')][contains(., 'Products')][contains(@onclick, 'productConfigurationList')]";
        private static string UserUserclassMaintenanceLink = "XPATH;.//*[contains(@class,'menuSub')][contains(., 'Userclass Maintenance')]";
        //private static string UserMaintenanceTab = "XPATH;.//*[contains(@class,'tab')][contains(., 'User Maintenance')]";
        private static string UserclassMaintenanceTab = "XPATH;.//*[contains(@class,'tab')][contains(., 'Userclass Maintenance')]";
        //private static string UserclassPermissionTab = "XPATH;.//*[contains(@class,'tab')][contains(., 'Userclass Permissions')]";
        private static string AddButton = "XPATH;//INPUT[@name='add']";
        private static string UserAddUserIdField = "XPATH;//INPUT[@name='SCAU_UID']";
        private static string UserAddUserFullNameField = "XPATH;//INPUT[@name='agentName']";
        private static string UserClassDropdown = "XPATH;//select[@name='userClass']";
        private static string PasswordMaintenancePasswordField = "XPATH;//INPUT[@name='USERSECUREDDATA_ENCRYPTEDPWDOLD']";
        private static string PasswordMaintenanceConfirmPasswordField = "XPATH;//INPUT[@name='passwordVerify']";
        private static string OnlineTellersTransactionSuspenceCreditDropdown = "XPATH;//Select [@name='SCAU_TSCR']";
        private static string OnlineTellersTransactionSuspenceDebitDropdown = "XPATH;//Select [@name='SCAU_TSDR']";
        private static string OnlineTellersPostingEnvironmentDropdown = "XPATH;//Select [@name='SCAU_CURRENV']";
        public static string SubmitButton = "XPATH;//INPUT[@value='Submit']";
        public static string AddButton1 = "XPATH;//INPUT[@value='Add']";
        private static string UserMaintenanceAuthorizationPasswordField = "XPATH;//INPUT[@name='agentAuthorization']";
        private static string UserMaintenanceAuthorizationSubmitButton = "XPATH;//button[text()='Submit']";
        //private static string WebAdminLogOutButton = "XPATH;//button[@name='logout']";
        private static string UserCreationSuccessfulText = "XPath;.//*[@class='info'][contains(.,'The user has been created.')]";
        private static string RecordExistText = "XPath;////*[@class='msg-box']/descendant::p";
        private static string UserListTable = "XPath;.//*[contains(@class,'ledgerScrollable dataTable')]/tbody";
        private static string UserListTableUserClassDescriptionField = "name;SCAU0_DESC";
        private static string OverallCashMaximumField = "name;SCAU0_OACMAX";
        private static string EditButton = "Name;edit";
        private static string BranchCodeDropdown = "XPATH;//Select [@name='SCAU_BRCD']";
        private static string UserModificationSuccessfulText = "XPATH;.//*[@class='info'][contains(.,'The user has been modified.')]";
        private static string OverAllCashMaximumField = "XPATH;.//INPUT[@name='SCAU0_OACMAX']";
        private static string UserClassModificationSuccessfulText = "XPATH;.//*[@class='info'][contains(.,'The userclass has been modified.')]";
        private static string ProductClassDropDown = "name;productClass";
        private static string ProductGroupDropDown = "name;productGroup";
        private static string SearchButton = "name;search";
        private static string ProdListTable = "XPath;.//*[contains(@class,'dataTables')][contains(@id,'products-list')]";
        private static string CopyButton = "name;copy";
        private static string ProductCopyNewTypeField = "XPath;.//*[contains(@name,'toProductType')]";
        private static string ProductalreadyExist = "XPath;//div[@class='error']/*[contains(.,'already exists')]";
        //06/14/2018
        private static string StatementsTab = "XPath;//*[contains(@class,'tab')][contains(.,'Statements')]";
        private static string GeneralInformationSuppressBalancePrintCheckbox = "XPath;.//INPUT[@type='checkbox'][@name='PRODCTL_BALSUP']";
        private static string TransactionProcessingTab = "XPath;//*[contains(@class,'tab')][contains(.,'Transaction Processing')]";
        private static string FundsTransferPermitPaymentOrderCheckbox = "XPath;.//INPUT[@type='checkbox'][@name='PRODDFTD_EFTDEB']";
        private static string USRegulatoryTab = "XPath;//*[contains(@class,'tab')][contains(.,'U.S. Regulatory')]";
        private static string InterestTab = "XPath;//*[contains(@class,'tab')][contains(.,'Interest')]";
        public static string RateDeterminationLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'RateDetermination')]";
        private static string TieredIndexValuesLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'TieredIndex')]";
        private static string PostingOptionsLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'PostingOption')]";
        private static string NegativeInterestLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'NegativeInterest')]";
        private static string TermAccountsTab = "XPath;//*[contains(@class,'tab')][contains(.,'Term Accounts')]";
        private static string PenaltyLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'Penalty')]";
        private static string NoticeAccountsLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'NoticeAccounts')]";
        private static string ScheduledDepositsLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'ScheduledDeposits')]";
        private static string ServiceFeesTab = "XPath;//*[contains(@class,'tab')][contains(.,'Service Fees')]";
        private static string CommercialAnalysisLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'CommercialAnalysis')]";
        private static string CheckbookTab = "XPath;//*[contains(@class,'tab')][contains(.,'Checkbook')]";
        private static string SavingsIncentiveTab = "XPath;//*[contains(@class,'tab')][contains(.,'Savings Incentive')]";
        private static string FundsAvailabilityTab = "XPath;//*[contains(@class,'tab')][contains(.,'Funds Availability')]";
        private static string OverDraftsTab = "XPath;//*[contains(@class,'tab')][contains(.,'Overdraft')]";
        private static string LinkedOverdraftLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'LinkedOverdraft')]";
        private static string InvestmentSweepTab = "XPath;//*[contains(@class,'tab')][contains(.,'Investment Sweep')]";
        private static string EscrowTab = "XPath;//*[contains(@class,'tab')][contains(.,'Escrow')]";
        private static string TransactionCodesTab = "XPath;//*[contains(@class,'tab')][contains(.,'Transaction Codes')]";
        private static string BackofficeLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'BackOffice')]";
        private static string ServiceFeesLink = "XPath;//*[contains(@class,'tabSub')][contains(@href,'ServiceFees')]";
        private static string BranchAuthorizationTab = "XPath;//*[contains(@class,'tab')][contains(.,'Branch Authorization')]";
        private static string TargetBalanceAccountsTab = "XPath;//*[contains(@class,'tab')][contains(.,'Branch Authorization')]";
        private static string GeneralTab = "XPath;//*[contains(@class,'tab')][contains(.,'General')]";
        private static string DeleteButton = "name;delete";
        private static string ProductDeletionMsg = "XPath;//*[contains(@class,'msg-box')][contains(.,'The product has been deleted')]";
        //06/15/2018
        private static string DepositUSregulatoryTabMsg = "XPath;//h1[text()[contains(.,'U.S. Regulatory')]]";
        private static string DepositInterestTabMsg = "XPath;//h2[text()[contains(.,'Daily Calculation')]]";
        private static string DepositInterestTabMsg2 = "XPath;//h2[text()[contains(.,'Promotional Rate')]]";
        private static string DepositInterestTabMsg3 = "XPath;//h2[text()[contains(.,'Account Tiered Index Values')]]";
        private static string DepositInterestTabMsg4 = "XPath;//h1[text()[contains(.,'Posting Options')]]";
        private static string DepositInterestTabMsg5 = "XPath;//h1[text()[contains(.,'Negative Interest')]]";
        private static string TransactionProcessingTabMsg = "XPath;//h2[text()[contains(.,'Funds Transfer')]]";
        private static string DepositTermAccountsTabMsg = "XPath;//h2[text()[contains(.,'Maturity Information')]]";
        private static string DepositTermAccountsTabMsg2 = "XPath;//h1[text()[contains(.,'Penalty')]]";
        private static string DepositTermAccountsTabMsg3 = "XPath;//h1[text()[contains(.,'Notice Accounts')]]";
        private static string DepositTermAccountsTabMsg4 = "XPath;//h1[text()[contains(.,'Scheduled Deposits')]]";
        private static string DepositServiceFeesTabMsg = "XPath;//h1[text()[contains(.,'Service Fees')]]";
        private static string DepositServiceFeesTabMsg2 = "XPath;//h1[text()[contains(.,'Commercial Analysis')]]";
        private static string DepositCheckBookTabMsg = "XPath;//h1[text()[contains(.,'Checkbook')]]";
        private static string DepositSavingsIncentiveTabMsg = "XPath;//h1[text()[contains(.,'Checkbook')]]";
        private static string DepositFundsAvailabilityTabMsg = "XPath;//h1[text()[contains(.,'Funds Availability')]]";
        private static string DepositOverDraftTabMsg = "XPath;//h1[text()[contains(.,'Authorized')]]";
        private static string DepositOverDraftTabMsg2 = "XPath;//h2[text()[contains(.,'Linked Account Overdraft')]]";
        private static string DepositInvestmentSweepTabMsg = "XPath;//h1[text()[contains(.,'Investment Sweep')]]";
        private static string DepositStatementsTabMsg = "XPath;//h1[text()[contains(.,'Statements')]]";
        private static string DepositEscrowTabMsg = "XPath;//h1[text()[contains(.,'Escrow')]]";
        private static string DepositTransactionCodeTabMsg = "XPath;//h1[text()[contains(.,'Adjustments')]]";
        private static string DepositTransactionCodeTabMsg2 = "XPath;//h1[text()[contains(.,'Back Office')]]";
        private static string DepositTransactionCodeTabMsg3 = "XPath;//h1[text()[contains(.,'Service Fees')]]";
        private static string DepositBranchAuthorizationTabMsg = "XPath;//h2[text()[contains(.,'Authorized Branches')]]";
        private static string DepositTargetBalanceAccountsTabMsg = "XPath;//h2[text()[contains(.,'Target Balance Accounts')]]";
        private static string DepositGeneralTabMsg = "XPath;//h2[text()[contains(.,'General Information')]]";
        private static string BillingStatementBillPrintDesignDropdown = "XPath;.//Select[contains(@name,'PRODCTL_BFP')]";
        private static string StatementsSummaryStatementDescriptionField = "XPath;.//Select[contains(@name,'PRODCTL_STMDSCS')]";
        private static string LoanGeneralInformationCurrencyDropdown = "XPath;.//Select[contains(@name,'PRODDFTL_CRCD')]";
        private static string InformationUpdateMsg = "XPath;.//*[contains(@class,'info')][contains(.,'The information has been updated.')]";
        // 06/18/2018
        private static string NewAccountsTab = "XPath;//*[contains(@class,'tab')][contains(.,'New Accounts')]";
        private static string LoanNewAccountsTabMsg = "XPath;//h1[contains(.,'New Accounts')]";
        private static string PaymentApplicationTab = "XPath;//*[contains(@class,'tab')][contains(.,'Payment Application')]";
        private static string PaymentApplicationTabMsg = "XPath;//h1[contains(.,'Payment Application')]";
        private static string PaymentCalculationTab = "XPath;//*[contains(@class,'tab')][contains(.,'Payment Calculation')]";
        private static string PaymentCalculationTabMsg1 = "XPath;//h1[contains(.,'Calculation Options')]";
        public static string RevolvingCreditPaymentLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Revolving Credit Payment')]";
        private static string PaymentCalculationTabMsg2 = "XPath;//h1[contains(.,'Revolving Credit Payment')]";
        private static string AdjustablePaymentLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Adjustable Payment')]";
        private static string PaymentCalculationTabMsg3 = "XPath;//h1[contains(.,'Adjustable Payment')]";
        private static string AdjustablePaymentLimitsLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Adjustable Payment Limits')]";
        private static string PaymentCalculationTabMsg4 = "XPath;//h1[contains(.,'Adjustable Payment Limits')]";
        private static string GLCategoriesTab = "XPath;//*[contains(@class,'tab')][contains(.,'G/L Categories')]";
        private static string GLCategoriesTabMsg = "XPath;//h1[contains(.,'G/L Categories')]";
        private static string LoanInterestTabMsg1 = "XPath;//h1[contains(.,'Calculation')]";
        private static string LoanInterestTabMsg2 = "XPath;//h1[contains(.,'Rate Determination')]";
        private static string CapitalizedInterestProcessingLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Capitalized Interest Processing')]";
        private static string LoanInterestTabMsg3 = "XPath;//h1[contains(.,'Capitalized Interest Processing')]";
        private static string MaturityRenewalTab = "XPath;//*[contains(@class,'tab')][contains(.,'Maturity/Renewal')]";
        private static string MaturityRenewalTabMsg1 = "XPath;//h1[contains(.,'Maturity Processing')]";
        private static string RenewalProcessingLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Renewal Processing')]";
        private static string MaturityRenewalTabMsg2 = "XPath;//h1[contains(.,'Renewal Processing')]";
        private static string DelinquencyTab = "XPath;//*[contains(@class,'tab')][contains(.,'Delinquency')]";
        private static string DelinquencyTabMsg1 = "XPath;//h1[contains(.,'Options')]";
        private static string NoticeOffsetDaysLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Notice Offset Days')]";
        private static string DelinquencyTabMsg2 = "XPath;//h1[contains(.,'Notice Offset Days')]";
        private static string NoticeSelectionLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Notice Selection')]";
        private static string DelinquencyTabMsg3 = "XPath;//h1[contains(.,'Notice Selection')]";
        private static string CountersDaysLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Counters - Days')]";
        private static string DelinquencyTabMsg4 = "XPath;//h1[contains(.,'Counters - Days')]";
        private static string EscrowAnalysisTab = "XPath;//*[contains(@class,'tab')][contains(.,'Escrow Analysis')]";
        private static string EscrowAnalysisTabMsg = "XPath;//h1[contains(.,'Escrow Analysis')]";
        private static string TransactionCodesTabMsg1 = "XPath;//h1[contains(.,'Adjustments')]";
        private static string PaymentsLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Payments')]";
        private static string PayoffLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Payoff')]";
        private static string FeesLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Fees')]";
        private static string EscrowLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Escrow')]";
        private static string TransactionCodesTabMsg2 = "XPath;//h1[contains(.,'Payments')]";
        private static string TransactionCodesTabMsg3 = "XPath;//h1[contains(.,'Payoff')]";
        private static string TransactionCodesTabMsg4 = "XPath;//h1[contains(.,'Fees')]";
        private static string TransactionCodesTabMsg5 = "XPath;//h1[contains(.,'Escrow')]";
        private static string CreditCardsTab = "XPath;//*[contains(@class,'tab')][contains(.,'Credit Cards')]";
        private static string CreditCardsTabMsg = "XPath;//h1[contains(.,'Credit Cards')]";
        public static string TableConfigurationLink = "Xpath;.//*[contains(@class,'menuGroupHeading')][contains(., 'Table Configuration')]";
        public static string Institutionvariablesink = "Xpath;.//*[contains(@class,'menuSub')][contains(., 'Products')][contains(@onclick, 'institutionVariables')]";
        // private static string InstitutionGeneralTabMsg = "XPath;//h2[contains(.,'Institution Information')]";
        private static string InstitutionUSRegulatoryTabMsg = "XPath;//h2[contains(.,'Year-End Reporting')]";
        public static string USRegulatory2Link = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Regulatory 2')]";
        private static string InstitutionUSRegulatoryTabMsg2 = "XPath;//h2[contains(.,'Regulation CC Control Options')]";
        public static string OTSThriftFinancialReportLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'OTS Thrift Financial Report')]";
        private static string InstitutionUSRegulatoryTabMsg3 = "XPath;//h2[contains(.,'Schedule DI')]";
        private static string AccountsTab = "XPath;//*[contains(@class,'tab')][contains(.,'Accounts')]";
        private static string CustomerInformationMsg = "XPath;//h2[contains(.,'Customer Information')]";
        public static string DepositLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'OTS Thrift Financial Report')]";
        private static string AccountsTabMsg2 = "XPath;//h2[contains(.,'Interest Processing')]";
        public static string RetirementLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Retirement')]";
        private static string AccountsTabMsg3 = "XPath;//h2[contains(.,'Default Reason Codes')]";
        public static string LoanLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Loan')]";
        private static string AccountsTabMsg4 = "XPath;//h2[contains(.,'Loan Accrual Adjustments')]";
        public static string LoanReportingLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Loan Reporting')]";
        private static string AccountsTabMsg5 = "XPath;//h2[contains(.,'Escrow Processing')]";
        public static string DelinquencyClassificationLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Delinquency Classification')]";
        private static string AccountsTabMsg6 = "XPath;//h2[contains(.,'Provision Processing')]";
        private static string InstitutionTransactionProcessingTabMsg1 = "XPath;//h2[contains(.,'Teller')]";
        private static string InstitutionTransactionProcessingTabMsg2 = "XPath;//h2[contains(.,'Random Payment Order Processing')]";
        private static string InstitutionTransactionProcessingTabMsg3 = "XPath;//h2[contains(.,'Foreign Currency Posting')]";
        private static string PaymentSystemLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Payment System')]";
        private static string ForeignCurrencyLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'Foreign Currency')]";
        private static string SystemTab = "XPath;//*[contains(@class,'tab')][contains(.,'System')]";
        private static string SystemTabMsg1 = "XPath;//h1[contains(.,'Integrity Information')]";
        private static string SystemManagementLink = "XPath;//*[contains(@class,'tabSub')][contains(text(),'System Management')]";
        private static string SystemTabMsg2 = "XPath;//h2[contains(.,'Dayend Processing')]";
        private static string GeneralLedgerTab = "XPath;//*[contains(@class,'tab')][contains(.,'General Ledger')]";
        private static string GeneralLedgerTabMsg = "XPath;//h2[contains(.,'General Ledger')]";

        //private static string VendorManagementLink = "XPath;//td[text()='Vendor Management']";

        private static string GeneralTableManagementLink = "XPath;//td[text()='General Table Management']";
        //private static string GeneralLedgerLink = "XPath;//td[text()='General Ledger']";
        //private static string NotificationsLink = "XPath;//td[text()='Notifications']";
        //private static string UtilitiesLink = "XPath;//td[text()='Utilities']";
        // private static string CheckProcessingLink = "XPath;//td[text()='Check Processing']";
        // private static string ReportingLink = "XPath;//td[text()='Reporting']";
        //private static string ToolsLink = "XPath;//td[text()='Tools']";
        private static string ProductFactoryPackagesLink = "XPath;//td[text()='Packages']";
        public static string appdate = "Xpath;.//*[@class='right'][contains(.,'Log Out')]";
        public static string LogoutButton = "XPath;//button[@name='logout'][@type='button']";
        public static string tabProcessingOptions = "XPath;//td[contains(text(),'Processing Options')]";
        public static string tabMiscellaneousFields = "XPath;//td[contains(text(),'Miscellaneous Fields')]";
        public static string tabProcessingControlOptions = "XPath;//td[contains(text(),'Processing Control Options')]";
        public static string btnAuthorize = "XPath;//input[@name='authorize']";
        public static string btnRates = "XPath;//input[@type='submit'][@value='Rates']";
        public static string btnDelete = "Xpath;//input[@value='Delete']";
        public static string btnContinue = "name;continue";
        public static string btnCancel="Xpath;//input[@name='cancel']";
        public static string btnAdd="Xpath;//input[@name='add']";
        public static string tblTableRecordsAction = "Xpath;//table[@id='fee-plans-list']/tbody";
        public static string tblTableRecordsActionHeader = "Xpath;//div[@class='dataTables_scrollHeadInner']//table[@class='ledgerScrollable dataTable']";
        public static string lnkExemptionPlans="Xpath;//td[contains(text(),'Exemption Plans')]";
        public static string lnkRenewalProcessing="Xpath;//a[@class='tabSub']";
        public static string lnkRateDetermination="Xpath;//a[contains(text(),'Rate Determination')]";
        public static string lnkPostingOptions="Xpath;//a[contains(text(),'Posting Options')]";
        private static string buttonEdit="XPath;//*[@name='edit']";
        private static string buttonList = "Xpath;//*[@value='List']";
        public virtual void NavigateToCreateUserPage()
        {
            Report.Info("Navigate to Create User Page");
            appHandle.ClickObject(SecurityConfigurationLink);
            appHandle.ClickObject(UserUserclassMaintenanceLink);
            appHandle.ClickObject(AddButton);
            Report.Info("Completed Navigation to Create User Page");
        }

        public virtual String FillNewUserDetailsWebAdmin(String[] UserCredentials)
        {
            Boolean FormAuthenticationPopUp;
            Boolean RecordExistTextavailable;
            Boolean UserCreationSuccessMessageExist;
            string NewUserID = RandomNumberGenerator.Generate();
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Enter New user details");
            appHandle.Wait_for_object(SubmitButton, 5000);
            // Enter New User Details in Add User Page     
            appHandle.SelectDropdownSpecifiedValue(UserClassDropdown, UserCredentials[0]);
            appHandle.Set_field_value(UserAddUserIdField, NewUserID);
            appHandle.Set_field_value(UserAddUserFullNameField, UserCredentials[3]);
            appHandle.Set_field_value(PasswordMaintenancePasswordField, UserCredentials[1]);
            appHandle.Set_field_value(PasswordMaintenanceConfirmPasswordField, UserCredentials[1]);
            appHandle.SelectDropdownSpecifiedValue(OnlineTellersTransactionSuspenceCreditDropdown, UserCredentials[4]);
            appHandle.SelectDropdownSpecifiedValue(OnlineTellersTransactionSuspenceDebitDropdown, UserCredentials[5]);
            appHandle.SelectDropdownSpecifiedValue(OnlineTellersPostingEnvironmentDropdown, UserCredentials[6]);
            appHandle.SelectButton(SubmitButton);
            appHandle.SyncPage();
            FormAuthenticationPopUp = appHandle.IsObjectExists(UserMaintenanceAuthorizationPasswordField);
            if (FormAuthenticationPopUp == true)
            {
                appHandle.Set_field_value(UserMaintenanceAuthorizationPasswordField, UserCredentials[7]);
                appHandle.SelectButton(UserMaintenanceAuthorizationSubmitButton);
                appHandle.SyncPage();
            }
            RecordExistTextavailable = appHandle.IsObjectExists(RecordExistText);

            //Verify That User creation is successful
            UserCreationSuccessMessageExist = appHandle.IsObjectExists(UserCreationSuccessfulText);
            if (UserCreationSuccessMessageExist == true)
            {
                Report.Pass(NewUserID + ": User Created successfully.", "User Creation Successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                return NewUserID;
            }
            else
            {
                Report.Fail("User was not Created successfully.", "User Creation failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                return null;
            }


            //Verify That "The user has been created" message appears
            // if (UserCreationSuccessMessageExist==true)
            // {
            //   Report.Pass("User Created successfully", "User Creation Successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            //   return NewUserID;
            // }
            // else
            // {
            //   Report.Fail ("User was not Created successfully","User Creation failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            //   return null;
            // }
            //return NewUserID;

        }


        public virtual String FillExistingUserDetailsWebAdmin(String[] UserCredentials)
        {
            Boolean FormAuthenticationPopUp;
            Boolean UserCreationSuccessMessageExist;
            Boolean RecordExistTextavailable;
            string NewUserID = RandomNumberGenerator.Generate();
            string UserID = UserCredentials[7];

            appHandle.Wait_for_object(SubmitButton, 5000);
            // Enter User Details in Add User Page with Existing User ID        
            appHandle.Set_field_value(UserAddUserIdField, UserID);
            appHandle.Set_field_value(UserAddUserFullNameField, UserCredentials[3]);
            appHandle.SelectDropdownSpecifiedValue(UserClassDropdown, UserCredentials[0]);
            appHandle.Set_field_value(PasswordMaintenancePasswordField, UserCredentials[1]);
            appHandle.Set_field_value(PasswordMaintenanceConfirmPasswordField, UserCredentials[1]);
            appHandle.SelectDropdownSpecifiedValue(OnlineTellersTransactionSuspenceCreditDropdown, UserCredentials[4]);
            appHandle.SelectDropdownSpecifiedValue(OnlineTellersTransactionSuspenceDebitDropdown, UserCredentials[5]);
            appHandle.SelectDropdownSpecifiedValue(OnlineTellersPostingEnvironmentDropdown, UserCredentials[6]);
            appHandle.SelectButton(SubmitButton);
            appHandle.SyncPage();
            RecordExistTextavailable = appHandle.IsObjectExists(RecordExistText);

            if (RecordExistTextavailable == true)
            {
                Report.Pass("Record Already Exists is displayed", "Record Already Exists Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("Record Already Exists is not displayed", "Record Already Exists failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }

            // Enter New User ID
            appHandle.Set_field_value(UserAddUserIdField, NewUserID);
            appHandle.SelectButton(SubmitButton);
            appHandle.SyncPage();
            FormAuthenticationPopUp = appHandle.IsObjectExists(UserMaintenanceAuthorizationPasswordField);
            if (FormAuthenticationPopUp == true)
            {
                appHandle.Set_field_value(UserMaintenanceAuthorizationPasswordField, UserCredentials[2]);
                appHandle.SyncPage();
                appHandle.SelectButton(UserMaintenanceAuthorizationSubmitButton);
                appHandle.SyncPage();
            }

            //Verify That User creation is successful
            UserCreationSuccessMessageExist = appHandle.IsObjectExists(UserCreationSuccessfulText);
            if (UserCreationSuccessMessageExist == true)
            {
                Report.Pass("User Created successfully", "User Creation Successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                return NewUserID;
            }
            else
            {
                Report.Fail("User was not Created successfully", "User Creation failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                return null;
            }


        }

        public virtual void SelectUSerIDfromUserList(string NewUserID)
        {
            appHandle.SelectRadioButtonInTable(UserListTable, NewUserID);
        }
        public virtual void ModifyUserDetails(string[] UserCredentials)
        {
            string BranchCode = UserCredentials[0];
            Boolean FormAuthenticationPopUp;

            appHandle.ClickObject(EditButton);
            appHandle.SyncPage();
            // Here verification required for static field named Status. The status should be active. Mail has been sent for a native function 
            // check_cell_value_by_label

            // Modify the  Branch Code (SCAU.BRCD):  0 – Back Office and Click on Submit Button.
            appHandle.SelectDropdownSpecifiedValue(BranchCodeDropdown, BranchCode);
            appHandle.ClickObject(SubmitButton);

            FormAuthenticationPopUp = appHandle.IsObjectExists(UserMaintenanceAuthorizationPasswordField);
            if (FormAuthenticationPopUp == true)
            {
                appHandle.Set_field_value(UserMaintenanceAuthorizationPasswordField, UserCredentials[2]);
                appHandle.SelectButton(UserMaintenanceAuthorizationSubmitButton);
                appHandle.SyncPage();
            }

            Boolean UserModifiedMsgExist = appHandle.VerifyObjectText(UserModificationSuccessfulText, UserCredentials[1]);

            if (UserModifiedMsgExist == true)

            {
                Report.Pass("User Modified successfully", "User Modified successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("User was not Modified successfully", "User not modofied failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }


        }
        public virtual void VerifyBranchCode(string BranchCode)
        {
            Boolean BranchCodeSelected = appHandle.CheckValueInDropdown(BranchCodeDropdown, BranchCode);
            //Boolean BranchCodeSelected =appHandle.SelectDropdownSpecifiedValue(BranchCodeDropdown, BranchCode);
            //Boolean BranchCodeSelected = appHandle.CheckDropdownContents(BranchCodeDropdown,BranchCode);
            if (BranchCodeSelected == true)
            {
                Report.Pass("Branch code is selected as 0- Back Office", "Branch code is selected successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("Branch code is selected as 0- Back Office", "Branch code is selected successful Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }


        }

        public virtual void NavigatetoUserClassMaintenancePage()
        {
            Report.Info("Navigate to User Maintenance Page");
            appHandle.ClickObject(SecurityConfigurationLink);
            appHandle.ClickObject(UserUserclassMaintenanceLink);
            appHandle.ClickObject(UserclassMaintenanceTab);

        }

        public virtual void ModifyUserClass(string UserClass, string OverallCashMaximum)
        {
            //Select UserClass from User Class List Table
            SelectUSerIDfromUserList(UserClass);
            appHandle.ClickObject(EditButton);
            //Verify that static value  of UserClass is displayed correctly against  the field User Class. Waiting for Native function
            //check_cell_value_by_label     
            appHandle.VerifyObjectText(UserListTableUserClassDescriptionField, UserClass);
            appHandle.Set_field_value(OverallCashMaximumField, OverallCashMaximum);
            appHandle.ClickObject(SubmitButton);
            appHandle.SyncPage();
            // Verify that The userclass is modified successfully
            Boolean UserClassModification = appHandle.IsObjectExists(UserClassModificationSuccessfulText);
            if (UserClassModification == true)
            {
                Report.Pass("The User Class is modified successfully", "User Class is modified successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The User Class is not modified successfully", "User Class is not modified Failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }


        }

         public virtual void NavigatetoUserClassPage()
        {
            Report.Info("Navigate to User Maintenance Page");
            appHandle.ClickObject(SecurityConfigurationLink);
            appHandle.ClickObject(UserUserclassMaintenanceLink);
            
            
        }

        public virtual void VerifyUserClass(string OverallMaximumAmount)
        {
            Boolean OverAllCashAmount = appHandle.CheckInnerText(OverAllCashMaximumField, OverallMaximumAmount);
            if (OverAllCashAmount == true)
            {
                Report.Pass("The User Classcontains correct Over all Cash Maximum Amount", "User Class Page successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The User Class does not contain correct Over all Cash Maximum Amount", "User Class Page Failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }

        public virtual void NavigatetoProductFactoryPage()
        {
            if (!appHandle.IsObjectExists(ProductsLink))
            {
                SelectProductFactoryMenuLink();
                appHandle.Wait_for_object(ProductsLink, 3);
            }
            appHandle.SyncPage();
            SelectProductsSubMenuLink();
        }
        public virtual void SelectProductFactoryMenuLink()
        {
            appHandle.ClickObject(ProductFactoryLink);
            appHandle.SyncPage();
            appHandle.Wait_for_object(ProductsLink, 10);
        }
        public virtual void SelectProductsSubMenuLink()
        {
            appHandle.ClickObject(ProductsLink);
            appHandle.SyncPage();
            appHandle.Wait_for_object(SearchButton, 10);
        }
        public virtual void VerifyProductGroupDropDown(string[] ProductGroup)
        {
            string[] DepositProductGroup = new string[6];
            string[] LoanProductGroup = new string[7];
            DepositProductGroup[0] = ProductGroup[1];
            DepositProductGroup[1] = ProductGroup[2];
            DepositProductGroup[2] = ProductGroup[3];
            DepositProductGroup[3] = ProductGroup[4];
            DepositProductGroup[4] = ProductGroup[5];
            DepositProductGroup[5] = ProductGroup[6];
            LoanProductGroup[0] = ProductGroup[7];
            LoanProductGroup[1] = ProductGroup[8];
            LoanProductGroup[2] = ProductGroup[9];
            LoanProductGroup[3] = ProductGroup[10];
            LoanProductGroup[4] = ProductGroup[11];
            LoanProductGroup[5] = ProductGroup[12];
            LoanProductGroup[6] = ProductGroup[13];
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.SelectDropdownSpecifiedValue(ProductClassDropDown, ProductGroup[0]);
            appHandle.SyncPage();
            bool ProductGroupValidation = appHandle.CheckDropdownContents(ProductGroupDropDown, DepositProductGroup);
            if (ProductGroupValidation == true)
            {
                Report.Pass("The Deposit Product Group Verification Passed", "The Product Group Verification successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Deposit Product Group Verification was not successful ", "The Product Group Verification Failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            // Have a doubt need to clarify
            bool LoanProductGroupValidation = appHandle.CheckDropdownContents(ProductGroupDropDown, LoanProductGroup);
            if (LoanProductGroupValidation == false)
            {
                Report.Pass("The Loan Product Group Verification Passed", "The Product Group Verification successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Loan Product Group Verification was not successful", "The Loan Product Group Verification unsuccessful Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }

        /*CreateProductWithExistingRecord() :will try to create a product from standard Product and verify the error message that Product Already exist
        ProductDetails[0]= Product Class
        ProductDetails[1]= Product Group
        ProductDetails[2]= Standard Product Number

        */
        public virtual void CreateProductWithExistingRecord(string[] ProductDetails)

        {
            string ProductAlreadyExistMsg = "Product " + ProductDetails[3] + " already exists";

            NavigatetoProductFactoryPage();
            appHandle.SelectDropdownSpecifiedValue(ProductClassDropDown, ProductDetails[0]);
            appHandle.SelectDropdownSpecifiedValue(ProductGroupDropDown, ProductDetails[1]);
            appHandle.ClickObject(SearchButton);
            appHandle.SyncPage();
            appHandle.SelectRadioButtonInTable(ProdListTable, ProductDetails[2]);
            appHandle.ClickObject(CopyButton);
            appHandle.SyncPage();
            appHandle.Set_field_value(ProductCopyNewTypeField, ProductDetails[3]);
            appHandle.SelectButton(SubmitButton);
            bool ProductAlreadyExistMsgValidation = appHandle.VerifyObjectText(ProductalreadyExist, ProductAlreadyExistMsg);
            if (ProductAlreadyExistMsgValidation == true)
            {
                Report.Pass("The Copy Product with existing Product ID Verification Passed", "The Product Already Exists is displayed Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Copy Product with existing Product ID Verification Failed", "The Product Already Exists is not displayed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }



        }
        /*VerifyProduct() :In the WebAdmin, It will navigate through all the pages for the Product and verify the availability of those pages.
        ProductNo= The 

        */
        public virtual void VerifyProduct(string ProductNo)
        {
            appHandle.SelectTab(StatementsTab);
            appHandle.SyncPage();
            appHandle.Select_CheckBox(GeneralInformationSuppressBalancePrintCheckbox);
            appHandle.ClickObject(SubmitButton);
            bool UpdateMsgExist = appHandle.IsObjectExists(UserModificationSuccessfulText);
            if (UpdateMsgExist == true)
            {
                Report.Pass("The Product Modification Passed", "The Product Modification is successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Product Modification Failed", "The Product Modification Failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            appHandle.SelectTab(TransactionProcessingTab);
            appHandle.SyncPage();
            appHandle.Select_CheckBox(FundsTransferPermitPaymentOrderCheckbox);
            appHandle.ClickObject(SubmitButton);
            UpdateMsgExist = appHandle.IsObjectExists(UserModificationSuccessfulText);
            if (UpdateMsgExist == true)
            {
                Report.Pass("The Product Modification Passed", "The Product Modification is successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Product Modification Failed", "The Product Modification Failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            appHandle.SelectTab(USRegulatoryTab);
            appHandle.SyncPage();
            bool USRegulatoryMsgExist = appHandle.IsObjectExists(DepositUSregulatoryTabMsg);
            appHandle.SelectTab(TransactionProcessingTab);
            appHandle.SyncPage();
            bool TransactionProcessingMsgExist = appHandle.IsObjectExists(TransactionProcessingTabMsg);
            appHandle.SelectTab(InterestTab);
            appHandle.SyncPage();
            bool InterstTabMsgExist = appHandle.IsObjectExists(DepositInterestTabMsg);
            appHandle.Select_link(RateDeterminationLink);
            appHandle.SyncPage();
            bool RateDeterminationMsgExist = appHandle.IsObjectExists(DepositInterestTabMsg2);
            appHandle.Select_link(TieredIndexValuesLink);
            appHandle.SyncPage();
            bool TiredIndexMsgExist = appHandle.IsObjectExists(DepositInterestTabMsg3);
            appHandle.Select_link(PostingOptionsLink);
            appHandle.SyncPage();
            bool PostingMsgExist = appHandle.IsObjectExists(DepositInterestTabMsg4);
            appHandle.Select_link(NegativeInterestLink);
            appHandle.SyncPage();
            bool NegativeInterestMsgExist = appHandle.IsObjectExists(DepositInterestTabMsg5);
            appHandle.SelectTab(TermAccountsTab);
            appHandle.SyncPage();
            bool TermAccountMsgExist = appHandle.IsObjectExists(DepositTermAccountsTabMsg);
            appHandle.Select_link(PenaltyLink);
            appHandle.SyncPage();
            bool PenaltyMsgExist = appHandle.IsObjectExists(DepositTermAccountsTabMsg2);
            appHandle.Select_link(NoticeAccountsLink);
            appHandle.SyncPage();
            bool NoticeAccountMsgExist = appHandle.IsObjectExists(DepositTermAccountsTabMsg3);
            appHandle.Select_link(ScheduledDepositsLink);
            appHandle.SyncPage();
            bool ScheduledDepositMsgExist = appHandle.IsObjectExists(DepositTermAccountsTabMsg4);
            appHandle.SelectTab(ServiceFeesTab);
            appHandle.SyncPage();
            bool ServiceFeesMsgExist = appHandle.IsObjectExists(DepositServiceFeesTabMsg);
            appHandle.Select_link(CommercialAnalysisLink);
            appHandle.SyncPage();
            bool CommercialAnalysisMsgExist = appHandle.IsObjectExists(DepositServiceFeesTabMsg2);
            appHandle.SelectTab(CheckbookTab);
            appHandle.SyncPage();
            bool CheckbbokMsgExist = appHandle.IsObjectExists(DepositCheckBookTabMsg);
            appHandle.SelectTab(SavingsIncentiveTab);
            appHandle.SyncPage();
            bool SavingsIncentiveMsgExist = appHandle.IsObjectExists(DepositSavingsIncentiveTabMsg);
            appHandle.SelectTab(FundsAvailabilityTab);
            appHandle.SyncPage();
            bool FundsAvailabilityMsgExist = appHandle.IsObjectExists(DepositFundsAvailabilityTabMsg);
            appHandle.SelectTab(OverDraftsTab);
            appHandle.SyncPage();
            bool MsgExist = appHandle.IsObjectExists(DepositOverDraftTabMsg);
            appHandle.Select_link(LinkedOverdraftLink);
            appHandle.SyncPage();
            bool LinkedOverdraftMsgExist = appHandle.IsObjectExists(DepositOverDraftTabMsg2);
            appHandle.SelectTab(InvestmentSweepTab);
            appHandle.SyncPage();
            bool InvestMentSweepMsgExist = appHandle.IsObjectExists(DepositInvestmentSweepTabMsg);
            appHandle.SelectTab(StatementsTab);
            appHandle.SyncPage();
            bool DepositStatementsMsgExist = appHandle.IsObjectExists(DepositStatementsTabMsg);
            appHandle.SelectTab(EscrowTab);
            appHandle.SyncPage();
            bool EscrowMsgExist = appHandle.IsObjectExists(DepositEscrowTabMsg);
            appHandle.SelectTab(TransactionCodesTab);
            appHandle.SyncPage();
            bool TransactionCodeMsgExist = appHandle.IsObjectExists(DepositTransactionCodeTabMsg);
            appHandle.Select_link(BackofficeLink);
            appHandle.SyncPage();
            bool BackOfficeMsgExist = appHandle.IsObjectExists(DepositTransactionCodeTabMsg2);
            appHandle.Select_link(ServiceFeesLink);
            appHandle.SyncPage();
            ServiceFeesMsgExist = appHandle.IsObjectExists(DepositTransactionCodeTabMsg3);
            appHandle.SelectTab(BranchAuthorizationTab);
            appHandle.SyncPage();
            bool BranchAuthMsgExist = appHandle.IsObjectExists(DepositBranchAuthorizationTabMsg);
            appHandle.SelectTab(TargetBalanceAccountsTab);
            appHandle.SyncPage();
            bool TargetAccountBalMsgExist = appHandle.IsObjectExists(DepositTargetBalanceAccountsTabMsg);
            appHandle.SelectTab(GeneralTab);
            appHandle.SyncPage();
            bool GeneralMsgExist = appHandle.IsObjectExists(DepositGeneralTabMsg);
            if (USRegulatoryMsgExist && TransactionProcessingMsgExist && InterstTabMsgExist && RateDeterminationMsgExist && TiredIndexMsgExist && PostingMsgExist && ScheduledDepositMsgExist && NegativeInterestMsgExist && NoticeAccountMsgExist && PenaltyMsgExist && TermAccountMsgExist && ServiceFeesMsgExist && CommercialAnalysisMsgExist && CheckbbokMsgExist && SavingsIncentiveMsgExist && FundsAvailabilityMsgExist && MsgExist && LinkedOverdraftMsgExist && InvestMentSweepMsgExist && DepositStatementsMsgExist && EscrowMsgExist && TransactionCodeMsgExist && BackOfficeMsgExist && ServiceFeesMsgExist && BranchAuthMsgExist && TargetAccountBalMsgExist && GeneralMsgExist)
            {
                Report.Pass("The Product page verification Passed", "The Product page verification successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Product page verification Failed", "The Product page verification Failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }


        }
        public virtual void DeleteProduct(string[] ProductDetails)
        {
            NavigatetoProductFactoryPage();
            appHandle.SelectDropdownSpecifiedValue(ProductClassDropDown, ProductDetails[0]);
            appHandle.SelectDropdownSpecifiedValue(ProductGroupDropDown, ProductDetails[1]);
            appHandle.ClickObject(SearchButton);
            appHandle.SyncPage();
            appHandle.SelectRadioButtonInTable(ProdListTable, ProductDetails[2]);
            appHandle.ClickObject(DeleteButton);
            // Code For confirmation Ok Button needs to be added.
            bool ProductDeletionSuccessful = appHandle.IsObjectExists(ProductDeletionMsg);
            if (ProductDeletionSuccessful == true)
            {
                Report.Pass("The Product has been deleted successfully", "The Product deletion successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Product Deletion has been failed", "The Product deletion failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }


        }

        public virtual void ModifyLoanProduct(string[] LoanProductDetails)
        {
            NavigatetoProductFactoryPage();
            appHandle.SelectDropdownSpecifiedValue(ProductClassDropDown, LoanProductDetails[0]);
            appHandle.SelectDropdownSpecifiedValue(ProductGroupDropDown, LoanProductDetails[1]);
            appHandle.ClickObject(SearchButton);
            appHandle.SyncPage();
            appHandle.SelectRadioButtonInTable(ProdListTable, LoanProductDetails[2]);
            appHandle.ClickObject(EditButton);
            appHandle.SyncPage();
            appHandle.SelectDropdownSpecifiedValue(BillingStatementBillPrintDesignDropdown, LoanProductDetails[6]);
            appHandle.Set_field_value(StatementsSummaryStatementDescriptionField, LoanProductDetails[4]);
            appHandle.ClickObject(SubmitButton);
            appHandle.SyncPage();
            bool UpdateMsgExist = appHandle.IsObjectExists(InformationUpdateMsg);
            if (UpdateMsgExist == true)
            {
                Report.Pass("The Product has been updated successfully", "The Product deletion successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Product Update has been failed", "The Product Update failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            appHandle.SelectDropdownSpecifiedValue(LoanGeneralInformationCurrencyDropdown, LoanProductDetails[5]);
            appHandle.ClickObject(SubmitButton);
            UpdateMsgExist = appHandle.IsObjectExists(InformationUpdateMsg);
            if (UpdateMsgExist == true)
            {
                Report.Pass("The Product has been updated successfully", "The Product deletion successful Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Product Update has been failed", "The Product Update failed Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }

        }

        public virtual void VerifyLoanProduct(string LoanProductNo)
        {
            appHandle.SelectTab(USRegulatoryTab);
            appHandle.SyncPage();
            bool USRegulatoryMsgExist = appHandle.IsObjectExists(DepositUSregulatoryTabMsg);
            appHandle.SelectTab(NewAccountsTab);
            appHandle.SyncPage();
            bool LoanNewAccountsTabMsgExist = appHandle.IsObjectExists(LoanNewAccountsTabMsg);
            appHandle.SelectTab(TransactionProcessingTab);
            appHandle.SyncPage();
            bool TransactionProcessingTabMsgExist = appHandle.IsObjectExists(TransactionProcessingTabMsg);
            appHandle.SelectTab(PaymentApplicationTab);
            appHandle.SyncPage();
            bool PaymentApplicationTabMsgExist = appHandle.IsObjectExists(PaymentApplicationTabMsg);
            appHandle.SelectTab(PaymentCalculationTab);
            appHandle.SyncPage();
            bool PaymentCalculationTabMsg1Exist = appHandle.IsObjectExists(PaymentCalculationTabMsg1);
            appHandle.Select_link(RevolvingCreditPaymentLink);
            appHandle.SyncPage();
            bool PaymentCalculationTabMsg2Exist = appHandle.IsObjectExists(PaymentCalculationTabMsg2);
            appHandle.Select_link(AdjustablePaymentLink);
            appHandle.SyncPage();
            bool PaymentCalculationTabMsg3Exist = appHandle.IsObjectExists(PaymentCalculationTabMsg3);
            appHandle.Select_link(AdjustablePaymentLimitsLink);
            appHandle.SyncPage();
            bool PaymentCalculationTabMsg4Exist = appHandle.IsObjectExists(PaymentCalculationTabMsg4);
            if (USRegulatoryMsgExist && LoanNewAccountsTabMsgExist && TransactionProcessingTabMsgExist && PaymentApplicationTabMsgExist && PaymentCalculationTabMsg1Exist && PaymentCalculationTabMsg2Exist && PaymentCalculationTabMsg3Exist && PaymentCalculationTabMsg4Exist)
            {
                Report.Pass("The Loan Product verification passed for US Regulatory,New Accounts, Payment Application and Payment Calculation Tab", "The Product verification successful for US Regulatory,New Accounts, Payment Application and Payment Calculation Tab  Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Loan Product verification Failed for US Regulatory,New Accounts, Payment Application and Payment Calculation Tab", "The Product verification Failed for US Regulatory,New Accounts, Payment Application and Payment Calculation Tab  Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            appHandle.SelectTab(GLCategoriesTab);
            appHandle.SyncPage();
            bool GLCategoriesTabMsgExist = appHandle.IsObjectExists(GLCategoriesTabMsg);
            appHandle.SelectTab(InterestTab);
            appHandle.SyncPage();
            bool LoanInterestTabMsg1Exist = appHandle.IsObjectExists(LoanInterestTabMsg1);
            appHandle.Select_link(RateDeterminationLink);
            appHandle.SyncPage();
            bool LoanInterestTabMsg2Exist = appHandle.IsObjectExists(LoanInterestTabMsg2);
            appHandle.Select_link(CapitalizedInterestProcessingLink);
            appHandle.SyncPage();
            bool LoanInterestTabMsg3Exist = appHandle.IsObjectExists(LoanInterestTabMsg3);
            if (GLCategoriesTabMsgExist && LoanInterestTabMsg1Exist && LoanInterestTabMsg2Exist && LoanInterestTabMsg3Exist)
            {
                Report.Pass("The Loan Product verification passed for G/L categories and Interest Tab", "The Loan Product verification successful for G/L categories and Interest Tab  Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Loan Product verification Failed for G/L categories and Interest Tab", "The Product verification Failed for G/L categories and Interest Tab  Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            appHandle.SelectTab(MaturityRenewalTab);
            appHandle.SyncPage();
            bool MaturityRenewalTabMsg1Exist = appHandle.IsObjectExists(MaturityRenewalTabMsg1);
            appHandle.Select_link(RenewalProcessingLink);
            appHandle.SyncPage();
            bool MaturityRenewalTabMsg2Exist = appHandle.IsObjectExists(MaturityRenewalTabMsg2);
            appHandle.SelectTab(DelinquencyTab);
            appHandle.SyncPage();
            bool DelinquencyTabMsg1Exist = appHandle.IsObjectExists(DelinquencyTabMsg1);
            appHandle.Select_link(NoticeOffsetDaysLink);
            appHandle.SyncPage();
            bool DelinquencyTabMsg2Exist = appHandle.IsObjectExists(DelinquencyTabMsg2);
            appHandle.Select_link(NoticeSelectionLink);
            appHandle.SyncPage();
            bool DelinquencyTabMsg3Exist = appHandle.IsObjectExists(DelinquencyTabMsg3);
            appHandle.Select_link(CountersDaysLink);
            appHandle.SyncPage();
            bool DelinquencyTabMsg4Exist = appHandle.IsObjectExists(DelinquencyTabMsg4);
            if (MaturityRenewalTabMsg1Exist && MaturityRenewalTabMsg2Exist && DelinquencyTabMsg4Exist && DelinquencyTabMsg3Exist && DelinquencyTabMsg2Exist && DelinquencyTabMsg1Exist)
            {
                Report.Pass("The Loan Product verification passed for Maturity/Renewal and Delinquency Tab", "The Loan Product verification successful for Maturity/Renewal and Delinquency Tab  Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Loan Product verification Failed for Maturity/Renewal and Delinquency Tab", "The Product verification Failed for Maturity/Renewal and Delinquency Tab  Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            appHandle.SelectTab(EscrowAnalysisTab);
            appHandle.SyncPage();
            bool EscrowAnalysisTabMsgExist = appHandle.IsObjectExists(EscrowAnalysisTabMsg);
            appHandle.SelectTab(TransactionCodesTab);
            appHandle.SyncPage();
            bool TransactionCodesTabMsg1Exist = appHandle.IsObjectExists(TransactionCodesTabMsg1);
            appHandle.Select_link(PaymentsLink);
            appHandle.SyncPage();
            bool TransactionCodesTabMsg2Exist = appHandle.IsObjectExists(TransactionCodesTabMsg2);
            appHandle.Select_link(PayoffLink);
            appHandle.SyncPage();
            bool TransactionCodesTabMsg3Exist = appHandle.IsObjectExists(TransactionCodesTabMsg3);
            appHandle.Select_link(FeesLink);
            appHandle.SyncPage();
            bool TransactionCodesTabMsg4Exist = appHandle.IsObjectExists(TransactionCodesTabMsg4);
            appHandle.Select_link(EscrowLink);
            appHandle.SyncPage();
            bool TransactionCodesTabMsg5Exist = appHandle.IsObjectExists(TransactionCodesTabMsg5);
            if (EscrowAnalysisTabMsgExist && TransactionCodesTabMsg1Exist && TransactionCodesTabMsg2Exist && TransactionCodesTabMsg3Exist && TransactionCodesTabMsg4Exist && TransactionCodesTabMsg5Exist)
            {
                Report.Pass("The Loan Product verification passed for Escrow Analysis and Transaction Processing Tab", "The Loan Product verification successful for Escrow Analysis and Transaction Processing  Tab  Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Loan Product verification Failed for Escrow Analysis and Transaction Processing  Tab", "The Product verification Failed for Escrow Analysis and Transaction Processing  Tab  Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            appHandle.SelectTab(BranchAuthorizationTab);
            appHandle.SyncPage();
            bool DepositBranchAuthorizationTabMsgExist = appHandle.IsObjectExists(DepositBranchAuthorizationTabMsg);
            appHandle.SelectTab(CreditCardsTab);
            appHandle.SyncPage();
            bool CreditCardsTabMsgExist = appHandle.IsObjectExists(CreditCardsTabMsg);
            appHandle.SelectTab(GeneralTab);
            appHandle.SyncPage();
            bool DepositGeneralTabMsgExist = appHandle.IsObjectExists(DepositGeneralTabMsg);
            if (DepositBranchAuthorizationTabMsgExist && CreditCardsTabMsgExist && DepositGeneralTabMsgExist)
            {
                Report.Pass("The Loan Product verification passed for Branch Authorization,Credit Card  and General Tab", "The Loan Product verification successful for Branch Authorization,Credit Card  and General Tab  Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Loan Product verification Failed for Branch Authorization,Credit Card  and General  Tab", "The Product verification Failed for Branch Authorization,Credit Card  and General  Tab  Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }


        }

        public virtual void NavigatetoInstitutionVariablePage()
        {
            appHandle.Select_link(TableConfigurationLink);
            appHandle.Select_link(Institutionvariablesink);
        }

        public virtual void VerifyInstitutionVariablePage()
        {
            appHandle.SelectTab(GeneralTab);
            appHandle.SyncPage();
            bool DepositGeneralTabMsgExist = appHandle.IsObjectExists(DepositGeneralTabMsg);
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.SelectTab(USRegulatoryTab);
            appHandle.SyncPage();
            bool InstitutionUSRegulatoryTabMsgExist = appHandle.IsObjectExists(InstitutionUSRegulatoryTabMsg);
            appHandle.Select_link(USRegulatory2Link);
            appHandle.SyncPage();
            bool InstitutionUSRegulatoryTabMsg2Exist = appHandle.IsObjectExists(InstitutionUSRegulatoryTabMsg2);
            appHandle.Select_link(OTSThriftFinancialReportLink);
            appHandle.SyncPage();
            bool InstitutionUSRegulatoryTabMsg3Exist = appHandle.IsObjectExists(InstitutionUSRegulatoryTabMsg3);
            if (DepositGeneralTabMsgExist && InstitutionUSRegulatoryTabMsgExist && InstitutionUSRegulatoryTabMsg2Exist && InstitutionUSRegulatoryTabMsg3Exist)
            {
                Report.Pass("The Institution Variables Page verification passed for General and US Regulatory Tab", "The Institution Variable Page verification successful for General and US Regulatory Tab  Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Institution Variables Page  verification Failed for General and US Regulatory Tab", "The Institution Variable Page verification Failed for General and US Regulatory Tab  Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            appHandle.SelectTab(AccountsTab);
            appHandle.SyncPage();
            bool CustomerInformationMsgExist = appHandle.IsObjectExists(CustomerInformationMsg);
            appHandle.Select_link(DepositLink);
            appHandle.SyncPage();
            bool AccountsTabMsg2Exist = appHandle.IsObjectExists(AccountsTabMsg2);
            appHandle.Select_link(RetirementLink);
            appHandle.SyncPage();
            bool AccountsTabMsg3Exist = appHandle.IsObjectExists(AccountsTabMsg3);
            appHandle.Select_link(LoanLink);
            appHandle.SyncPage();
            bool AccountsTabMsg4Exist = appHandle.IsObjectExists(AccountsTabMsg4);
            appHandle.Select_link(LoanReportingLink);
            appHandle.SyncPage();
            bool AccountsTabMsg5Exist = appHandle.IsObjectExists(AccountsTabMsg5);
            appHandle.Select_link(DelinquencyClassificationLink);
            appHandle.SyncPage();
            bool AccountsTabMsg6Exist = appHandle.IsObjectExists(AccountsTabMsg6);
            appHandle.SelectTab(TransactionProcessingTab);
            appHandle.SyncPage();
            bool InstitutionTransactionProcessingTabMsg1Exist = appHandle.IsObjectExists(InstitutionTransactionProcessingTabMsg1);
            appHandle.Select_link(PaymentSystemLink);
            appHandle.SyncPage();
            bool InstitutionTransactionProcessingTabMsg2Exist = appHandle.IsObjectExists(InstitutionTransactionProcessingTabMsg2);
            appHandle.Select_link(ForeignCurrencyLink);
            appHandle.SyncPage();
            bool InstitutionTransactionProcessingTabMsg3Exist = appHandle.IsObjectExists(InstitutionTransactionProcessingTabMsg3);
            if (CustomerInformationMsgExist && AccountsTabMsg2Exist && AccountsTabMsg3Exist && AccountsTabMsg4Exist && AccountsTabMsg5Exist && AccountsTabMsg6Exist && InstitutionTransactionProcessingTabMsg1Exist && InstitutionTransactionProcessingTabMsg2Exist && InstitutionTransactionProcessingTabMsg3Exist)
            {
                Report.Pass("The Institution Variables Page verification passed for Accounts and Transaction Processing Tab", "The Institution Variable Page verification successful for Accounts and Transaction Processing Tab  Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Institution Variables Page  verification Failed for Accounts and Transaction Processing Tab", "The Institution Variable Page verification Failed for Accounts and Transaction Processing Tab  Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            appHandle.SelectTab(SystemTab);
            appHandle.SyncPage();
            bool SystemTabMsg1Exist = appHandle.IsObjectExists(SystemTabMsg1);
            appHandle.Select_link(SystemManagementLink);
            appHandle.SyncPage();
            bool SystemTabMsg2Exist = appHandle.IsObjectExists(SystemTabMsg2);
            appHandle.SelectTab(GeneralLedgerTab);
            appHandle.SyncPage();
            bool GeneralLedgerTabMsgExist = appHandle.IsObjectExists(GeneralLedgerTabMsg);
            if (SystemTabMsg1Exist && SystemTabMsg2Exist && GeneralLedgerTabMsgExist)
            {
                Report.Pass("The Institution Variables Page verification passed for System and General Ledger Tab", "The Institution Variable Page verification successful for System and General Ledger Tab  Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The Institution Variables Page  verification Failed for System and General Ledger Tab", "The Institution Variable Page verification Failed for System and General Ledger Tab  Screen", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }

        public virtual void NavigateToPackagesPage()
        {
            appHandle.Select_link(ProductFactoryLink);
            appHandle.SyncPage();
            appHandle.Select_link(ProductFactoryPackagesLink);
            appHandle.SyncPage();
        }

        public virtual void NavigateToGeneralTableManagementPage()
        {
            appHandle.Select_link(TableConfigurationLink);
            appHandle.SyncPage();
            appHandle.Select_link(GeneralTableManagementLink);
            appHandle.SyncPage();
        }

        public virtual void ClickTableconfigurationLink()
        {
            appHandle.Select_link(TableConfigurationLink);
            appHandle.SyncPage();
        }

        public virtual string GetAppDate()
        {
            string appDate = appHandle.GetLabelText(appdate);
            appDate = appDate.Substring(0, appDate.Length - 7);
            return appDate;
        }

        public virtual void CloseBrowser()
        {
            appHandle.CloseApplication(this);
        }

        /// <summary>
        /// To select link under Tab by clicking on Tab.
        /// <param name= "TabName"></param> 
        /// <param name= "LinkName"></param> 
        /// <returns></returns>
        /// <example>SelectLinkinTab(TabName,LinkName)</example>
        public void SelectLinkinTab(string TabName, string LinkName = null)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle.WaitUntilElementVisible(TabName);
                appHandle.WaitUntilElementClickable(TabName);
                string obj = TabName + "/preceding-sibling::td/img[contains(@src,'open')]";
                if (!(appHandle.IsObjectExists(obj)))
                    appHandle.ClickObject(TabName);
                if (LinkName != null && LinkName != "")
                {
                    appHandle.WaitUntilElementClickable(LinkName);
                    appHandle.Select_link(LinkName);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }

        }

        /// <summary>
        /// To verify Expected Message.
        /// <param name= "Expected Message"></param> 
        /// <returns></returns>
        /// <example>CheckSuccessMessage(message)</example>
        public virtual bool CheckSuccessMessage(string message = null)
        {
            bool bCheck = false;
            try
            {
                if (message != null && message != "")
                    bCheck = appHandle.CheckSuccessMessage(message);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bCheck;
        }

        /// <summary>
        /// This method is used to click on Add button
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOnAddButton();
        /// </example>
        public virtual void ClickOnAddButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(AddButton);
                appHandle.WaitUntilElementClickable(AddButton);
                appHandle.ClickObject(AddButton);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on Add button
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOnContinueButton();
        /// </example>
        public virtual void ClickOnContinueButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnContinue);
                appHandle.WaitUntilElementClickable(btnContinue);
                appHandle.ClickObject(btnContinue);
                appHandle.Wait_For_Specified_Time(10);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on Submit button
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOnSubmitButton();
        /// </example>
        public virtual void ClickOnSubmitButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(SubmitButton);
                appHandle.WaitUntilElementClickable(SubmitButton);
                appHandle.ClickObject(SubmitButton);
                appHandle.Wait_For_Specified_Time(3);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        /// <summary>
        /// To Split the given string with specified delimeter.
        /// <param name= "Main String"></param> 
        /// <param name= "Delimeter"></param>
        /// <returns>string array</returns>
        /// <example>SplitString(sMainString,sDelimeter)</example>
        public string[] SplitString(string sMainString, string sDelimeter)
        {
            string[] arrstrng = null;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                arrstrng = appHandle.SplitString(sMainString, sDelimeter);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return arrstrng;
        }

        /// <summary>
        /// To Check Object Exists.
        /// <param name= "object"></param> 
        /// <returns>bool</returns>
        /// <example>CheckObjectExists(obj)</example>
        public bool CheckObjectExists(string obj)
        {
            bool bval = false;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                bval = appHandle.IsObjectExists(obj);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bval;
        }

        /// <summary>
        /// To generate Random Data.
        /// <param name= "fieldType"></param> 
        /// <param name= "iMin"></param> 
        /// <param name= "iMax"></param> 
        /// <param name= "iLength"></param> 
        /// <returns>Random Data</returns>
        /// <example>CheckObjectExists(fieldType,iMin,iMax,iLength)</example>
        public object CreateRamdomData(FieldType fieldType, int iMin = 0, int iMax = 0, int iLength = 0)
        {
            object Outdata = null;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                Outdata = appHandle.CreateRamdomData(fieldType, iMin, iMax, iLength);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return Outdata;
        }

        /// <summary>
        /// This method is used to click on Edit button
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOnEditButton();
        /// </example>
        public virtual void ClickOnEditButton()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
    {
        appHandle.ClickObjectViaJavaScript(buttonEdit);
    }
    Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton);
        }

        public virtual bool CheckSubmitButtonExists()
        {
            bool bCheck = false;
            try
            {
                appHandle.WaitUntilElementVisible(SubmitButton);
                bCheck = appHandle.IsObjectExists(SubmitButton);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bCheck;
        }
        /// <summary>
        /// This method is used to click on Search button
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOnSearchButton();
        /// </example>
        public virtual void ClickOnSearchButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(SearchButton);
                appHandle.WaitUntilElementClickable(SearchButton);
                appHandle.ClickObject(SearchButton);
                appHandle.Wait_For_Specified_Time(3);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on Copy button
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOnCopyButton();
        /// </example>
        public virtual void ClickOnCopyButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(CopyButton);
                appHandle.WaitUntilElementClickable(CopyButton);
                appHandle.ClickObject(CopyButton);
                appHandle.Wait_For_Specified_Time(3);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on Authorize button
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOnAuthorizeButton();
        /// </example>
        public virtual void ClickOnAuthorizeButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnAuthorize);
                appHandle.WaitUntilElementClickable(btnAuthorize);
                appHandle.ClickObject(btnAuthorize);
                appHandle.Wait_For_Specified_Time(3);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on Rates button
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOnRatesButton();
        /// </example>
        public virtual void ClickOnRatesButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnRates);
                appHandle.WaitUntilElementClickable(btnRates);
                appHandle.ClickObject(btnRates);
                appHandle.Wait_For_Specified_Time(3);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on Ok button for Alerts
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOkButton();
        /// </example>
        public virtual void ClickOkButton()
        {
            try
            {
                appHandle.WaitForSpecifiedTime(3);
                appHandle.PerformActionOnAlert(PopUpAction.Accept);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on Delete button
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.WebAdminCommonPage.ClickOnDeleteButton();
        /// </example>
        public virtual void ClickOnDeleteButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnDelete);
                appHandle.WaitUntilElementClickable(btnDelete);
                appHandle.ClickObject(btnDelete);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on any object
        /// <param name= "object Xpath"></param> 
        /// <returns></returns> 
        /// <example>WebAdminPageFactory.WebAdminCommonPage.ClickOnObject(sobj);</example>
        public virtual void ClickOnObject(string sobj)
        {
            try
            {
                appHandle.WaitUntilElementVisible(sobj);
                appHandle.WaitUntilElementClickable(sobj);
                appHandle.ClickObject(sobj);
            }
            catch (Exception e) { Report.Info("Exception logged as : " + e); }
        }

        /// <summary>
        /// This method is used to Generate Xpath for Tabs.
        /// <param name= "Tab Name"></param> 
        /// <returns>Xpath</returns> 
        /// <example>WebAdminPageFactory.WebAdminCommonPage.GenerateXpathforTabs("General");</example>
        public virtual string GenerateXpathforTabs(string sTabName)
        {
            string TabName = null;
            try
            {
                TabName = "XPath;//table[@class='tab']/descendant::td[contains(text(),'"+sTabName+"')]";
            }
            catch (Exception e) { Report.Info("Exception logged as : " + e); }
            return TabName;
        }

        /// <summary>
        /// This method is used to enter value in Field 
        /// <param name= "object Xpath"></param> 
        /// <param name= "value"></param> 
        /// <returns></returns> 
        /// <example>WebAdminPageFactory.WebAdminCommonPage.SetFieldValue(objXpath,value);</example>
        public virtual void SetFieldValue(string objXpath, string value)
        {
            try
            {
                appHandle.Set_field_value(objXpath, value);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to select value in Dropdown
        /// <param name= "object Xpath"></param> 
        /// <param name= "value"></param> 
        /// <returns></returns> 
        /// <example>WebAdminPageFactory.WebAdminCommonPage.SelectDropdownValue(objXpath,value);</example>
        public virtual void SelectDropdownValue(string objXpath, string value)
        {
            try
            {
                appHandle.SelectDropdownSpecifiedValue(objXpath, value);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to select checkbox on or off
        /// <param name= "object Xpath"></param> 
        /// <param name= "value"></param> 'on/off
        /// <returns></returns> 
        /// <example>WebAdminPageFactory.WebAdminCommonPage.SelectCheckBox(objXpath,value);</example>
        public virtual void SelectCheckBox(string objXpath, string value)
        {
            try
            {
                if (value == "ON")
                    appHandle.Select_CheckBox(objXpath);
                else
                    appHandle.DeSelectCheckBox(objXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to select radiobutton
        /// <param name= "object Xpath"></param> 
        /// <returns></returns> 
        /// <example>WebAdminPageFactory.WebAdminCommonPage.SetRadioButton(objXpath);</example>
        public virtual void SetRadioButton(string objXpath)
        {
            try
            {
                appHandle.Set_radiobutton(objXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to click the button
        /// <param name= "object Xpath"></param> 
        /// <returns></returns> 
        /// <example>WebAdminPageFactory.WebAdminCommonPage.ClickButton(objXpath);</example>

        public virtual void ClickButton(string objXpath)
        {
            try
            {
                appHandle.SelectButton(objXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to Calculate New Date
        /// <param name= "startdate"></param> 
        /// <param name= "date param"></param> 
        /// <param name= "numberofDay"></param>
        /// <returns>New Date</returns> 
        /// <example>WebAdminPageFactory.WebAdminCommonPage.CalculateNewDate(startdate,dparam,numberofDay);</example>
        public virtual string CalculateDate(string startdate, string dparam, int numberofDay)
        {
            return appHandle.CalculateNewDate(startdate, dparam, numberofDay);
        }

        /// <summary>
        /// This method is used to select Radio Button in table.
        /// <param name= "tableXpath"></param> 
        /// <param name= "sColumnValue"></param>
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.SelectRadioButtonInTable();<example>
        public virtual void SelectRadioButtonInTable(string tableXpath, string sColumnValue)
        {
            try
            {
                appHandle.SelectRadioButtonInTable(tableXpath, sColumnValue);
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged: " + e);
            }
        }

        /// <summary>
        /// This method is used to check checkbox status.
        /// <param name= "sCheckboxXpath"></param> 
        /// <returns>true/false</returns> 
        /// <example>WebCSRMasterPage.VerifyCheckBoxUnchecked(sCheckboxXpath)<example>
        public virtual bool VerifyCheckBoxUnchecked(string sCheckboxXpath)
        {
            bool CheckboxStatus = true;
            try
            {
                CheckboxStatus = appHandle.CheckCheckBoxUnchecked(sCheckboxXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged: " + e);
            }
            return CheckboxStatus;
        }

        /// <summary>
        /// This method is used to do action on popup button.
        /// <param name= "ActionType"></param>  
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.ActionOnPopButton("OK")<example>
        /// <example>WebCSRMasterPage.ActionOnPopButton("CANCEL")<example>
        public virtual void ActionOnPopButton(string ActionType)
        {
            try
            {
                if (ActionType.ToUpper().Equals("OK"))
                {
                    appHandle.PerformActionOnAlert(PopUpAction.Accept);
                }
                else
                {
                    appHandle.PerformActionOnAlert(PopUpAction.Decline);
                }
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

        /// This method is used to click on Cancel button.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminMasterPage.ClickOnCancelButton();
        /// </example>
        public virtual void ClickOnCancelButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(btnCancel);
                appHandle.ClickObject(btnCancel);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// </summary>
        /// This method is used for check the object is not exists.
        /// <returns></returns> 
        /// <example>
        /// WebAdminMasterPage.checkobjectisnotexists();
        /// </example>
        public virtual bool checkobjectisnotexists(string obj1)
        {
            bool objstatus = false;
            try
            {
                objstatus = appHandle.CheckObjectNotExist(obj1);
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged: " + e);
            }
            return objstatus;
        }

        /// Function for Navigating the Add Exemption Plan Parameters page.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminMasterPage.NavigateToAddExemptionPlanParametersPage();
        /// </example>
        public virtual void NavigateToAddExemptionPlanParametersPage()
        {
            try{

            appHandle.Select_link(TableConfigurationLink);
            appHandle.SyncPage();
            appHandle.Select_link(lnkExemptionPlans);
            appHandle.SyncPage();
            WebAdminPageFactory.ExemptionPlanListPage.ClickAddButton();
            bool blnConfirmedMsg = WebAdminPageFactory.AddExemptionPlanParametersPage.ConfirmAddExemptionPlanParametersPage();
            if (blnConfirmedMsg == true)
                Report.Pass("Successfully navigated to Add Exemption Plan parameters page", "blnConfirmedMsg", "True", appHandle);
            else
                Report.Fail("Not navigated to the Add Exemption Plan page", "blnConfirmedMsg", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        //Method for click the tab in respective page in WebAdmin.
        public virtual void ClicktheTab(string tabpath)
        {
            appHandle.SelectTab(tabpath);
            appHandle.SyncPage();
        }

        public virtual void ClickObject(string xpath)
        {
            try
            {
                appHandle.ClickObject(xpath);

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        public virtual string CountPageLength()
        {
             string outputValue = null;
            try
            {
                string sLastArrowXpath = "Xpath;//a[@id='content:service:scroll_1last']";
                appHandle.ClickObject(sLastArrowXpath);
                string xpath = sLastArrowXpath + "/preceding-sibling::b";
                outputValue = appHandle.GetObjectText(xpath);
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return outputValue;

        }

        public virtual string GenerateXpathForPageLinks(int j)
        {
            string outputXpath = null;
            try
            {
                outputXpath = "Xpath;//a[text()='" + j + "']";
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return outputXpath;
        }

        public virtual bool CheckObjectStatus(string sObjectXpath)
        {
             bool bCheck  = false;
            try
            {
                bCheck = appHandle.CheckObjectEnabled(sObjectXpath);
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return bCheck;
        }

        public virtual void ClickAddButton()
        {
            try
            {
                appHandle.WaitUntilElementVisible(AddButton1);
                appHandle.WaitUntilElementClickable(AddButton1);
                appHandle.ClickObject(AddButton1);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }


    }
}