using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class RateScheduleEffectiveDatesListPage
    {
        WebApplication appHandle;
        public static string tblRateScheduleEffectiveDatesList = "XPath;//div[contains(@id,'rate-schedule')]";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// This method is used to select specified EffectiveDate in Rate Schedule Table
        /// <param name = "EffectiveDate"></param> 
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.SelectSpecifiedRateScheduleName(sEffectiveDate);
        /// </example> 
        public void SelectSpecifiedEffectiveDate(string sEffectiveDate)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(tblRateScheduleEffectiveDatesList);
                AppHandle.WaitUntilElementClickable(tblRateScheduleEffectiveDatesList);
                string obj = "XPath;//input[@name='rateScheduleEffectiveDate'][@value='" + sEffectiveDate + "']";
                AppHandle.Set_radiobutton(obj);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to check specified EffectiveDate exists in Rate Schedule Table
        /// <param name = "EffectiveDate"></param> 
        /// <returns>bool</returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.CheckSpecifiedEffectiveDateExists(sEffectiveDate);
        /// </example> 
        public virtual bool CheckSpecifiedEffectiveDateExists(string sEffectiveDate)
        {
            bool bcheck = false;
            try
            {
                AppHandle.WaitUntilElementVisible(tblRateScheduleEffectiveDatesList);
                AppHandle.WaitUntilElementClickable(tblRateScheduleEffectiveDatesList);
                string obj = "XPath;//input[@name='rateScheduleEffectiveDate'][@value='" + sEffectiveDate + "']";
                bcheck = AppHandle.IsObjectExists(obj);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            return bcheck;
        }
    }
}