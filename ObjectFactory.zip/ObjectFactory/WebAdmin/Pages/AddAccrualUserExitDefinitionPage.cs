using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class AddAccrualUserExitDefinitionPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string btnAdd="Xpath;//input[@name='add']";
        public static string txtAddAccrualMsg="Xpath;//h1[contains(text(),'Add Accrual User Exit Definition')]";
        public static string txtName="Xpath;//input[@name='accrualExitName']";
        public static string txtDescription="Xpath;//input[@name='description']";
        public static string txtConditionalExecution="Xpath;//textarea[@name='conditionalExecution']";
        public static string drpTableName="Xpath;//select[@name='fileName']";
        public static string txtSelectDataItemsLine1="Xpath;//textarea[@name='selectDataItem1']";
        public static string txtSelectDataItemsLine2="Xpath;//textarea[@name='selectDataItem2']";
        public static string txtRecordSelectConditionsLine1="Xpath;//textarea[@name='recordSelectionCondition1']";
        public static string txtRecordSelectConditionsLine2="Xpath;//textarea[@name='recordSelectionCondition2']";
        public static string ckbUserPreProcessorDefined="Xpath;//input[@name='userPreProcessorDefinedModify1']";
        public static string ckbRecordLevelUserCodeDefined="Xpath;//input[@name='recordLevelUserCodeDefinedModify2']";
        public static string ckbUserPostProcessorDefined="Xpath;//input[@name='userPostProcessorDefinedModify3']";
        public static string drpRecordFormat="Xpath;//select[@name='recordFormat']";
        public static string txtDevice="Xpath;//input[@name='device']";
        public static string btnSubmit="Xpath;//input[@name='submit']";
        public static string btnCancel="Xpath;//input[@name='cancel']";



    //Method for Confirm the Add Accrual user exit definition page. 
        public virtual bool ConfirmAddAccrualUserExitDefinitionPage()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Report.Info("Confirmed the Add Accrual User Exit Definition");
            bool blnSuccess = false;
            if (appHandle.CheckObjectExist(txtAddAccrualMsg))
            {
                blnSuccess = true;
            }
            else
            {
                blnSuccess = false;
            }
            return blnSuccess;
        }

        //Method for Check the Object is Exists..
        /// <summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebAdminPagefactory.ChecktheObjectisExists();
        /// </example>
        public virtual bool ChecktheObjectisExists(string obj1)
        {
            bool bcheck = false;
            try
            {
                bcheck = appHandle.CheckObjectExist(obj1);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

        //Method for Check the object is disabled.
        public virtual bool ChecktheObjectisDisabled(string obj1)
        {
            bool bcheck = false;
            try
            {
                bcheck = appHandle.CheckObjectDisabled(obj1);
             }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }
        


    }
}