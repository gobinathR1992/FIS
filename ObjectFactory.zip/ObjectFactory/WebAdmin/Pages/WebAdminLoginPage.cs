using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class WebAdminLoginPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string UserIDField = "Name;userName";
        private static string PasswordField = "Name;password";
        private static string SubmitButton = "XPATH;//INPUT[@value='Submit']";
        private static string ClearButton = "XPATH;//input[@value='Clear']";
        private static string ExistingPasswordField = "name;password";
        private static string NewPasswordField = "name;newPassword";
        private static string ConfirmPasswordField = "name;newPasswordVerify";
        private static string LogOutButton = "name;logout";
        private static string PasswordResetSuccessMsg = "XPATH;.//*[@class='info'][contains(.,'Password changed successfully. Please login again.')]";
        private static string buttonAdvanced = "Xpath;//button[contains(text(),'Advanced')]";
        private static string linkUnsafe = "XPath;//a[contains(text(),'unsafe')]";
        private static string linkSecurityConfiguration = "XPath;//*[text()='Security Configuration']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";

        public static string buttonLogout="XPath;//button[@name='logout']";
        public virtual void FilloginDetailsWebAdmin(String userID, String password)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(UserIDField))
            {
                appHandle.Set_field_value(UserIDField, userID);
                appHandle.Set_field_value(PasswordField, password);
            }
        }

        public virtual void SubmitPage()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton))
            {
                appHandle.ClickObjectViaJavaScript(SubmitButton);
            }
        }

        public virtual void FillResetPasswordDetailsWebAdmin(String password, String newpassword)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(ExistingPasswordField);
            appHandle.Set_field_value(ExistingPasswordField, password);
            appHandle.Set_field_value(NewPasswordField, newpassword);
            appHandle.Set_field_value(ConfirmPasswordField, newpassword);
            
        }

        public virtual void LaunchWebAdminURL()
        {
            appHandle.LaunchApplication(Util.BaseURLGenerator.Generate(Data.Get("WebAdmin")),"chrome");
            if (appHandle.GetTitle().Equals("Privacy error"))
            {
                OverComeAdvancedBrowserConn();
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton);
            }
        }
        public virtual void OverComeAdvancedBrowserConn()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdvanced, 2))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdvanced);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(linkUnsafe, 2))
                {
                    appHandle.ClickObjectViaJavaScript(linkUnsafe);
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton);
                }
            }
        }
        public virtual void WebAdminLogOut()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(LogOutButton))
            {
                appHandle.ClickObjectViaJavaScript(LogOutButton);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton, 30);
                Profile7CommonLibrary.KillProcessByProcessName("chrome");                
            } 

        }

        public virtual bool VerifyResetPasswordMessage()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("Password changed successfully. Please login again.")))
            {
                Result = true;
            }

            return Result;
        }
        public virtual bool VerifyWebAdminHomePageLoads()
        {
            bool Result = false;
            
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonLogout))
            {
                Result = true;
            }
            return Result;
        }
        public virtual bool VerifyMSGToResetPassword()
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Data.Get("You must change your password before you can proceed. Please choose a new password.")))
            {
                Result = true;
            }

            return Result;
        }

        public virtual void reloadWebAdminURL()
        {
            appHandle.LaunchApplication(Util.BaseURLGenerator.Generate(Data.Get("WebAdmin"))+"?reload=true","chrome");

            if (appHandle.GetTitle().Equals("Privacy error"))
            {
                OverComeAdvancedBrowserConn();
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(SubmitButton);
            }
        }
        public virtual bool VerifyMessageInWebadminLogin(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool VerifyResetPasswordMessage(string Msg ="Password changed successfully. Please login again.")
        {
            bool Result = false;
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ);
            if (appHandle.GetObjectText(MSGOBJ).Equals(Msg))
            {
                Result = true;
            }

            return Result;
        }

        
       
        
    }

}