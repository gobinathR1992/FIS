using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class RateScheduleEffectiveDateRateModifyPage
    {
        WebApplication appHandle;
        public static string tblRateScheduleMinimumBalanceList = "XPath;//div[contains(@id,'minimum-balances-list')]";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// This method is used to select specified Minimum Balance in Rate Schedule Table
        /// <param name = "MinimumBalance"></param> 
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.SelectSpecifiedMinimumBalance(MinimumBalance);
        /// </example> 
        public void SelectSpecifiedMinimumBalance(string MinimumBalance)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(tblRateScheduleMinimumBalanceList);
                AppHandle.WaitUntilElementClickable(tblRateScheduleMinimumBalanceList);
                string obj = "XPath;//input[@name='rateScheduleMinimumBalance'][@value='" + MinimumBalance + "']";
                AppHandle.Set_radiobutton(obj);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to check specified MinimumBalance exists in Rate Schedule Table
        /// <param name = "MinimumBalance"></param> 
        /// <returns>bool</returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleListPage.CheckSpecifiedMinimumBalanceExists(MinimumBalance);
        /// </example> 
        public virtual bool CheckSpecifiedMinimumBalanceExists(string MinimumBalance)
        {
            bool bcheck = false;
            try
            {
                AppHandle.WaitUntilElementVisible(tblRateScheduleMinimumBalanceList);
                AppHandle.WaitUntilElementClickable(tblRateScheduleMinimumBalanceList);
                string obj = "XPath;//input[@name='rateScheduleMinimumBalance'][@value='" + MinimumBalance + "']";
                bcheck = AppHandle.IsObjectExists(obj);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            return bcheck;
        }
    }
}