using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebCSR.Pages
{
    public class ChangePasswordPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtExistingPassword = "Xpath;//input[@name='password']";
        public static string txtNewPassword="Xpath;//input[@name='newPassword']";
        public static string txtConfirmPassword="Xpath;//input[@name='newPasswordVerify']";

         public virtual void set_Existing_Password_field_value(string sExistPwdvalue)
        {
            appHandle.Set_field_value(txtExistingPassword, sExistPwdvalue);
        }
        public virtual void set_New_Password_field_value(string sNewPwdvalue)
        {
            appHandle.Set_field_value(txtNewPassword, sNewPwdvalue);
        }
        public virtual void set_confirm_password_field_vale(string sConfirmPwdVale)
        {
              appHandle.Set_field_value(txtConfirmPassword, sConfirmPwdVale);
        }
    }

}
