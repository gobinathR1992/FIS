using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class ExemptionPlanListPage
    {
        public static WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string btnAdd="Xpath;//input[@name='_eventId_add']";
        public static string txtExemptionListMsg="Xpath;//h1[contains(text(),'Exemption Plan List')]";
        public static string btnEdit="Xpath;//input[@name='_eventId_edit']";
        public static string btnCopy="Xpath;//input[@name='_eventId_copy']";
        public static string tblExemptionPlansList="Xpath;//table[@id='exemption-plan-list']";

        

        //Method for Click the Add Button.
        public virtual void ClickAddButton()
        {
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            AppHandle.SelectButton(btnAdd);
            Thread.Sleep(2000);
            Report.Info("Add button is clicked.");
        }

        //Method for Click the EDit Button.
        public virtual void ClickEditButton()
        {
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            AppHandle.SelectButton(btnEdit);
            Thread.Sleep(1000);
            Report.Info("Edit button is clicked.");
        }

  


    }
}