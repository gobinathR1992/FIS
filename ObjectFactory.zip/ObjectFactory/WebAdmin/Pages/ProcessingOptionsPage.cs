using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Threading;
using System.Collections.Generic;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class ProcessingOptionsPage
    {
        WebApplication appHandle;
        public static string imgLinkedTranscationCodeDefaultAccountSearch = "Xpath;//td[@class='data']//a//img";
        public static string cbkCustomerActivityOptionsEnclosure = "Name;TRN_ENC";
        public static string cbkCustomerActivityOptionsPrintReceipt = "Name;TRN_RECEIPT";
        public static string cbkCustomerActivityOptionsSkipReversalsWithinBillingPeriod = "Name;TRN_SKPREVBP";
        public static string cbkCustomerActivityOptionsSkipStatementPrint = "Name;TRN_SKPP";
        public static string cbkCustomerActivityOptionsValidateVoucher = "Name;TRN_VOUCHER";
        public static string cbkLinkedTranscationCodeDisableIfZero = "Name;TRN_LNKDSABL";
        public static string cbkProcessingOptionsProhibitOfflineUse = "Name;TRN_PROHOFF";
        public static string cbkProcessingOptionsProhibitTellerUse = "Name;TRN_SGT";
        public static string txtCustomerActivityOptionsStatementDesc = "Name;TRN_PRDES";
        public static string txtLinkedTranscationCodeDefaultAccount = "Name;TRN_LNKCID1";
        public static string txtLinkedTranscationCodeDefaultAmount = "Name;TRN_LNKAMT1";
        public static string txtLinkedTranscationCodeDefaultComment = "Name;TRN_LNKCMT1";
        public static string txtProcessingOptionsClientServerMisc1 = "Name;TRN_SVMSC1";
        public static string txtProcessingOptionsClientServerMisc2 = "Name;TRN_SVMSC2";
        public static string txtProcessingOptionsDefaultAccount = "Name;TRN_ACN";
        public static string txtProcessingOptionsDefaultTranscationAmount = "Name;TRN_AMT";
        public static string txtProcessingOptionsECPostingProgram = "Name;TRN_PGMEC";
        public static string txtProcessingOptionsPostingProgram = "Name;TRN_PGM";
        public static string txtProcessingOptionsTransactionCodeBatchPreProcessor = "Name;TRN_PPB";
        public static string txtProcessingOptionsTransactionCodePostProcessor = "Name;TRN_POP";
        public static string txtProcessingOptionsTransactionCodePreProcessor = "Name;TRN_PP";
        public static string txtProcessingOptionsTranscationDesc = "Name;TRN_DES";
        public static string txtProcessingOptionsMaxTransactionAmount = "Name;TRN_TRMAX";
        public static string txtProcessingOptionsVariableTransactionAmount = "Name;TRN_VARTAMT";
        public static string txtProcessingOptionsCheckType = "Name;TRN_CKTYP";
        public static string drpCustomerActivityOptionsStatementExtractDetailCategory = "Name;TRN_STMTRD";
        public static string drpCustomerActivityOptionsStatementExtractSummaryCategory = "Name;TRN_STMTRS";
        public static string drpCustomerActivityOptionsStatementPrintOption = "Name;TRN_STPNT";
        public static string drpDirectTransactionFeeOptionsFeeIncomeGeneralLedgerAccount = "Name;TRN_FEEGL";
        public static string drpDirectTransactionFeeOptionsServiceFeePlan = "Name;TRN_FEEPLN";
        public static string drpDirectTransactionFeeOptionsTransactionCodeGroup = "Name;TRN_FEEGRP";
        public static string drpLinkedTranscationCodeDefaultAccount = "Name;TRN_LNKCID";
        public static string drpLinkedTranscationCodeDefaultAmount = "Name;TRN_LNKAMT";
        public static string drpLinkedTranscationCodeDefaultComment = "Name;TRN_LNKCMT";
        public static string drpLinkedTranscationCodeLinkedCode = "Name;TRN_LNKETC";
        public static string drpProcessingOptionsBinGroup = "Name;TRN_BINGRP";
        public static string drpProcessingOptionsDebitOrCreditIndicator = "Name;TRN_DC";
        public static string drpProcessingOptionsGroup = "Name;TRN_GRP";
        public static string drpProcessingOptionsSWIFTTypeCode = "Name;TRN_TCODE";
        public static string drpProcessingOptionsDefaultCostCenter = "Name;TRN_DFTCC";
        public static string drpProcessingOptionsTransactionType = "Name;TRN_TRNTYP";
        public static string drpProcessingOptionsRegulationETransactionCategory = "Name;TRN_REGETRANCODE";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To enter value in Edit Feild in ProcessingOptionsPage.
        /// <param name = "Feild Name"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetEditValue(sfieldname,sfieldvalue)</example>
        public virtual void SetEditValue(string sfieldname, string sfieldvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sfieldname);
                AppHandle.WaitUntilElementClickable(sfieldname);
                AppHandle.Set_field_value(sfieldname, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select dropdown value in ProcessingOptionsPage.
        /// <param name = "dropdown Name"></param> 
        /// <param name = "dropdown Value"></param> 
        /// <returns></returns>
        /// <example>SelectDropdownValue(sdrpname,sdrpvalue)</example>
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sdrpname);
                AppHandle.WaitUntilElementClickable(sdrpname);
                AppHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
        /// <summary>
        /// To select checkbox on in ProcessingOptionsPage.
        /// <param name = "checkbox"></param> 
        /// <returns></returns>
        /// <example>SelectCheckboxOn(schkname)</example>
        public virtual void SelectCheckboxOn(string schkname)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(schkname);
                AppHandle.WaitUntilElementClickable(schkname);
                AppHandle.Select_CheckBox(schkname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select checkbox off in ProcessingOptionsPage.
        /// <param name = "checkbox"></param> 
        /// <returns></returns>
        /// <example>SelectCheckboxOff(schkname)</example>
        public virtual void SelectCheckboxOff(string schkname)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(schkname);
                AppHandle.WaitUntilElementClickable(schkname);
                AppHandle.DeSelectCheckBox(schkname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To Enter Details in ProcessingOptionsPage
        /// <param name="lstPOFlddetails"></param>
        /// lstPOFlddetails.Add(ProcessingOptionsPage.txtCustomerActivityOptionsStatementDesc   + "|field|CD Increase W/H Prior Yr"); 
        /// lstPOFlddetails.Add(ProcessingOptionsPage.cbkCustomerActivityOptionsSkipReversalsWithinBillingPeriod   + "|checkbox|on");
        /// lstPOFlddetails.Add(ProcessingOptionsPage.cbkCustomerActivityOptionsSkipStatementPrint   + "|checkbox|off");
        /// lstPOFlddetails.Add(ProcessingOptionsPage.drpCustomerActivityOptionsStatementExtractDetailCategory   + "|dropdown|ADVANCES");
        /// lstPOFlddetails.Add(ProcessingOptionsPage.drpCustomerActivityOptionsStatementPrintOption   + "|dropdown|No Fields");
        /// <returns></returns>
        /// <example>EnterDetailsinProcessingOptionsPage(lstPOFlddetails)</example>
        public virtual void EnterDetailsinProcessingOptionsPage(List<string> lstPOFlddetails)
        {
            try
            {
                string[] arrserplnDetails = new string[3];
                for (int i = 0; i < lstPOFlddetails.Count; i++)
                {
                    arrserplnDetails = AppHandle.SplitString(lstPOFlddetails[i], "|"); //separator
                    switch (arrserplnDetails[1].ToUpper())
                    {
                        case "FIELD":
                            WebAdminPageFactory.ProcessingOptionsPage.SetEditValue(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "DROPDOWN":
                            WebAdminPageFactory.ProcessingOptionsPage.SelectDropdownValue(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "CHECKBOX":
                            if (arrserplnDetails[2].ToUpper() == "ON")
                                WebAdminPageFactory.ProcessingOptionsPage.SelectCheckboxOn(arrserplnDetails[0]);
                            else
                                WebAdminPageFactory.ProcessingOptionsPage.SelectCheckboxOff(arrserplnDetails[0]);
                            break;
                    }
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

    }
}
