using System;
using System.Collections.Generic;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class ProfileReportsPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string txtReportFunctionIDORDesc = "XPAth;//*[contains(text(),'Report Function ID or Description')]/following-sibling::*/descendant::input[@type='text']";
        private static string buttonSearch = "XPath;//*[contains(text(),'Report Function ID or Description')]/following-sibling::*/descendant::input[@value='Search']";
        private static string buttonRun = "XPath;//*[@value='Run']";
        private static string mainbody = "XPAth;//*[@class='main']";
        private static string buttonChangeReportCriteria = "XPath;//*[contains(@value,'Change Report Criteria')]";
        private static string buttonChooseAnotherReport = "XPath;//*[contains(@value,'Choose Another Report')]";
        private static string ReportDetailsObj = "Xpath;//pre[contains(text(),*)]";
        private static string PageCellObj = "XPath;//*[@class='contentTable']/descendant::pre/ancestor::tr[1]/following-sibling::tr/descendant::a/ancestor::td[1]";

        public virtual void ClickOnSearchButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearch))
            {
                appHandle.ClickObjectViaJavaScript(buttonSearch);
            }
        }
         public virtual void ClickOnRunButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRun))
            {
                appHandle.ClickObjectViaJavaScript(buttonRun);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonChangeReportCriteria);
            }
        }

        public virtual bool SelectReport(string ReportIDORDesc)
        {
            bool Result = false;
            string RunTimeRadiobutton = "XPath;//*[contains(text(),'" + ReportIDORDesc + "')]/ancestor::tr[1]/descendant::*[@type='radio']";
            
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeRadiobutton, 200))
            {
                appHandle.ScrollToObject(RunTimeRadiobutton);
                Report.Info(ReportIDORDesc + " is to be selected.", ReportIDORDesc + "ToSelect", "True", appHandle);
                appHandle.ClickObjectViaJavaScript(RunTimeRadiobutton);
                Result = true;
                
            }
            return Result;
        }

        public virtual void EnterSearchCriteria(string StrSearchCriteriaPipeSearchValue)
        {
            StrSearchCriteriaPipeSearchValue = StrSearchCriteriaPipeSearchValue + ";";
            int EnteredCounter = 0;
            string[] arr = StrSearchCriteriaPipeSearchValue.Split(';');
            for (int a = 0; a < arr.Length - 1; a++)
            {
                string criterianame = arr[a].Split('|')[0].Trim();
                string criteriavalue = arr[a].Split('|')[1].Trim();
                string runtimeobj = "XPath;//*[contains(text(),'" + criterianame + "')]/following-sibling::*/descendant::*[1]";
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runtimeobj))
                {
                    appHandle.Set_field_value(runtimeobj, criteriavalue);
                    EnteredCounter++;
                }
                if (EnteredCounter == arr.Length - 1)
                {
                    break;
                }
            }
        }
        public virtual void ClickOnChangeReportCriteriaButton()

        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonChangeReportCriteria))
            {
                appHandle.ClickObjectViaJavaScript(buttonChangeReportCriteria);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRun);
            }
        }
        public virtual void ClickOnChooseAnotherReportButton()

        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonChooseAnotherReport))
            {
                appHandle.ClickObjectViaJavaScript(buttonChooseAnotherReport);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearch);
            }
        }
        public virtual string ReadReportDetails()
        {
            string Result = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ReportDetailsObj))
            {
                Result = appHandle.GetObjectText(ReportDetailsObj);
            }

            return Result;
        }

        public virtual int GetNumberOfPagesInReport()
        {
            int PageCount = 0;
            string temp = appHandle.GetObjectText(PageCellObj);
            temp = temp.Trim();
            string max = temp.Split(' ')[temp.Split(' ').Length - 1];
            if (max.Contains("."))
            {
                max = max.Replace(".", string.Empty);
            }
            PageCount = Int32.Parse(max);
            return PageCount;
        }
        public virtual bool VerifyPageFoundBySpecificCriteria(string strinput)
        {
            bool PageFound = false;
            int totPageCount = GetNumberOfPagesInReport();

            for (int a = 1; a <= totPageCount; a++)
            {
                if (ReadReportDetails().Contains(strinput))
                {
                    PageFound = true;
                }
            }
            return PageFound;
        }
        public virtual void ClickOnPageLinkByPageNumber(int pageNumber)
        {
            string pagenumber=pageNumber+"";
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(PageCellObj))
            {
                appHandle.ClickObjectViaJavaScript(PageCellObj+"/descendant::*[contains(text(),'"+pagenumber+"')]");
            }
            
        }
       
       public virtual bool CheckReportDetailPageLoaded()
       {
        bool Result=false;
        if (appHandle.GetObjectText(mainbody).Contains("Report Criteria"))
        {
        Result=true;  
        }
        return Result;
        }       

    }

}