using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminProductsCommonPage
    {

        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string tabbed_lnk_General = "XPath;//td[text()='General']";
        private static string tabbed_lnk_US_Regulatory = "XPath;//td[contains(text(),'U.S. Regulatory')]";
        private static string tabbed_lnk_New_Accounts = "XPath;//td[contains(text(),'New Accounts')]";
        private static string tabbed_lnk_Transaction_Processing = "XPath;//td[contains(text(),'Transaction Processing')]";
        private static string btn_Submit = "xpath;//input[@value='Submit']";
        private static string dropdownProductClass = "XPath;//*[contains(text(),'Product Class')]/following-sibling::*/select";
        private static string dropdownProductGroup = "XPath;//*[contains(text(),'Product Group')]/following-sibling::*/select";
        private static string buttonSearch = "XPath;//*[contains(text(),'Product Group')]/following-sibling::*/input";
        private static string tableProducts = "XPath;//*[contains(@class,'dataTables_scrollBody')]/descendant::tbody";
        private static string buttonCopy = "XPath;//*[@value='Copy']";
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string buttonDelete = "XPath;//*[@value='Delete']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        private static string tabbed_lnk_Interest = "Xpath;//td[text()='Interest']";
        private static string labelProductNumber = "XPath;//*[@class='pageHeadingParameters']";
        private static string mainbody = "XPAth;//*[@class='main']";

        public virtual void select_general_tab()
        {
            appHandle.Wait_for_object(tabbed_lnk_General, 3);
            appHandle.SelectTab(tabbed_lnk_General);
            appHandle.Wait_for_object(btn_Submit, 5);
        }
        public virtual void select_us_regulatory_tab()
        {
            appHandle.Wait_for_object(tabbed_lnk_US_Regulatory, 3);
            appHandle.SelectTab(tabbed_lnk_US_Regulatory);
            appHandle.Wait_for_object(btn_Submit, 5);
        }
        public virtual void select_new_accounts_tab()
        {
            appHandle.Wait_for_object(tabbed_lnk_New_Accounts, 3);
            appHandle.SelectTab(tabbed_lnk_New_Accounts);
            appHandle.Wait_for_object(btn_Submit, 5);
        }
        public virtual void select_transaction_processing_tab()
        {
            appHandle.Wait_for_object(tabbed_lnk_Transaction_Processing, 3);
            appHandle.SelectTab(tabbed_lnk_Transaction_Processing);
            appHandle.Wait_for_object(btn_Submit, 5);
        }

        public virtual void SelectProductClassGroup(string ProductClass, string ProductGroup)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownProductClass))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownProductClass, ProductClass);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownProductGroup, ProductGroup);
            }
        }

        public virtual void ClickOnSearchBUtton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearch))
            {
                appHandle.ClickObjectViaJavaScript(buttonSearch);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableProducts + "/descendant::td[1]/input");
            }
        }
        public virtual bool ClickOnCopyButton()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCopy))
            {
                appHandle.ClickObjectViaJavaScript(buttonCopy);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual bool SelectProductToBeCopied(string ProductNumber)
        {
            bool Result = false;
            string ProductObjRadiobutton = tableProducts + "/descendant::td[text()='" + ProductNumber + "']/ancestor::*[1]/td/input";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableProducts + "/descendant::td[1]/input"))
            {
                appHandle.ClickObjectViaJavaScript(ProductObjRadiobutton);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCopy))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void ClickOnEditButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tabbed_lnk_Transaction_Processing);
        }
        public virtual void ClickOnDeleteButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonDelete))
            {
                appHandle.ClickObjectViaJavaScript(buttonDelete);

            }
        }

        public virtual bool VerifyMessageInProductsPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual void select_Interest_tab()
        {
            appHandle.Wait_for_object(tabbed_lnk_Interest, 3);
            appHandle.SelectTab(tabbed_lnk_Interest);
            appHandle.Wait_for_object(buttonSubmit, 5);
        }
        public virtual bool CheckProductNumberLoaded(string ProductNumber)
        {
            bool Result = false;
            if (appHandle.GetObjectText(mainbody).Contains(ProductNumber))
            {
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(labelProductNumber))
                {
                    if (appHandle.GetObjectText(labelProductNumber).Contains(ProductNumber))
                    {
                        Result = true;
                    }
                }
            }

            return Result;
        }

    }
}