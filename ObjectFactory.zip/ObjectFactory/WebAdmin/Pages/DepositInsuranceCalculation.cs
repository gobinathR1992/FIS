using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;
using OpenQA.Selenium;

 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class DepositInsuranceCalculation
    { 
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonRun="XPath;//input[@name='submit']";

        public virtual void ClickOnRunButton()
        {
            
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRun))
            {
                appHandle.ClickObjectViaJavaScript(buttonRun);
                
            }
            
        }
    }
}