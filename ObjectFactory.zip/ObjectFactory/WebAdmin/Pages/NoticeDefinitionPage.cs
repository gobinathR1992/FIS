using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class NoticeDefinitionPage
    {
        WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tblNoticeDefinition = "XPath;//body[@class='main']/table[@id='mainTable']/tbody/tr/td[@id='content']/table/tbody/tr/td/form[@name='noticeDefinitionForm']/table[@class='contentTable']/tbody[1]";
        public static string ckbNoticeDeliveryInformation="Xpath;//input[@name='FWKNOTICE_NEEDSDELIVERYINFO']";
        public static string txtNoticeID="Xpath;//input[@name='FWKNOTICE_ID']";
        public static string txtNoticeDescription="Xpath;//input[@name='FWKNOTICE_DESCRIPTION']";
        public static string txtNoticeBundle="Xpath;//input[@name='FWKNOTICE_BUNDLE']";
        public static string txtNoticeBundleKey="Xpath;//input[@name='FWKNOTICE_BUNDLEKEY']";
        public static string drpNoticeCategory="Xpath;//select[@name='FWKNOTICE_CATEGORY']";

   
    }

}

