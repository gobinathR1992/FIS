using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class FundsAvailabilityPage
    { 
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string drpdownCheckHoldTable ="Xpath;//*[@name='PRODDFTD_HLDTBL']";
        private static string drpdownFloatHoldTable ="Xpath;//*[@name='PRODDFTD_FLTTBL']";

        public virtual bool VerifyRegulatory2DetailsbyFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "Check Hold Table":
                        if (appHandle.CheckValueInDropdown(drpdownCheckHoldTable, expval))

                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "Float Hold Table":
                        if (appHandle.CheckValueInDropdown(drpdownFloatHoldTable, (expval)))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }

            return result;
        }
        


    }
         
    }
