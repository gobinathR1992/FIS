using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class EditUserClassPage
    { 
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        
    public static string checkboxSelfEntitlement="XPath;//input[@name='SCAU0_ENTITLEMENTFLAG']";
    public static string buttonSubmit="XPath;//input[@name='submit']";
    public static string txtPasswordHistoryDays="XPath;//*[@name='SCAU0_PWDARCHIVEDAYS']";
    public static string txtPasswordHistoryNumbers ="XPath;//*[@name='SCAU0_NUMBEROFPWDSTOCHECK']";
    public virtual void ClickOnSelfEntitlementCheckbox()
    {
        Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxSelfEntitlement);
        if(appHandle.CheckCheckBoxChecked(checkboxSelfEntitlement))
        {
            appHandle.ClickObjectViaJavaScript(checkboxSelfEntitlement);
        }
        Report.Info("The Self-Entitlement checkbox is selected","selfpass","True",appHandle);
        
    
    }

    public virtual void ClickOnSubmitButton()
    {
        Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
        appHandle.ClickObjectViaJavaScript(buttonSubmit);
    }

    public virtual bool CheckSuccessMessage()
    {
        string expmsg=Data.Get("MsgUserClassModified");
        return appHandle.CheckSuccessMessage(expmsg);
    }

    public virtual void UpdatePasswordHistory(string Days,string No)
    {
        appHandle.WaitUntilElementExists(txtPasswordHistoryDays);
        appHandle.Set_field_value(txtPasswordHistoryDays,Days);
        appHandle.Set_field_value(txtPasswordHistoryNumbers,No);
    }

    }
}