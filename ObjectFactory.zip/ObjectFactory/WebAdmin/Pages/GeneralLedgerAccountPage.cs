using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;
using System.Collections.Generic;
using OpenQA.Selenium;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class GeneralLedgerAccountPage
    { 
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string DropdownGLType = "XPath;//*[contains(text(),'')]/ancestor::tr[1]/following-sibling::tr[1]/descendant::td/descendant::select[1]";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonAdd = "Xpath;//*[@value='Add']";
        private static string buttonSearch = "Xpath;//*[@value='Search']";
        private static string txtGLAccount = "Xpath;//*[contains(text(),'General Ledger Account:')]/parent::td/following-sibling::td/descendant::input";
        private static string txtDescription = "Xpath;//input[@name='description1']";
         private static string dropdownProductClass = "XPath;//*[contains(text(),'Product Class')]/following-sibling::*/select";
        private static string dropdownProductGroup = "XPath;//select[@name= 'productGroup']";
        private static string drpGlsetcode ="Xpath;//select[@name = 'glSetCode']";
        private static string dropdownsetcodeProductCls = "Xpath;//select[@name='productClass']";
        private static string drpsetcodeAssetclass = "Xpath;//select[@name ='assetClass']";
        private static string buttonCancel = "Xpath;//*[@value ='Cancel']";
        private static string buttonEdit = "Xpath;//*[@value = 'Edit']";
        private static string buttonDelete = "Xpath;//*[@value = 'Delete']";
        private static string checkboxLedgerAccount = "Xpath;//*[contains(text(),'Base Ledger Account Only:')]/parent::td/following-sibling::td/descendant::input";
        private static string tblsetcodetab = "Xpath;//*[contains(text(),'G/L Set Code')]/ancestor::*[@class='dataTables_scrollHead']/following-sibling::*/descendant::tbody";
        public static string SetCodeTable="Xpath;//*[contains(@class,'ledgerScrollable dataTable')]/tbody";
        private static string DropdownFATCAWithholding="Xpath;//*[@name='UTBLGLSC_DGLFATCAWTH']";
             
        public virtual string CreateGLAccount(string GLType,string Description,bool BaseLedgerAccountONorOFF)
        {
            string GLAccountNo = appHandle.CreateRamdomData(FieldType.NUMERIC, 1000, 9999, 4) + "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(DropdownGLType))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(DropdownGLType, GLType);
            }
            this.ClickOnAddButton();
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtGLAccount))
            {
                appHandle.Set_field_value(txtGLAccount, GLAccountNo);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDescription))
            {
                appHandle.Set_field_value(txtDescription, Description);
            }
            if (!BaseLedgerAccountONorOFF)
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Base Ledger Account Only") + "|" + Data.Get("OFF"));
            }
            else
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Base Ledger Account Only") + "|" + Data.Get("GLOBAL_ON"));
            }
            return GLAccountNo;
               
        }
        
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                
            }
        }
         public virtual bool VerifyMessageInInterestAddPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
                
            }
        }
        public virtual void ClickOnSearchButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSearch))
            {
                appHandle.ClickObjectViaJavaScript(buttonSearch);
                
            }
        }
        public virtual bool IsProdExistsMsg()
        {
            bool Result = false;
            try
            {
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX, 1))
                {
                    if (appHandle.GetObjectText(MSGBOX).Contains("already exists"))
                    {
                        Result = true;
                    }
                }
            }
            catch (Exception e) { }
            return Result;
        }
         public virtual void SelectProductClassGroup(string ProductClass, string ProductGroup)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownProductClass))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownProductClass, ProductClass);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownProductGroup, ProductGroup);
            }
        }

        public virtual bool VerifyDataInSetCode(string refColumnValuesSemicolonDelimited)
        {
            bool Result = false;
            int matchCount=0;
            refColumnValuesSemicolonDelimited=refColumnValuesSemicolonDelimited+"|";
            string[] arr=refColumnValuesSemicolonDelimited.Split('|');
            for(int a=0;a<arr.Length-1;a++)
            {
                if(Profile7CommonLibrary.VerifyDataInTableByColumnValues(arr[a]))
                {
                    matchCount++;
                }
                if(matchCount==arr.Length-1)
                {
                    Result=true;
                    break;
                }
            }

            return Result;
            
        }

        public virtual void SelectSetCodes(string ProductClass, string AssetClass)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownsetcodeProductCls))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownsetcodeProductCls, ProductClass);
                appHandle.WaitForSpecifiedTime(5);
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpsetcodeAssetclass, AssetClass);
            }
        }
        public virtual string EnterReclassificationDepositType(string Glsetcode,string AdditionalDetailLabelnameLabelValueByPipeDelimited = "")
        {
            string tagname = "";
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpGlsetcode, Glsetcode);
            if (!string.IsNullOrEmpty(AdditionalDetailLabelnameLabelValueByPipeDelimited))
            {
                AdditionalDetailLabelnameLabelValueByPipeDelimited = AdditionalDetailLabelnameLabelValueByPipeDelimited + ";";
                string[] arr = AdditionalDetailLabelnameLabelValueByPipeDelimited.Split(';');
                for (int a = 0; a < arr.Length - 1; a++)
                {
                    string LabelName = arr[a].Split('|')[0];
                    string LabelValue = arr[a].Split('|')[1];
                    string RunTimeObj = "XPath;//*[contains(text(),'" + LabelName + "')]/ancestor::*[1]/following-sibling::*/*[1]";
                    try
                    {
                        IWebElement obj = (IWebElement)appHandle.FindElement(RunTimeObj);
                        tagname = obj.TagName;
                        if (tagname.Trim().ToUpper().Equals("SELECT"))
                        {
                            appHandle.SelectDropdownSpecifiedValueByPartialText(RunTimeObj, LabelValue);
                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            if (LabelValue.Equals("ON"))
                            {
                                if (appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                }
                            }
                            else
                            {
                                if (!appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                }
                            }

                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && !appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            appHandle.Set_field_value(RunTimeObj, LabelValue);
                        }
                    }
                    catch (Exception e) { }
                }
            }
            return tagname;
            
        }
        public virtual void ClickOnCancelButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCancel))
            {
                appHandle.ClickObjectViaJavaScript(buttonCancel);
                
            }
        }

        public virtual void SelectGlSetCode(string glsetcode)
        {
            string runTimeObj = "XPath;//*[@name='glSetCode'][@value='" + glsetcode + "']";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runTimeObj))
            {
                appHandle.ClickObjectViaJavaScript(runTimeObj);
            }
        }
        public virtual void ClickOnEditButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
                
            }
        }
        public virtual string EditReclassificationDepositType(string AdditionalDetailLabelnameLabelValueByPipeDelimited = "")
        {
            string tagname = "";
            if (!string.IsNullOrEmpty(AdditionalDetailLabelnameLabelValueByPipeDelimited))
            {
                AdditionalDetailLabelnameLabelValueByPipeDelimited = AdditionalDetailLabelnameLabelValueByPipeDelimited + ";";
                string[] arr = AdditionalDetailLabelnameLabelValueByPipeDelimited.Split(';');
                for (int a = 0; a < arr.Length - 1; a++)
                {
                    string LabelName = arr[a].Split('|')[0];
                    string LabelValue = arr[a].Split('|')[1];
                    string RunTimeObj = "XPath;//*[contains(text(),'" + LabelName + "')]/ancestor::*[1]/following-sibling::*/*[1]";
                    try
                    {
                        IWebElement obj = (IWebElement)appHandle.FindElement(RunTimeObj);
                        tagname = obj.TagName;
                        if (tagname.Trim().ToUpper().Equals("SELECT"))
                        {
                            appHandle.SelectDropdownSpecifiedValueByPartialText(RunTimeObj, LabelValue);
                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            if (LabelValue.Equals("ON"))
                            {
                                if (appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                }
                            }
                            else
                            {
                                if (!appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                }
                            }

                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && !appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            appHandle.Set_field_value(RunTimeObj, LabelValue);
                        }
                    }
                    catch (Exception e) { }
                }
            }
            return tagname;
            
        }
        public virtual void ClickOnDeleteButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonDelete))
            {
                appHandle.ClickObjectViaJavaScript(buttonDelete);
                
            }
        }
        public virtual void VerifyGlSetcodeExistsInTable(string GLSetcode)
        {
            if(appHandle.GetObjectText(SetCodeTable).Contains(GLSetcode))
            {
                appHandle.SelectRadioButtonInTable(SetCodeTable,GLSetcode);
                ClickOnDeleteButton();
                appHandle.SwitchTo(SwitchInto.ALERT);
                appHandle.Wait_For_Specified_Time(3);
                appHandle.PerformActionOnAlert(PopUpAction.Accept);
                appHandle.SwitchTo(SwitchInto.DEFAULT);
            }
        
        }
        public virtual void SelectFATCAWithholdingInSetCode(string FATCAWithholding)
        {
            appHandle.WaitUntilElementExists(DropdownFATCAWithholding);
            appHandle.SelectDropdownSpecifiedValue(DropdownFATCAWithholding,FATCAWithholding);
        }
        public virtual void SelectGlSetcodeExistsInTable(string GLSetcode)
        {
            if(appHandle.GetObjectText(SetCodeTable).Contains(GLSetcode))
            {
                appHandle.SelectRadioButtonInTable(SetCodeTable,GLSetcode);
                ClickOnEditButton();
            }
        }
        
    }
}