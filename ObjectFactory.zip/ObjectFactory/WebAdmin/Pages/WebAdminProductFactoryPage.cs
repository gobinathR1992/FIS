
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminProductFactoryPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        //10/10/2018
        private static string ProductClassDropDown = "name;productClass";
        private static string ProductGroupDropDown = "name;productGroup";
        private static string SearchButton = "name;search";
        private static string ProdListTable = "XPath;.//*[contains(@class,'dataTables')][contains(@id,'products-list')]";
        private static string CopyButton = "Xpath;//input[@value='Copy']";
        private static string btn_Edit = "Xpath;//input[@value='Edit']";
        //private static string btn_Delete = "Xpath;//input[@value='Delete']";
        private static string btn_Submit = "Xpath;//input[@value='Submit']";

        public static string dropdownProductClass="XPath;//select[@name='productClass']";
        public static string dropdownProductGroup="XPath;//select[@name='productGroup']";
        public static string buttonSearch="XPath;//input[@name='search']";

        public static string tableProduct="XPath;//table[@id='products-list']";


        public virtual void SearchProduct(string ProductClassDropdownval, string ProductGroupDropdownval)
        {
            WebAdminMasterPage WebAdminMasterPage = new WebAdminMasterPage();
            WebAdminMasterPage.NavigatetoProductFactoryPage();
            appHandle.SelectDropdownSpecifiedValue(ProductClassDropDown, ProductClassDropdownval);
            appHandle.SelectDropdownSpecifiedValue(ProductGroupDropDown, ProductGroupDropdownval);
            appHandle.ClickObject(SearchButton);
            appHandle.SyncPage();
            appHandle.Wait_for_object(CopyButton, 5);
        }

        public virtual void select_product_radio_button_from_product_list_table(string sProductNumber)
        {

            string ProdRadioButton = "XPAth;//*[text()='" + sProductNumber + "']/ancestor::*[1]/descendant::input";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ProdRadioButton))
            {
                appHandle.ClickObjectViaJavaScript(ProdRadioButton);
            }

        }

        public virtual void SelectProductFromProductList(string sProductNumber)
        {
            select_product_radio_button_from_product_list_table(sProductNumber);
            select_copy_button();
            
        }

        public virtual void select_copy_button()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(CopyButton))
            {
            appHandle.ClickObjectViaJavaScript(CopyButton);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(btn_Submit);
            }
      
        }

        public virtual void select_edit_button()
        {
            appHandle.ClickObject(btn_Edit);
            appHandle.SyncPage();
            appHandle.Wait_for_object(btn_Submit, 3);
        }

        public virtual void get_product(string sProductClassDropdown, string sProductGroupDropdown, string sProductNumber)
        {
            try
            {
                WebAdminMasterPage objWebAdminMasterPage = new WebAdminMasterPage();

                if ((sProductClassDropdown == "") || (sProductGroupDropdown == "") || (sProductNumber == ""))
                {
                    Report.Fail("Please check the parameters.");
                }
                else
                {
                    objWebAdminMasterPage.NavigatetoProductFactoryPage();
                    appHandle.SelectDropdownSpecifiedValue(ProductClassDropDown, sProductClassDropdown);
                    appHandle.SelectDropdownSpecifiedValue(ProductGroupDropDown, sProductGroupDropdown);
                    appHandle.ClickObject(SearchButton);
                    appHandle.SyncPage();
                    appHandle.Wait_for_object(CopyButton, 5);
                    select_product_radio_button_from_product_list_table(sProductNumber);
                    select_edit_button();
                    Report.Pass("Successfully navigated to the product - " + sProductNumber);
                }
            }
            catch (System.Exception)
            {

            }

        }


        public virtual void SelectProductFromTable(string prodclass,string prodgroup,string productnumber)
        {
            string dynamicprodobj="XPath;";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownProductClass);
            appHandle.SelectDropdownSpecifiedValue(dropdownProductClass,prodclass);
            appHandle.SelectDropdownSpecifiedValue(dropdownProductGroup,prodgroup);
            appHandle.ClickObjectViaJavaScript(buttonSearch);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableProduct);



        }


    }
}