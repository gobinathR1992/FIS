using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class GeneralPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtDescription="XPath;//input[@name='PRODCTL_DES']";
        public static string txtStartDate="XPath;//input[@name='PRODCTL_DTBEG']";
        public static string txtEndDate="XPath;//input[@name='PRODCTL_ENDATE']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public static string txtMinimumOpeningDeposit="XPath;//input[@name='PRODCTL_MINODA']";
        
          public virtual bool EnterDetailsInGeneralSection(string descriptionval,string startdate,string enddate)
         {
               Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtStartDate);
               appHandle.Set_field_value(txtDescription,descriptionval);
               appHandle.Set_field_value(txtStartDate,startdate);
               appHandle.Set_field_value(txtEndDate,enddate);
               appHandle.ClickObjectViaJavaScript(buttonSubmit);
               return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

         }

          public virtual bool EnterValueForDescriptionField(string descriptionval)
          {
               Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDescription);
               appHandle.Set_field_value(txtDescription,descriptionval);
               appHandle.ClickObjectViaJavaScript(buttonSubmit);
               return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
          }

       public virtual bool EnterValueInMinimumOpeningDepositField(string mindepval)
       {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtMinimumOpeningDeposit);
            appHandle.Set_field_value(txtMinimumOpeningDeposit,mindepval);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

       }
       public virtual void EnterValuesForGeneralPageField(string sLabelNameLabelValuePipeDelimited)
          {
               Profile7CommonLibrary.EnterDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
               appHandle.ClickObjectViaJavaScript(buttonSubmit);
          }


          
    }
}