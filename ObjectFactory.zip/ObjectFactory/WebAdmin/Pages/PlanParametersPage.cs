using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class PlanParametersPage
    {
        WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtSericeFeePlan = "XPath;//input[@name='FEEPLN_PLAN']";
        public static string txtEffectiveDate = "XPath;//input[@name='FEEPLN_FEEDT']";
        public static string txtPlanDescription = "XPath;//input[@name='FEEPLN_DESC']";
        public static string drpPlanType = "XPath;//select[@name='FEEPLN_PLTP']";
        public static string drpBalanceUsedFeeComputation = "XPath;//select[@name='FEEPLN_FEEBAL']";
        public static string drpFeeBalanceRoundingMethod = "XPath;//select[@name='FEEPLN_FEEBALRM']";
        public static string txtFeeBalanceRoundingFactor = "XPath;//input[@name='FEEPLN_FEEBALRF']";
        public static string chkConvertAmountFields = "XPath;//input[@name='FEEPLN_CURFLG']";
        public static string drpBaseCurrency = "XPath;//select[@name='FEEPLN_PLANCUR']";
        public static string drpExchangeRate = "XPath;//select[@name='FEEPLN_PLANEXC']";
        public static string txtMinimumFeeAmount = "XPath;//input[@name='FEEPLN_FEEMIN']";
        public static string txtMaximumFeeAmount = "XPath;//input[@name='FEEPLN_FEEMAX']";
        public static string txtBaseFeeAmount = "XPath;//input[@name='FEEPLN_BASE']";
        public static string txtFreeTransactionFee = "XPath;//input[@name='FEEPLN_FTRF']";
        public static string txtMinimumTransactionFee = "XPath;//input[@name='FEEPLN_MINTRF']";
        public static string txtMaximumTransactionFee = "XPath;//input[@name='FEEPLN_MAXTRF']";
        public static string txtOtherTransactionFee = "XPath;//input[@name='FEEPLN_OTRTRF']";
        public static string chkDailyFeeSubjecttoRegulationDD = "XPath;//input[@name='FEEPLN_DLYREGDD']";
        public static string btnSubmitServiceFeePlan = "XPath;//input[@name='submit'][@value='Submit']";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }
        public static string btnFees="Xpath;//td[contains(text(),'Fees')]";

        /// <summary>
        /// To Click on Submit button in PlanParametersPage.
        /// <param></param> 
        /// <returns></returns>
        /// <example>ClickOnAddServiceFeePlanSubmitButton()</example>
        public void ClickOnAddServiceFeePlanSubmitButton()
        {
            try
            {
                AppHandle.WaitUntilElementVisible(btnSubmitServiceFeePlan);
                AppHandle.WaitUntilElementClickable(btnSubmitServiceFeePlan);
                AppHandle.SelectButton(btnSubmitServiceFeePlan);
                AppHandle.WaitUntilElementClickable(PlanParametersPage.txtSericeFeePlan);
                AppHandle.Wait_For_Specified_Time(5);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To enter value in Edit Feild in PlanParametersPage.
        /// <param name = "Feild Name"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetEditValue(sfieldname,sfieldvalue)</example>
        public virtual void SetEditValue(string sfieldname, string sfieldvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sfieldname);
                AppHandle.WaitUntilElementClickable(sfieldname);
                AppHandle.Set_field_value(sfieldname, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select dropdown value in PlanParametersPage.
        /// <param name = "dropdown Name"></param> 
        /// <param name = "dropdown Value"></param> 
        /// <returns></returns>
        /// <example>SelectDropdownValue(sdrpname,sdrpvalue)</example>
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sdrpname);
                AppHandle.WaitUntilElementClickable(sdrpname);
                AppHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select checkbox on in PlanParametersPage.
        /// <param name = "checkbox"></param> 
        /// <returns></returns>
        /// <example>SelectCheckboxOn(schkname)</example>
        public virtual void SelectCheckboxOn(string schkname)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(schkname);
                AppHandle.WaitUntilElementClickable(schkname);
                AppHandle.Select_CheckBox(schkname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select checkbox off in PlanParametersPage.
        /// <param name = "checkbox"></param> 
        /// <returns></returns>
        /// <example>SelectCheckboxOff(schkname)</example>
        public virtual void SelectCheckboxOff(string schkname)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(schkname);
                AppHandle.WaitUntilElementClickable(schkname);
                AppHandle.DeSelectCheckBox(schkname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        public virtual void ClickOnFeesTab()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnFees);
            appHandle.ClickObjectViaJavaScript(btnFees);
        }

    }

}