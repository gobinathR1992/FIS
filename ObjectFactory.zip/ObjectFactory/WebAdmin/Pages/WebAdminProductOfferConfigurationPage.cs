using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Profile7Automation.Libraries.Util;
using System;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminProductOfferConfigurationPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string ChannelDropdown = "XPath;.//Select[@name='UTBLOFFER_CHANID']";
        private static string AddButton = "XPath;//INPUT[@value='Add']";
        private static string ProductOffersLink = "XPath;//td[text()='Product Offers']";
        //private static string ProductTable="XPath;.//table[@class='ledgerScrollable dataTable']";
        private static string ProductTable = "XPath;//div[@class='dataTables_scrollBody']//table";
        private static string RelationshipButton = "XPath;//input[@name='relationships']";
        private static string btn_Submit = "XPath;//input[@value='Submit']";
        private static string tableProducts = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";
        private static string dropdownProductType = "XPath;//*[contains(text(),'Product Type')]/ancestor::td/following-sibling::td/select";
        public static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        public static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p";
        public static string ApplicationDate = new WebAdminProductOfferConfigurationPage().GetApplicationDate();
        private static string txtStartDate = "XPath;//*[@name='UTBLOFFER_SDATE']";
        private static string txtExpirationDate = "XPath;//*[@name='UTBLOFFER_EDATE']";
        private static string txtProductDescription = "Xpath;//*[@name='UTBLOFFER_PRODDESC']";
        private static string txtDefaultValues = "XPath;//*[@name='UTBLOFFER_DVAL']";
        private static string txtURL = "XPath;//*[@name='UTBLOFFER_URL']";
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string checkboxDisplayRates = "XPath;//*[contains(text(),'Display Rates')]/ancestor::td/following-sibling::*/input";
        private static string checkboxAllowDebitsForChannel = "XPath;//*[contains(text(),'Allow Debits for Channel')]/ancestor::td/following-sibling::*/input";
        private static string checkboxAllowCreditsForChannel = "XPath;//*[contains(text(),'Allow Credits for Channel')]/ancestor::td/following-sibling::*/input";
        private static string checkboxCreationMethod = "XPath;//*[contains(text(),'Creation Method')]/ancestor::td/following-sibling::*/input";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        private static string buttonCancel = "Xpath;//*[@value='Cancel']";
        public static string tableRelationships = "XPAth;//table[@id='relationship-forms-list']/tbody";
        public static string txtProdStartDate = "Xpath;//input[@name='PRODCTL_DTBEG']";
        private static string drpDownGeneralLedgerSetCode = "Xpath;//*[@class='fieldLabel'][contains(.,'General Ledger Set Code')]/following-sibling::td/select";
        private static string drpDownAccrualBase = "Xpath;//*[@class='fieldLabel'][contains(.,'Accrual Base')]/following-sibling::td/select";
        private static string drpDownAccrualMethod = "Xpath;//select[@name='PRODDFTD_IACM']";
        private static string chkboxElectronicTransferPayoffAllowed = "Xpath;//input[@name='PRODCTL_POEFT']";
        private static string txtOriginalIssueDiscount = "Xpath;//input[@name='PRODDFTD_OID']";
        private static string dropdownCurrency = "Xpath;//select[@name ='PRODDFTL_CRCD']";
        private static string dropdownBillPrintDesign = "Xpath;//select[@name ='PRODCTL_BFP']";

        public virtual void NavigatetoProductOfferConfigurationPage()
        {
            WebAdminMasterPage objWebAdminMasterPage = new WebAdminMasterPage();
            if (!appHandle.IsObjectExists(ProductOffersLink))
            {
                objWebAdminMasterPage.SelectProductFactoryMenuLink();
                appHandle.Wait_for_object(ProductOffersLink, 3);
            }
            SelectProductOffersSubMenuLink();
            appHandle.SyncPage();
            appHandle.Wait_For_Specified_Time(5);
        }
        public virtual void SelectProductOffersSubMenuLink()
        {
            appHandle.ClickObject(ProductOffersLink);
            appHandle.SyncPage();
            appHandle.Wait_for_object(ChannelDropdown, 10);
        }
        public virtual void SelectChannel(string channelname)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ChannelDropdown))
            {
                appHandle.SelectDropdownSpecifiedValue(ChannelDropdown, channelname);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableProducts + "/descendant::td[1]");
        }
        public virtual void ClickAdd()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(AddButton))
            {
                appHandle.ClickObjectViaJavaScript(AddButton);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownProductType);

        }
        public virtual void select_product_from_product_list_table(string ProductNumber)
        {
            appHandle.SelectRadioButtonInTable(ProductTable, ProductNumber);
        }
        public virtual void ClickRelationshipButton()
        {
            appHandle.ClickObject(RelationshipButton);
            appHandle.Wait_for_object(btn_Submit, 3);
        }
        public virtual bool WaitUntilProductOfferConfigurationPageLoads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ChannelDropdown))
            {
                result = true;
            }

            return result;

        }

        public virtual void EnterDetailsAddProductOffer(string NewProductNumber, string ProdDetailsOfCopiedFromProduct)
        {
            string[] arr = ProdDetailsOfCopiedFromProduct.Split('|');

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownProductType))
            {
                SelectProductTypeInProductOfferByProductRef(NewProductNumber);
                appHandle.Set_field_value(txtStartDate, arr[0]);
                appHandle.Set_field_value(txtExpirationDate, arr[1]);
                appHandle.Set_field_value(txtProductDescription, NewProductNumber);
                appHandle.Set_field_value(txtURL, arr[2]);
                appHandle.Set_field_value(txtDefaultValues, arr[3]);
                if (arr[4].Contains("true"))
                {
                    appHandle.ClickObjectViaJavaScript(checkboxDisplayRates);
                }
                if (arr[5].Contains("true"))
                {
                    appHandle.ClickObjectViaJavaScript(checkboxCreationMethod);
                }
                if (arr[6].Contains("true"))
                {
                    appHandle.ClickObjectViaJavaScript(checkboxAllowDebitsForChannel);
                }
                if (arr[7].Contains("true"))
                {
                    appHandle.ClickObjectViaJavaScript(checkboxAllowCreditsForChannel);
                }
            }
        }

        public virtual string GetApplicationDate()
        {
            string result = "";
            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }
        public virtual void SelectProductFromProductListTable(string ProdNumber)
        {

            int locator = 0;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableProducts + "/tr[1]/descendant::input"))
            {
                string temp = appHandle.GetObjectText(tableProducts);
                string[] arr = temp.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                for (int a = 0; a < arr.Length; a++)
                {
                    if (arr[a].Contains(ProdNumber))
                    {
                        locator = a + 1;
                        break;
                    }
                }
            }
            appHandle.ClickObjectViaJavaScript(tableProducts + "/tr[" + locator + "]/descendant::input");
        }
        public virtual string GetStandardProdDetails(string StandProdNumber)
        {
            string ProductDetails = "";
            List<string> ProdDetails = new List<String>();
            string StartDate = appHandle.GetSpecifiedObjectAttribute(txtStartDate, "value").Trim();
            string ExpirationDate = appHandle.GetSpecifiedObjectAttribute(txtExpirationDate, "value").Trim();
            string URL = appHandle.GetSpecifiedObjectAttribute(txtURL, "value").Trim();
            string DefaultValue = appHandle.GetSpecifiedObjectAttribute(txtDefaultValues, "value").Trim();
            string checkPropertyDisplayAlert = appHandle.GetSpecifiedObjectAttribute(checkboxDisplayRates, "checked");
            string checkPropertyCreationMethod = appHandle.GetSpecifiedObjectAttribute(checkboxCreationMethod, "checked");
            string checkPropertyAllowDebitsForChannel = appHandle.GetSpecifiedObjectAttribute(checkboxAllowDebitsForChannel, "checked");
            string checkPropertyAllowCreditsForChannel = appHandle.GetSpecifiedObjectAttribute(checkboxAllowDebitsForChannel, "checked");
            ProdDetails.Add(StartDate);
            ProdDetails.Add(ExpirationDate);
            ProdDetails.Add(URL);
            ProdDetails.Add(DefaultValue);
            ProdDetails.Add(checkPropertyDisplayAlert);
            ProdDetails.Add(checkPropertyCreationMethod);
            ProdDetails.Add(checkPropertyAllowDebitsForChannel);
            ProdDetails.Add(checkPropertyAllowCreditsForChannel);
            ProductDetails = string.Join("|", ProdDetails);
            return ProductDetails;
        }
        public virtual bool ClickOnEditButton()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtStartDate))
                {
                    result = true;
                }
            }
            return result;
        }
        public virtual bool ClickOnSubmitButton()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btn_Submit))
            {
                appHandle.ClickObjectViaJavaScript(btn_Submit);
            }
            return result;
        }
        public virtual bool VerifyMessageProductOfferConfigurationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void ClickONCancelButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCancel))
            {
                appHandle.ClickObjectViaJavaScript(buttonCancel);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(ChannelDropdown);
        }
        public virtual string GetRelationshipsDetailsFromProductToBeCopied(string ProductNumber)
        {
            string RelationShipDetails = "";
            List<string> RelationsListStatus = new List<string>();
            int numberofCheckBoxes = appHandle.GetRowCountfromList(tableRelationships);
            string runTimeStatCheck = "";
            string RelationDesc = "";
            for (int a = 1; a < numberofCheckBoxes; a++)
            {
                runTimeStatCheck = appHandle.GetSpecifiedObjectAttribute(tableRelationships + "/tr[" + a + "]/td[1]/input", "checked");
                if (string.IsNullOrEmpty(runTimeStatCheck)) { continue; }
                if (runTimeStatCheck.Equals("true"))
                {
                    RelationDesc = appHandle.GetObjectText(tableRelationships + "/tr[" + a + "]/td[1]/input/ancestor::*[1]/following-sibling::td[2]");
                    RelationsListStatus.Add(RelationDesc);
                }


            }
            RelationShipDetails = string.Join("|", RelationsListStatus);
            return RelationShipDetails;
        }
        public virtual bool ClickOnRelationshipButton()
        {
            bool Result = false;

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RelationshipButton))
            {
                appHandle.ClickObjectViaJavaScript(RelationshipButton);
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btn_Submit))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void SetRelationshipForSpecificedProductNumber(string productNumber, string RelationShipDetailsBaseProduct = "")
        {

            string RunTimeCheckbox = "";
            SelectProductFromProductListTable(productNumber);            
            ClickOnRelationshipButton();
            if (!string.IsNullOrEmpty(RelationShipDetailsBaseProduct))
            {
                string[] arr = RelationShipDetailsBaseProduct.Split('|');
                for (int b = 0; b < arr.Length; b++)
                {
                    RunTimeCheckbox = "XPath;//td[text()='" + arr[b] + "']/preceding-sibling::td/input";
                    appHandle.ClickObjectViaJavaScript(RunTimeCheckbox);
                }

            }
        }
        public virtual void SelectProductTypeInProductOfferByProductRef(string Productref)
        {
            string text = appHandle.GetObjectText(dropdownProductType + "/parent::*[1]");
            string[] arr = text.Split(new string[] { "      \r\n       " }, StringSplitOptions.None);
            // List<string> DropdownOptionsList = new List<string>();
            for (int a = 1; a < arr.Length; a++)
            {
                if (arr[a].Trim().Substring(0,4).Equals(Productref))
                {
                    appHandle.SelectDropdownValueByIndex(dropdownProductType, a);
                    break;
                }
            }
        }
        public virtual void UpdateProductGeneralSection(string StartDate)
        {
            appHandle.Set_field_value(txtProdStartDate, StartDate);

        }
        public virtual void UpdateProductGeneralSection(string StartDate, string GLSetCodeNumber, string OriginalIssueDiscount = "",string BillPrintDesign="", string Currency="")
        {
            if (!string.IsNullOrEmpty(StartDate))
            {
                appHandle.Set_field_value(txtProdStartDate, StartDate);
            }
            if (!string.IsNullOrEmpty(GLSetCodeNumber))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpDownGeneralLedgerSetCode, GLSetCodeNumber);
            }
            if (!string.IsNullOrEmpty(OriginalIssueDiscount))
            {
                if ((OriginalIssueDiscount.ToLower().Contains("on")) && (appHandle.CheckCheckBoxChecked(txtOriginalIssueDiscount) == false))
                {
                    appHandle.ClickObjectViaJavaScript(txtOriginalIssueDiscount);
                }
                else if((OriginalIssueDiscount.ToLower().Contains("on")) && (appHandle.CheckCheckBoxChecked(txtOriginalIssueDiscount) == true))
                {}
                else if((OriginalIssueDiscount.ToLower().Contains("off")) && (appHandle.CheckCheckBoxChecked(txtOriginalIssueDiscount) == true))
                {
                    appHandle.ClickObjectViaJavaScript(txtOriginalIssueDiscount);
                }
                else if((OriginalIssueDiscount.ToLower().Contains("off")) && (appHandle.CheckCheckBoxChecked(txtOriginalIssueDiscount) == false))
                {}
            }
            if (!string.IsNullOrEmpty(BillPrintDesign))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBillPrintDesign, BillPrintDesign);
            }
            if (!string.IsNullOrEmpty(Currency))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownCurrency, Currency);
            }
        }
        public virtual void UpdateTransactionProcessingPayoff(string ElectronicTransferPayoffAllowed)
        {
            if (!string.IsNullOrEmpty(ElectronicTransferPayoffAllowed)){
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chkboxElectronicTransferPayoffAllowed))
                {
                    if ((ElectronicTransferPayoffAllowed.ToLower().Contains("on") && (appHandle.CheckCheckBoxChecked(chkboxElectronicTransferPayoffAllowed)) == false))
                    {
                        appHandle.ClickObjectViaJavaScript(chkboxElectronicTransferPayoffAllowed);
                    }
                    else if ((ElectronicTransferPayoffAllowed.ToLower().Contains("on") && (appHandle.CheckCheckBoxChecked(chkboxElectronicTransferPayoffAllowed)) == true)) 
                    {}
                    else if ((ElectronicTransferPayoffAllowed.ToLower().Contains("off") && (appHandle.CheckCheckBoxChecked(chkboxElectronicTransferPayoffAllowed)) == false)) { }
                    else if ((ElectronicTransferPayoffAllowed.ToLower().Contains("off") && (appHandle.CheckCheckBoxChecked(chkboxElectronicTransferPayoffAllowed)) == true))
                    {
                        appHandle.ClickObjectViaJavaScript(chkboxElectronicTransferPayoffAllowed);
                    }
                }
                }
        }
    }
}