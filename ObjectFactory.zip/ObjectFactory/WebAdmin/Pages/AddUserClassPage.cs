using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class AddUserClassPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string buttonAdd="XPath;//input[@name='add']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public static string txtUserClass="XPath;//input[@name='SCAU0_UCLS']";
        public static string txtDescription="XPath;//input[@name='SCAU0_DESC']"; 
        public static string dropdownMenuLinkage="XPath;//select[@name='SCAU0_MENU']";       
        public static string txtMinimumPasswordLength="XPath;//input[@name='SCAU0_PWDLEN']";
        public static string txtMaximumNumberofRetries="XPath;//input[@name='SCAU0_PWDTRY']";
        public static string txtForcedChangeDays="XPath;//input[@name='SCAU0_PWDCHG']";
        

        public virtual string CreateNewUserClass(string menulinkagename)
        {
            
            string userclass=appHandle.CreateRamdomData(FieldType.NUMERIC,10000,99999).ToString();
            string description=userclass;
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.Set_field_value(txtUserClass,userclass);
            appHandle.Set_field_value(txtDescription,description);
            appHandle.SelectDropdownSpecifiedValue(dropdownMenuLinkage,menulinkagename);
            appHandle.Set_field_value(txtMinimumPasswordLength,"3");
            appHandle.Set_field_value(txtMaximumNumberofRetries,"5");
            appHandle.Set_field_value(txtForcedChangeDays,"365");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            bool retval=appHandle.CheckSuccessMessage(Data.Get("SuccessMsgUserClass"));
            Report.Info("The UserClass is created Successfully "+userclass,"uclass","True",appHandle);
            return userclass;
        }


    }
}