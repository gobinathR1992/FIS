using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;
//using System.Collections.Generic;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class AddServiceFeeTransactionCodeGroupPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonAdd ="Xpath;//*[@value='Add']";      
        private static string  txtServiceFeesTransCodeGrp = "Xpath;//input[@name='tranCodeGroup']";
        private static string  txtServiceFeesTransCodeGrpDate = "Xpath;//input[@name='tranCodeGrpDate']";
        private static string  txtServiceFeesTransCodeGrpDescription = "Xpath;//input[@name='tranCodeGrpDesc']";
        private static string tableTransactionCodesAdd = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";        
        public static string buttonSubmit="XPath;//input[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonEdit = "Xpath;//*[@value = 'Edit']";
        private static string buttonDelete = "Xpath;//*[@value = 'Delete']";
        private static string txtloanfeegrp = "Xpath;//input[@name = 'feeGroup']";
        private static string PageCellObj = "XPath;//*[@class='contentTable']/descendant::tr/following-sibling::tr/descendant::a/ancestor::td[1]";
        private static string txtavailabledate = "XPath;//input[@name='dateAvailable']";
        private static string startdate = "Xpath;//input[@name='startDate']";
        private static string enddate = "Xpath;//input[@name='endDate']";

        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
                
            }
        }
        public virtual string GetColumnHeaderNameByColumnNumberInTCList(int ColNum)
        {
            string headername = "";
            string runtimeObj = tableTransactionCodesAdd + "/ancestor::*[@class='dataTables_scrollBody']/preceding-sibling::div/descendant::thead/tr[1]/th[" + ColNum + "]";
            headername = appHandle.GetObjectText(runtimeObj).Trim();
            return headername;
        }
        public virtual string AddRecordForTableUTBLTRNGRPT(string TCGDate,string TCGDescription,int noofRec, string columnvaluesseperatedbydelimsemicolon)
        {
			ClickOnAddButton();
            string ServiceFeesTransCodeGrp = "SFTCG"+appHandle.CreateRamdomData(FieldType.NUMERIC, 100, 999, 3) + "";
            appHandle.Set_field_value(txtServiceFeesTransCodeGrp,ServiceFeesTransCodeGrp);
            appHandle.Set_field_value(txtServiceFeesTransCodeGrpDate,TCGDate);
            appHandle.Set_field_value(txtServiceFeesTransCodeGrpDescription,ServiceFeesTransCodeGrp);
			
            string temp = "";
            bool DataEntered = false;
            int numberofDataToEnterPerRow = 0;
            int RecordCount = 0;
            columnvaluesseperatedbydelimsemicolon = columnvaluesseperatedbydelimsemicolon + ";";
            string[] arr = columnvaluesseperatedbydelimsemicolon.Split(';');
			int rowscount = noofRec;
            for (int c = 0; c < arr.Length - 1; c++)
            {
                for (int a = 1; a <= rowscount; a++)
                {
                    ClickOnAddButton();
                    if (arr[c].Contains("|"))
                    {
                        numberofDataToEnterPerRow = arr[c].Split('|').Length;
                    }
                    else { numberofDataToEnterPerRow = 1; }

                    for (int b = 1; b <= numberofDataToEnterPerRow; b++)
                    {
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableTransactionCodesAdd + "/tr[" + a + "]/td[" + b + "]/descendant::input"))
                        {
                            appHandle.Set_field_value(tableTransactionCodesAdd + "/tr[" + a + "]/td[" + b + "]/descendant::input", arr[c].Split('|')[b - 1]);

                            temp = temp + " , " + this.GetColumnHeaderNameByColumnNumberInTCList(b + 1) + " in level : " + a + " is entered as :" + arr[c].Split('|')[b - 1];
                            RecordCount++;
                            if (RecordCount == arr[c].Split('|').Length)
                            {
                                DataEntered = true;
                                RecordCount = 0;
                                break;
                            }
                        }
                        else
                        {
                            DataEntered = false;
                        }
                    }
                    c++;
                    if (c == arr.Length - 1)
                    {
                        if (DataEntered)
                        {
                            temp = temp.Substring(3, temp.Length - 3).Trim();
                            Report.Info(temp, "ServiceFeesTransactionCodeEntered", "True", appHandle);
                        }
                        break;
                    }
                    else { continue; }

                }
                if (c == arr.Length - 1) { break; } else { continue; }
            }
            ClickOnSubmitButton();
            if (appHandle.CheckTextExistsInTable(tableTransactionCodesAdd, ServiceFeesTransCodeGrp))
            {
                Report.Pass("Record has been added to  General Table Managment", "recpass", "True", appHandle);
            }
            else
            {
                Report.Fail("Record has not been added to General Table Managment", "recfail", "True", appHandle);
            }            
            return ServiceFeesTransCodeGrp;
        }					
        public virtual bool VerifyMessageInServiceFeeTranCodePage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;  
        }
       public virtual string GetPageHeader()
        {
            string pageheader = appHandle.GetObjectText("Xpath;//H1[contains(text(),'')]");
            return pageheader;
        }
        public virtual void SelectTranCodeFromTable(string trancode)
        {
            
            string runTimeObj = "XPath;//*[@type='radio'][@value='" + trancode + "']";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runTimeObj))
            {
                appHandle.ClickObjectViaJavaScript(runTimeObj);
            }
        }
        public virtual void ClickOnEditButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
                
            }
        }

         public virtual void ClickOnDeleteButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonDelete))
            {
                appHandle.ClickObjectViaJavaScript(buttonDelete);
                
            }
        }

        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                
            }
        }
        public virtual void DeleteRecordInTableUTBLTRNGRPT(string TranCode, string GroupDate)
        {
            string obj = "XPath;//input[@name='transCodeGrp'][@value='" + TranCode + " - " + GroupDate + "']";
            ////div[contains(@id,'top-level-list')][contains(@class,'ledgerScrollable dataTable')]
            appHandle.WaitUntilElementVisible(tableTransactionCodesAdd);
            appHandle.WaitUntilElementClickable(tableTransactionCodesAdd);
            appHandle.ClickObject(obj);
            ClickOnDeleteButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept); 
            if (appHandle.CheckTextExistsInTable(tableTransactionCodesAdd, TranCode))
            {                
                Report.Fail("Record has not been deleted in General Table Managment", "recfail", "True", appHandle);
            }
            else
            {
                Report.Pass("Record has been deleted in  General Table Managment", "recpass", "True", appHandle);
            }            
                   
        }        
      
     }
}