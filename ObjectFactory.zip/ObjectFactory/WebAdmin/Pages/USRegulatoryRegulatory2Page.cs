using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class USRegulatoryRegulatory2Page
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string ckbAggregateAmountsByCustomer = "XPath;//input[@name='CUVAR_REGCCOPT']";
        public static string ckbInclearingNewAccountCalculationmethod="Xpath;//input[@name='CUVAR_REGCCINC']";
        public static string ckbOneBusinessDayExtension="Xpath;//input[@name='CUVAR_OBDE']";
        public static string ckbTelephoneConsumerProtectionActEnabled="Xpath;//input[@name='CUVAR_TCPAENABLED']";
        public static string ckbPatriotActPOBoxVerification="Xpath;//input[@name='CUVAR_POCHK']";
        public static string txtNextDayAvailabilityAmount="Xpath;//input[@name='CUVAR_REGCCNDA']";
        public static string txtCashHoldAmount="Xpath;//input[@name='CUVAR_OBDECHA']";
        public static string txtNewAccountExceptionDays="Xpath;//input[@name='CUVAR_REGCCDCN']";
        public static string txtDaystoholdchecktype1and2amountsover1000="Xpath;//input[@name='CUVAR_REGCC1']";
        public static string txtDaystoextendchecktype3RTtableholddays="Xpath;//input[@name='CUVAR_REGCC2']";
        public static string txtMaximumnumberofdaysfornewaccountholds="Xpath;//input[@name='CUVAR_REGCCNAM']";
        public static string txtNumberofoverdraftstoqualifyasarepeatedoverdrafter="Xpath;//input[@name='CUVAR_REGCCRO']";
        public static string txtDaystoextendrepeatedoverdraftexceptions="Xpath;//input[@name='CUVAR_REGCC5']";
        public static string txtDaystoextendchecktype3RTtableholdsonamountsover1000="Xpath;//input[@name='CUVAR_REGCC3']";
        public static string txtRegCCLargeDepositsAmount="Xpath;//input[@name='CUVAR_REGCCLDA']";
        public static string txtDaystoextendchecktype4holds="Xpath;//input[@name='CUVAR_REGCC4']";
        public static string txtDaystoextendchecktype5holds="Xpath;//input[@name='CUVAR_REGCC6']";
        public static string txtDaystoextendchecktype6holds="Xpath;//input[@name='CUVAR_REGCC7']";
        public static string txtConformingLoanLimit="Xpath;//input[@name='CUVAR_CONFLNLIM']";
        public static string txtServicemembersCivilReliefActInterestRate="Xpath;//input[@name='CUVAR_SCRAIRN']";
        public static string txtMaximumMilitaryAPR="Xpath;//input[@name='CUVAR_MAXMILITARYAPR']";
        public static string txtServicemembersCivilReliefActOffsetPeriod="Xpath;//input[@name='CUVAR_SCRAOFF']";
        public static string txtNumberofATMPOSoverdraftstoqualifyasaexcessiveuse="Xpath;//input[@name='CUVAR_MAXAPODYEAR']";
        public static string txtRegDMinimumDepositdays="Xpath;//input[@name='CUVAR_REGDPENALTYPERIOD']";
        public static string txtRegDPenaltyAssessmentdays="Xpath;//input[@name='CUVAR_REGDASSESSPENALTYDAYS']";
        public static string txtRegEVaryingAmountNoticeDays="Xpath;//input[@name='CUVAR_REGEVARXFRNOTDAYS']";
        public static string txtFDIC370StandardMaximumInsuranceAmount="Xpath;//input[@name='CUVAR_FDIC370MAXDEPINSURANCE']";
        public static string txtEarlyInterventionNoticeDays="Xpath;//input[@name='CUVAR_EARLYINTERVENNOTDAYS']";
        public static string txtDelinquencyNoticeDays="Xpath;//input[@name='CUVAR_DELQNOTDAYS']";
        public static string txtRespondentID="Xpath;//input[@name='CUVAR_FR2420RESPONDENTID']";
        public static string txtTransactionReportingThreshold="Xpath;//input[@name='CUVAR_FR2420TRANTHR']";
        public static string txtTermThreshold="Xpath;//input[@name='CUVAR_FR2420TERMDTHR']";
        public static string txtDaystoDisputeCustomer="Xpath;//input[@name='CUVAR_DISPUTECUSTOMER']";
        public static string txtDaystoDisputeCSR="Xpath;//input[@name='CUVAR_DISPUTECSR']";
        public static string drpCheckHoldCalendar="Xpath;//select[@name='CUVAR_REGCCCHC']";
        public static string tblRegulatory2="Xpath;//table[@class='contentTable']//tbody//tr//td//table";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonSubmit = "XPath;//*[@Value='Submit']";
        private static string txtRepeatlyODthreshold ="Xpath;//*[@name='CUVAR_REPEATEDLYODTHRESHOLD']";
        public virtual void UpdateCardDetails(string Amount,string DepositAmount)
        {
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.WaitUntilElementExists(txtNextDayAvailabilityAmount);
            appHandle.Set_field_value(txtNextDayAvailabilityAmount,Amount);
            appHandle.SelectCheckBox(ckbInclearingNewAccountCalculationmethod);
            appHandle.Set_field_value(txtRegCCLargeDepositsAmount,DepositAmount);
            appHandle.Set_field_value(txtRepeatlyODthreshold,"6");
        }

        public virtual bool VerifyMessageInRegulatory2Page(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void ClickOnSubmitButton()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual void UpdateFDIC370MaximumInssuranceAmount(string Amount)
            {
                appHandle.WaitUntilElementExists(txtFDIC370StandardMaximumInsuranceAmount);
                appHandle.Set_field_value(txtFDIC370StandardMaximumInsuranceAmount,Amount);

            }
            
        public virtual void EnterRegulatory2PageOption(string strLabelNamePipeDelimitedLabelValue)
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(strLabelNamePipeDelimitedLabelValue);
            ClickOnSubmitButton();
        }
        public virtual bool VerifyRegulatory2DetailsbyFieldValuesByLabelNameFieldValue(string LabelNamePipeDelimitedExpectedvalue)
        {
            bool result = false;
            int matchcount = 0;
            LabelNamePipeDelimitedExpectedvalue = LabelNamePipeDelimitedExpectedvalue + ";";

            string[] arr = LabelNamePipeDelimitedExpectedvalue.Split(';');

            for (int a = 0; a < arr.Length - 1; a++)
            {
                string labelname = arr[a].Split('|')[0];
                string expval = arr[a].Split('|')[1];

                switch (labelname)
                {
                    case "Check Hold Calendar":
                        if (appHandle.GetSpecifiedObjectAttribute(drpCheckHoldCalendar, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                    case "Next Day Availability Amount":
                        if (appHandle.GetSpecifiedObjectAttribute(txtNextDayAvailabilityAmount, "value").Contains(expval))
                        {
                            result = true;
                            matchcount++;
                        }

                        break;
                }
                if (matchcount == arr.Length - 1)
                {
                    break;
                }
            }

            return result;
        }
        public virtual void UpdateRegulationCCControlOptions(string DaystoextendrepeatedOD,string Maximumnoofdaysfornewacct,string Daystoextendchecktype3RTtableholdsonamountsover5000,string Daystoextendchecktype3RTtableholddays)
        {
            appHandle.WaitUntilElementExists(txtDaystoextendrepeatedoverdraftexceptions);
            appHandle.Set_field_value(txtDaystoextendrepeatedoverdraftexceptions,DaystoextendrepeatedOD);
            appHandle.Set_field_value(txtMaximumnumberofdaysfornewaccountholds,Maximumnoofdaysfornewacct);
            appHandle.Set_field_value(txtDaystoholdchecktype1and2amountsover1000,Daystoextendchecktype3RTtableholdsonamountsover5000);
            appHandle.Set_field_value(txtDaystoextendchecktype3RTtableholddays,Daystoextendchecktype3RTtableholddays);


        }
         public virtual bool ClickOnInClearingNewAccountCalculationMethodCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbInclearingNewAccountCalculationmethod))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(ckbInclearingNewAccountCalculationmethod)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbInclearingNewAccountCalculationmethod);
                        if (appHandle.CheckCheckBoxChecked(ckbInclearingNewAccountCalculationmethod))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(ckbInclearingNewAccountCalculationmethod) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbInclearingNewAccountCalculationmethod);
                        if (appHandle.CheckCheckBoxChecked(ckbInclearingNewAccountCalculationmethod) == false) { Result = true; }
                    }
                }
            }
            return Result;


        }
        public virtual string GetRespondentIDFR2420()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtRespondentID);
            string RespondentID = appHandle.GetEditFieldValue(txtRespondentID);
            return RespondentID;
        }

        



    }

}
