using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class TableConfigurationInstitutionVariablesPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string dropdownATMCardOption = "XPath;//*[contains(text(),'ATM Card Option')]/ancestor::td[1]/following-sibling::*/descendant::select";
        private static string checkboxBuildCMSActionFileOption="XPath;//*[contains(text(),'Build CMS Action File Option')]/ancestor::td[1]/following-sibling::*/descendant::input";
        private static string txtCardAccountValidationRoutine="XPath;//*[contains(text(),'Card Account Validation Routine')]/ancestor::td[1]/following-sibling::*/descendant::input";

        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string buttonAdd = "XPath;//*[@value='Add']";
        private static string buttonMargins = "XPath;//*[@value='Margin']";
        private static string buttonDelete = "XPath;//*[@value='Delete']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonSubmit = "XPath;//*[@Value='Submit']";
        private static string txtRetailMidRate = "XPath;//input[@name='CRCD_MIDRATE']";
        // public virtual void SelectCurrencyCodeInCurrencyCodeList(string CurrencyCode)
        // {
        //     string RunTimeRadioButton = tableCurrencyCode + "/descendant::*[contains(text(),'" + CurrencyCode + "')]/preceding-sibling::td/input";
        //     if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeRadioButton))
        //     {
        //         appHandle.ClickObjectViaJavaScript(RunTimeRadioButton);
        //     }
        // }
        // public virtual bool VerifyCurrencyCodesPageLoads()
        // {
        //     return Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
        // }

        // public virtual bool ClickOnEditButton()
        // {
        //     bool Result = false;
        //     if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
        //     {
        //         appHandle.ClickObjectViaJavaScript(buttonEdit);
        //     }
        //     if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
        //     {
        //         Result = true;
        //     }
        //     return Result;
        // }
        // public virtual void EnterRetailMidRateInExchangeRates(string strRetailMidRate)
        // {
        //     if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
        //     {
        //         appHandle.Set_field_value(txtRetailMidRate, strRetailMidRate);
        //     }
        // }
        //  public virtual bool VerifyMessageInTableConfigurationCurrencyCodesPage(string sMessage)
        // {
        //    bool Result = false;
        //     if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
        //     {
        //         if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
        //         {
        //             Result = true;
        //         }
        //     }

        //     return Result;
        // }
         public virtual void ClickOnSubmitButton()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual void UpdateCardDetails(string AcctValidation,string ATMCardOption)
        {
            appHandle.WaitUntilElementExists(dropdownATMCardOption);
            appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownATMCardOption,ATMCardOption);
            appHandle.SelectCheckBox(checkboxBuildCMSActionFileOption);
            appHandle.Set_field_value(txtCardAccountValidationRoutine,AcctValidation);
        }
        public virtual bool VerifyMessageInTableConfiguration(string sMessage)
        {
            bool Result = false;
             if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
             {
                 if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                 {
                     Result = true;
                 }
             }

             return Result;
         }

 
    }
}