using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class TransactionCodeAuthorizationPage
    {
        WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string cbkAllUserclasses = "XPath;//input[@id='TRNAUT_UCLS']";
        public static string tblTransactionCodeAuthorizeUserClass = "XPath;//div[contains(@id,'sub-forms-list')]";
        
        public static string buttonSubmit="XPath;//input[@name='submit']";

        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To select or Deselect All Userclasses Checkbox in TransactionCodeAuthorizationPage.
        /// <param name = "sUserAction"></param> 'on or off
        /// <returns></returns>
        /// <example>SelectAllUserclassesCheckbox("on")</example>
        public virtual void SelectAllUserclassesCheckbox(string sUserAction)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(cbkAllUserclasses);
                AppHandle.WaitUntilElementClickable(cbkAllUserclasses);
                if (sUserAction.ToUpper() == "ON")
                    AppHandle.Select_CheckBox(cbkAllUserclasses);
                else
                    AppHandle.DeSelectCheckBox(cbkAllUserclasses);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select or Deselect 'Book' Checkbox for Specified User Class in TransactionCodeAuthorizationPage
        /// <param name = "sUserClass"></param> 
        /// <param name = "sUserAction"></param> 'on or off
        /// <returns></returns>
        /// <example>SelectBookCheckboxforUserClass("SCA","on")</example>
        public virtual void SelectBookCheckboxforUserClass(string sUserClass, string sUserAction)
        {
            try
            {
                string obj = "XPath;//div[contains(@id,'sub-forms-list')]//tr//td[text()='" + sUserClass + "']//parent::tr//input[contains(@name,'book')]";
                AppHandle.WaitUntilElementVisible(tblTransactionCodeAuthorizeUserClass);
                AppHandle.WaitUntilElementClickable(tblTransactionCodeAuthorizeUserClass);
                if (sUserAction.ToUpper() == "ON")
                    AppHandle.Select_CheckBox(obj);
                else
                    AppHandle.DeSelectCheckBox(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select or Deselect 'No Book' Checkbox for Specified User Class in TransactionCodeAuthorizationPage
        /// <param name = "sUserClass"></param> 
        /// <param name = "sUserAction"></param> 'on or off
        /// <returns></returns>
        /// <example>SelectNoBookCheckboxforUserClass("SCA","on")</example>
        public virtual void SelectNoBookCheckboxforUserClass(string sUserClass, string sUserAction)
        {
            try
            {
                string obj = "XPath;//div[contains(@id,'sub-forms-list')]//tr//td[text()='" + sUserClass + "']//parent::tr//input[contains(@name,'noBook')]";
                AppHandle.WaitUntilElementVisible(tblTransactionCodeAuthorizeUserClass);
                AppHandle.WaitUntilElementClickable(tblTransactionCodeAuthorizeUserClass);
                if (sUserAction.ToUpper() == "ON")
                    AppHandle.Select_CheckBox(obj);
                else
                    AppHandle.DeSelectCheckBox(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select or Deselect 'Reversal' Checkbox for Specified User Class in TransactionCodeAuthorizationPage
        /// <param name = "sUserClass"></param> 
        /// <param name = "sUserAction"></param> 'on or off
        /// <returns></returns>
        /// <example>SelectReversalCheckboxforUserClass("SCA","on")</example>
        public virtual void SelectReversalCheckboxforUserClass(string sUserClass, string sUserAction)
        {
            try
            {
                string obj = "XPath;//div[contains(@id,'sub-forms-list')]//tr//td[text()='" + sUserClass + "']//parent::tr//input[contains(@name,'reversal')]";
                AppHandle.WaitUntilElementVisible(tblTransactionCodeAuthorizeUserClass);
                AppHandle.WaitUntilElementClickable(tblTransactionCodeAuthorizeUserClass);
                if (sUserAction.ToUpper() == "ON")
                    AppHandle.Select_CheckBox(obj);
                else
                    AppHandle.DeSelectCheckBox(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        public virtual void SelectCheckbox(string userclassvalue)
        {
                string checkboxbook="XPath;//table[@class='ledgerScrollable dataTable']/tbody/descendant::td[contains(text(),'"+userclassvalue+"')]/following-sibling::td/input[contains(@name,'book')]";
                string checkboxnobook="XPath;//table[@class='ledgerScrollable dataTable']/tbody/descendant::td[contains(text(),'"+userclassvalue+"')]/following-sibling::td/input[contains(@name,'nbook')]";
                string checkboxreversal="XPath;//table[@class='ledgerScrollable dataTable']/tbody/descendant::td[contains(text(),'"+userclassvalue+"')]/following-sibling::td/input[contains(@name,'reversal')]";
                if(!appHandle.CheckCheckBoxChecked(checkboxbook))
                {
                    appHandle.ClickObjectViaJavaScript(checkboxbook);
                }
                if(!appHandle.CheckCheckBoxChecked(checkboxnobook))
                {
                    appHandle.ClickObjectViaJavaScript(checkboxnobook);
                }
                if(!appHandle.CheckCheckBoxChecked(checkboxreversal))
                {
                    appHandle.ClickObjectViaJavaScript(checkboxreversal);
                }

        }

        public virtual void ClickOnSubmitbutton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);

        }

        public virtual void CheckSuccessMessage()
        {
            
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(TransactionCodesPage.buttonSearch);
            if(appHandle.CheckSuccessMessage("The information has been updated."))
            {
                Report.Pass("The expected message exist in application","lop","True",appHandle);
            }
            else
            {
                Report.Fail("The expected message does not exist in application","lop1","True",appHandle);

            }
        
        }

         public virtual bool CheckTableDataExist(string valuetocheck)
        {
            string tblobj="XPath;//td[contains(text(),'"+valuetocheck+"')]";
            return appHandle.IsObjectExists(valuetocheck,tblobj);
        }


    }

}