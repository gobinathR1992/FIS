using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class UserModifyPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string BatchTellersSameDayRetryCheckbox = "Name;SCAU_SDRTY";
        public static string OnlineTellersLimitEMuCurrenciesCheckbox = "Name;SCAU_EMULIM";
        public static string OnlineTellersPMingAllowedCheckbox = "Name;SCAU_TPM";
        public static string PasswordMaintenanceRevokeManuallyCheckbox = "Name;USERSECUREDDATA_ISMANUALLYREVOKED";
        public static string ReturnItemLimitsBranchRestrictionCheckbox = "Name;SCAU_RETBRCD";
        public static string NotifyPasswordExpirationByEmailCheckbox  = "Name;USERSECUREDDATA_NOTIFYPWDEXPIRYBYEMAIL";
        public static string BatchTellersNumberOfRetriesField = "Name;SCAU_MARTY";
        public static string BatchTellersOverDraftRetriesField = "Name;SCAU_ODPRET";
        public static string OnlineTellersOverallCashMaxField = "Name;SCAU_OACMAX";
        public static string OnlineTellersOverallCashMinField = "Name;SCAU_OACMIN";
        public static string PasswordMaintenancePasswordField = "Name;USERSECUREDDATA_ENCRYPTEDPWDOLD";
        public static string PasswordMaintenanceConfirmPasswordField = "Name;passwordVerify";
        public static string RestrictedCustomersRestrictedCustomer1Field = "Name;restrictedCustomers[0]";
        public static string ReturnItemLimitsLedgerBalanceLimitField = "Name;SCAU_RETBALLIM";
        public static string ReturnItemLimitsUncollectedBalLimitField = "Name;SCAU_RETCOLLIM";
        public static string ReturnItemLimitsWaiveFeeLimitField = "Name;SCAU_RETFEELIM";
        public static string EmailAddressField = "Name;USERSECUREDDATA_EMAILADDRESS";
        public static string UserFullNameField = "Name;agentName";
        public static string UsersCustNumberField = "Name;SCAU_ACN";
        public static string AvailableUserClassAddExplanatoryField = "Xpath;//td[contains(text(),'To add a row to the Selected Userclass list, highl')]";
        public static string AvailableUserClassRemoveExplanatoryField = "Xpath;//td[contains(text(),'To remove a row from the Selected Userclass list, ')]";
        public static string BatchTellersOverDraftProtectionDropdown = "Name;SCAU_ODP";
        public static string BatchTellersReconcilingOffsetCreditDropdown = "Name;SCAU_ROCR";
        public static string BatchTellersReconcilingOffsetDebitDropdown = "Name;SCAU_RODR";
        public static string BatchTellersRejectHandlingDropdown ="Name;SCAU_BATREJ";
        public static string BatchTellersRepostTellerDropdown = "Name;SCAU_RTUID";
        public static string BatchTellersTranscationSortOptionDropdown = "Name;SCAU_TRNSRT";
        public static string OnlineTellersCashShortageGeneralLedgerDropdown = "Name;SCAU_CSSHRT";
        public static string OnlineTellersPostingEnvironmentDropdown = "Name;SCAU_CURRENV";
        public static string OnlineTellersTransactionSuspenseCreditDropdown = "Name;SCAU_TSCR";
        public static string OnlineTellersTransactionSuspenseDebitDropdown = "Name;SCAU_TSDR";
        public static string PasswordMaintenanceManualRevokeReasonDropdown = "Name;USERSECUREDDATA_MANUALREVOKEDREASON";
        public static string BranchCodeDropdown = "Name;SCAU_BRCD";
        public static string UserclassDropdown = "Name;userClass";
        public static string UserLanguageDropdown = "Name;SCAU_LANG";
        


       














    }
}