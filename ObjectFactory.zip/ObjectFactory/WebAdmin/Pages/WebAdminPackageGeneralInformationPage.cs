using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;



namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminPackageGeneralInformationPage
    {
        WebApplication AppHandle;

        private static string PackageInformationPackageNameField = "XPath;//input[@name='UTBLPACKAGE_PACKAGE'][@type='text']";
        private static string PackageInformationDescriptionField = "XPath;//input[@name='UTBLPACKAGE_FMDESC'][@type='text']";
        private static string PackageInforamtionPackageDetailField = "XPath;//textarea[@name='UTBLPACKAGE_FREETXT']";
        private static string PackageInformationPriorityPlacementField = "XPath;//input[@name='UTBLPACKAGE_PRIORITY'][@type='text']";
        private static string PackageInformationBankRecommendedCheckbox = "XPath;//input[@name='UTBLPACKAGE_BANKREC'][@type='checkbox']";
        private static string PackageInformationOfferStartDateField = "XPath;//input[@name='UTBLPACKAGE_OFFERSTART'][@type='text']";
        private static string PackageInformationOfferEndDateField = "XPath;//input[@name='UTBLPACKAGE_OFFEREND'][@type='text']";
        private static string PackageInformationCombinedStatementCheckbox = "XPath;//input[@name='UTBLPACKAGE_CMBSTMT'][@type='checkbox']";
        private static string PackageInformationEStatementcheckbox = "XPath;//input[@name='UTBLPACKAGE_ESTMT'][@type='checkbox']";
        private static string PackageInformationStatementCycleField = "XPath;//input[@name='UTBLPACKAGE_STMTCYC'][@type='text']";
       // private static string PackageInformationBankSiteURLField = "XPath;//input[@name='UTBLPACKAGE_BNKSTURL'][@type='text']";
       // private static string PackageInformationRuleSetIDDropdown = "XPath;//select[@name='UTBLPACKAGE_RULESETID']";
        private static string SubmitButton = "XPATH;//INPUT[@value='Submit']";
        private static string ErrorMessage="XPath;//div[@class='error']";




        public virtual void EnterPackageGeneralInformation(string[] PackageDetails)
        {

            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string PackageName = PackageDetails[0];
            string PackageDescription = PackageDetails[1];
            string Packagedetail = PackageDetails[2];
            string PriorityPlacement = PackageDetails[3];
            string OfferStartDate = PackageDetails[4];
            string OfferEndDate = PackageDetails[5];
            string StatementCycle = PackageDetails[6];


            AppHandle.Set_field_value(PackageInformationPackageNameField, PackageName);
            AppHandle.Set_field_value(PackageInformationDescriptionField, PackageDescription);
            AppHandle.Set_field_value(PackageInforamtionPackageDetailField, Packagedetail);
            AppHandle.Set_field_value(PackageInformationPriorityPlacementField, PriorityPlacement);
            AppHandle.Select_CheckBox(PackageInformationBankRecommendedCheckbox);
            AppHandle.Set_field_value(PackageInformationOfferStartDateField, OfferStartDate);
            AppHandle.Set_field_value(PackageInformationOfferEndDateField, OfferEndDate);
            AppHandle.Select_CheckBox(PackageInformationCombinedStatementCheckbox);
            AppHandle.Select_CheckBox(PackageInformationEStatementcheckbox);
            AppHandle.Set_field_value(PackageInformationStatementCycleField, StatementCycle);

        }


        public virtual void ClickSubmitButton()
        {
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            AppHandle.SelectButton(SubmitButton);
            Thread.Sleep(2000);
            Report.Info("Submit button is clicked.");
        }

        public virtual bool CheckIfErrorMessageAppears()
        {
            bool Result = false;
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            if (AppHandle.IsObjectExists(ErrorMessage))
            {
                Result=true;
            }
           else
           {
               Result=false;
           }
           
            return Result;
        }

        public virtual string ReenterDataOnErrorMessage()
        {
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string PackageName = "Test" + (string)AppHandle.CreateRamdomData(FieldType.ALPHANUMERICS,0,0,6);
            string PriorityPlacement = AppHandle.CreateRamdomData(FieldType.NUMERIC, 10, 999).ToString();
            AppHandle.Set_field_value(PackageInformationPackageNameField, PackageName);
            AppHandle.Set_field_value(PackageInformationDescriptionField, PackageName);
            AppHandle.Set_field_value(PackageInformationPriorityPlacementField, PriorityPlacement);
            return PackageName;
        }
       
         
       

    }
}