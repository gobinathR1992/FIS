using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class DepositRateDeterminationPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtFixedRateNominalRate = "Xpath;//input[@name='PRODDFTD_IRN']";
        public static string drpFixedRateRateSchedule = "Xpath;//select[@name='PRODDFTD_SCH']"; 
        public static string txtPromotionalRateRateField = "XPath;//input[@name='PRODDFTD_TRATE']";
        public static string txtPromotionalRateExpirationDate = "XPath;//input[@name='PRODDFTD_TREXD']";
        public static string tabbed_lnk_RateDetermination="Xpath;//a[text()='Rate Determination']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p";
        public static string txtNominalRate="XPath;//input[@name='PRODDFTD_IRN']";
        public static string dropdownPromotionalRateIndex="XPath;//select[@name='PRODDFTD_PROIND']";
        public static string txtPromotionalRateTerm="XPath;//input[@name='PRODCTL_TRTRM']";              
        public virtual void select_RateDetermination_subtab()
        {
            appHandle.Wait_for_object(tabbed_lnk_RateDetermination, 3);
            appHandle.SelectTab(tabbed_lnk_RateDetermination);
            appHandle.Wait_for_object(buttonSubmit, 5);
        }
         public virtual void updateNominalRate(string nominalRate)
        {
            appHandle.Set_field_value(txtFixedRateNominalRate, nominalRate);
        }
         public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
         public virtual bool VerifyMessageInInterestRateDeterminationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

        public virtual bool UpdateDataForRateDeterminationForTDSetup()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtNominalRate);
            appHandle.Set_field_value(txtNominalRate,"10.00");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtNominalRate);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }

        public virtual bool UpdateValuesOfPromotionalRateInRateDeterminationPage(string rateval,string indexval,string expdateval,string termval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPromotionalRateRateField);
            appHandle.Set_field_value(txtPromotionalRateRateField,rateval);
            appHandle.Set_field_value(txtPromotionalRateExpirationDate,expdateval);
            appHandle.Set_field_value(txtPromotionalRateTerm,termval);
            appHandle.SelectDropdownSpecifiedValue(dropdownPromotionalRateIndex,indexval);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }
       
        
    }
}
