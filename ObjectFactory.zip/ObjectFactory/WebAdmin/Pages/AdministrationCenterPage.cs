using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class AdministrationCenterPage
    {

      static  WebApplication appHandle= ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); 

        public static string LogOutButton = "Xpath;//button[@name='logout']";
        public static string TableConfigAccruedWithHoldingTaxIndexLink = "Xpath;//td[contains(text(),'Accrued Withholding Tax Index')]";
        public static string VendorManagementCheckFreeKeyManagementLink = "Xpath;//td[contains(text(),'CheckFree Key Management')]";
        public static string SecurityConfigContextFieldsLink = "Xpath;//td[contains(text(),'Context Fields')]";
        public static string SecurityConfigContextRelationshipsLink = "Xpath;//td[contains(text(),'Context Relationships')]";
        public static string SecurityConfigContextsLink = "Xpath;//td[contains(text(),'Contexts')]";
        public static string TableConfigCurrencyCodesLink = "Xpath;//td[contains(text(),'Currency Codes')]";
        public static string ProductFactoryCustomerOffersLink = "Xpath;//td[contains(text(),'Customer Offers')]";
        public static string VendorManagement_DecisionSolutionPwdLink = "Xpath;//td[contains(text(),'Decision Solutions Password')]";
        public static string TableConfigExemptionPlansLink = "Xpath;//td[contains(text(),'Exemption Plans')]";
        public static string GeneralLedgerAccountsLink = "Xpath;//td[contains(text(),'Accounts')]";
        public static string GeneralLedgerTab = "Xpath;//td[contains(text(),'General Ledger')]";
        public static string GeneralLedgerSetCodesLink = "Xpath;//td[text()='Set Codes']";
        public static string lnkGeneralTableManagement = "Xpath;//td[contains(text(),'General Table Management')]";
        public static string CheckProcessingInstitutionCheckAllocationLink = "Xpath;//td[contains(text(),'Institution Check Allocation')]";
        public static string TableConfigInstitutionVariablesLink = "Xpath;//td[contains(text(),'Institution Variables')]";
        public static string UtilitiesIntegrityErrorCheckLink = "Xpath;//td[contains(text(),'Integrity Error Check')]";
        public static string InterestIndexesLink = "Xpath;//td[contains(text(),'Interest Indexes')]";
        public static string UtilitiesInterestIndexTestUtilityLink = "Xpath;//td[contains(text(),'Interest Index Test Utility')]";
        public static string TableConfigInterestMatrixesLink = "Xpath;//td[contains(text(),'Interest Matrixes')]";
        public static string TableConfigLoanFeePlansLink = "Xpath;//td[contains(text(),'Loan Fee Plans')]";
        public static string NotificationsNoticeCategoryLink = "Xpath;//td[contains(text(),'Notice Category')]";
        public static string NotificationsNoticeServiceManagementLink = "Xpath;//td[contains(text(),'Notice Service Management')]";
        public static string ProductFactoryPackageOffersLink = "Xpath;//td[contains(text(),'Package Offers')]";
        public static string ProductFactoryPackageProductsLink = "Xpath;//td[contains(text(),'Package Products')]";
        public static string ProductFactoryPackageServicesLink = "Xpath;//td[contains(text(),'Package Services')]";
        public static string ProductFactoryPackagesLink = "Xpath;//td[contains(text(),'Packages')]";
        public static string ProductFactoryTab = "Xpath;//td[contains(text(),'Product Factory')]";
        public static string ProductFactoryProductOffersLink = "Xpath;//td[contains(text(),'Product Offers')]";
        public static string ProductFactoryProductServicesLink = "Xpath;//td[contains(text(),'Product Services')]";
        public static string ProductFactoryProductsLink = "Xpath;//td[text()='Products']";
        public static string ReportingProfileReports = "Xpath;//td[contains(text(),'Profile Reports')]";
        public static string RateSchedulesLink = "Xpath;//td[contains(text(),'Rate Schedules')]";
        public static string GeneralLedgerReclassificationSetCodesLink = "Xpath;//td[contains(text(),'Reclassification/Provision Set Codes')]";
        public static string TableConfigRelationshipCodesLink = "Xpath;//td[contains(text(),'Relationship Codes')]";
        public static string TableConfigRuleSetsLink = "Xpath;//td[contains(text(),'Rule Sets')]";
        public static string SecurityConfigurationTab = "Xpath;//td[contains(text(),'Security Configuration')]";
        public static string TableConfigServiceFeePlansLink = "Xpath;//td[contains(text(),'Service Fee Plans')]";
        public static string SecurityConfigSetPermissionsLink = "Xpath;//td[contains(text(),'Set Permissions')]";
        public static string CheckProcessingStartingCheckNumberLink = "Xpath;//td[contains(text(),'Starting Check Number')]";
        public static string SecurityConfigSuspectedActivitySearchLink = "Xpath;//td[contains(text(),'Suspected Activity Search')]";
        public static string TableConfigTableCompilationSearchLink = "Xpath;//td[contains(text(),'Table Compilation')]";
        public static string TableConfigTab = "Xpath;//td[contains(text(),'Table Configuration')]";
        public static string lnkLoanFeePlans = "Xpath;//td[contains(text(),'Loan Fee Plans')]";
        public static string ToolsTab = "Xpath;//td[contains(text(),'Tools')]";
        public static string ToolsPSLIDELink = "Xpath;//td[contains(text(),'PSL IDE')]";
        public static string TableConfigTransactionCodesLink = "Xpath;//td[contains(text(),'Transaction Codes')]";
        public static string SecurityConfigUserClassMaintenanceLink = "Xpath;//td[contains(text(),'User/Userclass Maintenance')]";
        public static string UtilitiesActivitySummaryLink = "Xpath;//td[contains(text(),'Activity Summary')]";
        public static string UtilitiesTab = "Xpath;//td[contains(text(),'Utilities')]";
        public static string VendorManagementTab= "Xpath;//td[contains(text(),'Vendor Management')]";
        public static string AdministrationCenterTable = "Xpath;//table[@id='header']";
        public static string NotificationsTab = "Xpath;//td[contains(text(),'Notifications')]";
        public static string CheckProcessingTab = "Xpath;//td[contains(text(),'Check Processing')]";
        public static string ReportingTab = "Xpath;//td[contains(text(),'Reporting')]";

        public void SelectLinkinTab(string TabName, string LinkName = null)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle.WaitUntilElementVisible(TabName);
                appHandle.WaitUntilElementClickable(TabName);
                appHandle.ClickObject(TabName);
                if (LinkName != null && LinkName != "")
                {
                    appHandle.WaitUntilElementClickable(LinkName);
                    appHandle.Select_link(LinkName);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }

        }

 public virtual void ClickLinkFromMenuItem(string MenuNameLinkNameDelimitedByPipe)
        {
            string[] arr = MenuNameLinkNameDelimitedByPipe.Split('|');
            string MenuName = arr[0].Trim();
            string LinkName = arr[1].Trim();

            string desc = appHandle.GetSpecifiedObjectAttribute("XPath;//*[contains(text(),'" + MenuName + "')]/ancestor::*/following-sibling::*[@class='subMenu'][1]", "style");
            string DynamicLinkObj = "XPath;//*[contains(text(),'" + MenuName + "')]/ancestor::*/following-sibling::*[@class='subMenu'][1]/descendant::*[contains(text(),'" + LinkName + "')][1]";
            string MenuLinkObj = "XPath;//*[@class='menuGroupHeading']/descendant::*[contains(text(),'" + MenuName + "')]";

            if (string.IsNullOrEmpty(desc))
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(DynamicLinkObj);
                appHandle.ClickObjectViaJavaScript(DynamicLinkObj);
                            }
            else
            {
                appHandle.ClickObjectViaJavaScript(MenuLinkObj);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(DynamicLinkObj);
                appHandle.ClickObjectViaJavaScript(DynamicLinkObj);
            }
        }


















        
    }
}