using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Threading;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class PaymentApplicationPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpApplicationRulesPaymentActionGrid = "XPath;//select[@name='PRODDFTL_PDAG']";
        public static string txtCalculationOptionsBillingOffsetDays = "Xpath;//input[@name='PRODDFTL_BLOFF']";
        public static string drpApplicationRulesPaymentApplicationString = "Xpath;//select[@name='PRODDFTL_PAS']";
        public static string drpApplicationRulesPaymentApplicationPath = "Xpath;//select[@name='PRODDFTL_PAP']";
        private static string buttonSubmit="XPath;//input[@value='Submit']";
        private static string startdate = "Xpath;//input[@name='startDate']";


        public virtual void AddDetailsInPaymentDueActionGrid(string columnvaluesseperatedbydelimsemicolon,string date,string paymentgriddefinitionvalueseparatedbysemicolon)
        {

            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(columnvaluesseperatedbydelimsemicolon);
            appHandle.Set_field_value(startdate,date);
            paymentgriddefinitionvalueseparatedbysemicolon = paymentgriddefinitionvalueseparatedbysemicolon + ";";
            string[] arr = paymentgriddefinitionvalueseparatedbysemicolon.Split(';');
                                   
            for (int i=0;i<arr.Length-1;i++)
            {
                string PartialPayment = arr[i].Split('|')[0].Trim();
                string fullpayment = arr[i].Split('|')[1].Trim();

                string runtimexpathforPartialPayment = "Xpath;//input[@name='paymentGridDefinitions["+i+"].partialPayments']";
                string runtimexpathforfullpayment = "Xpath;//input[@name='paymentGridDefinitions["+i+"].fullPayments']";
                
                appHandle.Set_field_value(runtimexpathforPartialPayment,PartialPayment);
                appHandle.Set_field_value(runtimexpathforfullpayment,fullpayment);               

            }
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }


    }

}