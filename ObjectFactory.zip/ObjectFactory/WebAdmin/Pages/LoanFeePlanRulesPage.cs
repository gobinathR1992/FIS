using System;
using GTS_OSAF.CoreLibs;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class LoanFeePlanRulesPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtHistoryCommentatAssessment = "name;histDesc";
        public static string drpFeeAssessmentMethod = "name;feeComputationAssessMeth";
        public static string cbkLinkedtoBasis = "Xpath;//input[@type='checkbox'][@name='linkedtoFee']";
        public static string cbkAssessFeeAtPayoff = "name;assessatPayoff";
        public static string drpTransactionBasedGroup = "name;feeTranGrp";

       

      
     }
}