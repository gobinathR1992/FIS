using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class DelinquencyNoticeOffsetDaysPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        
        public static string txtDaysPastLastScheduledDateCategory1="XPath;//input[@name='PRODCTL_DNC01']";
        public static string txtDaysPastLastScheduledDateCategory2="XPath;//input[@name='PRODCTL_DNC02']";
        public static string txtDaysPastLastScheduledDateCategory3="XPath;//input[@name='PRODCTL_DNC03']";
        public static string txtDaysPastLastScheduledDateCategory4="XPath;//input[@name='PRODCTL_DNC04']";
        public static string txtDaysPastLastScheduledDateCategory5="XPath;//input[@name='PRODCTL_DNC05']";

        public static string buttonSubmit="XPath;//input[@name='submit']";

        public virtual bool EnterDetailsForAllFields(string cat1val1,string cat1val2,string cat1val3,string cat1val4,string cat1val5)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDaysPastLastScheduledDateCategory1);
            appHandle.Set_field_value(txtDaysPastLastScheduledDateCategory1,cat1val1);
            appHandle.Set_field_value(txtDaysPastLastScheduledDateCategory2,cat1val2);
            appHandle.Set_field_value(txtDaysPastLastScheduledDateCategory3,cat1val3);
            appHandle.Set_field_value(txtDaysPastLastScheduledDateCategory4,cat1val4);
            appHandle.Set_field_value(txtDaysPastLastScheduledDateCategory5,cat1val5);
            Report.Info("The Details for Notice Offset Days entered","noti","True",appHandle);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));


        }
    
    }
}