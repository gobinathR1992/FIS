using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Collections.Generic;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class RelationshipCodePage
    {
        WebApplication appHandle;
        public static string txtRelationshipCode = "XPath;//input[@name='relationshipCode']";
        public static string txtRelationshipCodeDescription = "XPath;//input[@name='relationshipCodeDescription']";
        public static string txtLegalTitleDescription = "XPath;//input[@name='titleDescription']";
        public static string drpTaxRecipientCode = "XPath;//select[@name='taxRecipientCode']";
        public static string drpT5RecipientType = "XPath;//select[@name='t5RecipientType']";
        public static string drpFDICBeneficiaryTypeCode = "XPath;//select[@name='fdicBeneficiaryTypeCode']";
        public static string txtNR4RecipientType = "XPath;//input[@name='nr4RecipientType']";
        public static string drpFDIC370ORCCode = "XPath;//select[@name='fdic370ORCCode']";
        public static string lblRecordExistsMgs = "XPath;//div[@class='error']//p[contains(text(),'Record already exists in table RELCODE1')]";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To enter value in Edit Feild in RelationshipCodePage.
        /// <param name = "Feild Name"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetEditValue(sfieldname,sfieldvalue)</example>
        public virtual void SetEditValue(string sfieldname, string sfieldvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sfieldname);
                AppHandle.WaitUntilElementClickable(sfieldname);
                AppHandle.Set_field_value(sfieldname, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select dropdown value in RelationshipCodePage.
        /// <param name = "dropdown Name"></param> 
        /// <param name = "dropdown Value"></param> 
        /// <returns></returns>
        /// <example>SelectDropdownValue(sdrpname,sdrpvalue)</example>
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sdrpname);
                AppHandle.WaitUntilElementClickable(sdrpname);
                AppHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To enter Description value in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetDescriptionValueinRelationshipCodeTable(sRowNo,sfieldvalue)</example>
        public virtual void SetDescriptionValueinRelationshipCodeTable(int sRowNo, string sfieldvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//input[@name='relationshipCodesInfo[" + Row + "].description']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);
                if (sfieldvalue != "" && sfieldvalue != null)
                    AppHandle.Set_field_value(obj, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To enter Maximum CIF value in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetMaxCIFValueinRelationshipCodeTable(sRowNo,sfieldvalue)</example>
        public virtual void SetMaxCIFValueinRelationshipCodeTable(int sRowNo, string sfieldvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//input[@name='relationshipCodesInfo[" + Row + "].maximumNumberOfCIFsForRole']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);
                if (sfieldvalue != "" && sfieldvalue != null)
                    AppHandle.Set_field_value(obj, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To enter Suffix value in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetSuffixValueinRelationshipCodeTable(sRowNo,sfieldvalue)</example>
        public virtual void SetSuffixValueinRelationshipCodeTable(int sRowNo, string sfieldvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//input[@name='relationshipCodesInfo[" + Row + "].suffix']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);
                if (sfieldvalue != "" && sfieldvalue != null)
                    AppHandle.Set_field_value(obj, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To enter Minimum CIF value in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetMinCIFValueinRelationshipCodeTable(sRowNo,sfieldvalue)</example>
        public virtual void SetMinCIFValueinRelationshipCodeTable(int sRowNo, string sfieldvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//input[@name='relationshipCodesInfo[" + Row + "].minimumNumberOfCIFsForRole']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);
                if (sfieldvalue != "" && sfieldvalue != null)
                    AppHandle.Set_field_value(obj, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select or Deselect SS in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "On/Off"></param> 
        /// <returns></returns>
        /// <example>SetSSOnorOffinRelationshipCodeTable(sRowNo,sfieldvalue)</example>
        public virtual void SetSSOnorOffinRelationshipCodeTable(int sRowNo, string sfieldvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//input[@name='relationshipCodesInfo[" + Row + "].suffixSupressFlag']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);

                if (sfieldvalue.ToUpper() == "ON")
                    AppHandle.Select_CheckBox(obj);
                if (sfieldvalue.ToUpper() == "OFF")
                    AppHandle.DeSelectCheckBox(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select FDIC Relationship Code value in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "sdrpvalue"></param> 
        /// <returns></returns>
        /// <example>SelectFDICinRelationshipCodeTable(sRowNo,sdrpvalue)</example>
        public virtual void SelectFDICinRelationshipCodeTable(int sRowNo, string sdrpvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//select[@name='relationshipCodesInfo[" + Row + "].fdicRelationshipCode']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);
                if (sdrpvalue != "" && sdrpvalue != null)
                    AppHandle.SelectDropdownSpecifiedValue(obj, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select or Deselect Primary Owner in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "On/Off"></param> 
        /// <returns></returns>
        /// <example>SetPrimaryOwnerOnorOffinRelationshipCodeTable(sRowNo,sfieldvalue)</example>
        public virtual void SetPrimaryOwnerOnorOffinRelationshipCodeTable(int sRowNo, string sfieldvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//input[@name='relationshipCodesInfo[" + Row + "].primaryOwner']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);

                if (sfieldvalue.ToUpper() == "ON")
                    AppHandle.Select_CheckBox(obj);
                if (sfieldvalue.ToUpper() == "OFF")
                    AppHandle.DeSelectCheckBox(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select Customer Type value in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "sdrpvalue"></param> 
        /// <returns></returns>
        /// <example>SelectCustomerTypeinRelationshipCodeTable(sRowNo,sdrpvalue)</example>
        public virtual void SelectCustomerTypeinRelationshipCodeTable(int sRowNo, string sdrpvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//select[@name='relationshipCodesInfo[" + Row + "].customerType']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);
                if (sdrpvalue != "" && sdrpvalue != null)
                    AppHandle.SelectDropdownSpecifiedValue(obj, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select or Deselect Bureau Reporting Relationship in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "On/Off"></param> 
        /// <returns></returns>
        /// <example>SetBureauReportingRelationshipOnorOffinRelationshipCodeTable(sRowNo,sfieldvalue)</example>
        public virtual void SetBureauReportingRelationshipOnorOffinRelationshipCodeTable(int sRowNo, string sfieldvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//input[@name='relationshipCodesInfo[" + Row + "].bureauReportingRelationship']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);

                if (sfieldvalue.ToUpper() == "ON")
                    AppHandle.Select_CheckBox(obj);
                if (sfieldvalue.ToUpper() == "OFF")
                    AppHandle.DeSelectCheckBox(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select Customer Sub Type value in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "sdrpvalue"></param> 
        /// <returns></returns>
        /// <example>SelectCustomerSubTypeinRelationshipCodeTable(sRowNo,sdrpvalue)</example>
        public virtual void SelectCustomerSubTypeinRelationshipCodeTable(int sRowNo, string sdrpvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//select[@name='relationshipCodesInfo[" + Row + "].customerSubType']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);
                if (sdrpvalue != "" && sdrpvalue != null)
                    AppHandle.SelectDropdownSpecifiedValue(obj, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select or Deselect Direct Liability in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "On/Off"></param> 
        /// <returns></returns>
        /// <example>SetDirectLiabilityOnorOffinRelationshipCodeTable(sRowNo,sfieldvalue)</example>
        public virtual void SetDirectLiabilityOnorOffinRelationshipCodeTable(int sRowNo, string sfieldvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//input[@name='relationshipCodesInfo[" + Row + "].directLiability']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);

                if (sfieldvalue.ToUpper() == "ON")
                    AppHandle.Select_CheckBox(obj);
                if (sfieldvalue.ToUpper() == "OFF")
                    AppHandle.DeSelectCheckBox(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select Customer Product value in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "sdrpvalue"></param> 
        /// <returns></returns>
        /// <example>SelectCustomerProductinRelationshipCodeTable(sRowNo,sdrpvalue)</example>
        public virtual void SelectCustomerProductinRelationshipCodeTable(int sRowNo, string sdrpvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//select[@name='relationshipCodesInfo[" + Row + "].customerProductType']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);
                if (sdrpvalue != "" && sdrpvalue != null)
                    AppHandle.SelectDropdownSpecifiedValue(obj, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select or Deselect signatureCard in Relationship Code Table.
        /// <param name = "sRowNo"></param> 
        /// <param name = "On/Off"></param> 
        /// <returns></returns>
        /// <example>SetSignatureCardOnorOffinRelationshipCodeTable(sRowNo,sfieldvalue)</example>
        public virtual void SetSignatureCardOnorOffinRelationshipCodeTable(int sRowNo, string sfieldvalue)
        {
            try
            {
                int Row = sRowNo - 1;
                string obj = "XPath;//div[contains(@id,'relationship-code-list')][contains(@class,'dataTable')]//td//input[@name='relationshipCodesInfo[" + Row + "].signatureCard']";
                AppHandle.WaitUntilElementVisible(obj);
                AppHandle.WaitUntilElementClickable(obj);

                if (sfieldvalue.ToUpper() == "ON")
                    AppHandle.Select_CheckBox(obj);
                if (sfieldvalue.ToUpper() == "OFF")
                    AppHandle.DeSelectCheckBox(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To Enter Role Details in RelationshipCodeTable
        /// <param name="ColName"></param>
        /// string ColName = "Row No;Description;Maximum cif;minimum cif;Fdic Relationship code;customer type;customer sub-type;customer product;Suffix;SS;Primary Owner;Bureau Report Relation;Direct Liability;SignatureCard"; 'specify columns names to which the values has to be entered.
        /// <param name="RoleDetails"></param> 'List to define roles to relationship code.
        /// RoleDetails.Add("1;test1;2;;;PERSON - Personal;INDV - Individual;0 - Personal;suftes;on;off;on;on;on");'Enter values against the Column names as passed in ColName string
        /// RoleDetails.Add("2;test1;2;1;;PERSON - Personal;INDV - Individual;0 - Personal;;on;on;on;off;on");'if column value is not needed then pass blank value - ex (PERSON - Personal;INDV - Individual;0 - Personal) -> (PERSON - Personal;;0 - Personal)
        /// RoleDetails.Add("3;test1;2;1;CUS - Custodian;PERSON - Personal;INDV - Individual;0 - Personal;suftes;on;;off;on;on");
        /// <returns></returns>
        /// <example>EnterRoleDetailsinRelationshipCodeTable(ColNames,RoleDetails)</example>
        public virtual void EnterRoleDetailsinRelationshipCodeTable(string ColNames, List<string> RoleDetails)
        {
            try
            {
                string[] arrcolDetails = WebAdminPageFactory.WebAdminMasterPage.SplitString(ColNames, ";");

                for (int j = 0; j < RoleDetails.Count; j++)
                {
                    string[] arrRowDetails = WebAdminPageFactory.WebAdminMasterPage.SplitString(RoleDetails[j], ";");

                    for (int i = 0; i < arrcolDetails.Length; i++)
                    {
                        switch (arrcolDetails[i].ToUpper())
                        {
                            case "DESCRIPTION":
                                WebAdminPageFactory.RelationshipCodePage.SetDescriptionValueinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "MAXIMUM CIF":
                                WebAdminPageFactory.RelationshipCodePage.SetMaxCIFValueinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "SUFFIX":
                                WebAdminPageFactory.RelationshipCodePage.SetSuffixValueinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "MINIMUM CIF":
                                WebAdminPageFactory.RelationshipCodePage.SetMinCIFValueinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "SS":
                                WebAdminPageFactory.RelationshipCodePage.SetSSOnorOffinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "FDIC RELATIONSHIP CODE":
                                WebAdminPageFactory.RelationshipCodePage.SelectFDICinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "PRIMARY OWNER":
                                WebAdminPageFactory.RelationshipCodePage.SetPrimaryOwnerOnorOffinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "CUSTOMER TYPE":
                                WebAdminPageFactory.RelationshipCodePage.SelectCustomerTypeinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "BUREAU REPORT RELATION":
                                WebAdminPageFactory.RelationshipCodePage.SetBureauReportingRelationshipOnorOffinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "CUSTOMER SUB-TYPE":
                                WebAdminPageFactory.RelationshipCodePage.SelectCustomerSubTypeinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "DIRECT LIABILITY":
                                WebAdminPageFactory.RelationshipCodePage.SetDirectLiabilityOnorOffinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "CUSTOMER PRODUCT":
                                WebAdminPageFactory.RelationshipCodePage.SelectCustomerProductinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                            case "SIGNATURECARD":
                                WebAdminPageFactory.RelationshipCodePage.SetSignatureCardOnorOffinRelationshipCodeTable(Int32.Parse(arrRowDetails[0]), arrRowDetails[i]);
                                break;
                        }
                    }
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

    }

}