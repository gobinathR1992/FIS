using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Threading;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class QueryDefinitionPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtApplicationPriority="Xpath;//input[@name='FEEQRY_PRI']";
        public static string drpQuery="Xpath;//select[@id='FEEQRY_QRYNAME']";
        public static string txtFixedAmount="Xpath;//input[@name='FEEQRY_FEEAMT']";
        public static string txtMaximumDialyAmount="Xpath;//input[@name='FEEQRY_MAXDLY']";
        public static string drpFeeSchedule="Xpath;//select[@name='FEEQRY_FEESCH']";
        public static string txtFeePercent="Xpath;//input[@name='FEEQRY_FEEPRCT']";
        public static string drpFeeTable="Xpath;//select[@name='FEEQRY_FEETBL']";
        
        
    }

}