using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
using Profile7Automation.Util;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class ContextAndFieldPage
    {

        static  WebApplication appHandle= ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); 

        public static string dropdownChannel="XPath;//select[@name='channelId']";
        public static string dropdownUserClass="XPath;//select[@name='userClass']";
        public static string dropdownContext="XPath;//select[@name='contextId']";

        public static string buttonCascade="XPath;//input[@name='cascade0']";
        
        public static string buttonSubmit="XPath;//input[@name='submit']";
        
        
        
        
        
        public virtual void SelectValuesInContextFieldPage(string channelname,string userclass,string context)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownChannel);
            appHandle.SelectDropdownSpecifiedValue(dropdownChannel,channelname);
            appHandle.SelectDropdownSpecifiedValue(dropdownUserClass,userclass);
            appHandle.SelectDropdownSpecifiedValue(dropdownContext,context);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonCascade);

        }

        public virtual bool CheckPermissionValueInDropdown(string labelname, string permissionlevel)
        {
            bool res = false;
            string[] arr = null;
            int numberOfContext = appHandle.GetRowCountfromList("XPath;//*[text()='Permission']/ancestor::table[1]/tbody[1]");
            for (int a = 0; a < numberOfContext; a++)
            {
                string temp = appHandle.GetObjectText("XPath;//*[contains(@id,'context" + a + "')]");
                string[] perarr=permissionlevel.Split(';');
                for(int i=0;i<perarr.Length;i++)
                {
                        if (temp.Contains(labelname) && temp.Contains(perarr[i]))
                        {
                            res = true;
                        }
                        else
                        {
                            res=false;
                        }
                }

                if(res==true)
                {
                    break;
                }

            }
            return res;
        }

        public virtual void SelectPermissionDropdownValueBasedOnLabel(string label,string permissionval)
        {
            
            
            
            bool res = false;
            string[] arr = null;
            int numberOfContext = appHandle.GetRowCountfromList("XPath;//*[text()='Permission']/ancestor::table[1]/tbody[1]");
            for (int a = 0; a < numberOfContext; a++)
            {
                string temp = appHandle.GetObjectText("XPath;//*[contains(@id,'context" + a + "')]");
                
                if (temp.Contains(label) )
                {
                    string dynamicobj="XPath;//*[text()='Permission']/ancestor::table[1]/tbody[1]/tr["+(a+1)+"]/td[2]/select";
                    string buttonCascade="XPath;//*[text()='Permission']/ancestor::table[1]/tbody[1]/tr[1]/td[2]/input";
                    //appHandle.SelectDropdownSpecifiedValueByIndex(dynamicobj,1);
                    appHandle.SelectDropdownSpecifiedValue(dynamicobj,permissionval);
                    //appHandle.ClickObjectViaJavaScript(buttonCascade);
                    Report.Info("The expected value "+permissionval+"is selected","valpass","True",appHandle);
                    res=true;
                }
                else
                {
                    Report.Fail("The lable "+label+"is not present","labelfail","True",appHandle);
                }
                

                if(res==true)
                {
                    break;
                }

            }
            
        }


        public virtual void ClickOnCascadeButtonBasedOnLabel(string label)
        {
            bool res = false;
            string[] arr = null;
            int numberOfContext = appHandle.GetRowCountfromList("XPath;//*[text()='Permission']/ancestor::table[1]/tbody[1]");
            for (int a = 0; a < numberOfContext; a++)
            {
                string temp = appHandle.GetObjectText("XPath;//*[contains(@id,'context" +a + "')]");
                
                if (temp.Contains(label) )
                {
                    
                    string buttonCascade="XPath;//*[text()='Permission']/ancestor::table[1]/tbody[1]/tr["+(a+1)+"]/td[2]/input";
                    appHandle.ClickObjectViaJavaScript(buttonCascade);
                    break;
                }
                else
                {
                    Report.Fail("The lable "+label+"is not present","labelfail","True",appHandle);
                }
                

                
            }

        }

        public virtual bool CheckValuePresentInDropdwonBasedOnLabel(string labelname,string permissionval)
        {

            bool res = false;
            string[] arr = null;
            int numberOfContext = appHandle.GetRowCountfromList("XPath;//*[text()='Permission']/ancestor::table[1]/tbody[1]");
            for (int a = 0; a < numberOfContext; a++)
            {
                string temp = appHandle.GetObjectText("XPath;//*[contains(@id,'context" + a + "')]");
                
                if (temp.Contains(labelname) )
                {
                    string dynamicobj="XPath;//*[text()='Permission']/ancestor::table[1]/tbody[1]/tr["+(a+1)+"]/td[2]/select";
                    string text=appHandle.GetObjectText(dynamicobj);
                    if(text.Contains(permissionval))
                    {
                        res=true;
                    }
                    else
                    {
                        res=false;

                    }
                
                }
                else
                {
                    res=false;
                }
                

                if(res==true)
                {
                    break;
                }

            }

            return res;
        }

        public virtual void ClickOnSubmitButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
        }

         public virtual void Submit()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        } 

        public virtual void SelectValueFromDropdownInTable(string labelname,string permisssionval)
        {
            string dynamicobj="XPath;//*[contains(text(),'"+labelname+"')]/../td/select";
            appHandle.SelectDropdownSpecifiedValue(dynamicobj,permisssionval);
        }

        public virtual void SelectValueFromContextDropdown(string contextvalue)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownContext);
            appHandle.SelectDropdownSpecifiedValue(dropdownContext,contextvalue);
            Report.Info("The specified value "+contextvalue+" is selected","selpass","True",appHandle);
        }


        public virtual void SelectTabInContextFieldPage(string tabname)
        {
            string tab="XPath;//td[contains(text(),'"+tabname+"')]";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tab);
            appHandle.ClickObjectViaJavaScript(tab);

        }

        
        
    }
}