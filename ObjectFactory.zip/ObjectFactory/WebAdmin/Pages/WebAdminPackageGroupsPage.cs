using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminPackageGroupsPage
    {
        WebApplication AppHandle;
        private static string PackageGroupsList = "XPath;//table[contains(@id,'content:service:data')]/tbody[contains(@id,'content:service:data')]";
        private static string ScrollerTable = "XPath;//table[@class='scroller']/tbody";
        private static string AddButton = "XPath;//input[@value='Add']";
        public virtual bool CheckPackageGroupUpdated(string PackageGroupName)
        {
            bool Result = false;
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);


            if (AppHandle.CheckObjectExist(ScrollerTable))
            {
                string LinkListText = AppHandle.GetObjectText(ScrollerTable).Trim();

                string[] LinksArray = LinkListText.Split(' ');

                for (int i = 5; i < LinksArray.Length + 4; i++)
                {
                    string LinkToClick = ScrollerTable + "/tr[1]/td[" + i + "]/a[1]";


                    int PackageGroupTableRowCount = AppHandle.GetTableRowCount(PackageGroupsList);
                    for (int j = 1; j <= PackageGroupTableRowCount; j++)
                    {
                        string CellText = (string)AppHandle.GetTableCellValue((object)PackageGroupsList, j, 2);
                        if (CellText.ToUpper().Trim().Equals(PackageGroupName.ToUpper().Trim()))
                        {
                            Result = true;
                            break;
                        }
                    }
                    if(Result==false)
                    {
                    AppHandle.Select_link(LinkToClick);
                    }
                    else
                    {
                        break;
                    }
                }
            }
            return Result;
        }

        public virtual void ClickAddButton()
        {
            AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            AppHandle.SelectButton(AddButton);
            Thread.Sleep(2000);
            Report.Info("Add button is clicked.");
        }

    }
}