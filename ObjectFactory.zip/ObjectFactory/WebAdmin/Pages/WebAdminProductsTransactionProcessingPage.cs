using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminProductsTransactionProcessingPage
    {

        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string txt_Disbursement_Processing_Maximum_Number_of_Disbursements_Field = "XPath;//tr[td[label[contains(text(),'Maximum Number of Disbursements')]]]//input";
        private static string btn_Submit = "xpath;//input[@value='Submit']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        public static string ckbTransactionAcceptancePositivePayArsEligible = "Xpath;//input[@name='PRODDFTD_POSPAY']";
        public static string txtTransactionRestrictionsMinimumBalance = "Xpath;//input[@name='PRODDFTD_MINBAL']";
        public static string txtTransactionRestrictionsMaximimBalance = "Xpath;//input[@name='PRODDFTD_MAXBAL']";
        public static string drpTransactionRestrictionsProcessRestriction = "Xpath;//select[@name='PRODDFTD_FLG']";
        private static string checkboxFundsTransferPermitPaymentOrder = "XPath;//*[@name='PRODDFTD_EFTDEB']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p[1]";
        private static string txtReconcillationFrequency="XPath;//*[contains(text(),'Reconciliation Frequency:')]/ancestor::td/following-sibling::*/input[1]";
        private static string txtReconcillationOffsetDays="XPath;//*[contains(text(),'Reconciliation Offset Days:')]/ancestor::td/following-sibling::*/input[1]";
        private static string checkboxFundsTransferPermitCollectionOrder = "Xpath;//*[@name='PRODDFTD_EFTDEB']";
        private static string checkbokFundsTransferPermitDirectDebit ="Xpath;//*[@name='PRODDFTD_EFTDD']";
        private static string txtMaximumFundsTransferPerDay="Xpath;//*[@name='PRODDFTD_MAXFTD']";
        private static string txtMaximumNumberofDisbursements = "Xpath;//input[@name='PRODDFTL_MAXDRCT']";
        private static string drpdownAutomaticDisbursementPlan = "Xpath;//select[@name='PRODDFTL_ALDP']";
        private static string drpdownAutomaticDisbursementMethod = "Xpath;//select[@name='PRODDFTL_ALDM']";
        private static string drpdownAutomaticDisbursementCheckType = "Xpath;//select[@name='PRODDFTL_ALDCHK']";
        private static string chkboxDisbursementScheduleProcessing = "Xpath;//input[@name='PRODDFTL_DSCHPR']";
        
        public static string dropdownGeneralLedgerSetCode="XPath;//select[@name='PRODDFTL_GLSC']";
        public static string txtFixedExpenseAmount="XPath;//input[@name='PRODCTL_LEXF']";
        public static string txtOriginationFeePercentage="XPath;//input[@name='PRODDFTL_ORGFP']";
        public static string txtCommitmentFeePercentage="XPath;//input[@name='PRODDFTL_COMFP']";
        public static string dropdownLoanFeesNetDefferredFeePlan="XPath;//select[@name='PRODCTL_FPLN']";
        public static string buttonSubmit="XPath;//input[@name='submit']";        
        
        public virtual void navigate_to_products_transaction_processing_page(string sProductClassDropdown, string sProductGroupDropdown, string sProductNumber)
        {
            WebAdminPageFactory.WebAdminProductFactoryPage.SearchProduct(sProductClassDropdown, sProductGroupDropdown);
            WebAdminPageFactory.WebAdminProductFactoryPage.select_product_radio_button_from_product_list_table(sProductNumber);
            WebAdminPageFactory.WebAdminProductFactoryPage.select_edit_button();
            WebAdminPageFactory.WebAdminProductsCommonPage.select_transaction_processing_tab();
        }

        public virtual void set_maximum_number_of_disbursements_field_value(string sMaximumNumberofDisbursements)
        {
            appHandle.Wait_for_object(txt_Disbursement_Processing_Maximum_Number_of_Disbursements_Field, 3);
            appHandle.Set_field_value(txt_Disbursement_Processing_Maximum_Number_of_Disbursements_Field, sMaximumNumberofDisbursements);
        }
        public virtual void select_submit_button()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(btn_Submit))
            {
                appHandle.ClickObjectViaJavaScript(btn_Submit);
            }
        }

        public virtual bool CheckPackageSuccessMessage(string inputMessage)
        {
            bool Result = false;
            if (appHandle.GetObjectText(sSuccessMessage).Equals(inputMessage))
            {
                Result = true;
            }
            else
            {
                Result = false;
            }
            return Result;
        }
        public virtual bool ClickOnFundsTransferPermitPaymentOrderCheckbox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxFundsTransferPermitPaymentOrder))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxFundsTransferPermitPaymentOrder)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxFundsTransferPermitPaymentOrder);
                        if (appHandle.CheckCheckBoxChecked(checkboxFundsTransferPermitPaymentOrder))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxFundsTransferPermitPaymentOrder) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxFundsTransferPermitPaymentOrder);
                        if (appHandle.CheckCheckBoxChecked(checkboxFundsTransferPermitPaymentOrder) == false){ Result = true; }
                    }
                }
            }
            return Result;
        }
        public virtual void EnterReconcillationDetails(string RecncillationFreq="1MAE",string RecooncillationOffsetDays="1")
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtReconcillationFrequency))
            {
                appHandle.Set_field_value(txtReconcillationFrequency,RecncillationFreq);
                appHandle.Set_field_value(txtReconcillationOffsetDays,RecooncillationOffsetDays);
            }
        }
        public virtual bool VerifyMessageInWebAdminProductTransactionProcessingPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (appHandle.GetObjectText(MSGOBJ).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool ClickOnFundsTransferPermitCollectionOrderCheckbox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxFundsTransferPermitCollectionOrder))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxFundsTransferPermitCollectionOrder)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxFundsTransferPermitCollectionOrder);
                        if (appHandle.CheckCheckBoxChecked(checkboxFundsTransferPermitCollectionOrder))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxFundsTransferPermitCollectionOrder) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxFundsTransferPermitCollectionOrder);
                        if (appHandle.CheckCheckBoxChecked(checkboxFundsTransferPermitCollectionOrder) == false){ Result = true; }
                    }
                }
            }
            return Result;
        }
        public virtual bool ClickOnFundsTransferPermitDirectDebitCheckbox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkbokFundsTransferPermitDirectDebit))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkbokFundsTransferPermitDirectDebit)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkbokFundsTransferPermitDirectDebit);
                        if (appHandle.CheckCheckBoxChecked(checkbokFundsTransferPermitDirectDebit))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkbokFundsTransferPermitDirectDebit) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkbokFundsTransferPermitDirectDebit);
                        if (appHandle.CheckCheckBoxChecked(checkbokFundsTransferPermitDirectDebit) == false){ Result = true; }
                    }
                }
            }
            return Result;
        }
        public virtual void UpdateMaximumFundsTrnsferPerDay(string NoofTransfer)
        {
            appHandle.WaitUntilElementExists(txtMaximumFundsTransferPerDay);
            appHandle.Set_field_value(txtMaximumFundsTransferPerDay,NoofTransfer);
        }

        public virtual void UpdateDisbursementProcessing(string MaximumNumberofDisbursements, string AutomaticDisbursementPlan, string AutomaticDisbursementMethod, string AutomaticDisbursementCheckType, bool DisbursementScheduleProcessing)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtMaximumNumberofDisbursements))
            {
                if (!string.IsNullOrEmpty(MaximumNumberofDisbursements))
                {
                    appHandle.Set_field_value(txtMaximumNumberofDisbursements, MaximumNumberofDisbursements);
                }
                if (!string.IsNullOrEmpty(AutomaticDisbursementPlan))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpdownAutomaticDisbursementPlan, AutomaticDisbursementPlan);
                }
                if (!string.IsNullOrEmpty(AutomaticDisbursementMethod))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpdownAutomaticDisbursementMethod, AutomaticDisbursementMethod);
                }
                if (!string.IsNullOrEmpty(AutomaticDisbursementCheckType))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpdownAutomaticDisbursementCheckType, AutomaticDisbursementCheckType);
                }
                if (DisbursementScheduleProcessing)
                {
                    appHandle.ClickObjectViaJavaScript(chkboxDisbursementScheduleProcessing);
                }

            }
        }
        public virtual void UpdateTransRestrictMinimumBalance(string Balance="")
        {
            appHandle.WaitUntilElementExists(txtTransactionRestrictionsMinimumBalance);
            appHandle.Set_field_value(txtTransactionRestrictionsMinimumBalance,Balance);

        }



        public virtual bool UpdateDataInTransactionProcessingTab(string prodnum)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownGeneralLedgerSetCode);
            appHandle.SelectDropdownSpecifiedValue(dropdownGeneralLedgerSetCode,prodnum+" - "+prodnum);
            appHandle.SelectDropdownSpecifiedValue(dropdownLoanFeesNetDefferredFeePlan,"");
            appHandle.Set_field_value(txtFixedExpenseAmount,"");
            appHandle.Set_field_value(txtOriginationFeePercentage,"");
            appHandle.Set_field_value(txtCommitmentFeePercentage,"");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }
    }
}