using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class LoanMaturityProcessingPage
    { 
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtPaymentTerm = "XPath;//input[@name ='PRODDFTL_PTRM']";
        public static string dropdownMaturityOption = "XPath;//select[@name ='PRODDFTL_RENCD']"; 
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string drpdownPrincipalMaturityOption = "Xpath;//select[@name='PRODDFTD_RENCD']";
        private static string drpdownInterestMaturityOption = "Xpath;//select[@name='PRODDFTD_IMO']";
        private static string txtMaturityInformationTerm = "Xpath;//input[@name='PRODDFTD_TRM']";
        private static string txtpaymentterm = "Xpath;//input[@name='PRODDFTL_PTRM']";
        private static string drpbusinessdate = "Xpath;//select[@name='PRODDFTL_BUSOPT']";

        public virtual bool VerifyMessageLoanMaturityProcessingOptionPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        

        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }

         public virtual bool WaitUntilLoanMaturityProcessingPageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPaymentTerm))
            {
                result = true;
            }

            return result;

        }
         public virtual void EnterMaturityProcessingPageOption(string Maturityoption,string paymenterm="",string businessdate="")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPaymentTerm))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMaturityOption, Maturityoption);
                
            }
            if(!string.IsNullOrEmpty(paymenterm))
            {
                appHandle.Set_field_value(txtpaymentterm,paymenterm);
            }
            if (!string.IsNullOrEmpty(businessdate))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpbusinessdate, businessdate);                
            }
        }

        public virtual void EnterMaturityRenewalProcessingPageOption(string MaturityInformationTerm, string PrincipalMaturityoption, string InterestMaturityoption )
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpdownPrincipalMaturityOption))
            {
                if(!string.IsNullOrEmpty(MaturityInformationTerm))
                {
                    appHandle.Set_field_value(txtMaturityInformationTerm, MaturityInformationTerm);
                }
                if(!string.IsNullOrEmpty(PrincipalMaturityoption))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpdownPrincipalMaturityOption, PrincipalMaturityoption);
                }
                if(!string.IsNullOrEmpty(InterestMaturityoption))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpdownInterestMaturityOption, InterestMaturityoption);
                }
            }

        }
        public virtual void UpdatePaymentTerm(string PaymentTerm)
        {
            appHandle.WaitUntilElementExists(txtPaymentTerm);
            appHandle.Set_field_value(txtPaymentTerm,PaymentTerm);
        }

        public virtual bool EnterDetailsForMatOptionAndPayTerm(string term,string matoption)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownMaturityOption);
            appHandle.SelectDropdownSpecifiedValue(dropdownMaturityOption,matoption);
            appHandle.Set_field_value(txtPaymentTerm,term);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }

        public virtual bool EnterValueForPaymentTerm(string termval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPaymentTerm);
            appHandle.Set_field_value(txtPaymentTerm,termval);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
            

        }

    }
}