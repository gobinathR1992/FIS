using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class NoticeServiceManagementPage
    {
        WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtNumberOfMonitors = "XPath;//input[@name='numberOfMonitors']";
        public static string btnStart="Xpath;//input[@name='start']";
        public static string btnStop="Xpath;//input[@name='stop']";
        public static string btnUpdate="Xpath;//input[@name='update']";

    }

}
