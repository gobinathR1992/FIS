using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class CopyServiceFeePlanPage
    {
        WebApplication appHandle;
        public static string btnSubmitCopyServiceFeePlan = "XPath;//input[@name='submit'][@value ='Submit']";
        public static string drpEffectiveDate = "XPath;//select[@name='FEEPLN_FEEDT']";
        public static string txtCopyTo = "XPath;//input[@name='FEEPLN_PLAN_NEW']";
        public static string txtEffectiveDate = "XPath;//input[@name='FEEPLN_FEEDT_NEW']";
        public static string btnCancelCopyServiceFeePlan = "XPath;//input[@name='cancel'][@value ='Cancel']";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To Click on Submit button in CopyServiceFeePlanPage.
        /// <param></param> 
        /// <returns></returns>
        /// <example>ClickOnSubmitCopyServiceFeePlanButton()</example>
        public void ClickOnSubmitCopyServiceFeePlanButton()
        {
            try
            {
                AppHandle.WaitUntilElementVisible(btnSubmitCopyServiceFeePlan);
                AppHandle.WaitUntilElementClickable(btnSubmitCopyServiceFeePlan);
                AppHandle.SelectButton(btnSubmitCopyServiceFeePlan);
                AppHandle.WaitUntilElementClickable(ServiceFeePlanListPage.btnAddServiceFeePlan);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }


        /// <summary>
        /// To enter value in Edit Feild in CopyServiceFeePlanPage.
        /// <param name = "Feild Name"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetEditValue(sfieldname,sfieldvalue)</example>
        public virtual void SetEditValue(string sfieldname, string sfieldvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sfieldname);
                AppHandle.WaitUntilElementClickable(sfieldname);
                AppHandle.Set_field_value(sfieldname, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select dropdown value in CopyServiceFeePlanPage.
        /// <param name = "dropdown Name"></param> 
        /// <param name = "dropdown Value"></param> 
        /// <returns></returns>
        /// <example>SelectDropdownValue(sdrpname,sdrpvalue)</example>
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sdrpname);
                AppHandle.WaitUntilElementClickable(sdrpname);
                AppHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

    }
}