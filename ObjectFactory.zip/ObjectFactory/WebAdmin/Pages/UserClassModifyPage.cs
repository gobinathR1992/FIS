using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class UserClassModifyPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
       
       public static string IdentificationRestrictHostAccessDuringDayEndCheckbox = "Name;SCAU0_RSTRCT";
       public static string IdentificationSecureUserClassCheckbox = "Name;SCAU0_SECUCLS";
       public static string IdentificationSelfEntitlementCheckbox = "Name;SCAU0_ENTITLEMENTFLAG";
       public static string TranscationProcessingAllowSubAccountUpdatesCheckbox = "Name;SCAU0_PLSAUPD";
       public static string TranscationProcessingLimitGLPostingCostCenterCheckbox = "Name;SCAU0_RBRCC";
       public static string TranscationProcessingOverrideAuthorizationCheckbox  = "Name;SCAU0_OVR";
       public static string BackDatedNumberOfDaysUntilOverrideField = "Name;SCAU0_MAXWO";
       public static string BackDatedMaximumNumberOfDaysField = "Name;SCAU0_MAXEFD";
       public static string FutureDatedNumberOfDaysUntilOverrideField = "Name;SCAU0_OVRFT";
       public static string FutureDatedMaximumNumberOfDaysField = "Name;SCAU0_MAXFT";
       public static string IdentificationDescriptionField = "Name;SCAU0_DESC";
       public static string PasswordDetailsDaysUntilInactiveField = "Name;SCAU0_MAXIN";
       public static string PasswordDetailsDaysUntilRevokeField = "Name;SCAU0_MAXREV";
       public static string PasswordDetailsForcedChangeDaysField = "Name;SCAU0_PWDCHG";
       public static string PasswordDetailsMaxNumberofRetriesField = "Name;SCAU0_PWDTRY";
       public static string PasswordDetailsMinNumberUppercaseAlphaCharactersField = "Name;SCAU0_PWDUPCHAR";
       public static string PasswordDetailsMinPasswordLengthField = "Name;SCAU0_PWDLEN";
       public static string PasswordDetailsPasswordHistoryDaysField = "Name;SCAU0_PWDARCHIVEDAYS";
       public static string PasswordDetailsPasswordHistoryNumbersField = "Name;SCAU0_NUMBEROFPWDSTOCHECK";
       public static string TranscationProcessingOverallCashMaxField = "Name;SCAU0_OACMAX";
       public static string TranscationProcessingOverallCashMinField = "Name;SCAU0_OACMIN";
       public static string TranscationProcessingRestrictReturnItemTimeField = "Name;SCAU0_RETTIME";
       public static string IdentificationMenuLinkageDropdown = "Name;SCAU0_MENU";
       public static string UserClassModifyTable = "Xpath;//table[@class='contentTable']";
       













    }
}
