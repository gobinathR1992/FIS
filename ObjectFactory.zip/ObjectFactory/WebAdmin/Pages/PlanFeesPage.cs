using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Threading;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class PlanFeesPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string rdbPlanFees="Xpath;//input[@name='fees']";
        public static string btnadd="Xpath;//input[@name='add']";
        public static string btnQueryDefinitions="Xpath;//input[@name='queryDefs']";
        public static string tblPlanFeesHeader = "Xpath;//div[@class='dataTables_scrollHeadInner']//table[@class='ledgerScrollable dataTable']";
        public static string tblPlanFees = "Xpath;//table[@class='contentTable']/tbody";
        public static string tblPlanFeesAction = "Xpath;//table[@id='fees-list']/tbody";
        public static string drpCategory="Xpath;//select[@name='FEESRV_FEECAT']";
        public static string drpEvent="Xpath;//select[@name='FEESRV_FEETYP']";
        public static string drpChargeOption="Xpath;//select[@name='FEESRV_CHGOPT']";
        public static string txtFixedAmount="Xpath;//input[@name='FEESRV_FEEAMT']";
        public static string txtMaximumDialyAmount="Xpath;//input[@name='FEESRV_MAXDLY']";
        public static string drpFeeSchedule="Xpath;//select[@name='FEESRV_FEESCH']";
        public static string drpFeeTable="Xpath;//select[@name='FEESRV_FEETBL']";
        //public static string txtFixedAmount="XPath;//input[@name='FEESRV_FEEAMT']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public static string textSuccessMsg="XPath;//p[contains(text(),'The fees for the service fee plan have been created.')]";
        public static string planFeesTable="Xpath;.//*[contains(@class,'ledgerScrollable dataTable')]/tbody";
        public static string buttonDelete="XPath;//input[@name='delete']";
        private static string MSGBOX = "Xpath;//*[@class='info']/descendant::p[1]";        
        //Method for Click on the Query Definitions button.
        public virtual void ClickQueryDefinitionsButton()
        {
            try
            {
                appHandle.WaitUntilElementClickable(btnQueryDefinitions);
                appHandle.ClickObject(btnQueryDefinitions);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged as : " + e);
            }
        }

        public virtual void ClickOnAddButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnadd);
            appHandle.ClickObjectViaJavaScript(btnadd);
        }

        public virtual void SelectValuesinPlanFeePage(string inputvalues)
        {
            string[] inputarr=inputvalues.Split(';');
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpCategory);           
            appHandle.SelectDropdownSpecifiedValue(drpCategory,inputarr[0]);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpEvent);
            appHandle.SelectDropdownSpecifiedValue(drpEvent,inputarr[1]);
            appHandle.SelectDropdownSpecifiedValue(drpChargeOption,inputarr[2]);
            appHandle.Set_field_value(txtFixedAmount,inputarr[3]);
            Report.Pass("Service Fee plan details added", "lookuppass", "True", appHandle);
        }

        public virtual void ClickOnSubmitButton()
        {
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(btnQueryDefinitions);

        }


        public virtual bool CheckSuccessMsg(string msg)
        {
            string actmsg=appHandle.GetObjectText(textSuccessMsg);
            if(actmsg.Equals(msg))
            {
                return true;
            }
            return false;
        }
        public virtual bool VerifyMessageInPlanFeesPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void DeletePlanFees(string category)
        {
            appHandle.SelectRadioButtonInTable(planFeesTable,category);
            Report.Pass("The fees for the service fee plan is selected successfully.", "FeePlansFees", "True", appHandle);
            appHandle.ClickObject(buttonDelete);
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
        }

    }

}