using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs; 
using Profile7Automation.Libraries.Util;

 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class LoanPaymentCalculationPage
    { 
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtAmortizationTerm = "XPath;//input[@name='PRODDFTL_TRM']";
        public static string drpPaymentCalculationMethod = "XPath;//select[@name='PRODDFTL_PCM']";
        public static string drpInterestDeterminationPoint = "XPath;//select[@name='PRODDFTL_IDP']";
        private static string ckbConsiderInterestAccrualMethodforPaymentCalculation="Xpath;//*[@name='PRODDFTL_PIACM']";        
        private static string ckbFullPeriodtoFirstPayment="Xpath;//*[@name='PRODCTL_FPF']";
        public static string drpPaymentRecalculationMethod = "XPath;//select[@name='PRODDFTL_PMRECLMT']";
        public static string drpAdjustmentsAfterInterestRateChange = "XPath;//select[@name='PRODDFTL_APIRAOPT']";
        public static string txtPaymentFrequency = "XPath;//input[@name='PRODDFTL_DIST1FRE']";
        private static string btn_Submit = "xpath;//input[@value='Submit']";
        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p[1]";



        public virtual bool ClickOnFullPeriodtoFirstPaymentCheckbox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ckbFullPeriodtoFirstPayment))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(ckbFullPeriodtoFirstPayment)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbFullPeriodtoFirstPayment);
                        if (appHandle.CheckCheckBoxChecked(ckbFullPeriodtoFirstPayment))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(ckbFullPeriodtoFirstPayment) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbFullPeriodtoFirstPayment);
                        if (appHandle.CheckCheckBoxChecked(ckbFullPeriodtoFirstPayment) == false){ Result = true; }
                    }
                }
            }
            return Result;
        }
        public virtual void ClickOnSubmit()
        {
            appHandle.WaitUntilElementExists(btn_Submit);
            appHandle.ClickObjectViaJavaScript(btn_Submit);

        }
         public virtual bool VerifyMessageInWebAdminLoanPaymentCalculationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (appHandle.GetObjectText(MSGOBJ).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void EnterLoanCalculationOptions(bool ciampcCheckBoXOnorOff, bool fpfpCheckBox, string amortizationTerm, string paymentCalMet, string intDeterminationPoint, string PaymentFrequency,string PaymentRecalculationMethod, string AdjustmentsAfterInterestRateChange)
        {
                if (fpfpCheckBox)
                {
                    if (appHandle.CheckCheckBoxChecked(ckbFullPeriodtoFirstPayment)) {  }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbFullPeriodtoFirstPayment);
                        if (appHandle.CheckCheckBoxChecked(ckbFullPeriodtoFirstPayment))
                        {  }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(ckbFullPeriodtoFirstPayment) == false) {  }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbFullPeriodtoFirstPayment);
                        if (appHandle.CheckCheckBoxChecked(ckbFullPeriodtoFirstPayment) == false){ }
                    }
                }
                
                if (ciampcCheckBoXOnorOff)
                {
                    if (appHandle.CheckCheckBoxChecked(ckbConsiderInterestAccrualMethodforPaymentCalculation)) {  }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbConsiderInterestAccrualMethodforPaymentCalculation);
                        if (appHandle.CheckCheckBoxChecked(ckbConsiderInterestAccrualMethodforPaymentCalculation))
                        {  }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(ckbConsiderInterestAccrualMethodforPaymentCalculation) == false) {  }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(ckbConsiderInterestAccrualMethodforPaymentCalculation);
                        if (appHandle.CheckCheckBoxChecked(ckbConsiderInterestAccrualMethodforPaymentCalculation) == false){ }
                    }
                }

                int indexlength = appHandle.GetLengthOfText(txtAmortizationTerm);
                for(int i=0;i<=indexlength-1;i++)
                {
                    appHandle.SendKeyStroke(txtAmortizationTerm, InputKey.Backspace);
                }
                appHandle.Set_field_value(txtAmortizationTerm,amortizationTerm);

                if(!string.IsNullOrEmpty(paymentCalMet))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpPaymentCalculationMethod, paymentCalMet);
                }

                if(!string.IsNullOrEmpty(intDeterminationPoint))
                {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpInterestDeterminationPoint, intDeterminationPoint);
                }

                int indexlengthh = appHandle.GetLengthOfText(txtPaymentFrequency);
                for(int i=0;i<=indexlengthh-1;i++)
                {
                    appHandle.SendKeyStroke(txtPaymentFrequency, InputKey.Backspace);
                }
                appHandle.Set_field_value(txtPaymentFrequency,PaymentFrequency);

                if(PaymentRecalculationMethod=="")
                {
                    appHandle.SelectDropdownSpecifiedValue(drpPaymentRecalculationMethod,PaymentRecalculationMethod);
                }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpPaymentRecalculationMethod, PaymentRecalculationMethod);
                }     

                if(AdjustmentsAfterInterestRateChange=="")
                {
                    appHandle.SelectDropdownSpecifiedValue(drpAdjustmentsAfterInterestRateChange,AdjustmentsAfterInterestRateChange);
                }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpAdjustmentsAfterInterestRateChange, AdjustmentsAfterInterestRateChange);
                }  
        }
   



    }
}