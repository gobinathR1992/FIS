using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class DepositPostingOptionsPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtPostingOptionsPostingFrequency="Xpath;//input[@name='PRODDFTD_IPF']";
        public static string drpPositingOptionsDisbursementOption = "Xpath;//select[@name='PRODDFTD_IOPT']";
        public static string dropdownpPositingOptionsDisbursementOption = "Xpath;//select[@name='PRODDFTD_IOPT']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        public static string tabbed_lnk_PostingOptions="Xpath;//a[text()='Posting Options']";
        private static string PositingOptionsMinimumBalancetoCreditInterestField = "Xpath;//input[@name='PRODDFTD_MININT']";
        public static string dropdownpNegativeInterestAccrualOption = "Xpath;//select[@name='PRODDFTD_NEGACRPO']";
        private static string chkBoxAllowNegativeInterest = "Xpath;//input[@name='PRODDFTD_ISNEGRATEONPOSBALALLOWED']";
        private static string drpDownNegativeInterestPostingOption  = "Xpath;//select[@name='PRODDFTD_NEGIPO']";
        private static string txtNegativeInterestPostingFrequency = "Xpath;//input[@name='PRODDFTD_NEGIPF']";
        private static string chkBoxAccruePositiveInterestOnNegativeBalance = "Xpath;//input[@name='PRODDFTD_ISNEGRATEONNEGBALALLOWED']";
        private static string chkBoxPostZeroNetInterest = "Xpath;//input[@name='PRODDFTD_ISZERONETINTPOSTALLOWED']";
        private static string checkboxSubjectToWithholding = "Xpath;//input[@name='PRODDFTD_BWF']";
        private static string drpdownPrincipalMaturityOption = "Xpath;//select[@name='PRODDFTD_RENCD']";
        private static string drpdownIRSReportingOption = "Xpath;//select[@name='PRODDFTD_IRSEXM']";
        private static string chkboxStudentLoanProduct = "Xpath;//input[@name='PRODCTL_DEFAL']";
        private static string drpdownStudentLoanStatus = "Xpath;//select[@name='PRODDFTL_IDPF']";
        private static string txtOriginationFeePercentage = "Xpath;//input[@name='PRODDFTL_ORGFP']";             
        public static string dropdownDisbursementOption="XPath;//select[@name='PRODDFTD_IOPT']";
        public static string txtPostingFrequency="XPath;//input[@name='PRODDFTD_IPF']";
        public static string buttonSubmitnew="XPath;//input[@name='submit']";   
        private static string drpdownBusinessDateOption = "Xpath;//select[@name='PRODDFTD_BUSOPT']";
        private static string drpdownBusinessDateCalc = "Xpath;//select[@name='PRODDFTD_NBDC']";

        public virtual void select_PostingOptions_subtab()
        {
            appHandle.Wait_for_object(tabbed_lnk_PostingOptions, 3);
            appHandle.SelectTab(tabbed_lnk_PostingOptions);
            appHandle.Wait_for_object(buttonSubmit, 5);
        }
        public virtual void updatePostingOptionsDisbursementOption(string dOption)
        {
            if (appHandle.WaitForObjectEnabled(drpPositingOptionsDisbursementOption))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(drpPositingOptionsDisbursementOption, dOption);
            }
        }
        public virtual void updatePostingOptionsPostingFrequency(string pFrequency)
        {
            
            appHandle.Set_field_value(txtPostingOptionsPostingFrequency, pFrequency);
        }

          public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
         public virtual bool VerifyMessageInInterestPostingOptionsPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        
        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }
         public virtual bool CheckPackageSuccessMessage(string inputMessage)
        {
            bool Result=false;
            if(appHandle.GetObjectText(sSuccessMessage).Equals(inputMessage))
            {
                Result=true;
            }
            else
            {
                Result=false;
            }
            return Result;
        }
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                appHandle.WaitUntilElementVisible(sdrpname);
                appHandle.WaitUntilElementClickable(sdrpname);
                appHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
         public virtual bool VerifyMessageDepositInterestPostingOptionPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        
        public virtual bool WaitUntilInterestPostingOptionPageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownpPositingOptionsDisbursementOption))
            {
                result = true;
            }

            return result;

        }
        public virtual void EnterInterestPostingOptions(string DisbursmentOption , string PostingFrequency , string MinimumBalancetoCreditInterestField = "",bool SubjToWithONorOFF = false,bool AccrWithTaxProcessingONorOFF=false)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownpPositingOptionsDisbursementOption))
            {
                
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownpPositingOptionsDisbursementOption, DisbursmentOption);
                if(!string.IsNullOrEmpty(PostingFrequency))
                {
                appHandle.Set_field_value(txtPostingOptionsPostingFrequency,PostingFrequency);
                }
                if((!string.IsNullOrEmpty(MinimumBalancetoCreditInterestField)) && (MinimumBalancetoCreditInterestField.Contains("clear")))
                {
                    appHandle.ClearEditValue(MinimumBalancetoCreditInterestField);
                    //appHandle.Set_field_value(PositingOptionsMinimumBalancetoCreditInterestField, MinimumBalancetoCreditInterestField);
                }
                if (!SubjToWithONorOFF)
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Subject to Withholding") + "|" + Data.Get("OFF"));
                }
                else
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Subject to Withholding") + "|" + Data.Get("GLOBAL_ON"));
                }
                if (!AccrWithTaxProcessingONorOFF)
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Accrued Withholding Tax Processing") + "|" + Data.Get("OFF"));
                }
                else
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Accrued Withholding Tax Processing") + "|" + Data.Get("GLOBAL_ON"));
                }
            }
        }

         public virtual bool WaitUntilNegativeInterestPageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownpNegativeInterestAccrualOption))
            {
                result = true;
            }

            return result;

        }

        public virtual void EnterNegativeInterestDetails(bool AllowNegativeInterest, string NegativeInterestAccrualOption, string NegativeInterestPostingOption, string NegativeInterestPostingFrequency, bool AccruePositiveInterestOnNegativeBalance, bool PostZeroNetInterest)
        {
            if(AllowNegativeInterest)
            {
                appHandle.ClickObjectViaJavaScript(chkBoxAllowNegativeInterest);
            }
            if(!string.IsNullOrEmpty(NegativeInterestAccrualOption))
            {
                appHandle.SelectDropdownSpecifiedValue(dropdownpNegativeInterestAccrualOption, NegativeInterestAccrualOption);
            }
            if(!string.IsNullOrEmpty(NegativeInterestPostingOption))
            {
                appHandle.SelectDropdownSpecifiedValue(drpDownNegativeInterestPostingOption, NegativeInterestPostingOption);
            }
            if(!string.IsNullOrEmpty(NegativeInterestPostingFrequency))
            {
                appHandle.Set_field_value(txtNegativeInterestPostingFrequency, NegativeInterestPostingFrequency);
            }
            if(AccruePositiveInterestOnNegativeBalance)
            {
                appHandle.ClickObjectViaJavaScript(chkBoxAccruePositiveInterestOnNegativeBalance);
            }
            
            if(PostZeroNetInterest)
            {
                appHandle.ClickObjectViaJavaScript(chkBoxPostZeroNetInterest);
            }
        }    

         public virtual bool WaitUntilTransactionCodePageloads()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownpNegativeInterestAccrualOption))
            {
                result = true;
            }

            return result;

        }  

        public virtual void UpdateTermAccountsMaturityRenewal(string PrincipalMaturityOption="",string BusinessDateOption="",string BusinessDateCalc="")
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpdownPrincipalMaturityOption))
            {
                if (!string.IsNullOrEmpty(PrincipalMaturityOption))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpdownPrincipalMaturityOption, PrincipalMaturityOption);
                }
                if (!string.IsNullOrEmpty(BusinessDateOption))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownBusinessDateOption, BusinessDateOption);
                }
                if (!string.IsNullOrEmpty(BusinessDateCalc))
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownBusinessDateCalc, BusinessDateCalc);
                }
            }

        }

        public virtual void UpdateUSRegulatoryOptions(string IRSReportingOption)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(drpdownIRSReportingOption))
            {
                if (string.IsNullOrEmpty(IRSReportingOption))
                {
                    appHandle.SelectDropdownSpecifiedValue(drpdownIRSReportingOption, IRSReportingOption);
                }
            }
        }

        public virtual void UpdateProductNewAccounts(string StudentLoanProductCheckbox, string StudentLoanStatus)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(chkboxStudentLoanProduct))
            {
                if (!string.IsNullOrEmpty(StudentLoanProductCheckbox))
                {
                    if (StudentLoanProductCheckbox.ToLower().Contains("on") && appHandle.CheckCheckBoxChecked(chkboxStudentLoanProduct) == false)
                    {
                        appHandle.ClickObjectViaJavaScript(chkboxStudentLoanProduct, StudentLoanProductCheckbox);
                    }
                    else if (StudentLoanProductCheckbox.ToLower().Contains("on") && appHandle.CheckCheckBoxChecked(chkboxStudentLoanProduct) == true) { }
                    else if (StudentLoanProductCheckbox.ToLower().Contains("off") && appHandle.CheckCheckBoxChecked(chkboxStudentLoanProduct) == true)
                    {
                        appHandle.ClickObjectViaJavaScript(chkboxStudentLoanProduct, StudentLoanProductCheckbox);
                    }
                    else if (StudentLoanProductCheckbox.ToLower().Contains("off") && appHandle.CheckCheckBoxChecked(chkboxStudentLoanProduct) == false) { }

                    if (!string.IsNullOrEmpty(StudentLoanStatus))
                    {
                        appHandle.SelectDropdownSpecifiedValue(drpdownStudentLoanStatus, StudentLoanStatus);
                    }
                }
            }
        }

        public virtual void UpdateConsumerLoansTransactionProcessing(string OriginationFeePercentage)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtOriginationFeePercentage))
            {
                if (!string.IsNullOrEmpty(OriginationFeePercentage))
                {
                    appHandle.Set_field_value(txtOriginationFeePercentage, OriginationFeePercentage);
                }
            }
        }

        public virtual bool UpdateDataInPostingOptionsTabForTDSetup()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownDisbursementOption);
            appHandle.SelectDropdownSpecifiedValue(dropdownDisbursementOption,"Remain On Deposit");
            appHandle.Set_field_value(txtPostingFrequency,"1MAE");
            appHandle.ClickObjectViaJavaScript(buttonSubmitnew);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }

        public virtual bool UpdateFreqAndSubToWithholdcheckboxinPostingOptions(string freqval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtPostingFrequency);
            appHandle.Set_field_value(txtPostingFrequency,freqval);
            if(!appHandle.CheckCheckBoxChecked(checkboxSubjectToWithholding))
                appHandle.ClickObject(checkboxSubjectToWithholding);
            appHandle.ClickObject(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }

    }
}
