using System;
using GTS_OSAF.CoreLibs;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class LoanFeePlanCalculationPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtBaseFeeAmount = "name;fixedDollarAmt";
        
      
     }
}