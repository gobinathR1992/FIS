using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using GTS_OSAF.Util;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class LoanInterestCapitalizedInterestProcessingPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtDeferredInterestResolutionFrequency = "XPath;//input[@name='PRODDFTL_DIRFRE']";

        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        
        public virtual bool WaitUntilCapitalizedInterestProcessingPageLoad()
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtDeferredInterestResolutionFrequency))
            {
                result = true;
            }

            return result;

        }

       public virtual void EnterValuesForCapitalizedInterestProcessingPageField(string sLabelNameLabelValuePipeDelimited)
          {
               Profile7CommonLibrary.EnterDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
               appHandle.ClickObjectViaJavaScript(buttonSubmit);
          }
        public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }

         public virtual bool VerifyMessageCapitalizedInterestProcessingPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }

    }

}