using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Collections.Generic;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Profile7Automation.Libraries.Util;
using System;
using GTS_OSAF.HelperLibs.DataAdapter;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class LoanTransactionProcessingPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtLoanFeesOriginationFeePercentage = "XPath;//input[@name='PRODDFTL_ORGFP']";
        public static string txtLoanFeesCommitmentFeePercentage = "XPath;//input[@name='PRODDFTL_COMFP']";
        private static string buttonSubmit = "XPath;//*[@Value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string dropdownEarlyPayOffPenaltyMethod = "Xpath;//*[contains(text(),'Early Payoff Penalty Method:')]/parent::*[1]/following-sibling::*/descendant::select";

        private static string MSGOBJ = "XPath;//div[@class='msg-box']/descendant::p[1]";
        private static string txtMaximumNoOfDisbursement= "XPath;//*[@name='PRODDFTL_MAXDRCT']";
        


        public virtual bool SelectEarlyPayOffPenaltyMethod(string PenaltyMethod)
        {
            bool result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownEarlyPayOffPenaltyMethod))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownEarlyPayOffPenaltyMethod, PenaltyMethod);
                if (appHandle.CheckValueInDropdown(dropdownEarlyPayOffPenaltyMethod, PenaltyMethod))
                {
                    result = true;
                }
            }
            return result;
        }
        public virtual bool VerifyMessageInLoanTransactionProcessingPage(string strMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(strMessage))
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual void SelectSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
        public virtual void UpdateMaximumNoOfDisbursement(string MaxNo)
        {
            appHandle.WaitUntilElementExists(txtMaximumNoOfDisbursement);
            appHandle.Set_field_value(txtMaximumNoOfDisbursement,MaxNo);
        }

        public virtual void ClickOnSubmit()
        {
            appHandle.WaitUntilElementExists(buttonSubmit);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);

        }
         public virtual bool VerifyMessageInWebAdminLoanInterestCalculationPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGOBJ))
            {
                if (appHandle.GetObjectText(MSGOBJ).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        

    }

    }

