using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class WebAdminPackagesPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string AddButton="XPath;//input[@type='submit'][@name='add']";
        private static string PackageSuccessMessage="XPath;//p[text()='Package Products have been created.']";


        public virtual bool CheckPackageSuccessMessage(string inputMessage)
        {
            bool Result=false;
            if(appHandle.GetObjectText(PackageSuccessMessage).Equals(inputMessage))
            {
                Result=true;
            }
            else
            {
                Result=false;
            }
            return Result;
        }

         public virtual void ClickAddButton()
        {
            appHandle.SelectButton(AddButton); 
            Thread.Sleep(2000);
            Report.Info("Add button is clicked.");
        }
        
    }
}