using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;
using Profile7Automation.Libraries.Util;
using GTS_OSAF.HelperLibs.DataAdapter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class USRegulatoryRegulatoryPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string ckbRegionFlag = "XPath;//input[@name='CUVAR_REGFLG']";
        public static string ckbCIFCutoffFor1098="Xpath;//input[@name='CUVAR_CTOF1098']";
        public static string ckbCIFCutoffFor1099="Xpath;//input[@name='CUVAR_CTOF1099']";
        public static string ckbCutofffor1042S="Xpath;//input[@name='CUVAR_CTOF1042S']";
        public static string checkBoxRegulationCCAccount = "Xpath;//input[@name = 'PRODDFTD_REGCC']";
        public static string checkBoxRegulationDDAccount = "Xpath;//input[@name = 'PRODDFTD_REGDD']";
        public static string ckbReportAllNonResidentAlienson1042S="Xpath;//input[@name='CUVAR_RPT1042S']";
        public static string ckbTruncateTaxpayerIdentificationNumber="Xpath;//input[@name='CUVAR_TRUNCATETIN']";
        public static string txtPayerName="Xpath;//input[@name='CUVAR_PAYERNAM']";
        public static string txtTransmitterCodeDefault="Xpath;//input[@name='CUVAR_TCC']";
        public static string txtReportMortgageInsurancePremium="Xpath;//input[@name='CUVAR_REPORTMIP']";
        public static string txtFinancialYearEnd="Xpath;//input[@name='CUVAR_FINYE']";
        public static string txtTaxYearEnd="Xpath;//input[@name='CUVAR_TAXYE']";
        public static string txtIRSContactName="Xpath;//input[@name='CUVAR_AGNTNAME']";
        public static string txtIRSContactDepartment="Xpath;//input[@name='CUVAR_AGNTTITLE']";
        public static string txtMaximumRecordsperFile="Xpath;//input[@name='CUVAR_MAXIRSFIRERECORDS']";
        public static string txtReportingInstitutionName="Xpath;//input[@name='CUVAR_INAME']";
        public static string txtReportingInstitutionAddress1="Xpath;//input[@name='CUVAR_IAD1']";
        public static string txtReportingInstitutionAddress2="Xpath;//input[@name='CUVAR_IAD2']";
        public static string txtReportingInstitutionAddress3="Xpath;//input[@name='CUVAR_IAD3']";
        public static string txtReportingInstitutionCity="Xpath;//input[@name='CUVAR_ICITY']";
        public static string txtReportingInstitutionZipCode="Xpath;//input[@name='CUVAR_IZIP']";
        public static string txtReportingInstitutionTransmitterIDNumber="Xpath;//input[@name='CUVAR_IEIN']";
        public static string txtReportingInstitutionTechnicalContactName="Xpath;//input[@name='CUVAR_CONTACT']";
        public static string txtReportingInstitutionTechnicalContactAreaCode="Xpath;//input[@name='CUVAR_CAC']";
        public static string txtReportingInstitutionTechnicalContactTelephoneNumber="Xpath;//input[@name='CUVAR_CTELE']";
        public static string txtReportingInstitutionTechnicalContactExtnNumber="Xpath;//input[@name='CUVAR_CEXTN']";
        public static string txtReportingInstitutionTechnicalContactEmailAddress="Xpath;//input[@name='CUVAR_CEMAIL']";
        public static string txtVendorInformationContactName="Xpath;//input[@name='CUVAR_VCNAME']";
        public static string txtVendorInformationContactEmailAddress="Xpath;//input[@name='CUVAR_VEMAIL']";
        public static string txtVendorInformationContactAreaCode="Xpath;//input[@name='CUVAR_VCCODE']";
        public static string txtVendorInformationContactPhoneNumber="Xpath;//input[@name='CUVAR_VPHONE']";
        public static string txtVendorInformationName="Xpath;//input[@name='CUVAR_VNAME']";
        public static string txtVendorInformationMailingAddress="Xpath;//input[@name='CUVAR_VADDR']";
        public static string txtVendorInformationCity="Xpath;//input[@name='CUVAR_VCITY']";
        public static string txtVendorInformationZipCode="Xpath;//input[@name='CUVAR_VZIP']";
        public static string drpReportingInstitutionFilingCountry="Xpath;//select[@name='CUVAR_MAGCTRY']";
        public static string drpReportingInstitutionCountryCode="Xpath;//select[@name='CUVAR_ICNTRY']";
        public static string drpReportingInstitutionState="Xpath;//select[@name='CUVAR_ISTATE']";
        public static string drpVendorInformationState="Xpath;//select[@name='CUVAR_VSTATE']";
        private static string buttonSubmit = "XPath;//input[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string sSuccessMessage = "xpath;//p[contains(text(),'The information has been updated.')]";
        
        public static string dropdownRegulationDCategory="XPath;//select[@name='PRODDFTD_REGD']";
        public static string txtMMDACycleFrequency="XPath;//input[@name='PRODDFTD_MMDA4']";

        public static string checkboxSubjecttoregulationDD="XPath;//input[@name='PRODDFTD_REGDD']";
        public static string checkboxEligibleforCourtesyOverdraft="XPath;//input[@name='PRODDFTD_ODOPT']";
        public static string buttonSubmitnew="XPath;//input[@name='submit']";
        private static string checkboxReportAllNonresidentAlienson1042s="Xpath;//*[@name='CUVAR_RPT1042S']";


        public virtual bool ClickOnRegulationDDAccountCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkBoxRegulationDDAccount))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkBoxRegulationDDAccount)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkBoxRegulationDDAccount);
                        if (appHandle.CheckCheckBoxChecked(checkBoxRegulationDDAccount))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkBoxRegulationDDAccount) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkBoxRegulationDDAccount);
                        if (appHandle.CheckCheckBoxChecked(checkBoxRegulationDDAccount) == false) { Result = true; }
                    }
                }
            }
            return Result;
           

        }
           public virtual void SelectSubmitButton()
        {
            appHandle.Wait_for_object(buttonSubmit, 3);
            appHandle.SelectButton(buttonSubmit);
            appHandle.Wait_for_object(sSuccessMessage,5);
        }
        public virtual bool VerifyMessageDepositRateDeterminationPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual bool ClickOnRegulationCCAccountCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkBoxRegulationCCAccount))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkBoxRegulationCCAccount)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkBoxRegulationCCAccount);
                        if (appHandle.CheckCheckBoxChecked(checkBoxRegulationCCAccount))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkBoxRegulationCCAccount) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkBoxRegulationCCAccount);
                        if (appHandle.CheckCheckBoxChecked(checkBoxRegulationCCAccount) == false) { Result = true; }
                    }
                }
            }
            return Result;
           

        }

        public virtual bool UpdateDataInUSRegulatoryTabForTDSetup(string regval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownRegulationDCategory);
            appHandle.SelectDropdownSpecifiedValue(dropdownRegulationDCategory,regval);
            appHandle.Set_field_value(txtMMDACycleFrequency,"1MAE");
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }


        public virtual bool UpdateRegDDAndCourtesyODCheckbox(bool checkboxregddturnONorOFFFlag=true)
        {
            
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxSubjecttoregulationDD);
            if(checkboxregddturnONorOFFFlag)
            {
                if(!appHandle.CheckCheckBoxChecked(checkboxSubjecttoregulationDD))
                {
                    appHandle.ClickObject(checkboxSubjecttoregulationDD);
                }
            }
            else
            {
                if(appHandle.CheckCheckBoxChecked(checkboxSubjecttoregulationDD))
                {
                    appHandle.ClickObject(checkboxSubjecttoregulationDD);
                }
            }
            if(!appHandle.CheckCheckBoxChecked(checkboxEligibleforCourtesyOverdraft))
                appHandle.ClickObject(checkboxEligibleforCourtesyOverdraft);
            appHandle.ClickObject(buttonSubmitnew);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }
        public virtual bool ClickOnReportAllNonresidentAliensOn1042sCheckBox(bool ONorOFF)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(checkboxReportAllNonresidentAlienson1042s))
            {
                if (ONorOFF)
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxReportAllNonresidentAlienson1042s)) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxReportAllNonresidentAlienson1042s);
                        if (appHandle.CheckCheckBoxChecked(checkboxReportAllNonresidentAlienson1042s))
                        { Result = true; }

                    }
                }
                else
                {
                    if (appHandle.CheckCheckBoxChecked(checkboxReportAllNonresidentAlienson1042s) == false) { Result = true; }
                    else
                    {
                        appHandle.ClickObjectViaJavaScript(checkboxReportAllNonresidentAlienson1042s);
                        if (appHandle.CheckCheckBoxChecked(checkboxReportAllNonresidentAlienson1042s) == false) { Result = true; }
                    }
                }
            }
            return Result;
           

        }


    }

}


