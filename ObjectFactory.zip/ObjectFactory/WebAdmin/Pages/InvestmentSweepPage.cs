using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class InvestmentSweepPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonSubmit = "XPath;//*[@Value='Submit']";
        private static string dropdownProcessingOption = "XPath;//*[contains(text(),'Processing Option')]/ancestor::*[1]/following-sibling::*/select";
        private static string dropdownCode = "XPath;//*[contains(text(),'Code')]/ancestor::*[1]/following-sibling::*/select";
        private static string txtSavingsPurchaseThreshold = "XPath;//*[contains(text(),'Savings/Purchase Threshold')]/ancestor::*[1]/following-sibling::*/input";
        private static string txtRedemptionThreshold = "XPath;//*[contains(text(),'Redemption Threshold')]/ancestor::*[1]/following-sibling::*/input";
        private static string txtRedemptionIncrement = "XPath;//*[contains(text(),'Redemption Increment')]/ancestor::*[1]/following-sibling::*/input";
        private static string dropdownRedemptionOption = "XPath;//*[contains(text(),'Redemption Option')]/ancestor::*[1]/following-sibling::*/select";
        private static string dropdownBalanceOption = "XPath;//*[contains(text(),'Balance Option')]/ancestor::*[1]/following-sibling::*/select";
        private static string dropdownInvestmentPlan = "XPath;//*[contains(text(),'Investment Plan')]/ancestor::*[1]/following-sibling::*/select";
        private static string checkboxNonInstitutionAccount = "XPath;//*[contains(text(),'Non-Institution Account')]/ancestor::*[1]/following-sibling::*/input";
        private static string checkboxDelayInterestDividendPosting = "XPath;//*[contains(text(),'Delay Interest/Dividend Posting')]/ancestor::*[1]/following-sibling::*/input";
        private static string buttonCancel = "XPath;//input[@name='cancel']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        public virtual bool WaitUntilInvestmentSweepPageLoads()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void EnterDetailsInInvestmentSweep(string ProcessingOption = "", string Code = "", string SavingsPurchaseThreshold = "", string SavingsPurchaseIncrement = "", string RedemptionThreshold = "", string RedemptionIncrement = "", string RedemptionOption = "", string BalanceOption = "", string InvestmentPlan = "", bool NonInstitutionAccount = false, bool DelayInterestDividendPosting = false)
        {
            WaitUntilInvestmentSweepPageLoads();
            if (!string.IsNullOrEmpty(ProcessingOption)) { appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownProcessingOption, (string)ProcessingOption); }
            if (!string.IsNullOrEmpty(Code)) { appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownCode, (string)Code); }
            if (!string.IsNullOrEmpty(SavingsPurchaseThreshold)) { appHandle.Set_field_value(txtSavingsPurchaseThreshold, SavingsPurchaseThreshold); }
            if (!string.IsNullOrEmpty(SavingsPurchaseIncrement)) { appHandle.Set_field_value(txtRedemptionIncrement, SavingsPurchaseIncrement); }
            if (!string.IsNullOrEmpty(RedemptionThreshold)) { appHandle.Set_field_value(txtRedemptionThreshold, RedemptionThreshold); }
            if (!string.IsNullOrEmpty(RedemptionIncrement)) { appHandle.Set_field_value(txtRedemptionIncrement, RedemptionIncrement); }
            if (!string.IsNullOrEmpty(RedemptionOption)) { appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownRedemptionOption, (string)RedemptionOption); }
            if (!string.IsNullOrEmpty(BalanceOption)) { appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownBalanceOption, (string)BalanceOption); }
            if (!string.IsNullOrEmpty(InvestmentPlan)) { appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownInvestmentPlan, (string)InvestmentPlan); }
            if (NonInstitutionAccount)
            {
                if (appHandle.CheckCheckBoxChecked(checkboxNonInstitutionAccount)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxNonInstitutionAccount);
                }

            }
            else
            {
                if (appHandle.CheckCheckBoxChecked(checkboxNonInstitutionAccount)) { appHandle.ClickObjectViaJavaScript(checkboxNonInstitutionAccount); }
                else { }
            }
            if (DelayInterestDividendPosting)
            {
                if (appHandle.CheckCheckBoxChecked(checkboxDelayInterestDividendPosting)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxDelayInterestDividendPosting);
                }

            }
            else
            {
                if (appHandle.CheckCheckBoxChecked(checkboxDelayInterestDividendPosting)) { appHandle.ClickObjectViaJavaScript(checkboxDelayInterestDividendPosting); }
                else { }
            }


        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX);
            }

        }
        public virtual bool VerifyMessageInInvestmentSweepOption(string message)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(message))
                {
                    Result = true;
                }
            }
            return Result;
        }
    }
}