using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Threading;
using System;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class ReportCriteriaPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtCustomer="XPath;//input[@name='Customer']";
        public static string imgProductClass="XPath;//a[contains(@href,'Product Class')]/img";
        public static string buttonclosewindow="XPath;//input[@name='closeButton']";

        public static string imgNoteNumber="XPath;//a[contains(@href,'Note Number')]/img";
        public static string txtAccountNumber="XPath;//input[@name='Account Number']";
        public static string tablelookupvalues="XPath;//table[@class='ledger']/tbody";

        public virtual string VerifyLookupValues(string custno,string reportid)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCustomer);
            appHandle.Set_field_value(txtCustomer,custno);
            appHandle.ClickObjectViaJavaScript(imgProductClass);
            appHandle.SwitchTo(SwitchInto.WINDOW);
            bool depop=Profile7CommonLibrary.VerifyDataInTableByColumnValues("D;Deposit Accounts");
            bool loanop=Profile7CommonLibrary.VerifyDataInTableByColumnValues("L;Loan Accounts");
            
                       
            return depop+""+loanop;
        }

        public virtual void ClickCloseWindowButton()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonclosewindow);
            appHandle.ClickObjectViaJavaScript(buttonclosewindow);
            appHandle.SwitchTo(SwitchInto.DEFAULT);

        }

        public virtual string CheckLookupValuesForReportNOT002A(string accno,string notedesc,string appdate,string expdate)
        {
            int i=2,cnt=0;
            string retop="false";
            string dynamicobj1="XPath;//tr[@class='bkgd2']/td[2]";
            string dynamicobj2="XPath;//tr[@class='bkgd2']/td[3]";
            string dynamicobj3="XPath;//tr[@class='bkgd2']/td[4]";


            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtAccountNumber);
            appHandle.Set_field_value(txtAccountNumber,accno);
            appHandle.ClickObjectViaJavaScript(imgNoteNumber);
            appHandle.SwitchTo(SwitchInto.WINDOW);
            
            string txt1=appHandle.GetObjectText(dynamicobj1);
            i++;
            string txt2=appHandle.GetObjectText(dynamicobj2);
            i++;
            string txt3=appHandle.GetObjectText(dynamicobj3);
            if(txt1.Equals(notedesc))
            {
                cnt++;
            }
            if(txt2.Equals(appdate))
            {
                cnt++;
            }
            

            if(cnt==2)
            {
                retop="true";
            }            

            
            return retop;
        }


                
    }
}
