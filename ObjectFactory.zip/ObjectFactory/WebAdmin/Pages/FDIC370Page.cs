using GTS_CORE.HelperLibs;
using GTS_OSAF.CoreLibs; 
using Profile7Automation.Libraries.Util;

 
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page] 
    public class FDIC370Page
    { 
         public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
         public static string buttonRun="Xpath;//*[@id='runButton']";
         private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";

         public static string drpdownHoldType="Xpath;//*[@name='promptForms[0].propertyKey']";

         public virtual void ClickonRun()
         {
             appHandle.WaitUntilElementExists(buttonRun);
             appHandle.ClickObjectViaJavaScript(buttonRun);
         }

         public virtual bool VerifyMessageInFDIC370(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
        public virtual void SelectHoldType(string HoldType)
        {
            appHandle.WaitUntilElementExists(drpdownHoldType);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpdownHoldType,HoldType);
        }

    }
}