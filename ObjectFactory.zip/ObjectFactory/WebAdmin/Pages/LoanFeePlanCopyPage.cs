using GTS_OSAF.CoreLibs;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class LoanFeePlanCopyPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtCopyLoanFeePlanToFeePlan = "name;feeplanCopy";
        public static string txtCopyLoanFeePlanDescriptionField = "name;description";
        
     
     }
}