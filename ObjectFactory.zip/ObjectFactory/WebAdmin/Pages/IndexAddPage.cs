using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System.Collections.Generic;
using Profile7Automation.Libraries.Util;
using OpenQA.Selenium;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class IndexAddPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtInterestIndex = "XPath;//input[@name='INDEX_INDEX']";
        public static string txtInterestIndexDescription = "XPath;//input[@name='INDEX_DES']";
        public static string drpIndexType = "XPath;//select[@name='INDEX_BASREL']";
        public static string drpScheduleCMRIndexCode = "XPath;//select[@name='INDEX_CMRINDEX']";
        public static string drpReferenceRate = "XPath;//select[@name='INDEX_FR2420REFRATE']";
        public static string drpTieredIndexType = "XPath;//select[@name='INDEX_INDTYP']";
        public static string cbkDataItemAuthorization = "XPath; //input[@name='INDEX_DIAUTH']";
        public static string cbkLaggingMarketIndex = "XPath; //input[@name='INDEX_LAG']";
        public static string drpRateCalculationOption = "XPath;//select[@name='INDEX_IRATO']";
        public static string txtNoofDaystoAverageRate = "XPath;//input[@name='INDEX_AVGDYS']";
        public static string cbkDailyRateOption = "XPath; //input[@name='INDEX_DLYF']";
        public static string drpComparisonOption = "XPath;//select[@name='INDEX_COMP']";
        public static string txtOperatorandRounding = "XPath;//input[@name='INDEX_EXTENSION']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonRates = "Xpath;//*[@value='Rates']";
        public WebApplication AppHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        /// <summary>
        /// To enter value in Edit Feild in IndexAddPage.
        /// <param name = "Feild Name"></param> 
        /// <param name = "Feild Value"></param> 
        /// <returns></returns>
        /// <example>SetEditValue(sfieldname,sfieldvalue)</example>
        public virtual void SetEditValue(string sfieldname, string sfieldvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sfieldname);
                AppHandle.WaitUntilElementClickable(sfieldname);
                AppHandle.Set_field_value(sfieldname, sfieldvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To select dropdown value in IndexAddPage.
        /// <param name = "dropdown Name"></param> 
        /// <param name = "dropdown Value"></param> 
        /// <returns></returns>
        /// <example>SelectDropdownValue(sdrpname,sdrpvalue)</example>
        public virtual void SelectDropdownValue(string sdrpname, string sdrpvalue)
        {
            try
            {
                AppHandle.WaitUntilElementVisible(sdrpname);
                AppHandle.WaitUntilElementClickable(sdrpname);
                AppHandle.SelectDropdownSpecifiedValue(sdrpname, sdrpvalue);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To Enter Details in IndexAddPage
        /// <param name="lstAddIndxdetails"></param>
        /// lstAddIndxdetails.Add(IndexAddPage.txtNoofDaystoAverageRate + "|field|15");
        /// lstAddIndxdetails.Add(IndexAddPage.cbkDataItemAuthorization + "|checkbox|on");
        /// lstAddIndxdetails.Add(IndexAddPage.cbkLaggingMarketIndex + "|checkbox|off");
        /// lstAddIndxdetails.Add(IndexAddPage.drpTieredIndexType  + "|dropdown|C -Cumulative");
        /// <returns></returns>
        /// <example>EnterDetailsinIndexAddPage(lstAddIndxdetails)</example>
        public virtual void EnterDetailsinIndexAddPage(List<string> lstAddIndxdetails)
        {
            try
            {
                string[] arrserplnDetails = new string[3];
                for (int i = 0; i < lstAddIndxdetails.Count; i++)
                {
                    arrserplnDetails = AppHandle.SplitString(lstAddIndxdetails[i], "|"); //separator
                    switch (arrserplnDetails[1].ToUpper())
                    {
                        case "FIELD":
                            if (arrserplnDetails[0] != txtInterestIndex || arrserplnDetails[0] != txtInterestIndexDescription)
                                AppHandle.Set_field_value(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "DROPDOWN":
                            if (arrserplnDetails[0] != drpIndexType)
                                AppHandle.SelectDropdownSpecifiedValue(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "CHECKBOX":
                            if (arrserplnDetails[2].ToUpper() == "ON")
                                AppHandle.SelectCheckBox(arrserplnDetails[0]);
                            else
                                AppHandle.DeSelectCheckBox(arrserplnDetails[0]);
                            break;
                    }
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To check Index exists message.
        /// <param></param> 
        /// <returns>bool</returns>
        /// <example>bool val = CheckIndexExistsMessage()</example>
        public virtual bool CheckIndexExistsMessage()
        {
            bool bcheck = false;
            try
            {
                string obj = "XPath;//div[@class='error']//p[text()='Record already exists in table INDEX']";
                AppHandle.Wait_For_Specified_Time(3);
                bcheck = AppHandle.IsObjectExists(obj);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }
        public virtual string EnterIndexDetails(string strIndexType, string strInterestIndex = "", string IndexDescription = "", string AdditionalDetailLabelnameLabelValueByPipeDelimited = "")
        {
            string tagname = "";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);

            if (string.IsNullOrEmpty(strInterestIndex))
            {
                strInterestIndex = appHandle.CreateRamdomData(FieldType.ALPHABETS, 11, 99, 2).ToString().ToUpper() + appHandle.CreateRamdomData(FieldType.NUMERIC, 111, 999, 3).ToString();
            }

            appHandle.Set_field_value(txtInterestIndex, strInterestIndex);
            if (string.IsNullOrEmpty(IndexDescription))
            {
                IndexDescription = strInterestIndex;

            }
            appHandle.Set_field_value(txtInterestIndexDescription, IndexDescription);
            appHandle.SelectDropdownSpecifiedValueByPartialText(drpIndexType, strIndexType);
            if (!string.IsNullOrEmpty(AdditionalDetailLabelnameLabelValueByPipeDelimited))
            {
                AdditionalDetailLabelnameLabelValueByPipeDelimited = AdditionalDetailLabelnameLabelValueByPipeDelimited + ";";
                string[] arr = AdditionalDetailLabelnameLabelValueByPipeDelimited.Split(';');
                for (int a = 0; a < arr.Length - 1; a++)
                {
                    string LabelName = arr[a].Split('|')[0];
                    string LabelValue = arr[a].Split('|')[1];
                    string RunTimeObj = "XPath;//*[contains(text(),'" + LabelName + "')]/ancestor::*[1]/following-sibling::*/*[1]";
                    try
                    {
                        IWebElement obj = (IWebElement)appHandle.FindElement(RunTimeObj);
                        tagname = obj.TagName;
                        if (tagname.Trim().ToUpper().Equals("SELECT"))
                        {
                            appHandle.SelectDropdownSpecifiedValueByPartialText(RunTimeObj, LabelValue);
                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            if (LabelValue.Equals("ON"))
                            {
                                if (appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                }
                            }
                            else
                            {
                                if (!appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                }
                            }

                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && !appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            appHandle.Set_field_value(RunTimeObj, LabelValue);
                        }
                    }
                    catch (Exception e) { }
                }
            }
            return strInterestIndex;
        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                
            }
        }
         public virtual bool VerifyMessageInInterestAddPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
    }
}