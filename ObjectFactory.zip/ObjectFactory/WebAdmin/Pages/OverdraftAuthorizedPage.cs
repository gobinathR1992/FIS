using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class OverdraftAuthorizedPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        public static string txtAuthorizedOverdraftLimit = "Xpath;//input[@name='PRODDFTD_ODLIM']";
        public static string txtAuthorizedOverdraftTerm = "Xpath;//input[@name='PRODDFTD_ODTERM']";
        public static string txtCommitmentFeePercentage = "Xpath;//input[@name='PRODDFTD_COMMFPER']";
        public static string ckbAuthorizedProvisionProcessing = "Xpath;//input[@name='PRODCTL_PROVPO']";
        public static string ckbAuthorizedDepositReclassification = "Xpath;//input[@name='PRODCTL_DARCPO']";
        private static string buttonSubmit = "XPath;//input[@name='submit']";
        private static string buttonCancel = "XPath;//input[@name='cancel']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        public static string dropdownOptions="XPath;//select[@name='PRODDFTD_ODO']";
        public static string txtLimit="XPath;//input[@name='PRODDFTD_NSFLIM']";

        public virtual void setoverdraftlimitvalue(string sLimit)
        {
            appHandle.Set_field_value(txtAuthorizedOverdraftLimit, sLimit);
        }

        public virtual void setoverdrafttermvalue(string sTerm)
        {
            appHandle.Set_field_value(txtAuthorizedOverdraftTerm, sTerm);
        }

        public virtual void setCommitmentFeePercentagevalue(string sPercentage)
        {
            appHandle.Set_field_value(txtCommitmentFeePercentage, sPercentage);
        }

        public virtual void selecttheprovisionprocessing()
        {
            appHandle.SelectCheckBox(ckbAuthorizedProvisionProcessing);
        }

        public virtual void selectdepositreclassification()
        {
            appHandle.SelectCheckBox(ckbAuthorizedDepositReclassification);
        }
        public virtual void EnterDataInOverdraftAuthorizedPage(string AuthorizedOverdraftLimit = "", string AuthorizedOverdraftTerm = "", bool ProvisionProcessing = false, bool DepositReclassification = false, string CommitmentFeePercentage = "")
        {
            if (!string.IsNullOrEmpty(AuthorizedOverdraftLimit)) { appHandle.Set_field_value(txtAuthorizedOverdraftLimit, AuthorizedOverdraftLimit); }
            if (!string.IsNullOrEmpty(AuthorizedOverdraftTerm)) { appHandle.Set_field_value(txtAuthorizedOverdraftTerm, AuthorizedOverdraftTerm); }
            if (ProvisionProcessing)
            {
                if (appHandle.CheckCheckBoxChecked(ckbAuthorizedProvisionProcessing)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(ckbAuthorizedProvisionProcessing);
                }

            }
            else
            {
                if (appHandle.CheckCheckBoxChecked(ckbAuthorizedProvisionProcessing)) { appHandle.ClickObjectViaJavaScript(ckbAuthorizedProvisionProcessing); }
                else { }
            }
            if (DepositReclassification)
            {
                if (appHandle.CheckCheckBoxChecked(ckbAuthorizedDepositReclassification)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(ckbAuthorizedDepositReclassification);
                }

            }
            else
            {
                if (appHandle.CheckCheckBoxChecked(ckbAuthorizedDepositReclassification)) { appHandle.ClickObjectViaJavaScript(ckbAuthorizedDepositReclassification); }
                else { }
            }

            if (!string.IsNullOrEmpty(CommitmentFeePercentage)) { appHandle.Set_field_value(txtCommitmentFeePercentage, CommitmentFeePercentage); }

        }
        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX);
            }
        }
        public virtual bool VerifyMessageInOverdraftAuthorizedPage(string message)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(message))
                {
                    Result = true;
                }
            }
            return Result;
        }
         public virtual bool WaitUntilOverdraftAuthorizedPageLoads()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                Result = true;
            }
            return Result;
        }


        public virtual bool EnterDataForOptionsAndLimitInLinkedOverdraftPage(string optionval,string limitval)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownOptions);
            appHandle.SelectDropdownSpecifiedValue(dropdownOptions,optionval);
            appHandle.Set_field_value(txtLimit,limitval);
            appHandle.ClickObject(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));

        }
    }
}