using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class UserListPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string UserListActionTable = "";
        public static string btnRestore = "Name;restore";
        public static string tabUserClassPermission="XPath;//td[contains(text(),'Userclass Permissions')]";

        /// <summary>
        /// This method is used to select specified user in UserList table
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.UserListPage.SelectSpecifiedUser();
        /// </example> 
        public void SelectSpecifiedUser(string userId)
        {
            UserListActionTable = "Xpath;//input[@name='agent'][@value=" + userId + "]";
            appHandle.Set_radiobutton(UserListActionTable);
        }
        /// <summary>
        /// This method is used to click on restore button
        /// </summary>
        /// <returns>true/false</returns> 
        /// <example>
        /// WebAdminPageFactory.UserListPage.clickOnRestoreButtonAndVerifySuccessMsg();
        /// </example>
        public virtual bool clickOnRestoreButtonAndVerifySuccessMsg()
        {
            bool bCheck = false;
            try
            {
                appHandle.ClickObject(btnRestore);
                bCheck = appHandle.CheckSuccessMessage("GLOBAL_USER_RESTORED_MESSAGE");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;
        }


        public virtual void ClickOnTabUserClassPermission()
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tabUserClassPermission);
            appHandle.ClickObjectViaJavaScript(tabUserClassPermission);
        }
    }

}