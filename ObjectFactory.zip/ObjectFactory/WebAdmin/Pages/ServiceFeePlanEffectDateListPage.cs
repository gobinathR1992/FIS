using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages

{
    public class ServiceFeePlanEffectDateListPage
    {
        public static WebApplication appHandle=ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string btnEditServiceFeePlanEffectiveDate = "XPath;//input[@name='edit'][contains(@onclick,'effectiveDateModify')]";
        public static string btnDeleteServiceFeePlanEffectiveDate = "XPath;//input[@name='delete'][contains(@onclick,'deleteEffectiveDate')]";
        public static string btnCancelServiceFeePlanEffectiveDate = "XPath;//input[@name='cancel'][@value='Delete']";
        public static string tblActionServiceFeePlanEffectiveDateList = "XPath;//table[@class='contentTable']//div[contains(@id,'effective-date-list')]";
        //public WebApplication appHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }

        public static string buttonEdit="XPath;//input[@name='edit']";
        public static string tableServiceFeeplan="XPath;//table[@id='effective-date-list']/tbody";
        public static string buttonDelete = "XPath;//input[@name='delete']";
        
        /// <summary>
        /// To verify Edit button Exists in ServiceFeePlanEffectDateListPage.
        /// <param></param> 
        /// <returns></returns>
        /// <example>CheckEditServiceFeePlanEffectiveDateExists()</example>
        public virtual bool CheckEditServiceFeePlanEffectiveDateExists()
        {
            bool bcheck = false;
            try
            {
                appHandle.WaitUntilElementVisible(btnEditServiceFeePlanEffectiveDate);
                appHandle.WaitUntilElementClickable(btnEditServiceFeePlanEffectiveDate);
                bcheck = appHandle.IsObjectExists(btnEditServiceFeePlanEffectiveDate);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bcheck;
        }

        public virtual void ClickOnEditButton()
        {
            appHandle.ClickObjectViaJavaScript(buttonEdit);
        }

        public virtual void SelectRadioButtonInFeePlanTable(string refvalues)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit); 
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableServiceFeeplan);
            appHandle.SelectRadioButtonInTable(tableServiceFeeplan,refvalues);
        }
        public virtual void ClickOnDeleteButton()
        {
            appHandle.ClickObjectViaJavaScript(buttonDelete);
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept); 
        }

    }

}