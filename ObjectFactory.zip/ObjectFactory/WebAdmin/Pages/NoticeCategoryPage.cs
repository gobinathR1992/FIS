using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using System;
using System.Collections.Generic;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class NoticeCategoryPage
    {
        WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string tblNoticeCategoryList = "XPath;//body[@class='main']/table[@id='mainTable']/tbody/tr/td[@id='content']/table/tbody[1]";
        public static string txtategoryName="Xpath;//input[@name='FWKNOTICECATEGORY_NAME']";
        public static string txtCategoryDescription="Xpath;//input[@name='FWKNOTICECATEGORY_DESCRIPTION']";

    }

}
