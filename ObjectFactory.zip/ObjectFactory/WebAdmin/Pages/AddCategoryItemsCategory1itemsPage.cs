using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class AddCategoryItemsCategory1itemsPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpFeeType="Xpath;//select[@name='exemptionPlanCategoryList1[0].feeType']";
        public static string txtFeeAmount="Xpath;//input[@name='exemptionPlanCategoryList1[0].feeAmount']";
        public static string btnSubmit="Xpath;//input[@name='_eventId_submit']";

        //Method for Click the submit button.
        public virtual void ClickSubmitButton()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            appHandle.SelectButton(btnSubmit);
            Thread.Sleep(1000);
            Report.Info("Submit button is clicked.");
        }


    }
}