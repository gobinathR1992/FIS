using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.HelperLibs.DataAdapter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class IndexListPage
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string tableIndexList = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";
        private static string buttonAdd = "Xpath;//*[@value='Add']";
        private static string txtEffectiveDate = "XPath;//*[contains(text(),'Effective Date')]/parent::td/following-sibling::*/descendant::input";
        private static string buttonEdit = "Xpath;//*[@value='Edit']";
        private static string buttonRates = "Xpath;//*[@value='Rates']";
        private static string buttonSubmit = "XPath;//*[@value='Submit']";
        private static string checkboxAnticipatedRun = "Xpath;//input[@name = 'anticipatedRun']";
        private static string txtRateOrIndex = "Xpath;//*[contains(text(),'Rate or Index')]/ancestor::*[1]/following-sibling::*/input";
        private static string tableobject = "XPath;//*[@class='contentTable']/tbody/descendant::tbody";
        private static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        private static string txtEffectiveDateInterestRates = "XPath;//*[contains(text(),'Effective Date')]/ancestor::*[1]/following-sibling::*/descendant::input";
        private static string checkboxDayendRun = "Xpath;//input[@name = 'runAtDayends']";
        private static string ERRMSGBOX = "Xpath;//*[@id='core-error-box']/descendant::p[1]";
        /// <summary>
        /// This method is used to select specified Index Name in InterestIndexList Table
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName();
        /// </example> 
        public void SelectSpecifiedIndexName(string sIndexName)
        {
            SelectIndexInIndexList(sIndexName);
        }
        public virtual void ClickOnEditButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
            }
        }
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            }
        }
        public virtual void ClickOnRatesButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRates))
            {
                appHandle.ClickObjectViaJavaScript(buttonRates);
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            }
        }
        public virtual void EnterEffectiveDate(string sEffectiveDate)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtEffectiveDate))
            {
                appHandle.Set_field_value(txtEffectiveDate, sEffectiveDate);
            }
        }
        public virtual void EnterRateORIndex(string RateORIndex, bool AnticipatedONorOFF, bool DayendONorOFF)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtRateOrIndex))
            {
                appHandle.Set_field_value(txtRateOrIndex, RateORIndex);
            }
            if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("Anticipated Run")))
            {
                if (!AnticipatedONorOFF)
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Anticipated Run") + "|" + Data.Get("OFF"));
                }
                else
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Anticipated Run") + "|" + Data.Get("GLOBAL_ON"));
                }
            }
            if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("Run at Dayend")))
            {
                if (!DayendONorOFF)
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Run at Dayend") + "|" + Data.Get("OFF"));
                }
                else
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Run at Dayend") + "|" + Data.Get("GLOBAL_ON"));
                }
            }

        }

        public virtual void SelectIndexInIndexList(string index)
        {
            string runTimeObj = "XPath;//*[@name='INDEX_INDEX'][@value='" + index + "']";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runTimeObj))
            {
                appHandle.ClickObjectViaJavaScript(runTimeObj);
            }
        }

        public virtual bool EnterDataInTieredInterestIndexRates(string TiredIndexRateDetails)
        {
            string temp = "";
            bool DataEntered = false;
            int numberofDataToEnterPerRow = 0;
            int RecordCount = 0;
            TiredIndexRateDetails = TiredIndexRateDetails + ";";
            string[] arr = TiredIndexRateDetails.Split(';');
            int rowscount = appHandle.GetRowCountfromList(tableIndexList);
            for (int c = 0; c < arr.Length - 1; c++)
            {
                for (int a = 1; a <= rowscount; a++)
                {
                    if (arr[c].Contains("|"))
                    {
                        numberofDataToEnterPerRow = arr[c].Split('|').Length;
                    }
                    else { numberofDataToEnterPerRow = 1; }

                    for (int b = 1; b <= numberofDataToEnterPerRow; b++)
                    {
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableIndexList + "/tr[" + a + "]/td[" + (b + 1) + "]/descendant::input"))
                        {
                            appHandle.Set_field_value(tableIndexList + "/tr[" + a + "]/td[" + (b + 1) + "]/descendant::input", arr[c].Split('|')[b - 1]);

                            temp = temp + " , " + this.GetColumnHeaderNameByColumnNumberInIndexList(b + 1) + " in level : " + a + " is entered as :" + arr[c].Split('|')[b - 1];
                            RecordCount++;
                            if (RecordCount == arr[c].Split('|').Length)
                            {
                                DataEntered = true;
                                RecordCount = 0;
                                break;
                            }
                        }
                        else
                        {
                            DataEntered = false;
                        }
                    }
                    c++;
                    if (c == arr.Length - 1)
                    {
                        if (DataEntered)
                        {
                            temp = temp.Substring(3, temp.Length - 3).Trim();
                            Report.Info(temp, "tieredratesenter", "True", appHandle);
                        }
                        break;
                    }
                    else { continue; }

                }
                if (c == arr.Length - 1) { break; } else { continue; }
            }
            return DataEntered;
        }

        public virtual void ClickOnSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }

        }
        public virtual void EnterDataInComparativeIndexIndexLevelRates(string TypePipeDelimitedValue)
        {
            int recordCount = 0;
            TypePipeDelimitedValue = TypePipeDelimitedValue + ";";
            string[] arr = TypePipeDelimitedValue.Split(';');
            for (int d = 0; d < arr.Length - 1; d++)
            {
                string type = arr[d].Split('|')[0].Trim();
                string Rate = arr[d].Split('|')[1].Trim();

                if (type == "Interest/Dividend Index")
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText("XPath;//*[@name='rateForms[0].rateLevelForms[" + d + "].INDEX1_TIERTYP']", type);
                    appHandle.SelectDropdownSpecifiedValueByPartialText("XPath;//*[@name='rateForms[0].rateLevelForms[" + d + "].INDEX1_RATE']", Rate);
                }
                else
                {
                    appHandle.SelectDropdownSpecifiedValueByPartialText("XPath;//*[@name='rateForms[0].rateLevelForms[" + d + "].INDEX1_TIERTYP']", type);
                    appHandle.Set_field_value("XPath;//*[@name='rateForms[0].rateLevelForms[" + d + "].INDEX1_RATE']", Rate);
                }
                recordCount++;
                if (recordCount == arr.Length - 1)
                {
                    break;
                }
            }

        }
        public virtual string GetColumnHeaderNameByColumnNumberInIndexList(int ColNum)
        {
            string headername = "";
            string runtimeObj = tableIndexList + "/ancestor::*[@class='dataTables_scrollBody']/preceding-sibling::div/descendant::thead/tr[1]/th[" + ColNum + "]";
            headername = appHandle.GetObjectText(runtimeObj).Trim();
            return headername;
        }
        public virtual void SelectEffectiveDate(string EffectiveDate)
        {

            string runTimeObj = "XPath;//*[@type='radio'][@value='" + EffectiveDate + "']";

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runTimeObj))
            {
                appHandle.ClickObjectViaJavaScript(runTimeObj);
            }
        }
        public virtual bool VerifyMessageInIndexListPage(string sMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(ERRMSGBOX))
            {
                if (appHandle.GetObjectText(ERRMSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }     
        public static bool VerifyDataInTableByColumnValues(string sColumnValues, int CounterToCheckUntilElementFound = 60)

        {
            bool Result = false;
            string RunTimeTableObjSpecifiedValue = "";
            string[] ColValArr = sColumnValues.Split(new string[] { ";" }, StringSplitOptions.None);
            for (int b = 0; b < ColValArr.Length; b++)
            {
                RunTimeTableObjSpecifiedValue = RunTimeTableObjSpecifiedValue + "*[contains(@value,'" + ColValArr[b] + "')]/ancestor::tr[1]/descendant::";
            }
            RunTimeTableObjSpecifiedValue = "XPath;//" + RunTimeTableObjSpecifiedValue.Substring(0, RunTimeTableObjSpecifiedValue.Length - 1);
            RunTimeTableObjSpecifiedValue = RunTimeTableObjSpecifiedValue.Substring(0, (RunTimeTableObjSpecifiedValue.Length - "/descendant::".Length));
            RunTimeTableObjSpecifiedValue = RunTimeTableObjSpecifiedValue + "]";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeTableObjSpecifiedValue, CounterToCheckUntilElementFound))
            {
                appHandle.ScrollToObject(RunTimeTableObjSpecifiedValue);
                Result = true;
            }
            return Result;
        }
        public virtual bool VerifyDataInInterestIndexPage(string refColumnValuesSemicolonDelimited)
        {
            bool Result = false;
            int matchCount = 0;
            refColumnValuesSemicolonDelimited = refColumnValuesSemicolonDelimited + "|";
            string[] arr = refColumnValuesSemicolonDelimited.Split('|');
            for (int a = 0; a < arr.Length - 1; a++)
            {
                if (VerifyDataInTableByColumnValues(arr[a]))
                {
                    matchCount++;
                }
                if (matchCount == arr.Length - 1)
                {
                    Result = true;
                    break;
                }
            }

            return Result;
        }

        public virtual void IsAnticipatedDayend(bool AnticipatedONorOFF,bool DayendONorOFF)
        {
            if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("Anticipated Run")))
            {
                if (!AnticipatedONorOFF)
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Anticipated Run") + "|" + Data.Get("OFF"));
                }
                else
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Anticipated Run") + "|" + Data.Get("GLOBAL_ON"));
                }
            }
            if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("Run at Dayend")))
            {
                if (!DayendONorOFF)
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Run at Dayend") + "|" + Data.Get("OFF"));
                }
                else
                {
                    Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Run at Dayend") + "|" + Data.Get("GLOBAL_ON"));
                }
            }

        }
        
    }
}