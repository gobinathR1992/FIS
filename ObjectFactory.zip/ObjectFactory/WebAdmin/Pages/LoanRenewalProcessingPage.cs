using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class LoanRenewalProcessingPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string drpRenewalRecommendationCode="Xpath;//select[@name='PRODDFTL_RRC']";
        public static string txtMaturityAnalysisOffsetDays="Xpath;//input[@name='PRODDFTL_MAODYS']";
        public static string txtOptionsProductionOffsetDays="Xpath;//input[@name='PRODDFTL_RNWOOD']";
        public static string drpRenewalProductCatagory="Xpath;//select[@name='PRODCTL_PRDCAT']";

    }

}