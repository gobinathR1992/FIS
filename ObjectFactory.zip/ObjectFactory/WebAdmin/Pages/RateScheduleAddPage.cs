using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class RateScheduleAddPage
    {
        public static WebApplication appHandle { get => ApplicationHandlerFactory.GetApplication(ApplicationType.WEB); }
        public static string txtRateSchedule = "Xpath;//input[@name='rateSchedule']";
        public static string txtRateScheduleDescription = "Xpath;//input[@name='description']";
        public static string drpRateScheduleTermIncrement = "Xpath;//select[@name='termIncrement']";
        public static string drpRateScheduleRoundingOption = "Xpath;//select[@name='roundingOption']";
        public static string drpRateScheduleCalculationOption = "Xpath;//select[@name='calculationOption']";
        static WebAdminMasterPage webAdminMaster = new WebAdminMasterPage();

        /// <summary>
        /// This method is used to Add new Rate schedule
        /// <param name = "sRateScheduleDetails"></param> 
        /// <returns></returns> 
        /// <example>
        /// WebAdminPageFactory.RateScheduleAddPage.AddRateSchedule(sRateScheduleDetails);
        /// </example> 
        public string AddRateSchedule(string[] sRateScheduleDetails, int NumOfelm)
        {
            string rndrateschedule = null;
            try
            {

                rndrateschedule = (string)webAdminMaster.CreateRamdomData(FieldType.ALPHABETS, 4, 8,6);
                appHandle.Set_field_value(txtRateSchedule, rndrateschedule);
                appHandle.Set_field_value(txtRateScheduleDescription, rndrateschedule);
                NumOfelm = NumOfelm - 1;
                switch (NumOfelm.ToString())
                {
                    case "0":
                        appHandle.SelectDropdownSpecifiedValue(drpRateScheduleTermIncrement, sRateScheduleDetails[0]);
                        break;
                    case "1":
                        if (sRateScheduleDetails[0] != "")
                        {
                            appHandle.SelectDropdownSpecifiedValue(drpRateScheduleTermIncrement, sRateScheduleDetails[0]);
                        }
                        appHandle.SelectDropdownSpecifiedValue(drpRateScheduleRoundingOption, sRateScheduleDetails[1]);
                        break;
                    case "2":
                        if (sRateScheduleDetails[0] != "")
                        {
                            appHandle.SelectDropdownSpecifiedValue(drpRateScheduleTermIncrement, sRateScheduleDetails[0]);
                        }
                        if (sRateScheduleDetails[1] != "")
                        {
                            appHandle.SelectDropdownSpecifiedValue(drpRateScheduleRoundingOption, sRateScheduleDetails[1]);
                        }
                        appHandle.SelectDropdownSpecifiedValue(drpRateScheduleCalculationOption, sRateScheduleDetails[2]);
                        break;
                    default:
                        Report.Info("No rate schedule credentials provided");
                        break;
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return rndrateschedule;
        }
    }
}

