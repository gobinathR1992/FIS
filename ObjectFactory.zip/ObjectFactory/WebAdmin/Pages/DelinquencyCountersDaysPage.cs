using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class DelinquencyCountersDaysPage
    {
        public static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string txtCounterCategory1="XPath;//input[@name='PRODCTL_DCC1']";
        public static string txtCounterCategory2="XPath;//input[@name='PRODCTL_DCC2']";
        public static string txtCounterCategory3="XPath;//input[@name='PRODCTL_DCC3']";
        public static string txtCounterCategory4="XPath;//input[@name='PRODCTL_DCC4']";
        public static string txtCounterCategory5="XPath;//input[@name='PRODCTL_DCC5']";
        public static string txtCounterCategory6="XPath;//input[@name='PRODCTL_DCC6']";
        public static string txtCounterCategory7="XPath;//input[@name='PRODCTL_DCC7']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public virtual bool EnterDetailsForCounterDays(string val1,string val2,string val3,string val4,string val5,string val6,string val7)
        {
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(txtCounterCategory1);
            appHandle.Set_field_value(txtCounterCategory1,val1);
            appHandle.Set_field_value(txtCounterCategory2,val2);
            appHandle.Set_field_value(txtCounterCategory3,val3);
            appHandle.Set_field_value(txtCounterCategory4,val4);
            appHandle.Set_field_value(txtCounterCategory5,val5);
            appHandle.Set_field_value(txtCounterCategory6,val6);
            appHandle.Set_field_value(txtCounterCategory7,val7);  
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED"));        


        }



    }
}