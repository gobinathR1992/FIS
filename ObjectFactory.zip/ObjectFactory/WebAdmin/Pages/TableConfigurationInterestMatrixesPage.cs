using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using System;
using System.Threading;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.Libraries.Util;
using GTS_OSAF;
using System.IO;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class TableConfigurationInterestMatrixesPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string buttonAdd = "XPath;//*[@value='Add']";
        private static string buttonRates = "XPath;//*[@value='Rates']";
        private static string buttonDelete = "XPath;//*[@value='Delete']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonSubmit = "XPath;//*[@Value='Submit']";
        private static string txtMatrixName = "XPath;//*[@name='matrixName']";
        private static string txtMatrixDesc = "Xpath;//*[@name='description']";
        private static string dropdownMatrixRow = "XPath;//*[contains(text(),'Matrix Row')]/ancestor::td/following-sibling::*/descendant::select";
        private static string dropdownMatrixColumn = "XPath;//*[contains(text(),'Matrix Column')]/ancestor::td/following-sibling::*/descendant::select";
        private static string checkboxMassChargeInProgress = "XPath;//*[contains(text(),'Mass Change In-Progress')]/ancestor::td/following-sibling::*/descendant::input";
        private static string tableInterestMatrixRates = "XPath;//*[contains(text(),'Effective Date')]/ancestor::thead/following-sibling::tbody";
        private static string txtEffectiveDateInterestRates = "XPath;//*[contains(text(),'Effective Date')]/ancestor::*[1]/following-sibling::*/descendant::input";
        private static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        private static string tableInterestMatrixRateGrid = "XPath;//*[@id='interestMatrixRateGridBody']";
        private static string cellInterestMatrixGrid = "XPath;//*[@name='records[0].form.row']";
        private static string tableInterestMatrixRate = "XPath;//*[@id='interestMatrixRateGridBody']";
        public static string ApplicationDate = new TableConfigurationInterestMatrixesPage().GetApplicationDate();
        public virtual string GetApplicationDate()
        {
            string result = "";
            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
        }
        public virtual void ClickOnRatesButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRates))
            {
                appHandle.ClickObjectViaJavaScript(buttonRates);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
        }
        public virtual void SelectSubmitButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
        }

        public virtual string ClickOnSubmitButton()
        {
            string tempmatrix = "";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd, 1)) { }
            else
            {
                for (int i = 1; i <= 10; i++)
                {
                    if (appHandle.GetObjectText(MSGBOX).Contains(Data.Get("Record already exists in table UTBLMATATT")))
                    {
                        tempmatrix = GenerateInterestMatrix();
                        appHandle.Set_field_value(txtMatrixName, tempmatrix);
                        appHandle.Set_field_value(txtMatrixDesc, tempmatrix);
                        appHandle.ClickObjectViaJavaScript(buttonSubmit);
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd, 1)) { break; }
                    }
                }
            }
            return tempmatrix;
        }
        public virtual string EnterInterestMatrixDetails(string MatrixName = "", string MatrixDesc = "", string MatrixRow = "", string MatrixColumn = "", bool IsMassChangeInProgress = false)
        {
            string tempmatrixname = "";

            if (string.IsNullOrEmpty(MatrixName))
            {
                tempmatrixname = GenerateInterestMatrix();
                appHandle.Set_field_value(txtMatrixName, tempmatrixname);
            }
            else
            {
                tempmatrixname = MatrixName;
                appHandle.Set_field_value(txtMatrixName, MatrixName);
            }
            if (string.IsNullOrEmpty(MatrixDesc))
            {
                appHandle.Set_field_value(txtMatrixDesc, tempmatrixname);
            }
            else
            {
                appHandle.Set_field_value(txtMatrixDesc, MatrixDesc);
            }
            if (string.IsNullOrEmpty(MatrixRow))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMatrixRow, Data.Get("2 - Balance"));
            }
            else
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMatrixRow, MatrixRow);
            }
            if (!string.IsNullOrEmpty(MatrixColumn))
            {
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownMatrixColumn, MatrixColumn);
            }
            if (IsMassChangeInProgress)
            {
                if (appHandle.CheckCheckBoxChecked(checkboxMassChargeInProgress)) { }
                else
                {
                    appHandle.ClickObjectViaJavaScript(checkboxMassChargeInProgress);
                }

            }
            return tempmatrixname;
        }
        public virtual string GenerateInterestMatrix()
        {
            string OutMatrix = "";
            OutMatrix = (appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 3) + "").ToUpper() + appHandle.CreateRamdomData(FieldType.NUMERIC, 111111, 999999, 6) + "";
            return OutMatrix;
        }
        public virtual bool WaitUntilInterestMatrixPageLoads()
        {
            return Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
        }
        public virtual bool VerifyIterestMatrixInInterestMatrixList(string InterestMatrix)
        {
            bool Result = false;
            string runtimeObj = "XPath;//*[@type='radio'][@value='" + InterestMatrix + "']";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runtimeObj))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void SelectInterestMatrixInInterestMatrixList(string InterestMatrix)
        {
            if (this.VerifyIterestMatrixInInterestMatrixList(InterestMatrix))
            {
                string runtimeObj = "XPath;//*[@type='radio'][@value='" + InterestMatrix + "']";
                appHandle.ClickObjectViaJavaScript(runtimeObj);

            }
        }
        public virtual void EnterDataInInterestMatrixRates(string BalancePipeDelimitedRate, string EffectiveDate = "")
        {
            int recordCount = 0;
            if (string.IsNullOrEmpty(EffectiveDate))
            {
                appHandle.Set_field_value(txtEffectiveDateInterestRates, ApplicationDate);
            }
            else
            {
                appHandle.Set_field_value(txtEffectiveDateInterestRates, EffectiveDate);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            BalancePipeDelimitedRate = BalancePipeDelimitedRate + ";";
            string[] arr = BalancePipeDelimitedRate.Split(';');
            for (int d = 0; d < arr.Length - 1; d++)
            {
                string balance = arr[d].Split('|')[0].Trim();
                string Rate = arr[d].Split('|')[1].Trim();

                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
                {
                    appHandle.ClickObjectViaJavaScript(buttonAdd);
                }

                Profile7CommonLibrary.WaitForSpecifiedObjectExists(cellInterestMatrixGrid);
                appHandle.Set_field_value("XPath;//*[@name='records[" + d + "].form.row']", balance);
                appHandle.Set_field_value("XPath;//*[@name='records[" + d + "].form.spread']", Rate);

                recordCount++;
                if (recordCount == arr.Length - 1)
                {
                    break;
                }
            }

        }
        public virtual bool VerifyMessageInInterestMatrixPage(string strMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(strMessage))
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual void ClickOnEditButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
        }
        private static string mattable ="Xpath;//*[contains(@class,'ledger')]/tbody";
        public virtual void ModifyDataInterestMatrixRatesPostDayEnd(string MatrixRateDetailsPipeDelimited, string EffectiveDate = "", bool IsAnticipatedRun = false, bool IsRunAtDayEnd = false)
        {
            // this.ClickOnAddButton();
            // if (string.IsNullOrEmpty(EffectiveDate))
            // {
            //     appHandle.Set_field_value(txtEffectiveDateInterestRates, ApplicationDate);
            // }
            // else
            // {
            //     appHandle.Set_field_value(txtEffectiveDateInterestRates, EffectiveDate);
            // }
            // if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            // {
            //     appHandle.ClickObjectViaJavaScript(buttonSubmit);
            // }
            // this.WaitUntilInterestMatrixPageLoads();
            
            appHandle.SelectRadioButtonInTable(mattable,EffectiveDate);
            ClickOnEditButton();
            if (!IsAnticipatedRun)
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Anticipated Run") + "|" + Data.Get("OFF"));
            }
            else
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Anticipated Run") + "|" + Data.Get("GLOBAL_ON"));
            }
            if (!IsRunAtDayEnd)
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Run at Dayend") + "|" + Data.Get("OFF"));
            }
            else
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Run at Dayend") + "|" + Data.Get("GLOBAL_ON"));
            }
            MatrixRateDetailsPipeDelimited = MatrixRateDetailsPipeDelimited + ";";
            string[] arr = MatrixRateDetailsPipeDelimited.Split(';');
            int InputDataCount = arr.Length - 1;
            int existingRecordsCount = appHandle.GetRowCountfromList(tableInterestMatrixRate);
            if (InputDataCount <= existingRecordsCount)
            {
                for (int a = 0; a < InputDataCount; a++)
                {
                    for (int b = 0; b < arr[a].Split('|').Length; b++)
                    {
                        if (appHandle.GetSpecifiedObjectAttribute(tableInterestMatrixRate + "/tr[" + (a + 1) + "]/td[" + (b + 1) + "]/descendant::input", "value").Contains(arr[a].Split('|')[b])) { }
                        else
                        {
                            appHandle.Set_field_value(tableInterestMatrixRate + "/tr[" + (a + 1) + "]/td[" + (b + 1) + "]/descendant::input", arr[a].Split('|')[b]);
                        }
                    }

                }

            }
            else if (InputDataCount > existingRecordsCount)
            {
                for (int a = 0; a < existingRecordsCount; a++)
                {
                    for (int b = 0; b < arr[a].Split('|').Length; b++)
                    {
                        if (appHandle.GetSpecifiedObjectAttribute(tableInterestMatrixRate + "/tr[" + (a + 1) + "]/td[" + (b + 1) + "]/descendant::input", "value").Contains(arr[a].Split('|')[b])) { }
                        else
                        {
                            appHandle.Set_field_value(tableInterestMatrixRate + "/tr[" + (a + 1) + "]/td[" + (b + 1) + "]/descendant::input", arr[a].Split('|')[b]);
                        }
                    }
                }
                for (int c = existingRecordsCount; c < InputDataCount; c++)
                {
                    ClickOnAddButton();
                    for (int b = 0; b < arr[c].Split('|').Length; b++)
                    {
                        appHandle.Set_field_value(tableInterestMatrixRate + "/tr[" + (c + 1) + "]/td[" + (b + 1) + "]/descendant::input", arr[c].Split('|')[b]);

                    }

                }
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            appHandle.SwitchTo(SwitchInto.ALERT);
            string AlertMSG = Data.Get("Mass Matrix Change will take effect immediately- it may take some time to complete.");
            AlertMSG = AlertMSG.Replace("-", ";");
            appHandle.PerformActionOnAlert(PopUpAction.Verify, AlertMSG);
            appHandle.Wait_For_Specified_Time(2);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);

        }

        public void SelectEffectiveDateForMatrix(string sEffectiveDate)
        {
            try{
            string tblIndexEffectiveDatesList = "Xpath;//input[@value='"+sEffectiveDate+"']";
            appHandle.WaitUntilElementVisible(tblIndexEffectiveDatesList);
            appHandle.Set_radiobutton(tblIndexEffectiveDatesList);
            }catch(Exception e)
            {
                Report.Info("Exception logged : "+e);
            }
        } 
        public void SelectSpecifiedMatrixName(string matrix)
        {
             string runTimeObj = "XPath;//*[@name='interestMatrixName'][@value='" + matrix + "']";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runTimeObj))
            {
                appHandle.ClickObjectViaJavaScript(runTimeObj);
            }
        }
 
    }
}