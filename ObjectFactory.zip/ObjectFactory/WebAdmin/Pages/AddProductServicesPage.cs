using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class AddProductServicesPage
    {
        WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        public static string dropdownProductServices="XPath;//select[@name='productType']";
        public static string buttonAdd="XPath;//input[@name='add']";
        public static string buttonEdit="XPath;//input[@name='edit']";
        public static string buttonDelete="XPath;//input[@name='delete']";
        public static string dropdownServiceID="XPath;//select[@name='serviceId']";
        public static string txtServiceDescription="XPath;//input[@name='serviceDescription']";
        public static string checkboxBankRecmonded="XPath;//input[@name='bankRecommended']";
        public static string checkboxOptional="XPath;//input[@name='optional']";
        public static string buttonSubmit="XPath;//input[@name='submit']";
        public static string txtPriority="XPath;//input[@name='servicePriority']";

        public virtual bool AddServicesToProduct(string productnumber,string serviceidvalue,bool bankrecmondedflag,bool optionalflag,string priorityval)
        {
            string servicedesc=serviceidvalue+" Description";
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownProductServices);
            appHandle.SelectDropdownSpecifiedValue(dropdownProductServices,productnumber+" - "+productnumber);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
            appHandle.ClickObjectViaJavaScript(buttonAdd);
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
            appHandle.SelectDropdownSpecifiedValue(dropdownServiceID,serviceidvalue);
            appHandle.Set_field_value(txtServiceDescription,servicedesc);
            if(bankrecmondedflag)
            {
                if(!appHandle.CheckCheckBoxChecked(checkboxBankRecmonded))
                    appHandle.ClickObjectViaJavaScript(checkboxBankRecmonded);
            }
            if(optionalflag)
            {
                if(!appHandle.CheckCheckBoxChecked(checkboxOptional))
                    appHandle.ClickObjectViaJavaScript(checkboxOptional);
            }
            appHandle.Set_field_value(txtPriority,priorityval);
            appHandle.ClickObjectViaJavaScript(buttonSubmit);
            return appHandle.CheckSuccessMessage(Data.Get("SuccessMsgProductService"));
            



        }

    }
}