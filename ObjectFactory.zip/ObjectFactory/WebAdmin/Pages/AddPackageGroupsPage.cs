using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.Reporter;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    public class AddPackageGroupsPage
    {
        WebApplication AppHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

        private static string PackageGroupField = "XPath;//input[@id='content:service:PACKGRP']";
        private static string PackageGroupDescriptionField = "XPath;//input[@id='content:service:FMDESC']";
        private static string NumberOfRequiredProductsField = "XPath;//input[@id='content:service:NUMREQ']";
        private static string SubmitButton = "XPath;//input[@value='Submit']";
        private static string ErrorMessage = "XPath;//div[@class='error']";

        public virtual void EnterPackageGroupDetails(string[] PackageGroupdDetails)
        {
            string PackageGroup = PackageGroupdDetails[0];
            string PackageGroupDescription = PackageGroupdDetails[1];
            string NumberOfRequiredProducts = PackageGroupdDetails[2];
            AppHandle.Set_field_value(PackageGroupField, PackageGroup);
            AppHandle.Set_field_value(PackageGroupDescriptionField, PackageGroupDescription);
            AppHandle.Set_field_value(NumberOfRequiredProductsField, NumberOfRequiredProducts);
        }

        public virtual void ClickSubmitButton()
        {
            AppHandle.SelectButton(SubmitButton);
            Thread.Sleep(2000);
            Report.Info("Submit button is clicked.");
        }

        public virtual bool CheckIfErrorMessageAppears()
        {
            bool Result = false;
            if (AppHandle.IsObjectExists(ErrorMessage))
            {
                Result = true;
            }
            else
            {
                Result = false;
            }

            return Result;
        }

        public virtual string ReenterDataOnErrorMessage()
        {
            string PackageGroupName = "Test" + (string)AppHandle.CreateRamdomData(FieldType.ALPHANUMERICS, 0, 0, 6);
            string PriorityDescription = "Test" + (string)AppHandle.CreateRamdomData(FieldType.ALPHANUMERICS, 0, 0, 6);
            string NumberOfRequiredProducts = AppHandle.CreateRamdomData(FieldType.NUMERIC, 1, 5).ToString();
            AppHandle.Set_field_value(PackageGroupField, PackageGroupName);
            AppHandle.Set_field_value(PackageGroupDescriptionField, PriorityDescription);
            AppHandle.Set_field_value(NumberOfRequiredProductsField, NumberOfRequiredProducts);
            return PackageGroupName;
        }


    }
}