using System;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.Libraries.Util;

namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class TableConfigurationRatesSchedulePage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string buttonEdit = "XPath;//*[@value='Edit']";
        private static string buttonAdd = "XPath;//*[@value='Add']";
        private static string buttonRates = "XPath;//*[@value='Rates']";
        private static string buttonDelete = "XPath;//*[@value='Delete']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonSubmit = "XPath;//*[@Value='Submit']";
        private static string AppDateObj = "XPath;//button[contains(text(),'Log Out')]/ancestor::td[1]";
        private static string dropdownRoundingOption = "XPath;//*[contains(text(),'Rounding Option')]/ancestor::td[1]/following-sibling::*[1]/descendant::select";
        private static string txtRateSchedule = "XPath;//*[contains(text(),'Rate Schedule')]/ancestor::td[1]/following-sibling::*[1]/descendant::input";
        private static string txtRateDescription = "XPath;//*[contains(text(),'Description')]/ancestor::td[1]/following-sibling::*[1]/descendant::input";
        private static string dropdownTermIncrement = "XPath;//*[contains(text(),'Term Increment')]/ancestor::td[1]/following-sibling::*[1]/descendant::select";
        private static string dropdownCalculationOption = "Xpath;//*[contains(text(),'Calculation Option')]/ancestor::td[1]/following-sibling::*[1]/descendant::select";
        private static string MSGCouldNotProcessReq = "XPath;//*[@class='main']/descendant::*[contains(text(),'We could not process your request.')]";
        private static string tableRateScheduleEffDate = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";
        private static string txtEffectiveDate="XPath;//*[contains(text(),'Effective Date')]/ancestor::td[1]/following-sibling::*/descendant::input";
        public static string ApplicationDate = new TableConfigurationRatesSchedulePage().GetApplicationDate();
        public virtual string GetApplicationDate()
        {
            string result = "";
            result = appHandle.GetObjectText(AppDateObj).Split(new string[] { "Log Out" }, StringSplitOptions.None)[0].Trim();
            return result;
        }
        public virtual void ClickOnAddButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd))
            {
                appHandle.ClickObjectViaJavaScript(buttonAdd);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit);
        }
        public virtual void ClickOnRatesButton()
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonRates))
            {
                appHandle.ClickObjectViaJavaScript(buttonRates);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
        }
        public virtual string GenerateRateSchedule()
        {
            string OutMatrix = "";
            OutMatrix = (appHandle.CreateRamdomData(FieldType.ALPHABETS, 0, 0, 3) + "").ToUpper() + appHandle.CreateRamdomData(FieldType.NUMERIC, 11111, 99999, 5) + "";
            return OutMatrix;
        }
        public virtual bool WaitUntilRateSchedulePageLoads()
        {
            return Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
        }
        public virtual bool VerifyRateScheduleInRatesScheduleList(string RateSchedule)
        {
            bool Result = false;
            string runtimeObj = "XPath;//*[@type='radio'][@value='" + RateSchedule + "']";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(runtimeObj))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void SelectRateScheduleInRatesScheduleList(string RateSchedule)
        {
            if (this.VerifyRateScheduleInRatesScheduleList(RateSchedule))
            {
                string runtimeObj = "XPath;//*[@type='radio'][@value='" + RateSchedule + "']";
                appHandle.ClickObjectViaJavaScript(runtimeObj);

            }
        }

        public virtual string EnterRateScheduleDetails(string TermIncrement, string RoundingOption, string CalculationOption, string RateSchedule = "", string Description = "")
        {
            if (string.IsNullOrEmpty(RateSchedule))
            {
                RateSchedule = this.GenerateRateSchedule();
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownRoundingOption))
            {
                appHandle.Set_field_value(txtRateSchedule, RateSchedule);
                appHandle.Set_field_value(txtRateDescription, RateSchedule);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownTermIncrement, TermIncrement);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownRoundingOption, RoundingOption);
                appHandle.SelectDropdownSpecifiedValueByPartialText(dropdownCalculationOption, CalculationOption);
            }

            return RateSchedule;
        }
        public virtual string ClickOnSubmitButton()
        {
            string tempRateSchedule = "";
            bool flag = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }

            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd, 1)) { }
            else
            {
                do
                {
                    tempRateSchedule = this.GenerateRateSchedule();
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(dropdownRoundingOption))
                    {
                        appHandle.Set_field_value(txtRateSchedule, tempRateSchedule);
                        appHandle.Set_field_value(txtRateDescription, tempRateSchedule);
                    }
                    appHandle.ClickObjectViaJavaScript(buttonSubmit);
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd, 1))
                    {
                        flag = true;
                    }
                }
                while (flag == true);
            }


            return tempRateSchedule;
        }
        public virtual bool VerifyMessageInRateSchedulesPage(string strMessage)
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(strMessage))
                {
                    Result = true;
                }
            }
            return Result;
        }
        public virtual bool EnterRatesInRateScheduleEffectiveDateList(string RateDetailsPipeDelimited, string EffectiveDate = "", string MinimumBalance = "")
        {
            bool result = false;
            if (string.IsNullOrEmpty(EffectiveDate))
            {
                EffectiveDate = ApplicationDate;
            }
            if (string.IsNullOrEmpty(MinimumBalance))
            {
                MinimumBalance = Data.Get("GLOBAL_AMOUNT_DEPOSITED_1K");
            }
            ClickOnAddButton();
            appHandle.Set_field_value(txtEffectiveDate,EffectiveDate);
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(Data.Get("Minimum Balance") + "|" + MinimumBalance);
            result = this.EnterRatesInRateScheduleTable(RateDetailsPipeDelimited);

            return result;
        }

        public virtual bool EnterRatesInRateScheduleTable(string RateDetailsPipeDelimited)
        {
            string temp = "";
            bool DataEntered = false;
            int numberofDataToEnterPerRow = 0;
            int RecordCount = 0;
            RateDetailsPipeDelimited = RateDetailsPipeDelimited + ";";
            string[] arr = RateDetailsPipeDelimited.Split(';');
            int rowscount = appHandle.GetRowCountfromList(tableRateScheduleEffDate);
            for (int c = 0; c < arr.Length - 1; c++)
            {
                for (int a = 1; a <= rowscount; a++)
                {
                    if (arr[c].Contains("|"))
                    {
                        numberofDataToEnterPerRow = arr[c].Split('|').Length;
                    }
                    else { numberofDataToEnterPerRow = 1; }

                    for (int b = 1; b <= numberofDataToEnterPerRow; b++)
                    {
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(tableRateScheduleEffDate + "/tr[" + a + "]/td[" + (b) + "]/descendant::input"))
                        {
                            appHandle.Set_field_value(tableRateScheduleEffDate + "/tr[" + a + "]/td[" + (b) + "]/descendant::input", arr[c].Split('|')[b - 1]);

                            temp = temp + " , " + this.GetColumnHeaderNameByColumnNumberInRateScheduleEffectiveDateList(b) + " in row : " + a + " is entered as :" + arr[c].Split('|')[b - 1];
                            RecordCount++;
                            if (RecordCount == arr[c].Split('|').Length)
                            {
                                DataEntered = true;
                                RecordCount = 0;
                                break;
                            }
                        }
                        else
                        {
                            DataEntered = false;
                        }
                    }
                    c++;
                    if (c == arr.Length - 1)
                    {
                        if (DataEntered)
                        {
                            temp = temp.Substring(3, temp.Length - 3).Trim();
                            Report.Info(temp, "tieredratesenter", "True", appHandle);
                        }
                        break;
                    }
                    else { continue; }

                }
                if (c == arr.Length - 1) { break; } else { continue; }
            }
            return DataEntered;
        }
        public virtual string GetColumnHeaderNameByColumnNumberInRateScheduleEffectiveDateList(int ColNum)
        {
            string headername = "";
            string runtimeObj = tableRateScheduleEffDate + "/ancestor::*[@class='dataTables_scrollBody']/preceding-sibling::div/descendant::thead/tr[1]/th[" + ColNum + "]";
            headername = appHandle.GetObjectText(runtimeObj).Trim();
            return headername;
        }
        public virtual void SelectSubmitButton()

        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
            Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
        }
    }
}