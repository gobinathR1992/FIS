using GTS_OSAF.CoreLibs;
using Profile7Automation.Libraries.Util;
namespace Profile7Automation.ObjectFactory.WebAdmin.Pages
{
    [Page]
    public class TableConfigurationRelationshipCodesPage
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        private static string tableRelationshipCodesList = "XPath;//*[@class='dataTables_scrollBody']/descendant::tbody";
        private static string buttonEdit = "XPath;//input[@name='edit']";
        private static string buttonAdd = "XPath;//input[@name='add']";
        private static string MSGBOX = "Xpath;//*[@class='msg-box']/descendant::p[1]";
        private static string buttonSubmit = "XPath;//input[@name='submit']";

        public virtual void SelectRelationshipCodeInList(string RelCode)
        {
            string RunTimeRadioButton = tableRelationshipCodesList + "/descendant::*[contains(text(),'" + RelCode + "')]/preceding-sibling::td/input";
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeRadioButton))
            {
                appHandle.ClickObjectViaJavaScript(RunTimeRadioButton);
            }
        }
        public virtual bool VerifyRelationshipCodesPageLoads()
        {
            return Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonAdd);
        }

        public virtual bool ClickOnEditButton()
        {
            bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonEdit))
            {
                appHandle.ClickObjectViaJavaScript(buttonEdit);
            }
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                Result = true;
            }
            return Result;
        }
        public virtual void EnterRelationshipCodeOptions(string strRelCodeOptionsPipedelimited)
        {

            if(!string.IsNullOrEmpty(strRelCodeOptionsPipedelimited))
            {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(strRelCodeOptionsPipedelimited);
            }
        } 
         public virtual bool VerifyMessageInTableConfigurationRelationshipCodesPage(string sMessage)
        {
           bool Result = false;
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(MSGBOX))
            {
                if (appHandle.GetObjectText(MSGBOX).Contains(sMessage))
                {
                    Result = true;
                }
            }

            return Result;
        }
         public virtual void ClickOnSubmitButton()
        {
            if(Profile7CommonLibrary.WaitForSpecifiedObjectExists(buttonSubmit))
            {
                appHandle.ClickObjectViaJavaScript(buttonSubmit);
            }
        }
    }
}