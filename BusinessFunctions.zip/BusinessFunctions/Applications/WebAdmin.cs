using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using System;
using System.Threading;
using System.Collections.Generic;
using OpenQA.Selenium;
using Profile7Automation.Libraries.Util;
using GTS_OSAF;
using System.Runtime.InteropServices;

namespace Profile7Automation.BusinessFunctions.Applications
{
    public class WebAdmin
    {
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        static string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        static string PWD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;

        public virtual void LogintoWebAdmin(String userID, String password)
        {
            Profile7CommonLibrary.KillProcessByProcessName("chrome");
            WebAdminPageFactory.WebAdminLoginPage.LaunchWebAdminURL();
            if (appHandle.GetTitle().Contains("User ID"))
            {

            }
            else
            {
                WebAdminPageFactory.WebAdminLoginPage.FilloginDetailsWebAdmin(userID, password);
                WebAdminPageFactory.WebAdminLoginPage.SubmitPage();

            }
            if (WebAdminPageFactory.WebAdminLoginPage.VerifyWebAdminHomePageLoads())
            {
                //Report.Pass("WebAdmin application is Logged in successfully.", "Login Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("WebAdmin application is not Logged in successfully.", "Login Screen Fail", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB), true);
            }
        }

        public virtual void login_specified_application(string ApplicationName)
        {
            this.LogintoWebAdmin(UID, PWD);
        }
        /// <summary>
        /// This method can be used if create_user method is used to create user in WebAdmin
        /// </summary>
        /// <param name="UserName"></param>
        public virtual void LoginWebAdminWithNewUserCredential(string UserName, string password = "")
        {
            Profile7CommonLibrary.KillProcessByProcessName("chrome");
            string pwd = Data.Get("GLOBAL_WEBADMIN_USER_PASSWORD");
            WebAdminPageFactory.WebAdminLoginPage.LaunchWebAdminURL();
            WebAdminPageFactory.WebAdminLoginPage.FilloginDetailsWebAdmin(UserName, pwd);
            WebAdminPageFactory.WebAdminLoginPage.SubmitPage();
            if (WebAdminPageFactory.WebAdminLoginPage.VerifyMSGToResetPassword())
            {
                Report.Info(Data.Get("You must change your password before you can proceed. Please choose a new password.") + " is displayed to change password for the new created user.", "newuserpassword", "true", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("You must change your password before you can proceed. Please choose a new password.") + " is not displayed to change password for the new created user.", "newuserpasswordFail", "true", appHandle, true);
            }
            if (!string.IsNullOrEmpty(password))
            {
                WebAdminPageFactory.WebAdminLoginPage.FillResetPasswordDetailsWebAdmin(pwd, password);
            }
            else
            {
                WebAdminPageFactory.WebAdminLoginPage.FillResetPasswordDetailsWebAdmin(pwd, PWD);
            }
            WebAdminPageFactory.WebAdminLoginPage.SubmitPage();
            if (WebAdminPageFactory.WebAdminLoginPage.VerifyResetPasswordMessage())
            {
                Report.Pass("Password is  changed successfully.", "Password Reset Success", "true", appHandle);
                if (!string.IsNullOrEmpty(password))
                {
                    WebAdminPageFactory.WebAdminLoginPage.FilloginDetailsWebAdmin(UserName, password);
                }
                else
                {
                    WebAdminPageFactory.WebAdminLoginPage.FilloginDetailsWebAdmin(UserName, PWD);
                }
                WebAdminPageFactory.WebAdminLoginPage.SubmitPage();
                if (WebAdminPageFactory.WebAdminLoginPage.VerifyWebAdminHomePageLoads())
                {
                    Report.Pass("WebAdmin application is Logged in successfully using new user credentials.", "Login Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                }
                else
                {
                    Report.Fail("WebAdmin application is not Logged in successfully using new user credentials.", "Login Screen Fail", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB), true);
                }
            }
            else
            {
                Report.Fail("Password Reset is not successful.", "Password Reset Failed", appHandle, true);
            }

        }

        public virtual void WebAdminResetPassword(string Password, string NewPassword)
        {
            Report.Info("Enter Reset Password details");
            WebAdminPageFactory.WebAdminLoginPage.FillResetPasswordDetailsWebAdmin(Password, NewPassword);
            WebAdminPageFactory.WebAdminLoginPage.SubmitPage();
            WebAdminPageFactory.WebAdminLoginPage.VerifyResetPasswordMessage();
            Report.Info("Reset Password details completed");
        }

        public virtual String CreateUser(string[] UserCredentials)
        {
            Report.Info("Create User");
            string UserID;
            WebAdminPageFactory.WebAdminMasterPage.NavigateToCreateUserPage();
            UserID = WebAdminPageFactory.WebAdminMasterPage.FillNewUserDetailsWebAdmin(UserCredentials);
            return UserID;
        }
        /// <summary>
        /// It creates UserID with out any input arguments.
        /// </summary>
        /// <returns></returns>
        public virtual string Create_User(string userclassname = "SCA User Class", bool CreateNewUserOnUserExists = false)
        {
            string UserID = "";
            bool newUserCreated = false;
            string existmessage = Data.Get("GLOBAL_RECORD_ALREADY_EXIST_MESSAGE");
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            UserID = WebAdminPageFactory.UserAddPage.GenerateRandomUserID();
            WebAdminPageFactory.UserAddPage.ClickOnAddButton();
            WebAdminPageFactory.UserAddPage.EnterUserDetails(UserID, userclassname);
            WebAdminPageFactory.UserAddPage.ClickOnSubmitbutton();
            WebAdminPageFactory.UserAddPage.EnterAgentAuthorization();
            WebAdminPageFactory.UserAddPage.ClickOnAgentAuthorizationSubmitbutton();
            WebAdminPageFactory.WebAdminLoginPage.VerifyWebAdminHomePageLoads();
            if (WebAdminPageFactory.UserAddPage.VerifyUserCreationSuccess(UserID)
            &&
            WebAdminPageFactory.UserAddPage.VerifyIfUserIDExistsInUsersList(UserID))
            {

                Report.Pass(UserID + " is created successfully.", "usercreate", "true", appHandle);
            }
            else
            {
                if (CreateNewUserOnUserExists)
                {
                    do
                    {
                        WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
                        UserID = WebAdminPageFactory.UserAddPage.GenerateRandomUserID();
                        WebAdminPageFactory.UserAddPage.ClickOnAddButton();
                        WebAdminPageFactory.UserAddPage.EnterUserDetails(UserID, userclassname);
                        WebAdminPageFactory.UserAddPage.ClickOnSubmitbutton();
                        WebAdminPageFactory.UserAddPage.EnterAgentAuthorization();
                        WebAdminPageFactory.UserAddPage.ClickOnAgentAuthorizationSubmitbutton();
                        if (Profile7CommonLibrary.CheckTextAvailableInPage(existmessage))
                        {
                            newUserCreated = true;
                            break;
                        }


                    }
                    while (newUserCreated == false);
                    if (WebAdminPageFactory.UserAddPage.VerifyUserCreationSuccess(UserID)
           &&
           WebAdminPageFactory.UserAddPage.VerifyIfUserIDExistsInUsersList(UserID))
                    {

                        Report.Pass(UserID + " is created successfully.", "usercreate", "true", appHandle);
                    }
                    else
                    {
                        Report.Fail(UserID + " is not created successfully.", "usercreateFail", "true", appHandle, true);
                    }
                }
                else
                {
                    Report.Fail(UserID + " is not created successfully.", "usercreateFail", "true", appHandle, true);
                }
            }
            return UserID;
        }
        public virtual string CreateUserIDWithExistingUserID(string UserID, string userclassname = "SCA")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            WebAdminPageFactory.UserAddPage.ClickOnAddButton();
            WebAdminPageFactory.UserAddPage.EnterUserDetails(UserID, userclassname);
            WebAdminPageFactory.UserAddPage.ClickOnSubmitbutton();
            WebAdminPageFactory.UserAddPage.VerifyRecordExistsMessage();
            string NewUserID = this.Create_User();
            return NewUserID;
        }
        public virtual void SelectUserModifyUserDetails(string UserID)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            WebAdminPageFactory.UserAddPage.SelectUSerIDfromUserList(UserID);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
            WebAdminPageFactory.UserAddPage.SelectBranchCode();
            WebAdminPageFactory.UserAddPage.EnterPasswords();
            WebAdminPageFactory.UserAddPage.ClickOnSubmitbutton();
            WebAdminPageFactory.UserAddPage.EnterAgentAuthorization();
            WebAdminPageFactory.UserAddPage.ClickOnAgentAuthorizationSubmitbutton();
            WebAdminPageFactory.UserAddPage.VerifyUserModificationSuccess(UserID);
        }
        public virtual String CreateUserWithExistingUserID(string[] UserCredentials)
        {
            Report.Info("Create User with existing User ID");
            WebAdminPageFactory.WebAdminMasterPage.NavigateToCreateUserPage();
            string NewUserID = WebAdminPageFactory.WebAdminMasterPage.FillExistingUserDetailsWebAdmin(UserCredentials);
            return NewUserID;
        }

        public virtual void SelectUSerIDfromUserList(string NewUserID)
        {
            Report.Info("Select UserID from User List");
            WebAdminPageFactory.WebAdminMasterPage.SelectUSerIDfromUserList(NewUserID);
        }

        public virtual void ModifyUserDetails(string[] UserCredentials)
        {
            Report.Info("Verify the status : Active and Modify the User Details ");
            WebAdminPageFactory.WebAdminMasterPage.ModifyUserDetails(UserCredentials);
        }

        public virtual void VerifyBranchCode(string BranchCode)
        {
            Report.Info("Verify the Branch Code is set to 0- Back Office");
            WebAdminPageFactory.WebAdminMasterPage.VerifyBranchCode(BranchCode);
        }

        public virtual void LogOutofWebAdmin()
        {
            WebAdminPageFactory.WebAdminLoginPage.WebAdminLogOut();
        }
        public virtual void logoff_specified_application(string ApplicationName)
        {
            this.LogOutofWebAdmin();
        }

        public virtual void NavigatetoUserClassMaintenancePage()
        {
            Report.Info("Navigate to User Class Maintenance Page(Security Configuration|User/Userclass Maintenance|UserClass Maintenance");
            WebAdminPageFactory.WebAdminMasterPage.NavigatetoUserClassMaintenancePage();
        }

        public virtual void ModifyUserClass(string UserClass, string OverallCashMaximum)
        {
            Report.Info("Modify an existing User Class");
            WebAdminPageFactory.WebAdminMasterPage.ModifyUserClass(UserClass, OverallCashMaximum);
        }

        public virtual void NavigatetoUserClassPage()
        {
            Report.Info("Navigate to User Class Page");
            WebAdminPageFactory.WebAdminMasterPage.NavigatetoUserClassPage();
        }

        public virtual void VerifyUserClass(string OverallMaximumAmount)
        {
            Report.Info("Verify the maximum amount for the userclass");
            WebAdminPageFactory.WebAdminMasterPage.VerifyUserClass(OverallMaximumAmount);
        }

        public virtual void NavigatetoProductFactoryPage()
        {
            Report.Info("Navigate to Product Factory Page (Product Factory|Products");
            WebAdminPageFactory.WebAdminMasterPage.NavigatetoProductFactoryPage();
        }

        public virtual void VerifyProductGroupDropDown(string[] ProductGroup)
        {
            Report.Info("Verify that Product Group Dropdown displays Product Group from DepositClass when Product Class is selected as D- Deposit Accounts ");
            WebAdminPageFactory.WebAdminMasterPage.VerifyProductGroupDropDown(ProductGroup);
        }

        public virtual void CreateProductWithExistingRecord(string[] ProductDetails)
        {
            Report.Info("Verify That Record Already Exist is displayed while user tries to copy a product using existing sProductNumber.");
            WebAdminPageFactory.WebAdminMasterPage.CreateProductWithExistingRecord(ProductDetails);
        }

        public virtual void VerifyProduct(string sProductNumber)
        {
            Report.Info("Navigate to every pages at product level and verify those pages");
            WebAdminPageFactory.WebAdminMasterPage.VerifyProduct(sProductNumber);
        }

        public virtual void DeleteProduct(string[] ProductDetails)
        {
            Report.Info("Verify that User can delete a copied product from Profile WebAdmin");
            WebAdminPageFactory.WebAdminMasterPage.DeleteProduct(ProductDetails);
        }

        public virtual void ModifyLoanProduct(string[] ProductDetails)
        {

            Report.Info("Verify that User can delete a copied product from Profile WebAdmin");
            WebAdminPageFactory.WebAdminMasterPage.ModifyLoanProduct(ProductDetails);
        }

        public virtual void VerifyLoanProduct(string LoansProductNumber)
        {
            Report.Info("Verify that Loan Product Details in WebAdmin");
            WebAdminPageFactory.WebAdminMasterPage.VerifyLoanProduct(LoansProductNumber);
        }

        public virtual void NavigatetoInstitutionVariablePage()
        {
            Report.Info("Verify that User is able to Navigate to Institution Variable Page");
            WebAdminPageFactory.WebAdminMasterPage.NavigatetoInstitutionVariablePage();
        }

        public virtual void VerifyInstitutionVariablePage()
        {
            Report.Info("Verify that User is able to Navigate to Institution Variable Page");
            WebAdminPageFactory.WebAdminMasterPage.VerifyInstitutionVariablePage();
        }

        public virtual string Create_Package()
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string PackageName;
            string packageinput = "Test" + (string)appHandle.CreateRamdomData(FieldType.ALPHANUMERICS, 0, 0, 4);
            string priorityinput = appHandle.CreateRamdomData(FieldType.NUMERIC, 10, 999).ToString();
            string OfferStartDate = WebAdminPageFactory.WebAdminMasterPage.GetAppDate();
            string OfferEndDate = appHandle.CalculateNewDate(OfferStartDate, "Y", 2);
            string StatementCycle = "1MAE";

            string[] PackageDetails = { packageinput, packageinput, packageinput, priorityinput, OfferStartDate, OfferEndDate, StatementCycle };
            string PackageSuccessMessage = "Package Products have been created.";
            WebAdminPageFactory.WebAdminMasterPage.NavigateToPackagesPage();
            WebAdminPageFactory.WebAdminPackagesPage.ClickAddButton();
            WebAdminPageFactory.WebAdminPackageGeneralInformationPage.EnterPackageGeneralInformation(PackageDetails);
            WebAdminPageFactory.WebAdminPackageGeneralInformationPage.ClickSubmitButton();

            if (WebAdminPageFactory.WebAdminPackageGeneralInformationPage.CheckIfErrorMessageAppears())
            {
                do
                {
                    PackageName = WebAdminPageFactory.WebAdminPackageGeneralInformationPage.ReenterDataOnErrorMessage();
                    WebAdminPageFactory.WebAdminPackageGeneralInformationPage.ClickSubmitButton();
                }
                while (WebAdminPageFactory.WebAdminPackageGeneralInformationPage.CheckIfErrorMessageAppears());
            }
            else
            {
                PackageName = packageinput;
            }
            WebAdminPageFactory.WebAdminPackagesPage.CheckPackageSuccessMessage(PackageSuccessMessage);
            Report.Info(PackageName + " has been created successfully.");
            return PackageName;
        }

        public virtual string add_record_in_table_from_general_table_management(string TableName, string[] PackageGroupDetails)
        {
            string PackageGroupName = "";
            WebAdminPageFactory.WebAdminMasterPage.NavigateToGeneralTableManagementPage();
            WebAdminPageFactory.GeneralTableManagementPage.EnterTableName(TableName);
            WebAdminPageFactory.GeneralTableManagementPage.ClickOnSearchButton();
            WebAdminPageFactory.GeneralTableManagementPage.SelectPackageTableRadioButton(TableName);
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButton();
            Thread.Sleep(2000);
            WebAdminPageFactory.WebAdminPackageGroupsPage.ClickAddButton();
            string PackageGroup = PackageGroupDetails[0];
            string PackageGroupDescription = PackageGroupDetails[1];
            string NumberOfRequiredProducts = PackageGroupDetails[2];
            WebAdminPageFactory.AddPackageGroupsPage.EnterPackageGroupDetails(PackageGroupDetails);
            WebAdminPageFactory.AddPackageGroupsPage.ClickSubmitButton();

            if (WebAdminPageFactory.AddPackageGroupsPage.CheckIfErrorMessageAppears())
            {
                do
                {
                    PackageGroupName = WebAdminPageFactory.AddPackageGroupsPage.ReenterDataOnErrorMessage();
                    WebAdminPageFactory.AddPackageGroupsPage.ClickSubmitButton();
                }
                while (WebAdminPageFactory.AddPackageGroupsPage.CheckIfErrorMessageAppears());
            }
            else
            {
                PackageGroupName = PackageGroup;
            }

            if (WebAdminPageFactory.WebAdminPackageGroupsPage.CheckPackageGroupUpdated(PackageGroupName))
            {
                Report.Info(PackageGroupName + " is added in " + TableName);
            }
            return PackageGroupName;
        }


        //10/10/2018
        public virtual string enter_copy_product_definition_details(string sProductClassDropdown, string sProductGroupDropdown, string sStandardProductName, string CopyProductName, bool AddRelationship)
        {
            string sProductNumber = null;
            string systemdate = null;
            string startdate = null;
            string expirationdate = null;

            if ((sProductClassDropdown == null) || (sProductGroupDropdown == null) || (sStandardProductName == null))
            {
                Report.Fail("Wrong Arguments Passed to the function.", "Wrong Arguments Passed to the function", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                return sProductNumber;
            }

            sProductNumber = copy_product_without_offer(sProductClassDropdown, sProductGroupDropdown, sStandardProductName);

            if (sProductNumber == null)
            {
                Report.Fail("Copy Product Failed.", "Copy Product Failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                return null;
            }

            string[] standcopyfrom = sStandardProductName.Split('-');
            string copyfrom = standcopyfrom[0].Trim(' ');
            string copyto = standcopyfrom[1].Trim(' ');
            string CopiedProductname = sProductNumber + " - " + copyto;

            CopyProductName = CopyProductName + sProductNumber;

            systemdate = WebAdminPageFactory.WebAdminMasterPage.GetAppDate();
            startdate = appHandle.CalculateNewDate(systemdate, "Y", -2);
            expirationdate = appHandle.CalculateNewDate(systemdate, "Y", 10);

            bool msgchk = add_offer_webcsr_channel(CopiedProductname, CopyProductName, startdate, expirationdate);
            if (msgchk)
            {
                Report.Pass(sProductNumber + " - Product has been Offered to WebCSR.", "Product Offer to WebCSR Successful", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("Product has not been Offered to WebCSR.", "Product Offer to WebCSR is not Successful", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }

            msgchk = add_offer_webclient_channel(CopiedProductname, CopyProductName, startdate, expirationdate);
            if (msgchk)
            {
                Report.Pass(sProductNumber + " - Product has been Offered to WebClient.", "Product Offer to WebClient Successful", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("Product has not been Offered to WebClient.", "Product Offer to WebClient is not Successful", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }

            msgchk = add_offer_teller_channel(CopiedProductname, CopyProductName, startdate, expirationdate);
            if (msgchk)
            {
                Report.Pass(sProductNumber + " - Product has been Offered to Teller.", "Product Offer to Teller Successful", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("Product has not been Offered to Teller.", "Product Offer to Teller is not Successful", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }

            // bool msgchk1 = objProductOfferRelationshipPage.add_relationship_code_webcsr_channel(sProductClassDropdown, sProductGroupDropdown, sProductNumber);
            // if (msgchk1)
            // {
            //     Report.Pass("Successfully added the Relationship code in WebCSR channel.", "Relationship Modified successfully", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            //     //Report.Pass("Successfully addded the relationship code", "Product Offer to Teller Successful", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            // }
            // else
            // {
            //     Report.Fail("Failed to Add the Relationship code in WebCSR channel.", "Relationship Modified Failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            //     //Report.Fail("Product has not been Offered to Teller", "Product Offer to Teller is not Successful", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            // }

            // msgchk1 = objProductOfferRelationshipPage.add_relationship_code_webclient_channel(sProductClassDropdown, sProductGroupDropdown, sProductNumber);
            // if (msgchk1)
            // {
            //     Report.Pass("Successfully added the Relationship code in WebClient channel.", "Relationship Modified successfully", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            //     //Report.Pass("Successfully addded the relationship code", "Product Offer to Teller Successful", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            // }
            // else
            // {
            //     Report.Fail("Failed to Add the Relationship code in WebClient channel.", "Relationship Modified Failed", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            //     //Report.Fail("Product has not been Offered to Teller", "Product Offer to Teller is not Successful", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            // }

            // objWebAdminProductFactoryPage.get_product(sProductClassDropdown, sProductGroupDropdown, sProductNumber);
            // objWebAdminProductsGeneralPage.set_description_field_value(CopyProductName);
            // if (!sProductClassDropdown.Equals(Data.Get("GLOBAL_CUSTOMER_CLASS")))
            // {
            //     objWebAdminProductsGeneralPage.set_start_date_field_value(startdate);
            // }
            // objWebAdminProductsGeneralPage.select_submit_button();
            return sProductNumber;
        }

        public virtual string copy_product_without_offer(string ProductClassDropdown, string ProductGroupDropdown, string StandardProductName)
        {
            string sProductNumber = null;
            string[] standcopyfrom = StandardProductName.Split('-');
            string copyfrom = standcopyfrom[0].Trim(' ');
            string copyto = standcopyfrom[1].Trim(' ');
            WebAdminPageFactory.WebAdminProductFactoryPage.SearchProduct(ProductClassDropdown, ProductGroupDropdown);
            WebAdminPageFactory.WebAdminProductFactoryPage.SelectProductFromProductList(copyfrom);
            sProductNumber = WebAdminPageFactory.WebAdminProductCopyPage.CopyProductDetails(copyto);
            return sProductNumber;
        }

        //10/10/2018
        public virtual bool add_offer_webcsr_channel(string CopiedProductname, string CopyProductName, string startdate, string expirationdate)
        {
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.NavigatetoProductOfferConfigurationPage();
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SelectChannel(Data.Get("GLOBAL_PRODUCT_OFFER_CHANNEL_WEBCSR"));
            appHandle.SyncPage();
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickAdd();
            bool ProductAdd = WebAdminPageFactory.WebAdminAddProductOfferPage.OfferProduct(CopiedProductname, CopyProductName, startdate, expirationdate);
            return ProductAdd;
        }
        public virtual bool add_offer_webclient_channel(string CopiedProductname, string CopyProductName, string startdate, string expirationdate)
        {
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.NavigatetoProductOfferConfigurationPage();
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SelectChannel(Data.Get("GLOBAL_PRODUCT_OFFER_CHANNEL_WEBCLIENT"));
            appHandle.SyncPage();
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickAdd();
            bool ProductAdd = WebAdminPageFactory.WebAdminAddProductOfferPage.OfferProduct(CopiedProductname, CopyProductName, startdate, expirationdate);
            return ProductAdd;
        }
        public virtual bool add_offer_teller_channel(string CopiedProductname, string CopyProductName, string startdate, string expirationdate)
        {
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.NavigatetoProductOfferConfigurationPage();
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SelectChannel(Data.Get("GLOBAL_PRODUCT_OFFER_CHANNEL_TELLER"));
            appHandle.SyncPage();
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickAdd();
            bool ProductAdd = WebAdminPageFactory.WebAdminAddProductOfferPage.OfferProduct(CopiedProductname, CopyProductName, startdate, expirationdate);
            return ProductAdd;
        }
        internal void CloseBrowser()
        {
            WebAdminPageFactory.WebAdminMasterPage.CloseBrowser();
        }
        /// <summary>
        /// This method is used to restore user
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.RestoreUserId();
        /// </example>
        public void RestoreUserId(string sUserId)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.SecurityConfigurationTab, AdministrationCenterPage.SecurityConfigUserClassMaintenanceLink);
                WebAdminPageFactory.UserListPage.SelectSpecifiedUser(sUserId);
                bool bcheck = WebAdminPageFactory.UserListPage.clickOnRestoreButtonAndVerifySuccessMsg();
                if (bcheck == true)
                    Report.Pass("The user has been restored", "RestoreUserId", "True");
                else
                    Report.Fail("The order was not placed", "RestoreUserId", "True");
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

        /// <summary>
        /// To create a new Service Fee plan.
        /// <param name="lstservicedetails"></param>
        /// lstservicedetails.Add(PlanParametersPage.txtSericeFeePlan + "|field"); ' for Service fee plan name - random name is created in Bussiness function and same is returned as output
        /// lstservicedetails.Add(PlanParametersPage.drpPlanType + "|dropdown|Credit Plan - Usage Credits");
        /// lstservicedetails.Add(PlanParametersPage.chkConvertAmountFields + "|checkbox|on");
        /// lstservicedetails.Add(PlanParametersPage.chkDailyFeeSubjecttoRegulationDD + "|checkbox|off");
        /// <returns>string</returns>
        /// <example>string srvfeeplan = CreateServiceFeePlan(lstservicedetails)</example>
        public virtual string CreateServiceFeePlan(List<string> lstservicedetails)
        {
            string srvfeeplan = null;
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.TableConfigServiceFeePlansLink);
                WebAdminPageFactory.ServiceFeePlanListPage.ClickOnAddServiceFeePlanButton();

                string[] arrserplnDetails = new string[3];
                for (int i = 0; i < lstservicedetails.Count; i++)
                {
                    arrserplnDetails = appHandle.SplitString(lstservicedetails[i], "|"); //separator
                    switch (arrserplnDetails[1].ToUpper())
                    {
                        case "FIELD":
                            if (arrserplnDetails[0].Equals(PlanParametersPage.txtSericeFeePlan))
                            {
                                srvfeeplan = appHandle.CreateRamdomData(FieldType.ALPHANUMERICS, 10000, 99999, 5).ToString();
                                WebAdminPageFactory.PlanParametersPage.SetEditValue(arrserplnDetails[0], srvfeeplan);
                            }
                            else
                                WebAdminPageFactory.PlanParametersPage.SetEditValue(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "DROPDOWN":
                            WebAdminPageFactory.PlanParametersPage.SelectDropdownValue(arrserplnDetails[0], arrserplnDetails[2]);
                            break;
                        case "CHECKBOX":
                            if (arrserplnDetails[2].ToUpper() == "ON")
                                WebAdminPageFactory.PlanParametersPage.SelectCheckboxOn(arrserplnDetails[0]);
                            else
                                WebAdminPageFactory.PlanParametersPage.SelectCheckboxOff(arrserplnDetails[0]);
                            break;
                    }
                }
                Report.Info("New Service Fee Plan Details entered.", "servicefee", "True", appHandle);
                WebAdminPageFactory.PlanParametersPage.ClickOnAddServiceFeePlanSubmitButton();
                bool bcheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_SERVICEFEE_CREATED_MSG"));
                if (bcheck)
                    Report.Pass("New Service Fee Plan Created successfully.", "sfee", "True", appHandle);
                else
                    Report.Fail("failed to create Service Fee Plan", "sfee", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return srvfeeplan;
        }

        /// <summary>
        /// To create a new Service Fee plan by copying it from an exisiing service fee plan in Profile WebAdmin..
        /// <param name="CopyFromFeePlan"></param> ' Fee Plan to be copied
        /// <param name="CopyFromEffectiveDate"></param> ' existing fee effective date
        /// <param name="CopyToEffectiveDate"></param> ' new effective date
        /// <returns>string</returns>
        /// <example>string srvfeeplan = CopyServiceFeePlan(CopyFromFeePlan,CopyFromEffectiveDate,CopyToEffectiveDate)</example>
        public virtual string CopyServiceFeePlan(string CopyFromFeePlan, string CopyFromEffectiveDate, string CopyToEffectiveDate)
        {
            string srvfeeplan = null;
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.TableConfigServiceFeePlansLink);
                bool bchk = WebAdminPageFactory.ServiceFeePlanListPage.CheckServiceFeePlanExistsinActionTable(CopyFromFeePlan);
                if (bchk == false)
                    Report.Fail("Service Fee Plan does not exist in the Table", "sfee", "True", appHandle);
                else
                {
                    WebAdminPageFactory.ServiceFeePlanListPage.SelectFeePlanFromFeePlanTable(CopyFromFeePlan);
                    WebAdminPageFactory.ServiceFeePlanListPage.ClickOnCopyServiceFeePlanButton();
                    srvfeeplan = appHandle.CreateRamdomData(FieldType.ALPHANUMERICS, 10000, 99999, 5).ToString();
                    WebAdminPageFactory.CopyServiceFeePlanPage.SetEditValue(CopyServiceFeePlanPage.txtCopyTo, srvfeeplan);
                    WebAdminPageFactory.CopyServiceFeePlanPage.SetEditValue(CopyServiceFeePlanPage.txtEffectiveDate, CopyToEffectiveDate);
                    Report.Info("Service Fee Plan Details entered.", "servicefee", "True", appHandle);
                    WebAdminPageFactory.CopyServiceFeePlanPage.ClickOnSubmitCopyServiceFeePlanButton();
                    bool bcheck = (WebAdminPageFactory.ServiceFeePlanListPage.VerifyMessageInPlanFeesPage(Data.Get("GLOBAL_SERVICE_FEE_PLAN_COPIED_MSG")) || WebAdminPageFactory.ServiceFeePlanListPage.VerifyMessageInPlanFeesPage("Effective Date must be the same as or after the system date."));
                    if (bcheck)
                        Report.Pass("Service Fee Plan copy message validated successfully.", "sfee", "True", appHandle);
                    else
                        Report.Fail("failed to copy Service Fee Plan", "sfee", "True", appHandle);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return srvfeeplan;
        }

        /// <summary>
        /// Navigate To Service Fee Plan Effective Date List Page for given service fee plan in Profile WebAdmin.
        /// <param name="SerFeePlan"></param> 'Serive Fee Plan
        /// <returns></returns>
        /// <example>NavigateToServiceFeePlanEffectiveDateListPage(SerFeePlan)</example>
        public virtual void NavigateToServiceFeePlanEffectiveDateListPage(string SerFeePlan)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.TableConfigServiceFeePlansLink);
                bool bchk = WebAdminPageFactory.ServiceFeePlanListPage.CheckServiceFeePlanExistsinActionTable("Service Fee Plan;" + SerFeePlan);
                if (bchk == false)
                    Report.Fail("Service Fee Plan does not exist in the Table", "sfee", "True", appHandle);
                else
                {
                    WebAdminPageFactory.ServiceFeePlanListPage.SelectServiceFeePlaninActionTable(SerFeePlan);
                    WebAdminPageFactory.ServiceFeePlanListPage.ClickOnEditServiceFeePlanButton();
                    bool bcheck = WebAdminPageFactory.ServiceFeePlanEffectDateListPage.CheckEditServiceFeePlanEffectiveDateExists();
                    if (bcheck)
                        Report.Pass("Navigated to Service Fee Plan Effective Date List Page.", "sfee", "True", appHandle);
                    else
                        Report.Fail("failed to Navigated to Service Fee Plan Effective Date List Page", "sfee", "True", appHandle);
                }

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to delete  specified rate schedule
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.DeleteRateSchedule();
        /// </example>
        public virtual void DeleteRateSchedule(string sRateScheduleName)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.RateSchedulesLink);
                WebAdminPageFactory.RateScheduleListPage.SelectSpecifiedRateScheduleName(sRateScheduleName);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnDeleteButton();
                WebAdminPageFactory.WebAdminMasterPage.ClickOkButton();
                bool bCheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage("The rate schedule has been deleted.");
                if (bCheck == true)
                    Report.Pass("Successfully deleted rate schedule", "DeleteRateSchedule", "True");
                else
                    Report.Info("Failed to delete rate schedule", "DeleteRateSchedule", "True");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used to delete  Rate OfIndex By EffectiveDate
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.DeleteRatesOfIndexByEffectiveDate();
        /// </example>
        public virtual void DeleteRatesOfIndexByEffectiveDate(string sIndexName, string sEffectiveDate)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.InterestIndexesLink);
                WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(sIndexName);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnRatesButton();
                WebAdminPageFactory.IndexEffectiveDatesListPage.SelectEffectiveDateForIndex(sEffectiveDate);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnDeleteButton();
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                bool bCheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage("Rates for index " + sIndexName + " have been deleted.");
                if (bCheck == true)
                {
                    Report.Pass("Successfully deleted the rate of index", "DeleteRatesOfIndexByEffectiveDate", "True");
                }
                else
                {
                    Report.Fail("Failed to delete rate of index", "DeleteRatesOfIndexByEffectiveDate", "True");
                }
            }

            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This function is used to Add a Relationship Code.
        /// <param name="AccountClass"></param> 'Deposit or Loan account class
        /// <param name="RelationshipDetails"></param>
        /// RelationshipDetails.Add(RelationshipCodePage.txtRelationshipCode + "|field|kk"); 'Value to relationship code.Enter only letter apha for deposit relationship code and two digit numeric for loan relationship code. if this parameter is null then Method will generate Appropriate relationship code.
        /// RelationshipDetails.Add(RelationshipCodePage.txtRelationshipCodeDescription + "|field|kktest"); 'value to Description field
        /// RelationshipDetails.Add(RelationshipCodePage.txtLegalTitleDescription + "|field|lekktest"); 'value to Legal Title Description field
        /// RelationshipDetails.Add(RelationshipCodePage.txtNR4RecipientType + "|field|1");'value to NR4 Recipient Code field
        /// RelationshipDetails.Add(RelationshipCodePage.drpFDIC370ORCCode + "|dropdown|SGL - Single accounts");
        /// RelationshipDetails.Add(RelationshipCodePage.drpFDICBeneficiaryTypeCode + "|dropdown|I - IRA");
        /// RelationshipDetails.Add(RelationshipCodePage.drpTaxRecipientCode + "|dropdown|05 - Trust");'value toTax Recipient Code field
        /// <param name="ColName"></param>
        /// string ColName = "Row No;Description;Maximum cif;minimum cif;Fdic Relationship code;customer type;customer sub-type;customer product;Suffix;SS;Primary Owner;Bureau Report Relation;Direct Liability;SignatureCard"; 'specify columns names to which the values has to be entered.
        /// <param name="RoleDetails"></param> 'List to define roles to relationship code.
        /// RoleDetails.Add("1;test1;2;;;PERSON - Personal;INDV - Individual;0 - Personal;suftes;on;off;on;on;on");'Enter values against the Column names as passed in ColName string
        /// RoleDetails.Add("2;test1;2;1;;PERSON - Personal;INDV - Individual;0 - Personal;;on;on;on;off;on");'if column value is not needed then pass blank value - ex (PERSON - Personal;INDV - Individual;0 - Personal) -> (PERSON - Personal;;0 - Personal)
        /// RoleDetails.Add("3;test1;2;1;CUS - Custodian;PERSON - Personal;INDV - Individual;0 - Personal;suftes;on;;off;on;on");
        /// <returns>string</returns>
        /// <example>string Rcode = AddRelationshipCode(Data.Get("GLOBAL_LOAN_ACCOUNTCLASS"), RelationshipDetails, ColName, RoleDetails)</example>
        public virtual string AddRelationshipCode(string AccountClass, List<string> RelationshipDetails, string ColNames, List<string> RoleDetails)
        {
            string Rno = null;
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.TableConfigRelationshipCodesLink);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                string[] arrreplnDetails = new string[3];
                for (int i = 0; i < RelationshipDetails.Count; i++)
                {
                    arrreplnDetails = WebAdminPageFactory.WebAdminMasterPage.SplitString(RelationshipDetails[i], "|"); //separator
                    switch (arrreplnDetails[1].ToUpper())
                    {
                        case "FIELD":
                            {
                                if (arrreplnDetails[0].Equals(RelationshipCodePage.txtRelationshipCode) && (arrreplnDetails[2] == "" || arrreplnDetails[2] == null))
                                {
                                    if (AccountClass == Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"))
                                        Rno = WebAdminPageFactory.WebAdminMasterPage.CreateRamdomData(FieldType.NUMERIC, 10, 99, 2).ToString();
                                    else if (AccountClass == Data.Get("GLOBAL_LOAN_ACCOUNTCLASS"))
                                        Rno = WebAdminPageFactory.WebAdminMasterPage.CreateRamdomData(FieldType.ALPHABETS, 10, 99, 2).ToString();
                                    else
                                        Report.Fail("Invalid Account Class.", "flase");
                                    WebAdminPageFactory.RelationshipCodePage.SetEditValue(arrreplnDetails[0], Rno);
                                }
                                else
                                {
                                    WebAdminPageFactory.RelationshipCodePage.SetEditValue(arrreplnDetails[0], arrreplnDetails[2]);
                                    if (arrreplnDetails[0].Equals(RelationshipCodePage.txtRelationshipCode))
                                        Rno = arrreplnDetails[2];
                                }
                            }
                            break;
                        case "DROPDOWN":
                            WebAdminPageFactory.RelationshipCodePage.SelectDropdownValue(arrreplnDetails[0], arrreplnDetails[2]);
                            break;
                    }
                }
                WebAdminPageFactory.RelationshipCodePage.EnterRoleDetailsinRelationshipCodeTable(ColNames, RoleDetails);
                Report.Info("Relationship Code Details entered.", "rcode", "True", appHandle);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                bool bValue = WebAdminPageFactory.WebAdminMasterPage.CheckObjectExists(RelationshipCodePage.lblRecordExistsMgs);
                if (bValue)
                {
                    do
                    {
                        if (AccountClass == Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"))
                            Rno = WebAdminPageFactory.WebAdminMasterPage.CreateRamdomData(FieldType.NUMERIC, 10, 99, 2).ToString();
                        else if (AccountClass == Data.Get("GLOBAL_LOAN_ACCOUNTCLASS"))
                            Rno = WebAdminPageFactory.WebAdminMasterPage.CreateRamdomData(FieldType.ALPHABETS, 10, 99, 2).ToString();
                        else
                            Report.Fail("Invalid Account Class.", "flase");
                        WebAdminPageFactory.RelationshipCodePage.SetEditValue(RelationshipCodePage.txtRelationshipCode, Rno);
                        WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                        bValue = WebAdminPageFactory.WebAdminMasterPage.CheckObjectExists(RelationshipCodePage.lblRecordExistsMgs);
                    } while (bValue);
                }
                bool bcheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_RELATIONSHIP_CODE_CREATED_SUCCESS_MSG"));
                if (bcheck)
                    Report.Pass("Successfully created relationship code.", "rcode", "True", appHandle);
                else
                    Report.Fail("Failed to create the relationship code.", "rcode", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return Rno;
        }

        /// <summary>
        /// This function is used to modify a Relationship Code.
        /// <param name="RelationshipCode"></param> 'Deposit or Loan account class
        /// <param name="RelationshipDetails"></param>
        /// RelationshipDetails.Add(RelationshipCodePage.txtRelationshipCodeDescription + "|field|kktest"); 'value to Description field
        /// RelationshipDetails.Add(RelationshipCodePage.txtLegalTitleDescription + "|field|lekktest"); 'value to Legal Title Description field
        /// RelationshipDetails.Add(RelationshipCodePage.txtNR4RecipientType + "|field|1");'value to NR4 Recipient Code field
        /// RelationshipDetails.Add(RelationshipCodePage.drpFDIC370ORCCode + "|dropdown|SGL - Single accounts");
        /// RelationshipDetails.Add(RelationshipCodePage.drpFDICBeneficiaryTypeCode + "|dropdown|I - IRA");
        /// RelationshipDetails.Add(RelationshipCodePage.drpTaxRecipientCode + "|dropdown|05 - Trust");'value toTax Recipient Code field
        /// <param name="ColName"></param>' optional
        /// string ColName = "Row No;Description;Maximum cif;minimum cif;Fdic Relationship code;customer type;customer sub-type;customer product;Suffix;SS;Primary Owner;Bureau Report Relation;Direct Liability;SignatureCard"; 'specify columns names to which the values has to be entered.
        /// <param name="RoleDetails"></param> 'List to define roles to relationship code. ' optional
        /// RoleDetails.Add("1;test1;2;;;PERSON - Personal;INDV - Individual;0 - Personal;suftes;on;off;on;on;on");'Enter values against the Column names as passed in ColName string
        /// RoleDetails.Add("2;test1;2;1;;PERSON - Personal;INDV - Individual;0 - Personal;;on;on;on;off;on");'if column value is not needed then pass blank value - ex (PERSON - Personal;INDV - Individual;0 - Personal) -> (PERSON - Personal;;0 - Personal)
        /// RoleDetails.Add("3;test1;2;1;CUS - Custodian;PERSON - Personal;INDV - Individual;0 - Personal;suftes;on;;off;on;on");
        /// <returns></returns>
        /// <example>ModifyRelationshipCode("1", RelationshipDetails, ColName, RoleDetails)</example>
        public virtual void ModifyRelationshipCode(string RelationshipCode, List<string> RelationshipDetails, string ColNames = null, List<string> RoleDetails = null)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.TableConfigRelationshipCodesLink);
                bool bval = false;
                bval = WebAdminPageFactory.RelationshipCodesListPage.CheckRelationshipCodeExistsinRelationshipCodesListTable(RelationshipCode);
                if (!bval)
                {
                    int i = 2;
                    bool bval1 = false;
                    do
                    {
                        bval1 = WebAdminPageFactory.RelationshipCodesListPage.CheckPageNoExistsinRelationshipCodesListPage(i.ToString());
                        if (bval1)
                        {
                            WebAdminPageFactory.RelationshipCodesListPage.ClickonPageNoinRelationshipCodesListPage(i.ToString());
                            bval = WebAdminPageFactory.RelationshipCodesListPage.CheckRelationshipCodeExistsinRelationshipCodesListTable(RelationshipCode);
                            if (bval)
                                break;
                            else
                                i++;
                        }
                    } while (bval1);
                }
                if (bval)
                {
                    WebAdminPageFactory.RelationshipCodesListPage.SelectRelationshipCodeinRelationshipCodesListTable(RelationshipCode);
                    Report.Info("Specified Relationship Code selected.", "rcode", "True", appHandle);
                    WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
                    string[] arrreplnDetails = new string[3];
                    for (int i = 0; i < RelationshipDetails.Count; i++)
                    {
                        arrreplnDetails = WebAdminPageFactory.WebAdminMasterPage.SplitString(RelationshipDetails[i], "|"); //separator
                        switch (arrreplnDetails[1].ToUpper())
                        {
                            case "FIELD":
                                WebAdminPageFactory.RelationshipCodePage.SetEditValue(arrreplnDetails[0], arrreplnDetails[2]);
                                break;
                            case "DROPDOWN":
                                WebAdminPageFactory.RelationshipCodePage.SelectDropdownValue(arrreplnDetails[0], arrreplnDetails[2]);
                                break;
                        }
                    }
                    if (ColNames != null && ColNames != "")
                    {
                        WebAdminPageFactory.RelationshipCodePage.EnterRoleDetailsinRelationshipCodeTable(ColNames, RoleDetails);
                        Report.Info("Relationship Code Details entered.", "rcode", "True", appHandle);
                    }
                    WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                    bool bcheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_RELATIONSHIP_CODE_UPDATED_SUCCESS_MSG"));
                    if (bcheck)
                        Report.Pass("Successfully modified the relationship code.", "rcode", "True", appHandle);
                    else
                        Report.Fail("Failed to modify the relationship code.", "rcode", "True", appHandle);
                }
                else
                    Report.Fail("Relationship code does not exist in Table.", "rcode", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to check whether specified Rate Schedule exists in WebAdmin.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.GetRateSchedule();
        /// </example>
        public virtual void GetRateSchedule(string sRateScheduleName)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.RateSchedulesLink);
                WebAdminPageFactory.RateScheduleListPage.SelectSpecifiedRateScheduleName(sRateScheduleName);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
                bool bCheck = WebAdminPageFactory.WebAdminMasterPage.CheckObjectExists(WebAdminMasterPage.SubmitButton);
                if (bCheck)
                {
                    Report.Pass("Successfully fetched the rate schedule", "RateScheduleName", "True", appHandle);
                }
                else
                {
                    Report.Fail("Unable to fetch the rate schedule", "RateScheduleName", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// To create a new transaction codes from existing transaction codes.This function returns the newly copied transaction code.
        /// <param name="TransactionCodeClass"></param>
        /// <param name="TransactionCodeGroup"></param>
        /// <param name="StandardTransactionCode"></param>
        /// <returns>string</returns>
        /// <example>string Tcode = CopyTransactionCode(TransactionCodeClass,TransactionCodeGroup,StandardTransactionCode)</example>
        public virtual string CopyTransactionCode(string TransactionCodeClass, string TransactionCodeGroup, string StandardTransactionCode)
        {
            string UpperRno = null;
            string Rno = null;
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.TableConfigTransactionCodesLink);
                WebAdminPageFactory.TransactionCodeConfigurationPage.SelectDropdownValue(TransactionCodeConfigurationPage.drpTransactionCodeClass, TransactionCodeClass);
                WebAdminPageFactory.TransactionCodeConfigurationPage.SelectDropdownValue(TransactionCodeConfigurationPage.drpTransactionCodeGroup, TransactionCodeGroup);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSearchButton();
                if (WebAdminPageFactory.TransactionCodeConfigurationPage.CheckTransactionCodeExistsinTransactionCodeTable(StandardTransactionCode))
                {
                    WebAdminPageFactory.TransactionCodeConfigurationPage.SelectTransactionCodeinTransactionCodeTable(StandardTransactionCode);
                    Report.Info("Specified Transaction Code selected.", "Tcode", "True", appHandle);
                    WebAdminPageFactory.WebAdminMasterPage.ClickOnCopyButton();
                    Rno = WebAdminPageFactory.WebAdminMasterPage.CreateRamdomData(FieldType.ALPHABETS, 1000, 9999, 4).ToString();
                    UpperRno = Rno.ToUpper();
                    WebAdminPageFactory.TransactionCodeCopyPage.SetEditValueinCoptToField(UpperRno);
                    WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                    if (WebAdminPageFactory.TransactionCodeCopyPage.CheckTransactionCodeExistsMgsinCopyTransactionCodePage(UpperRno))
                    {
                        do
                        {
                            Rno = WebAdminPageFactory.WebAdminMasterPage.CreateRamdomData(FieldType.ALPHABETS, 1000, 9999, 4).ToString();
                            UpperRno = Rno.ToUpper();
                            WebAdminPageFactory.TransactionCodeCopyPage.SetEditValueinCoptToField(UpperRno);
                            WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                        } while (WebAdminPageFactory.TransactionCodeCopyPage.CheckTransactionCodeExistsMgsinCopyTransactionCodePage(UpperRno));
                    }
                    if (WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_TRANSACTION_CODE_COPIED_MSG")))
                        Report.Pass("Successfully copied the Transaction code.", "Tcode", "True", appHandle);
                    else
                        Report.Fail("Failed to copy the transaction code.", "Tcode", "True", appHandle);
                }
                else
                    Report.Fail("Specified Transaction Code does not exist.", "Tcode", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return UpperRno;
        }

        /// <summary>
        /// To Navigate To Spcified Transaction Code.
        /// <param name="TransactionCodeClass"></param>
        /// <param name="TransactionCodeGroup"></param>
        /// <param name="StandardTransactionCode"></param>
        /// <returns></returns>
        /// <example>NavigateToSpcifiedTransactionCode(TransactionCodeClass,TransactionCode,TransactionCodeGroup)</example>
        public virtual void NavigateToSpcifiedTransactionCode(string TransactionCodeClass, string TransactionCode, string TransactionCodeGroup = null)
        {
            string Tcode = TransactionCode.ToUpper();
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.TableConfigTransactionCodesLink);
                WebAdminPageFactory.TransactionCodeConfigurationPage.SelectDropdownValue(TransactionCodeConfigurationPage.drpTransactionCodeClass, TransactionCodeClass);
                if (TransactionCodeGroup != null && (TransactionCodeGroup.Trim()) != "")
                    WebAdminPageFactory.TransactionCodeConfigurationPage.SelectDropdownValue(TransactionCodeConfigurationPage.drpTransactionCodeGroup, TransactionCodeGroup);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSearchButton();
                if (WebAdminPageFactory.TransactionCodeConfigurationPage.CheckTransactionCodeExistsinTransactionCodeTable(Tcode))
                {
                    WebAdminPageFactory.TransactionCodeConfigurationPage.SelectTransactionCodeinTransactionCodeTable(Tcode);
                    Report.Info("Specified Transaction Code selected.", "Tcode", "True", appHandle);
                    WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
                    if (WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Tcode))
                        Report.Info("Successfully Navigated to Transaction code.");
                    else
                        Report.Fail("Failed to Navigate to Transaction code.", "Tcode", "True", appHandle);
                }
                else
                    Report.Fail("Specified Transaction Code does not exist.", "Tcode", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used to modify a Transaction Code.
        /// <param name="TransactionCodeClass"></param>
        /// <param name="TransactionCodeGroup"></param>
        /// <param name="StandardTransactionCode"></param>
        /// <param name="lstPOFlddetails"></param>
        /// lstPOFlddetails.Add(ProcessingOptionsPage.txtCustomerActivityOptionsStatementDesc   + "|field|CD Increase W/H Prior Yr"); 
        /// lstPOFlddetails.Add(ProcessingOptionsPage.cbkCustomerActivityOptionsSkipReversalsWithinBillingPeriod   + "|checkbox|on");
        /// lstPOFlddetails.Add(ProcessingOptionsPage.cbkCustomerActivityOptionsSkipStatementPrint   + "|checkbox|off");
        /// lstPOFlddetails.Add(ProcessingOptionsPage.drpCustomerActivityOptionsStatementExtractDetailCategory   + "|dropdown|ADVANCES");
        /// lstPOFlddetails.Add(ProcessingOptionsPage.drpCustomerActivityOptionsStatementPrintOption   + "|dropdown|No Fields");
        /// <param name="TabName"></param>' optional ' if you wont pass any Tab name, by default it will enter details in Processing Options Page
        /// <param name="bSameTcodeUpdates"></param> 'By default method will search transaction code and will navigate to Processing Options Page and If this parm is true it wont search and navigate to Transaction Code.this pram should be passed as true when you need to update the same transaction in diffrent Tab
        /// <returns></returns>
        /// <example>ModifyTransactionCode("D - Deposit", "CCDB", lstPOFlddetails, "CD - Certificates" )</example>
        /// <example>ModifyTransactionCode("D - Deposit", "CCDB", lstPOFlddetails)</example>
        /// <param name="lstMisFlddetails"></param>
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.txtTransactionDescription + "|field|CD Decr Uncollected Int Accrued"); 
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.txtField1Table + "|field|Teller Comment"); 
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.txtField2Description + "|field|Teller Comment"); 
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.chkField4Required + "|checkbox|on");
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.chkField2Required + "|checkbox|off");
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.drpGroup + "|dropdown|Certificates");
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.drpField1Name + "|dropdown|Teller Comment");
        /// lstMisFlddetails.Add(MiscellaneousFieldsPage.drpField2Name + "|dropdown|Teller Comment");
        /// <example>ModifyTransactionCode("D - Deposit", "CCDB", lstMisFlddetails, "CD - Certificates","Miscellaneous Fields", true )</example> '  when you need to update the same transaction for second time in diffrent Tab
        /// <param name="lstPCOGFlddetails"></param>
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.txtProcessingControlOptionsTransactionDesc  + "|field|CD Increase W/H Prior Yr"); 
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.cbkProcessingControlOptionsProcessInterestRateBuydown  + "|checkbox|on");
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.cbkProcessingControlOptionsPromptForBudgetCode  + "|checkbox|off");
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.drpProcessingControlOptionsConsiderMMDALimitations  + "|dropdown|MMDA third party checks");
        /// lstPCOGFlddetails.Add(ProcessingControlOptionsPage.drpProcessingControlOptionsGroup  + "|dropdown|Certificates");
        /// <example>ModifyTransactionCode("D - Deposit", "CCDB", lstPCOGFlddetails, "CD - Certificates","Processing Control Options", true )</example>
        public virtual void ModifyTransactionCode(string TransactionCodeClass, string TransactionCode, List<string> lstTcodedetails, string TransactionCodeGroup = null, string TabName = null, bool bSameTcodeUpdates = false)
        {
            try
            {
                if (!bSameTcodeUpdates)
                    Application.WebAdmin.NavigateToSpcifiedTransactionCode(TransactionCodeClass, TransactionCode, TransactionCodeGroup);
                else
                {
                    WebAdminPageFactory.TransactionCodeConfigurationPage.SelectTransactionCodeinTransactionCodeTable(TransactionCode);
                    WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
                }
                if (TabName != null && TabName != "")
                {
                    switch (TabName.ToUpper())
                    {
                        case "PROCESSING OPTIONS":
                            WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(WebAdminMasterPage.tabProcessingOptions);
                            WebAdminPageFactory.ProcessingOptionsPage.EnterDetailsinProcessingOptionsPage(lstTcodedetails);
                            break;
                        case "MISCELLANEOUS FIELDS":
                            WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(WebAdminMasterPage.tabMiscellaneousFields);
                            WebAdminPageFactory.MiscellaneousFieldsPage.EnterDetailsinMiscellaneousFieldsPage(lstTcodedetails);
                            break;
                        case "PROCESSING CONTROL OPTIONS":
                            WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(WebAdminMasterPage.tabProcessingControlOptions);
                            WebAdminPageFactory.ProcessingControlOptionsPage.EnterDetailsinProcessingControlOptionsPage(lstTcodedetails);
                            break;
                    }
                }
                else
                    WebAdminPageFactory.ProcessingOptionsPage.EnterDetailsinProcessingOptionsPage(lstTcodedetails);

                Report.Info("Transaction Code Details entered.", "tcode", "True", appHandle);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                if (WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                    Report.Pass("Successfully modified the transaction code.", "tcode", "True", appHandle);
                else
                    Report.Fail("Failed to modify the transaction code.", "tcode", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To authorize the transaction code for a specified user class or all 'All User classes' in WebAdmin.
        /// <param name="TransactionCodeClass"></param>
        /// <param name="TransactionCodeGroup"></param>
        /// <param name="TransactionCode"></param>
        /// <param name="UserClsandUserAction"></param>'"userClass;Book-on/off;NoBook-on/off;Reversal-on/off"
        /// <returns></returns>
        /// <example>AuthorizeTransactionCode(TransactionCodeClass,TransactionCode,UserClsandUserAction,TransactionCodeGroup)</example>
        /// <example>AuthorizeTransactionCode("D - Deposit", "CCDB", "SCA;on;on;on", "CD - Certificates")</example>
        /// <example>AuthorizeTransactionCode("D - Deposit", "CCDB", "All Userclasses;on", "CD - Certificates")</example>
        /// <example>AuthorizeTransactionCode("D - Deposit", "CCDB", "MGR;on;off;on", "CD - Certificates")</example>
        public virtual void AuthorizeTransactionCode(string sTransactionCodeClass, string sTransactionCode, String sUserClsandUserAction, string sTransactionCodeGroup = null)
        {
            string Tcode = sTransactionCode.ToUpper();
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.TableConfigTransactionCodesLink);
                WebAdminPageFactory.TransactionCodeConfigurationPage.SelectDropdownValue(TransactionCodeConfigurationPage.drpTransactionCodeClass, sTransactionCodeClass);
                if (sTransactionCodeGroup != null && (sTransactionCodeGroup.Trim()) != "")
                    WebAdminPageFactory.TransactionCodeConfigurationPage.SelectDropdownValue(TransactionCodeConfigurationPage.drpTransactionCodeGroup, sTransactionCodeGroup);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSearchButton();
                if (WebAdminPageFactory.TransactionCodeConfigurationPage.CheckTransactionCodeExistsinTransactionCodeTable(Tcode))
                {
                    WebAdminPageFactory.TransactionCodeConfigurationPage.SelectTransactionCodeinTransactionCodeTable(Tcode);
                    Report.Info("Specified Transaction Code selected.", "ATcode", "True", appHandle);
                    WebAdminPageFactory.WebAdminMasterPage.ClickOnAuthorizeButton();
                    string[] arrUclsDtls = WebAdminPageFactory.WebAdminMasterPage.SplitString(sUserClsandUserAction, ";");
                    if (arrUclsDtls[0].ToUpper() == "ALL USERCLASSES")
                        WebAdminPageFactory.TransactionCodeAuthorizationPage.SelectAllUserclassesCheckbox(arrUclsDtls[1]);
                    if (arrUclsDtls[0].ToUpper() != "ALL USERCLASSES" && arrUclsDtls.Length >= 2)
                        WebAdminPageFactory.TransactionCodeAuthorizationPage.SelectBookCheckboxforUserClass(arrUclsDtls[0], arrUclsDtls[1]);
                    if (arrUclsDtls[0].ToUpper() != "ALL USERCLASSES" && arrUclsDtls.Length >= 3)
                        WebAdminPageFactory.TransactionCodeAuthorizationPage.SelectNoBookCheckboxforUserClass(arrUclsDtls[0], arrUclsDtls[2]);
                    if (arrUclsDtls[0].ToUpper() != "ALL USERCLASSES" && arrUclsDtls.Length == 4)
                        WebAdminPageFactory.TransactionCodeAuthorizationPage.SelectReversalCheckboxforUserClass(arrUclsDtls[0], arrUclsDtls[3]);
                    Report.Info("User Class Details updated.", "ATcode", "True", appHandle);
                    WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                    if (WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                        Report.Pass("Successfully authorized the transaction code for specified user class.", "ATcode", "True", appHandle);
                    else
                        Report.Fail("Failed to authorize the transaction code for specified user class.", "ATcode", "True", appHandle);
                }
                else
                    Report.Fail("Specified Transaction Code does not exist.", "Tcode", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used to add the interest index.The function returns the newly  created interest index.
        /// <param name="IndexType"></param>
        /// <param name="lstAddIndxdetails"></param>'should not pass Interest Index, Description and Index Type and random name is created in method for Interest Index.
        /// lstAddIndxdetails.Add(IndexAddPage.txtNoofDaystoAverageRate + "|field|15");
        /// lstAddIndxdetails.Add(IndexAddPage.cbkDataItemAuthorization + "|checkbox|on");
        /// lstAddIndxdetails.Add(IndexAddPage.cbkLaggingMarketIndex + "|checkbox|off");
        /// lstAddIndxdetails.Add(IndexAddPage.drpTieredIndexType  + "|dropdown|C -Cumulative");
        /// <returns>string</returns>
        /// <example>string srvfeeplan = CreateInterestIndex(IndexType,lstservicedetails)</example>
        public virtual string CreateInterestIndex(string IndexType, List<string> lstAddIndxdetails = null)
        {
            string Index = null;
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.InterestIndexesLink);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                Index = appHandle.CreateRamdomData(FieldType.ALPHANUMERICS, 10000, 99999, 6).ToString();
                WebAdminPageFactory.IndexAddPage.SetEditValue(IndexAddPage.txtInterestIndex, Index);
                WebAdminPageFactory.IndexAddPage.SetEditValue(IndexAddPage.txtInterestIndexDescription, Index);
                WebAdminPageFactory.IndexAddPage.SelectDropdownValue(IndexAddPage.drpIndexType, IndexType);
                if (lstAddIndxdetails != null)
                    WebAdminPageFactory.IndexAddPage.EnterDetailsinIndexAddPage(lstAddIndxdetails);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                if (WebAdminPageFactory.IndexAddPage.CheckIndexExistsMessage())
                {
                    do
                    {
                        Index = appHandle.CreateRamdomData(FieldType.ALPHANUMERICS, 10000, 99999, 6).ToString();
                        WebAdminPageFactory.IndexAddPage.SetEditValue(IndexAddPage.txtInterestIndex, Index);
                        WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                    } while (WebAdminPageFactory.IndexAddPage.CheckIndexExistsMessage());
                }
                bool bcheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_INDEX_CREATED_MSG"));
                if (bcheck)
                    Report.Pass("Successfully created the new interest index - " + Index + ".", "IID", "True", appHandle);
                else
                    Report.Fail("Failed to create the new interest index", "IID", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return Index;
        }

        /// <summary>
        /// This function is used to modify the rates of a specified Rate Schedule in WebAdmin.
        /// <param name="RateScheduleName"></param>
        /// <param name="EffectiveDate"></param>
        /// <param name="MinimumBalance"></param>
        /// <param name="lstRateCredentials"></param>'
        /// lstAddIndxdetails.Add("7;3.75000");'--> ("Days;Rate")
        /// lstAddIndxdetails.Add("90;4.85000");' Pass like this if you need Modify a rate for a specified Day value
        /// lstAddIndxdetails.Add("345;5.85000;Add"); ' Pass like this if you need add a new rate in new row
        /// <returns></returns>
        /// <example>ModifyRatesOfRateSchedule("CD","01/01/2016","1000.00",lstRateCredentials)</example>
        public virtual void ModifyRatesOfRateSchedule(string RateScheduleName, string EffectiveDate, string MinimumBalance, List<string> lstRateCredentials)
        {
            try
            {
                string sysdate = WebAdminPageFactory.WebAdminMasterPage.GetAppDate();
                DateTime AppDate = Convert.ToDateTime(sysdate);
                DateTime EffDate = Convert.ToDateTime(EffectiveDate);
                int val = DateTime.Compare(EffDate, AppDate);
                if (val != -1)
                {
                    WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.RateSchedulesLink);
                    if (WebAdminPageFactory.RateScheduleListPage.CheckSpecifiedRateScheduleExists(RateScheduleName))
                    {
                        WebAdminPageFactory.RateScheduleListPage.SelectSpecifiedRateScheduleName(RateScheduleName);
                        WebAdminPageFactory.WebAdminMasterPage.ClickOnRatesButton();
                        if (WebAdminPageFactory.RateScheduleEffectiveDatesListPage.CheckSpecifiedEffectiveDateExists(EffectiveDate))
                        {
                            WebAdminPageFactory.RateScheduleEffectiveDatesListPage.SelectSpecifiedEffectiveDate(EffectiveDate);
                            WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
                            if (WebAdminPageFactory.RateScheduleEffectiveDateRateModifyPage.CheckSpecifiedMinimumBalanceExists(MinimumBalance))
                            {
                                WebAdminPageFactory.RateScheduleEffectiveDateRateModifyPage.SelectSpecifiedMinimumBalance(MinimumBalance);
                                WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
                                WebAdminPageFactory.RateScheduleEffectiveDateRateAddPage.AddandModifyRates(lstRateCredentials);
                                Report.Info("Modified Rate schedule Details.", "RT", "True", appHandle);
                                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                                if (WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_RATE_SCHEDULE_MODIFIED")))
                                    Report.Pass("Successfully updated rates of Rate Schedule '" + RateScheduleName + "'.", "RsD", "True", appHandle);
                                else
                                    Report.Fail("Failed to updated rates of Rate Schedule '" + RateScheduleName + "'.", "RsD", "True", appHandle);
                            }
                            else
                                Report.Fail("The specified Minimum Balance Value '" + MinimumBalance + "' does not exist for rate schedule '" + RateScheduleName + "'.", "Rtsch", "True", appHandle);
                        }
                        else
                            Report.Fail("The specified effective date '" + EffectiveDate + "' does not exist for rate schedule '" + RateScheduleName + "'.", "Rtsch", "True", appHandle);
                    }
                    else
                        Report.Fail("The specified rate schedule '" + RateScheduleName + "' does not exist.", "Rtsch", "True", appHandle);
                }
                else
                    Report.Fail("Effective date is not valid. Please check.", "Rtsch", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }


        /// <summary>
        ///  This function is used to find the user class name from the userclass maintenance page.
        /// <param name="UserClassName"></param>
        /// <returns></returns>
        /// <example>CheckUserClassinUserClassMaintenancePage("UserClassName")</example>
        public virtual bool CheckUserClassinUserClassMaintenancePage(string sUserClassName)
        {
            bool bCheck = false;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                WebAdminPageFactory.WebAdminMasterPage.NavigatetoUserClassMaintenancePage();
                bool blnUserClassListMsg = WebAdminPageFactory.UserClassListPage.ConfirmUserClassListPage();
                bCheck = WebAdminPageFactory.UserClassListPage.CheckUserclassfound(sUserClassName);
                if (bCheck)
                {
                    Report.Pass("User Class List page is found.", "True", appHandle);
                }
                else
                {
                    Report.Fail("User Class List page not Found", "True", appHandle);
                }
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return bCheck;
        }


        /// <summary>
        /// This function is used to get the number of links in profile report.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.GetReportLinksCount();
        /// </example>
        public virtual void GetReportLinksCount()
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                WebAdminPageFactory.ReportDetailPage.ClicktheLastRowImg();
                WebAdminPageFactory.ReportDetailPage.GetthePageNumberinReportDetailpage();
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to click on Tab and associated link of Tab in WebAdmin.
        /// <param name= "Tab Name"></param> ' "General","Interest" --> pass the Tab Name same as in application
        /// <param name= "Link"></param> ' Pass the Xpath of the link
        /// <returns></returns> 
        /// <example>ClickonTabinProductPage("General");</example>
        /// <example>ClickonTabinProductPage("Interest",WebAdminProductsCommonPage.RateDeterminationlnk);</example>
        public virtual void ClickonTabinProductPage(string sTabName, string sLink = null)
        {
            try
            {
                string TabName = WebAdminPageFactory.WebAdminMasterPage.GenerateXpathforTabs(sTabName);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnObject(TabName);
                if (sLink != null && sLink != "")
                {
                    WebAdminPageFactory.WebAdminMasterPage.ClickOnObject(sLink);
                }
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// To Enter Deatils in Specified Page
        /// <param name="lstdetails"></param>
        /// lstdetails.Add(DepositeGeneralPage.txtDescription + "|field|ProductName"); ' for Service fee plan name - random name is created in Bussiness function and same is returned as output
        /// lstdetails.Add(DepositeGeneralPage.drpCurrency + "|dropdown|INR - Indian Rupee");
        /// lstdetails.Add(DepositeGeneralPage.chkOriginalIssueDiscount + "|checkbox|off");
        /// lstdetails.Add(DepositeGeneralPage.chkAccountPurposeRequired + "|checkbox|on");
        /// <returns></returns>
        /// <example>EnterValuesInSpecifiedPage(lstdetails)</example>
        public virtual void EnterValuesInWebAdminSpecifiedPage(List<string> FieldValues)
        {
            try
            {
                foreach (string value in FieldValues)
                {
                    string[] temp = value.Split('|');

                    switch (temp[1].ToUpper())
                    {
                        case "FIELD":
                            WebAdminPageFactory.WebAdminMasterPage.SetFieldValue(temp[0], temp[2]);
                            break;
                        case "DROPDOWN":
                            WebAdminPageFactory.WebAdminMasterPage.SelectDropdownValue(temp[0], temp[2]);
                            break;
                        case "CHECKBOX":
                            WebAdminPageFactory.WebAdminMasterPage.SelectCheckBox(temp[0], temp[2]);
                            break;
                        case "RADIOBUTTON":
                            WebAdminPageFactory.WebAdminMasterPage.SetRadioButton(temp[0]);
                            break;
                        case "BUTTON":
                            WebAdminPageFactory.WebAdminMasterPage.ClickButton(temp[0]);
                            break;
                    }
                }
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// To Enter and update Deatils in Specified Page
        /// <param name="lstdetails"></param>
        /// lstdetails.Add(DepositeGeneralPage.txtDescription + "|field|ProductName"); ' for Service fee plan name - random name is created in Bussiness function and same is returned as output
        /// lstdetails.Add(DepositeGeneralPage.drpCurrency + "|dropdown|INR - Indian Rupee");
        /// lstdetails.Add(DepositeGeneralPage.chkOriginalIssueDiscount + "|checkbox|off");
        /// lstdetails.Add(DepositeGeneralPage.chkAccountPurposeRequired + "|checkbox|on");
        /// <param name="Message"></param>
        /// <returns></returns>
        /// <example>UpdateInformationInSpecifiedPage(lstdetails,Data.Get("GLOBAL_INFORMATION_UPDATED"))</example>
        public virtual void UpdateInformationInWebAdminSpecifiedPage(List<string> FieldValues, string message)
        {
            try
            {
                EnterValuesInWebAdminSpecifiedPage(FieldValues);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                bool bcheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(message);
                if (bcheck)
                    Report.Pass("Expected Result is coming.", "sf", "True", appHandle);
                else
                    Report.Fail("Not getting the Expected Result", "sf", "True", appHandle);

            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to Calculate New Date
        /// <param name= "startdate"></param> 
        /// <param name= "date param"></param> 
        /// <param name= "numberofDay"></param>
        /// <returns>New Date</returns> 
        /// <example>CalculateNewDate(startdate,dparam,numberofDay);</example>
        public virtual string CalculateNewDate(string startdate, string dparam, int numberofDay)
        {
            return WebAdminPageFactory.WebAdminMasterPage.CalculateDate(startdate, dparam, numberofDay);
        }

        /// <summary>
        /// This method is used to Calculate New Date
        /// <param name= "sRateschdulecredentials"></param> 
        /// <returns>string</returns> 
        /// <example>CreateRateSchedule(Months;Round to nearest 1/2;Select rate from term/balance tier);</example>
        public virtual string CreateRateSchedule(string Rateschdulecredentials)
        {
            string RateScheduleName = "";
            try
            {
                string[] Rateschdtls = null;
                int NumberOfElements = 0;
                if (Rateschdulecredentials != "")
                {
                    Rateschdtls = Rateschdulecredentials.Split(';');
                    NumberOfElements = Rateschdtls.Length;
                }
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.RateSchedulesLink);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                RateScheduleName = WebAdminPageFactory.RateScheduleAddPage.AddRateSchedule(Rateschdtls, NumberOfElements);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                bool bCheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_ADD_RATES_SCHDULE_SUCCESS_MSG"));
                if (bCheck)
                {
                    Report.Pass("Successfully created the new rate schedule", "CreateRateSchedule", "True", appHandle);
                }
                else
                {
                    Report.Fail("Unable to create the new rate schedule", "CreateRateSchedule", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return RateScheduleName;
        }

        /// <summary>
        /// This method is used to add rates to rate schedule
        /// <param name= "Ratecredentials"></param>
        /// Ratecredentials[0] = "TEST050"           ' Rate ScheduleName
        /// Ratecredentials(1) = "04/20/2010"        ' Effective Date
        /// Ratecredentials(2) = "10000.00"          ' Minimum Balance
        /// Ratecredentials(3) = "2:5"           	  ' Term1:Interest Rate1
        /// Ratecredentials(4) = "5:4"           	  ' Term2:Interest Rate2
        /// Ratecredentials(5) = "4:6"           	  ' Term3:Interest Rate3
        /// Ratecredentials(6) = "6:7"           	  ' Term4:Interest Rate4
        /// <returns></returns> 
        /// <example>AddRatesToRateSchedule(Ratecredentials);</example>
        public virtual void AddRatesToRateSchedule(string[] Ratecredentials)
        {
            try
            {
                string RateSchedule = Ratecredentials[0];
                string Effectivedate = Ratecredentials[1];
                string MinBalance = Ratecredentials[2];
                int CredCount = Ratecredentials.Length;
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.RateSchedulesLink);
                WebAdminPageFactory.RateScheduleListPage.SelectSpecifiedRateScheduleName(RateSchedule);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnRatesButton();
                WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                WebAdminPageFactory.RateScheduleEffectiveDateRateAddPage.AddRateScheduleEffectiveDate(Effectivedate, MinBalance, Ratecredentials);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                bool flag = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_ADD_RATES_RATE_SCHDULE_SUCCESS_MSG"));
                if (flag)
                {
                    Report.Pass("Successfully added rates to rate schedule", "AddedRatesToRateSchedule", "True", appHandle);
                }
                else
                {
                    Report.Fail("Failed to add rates to rate schedule", "AddedRatesToRateSchedule", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to Navigate to Product general page of specified product
        /// <param name= "sProductClassDropdown"></param> 
        /// <param name= "sProductGroupDropdown"></param> 
        /// <param name= "sProductNumber"></param>
        /// <returns></returns> 
        /// <example>GetProduct(GLOBAL_DEPOSIT_ACCT_CLASS,GLOBAL_CERTIFICATEOFDEPOSIT_GROUP, cdProdNumber3);</example>
        public virtual void GetProduct(string sProductClassDropdown, string sProductGroupDropdown, string sProductNumber)
        {
            if (WebAdminPageFactory.WebAdminProductsCommonPage.CheckProductNumberLoaded(sProductNumber)) { }
            else
            {
                WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
                WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClassDropdown, sProductGroupDropdown);
                WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();
                if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
                {
                    Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
                }
                WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            }
        }

        public virtual string GetApplicationDate()
        {
            string Date = WebAdminPageFactory.WebAdminMasterPage.GetAppDate();
            return Date;
        }

        /// <summary>
        /// This method is used to generate random number between specified range
        /// <param name= "min"></param> 
        /// <param name= "max"></param> 
        /// <returns>Integer</returns> 
        /// <example>RandomNumber(10,1000);</example>

        public int RandomNumber(int min, int max)
        {
            int genRand = 0;
            try
            {
                Random r = new Random();
                genRand = r.Next(min, max);

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return genRand;
        }

        /// <summary>
        /// This method is add new loan fee plan.
        /// <param name= List<string> LoanFeeDetails></param> 
        /// <param name= List<string> LoanFeePlanRules</param> 
        /// <param name= List<string> LoanFeeCalculationDetails</param>
        /// <param name= List<string> LoanFeeTransactionCodes</param>
        /// <returns></returns> 
        /// <example>AddNewLoanFeePLan(LoanFeeDetails,LoanFeePlanRules,LoanFeeCalculationDetails,LoanFeeTransactionCodes)</example>
        public virtual void AddNewLoanFeePLan(List<string> LoanFeeDetails, List<string> LoanFeePlanRules, List<string> LoanFeeCalculationDetails, List<string> LoanFeeTransactionCodes)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.lnkLoanFeePlans);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                EnterValuesInWebAdminSpecifiedPage(LoanFeeDetails);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnContinueButton();
                EnterValuesInWebAdminSpecifiedPage(LoanFeePlanRules);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnContinueButton();
                EnterValuesInWebAdminSpecifiedPage(LoanFeeCalculationDetails);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnContinueButton();
                EnterValuesInWebAdminSpecifiedPage(LoanFeeTransactionCodes);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnContinueButton();
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is add new loan fee plan.
        /// <param name= "Xpath"</param> 
        /// <param name= "sColumnValue"</param> 
        /// <param name= "sTabName"</param>
        /// <param name= List<string> EditLoanPlanDetails</param>
        /// <param name= "sExpectedMsg"</param>
        /// <returns></returns> 
        /// <example>EditLoanFeePLan(Xpath,sColumnValue,sTabName,EditLoanPlanDetails,sExpectedMsg)</example>
        public virtual void EditLoanFeePLan(string Xpath, string sColumnValue, string sTabName, List<string> EditLoanPlanDetails, string sExpectedMsg, bool bCheckbox = false)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectRadioButtonInTable(Xpath, sColumnValue);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
                string TabXpath = WebAdminPageFactory.WebAdminMasterPage.GenerateXpathforTabs(sTabName);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnObject(TabXpath);
                if (bCheckbox)
                    CheckCheckboxDisabled(LoanFeePlanRulesPage.cbkAssessFeeAtPayoff);
                EnterValuesInWebAdminSpecifiedPage(EditLoanPlanDetails);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(sExpectedMsg);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used to check checkbox status.
        /// <param name= "sCheckboxXpath"></param> 
        /// <returns>true/false</returns> 
        /// <example>WebCSRMasterPage.CheckCheckboxDisabled(sCheckboxXpath)<example>
        public virtual bool CheckCheckboxDisabled(string sCheckboxXpath)
        {
            bool CheckboxStatus = false;
            try
            {
                CheckboxStatus = WebAdminPageFactory.WebAdminMasterPage.VerifyCheckBoxUnchecked(sCheckboxXpath);
                if (CheckboxStatus)
                {
                    Report.Pass("Checkbox is disabled", "CheckCheckboxDisabled", "True", appHandle);
                }
                else
                {
                    Report.Fail("Checkbox is enabled", "CheckCheckboxDisabled", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged: " + e);
            }
            return CheckboxStatus;
        }

        /// <summary>
        /// This method is add new loan fee plan.
        /// <param name= "Xpath"</param> 
        /// <param name= "sColumnValue"</param> 
        /// <param name= "sTabName"</param>
        /// <param name= List<string> CopyLoanFeePlanDetails</param>
        /// <param name= "sExpectedMsg"</param>
        /// <returns></returns> 
        /// <example>CopyLoanFeePLan(Xpath,sColumnValue,CopyLoanFeePlanDetails,sExpectedMsg)</example>
        public virtual void CopyLoanFeePLan(string Xpath, string sColumnValue, List<string> CopyLoanFeePlanDetails, string sExpectedMsg = null)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectRadioButtonInTable(Xpath, sColumnValue);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnCopyButton();
                EnterValuesInWebAdminSpecifiedPage(CopyLoanFeePlanDetails);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }
        /// <summary>
        /// This method is add new loan fee plan.
        /// <param name= "Xpath"</param> 
        /// <param name= "sColumnValue"</param> 
        /// <param name= "AlertAction"</param>
        /// <param name= "sExpectedMsg"</param>
        /// <returns></returns> 
        /// <example>DeleteLoanFeePlan(Xpath,sColumnValue,AlertAction,sExpectedMsg)</example>
        public virtual void DeleteLoanFeePlan(string Xpath, string sColumnValue, string AlertAction, string sExpectedMsg = null)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectRadioButtonInTable(Xpath, sColumnValue);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnDeleteButton();
                WebAdminPageFactory.WebAdminMasterPage.ActionOnPopButton(AlertAction);

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is add Create New PaymentGrid.!-- 
        /// <param name= "sTableName"</param> 
        /// <param name= "PaymentGridValues"</param> 
        /// <param name= List<string> EnterPayments</param>
        /// <returns></returns> 
        /// <example>CreateNewPaymentGrid(sTableName,PaymentGridValues,EnterPayments)</example>
        public virtual void CreateNewPaymentGrid(string sTableName, List<string> PaymentGridValues, List<string> EnterPayments)
        {
            bool bCheck = false;
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectLinkinTab(AdministrationCenterPage.TableConfigTab, AdministrationCenterPage.lnkGeneralTableManagement);
                WebAdminPageFactory.WebAdminMasterPage.SetFieldValue(GeneralTableManagementPage.TableNameField, sTableName);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnObject(GeneralTableManagementPage.btnSeach);
                WebAdminPageFactory.WebAdminMasterPage.SelectRadioButtonInTable(GeneralTableManagementPage.TableList, sTableName);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                EnterValuesInWebAdminSpecifiedPage(PaymentGridValues);
                EnterValuesInWebAdminSpecifiedPage(EnterPayments);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                bCheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_PAYMENT_DUE_ACTION_GRID_CREATE_MSG"));
                if (bCheck)
                {
                    Report.Pass("Successfully created new payment grid", "CreateNewPaymentGrid", "True", appHandle);
                }
                else
                {
                    Report.Fail("Failed to create new payment grid", "CreateNewPaymentGrid", "True", appHandle);
                }

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This Function for Navigating to the Add Accrual User Definition List Page.
        /// </summary>
        /// <param name="string TableName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.NavigatetoAddAccrualUserExitDefinitionPage("string TableName");
        /// </example>
        public virtual void NavigatetoAddAccrualUserExitDefinitionPage(string TableName)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.NavigateToGeneralTableManagementPage();
                WebAdminPageFactory.GeneralTableManagementPage.EnterTableName(TableName);
                WebAdminPageFactory.GeneralTableManagementPage.ClickOnSearchButton();
                WebAdminPageFactory.GeneralTableManagementPage.SelectPackageTableRadioButton(TableName);
                WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButton();
                Thread.Sleep(2000);
                WebAdminPageFactory.AccrualUserExitDefinitionsListPage.ClickAddButton();
                bool blnConfirmedMsg = WebAdminPageFactory.AddAccrualUserExitDefinitionPage.ConfirmAddAccrualUserExitDefinitionPage();
                if (blnConfirmedMsg == true)
                    Report.Pass("Successfully navigated to Add Accrual User Exit Definition page", "blnConfirmedMsg", "True", appHandle);
                else
                    Report.Fail("Not navigated to the Add Accrual User Exit Definition page", "blnConfirmedMsg", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }


        /// <summary>
        /// This function is used for verify the Object is exists.
        /// </summary>
        /// <param name="string obj1"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.VerifytheObjectExists("string obj1");
        /// </example>

        public virtual bool ChecktheObjectExists(string Obj1)
        {
            bool output = false;
            try
            {
                output = WebAdminPageFactory.AddAccrualUserExitDefinitionPage.ChecktheObjectisExists(Obj1);
                if (output == true)
                    Report.Pass("Object exists in Page", "ChecktheObjectExists", "True", appHandle);
                else
                    Report.Fail("Object not exists in Page", "ChecktheObjectExists", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return output;
        }

        //Function for Clcik the cancel button.
        public virtual void ClickonCancelButton()
        {
            WebAdminPageFactory.WebAdminMasterPage.ClickOnCancelButton();
        }

        //Function for Clcik the Add button.
        public virtual void ClickonAddButton()
        {
            WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
        }

        //Function for Clcik the EDit button.
        public virtual void ClickonEditButton()
        {
            WebAdminPageFactory.AccrualUserExitDefinitionsListPage.ClickEditButton();
        }

        //Function for Clcik the Delete button.
        public virtual void ClickonDeleteButton()
        {
            WebAdminPageFactory.AccrualUserExitDefinitionsListPage.ClickDeleteButton();
        }

        /// <summary>
        /// This function is used for Add Accrual User Exit Definition Record.
        /// </summary>
        /// <param name="List<string> FieldsValues"></param>
        /// <param name="string tablename"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.AddBeneficiary("List<string> FieldsValues, string acctname, string acctnumber, string ExpectedMsg");
        /// </example>
        public virtual void AddAccrualUserExitDefinitionrecord(List<string> FieldsValues, string tableName, string Msg)
        {
            try
            {
                NavigatetoAddAccrualUserExitDefinitionPage(tableName);
                EnterValuesInWebAdminSpecifiedPage(FieldsValues);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                bool bcheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Msg);
                if (bcheck)
                    Report.Pass("Accrual Record Added Successfully", "UpdateInformation", "True", appHandle);
                else
                    Report.Fail("Accrual Record not Added Successfully", "UpdateInformation", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }


        //Function for click the pop up on browser.
        public virtual void ActionOnPopButton(bool ActionType, string msg = null)
        {
            try
            {
                if (msg != null)
                {
                    bool bPopUpTextVerify = PerformActionOnAlert(PopUpAction.Verify, msg);
                    if (bPopUpTextVerify)
                    {
                        Report.Info("Expected message is coming in Pop-up");
                    }
                    else
                    {
                        Report.Info("Expected not message is coming in Pop-up");
                    }
                }
                if (ActionType == true)
                {
                    appHandle.PerformActionOnAlert(PopUpAction.Accept);
                    Report.Pass("Ok Button is clicked", "ActionOnPopButton", "True", appHandle);
                }
                else
                {
                    appHandle.PerformActionOnAlert(PopUpAction.Decline);
                    Report.Pass("False button is clicked", "ActionOnPopButton", "True", appHandle);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        public virtual bool PerformActionOnAlert(PopUpAction PopUpAct, string PopUpText = "")
        {
            IWebDriver webDriver = (IWebDriver)appHandle.GetWebDriver();
            IAlert alert = null;
            bool bPopUpTextVerify = false;
            while (alert == null)
            {
                try
                {
                    alert = webDriver.SwitchTo().Alert();
                }
                catch (UnhandledAlertException e)
                {
                    alert = webDriver.SwitchTo().Alert();
                }
            }
            switch (PopUpAct)
            {
                case PopUpAction.Accept:
                    alert.Accept();
                    break;
                case PopUpAction.Decline:
                    alert.Dismiss();
                    break;
                case PopUpAction.Verify:
                    string sAlertText = alert.Text;
                    if (sAlertText.Equals(PopUpText))
                    {
                        bPopUpTextVerify = true;
                    }
                    else
                    {
                        bPopUpTextVerify = false;
                    }
                    break;
                case PopUpAction.SetText:
                    alert.SendKeys(PopUpText);
                    break;

            }
            return bPopUpTextVerify;
        }

        /// <summary>
        /// This function is used for verify the Object is disabled.
        /// </summary>
        /// <param name="string obj1"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.VerifytheObjectExists("string obj1");
        /// </example>

        public virtual bool CheckObjectisDisabled(string Obj1)
        {
            bool output = false;
            try
            {
                output = WebAdminPageFactory.AddAccrualUserExitDefinitionPage.ChecktheObjectisDisabled(Obj1);
                if (output == true)
                    Report.Pass("Object is disabled in Page", "CheckObjectisDisabled", "True", appHandle);
                else
                    Report.Fail("Object not exists in Page", "CheckObjectisDisabled", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return output;
        }


        /// <summary>
        /// This function is used for verify the expected message.
        /// </summary>
        /// <param name="string msg"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckSuccessMessage("string msg");
        /// </example>

        public virtual void CheckSuccessMessage(string msg)
        {
            try
            {
                bool output = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(msg);
                if (output == true)
                    Report.Pass("Expected Result is Exists in this page", "CheckSuccessMessage", "True", appHandle);
                else
                    Report.Fail("Expected Result is not exists", "CheckSuccessMessage", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }


        /// <summary>
        /// This method is used to select Radio Button in table.
        /// <param name= "tableXpath"></param> 
        /// <param name= "sColumnValue"></param>
        /// <returns></returns> 
        /// <example>WebCSRMasterPage.SelectRadioButtonInTable();<example>
        public virtual void SelecttheRadioButtoninTable(string tableXpath, string sColumnValue)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.SelectRadioButtonInTable(tableXpath, sColumnValue);
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

        /// <summary>
        /// This method is used to check value exists in specified data Table.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdmin.CheckspecifiedDataExistsinTable();
        /// </example>
        public virtual bool CheckspecifiedDataExistsinTable(string Refvalue, string TableName)
        {
            bool bCheck = false;
            try
            {
                bCheck = appHandle.CheckSpecifiedDataAvailableInTable(Refvalue, TableName);
                if (bCheck == true)
                    Report.Pass("Expected Data is available in Table", "CheckspecifiedDataExistsinTable", "True", appHandle);
                else
                    Report.Fail("Expected Data is not available in Table", "CheckspecifiedDataExistsinTable", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bCheck;
        }

        /// <summary>
        /// This method is used to check value not exists in specified data Table.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// WebAdmin.CheckspecifiedDatanotExistsinTable();
        /// </example>
        public virtual bool CheckspecifiedDatanotExistsinTable(string Refvalue, string TableName)
        {
            bool bCheck = false;
            try
            {
                bCheck = appHandle.CheckSpecifiedDataNotAvailableInTable(Refvalue, TableName);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bCheck;
        }


        /// <summary>
        /// This function is used for verify the Object is not exists.
        /// </summary>
        /// <param name="string obj1"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.ChecktheObjectnotExists("string obj1");
        /// </example>
        public virtual bool checktheobjectisnotexists(string obj1)
        {
            bool ObjStatus = false;
            try
            {
                ObjStatus = WebAdminPageFactory.WebAdminMasterPage.checkobjectisnotexists(obj1);
                if (ObjStatus == false)
                    Report.Pass("Object is not there", "checktheobjectisnotexixts", "True", appHandle);
                else
                    Report.Fail("Object is there", "checktheobjectisnotexixts", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return ObjStatus;
        }

        //Function for Click the continue button.
        public virtual void ClickonContinueButton()
        {
            WebAdminPageFactory.AddExemptionPlanParametersPage.ClickonContinue();
        }

        /// <summary>
        /// This function is used for Add the Exemption Plan.
        /// </summary>
        /// <param name="List<string> FieldsValues"></param>
        /// <param name="string tablename"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.AddBeneficiary("List<string> FieldsValues, string acctname, string acctnumber, string ExpectedMsg");
        /// </example>
        public virtual void AddEXemptionPlan(List<string> FieldsValues, string Msg)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.NavigateToAddExemptionPlanParametersPage();
                EnterValuesInWebAdminSpecifiedPage(FieldsValues);
                WebAdminPageFactory.AddCategoryItemsCategory1itemsPage.ClickSubmitButton();
                bool bcheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(Msg);
                if (bcheck)
                    Report.Pass("Exemption Plan Added Successfully", "UpdateInformation", "True", appHandle);
                else
                    Report.Fail("Exemption Plan not Added Successfully", "UpdateInformation", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }


        /// <summary>
        /// This Function for Navigating to respective User table page.
        /// </summary>
        /// <param name="string TableName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.NavigatetoUserTablePage("string TableName");
        /// </example>
        public virtual void NavigatetoUserTablePage(string TableName)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.NavigateToGeneralTableManagementPage();
                WebAdminPageFactory.GeneralTableManagementPage.EnterTableName(TableName);
                WebAdminPageFactory.GeneralTableManagementPage.ClickOnSearchButton();
                WebAdminPageFactory.GeneralTableManagementPage.SelectPackageTableRadioButton(TableName);
                WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButton();
                bool blnConfirmedMsg = WebAdminPageFactory.FeeScheduleParametersPage.ConfirmFeeScheduleParametersPage();
                if (blnConfirmedMsg == true)
                    Report.Pass("Successfully navigated to respective user table page", "blnConfirmedMsg", "True", appHandle);
                else
                    Report.Fail("Not Successfully navigated to respective user table page", "blnConfirmedMsg", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        //Function for Click the Table configuration Link.
        public virtual void ClickTableconfigurationLink()
        {
            WebAdminPageFactory.WebAdminMasterPage.ClickTableconfigurationLink();
            appHandle.SyncPage();
        }
        //Function for Click the tab in page.
        public virtual void ClicktheTab()
        {
            WebAdminPageFactory.WebAdminMasterPage.ClicktheTab(PlanParametersPage.btnFees);
            appHandle.SyncPage();
        }

        /// <summary>
        /// This function is used for Add the Plan Fees to Service Fee Plan.
        /// </summary>
        /// <param name="List<string> FieldsValues"></param>
        /// <param name="FeeCatagory"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebAdmin.AddPlanFeestoServiceFeePlan("List<string> FieldsValues, string FeeCatagory, string ExpectedMsg");
        /// </example>
        public virtual void AddPlanFeestoServiceFeePlan(List<string> FieldValues, string message)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.ClicktheTab(PlanParametersPage.btnFees);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                EnterValuesInWebAdminSpecifiedPage(FieldValues);
                WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
                bool bcheck = WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage(message);
                if (bcheck)
                    Report.Pass("Plan Fees Added to Service Fee Plan", "AddPlanFeestoServiceFeePlan", "True", appHandle);
                else
                    Report.Fail("Plan Fees not Added to Service Fee Plan", "AddPlanFeestoServiceFeePlan", "True", appHandle);

            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        //Function for Click on the Query Definitions button.
        public virtual void ClickQueryDefinitionsButton()
        {
            try
            {
                WebAdminPageFactory.PlanFeesPage.ClickQueryDefinitionsButton();
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        //Function for select the link.
        public virtual void SelecttheLink(string Linkname)
        {
            appHandle.Select_link(Linkname);
        }

        public virtual bool CheckSpecifiedDataAvailableInTable(string sTableHeaderXpath, string sTableBodyXpath, string sReferenceValues)
        {
            bool bflag = false;
            try
            {
                string[] refValues = sReferenceValues.Split(';');
                int refValueCount = (refValues.Length) - 1;
                List<int> lstColIndex = new List<int>();
                List<string> lstRefValue = new List<string>();
                string strExpValue = refValues[refValueCount];
                string strExpColumn = refValues[refValueCount - 1];
                IList<object> validRow = new List<object>();
                if (appHandle.IsObjectExists(sTableHeaderXpath))
                {
                    List<object> ColumnsInTable = appHandle.GetColumnInTable(sTableHeaderXpath);
                    IList<object> col = ((List<object>)ColumnsInTable);
                    appHandle.GetColumnIndexesFromColumnValues(refValues, lstColIndex, lstRefValue, col);
                    validRow = FindMatchingRows(sTableBodyXpath, lstColIndex, lstRefValue);
                    if (validRow.Count > 0)
                    {
                        bflag = true;
                        Report.Pass("Data found in specified table", "DataFound", "True", appHandle);
                    }
                    else
                    {
                        Report.Fail("Data not found in specified table", "DataFound", "True", appHandle);
                    }

                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
            return bflag;
        }

        private IList<object> FindMatchingRows(object oObjectTable, List<int> lstColIndex, List<string> lstRefValue, object oParentObject = null)
        {
            try
            {

                IWebElement element = (IWebElement)appHandle.FindElement(oObjectTable);
                IList<IWebElement> rows = element.FindElements(By.TagName("tr"));
                int rowCount = rows.Count;
                bool bMatch = true;
                List<int> newlstColIndex = new List<int>();
                IList<object> matchingElement = new List<object>();
                for (int i = 0; i < rows.Count; i++)
                {
                    bMatch = true;
                    for (int j = 0; j < lstColIndex.Count; j++)
                    {
                        string columnValue = appHandle.GetObjectText("XPATH;.//td[" + lstColIndex[j] + "]", rows[i]);
                        if (columnValue == null)
                        {
                            bMatch = false;
                            break;
                        }
                        else if (columnValue.ToUpper().Trim() != lstRefValue[j].ToUpper().Trim())
                        {
                            bMatch = false;
                            break;
                        }
                    }
                    if (bMatch)
                        matchingElement.Add(rows[i]);
                }
                return matchingElement;
            }
            catch (NoSuchElementException e)
            {
                Report.Fail("FindMatchingRows: " + oObjectTable + " not found in the current page." + e);
                return null;
            }
        }

        public virtual void SelectRadioBySearchInMultiplePages(string sTableHeader, string sTablebody, string sRefValues)
        {
            bool bCheck = false;
            string[] arrValues = sRefValues.Split(';');
            string sColumnValue = arrValues[1];
            string length = WebAdminPageFactory.WebAdminMasterPage.CountPageLength();
            int j = int.Parse(length);
            while (bCheck == false && j > 0)
            {
                bCheck = CheckSpecifiedDataAvailableInTable(sTableHeader, sTablebody, sRefValues);
                if (bCheck)
                {
                    WebAdminPageFactory.WebAdminMasterPage.SelectRadioButtonInTable(WebAdminMasterPage.tblTableRecordsAction, sColumnValue);
                    break;
                }
                j = j - 1;
                string sPageLinkXpath = WebAdminPageFactory.WebAdminMasterPage.GenerateXpathForPageLinks(j);
                WebAdminPageFactory.WebAdminMasterPage.ClickObject(sPageLinkXpath);

            }
        }

        public virtual bool CheckSpecifiedDataNotAvailableInTable(string sTableHeaderXpath, string sTableBodyXpath, string sReferenceValues)
        {
            bool bflag = false;
            try
            {
                string[] refValues = sReferenceValues.Split(';');
                int refValueCount = (refValues.Length) - 1;
                List<int> lstColIndex = new List<int>();
                List<string> lstRefValue = new List<string>();
                string strExpValue = refValues[refValueCount];
                string strExpColumn = refValues[refValueCount - 1];
                IList<object> validRow = new List<object>();
                if (appHandle.IsObjectExists(sTableHeaderXpath))
                {
                    List<object> ColumnsInTable = appHandle.GetColumnInTable(sTableHeaderXpath);
                    IList<object> col = ((List<object>)ColumnsInTable);
                    appHandle.GetColumnIndexesFromColumnValues(refValues, lstColIndex, lstRefValue, col);
                    validRow = FindMatchingRows(sTableBodyXpath, lstColIndex, lstRefValue);
                    if (validRow.Count > 0)
                    {
                        Report.Fail("Data available in specified table", "DataFound", "True", appHandle);
                    }
                    else
                    {
                        bflag = true;
                        Report.Pass("Data not available in specified table", "DataFound", "True", appHandle);
                    }

                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
            return bflag;
        }

        public virtual void CheckObjectEnabledTrue(string sObjectXpath)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.CheckObjectStatus(sObjectXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
        }

        public virtual void ClickOnObject(string sObjectXpath)
        {
            try
            {
                WebAdminPageFactory.WebAdminMasterPage.ClickObject(sObjectXpath);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
        }
        public virtual string EnterCopyProductDefinitionDetails(string sProductClass, string sProductGroup, string sProductNumberToBeCopied, bool ProductOffer = false, string ChannelstoBeOfferedPipeDelimited = "")
        {
            string Product = "";
            bool flag = false;
            string NewProdNumber = "";
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumberToBeCopied);
            Report.Info(sProductClass + " and " + sProductGroup + " are selected . Base Product i.e. Product number which need to Copied : " + sProductNumberToBeCopied + " is selected in Products Table .", "prodcopy1", "True", appHandle);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnCopyButton();
            NewProdNumber = appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999, 4) + "";
            WebAdminPageFactory.WebAdminProductCopyPage.EnterProductCopyDetails(NewProdNumber);
            Report.Info(NewProdNumber + " data is entered in Product Copy page.", "prodcopyData", "True", appHandle);
            WebAdminPageFactory.WebAdminProductCopyPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.WebAdminProductCopyPage.IsProdExistsMsg())
            {
                do
                {
                    NewProdNumber = appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999, 4) + "";
                    WebAdminPageFactory.WebAdminProductCopyPage.EnterProductCopyDetails(NewProdNumber);
                    WebAdminPageFactory.WebAdminProductCopyPage.ClickOnSubmitButton();
                    if (!WebAdminPageFactory.WebAdminProductCopyPage.IsProdExistsMsg())
                    {
                        flag = true;
                        Report.Info(NewProdNumber + " data is entered in Product Copy page as earlier product number was existing.", "prodcopyDataexist", "True", appHandle);
                        break;
                    }
                    else
                    {
                        continue;
                    }

                }
                while (flag == false);

            }
            if (WebAdminPageFactory.WebAdminProductCopyPage.VerifyMessageProductCopyPage(Data.Get("The product has been copied.")))
            {
                appHandle.ScrollToObject("Xpath;//td[text()='" + NewProdNumber + "'][1]");
                Report.Pass(sProductNumberToBeCopied + " is copied to a new product number " + NewProdNumber, "copied", "True", appHandle);
            }
            else
            {
                this.EnterCopyProductDefinitionDetails(sProductClass, sProductGroup, sProductNumberToBeCopied, ProductOffer, ChannelstoBeOfferedPipeDelimited = "");
                Report.Fail(sProductNumberToBeCopied + " is failed to copy to a new product number " + NewProdNumber, "copied", "True", appHandle);
            }
            if (ProductOffer)
            {
                if (string.IsNullOrEmpty(ChannelstoBeOfferedPipeDelimited))
                {
                    string[] arr = new string[2];
                    arr[0] = Data.Get("WebCSR");
                    arr[1] = Data.Get("Teller");
                    for (int a = 0; a < arr.Length; a++)
                    {

                        WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Product Offers"));
                        if (WebAdminPageFactory.WebAdminProductOfferConfigurationPage.WaitUntilProductOfferConfigurationPageLoads())
                        {
                            Report.Info("Product Offer Configuration is loaded successfully.", "prodofferconfigurationpageload", "True", appHandle);
                        }
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SelectChannel(arr[a]);
                        Report.Info(arr[a] + " channel is selected.", "channelselected", "True", appHandle);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SelectProductFromProductListTable(sProductNumberToBeCopied);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnEditButton();
                        string CopiedFromProdDetails = WebAdminPageFactory.WebAdminProductOfferConfigurationPage.GetStandardProdDetails(sProductNumberToBeCopied);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickONCancelButton();
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickAdd();
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.EnterDetailsAddProductOffer(NewProdNumber, CopiedFromProdDetails);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnSubmitButton();
                        if (WebAdminPageFactory.WebAdminProductOfferConfigurationPage.VerifyMessageProductOfferConfigurationPage(Data.Get("Product has been added to the offer table.")))
                        {
                            if (appHandle.IsObjectExists("XPath;//td[text()='" + NewProdNumber + "'][1]"))
                            {
                                appHandle.ScrollToObject("XPath;//td[text()='" + NewProdNumber + "'][1]");
                                Report.Pass(NewProdNumber + " Product is offered for " + arr[a] + " application.", "ProdOffer" + a + "", "True", appHandle);

                            }
                            else
                            {
                                Report.Fail(NewProdNumber + " Product is not offered for " + arr[a] + " application.", "ProdOffer" + a + "", "True", appHandle, true);
                            }
                        }
                        else
                        {
                            Report.Fail(NewProdNumber + " Product is not offered for " + arr[a] + " application.", "ProdOffer" + a + "", "True", appHandle, true);
                        }
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SelectProductFromProductListTable(sProductNumberToBeCopied);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnRelationshipButton();
                        string RelationsShipDetails = WebAdminPageFactory.WebAdminProductOfferConfigurationPage.GetRelationshipsDetailsFromProductToBeCopied(sProductNumberToBeCopied);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickONCancelButton();
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SetRelationshipForSpecificedProductNumber(NewProdNumber, RelationsShipDetails);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnSubmitButton();
                        if (WebAdminPageFactory.WebAdminProductOfferConfigurationPage.VerifyMessageProductOfferConfigurationPage(Data.Get("The relationship(s) for the product type has been modified.")))
                        {
                            Report.Pass("Relationship for " + NewProdNumber + " Product type is modified successfully. " + arr[a] + " application.", "RelationModified" + a + "", "True", appHandle);
                        }
                        else
                        {
                            Report.Fail("Relationship for " + NewProdNumber + " Product type is modified successfully. ", "RelationModified" + a + "", "True", appHandle, true);
                        }
                    }
                }
                else
                {
                    string[] arr1 = ChannelstoBeOfferedPipeDelimited.Split('|');
                    for (int b = 0; b < arr1.Length; b++)
                    {
                        WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Product Offers"));
                        if (WebAdminPageFactory.WebAdminProductOfferConfigurationPage.WaitUntilProductOfferConfigurationPageLoads())
                        {
                            Report.Info("Product Offer Configuration is loaded successfully.", "prodofferconfigurationpageload", "True", appHandle);
                        }
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SelectChannel(arr1[b]);
                        Report.Info(arr1[b] + " channel is selected.", "channelselected", "True", appHandle);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnEditButton();
                        string CopiedFromProdDetails = WebAdminPageFactory.WebAdminProductOfferConfigurationPage.GetStandardProdDetails(sProductNumberToBeCopied);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickONCancelButton();
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickAdd();
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.EnterDetailsAddProductOffer(NewProdNumber, CopiedFromProdDetails);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnSubmitButton();
                        if (WebAdminPageFactory.WebAdminProductOfferConfigurationPage.VerifyMessageProductOfferConfigurationPage(Data.Get("Product has been added to the offer table.")))
                        {
                            if (appHandle.IsObjectExists("XPath;//td[text()='" + NewProdNumber + "'][1]"))
                            {
                                appHandle.ScrollToObject("XPath;//td[text()='" + NewProdNumber + "'][1]");
                                Report.Pass(NewProdNumber + " Product is offered for " + arr1[b] + " application.", "ProdOffer" + b + "", "True", appHandle);

                            }
                            else
                            {
                                Report.Fail(NewProdNumber + " Product is not offered for " + arr1[b] + " application.", "ProdOffer" + b + "", "True", appHandle, true);
                            }
                        }
                        else
                        {
                            Report.Fail(NewProdNumber + " Product is not offered for " + arr1[b] + " application.", "ProdOffer" + b + "", "True", appHandle, true);
                        }
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SelectProductFromProductListTable(sProductNumberToBeCopied);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnRelationshipButton();
                        string RelationsShipDetails = WebAdminPageFactory.WebAdminProductOfferConfigurationPage.GetRelationshipsDetailsFromProductToBeCopied(sProductNumberToBeCopied);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickONCancelButton();
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SetRelationshipForSpecificedProductNumber(NewProdNumber, RelationsShipDetails);
                        Report.Info("Relationships are selected as per base product.", "reltocopyprod", "true", appHandle);
                        WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnSubmitButton();
                        if (WebAdminPageFactory.WebAdminProductOfferConfigurationPage.VerifyMessageProductOfferConfigurationPage(Data.Get("The relationship(s) for the product type has been modified.")))
                        {
                            Report.Pass("Relationship for " + NewProdNumber + " Product type is modified successfully for " + arr1[b] + " application.", "RelationModified" + b + "", "True", appHandle);
                        }
                        else
                        {
                            Report.Fail("Relationship for " + NewProdNumber + " Product type is modified successfully for " + arr1[b] + " application.", "RelationModified" + b + "", "True", appHandle, true);
                        }
                    }
                }
            }
            Product = NewProdNumber;
            return Product;
        }
        public virtual void UpdateExchangeRateByCurrencyCodeRate(string CurrencyCode, string Rate)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Currency Codes"));
            WebAdminPageFactory.TableConfigurationCurrencyCodesPage.VerifyCurrencyCodesPageLoads();
            WebAdminPageFactory.TableConfigurationCurrencyCodesPage.SelectCurrencyCodeInCurrencyCodeList(CurrencyCode);
            Report.Info("Currency Code : " + CurrencyCode + " is selected.", "currencycodeconfig", "True", appHandle);
            WebAdminPageFactory.TableConfigurationCurrencyCodesPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Exchange Rates"));
            WebAdminPageFactory.TableConfigurationCurrencyCodesPage.EnterRetailMidRateInExchangeRates(Rate);
            Report.Info("Mid rate in Exchange is entered as : " + Rate, "exchgateonfig", "True", appHandle);
            WebAdminPageFactory.TableConfigurationCurrencyCodesPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.TableConfigurationCurrencyCodesPage.VerifyMessageInTableConfigurationCurrencyCodesPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Rate : " + Rate + " is updated for Currency : " + CurrencyCode + " successfully.", "currupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Rate : " + Rate + " is not updated for Currency : " + CurrencyCode + " successfully.", "currupdate", "True", appHandle, true);
            }
        }
        /// <summary>
        /// This method is used to verify Error Message : Product already exists. 
        /// Example:
        /// sProductClass : D - Deposit Accounts 
        ///  sProductGroup : SAV - Savings
        ///  sProductNumberToBeCopied : Standard product number to be copied.static
        ///  ExistingProductNumber : Product number to be validated .
        /// </summary>
        /// <param name="sProductClass"></param>
        /// <param name="sProductGroup"></param>
        /// <param name="sProductNumberToBeCopied"></param>
        /// <param name="ExistingProductNumber"></param>
        public virtual void VerifyProductExistsCopyProduct(string sProductClass, string sProductGroup, string sProductNumberToBeCopied, string ExistingProductNumber)
        {

            if (appHandle.GetTitle().Contains("Product Factory")) { }
            else
            {
                WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumberToBeCopied);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnCopyButton();

            WebAdminPageFactory.WebAdminProductCopyPage.EnterProductCopyDetails(ExistingProductNumber);
            Report.Info(ExistingProductNumber + " data is entered in Product Copy page.", "prodcopyData", "True", appHandle);
            WebAdminPageFactory.WebAdminProductCopyPage.ClickOnSubmitButton();


            if (WebAdminPageFactory.WebAdminProductCopyPage.VerifyMessageProductCopyPage("Product " + ExistingProductNumber + " already exists"))
            {

                Report.Pass("Message : Product " + ExistingProductNumber + " already exists. is displayed. ", "existingprodcopied", "True", appHandle);
            }
            else
            {
                Report.Fail("Message : Product " + ExistingProductNumber + " already exists. is not displayed.", "existingprodcopiedFail", "True", appHandle, true);
            }
        }
        public virtual void UpdateStatementsSuppressBalancePrintOption(string sProductClass, string sProductGroup, string sProductNumber, bool ONorOFF)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();
            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Statements"));
            if (WebAdminPageFactory.WebAdminProductStatementsPage.ClickOnSuppressBalancePrintCheckbox(ONorOFF))
            {
                WebAdminPageFactory.WebAdminProductStatementsPage.ClickOnSubmitButton();

                if (WebAdminPageFactory.WebAdminProductStatementsPage.VerifyMessageInWebAdminProductStatementsPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Suppress balance Print is updated in Product Statements Page.", "suppressbalprint", "True", appHandle);
                }
                else
                {
                    Report.Fail("Suppress balance Print is not updated in Product Statements Page.", "suppressbalprintfail", "True", appHandle, true);
                }
            }
        }

        public virtual void UpdateFundsTransferPermitPaymentOrderOption(string sProductClass, string sProductGroup, string sProductNumber, bool ONorOFF, string ReconcillationFreq = "1MAE", string ReconcillationOffsetDays = "1")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            if (WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.ClickOnFundsTransferPermitPaymentOrderCheckbox(ONorOFF))
            {
                WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.EnterReconcillationDetails(ReconcillationFreq, ReconcillationOffsetDays);
                WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.select_submit_button();
                if (WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.VerifyMessageInWebAdminProductTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Permit payment order is updated in Product Transaction Processing Page.", "Permitpaymentorder", "True", appHandle);
                }
                else
                {
                    Report.Fail("Permit payment order is not updated in Product Transaction Processing Page.", "Permitpaymentorderfail", "True", appHandle, true);
                }
            }
        }
        public virtual void DeleteProductFromProductsList(string sProductClass, string sProductGroup, string sProductNumber)
        {
            string ProdDeleteConfMSG = Data.Get("Are you sure you want to delete this product?");
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();
            if (appHandle.IsObjectExists("XPath;//*[text()='" + sProductNumber + "']"))
            {
                if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
                {
                    Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
                }
                WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnDeleteButton();
                appHandle.SwitchTo(SwitchInto.ALERT);
                // Report.Info(ProdDeleteConfMSG + " is displayed.", "DeleteConf", "true", appHandle);
                appHandle.PerformActionOnAlert(PopUpAction.Verify, ProdDeleteConfMSG);


                // Report.Info(Data.Get("Are you sure you want to delete this product?") + " is displayed.", "deleteconfirmsuccess", "True", appHandle);
                appHandle.Wait_For_Specified_Time(3);
                appHandle.PerformActionOnAlert(PopUpAction.Accept);
                appHandle.SwitchTo(SwitchInto.DEFAULT);

                if (WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.VerifyMessageInWebAdminProductTransactionProcessingPage(Data.Get("The product has been deleted.")))
                {
                    if (!appHandle.IsObjectExists("XPath;//*[text()='" + sProductNumber + "']"))
                    {
                        Report.Pass(sProductNumber + " is removed from Products Table.", "deleteProd", "True", appHandle);
                    }
                    else
                    {
                        Report.Fail(sProductNumber + " is not removed from Products Table.", "deleteProdfail", "True", appHandle, true);
                    }
                }
                // }
                // else
                // {
                //     Report.Fail(Data.Get("Are you sure you want to delete this product?") + " is not  displayed.", "deleteconfirmfail", "True", appHandle, true);
                // }
            }
            else
            {
                WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnDeleteButton();
                appHandle.Wait_For_Specified_Time(4);
                if (appHandle.PerformActionOnAlert(PopUpAction.Verify, Data.Get("Please select a product to delete.")))
                {
                    Report.Fail("Product Delete operation can not be carried out as " + sProductNumber + " is not found in the Products List .", "prodnumberunavailable", "True", appHandle);
                }
                appHandle.Wait_For_Specified_Time(2);
                appHandle.PerformActionOnAlert(PopUpAction.Accept);
            }

        }
        public virtual void VerifyErrorMessageDeletingProductWithAccount()
        {
            if (WebAdminPageFactory.WebAdminProductsCommonPage.VerifyMessageInProductsPage(Data.Get("Accounts exist with this product type. Cannot delete.")))

            {
                Report.Pass(Data.Get("Accounts exist with this product type. Cannot delete.") + " is successfully displayed while deleting a Product for whih an account exists.", "deletemsg", "true", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("Accounts exist with this product type. Cannot delete.") + " is not successfully displayed while deleting a Product for whih an account exists.", "deletemsgfail", "true", appHandle, true);
            }
        }
        /// <summary>
        /// To create an Interest index under Table management in WebAdmin .
        /// IndexType : Any of 4 items present in Index type dropdown.
        /// Interest Index : Index name .It is an optional parameter. By default a name is created, but if in any case we need to pass specific name the same can be passed. 
        /// Index Desc : Index description .It is an optional parameter. By default a description is created, but if in any case we need to pass specific description the same can be passed. 
        /// AdditionalDetailLabelnameLabelValueByPipeDelimited : Apart from Index type, Index desc , Index name if data need to be entered in any other fields then this can be used. It has to be passed as labelname|Label value  . In case of multiple parameter label1|value1;label2|value2
        /// </summary>
        /// <param name="IndexType"></param>
        /// <param name="InterestIndex"></param>
        /// <param name="IndexDesc"></param>
        /// <param name="AdditionalDetailLabelnameLabelValueByPipeDelimited"></param>
        /// <returns>Index name</returns>
        public virtual string CreateTableConfigurationInterestIndex(string IndexType, string InterestIndex = "", string IndexDesc = "", string AdditionalDetailLabelnameLabelValueByPipeDelimited = "")
        {
            string InterestIndexValue = "";
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
            WebAdminPageFactory.IndexListPage.ClickOnAddButton();
            InterestIndexValue = WebAdminPageFactory.IndexAddPage.EnterIndexDetails(IndexType, InterestIndex, IndexDesc, AdditionalDetailLabelnameLabelValueByPipeDelimited);
            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.IndexAddPage.VerifyMessageInInterestAddPage(Data.Get("The index has been created.")))
            {
                Report.Pass(InterestIndexValue + " is created successfully for index type " + IndexType + " .", "indexcreate", "True", appHandle);
            }
            else
            {
                Report.Fail(InterestIndexValue + " is not  created successfully for index type " + IndexType + " .", "indexcreate", "True", appHandle, true);
            }
            return InterestIndexValue;
        }
        /// <summary>
        /// This method is used to add rates to interest index in table management in WebAdmin
        /// IndexType :  Type of the Index.
        /// InterestIndex : Index name.
        /// EffectiveDate : It is an optional parameter .By default it enters system date.
        /// BasisIndexRate : Basis index type rate .
        /// ComparativeIndexAccountLevelRate : Comparative index account level type rate.
        /// ComparativeIndexIndexLevelRate : Comparative index level type rate
        /// TiredIndexRate : Tired index rate  
        /// </summary>
        /// <param name="IndexType"></param>
        /// <param name="InterestIndex"></param>
        /// <param name="EffectiveDate"></param>
        /// <param name="BasisIndexRate"></param>
        /// <param name="ComparativeIndexAccountLevelRate"></param>
        /// <param name="ComparativeIndexIndexLevelRate"></param>
        /// <param name="TiredIndexRate"></param>
        public virtual void AddRatesToInterestIndex(string IndexType, string InterestIndex, string EffectiveDate = "", string BasisIndexRate = "", string ComparativeIndexAccountLevelRate = "", string ComparativeIndexIndexLevelRate = "", string TiredIndexRateDetailsPipeDelimited = "", bool AnticipatedONorOFF = true, string BalancePipeDelimitedRate = "", bool DayendONorOFF = true)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
            WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(InterestIndex);
            WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
            WebAdminPageFactory.IndexListPage.ClickOnAddButton();
            if (string.IsNullOrEmpty(EffectiveDate))
            {
                EffectiveDate = this.GetApplicationDate();
            }
            WebAdminPageFactory.IndexListPage.EnterEffectiveDate(EffectiveDate);
            Report.Info(EffectiveDate + " has been entered as entered as effective date.", "effectivedate", "True", appHandle);
            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();

            switch (IndexType)
            {
                case "0 - Basis Index":
                    if (string.IsNullOrEmpty(BasisIndexRate))
                    {
                        BasisIndexRate = "10";
                    }
                    WebAdminPageFactory.IndexListPage.EnterRateORIndex(BasisIndexRate, AnticipatedONorOFF, DayendONorOFF);
                    Report.Info(BasisIndexRate + " has been entered as entered as basis index interest rate.", "basisindexinterestrate", "True", appHandle);
                    break;

                case "1 - Tiered Index":
                    if (!string.IsNullOrEmpty(TiredIndexRateDetailsPipeDelimited))
                    {
                        if (WebAdminPageFactory.IndexListPage.EnterDataInTieredInterestIndexRates(TiredIndexRateDetailsPipeDelimited))
                        { }
                        else
                        {
                            Report.Fail("Please check the input values passed.", "dataentrfailed", "True", appHandle, true);
                        }
                    }
                    break;

                case "2 - Comparative Index - Index Level":

                    if (string.IsNullOrEmpty(ComparativeIndexIndexLevelRate))
                    {
                        string temp = "";
                        string[] arr = null;
                        string msg = "", failmsg = "";
                        if (BalancePipeDelimitedRate.Contains(";"))
                        {
                            arr = BalancePipeDelimitedRate.Split(';');
                            for (int b = 0; b < arr.Length; b++)
                            {
                                temp = temp + " , " + string.Join(" , ", arr[b].Split('|')) + " is added successfully in  Interest Index Rates List in WebAdmin.";

                            }
                            msg = temp.Substring(3, temp.Length - 3);
                            //failmsg = msg.Replace(" is ", " is not ");
                        }
                        else
                        {
                            msg = string.Join(" , ", BalancePipeDelimitedRate.Split('|')) + " is added successfully in  Interest Index Rates List in WebAdmin.";
                            // failmsg = msg.Replace(" is ", " is not ");
                        }
                        WebAdminPageFactory.IndexListPage.EnterDataInComparativeIndexIndexLevelRates(BalancePipeDelimitedRate);
                        Report.Pass(msg, "AddRatesToComparativeIndex", "True", appHandle);

                    }
                    break;
            }
            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.IndexAddPage.VerifyMessageInInterestAddPage("Rates have been added to the index " + InterestIndex + "."))
            {
                Report.Pass("Rates have been added to the index " + InterestIndex + ".", "interestrateadd", "True", appHandle);
            }
            else
            {
                Report.Fail("Rates have not been added to the index " + InterestIndex + ".", "interestrateaddFail", "True", appHandle, true);
            }
        }

        public virtual bool VerifyProfileReports(string ReportIDOrDESC, string ToVerifyValuesByPipeDelimited, string SearchCriteriaPipeDelimited = "")
        {
            bool Result = false;
            string msg = "";
            string failmsg = "";
            bool MatchFound = false;
            int temppageno = 0;
            int matchcount = 0;
            ToVerifyValuesByPipeDelimited = ToVerifyValuesByPipeDelimited + "|";
            string[] arr = ToVerifyValuesByPipeDelimited.Split('|');
            if (string.IsNullOrEmpty(arr[1]))
            {
                msg = arr[0] + " is found successfully in the Report: " + ReportIDOrDESC + " in Page Number : ";
                failmsg = arr[0] + " is not found  in the Report: " + ReportIDOrDESC + " in any of the pages.";
            }
            else
            {
                msg = string.Join(" , ", arr) + " are found successfully in the Report: " + ReportIDOrDESC + " in Page Number : ";
                failmsg = string.Join(" , ", arr) + " are not found  in the Report: " + ReportIDOrDESC + " in any of the pages.";
            }
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Reporting") + "|" + Data.Get("Profile Reports"));
            WebAdminPageFactory.ProfileReportsPage.SelectReport(ReportIDOrDESC);
            if (WebAdminPageFactory.ProfileReportsPage.CheckReportDetailPageLoaded())
            {
                WebAdminPageFactory.ProfileReportsPage.EnterSearchCriteria(SearchCriteriaPipeDelimited);
                WebAdminPageFactory.ProfileReportsPage.ClickOnRunButton();
            }
            int TotReportPageCount = WebAdminPageFactory.ProfileReportsPage.GetNumberOfPagesInReport();
            for (int a = 2; a <= TotReportPageCount; a++)
            {
                WebAdminPageFactory.ProfileReportsPage.ClickOnPageLinkByPageNumber(a);
                string tempContent = WebAdminPageFactory.ProfileReportsPage.ReadReportDetails();
                if (arr.Length == 1)
                {
                    if (tempContent.Contains(arr[0]))
                    {
                        MatchFound = true;
                        temppageno = a - 1;
                        break;
                    }
                    else { continue; }
                }
                else
                {
                    for (int b = 0; b < arr.Length - 1; b++)
                    {
                        if (tempContent.Contains(arr[b]))
                        {
                            matchcount++;
                        }
                        if (matchcount == arr.Length - 1)
                        {
                            MatchFound = true;
                            temppageno = a - 1;
                            break;
                        }
                    }


                }
                if (matchcount == arr.Length - 1)
                {
                    if (MatchFound)
                    {
                        break;
                    }
                }
                else
                {
                    matchcount = 0;
                }


            }
            if (MatchFound == true)
            {
                if (arr.Length == 1)
                {
                    Report.Pass(msg + temppageno + "", "reportfoundpass", "True", appHandle);
                }
                if (arr.Length > 1)
                {
                    Report.Pass(msg + temppageno + "", "reportfoundpass", "True", appHandle);
                }
                Result = true;
            }
            else
            {
                if (arr.Length == 1)
                {
                    Report.Fail("The data is not present in specified file. Please check the parameter");
                }
                if (arr.Length > 1)
                {
                    Report.Fail("The data is not present in specified file. Please check the parameter");
                }
            }
            return Result;

        }
        public virtual void UpdateInterestCalculationDailyCalculation(string sProductClass, string sProductGroup, string sProductNumber, string accrualBase, string accrualMethod, string updateMessage)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            WebAdminPageFactory.WebAdminProductsCommonPage.select_Interest_tab();
            try
            {
                WebAdminPageFactory.DepositInterestCalculationPage.UpdateDailyCalculationAccrualBase(accrualBase);
                accrualMethod = appHandle.ReplaceString(accrualMethod, "-", ",");
                WebAdminPageFactory.DepositInterestCalculationPage.UpdateDailyCalculationAccrualMethod(accrualMethod);
                WebAdminPageFactory.DepositInterestCalculationPage.ClickOnSubmitButton();
                if (WebAdminPageFactory.DepositInterestCalculationPage.VerifyMessageInInterestCalculationPage(updateMessage))
                {
                    Report.Pass("Accrual details are updated in Calculation page.", "AccrualDetails", "True", appHandle);
                }
                else
                {
                    Report.Fail("Accrual details are updated in Calculation page.", "AccrualDetailsfail", "True", appHandle, true);
                }
            }
            catch (Exception e)
            {
                Report.Fail("Failed to update Accrual details in Calculation page" + e, "AccrualDetailsfail", "True", appHandle, true);
            }

        }

        public virtual void UpdateInterestRateDeterminationFixedDetails(string sProductClass, string sProductGroup, string sProductNumber, string nominalRate, string updateMessage)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            WebAdminPageFactory.WebAdminProductsCommonPage.select_Interest_tab();
            WebAdminPageFactory.DepositRateDeterminationPage.select_RateDetermination_subtab();
            try
            {
                WebAdminPageFactory.DepositRateDeterminationPage.updateNominalRate(nominalRate);
                WebAdminPageFactory.DepositRateDeterminationPage.ClickOnSubmitButton();
                if (WebAdminPageFactory.DepositRateDeterminationPage.VerifyMessageInInterestRateDeterminationPage(updateMessage))
                {
                    Report.Pass("Fixed rate Nominal rate details are updated in RateDetermination page.", "FixedRate", "True", appHandle);
                }
                else
                {
                    Report.Fail("Fixed rate Nominal rate details are not updated in RateDetermination page.", "FixedRatefail", "True", appHandle, true);
                }
            }
            catch (Exception e)
            {
                Report.Fail("Failed to update Fixed Rate details in RateDetermination page" + e, "FixedRatefail", "True", appHandle, true);
            }

        }

        public virtual void UpdateInterestPostingOptionsDetails(string sProductClass, string sProductGroup, string sProductNumber, string disbursementOption, string postingFrequency, string updateMessage)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            WebAdminPageFactory.WebAdminProductsCommonPage.select_Interest_tab();
            WebAdminPageFactory.DepositPostingOptionsPage.select_PostingOptions_subtab();
            try
            {
                WebAdminPageFactory.DepositPostingOptionsPage.updatePostingOptionsDisbursementOption(disbursementOption);
                WebAdminPageFactory.DepositPostingOptionsPage.updatePostingOptionsPostingFrequency(postingFrequency);
                WebAdminPageFactory.DepositPostingOptionsPage.ClickOnSubmitButton();
                if (WebAdminPageFactory.DepositPostingOptionsPage.VerifyMessageInInterestPostingOptionsPage(updateMessage))
                {
                    Report.Pass("Posting Option details are updated in Posting Options page.", "PostingOptions", "True", appHandle);
                }
                else
                {
                    Report.Fail("Posting Option details are not updated in Posting Options page.", "PostingOptionsfail", "True", appHandle, true);
                }
            }
            catch (Exception e)
            {
                Report.Fail("Failed to update Posting Options details in Posting Options page" + e, "PostingOptionsfail", "True", appHandle, true);
            }

        }
        /// <summary>
        /// This method is used to update the U.S Regulatory Page DD Option.
        /// </summary>
        /// <param name="ONorOFF"></param>
        public virtual void UpdateUSRegulatoryPageDDOption(string sProductClass, string sProductGroup, string sProductNumber, bool ONorOFF)
        {
            this.GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));

            if (WebAdminPageFactory.USRegulatoryRegulatoryPage.ClickOnRegulationDDAccountCheckBox(ONorOFF))
            {
                WebAdminPageFactory.USRegulatoryRegulatoryPage.SelectSubmitButton();

                if (WebAdminPageFactory.USRegulatoryRegulatoryPage.VerifyMessageDepositRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Regulation DD checkbox is selected in U.S Regulatory Page.", "DDAcheckboxSelected", "True", appHandle);
                }
                else
                {
                    Report.Fail("Regulation DD checkbox is not selected in U.S Regulatory Page.", "DDAcheckboxNotSelected", "True", appHandle, true);
                }
            }
        }


        /// <summary>
        /// This Method is used to update Accrual Base , Accrual Method, Minimum Balance to Accrue, Minimum Balance Accrual Option,
        /// Maximum Balance to Accrue in Interest Calculation Page.
        /// </summary>
        /// <param name="sProductClass"></param>
        /// <param name="sProductGroup"></param>
        /// <param name="sProductNumber"></param>
        /// <param name="AccrualBaseOption"></param>
        /// <param name="AccrualMethodOption"></param>
        /// <param name="MinBal"></param>
        /// <param name="MinBalAccrualOption"></param>
        /// <param name="MaxBal"></param>
        public virtual void UpdateDepositInterestCalculationAccrualOption(string sProductClass, string sProductGroup, string sProductNumber, string AccrualBaseOption, string AccrualMethodOption, string MinBal = "", string MinBalAccrualOption = "", string MaxBal = "", bool FastRecalculation = false, string AvailableInterest = "", string CompFreq = "")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Calculation"));
            if (WebAdminPageFactory.DepositInterestCalculationPage.WaitUntilInterestPageloads())
            {
                WebAdminPageFactory.DepositInterestCalculationPage.EnterInterestAccrualOptions(AccrualBaseOption, AccrualMethodOption, MinBal, MinBalAccrualOption, MaxBal, FastRecalculation, AvailableInterest, CompFreq);
                WebAdminPageFactory.DepositInterestCalculationPage.SelectSubmitButton();
                if (WebAdminPageFactory.DepositInterestCalculationPage.VerifyMessageDepositInterestCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Accrual Base and Accrual Method is updated in Interest Calculation Page.", "InterestCalculationfieldUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Accrual Base and Accrual Method is not updated in Interest Calculation Page.", "InterestCalculationfieldNotUpdated", "True", appHandle, true);
                }
            }
        }
        public virtual void UpdateInterestPostingOptionPageDetails(string sProductClass = "", string sProductGroup = "", string sProductNumber = " ", string DisbursmentOpt = "", string PostingFreq = "", string MinimumBalancetoCreditInterestField = "", bool SubjToWithONorOFF = false, bool AccrWithTaxProcessingONorOFF = false)
        {

            GetProduct(sProductClass, sProductGroup, sProductNumber);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Posting Options"));
            if (WebAdminPageFactory.DepositPostingOptionsPage.WaitUntilInterestPostingOptionPageloads())
            {
                WebAdminPageFactory.DepositPostingOptionsPage.EnterInterestPostingOptions(DisbursmentOpt, PostingFreq, MinimumBalancetoCreditInterestField, SubjToWithONorOFF, AccrWithTaxProcessingONorOFF);
                WebAdminPageFactory.DepositPostingOptionsPage.SelectSubmitButton();
                if (WebAdminPageFactory.DepositPostingOptionsPage.VerifyMessageDepositInterestPostingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Disbursment Option and Posting Frequency fields are updated in Posting Option Page", "PaymentOptionFieldUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Disbursment Option and Posting Frequency fields are not updated in Posting Option Page.", "PaymentOptionFieldNotUpdated", "True", appHandle, true);
                }
            }
        }
        public virtual void UpdateLoanMaturityProcessingPageOption(string sProductClass = "", string sProductGroup = "", string sProductNumber = "", string Maturityoption = "", string paymenterm = "", string businessdate = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Maturity/Renewal"));
            if (WebAdminPageFactory.LoanMaturityProcessingPage.WaitUntilLoanMaturityProcessingPageloads())
            {
                WebAdminPageFactory.LoanMaturityProcessingPage.EnterMaturityProcessingPageOption(Maturityoption, paymenterm, businessdate);
                WebAdminPageFactory.LoanMaturityProcessingPage.SelectSubmitButton();
                if (WebAdminPageFactory.LoanMaturityProcessingPage.VerifyMessageLoanMaturityProcessingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Loan Maturity option is updated in Maturity Processing Page", "MaturityProcessingFieldupdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Loan Maturity option not updated in Posting Option Page.", "MaturityProcessingFieldNotUpdated", "True", appHandle, true);
                }
            }
        }
        public virtual void UpdateLoanUSRegulatoryPageOption(string sProductClass, string sProductGroup, string sProductNumber, string USRegulatoryOptionsSemecolonDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));
            if (WebAdminPageFactory.LoanUSRegulatoryPage.WaitUntilLoanUSRegulatoryPageloads())
            {
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue(USRegulatoryOptionsSemecolonDelimited);
                //WebAdminPageFactory.LoanUSRegulatoryPage.EnterUSRegulatoryPageOptions(FDICPrimaryReportingCode);
                WebAdminPageFactory.LoanUSRegulatoryPage.SelectSubmitButton();
                if (WebAdminPageFactory.LoanUSRegulatoryPage.VerifyMessageLoanUSRegulatoryOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Loan Maturity option is updated in Maturity Processing Page", "MaturityProcessingFieldupdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Loan Maturity option not updated in Posting Option Page.", "MaturityProcessingFieldNotUpdated", "True", appHandle, true);
                }
            }
        }

        public virtual void updateTransactionCodeAdjustmentPageOption(string sProductClass = "", string sProductGroup = "", string sProductNumber = "", string NegAcrIntDebit = "", string NegAcrIntCredit = "", string UnAcrIntDebit = "", string UnAcrIntCredit = " ")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Codes"));
            if (WebAdminPageFactory.DepositTransactionCodePage.WaitUntilTransactionCodeAdjustmentPageloads())
            {
                WebAdminPageFactory.DepositTransactionCodePage.EnterTransactionCodeAdjustmentDetails(NegAcrIntDebit, NegAcrIntCredit, UnAcrIntDebit, UnAcrIntCredit);
                WebAdminPageFactory.DepositTransactionCodePage.SelectSubmitButton();
                if (WebAdminPageFactory.DepositTransactionCodePage.VerifyMessageDepositTransactionCodeAdjustmentPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Loan Maturity option is updated in Maturity Processing Page", "MaturityProcessingFieldupdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Loan Maturity option not updated in Posting Option Page.", "MaturityProcessingFieldNotUpdated", "True", appHandle, true);
                }
            }
        }

        public virtual void VerifyLookupValuesInReportCriteria(string custno, string reportid)
        {

            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Reporting") + "|" + Data.Get("Profile Reports"));
            WebAdminPageFactory.ProfileReportsPage.SelectReport(reportid);
            string op = WebAdminPageFactory.ReportCriteriaPage.VerifyLookupValues(custno, reportid);
            if (op.Equals("TrueTrue"))
            {
                Report.Pass("The expected values D Deposit Accounts and L Loan Accounts present in look value table", "lookuppass", "True", appHandle);
            }
            else
            {
                Report.Fail("The expected values D Deposit Accounts and L Loan Accounts not present in look value table", "lookufail", "True", appHandle);
            }

            WebAdminPageFactory.ReportCriteriaPage.ClickCloseWindowButton();
        }

        public virtual string AddServiceFeePlan(string inputvaluesseparatedbysemicolon, string Currency, string ServicePlanDesc = "", string EfffectiveDate = "", bool ConvertAmtField = false, string basecurrency = "", string exchangerate = "", bool dailyfeesubjtoRegDD = false)

        {
            string feesuccessmsg = Data.Get("GLOBAL_SERVICEFEE_CREATED_MSG");
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("ServiceFeePlans"));
            WebAdminPageFactory.ServiceFeePlanListPage.ClickOnAddButton();
            string servicefeeplan = WebAdminPageFactory.AddServiceFeePlanPage.EnterDetailsOfServiceFeePlan(inputvaluesseparatedbysemicolon, ServicePlanDesc, EfffectiveDate, ConvertAmtField, basecurrency, exchangerate, dailyfeesubjtoRegDD);
            WebAdminPageFactory.AddServiceFeePlanPage.ClickSubmitButton();
            bool opval = WebAdminPageFactory.AddServiceFeePlanPage.CheckSuccessMsgForFeePlan(feesuccessmsg);
            if (opval)
            {
                Report.Pass("The effective date for the service fee plan has been created.", "AddPlanPass", "True", appHandle);
            }
            else
            {
                Report.Fail("The effective date for the service fee plan has not been created.", "AddPlanFail", "True", appHandle);

            }

            //string feeplanvalue = WebAdminPageFactory.AddServiceFeePlanPage.GetServicePlanValue();

            return servicefeeplan;

        }

        public virtual void EditServiceFeePlanInFeesTab(string servicefeeplan, string inputvaluesseparatedbysemicolon)
        {
            string sucmsg = Data.Get("GLOBAL_SERVICE_FEE_PLAN_CATEGORY_ADD_SUCCESS_MESSAGE");
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("ServiceFeePlans"));
            WebAdminPageFactory.ServiceFeePlanListPage.SelectFeePlanFromFeePlanTable(servicefeeplan);
            WebAdminPageFactory.ServiceFeePlanListPage.ClickEditButton();
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.SelectRadioButtonInFeePlanTable(servicefeeplan);
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.ClickOnEditButton();
            WebAdminPageFactory.PlanParametersPage.ClickOnFeesTab();
            WebAdminPageFactory.PlanFeesPage.ClickOnAddButton();
            WebAdminPageFactory.PlanFeesPage.SelectValuesinPlanFeePage(inputvaluesseparatedbysemicolon);
            WebAdminPageFactory.PlanFeesPage.ClickOnSubmitButton();
            bool opval = WebAdminPageFactory.PlanFeesPage.CheckSuccessMsg(sucmsg);
            if (opval)
            {
                Report.Pass("The fees for the service fee plan have been created.", "feeplaneditpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The fees for the service fee plan have been created.", "feeplaneditfail", "True", appHandle);
            }


        }


        public virtual void VerifyLookupValuesForReportNOT002A(string reportname, string accno, string notedesc, string appdate, string expdate)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Reporting") + "|" + Data.Get("Profile Reports"));
            WebAdminPageFactory.ProfileReportsPage.SelectReport(reportname);
            string op = WebAdminPageFactory.ReportCriteriaPage.CheckLookupValuesForReportNOT002A(accno, notedesc, appdate, expdate);

            if (op.Equals("true"))
            {
                Report.Pass("The expected values note description,note expiration date present in look value table", "lookuppass", "True", appHandle);
            }
            else
            {
                Report.Fail("The expected values note description,note expiration date not present in look value table", "lookupFail", "True", appHandle);
            }

            WebAdminPageFactory.ReportCriteriaPage.ClickCloseWindowButton();

        }

        public virtual void ValidateUTBLREGION()
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("General Table Management"));
            WebAdminPageFactory.GeneralTableManagementPage.SearchTableName(Data.Get("UTBLREGION"));
            WebAdminPageFactory.GeneralTableManagementPage.ValidateAddRegion();
        }
        public virtual void EditProductGeneralSection(string sProductClass, string sProductGroup, string ProductToBeEdited, string StartDate = "", string GLSetCodeNumber = "", string BillPrintDesign = "", string Currency = "")
        {
            GetProduct(sProductClass, sProductGroup, ProductToBeEdited);
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.UpdateProductGeneralSection(StartDate, GLSetCodeNumber, BillPrintDesign, Currency);
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnSubmitButton();

            if (WebAdminPageFactory.WebAdminProductOfferConfigurationPage.VerifyMessageProductOfferConfigurationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Product " + ProductToBeEdited + " is modified successfully.", "EditProductGeneralSection", "True", appHandle);
            }
            else
            {
                Report.Fail("Product " + ProductToBeEdited + " is not modified . ", "EditProductGeneralSection", "True", appHandle, true);
            }
        }


        public virtual string CreateTableConfigurationInterestMatrix(string MatrixName = "", string MatrixDesc = "", string MatrixRow = "", string MatrixColumn = "", bool isMassChangeInProgress = false)
        {
            string InterestMatrix = "";
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Matrixes"));
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.ClickOnAddButton();
            InterestMatrix = WebAdminPageFactory.TableConfigurationInterestMatrixesPage.EnterInterestMatrixDetails(MatrixName, MatrixDesc, MatrixRow, MatrixColumn, isMassChangeInProgress);
            string tempmatrix = WebAdminPageFactory.TableConfigurationInterestMatrixesPage.ClickOnSubmitButton();
            if (!string.IsNullOrEmpty(tempmatrix))
            {
                InterestMatrix = tempmatrix;
            }
            if (WebAdminPageFactory.TableConfigurationInterestMatrixesPage.VerifyIterestMatrixInInterestMatrixList(InterestMatrix)
            && WebAdminPageFactory.TableConfigurationInterestMatrixesPage.VerifyMessageInInterestMatrixPage(Data.Get("The interest matrix has been created.")))

            {
                Report.Pass(InterestMatrix + " is successfully added in Interest Matrix List.", "intmatrixadd", "True", appHandle);
            }
            else
            {
                Report.Fail(InterestMatrix + " is not added in Interest Matrix List.", "intmatrixaddfail", "True", appHandle, true);
            }
            return InterestMatrix;
        }
        public virtual void AddRatesToInterestMatrix(string MatrixName, string BalancePipeDelimitedRate, string EffectiveDate = "")
        {
            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (BalancePipeDelimitedRate.Contains(";"))
            {
                arr = BalancePipeDelimitedRate.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split('|')) + " is added successfully in  Interest Matrix Rates List in WebAdmin.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", BalancePipeDelimitedRate.Split('|')) + " is added successfully in  Interest Matrix Rates List in WebAdmin.";
                failmsg = msg.Replace(" is ", " is not ");
            }
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Matrixes"));
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.SelectInterestMatrixInInterestMatrixList(MatrixName);
            Report.Info(MatrixName + " is selected in interest matrix List.", "selectinterestmatrix", "True", appHandle);
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.ClickOnRatesButton();
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.ClickOnAddButton();
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.EnterDataInInterestMatrixRates(BalancePipeDelimitedRate, EffectiveDate);
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.SelectSubmitButton();
            if (WebAdminPageFactory.TableConfigurationInterestMatrixesPage.VerifyMessageInInterestMatrixPage(Data.Get("Rates have been added to the matrix.")))
            {
                Report.Pass(msg, "AddRatesToInterestMatrix", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "AddRatesToInterestMatrixFail", "True", appHandle, true);
            }
        }
        public virtual void ReloadWebAdminapplication(string ApplicationName)
        {
            Profile7CommonLibrary.ReloadApplication(ApplicationName);

        }
        public virtual void UpdateLoanInterestRateDeterminationPageOption(string sProductClass, string sProductGroup, string sProductNumber, string FRate = "", string VRIndex = "", string CFOption = "", string ratedeterminationoptionssemecolondelemited = "")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Rate Determination"));
            if (WebAdminPageFactory.LoanRateDeterminationPage.WaitUntilRateDeterminationPageLoad())
            {
                WebAdminPageFactory.LoanRateDeterminationPage.EnterRateDeterminationOptions(FRate, VRIndex, CFOption, ratedeterminationoptionssemecolondelemited);
                WebAdminPageFactory.LoanRateDeterminationPage.SelectSubmitButton();
                if (WebAdminPageFactory.LoanRateDeterminationPage.VerifyMessageDepositRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Nominal Rate, Variable Rate Index and Change Frequency fields are updated in Rate Determination Page.", "RateDeterminationFieldUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Nominal Rate, Variable Rate Index and Change Frequency fields are not updated in Rate Determination Page.", "RateDeterminationFieldNotUpdated", "True", appHandle, true);
                }
            }
        }
        public virtual void UpdateAvailableBalanceCalculationCodeProductGeneralPage(string sProductClass, string sProductGroup, string sProductNumber, string CalcCode)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            WebAdminPageFactory.WebAdminProductsGeneralPage.SelectAvailableBalanceCalculationCode(CalcCode);
            WebAdminPageFactory.WebAdminProductsGeneralPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.WebAdminProductsGeneralPage.VerifyMessageWebAdminProductGeneralPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Available Balance Calculation Code is selected as : " + CalcCode + " in product General Page in WebAdmin.", "prodgeneralcalcode", "True", appHandle);
            }
            else
            {
                Report.Fail("Available Balance Calculation Code is not selected as : " + CalcCode + " in product General Page in WebAdmin.", "prodgeneralcalcodefail", "True", appHandle, true);
            }

        }
        /// <summary>
        /// This method is used to update the U.S Regulatory Page CC Option.
        /// </summary>
        /// <param name="ONorOFF"></param>
        public virtual void UpdateUSRegulatoryPageCCOption(string sProductClass, string sProductGroup, string sProductNumber, bool ONorOFF)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));

            if (WebAdminPageFactory.USRegulatoryRegulatoryPage.ClickOnRegulationCCAccountCheckBox(ONorOFF))
            {
                WebAdminPageFactory.USRegulatoryRegulatoryPage.SelectSubmitButton();

                if (WebAdminPageFactory.USRegulatoryRegulatoryPage.VerifyMessageDepositRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Regulation CC checkbox is selected in U.S Regulatory Page.", "DDAcheckboxSelected", "True", appHandle);
                }
                else
                {
                    Report.Fail("Regulation CC checkbox is not selected in U.S Regulatory Page.", "DDAcheckboxNotSelected", "True", appHandle, true);
                }
            }
        }
        public virtual void UpdateDetailsInInvestmentSweepPage(string ProductClass, string ProductGroup, string ProductNumber, string ProcessingOption = "", string Code = "", string SavingsPurchaseThreshold = "", string SavingsPurchaseIncrement = "", string RedemptionThreshold = "", string RedemptionIncrement = "", string RedemptionOption = "", string BalanceOption = "", string InvestmentPlan = "", bool NonInstitutionAccount = false, bool DelayInterestDividendPosting = false)
        {
            GetProduct(ProductClass, ProductGroup, ProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Investment Sweep"));
            WebAdminPageFactory.InvestmentSweepPage.WaitUntilInvestmentSweepPageLoads();
            WebAdminPageFactory.InvestmentSweepPage.EnterDetailsInInvestmentSweep(ProcessingOption, Code, SavingsPurchaseThreshold, SavingsPurchaseIncrement, RedemptionThreshold, RedemptionIncrement, RedemptionOption, BalanceOption, InvestmentPlan, NonInstitutionAccount, DelayInterestDividendPosting);
            WebAdminPageFactory.InvestmentSweepPage.ClickOnSubmitButton();
            WebAdminPageFactory.InvestmentSweepPage.VerifyMessageInInvestmentSweepOption(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }
        public virtual void UpdateDetailsInOverdraftAuthorizedPage(string ProductClass, string ProductGroup, string ProductNumber, string AuthorizedOverdraftLimit = "", string AuthorizedOverdraftTerm = "", bool ProvisionProcessing = false, bool DepositReclassification = false, string CommitmentFeePercentage = "")
        {
            GetProduct(ProductClass, ProductGroup, ProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Overdraft"));
            WebAdminPageFactory.OverdraftAuthorizedPage.WaitUntilOverdraftAuthorizedPageLoads();
            WebAdminPageFactory.OverdraftAuthorizedPage.EnterDataInOverdraftAuthorizedPage(AuthorizedOverdraftLimit, AuthorizedOverdraftTerm, ProvisionProcessing, DepositReclassification, CommitmentFeePercentage);
            WebAdminPageFactory.OverdraftAuthorizedPage.ClickOnSubmitButton();
            WebAdminPageFactory.OverdraftAuthorizedPage.VerifyMessageInOverdraftAuthorizedPage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }
        public virtual void UpdateDetailsInDepositInterestNegativeInterestPage(string ProductClass, string ProductGroup, string ProductNumber, bool AllowNegativeInterestRate = false, string AccrualOption = "", string PostingOption = "", string PostingFrequency = "", bool PostZeroNetInterest = false, string MinimumNegativeInterestChargeOption = "", string MinimumNegativeInterestChargeAmount = "", string NegativeAccountBalanceOption = "", string VATonInterestCalculationOption = "", bool AccPosIntOnNegBal = false)
        {
            GetProduct(ProductClass, ProductGroup, ProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Negative Interest"));
            WebAdminPageFactory.DepositInterestCalculationPage.WaitUntilNegativeInterestPageLoads();
            WebAdminPageFactory.DepositInterestCalculationPage.EnterDataInterestNegativeInterestNegativeInterestSection(AllowNegativeInterestRate, AccrualOption, PostingOption, PostingFrequency, PostZeroNetInterest, MinimumNegativeInterestChargeOption, MinimumNegativeInterestChargeAmount, NegativeAccountBalanceOption, VATonInterestCalculationOption, AccPosIntOnNegBal);
            WebAdminPageFactory.DepositInterestCalculationPage.ClickOnSubmitButton();
            WebAdminPageFactory.DepositInterestCalculationPage.VerifyMessageDepositInterestCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED"));
        }
        /// <summary>
        /// This method is used to add rates to Tired Interest index .
        /// InterestIndex : Interest index to be passed as input.
        /// TiredIndexDetails : The data has to be passed as below examples :
        /// "15|12|DEP.EXP;12.23|23"
        /// "15"
        /// "15|12|DEP.EXP"
        /// EffectiveDate : Optional Parameter . If no value is passed it considers system Date
        /// </summary>
        /// <param name="InterestIndex"></param>
        /// <param name="TiredIndexDetails"></param>
        /// <param name="EffectiveDate"></param>
        public virtual void AddRatesToTiredInterestIndex(string InterestIndex, string TiredIndexDetails, string EffectiveDate = "")
        {
            this.AddRatesToInterestIndex(Data.Get("1 - Tiered Index"), InterestIndex, EffectiveDate, string.Empty, string.Empty, string.Empty, TiredIndexDetails);
        }
        public virtual void ModifyRatesToInterestIndex(string IndexType, string InterestIndex, string EffectiveDate = "", string BasisIndexRate = "", string TiredIndexRate = "", bool AnticipatedONorOFF = true, bool DayendONorOFF = true)
        {

            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
            WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(InterestIndex);
            WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
            WebAdminPageFactory.IndexListPage.SelectEffectiveDate(EffectiveDate);
            WebAdminPageFactory.IndexListPage.ClickOnEditButton();

            switch (IndexType)
            {
                case "0 - Basis Index":
                    if (string.IsNullOrEmpty(BasisIndexRate))
                    {
                        BasisIndexRate = "10";
                    }
                    WebAdminPageFactory.IndexListPage.EnterRateORIndex(BasisIndexRate, AnticipatedONorOFF, DayendONorOFF);
                    Report.Info(BasisIndexRate + " has been entered as entered as basis index interest rate.", "basisindexinterestrate", "True", appHandle);
                    break;

            }
            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            if (WebAdminPageFactory.IndexAddPage.VerifyMessageInInterestAddPage("Rates for index " + InterestIndex + " have been modified in anticipated mode."))
            {
                Report.Pass("Rates have been modified to the index " + InterestIndex + ".", "interestrateadd", "True", appHandle);
            }
            else
            {
                Report.Fail("Rates have not been modified to the index " + InterestIndex + ".", "interestrateaddFail", "True", appHandle, true);
            }
        }

        public virtual void DeleteRatesFromIndexByEffectiveDate(string InterestIndex, string sEffectiveDate)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
            WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(InterestIndex);
            WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
            WebAdminPageFactory.IndexEffectiveDatesListPage.SelectEffectiveDateForIndex(sEffectiveDate);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnDeleteButton();
            WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            if (WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage("Rates for index " + InterestIndex + " have been deleted."))
            {
                Report.Pass("Successfully deleted the rate of index", "DeleteRatesOfIndexByEffectiveDate", "True");
            }
            else
            {
                Report.Fail("Failed to delete rate of index", "DeleteRatesOfIndexByEffectiveDate", "True");
            }
        }

        public virtual void UpdateRatesInInterestMatrixesTable(string InterestMatrix, string MatrixRateDetailsPipeDelimited, string EffectiveDate = "", bool IsAnticipatedRun = true, bool IsRunAtDayEnd = true)
        {
            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (MatrixRateDetailsPipeDelimited.Contains(";"))
            {
                arr = MatrixRateDetailsPipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split('|')) + " is updated successfully in  Interest Matrix Rates List in WebAdmin.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", MatrixRateDetailsPipeDelimited.Split('|')) + " is updated successfully in  Interest Matrix Rates List in WebAdmin.";
                failmsg = msg.Replace(" is ", " is not ");
            }
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Matrixes"));
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.SelectInterestMatrixInInterestMatrixList(InterestMatrix);
            Report.Info(MatrixRateDetailsPipeDelimited + " is selected in interest matrix List.", "selectinterestmatrix", "True", appHandle);
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.ClickOnRatesButton();
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.ModifyDataInterestMatrixRatesPostDayEnd(MatrixRateDetailsPipeDelimited, EffectiveDate, IsAnticipatedRun, IsRunAtDayEnd);
            if (WebAdminPageFactory.TableConfigurationInterestMatrixesPage.VerifyMessageInInterestMatrixPage("Rates have been updated to the matrix in anticpation mode."))
            {
                Report.Pass(msg, "updateratematrix", "True", appHandle);
            }
            else

            {
                Report.Fail(msg, "updateratematrixfail", "True", appHandle, true);
            }
        }
        public virtual void EnterInstititionVariableOption(string sLabelNameLabelValuePipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Accounts"), Data.Get("Deposit"));
            string msg = "";
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
                msg = string.Join(" , ", msg.Split(';'));
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
            }
            WebAdminPageFactory.InstitutionVariablePage.EnterInterestProcessingOption(sLabelNameLabelValuePipeDelimited);
            WebAdminPageFactory.InstitutionVariablePage.SelectSubmitButton();
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Institution Variable Page option updated ", "InstitionVariableOptionSelected", "True", appHandle);
            }
            else

            {
                Report.Fail("Institution Variable Page option is not updated ", "InstitionVariableOptionNotSelected", "True", appHandle, true);
            }
        }

        public virtual void EnterInstitutionVariablePageOption(string tabName, string subTabName, string sLabelNameLabelValuePipeDelimited)
        {

            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            if (subTabName.Equals(""))
            {

                Profile7CommonLibrary.SelectTabSubTabInApplication(tabName);

            }
            else
            {
                Profile7CommonLibrary.SelectTabSubTabInApplication(tabName, subTabName);
            }
            string msg = "";
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
                msg = string.Join(" , ", msg.Split(';'));
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
            }
            WebAdminPageFactory.USRegulatoryRegulatory2Page.EnterRegulatory2PageOption(sLabelNameLabelValuePipeDelimited);
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Institution Variable Page option updated ", "InstitionVariableOptionSelected", "True", appHandle);
            }
            else

            {
                Report.Fail("Institution Variable Page option is not updated ", "InstitionVariableOptionNotSelected", "True", appHandle, true);
            }
        }
        public virtual void UpdateUSRegulatoryPageOption(string sProductClass, string sProductGroup, string sProductNumber, bool ONorOFF)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));
            if (WebAdminPageFactory.USRegulatoryRegulatoryPage.ClickOnRegulationDDAccountCheckBox(ONorOFF))
            {
                WebAdminPageFactory.USRegulatoryRegulatoryPage.SelectSubmitButton();

                if (WebAdminPageFactory.USRegulatoryRegulatoryPage.VerifyMessageDepositRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Regulation DD checkbox is selected in U.S Regulatory Page.", "DDAcheckboxSelected", "True", appHandle);
                }
                else
                {
                    Report.Fail("Regulation DD checkbox is not selected in U.S Regulatory Page.", "DDAcheckboxNotSelected", "True", appHandle, true);
                }
            }
        }
        public virtual void EnterInstititionVariableOption(bool ACHStopRemovalCechbox)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Accounts"), Data.Get("Deposit"));
            WebAdminPageFactory.InstitutionVariablePage.ClickonACHStopRemovalCheckbox(ACHStopRemovalCechbox);
            WebAdminPageFactory.InstitutionVariablePage.SelectSubmitButton();
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Institution Variable Page option updated ", "InstitionVariableOptionSelected", "True", appHandle);
            }
            else

            {
                Report.Fail("Institution Variable Page option is not updated ", "InstitionVariableOptionNotSelected", "True", appHandle, true);
            }
        }

        public virtual void UpdateRatesToInterestIndex(string IndexType, string InterestIndex, string EffectiveDate = "", string BasisIndexRate = "", string ComparativeIndexAccountLevelRate = "", string ComparativeIndexIndexLevelRate = "", string TiredIndexRateDetailsPipeDelimited = "", bool AnticipatedONorOFF = true, string BalancePipeDelimitedRate = "", bool DayendONorOFF = true)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
            WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(InterestIndex);
            WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
            WebAdminPageFactory.IndexListPage.ClickOnAddButton();
            if (string.IsNullOrEmpty(EffectiveDate))
            {
                EffectiveDate = this.GetApplicationDate();
            }
            WebAdminPageFactory.IndexListPage.EnterEffectiveDate(EffectiveDate);
            Report.Info(EffectiveDate + " has been entered as entered as effective date.", "effectivedate", "True", appHandle);
            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();

            switch (IndexType)
            {
                case "0 - Basis Index":
                    if (string.IsNullOrEmpty(BasisIndexRate))
                    {
                        BasisIndexRate = "10";
                    }
                    WebAdminPageFactory.IndexListPage.EnterRateORIndex(BasisIndexRate, AnticipatedONorOFF, DayendONorOFF);
                    Report.Info(BasisIndexRate + " has been entered as entered as basis index interest rate.", "basisindexinterestrate", "True", appHandle);
                    break;

                case "":
                    
                    break; 
            }
            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            if (WebAdminPageFactory.IndexAddPage.VerifyMessageInInterestAddPage("Rates have been added to the index " + InterestIndex + " in anticipated mode.") ||
            WebAdminPageFactory.IndexAddPage.VerifyMessageInInterestAddPage("Rates have been added to the index " + InterestIndex + "."))
            {
                Report.Pass("Rates have been added to the index " + InterestIndex + ".", "interestrateadd", "True", appHandle);
            }
            else
            {
                Report.Fail("Rates have not been added to the index " + InterestIndex + ".", "interestrateaddFail", "True", appHandle, true);
            }
        }
        public virtual string CreateGeneralLedgerAccount(string GLType, string Description, bool BaseLedgerAccountONorOFF = false)
        {
            string GlAccount = "";
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("General Ledger") + "|" + Data.Get("Accounts"));
            GlAccount = WebAdminPageFactory.GeneralLedgerAccountPage.CreateGLAccount(GLType, Description, BaseLedgerAccountONorOFF);
            WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.GeneralLedgerAccountPage.IsProdExistsMsg())
            {
                for (int i = 1; i <= 10; i++)
                {
                    WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnCancelButton();
                    GlAccount = WebAdminPageFactory.GeneralLedgerAccountPage.CreateGLAccount(GLType, Description, BaseLedgerAccountONorOFF);
                    WebAdminPageFactory.WebAdminProductCopyPage.ClickOnSubmitButton();
                    if (!WebAdminPageFactory.GeneralLedgerAccountPage.IsProdExistsMsg())
                    {
                        Report.Info("General ledger account number already exists", "prodcopyDataexist", "True", appHandle);
                        break;
                    }
                    else
                    {
                        continue;
                    }

                }
            }
            if (WebAdminPageFactory.GeneralLedgerAccountPage.VerifyMessageInInterestAddPage(Data.Get("GLAccountSuccess")))
            {
                Report.Pass(GlAccount + "GL Account created successfully", "GLAccountCretaed", "True", appHandle);
            }
            else
            {
                Report.Fail(GlAccount + "GL Account not created successfully", "GLAccountNotCreated", "True", appHandle, true);
            }
            return GlAccount;
        }
        public virtual void VerifyDataInGeneralLedgerSetCodeTable(string productclass, string productgroup, string refColumnValuesSemicolonDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("General Ledger") + "|" + Data.Get("Set Codes"));
            WebAdminPageFactory.GeneralLedgerAccountPage.SelectProductClassGroup(productclass, productgroup);
            WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnSearchButton();

            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (refColumnValuesSemicolonDelimited.Contains("|"))
            {
                arr = refColumnValuesSemicolonDelimited.Split('|');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split(';')) + " is captured successfully in General Ledger set code table in WebAdmin.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", refColumnValuesSemicolonDelimited.Split(';')) + " is captured successfully in general ledger set code table in WebAdmin.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebAdminPageFactory.GeneralLedgerAccountPage.VerifyDataInSetCode(refColumnValuesSemicolonDelimited))
            {
                Report.Pass(msg, "GlSetcodeTableValueChecked", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "GlSetcodeTableValueNotChecked", "True", appHandle, true);
            }
        }
        public virtual void AddAssetCatagory(string productclass, string AssetClass, string glsetcode, string AdditionalDetailLabelnameLabelValueByPipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("General Ledger") + "|" + Data.Get("Reclassification/Provision Set Codes"));
            WebAdminPageFactory.GeneralLedgerAccountPage.SelectSetCodes(productclass, AssetClass);
            string[] assetnewValue = AssetClass.Split('-');
            string assetclass = assetnewValue[0];
            string[] setcodenew = glsetcode.Split('-');
            string setcode = setcodenew[0];
            WebAdminPageFactory.GeneralLedgerAccountPage.VerifyGlSetcodeExistsInTable(setcode);
            WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnAddButton();
            WebAdminPageFactory.GeneralLedgerAccountPage.EnterReclassificationDepositType(glsetcode, AdditionalDetailLabelnameLabelValueByPipeDelimited);
            WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnSubmitButton();

            if (WebAdminPageFactory.GeneralLedgerAccountPage.VerifyDataInSetCode("G/L Set Code " + setcode + "for Asset Class " + assetclass + "added."))
            {
                Report.Pass("G/L setcode for Asset Class Added Successfully", "AssetCatagoryAdded", "True", appHandle);
            }
            else
            {
                Report.Fail("G/L setcode for Asset Class not Added Successfully", "AssetcatagoryNotAdded", "True", appHandle, true);
            }

        }
        public virtual void ModifyAssetCatagory(string productclass, string AssetClass, string glsetcode, string AdditionalDetailLabelnameLabelValueByPipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("General Ledger") + "|" + Data.Get("Reclassification/Provision Set Codes"));
            WebAdminPageFactory.GeneralLedgerAccountPage.SelectSetCodes(productclass, AssetClass);
            WebAdminPageFactory.GeneralLedgerAccountPage.SelectGlSetCode(glsetcode);
            WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnEditButton();
            WebAdminPageFactory.GeneralLedgerAccountPage.EditReclassificationDepositType(AdditionalDetailLabelnameLabelValueByPipeDelimited);
            WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnSubmitButton();
            string[] assetnewValue = AssetClass.Split('-');
            string assetclass = assetnewValue[0];
            if (WebAdminPageFactory.GeneralLedgerAccountPage.VerifyDataInSetCode("G/L Set Code " + glsetcode + " for Asset Class " + assetclass + "modified."))
            {
                Report.Pass("G/L setcode for Asset Class is Modified Successfully", "AssetCatagoryModified", "True", appHandle);
            }
            else
            {
                Report.Fail("G/L setcode for Asset Class is not modified Successfully", "AssetcatagoryNotModified", "True", appHandle, true);
            }

        }
        public virtual void DeleteAssetCatagory(string productclass, string AssetClass, string glsetcode)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("General Ledger") + "|" + Data.Get("Reclassification/Provision Set Codes"));
            WebAdminPageFactory.GeneralLedgerAccountPage.SelectSetCodes(productclass, AssetClass);
            WebAdminPageFactory.GeneralLedgerAccountPage.SelectGlSetCode(glsetcode);
            WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnDeleteButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            if (WebAdminPageFactory.GeneralLedgerAccountPage.VerifyDataInSetCode("The Set Codes for the selected Asset Class has been deleted."))
            {
                Report.Pass("G/L setcode for Asset Class is deleted Successfully", "AssetCatagoryDeleted", "True", appHandle);
            }
            else
            {
                Report.Fail("G/L setcode for Asset Class is not deleted Successfully", "AssetcatagorynotDeleted", "True", appHandle, true);
            }

        }
        public virtual void SelectLinkFromLeftPaneInWebAdmin(string MenuNameLinkNameDelimitedByPipe)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(MenuNameLinkNameDelimitedByPipe);
            Report.Info("The Specified Link is selected from left pane", "panepass", "True", appHandle);
        }

        public virtual void performprerequisitestep()
        {
            WebAdminPageFactory.ContextFieldListPage.Performprerequisitestep();

        }

        public virtual void EditUserclass(string userclassname)
        {
            WebAdminPageFactory.UserClassListPage.SelectUserClassFromTable(userclassname);
            WebAdminPageFactory.EditUserClassPage.ClickOnSelfEntitlementCheckbox();
            WebAdminPageFactory.EditUserClassPage.ClickOnSubmitButton();
            bool retval = WebAdminPageFactory.EditUserClassPage.CheckSuccessMessage();
            if (retval)
            {
                Report.Pass("The Userclass " + userclassname + " is modified successfully", "modpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Userclass " + userclassname + " is not modified", "modfail", "True", appHandle);


            }


        }

        public virtual void EditUserClassForUpdatingSelfEntitlement(string userclassname)
        {
            WebAdminPageFactory.UserClassListPage.SelectUserClassFromTable(userclassname);
            WebAdminPageFactory.UserClassListPage.SelectSelfEntitlementCheckbox();
            WebAdminPageFactory.UserClassListPage.ClickOnSubmitbutton();
            bool retval = WebAdminPageFactory.UserClassListPage.CheckSuccessMessage(Data.Get("MsgUserClassModified"));
            if (retval)
            {
                Report.Pass("The Expected Message " + Data.Get("MsgUserClassModified") + " exist in the application", "er", "True", appHandle);
            }
            else
            {
                Report.Fail("The Expected Message " + Data.Get("MsgUserClassModified") + " does not exist in the application", "er", "True", appHandle);

            }


        }


        public virtual void PerformOperationsInProcedureTab()
        {

            WebAdminPageFactory.ContextAndFieldPage.SelectTabInContextFieldPage("Procedure");
            WebAdminPageFactory.ProcedurePage.EnterDetailsForProcedure();

        }

        public virtual void SetValuesInTransactionCodeAuthorization(string userclassvalue)
        {
            WebAdminPageFactory.TransactionCodesPage.EnterDetailsofTransactionCodes("D - Deposit", "SAV - Savings");
            WebAdminPageFactory.TransactionCodesPage.ClickOnSearchButton();
            WebAdminPageFactory.TransactionCodesPage.SelectRadiobuttonBasedonTrancode("D1843");
            WebAdminPageFactory.TransactionCodesPage.ClickOnAuthorizebutton();
            WebAdminPageFactory.TransactionCodeAuthorizationPage.SelectCheckbox(userclassvalue);
            WebAdminPageFactory.TransactionCodeAuthorizationPage.ClickOnSubmitbutton();
            WebAdminPageFactory.TransactionCodeAuthorizationPage.CheckSuccessMessage();

        }

        public virtual void ClickOnLinkInCopyAllPermisssions(string linkname)
        {
            WebAdminPageFactory.CopyUserClassPermissionPage.ClickOnLinkBasedOnName(linkname);
        }

        public virtual void EnterDetailsForUserClassPermission(string fromuserclass, string touserclass, string detailstobeselectedbydelimsemicoln = "")
        {
            Application.WebAdmin.SelectLinkFromLeftPaneInWebAdmin("Security Configuration|User/Userclass Maintenance");
            WebAdminPageFactory.UserListPage.ClickOnTabUserClassPermission();
            bool retval = WebAdminPageFactory.CopyUserClassPermissionPage.EnterDetailsForUserClassPermisssion(fromuserclass, touserclass, detailstobeselectedbydelimsemicoln);
            if (retval)
            {
                Report.Pass("The Copy Permisssion details are entered", "cpperpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Copy Permisssion details are not entered", "cpperfail", "True", appHandle);

            }

        }


        public virtual void UpdateDataInStatementsTabForTDSetup(string summaryval)
        {
            if (WebAdminPageFactory.WebAdminProductStatementsPage.UpdateDataInStatementsTab(summaryval))
            {
                Report.Pass("The Data has been entered successfully in statements tab", "stmt", "True", appHandle);
            }
            else
            {
                Report.Fail("The Data is not entered successfully in statements tab", "stmt1", "True", appHandle);
            }

        }

        public virtual void UpdateDataInInterestTabForTDSetup(string accralbaseval, string accrualmethodval)
        {
            if (WebAdminPageFactory.DepositInterestCalculationPage.UpdateDataInInterestTabForTDSetup(accralbaseval, accrualmethodval))
            {
                Report.Pass("The Data is entered successfully in interest tab", "int", "True", appHandle);
            }
            else
            {
                Report.Fail("The Data is not entered in interest tab", "int1", "True", appHandle);

            }
        }


        public virtual void UpdateDataInPostingOptionsTabForTDSetup()
        {
            WebAdminPageFactory.DepositInterestCalculationPage.SelectSpecifiedSublinkInInterestTab("Posting Options");
            if (WebAdminPageFactory.DepositPostingOptionsPage.UpdateDataInPostingOptionsTabForTDSetup())
            {
                Report.Pass("The Data is entered in Posting Options tab", "post", "True", appHandle);
            }
            else
            {
                Report.Fail("The Data is not entered in Posting Options tab", "post1", "True", appHandle);
            }
        }

        public virtual string CreateNewUserClassByCopy(string exustingUserClass)
        {
            WebAdminPageFactory.UserClassListPage.CopyExistingUserClass(exustingUserClass);
            string newuserclass = WebAdminPageFactory.CopyUserClassPage.EnterValuesForNewUserClass();
            WebAdminPageFactory.UserClassListPage.CheckSuccessMessageForCopyClass();
            return newuserclass;

        }

        public virtual void CheckNegaivtiveScenarioForScriptCopyUserclassAndAllPermissions002(string fromuserclass, string touserclass)
        {
            WebAdminPageFactory.UserClassListPage.ClickOnTabUserClassPermission();
            WebAdminPageFactory.CopyUserClassPermissionPage.CheckNegaivtiveScenarioForScriptCopyUserclassAndAllPermissions002(fromuserclass, touserclass);
            WebAdminPageFactory.UserClassListPage.CheckNegaivtiveScenarioForScriptCopyUserclassAndAllPermissions002another(fromuserclass, touserclass);


        }

        public virtual void UpdateDataInRateDeterminationTabForTDSetup()
        {
            WebAdminPageFactory.DepositInterestCalculationPage.SelectSpecifiedSublinkInInterestTab("Rate Determination");
            if (WebAdminPageFactory.DepositRateDeterminationPage.UpdateDataForRateDeterminationForTDSetup())
            {
                Report.Pass("The Data entered in Rate Determination tab successfully", "rt", "True", appHandle);
            }
            else
            {
                Report.Fail("The Data not entered in Rate Determination tab", "rt1", "True", appHandle);

            }
        }

        public virtual void UpdateDataInUSRegulatoryTabForTDSetup(string regval)
        {
            WebAdminPageFactory.USRegulatoryRegulatoryPage.UpdateDataInUSRegulatoryTabForTDSetup(regval);
        }

        public virtual void PerformOperationsUserClassPermissionForCopyUserclassAndAllPermissions002(string newclass, string copyclass)
        {
            WebAdminPageFactory.CopyUserClassPermissionPage.OperationsForCopyUserclassAndAllPermissions002(newclass, copyclass);
        }

        public virtual void SelectDropdownValuesForChannelUserClassContextField(string channelname, string userclassname, string contextname)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem("Security Configuration" + "|" + Data.Get("SetPermisssions"));
            WebAdminPageFactory.ContextAndFieldPage.SelectValuesInContextFieldPage(channelname, userclassname, contextname);
        }

        public virtual void SelectDropdownValueBasedOnLabelInContextFieldPage(string lablename, string permissionvalue, bool isselectintable = false)
        {
            if (isselectintable == false)
                WebAdminPageFactory.ContextAndFieldPage.SelectPermissionDropdownValueBasedOnLabel(lablename, permissionvalue);
            else
                WebAdminPageFactory.ContextAndFieldPage.SelectValueFromDropdownInTable(lablename, permissionvalue);

        }
        public virtual void UpdateDataInStatementTabForCombinedAndEstatementChecbox()
        {
            bool retval = WebAdminPageFactory.WebAdminProductStatementsPage.UpdateDataForStatementTab();
            if (retval)
            {
                Report.Pass("The checkbox combined statement and estatement are checked", "chq", "True", appHandle);
            }
            else
            {
                Report.Fail("The checkbox combined statement and estatement are not checked", "chq1", "True", appHandle);
            }

        }

        public virtual void AddServiceToProduct(string productnumber, string serviceidvalue, bool bankrecmondedflag, bool optionalflag, string priorityval)
        {
            if (WebAdminPageFactory.AddProductServicesPage.AddServicesToProduct(productnumber, serviceidvalue, bankrecmondedflag, optionalflag, priorityval))
            {
                Report.Pass("The Services have been added to Product", "service1", "True", appHandle);
            }
            else
            {
                Report.Fail("The Services not added to Product", "service12", "True", appHandle);
            }

        }

        public virtual void ClickOnCascadeButtonBasedOnLabelInContextFieldPage(string labelname)
        {
            WebAdminPageFactory.ContextAndFieldPage.ClickOnCascadeButtonBasedOnLabel(labelname);
        }
        public virtual void UpdateDetailsForProductInGeneralSection(string description, string startdate, string enddate)
        {
            if (WebAdminPageFactory.GeneralPage.EnterDetailsInGeneralSection(description, startdate, enddate))
            {
                Report.Pass("The Details updated in General Section", "thy", "True", appHandle);
            }
            else
            {
                Report.Fail("The Details not updated in General Section", "thyf", "True", appHandle);

            }
        }

        public virtual void UpdateRatedeterminationDetails(string rateval)
        {
            ClickonTabinProductPage("Interest");
            WebAdminPageFactory.CalculationPage.ClickOnLink("Rate Determination");
            if (WebAdminPageFactory.LoanRateDeterminationPage.EnterRateDeterminationDetails(rateval))
            {
                Report.Pass("The Rate Determination details are entered", "plk", "True", appHandle);
            }
            else
            {
                Report.Fail("The Rate Determination details not entered", "plkf", "True", appHandle);


            }

        }

        public virtual void UpdateDelinquencyCountersDaysDetails(string val1, string val2, string val3, string val4, string val5, string val6, string val7)
        {
            ClickonTabinProductPage("Delinquency");
            WebAdminPageFactory.DelinquencyOptionssPage.ClickOnLink("Counters - Days");
            if (WebAdminPageFactory.DelinquencyCountersDaysPage.EnterDetailsForCounterDays(val1, val2, val3, val4, val5, val6, val7))
            {
                Report.Pass("The Delinquency Data entered", "delp", "True", appHandle);
            }
            else
            {
                Report.Fail("The Delinquency Data not entered", "delf", "True", appHandle);

            }

        }

        public virtual void UpdateDelinquencyOptionsDetails(string latechargemethod6)
        {
            ClickonTabinProductPage("Escrow Analysis");
            ClickonTabinProductPage("Delinquency");
            if (WebAdminPageFactory.DelinquencyOptionssPage.EnterDetailsForOptions(latechargemethod6))
            {
                Report.Pass("The Delinquency Details are entered in options page", "pljp", "True", appHandle);
            }
            else
            {
                Report.Fail("The Delinquency Details not entered in options page", "pljf", "True", appHandle);

            }

        }


        public virtual void UpdateGeneralSectionforDescription(string descriptionval)
        {
            if (WebAdminPageFactory.GeneralPage.EnterValueForDescriptionField(descriptionval))
            {
                Report.Pass("The General Details entered", "gd1", "True", appHandle);
            }
            else
            {
                Report.Fail("The General Details not entered", "gd1f", "True", appHandle);

            }

        }

        public virtual void UpdateNoticeOffsetDaysInDeliquency(string cat1val1, string cat1val2, string cat1val3, string cat1val4, string cat1val5)
        {
            ClickonTabinProductPage("Delinquency");
            WebAdminPageFactory.DelinquencyOptionssPage.ClickOnLink("Notice Offset Days");
            WebAdminPageFactory.DelinquencyNoticeOffsetDaysPage.EnterDetailsForAllFields(cat1val1, cat1val2, cat1val3, cat1val4, cat1val5);

        }

        public virtual void EnterOptionsDetailsForTDSetup(string businessdayoption, string NonaccrualGeneralLedgerSetCode = "", string PrincipalVarianceOptionval = "")
        {
            WebAdminPageFactory.DelinquencyOptionssPage.ClickOnLink("Options");
            WebAdminPageFactory.DelinquencyOptionssPage.EnterOptionsDetailsForTDSetup(businessdayoption, NonaccrualGeneralLedgerSetCode, PrincipalVarianceOptionval);

        }

        public virtual void EnterDetailsForTransactionCodesPaymentPage(string debitprincipalvarpost, string credprincipalvarpost)
        {
            ClickonTabinProductPage("Transaction Codes");
            WebAdminPageFactory.DelinquencyOptionssPage.ClickOnLink("Payments");
            if (WebAdminPageFactory.TransactionCodePaymentsPage.EnterDetailsforPayments(debitprincipalvarpost, credprincipalvarpost))
            {
                Report.Pass("The Details are entered in payments of Transaction Codes", "tcp", "True", appHandle);
            }
            else
            {
                Report.Fail("The Details not entered in payments of Transaction Codes", "tcpf", "True", appHandle);

            }

        }


        public virtual void UpdateCountersDaysDetailsInDelinquencyforTDSetup(string val1, string val2, string val3, string val4, string val5, string val6, string val7)
        {
            ClickonTabinProductPage("Delinquency");
            WebAdminPageFactory.DelinquencyOptionssPage.ClickOnLink("Counters - Days");
            if (WebAdminPageFactory.DelinquencyCountersDaysPage.EnterDetailsForCounterDays(val1, val2, val3, val4, val5, val6, val7))
            {
                Report.Pass("The Details are entered in counter days of delinquency", "dsl", "True", appHandle);
            }
            else
            {
                Report.Fail("The Details are entered in counter days of delinquency", "dslf", "True", appHandle);

            }


        }

        public virtual void EnterNoticeSelectionDetailsInDelinquencyForTDSetup(string val1, string val2, string val3, string val4, string val5)
        {
            ClickonTabinProductPage("Delinquency");
            WebAdminPageFactory.DelinquencyOptionssPage.ClickOnLink("Notice Selection");
            WebAdminPageFactory.DelinquencyNoticeSelectionPage.EnterNoticeSelectionDetailsInDelinquencyForTDSetup(val1, val2, val3, val4, val5);

        }

        public virtual void EnterDetailsForOptionsForSomeFields()
        {
            if (WebAdminPageFactory.DelinquencyOptionssPage.EnterDetails())
            {
                Report.Pass("The Details Entered", "tde", "True", appHandle);
            }
            else
            {
                Report.Pass("The Details Entered", "tdef", "True", appHandle);

            }
        }


        public virtual void ClickOnSubmitInContextField()
        {
            WebAdminPageFactory.ContextAndFieldPage.ClickOnSubmitButton();
            if (appHandle.CheckSuccessMessage(Data.Get("MsgContextPermissionUpdated")))
            {
                Report.Pass("The Context Permission updated successfully", "perpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Context Permission not updated", "perfail", "True", appHandle);

            }
        }


        public virtual string AddRecordForTableInGeneralTableManagment(string tablename, string detailsdelimitedbysemicolon = "", string description = "", string sdate = "", string tableValuePipeDelimited = "", string edate = "", int noOfRec = 0)
        {
            string temp = "";
            string PageHeader = "";
            string PageHeader1 = "";


            bool addrec = false;
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(tablename);

            switch (tablename)
            {
                case "UTBLMXUCLS1":

                    if (tablename.Equals("UTBLMXUCLS1"))
                    {
                        addrec = WebAdminPageFactory.MaximumUserClassLimitsPage.EnterRecordsForTableUTBLMXUCLS1(detailsdelimitedbysemicolon);
                        if (addrec)
                        {
                            Report.Pass("Records has been added to  General Table Managment", "recpass", "True", appHandle);
                        }
                        else
                        {
                            Report.Pass("Records has not been added to General Table Managment", "recfail", "True", appHandle);
                        }
                    }
                    break;

                case "UTBLMXUCLS2":

                    if (tablename.Equals("UTBLMXUCLS2"))
                    {
                        addrec = WebAdminPageFactory.MaximumUserClassLimitsPage.EnterRecordsForTableUTBLMXUCLS2(detailsdelimitedbysemicolon);
                        if (addrec)
                        {
                            Report.Pass("Records has been added to  General Table Managment", "recpass", "True", appHandle);
                        }
                        else
                        {
                            Report.Pass("Records has not been added to General Table Managment", "recfail", "True", appHandle);
                        }
                    }
                    break;
                case "UTBLTRNGRPLT":

                    if (tablename.Equals("UTBLTRNGRPLT"))
                    {
                        temp = WebAdminPageFactory.LoanFeePlanTransactionCodesPage.EnterRecordsForTableUTBLTRNGRPLT(description, detailsdelimitedbysemicolon);
                        PageHeader = WebAdminPageFactory.LoanFeePlanTransactionCodesPage.GetPageHeader();
                        PageHeader1 = PageHeader.Remove(PageHeader.Length - 1, 1);
                        if (WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyMessageInLoanFeePage("The " + PageHeader + " has been created.") ||
                        WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyMessageInLoanFeePage("The " + PageHeader1 + " has been created."))
                        {
                            Report.Pass("Record has been added to  General Table Managment", "recpass", "True", appHandle);
                        }
                        else
                        {
                            Report.Fail("Record has not been added to General Table Managment", "recfail", "True", appHandle);
                        }
                    }
                    break;
                case "UTBLLNFEEGRP":

                    if (tablename.Equals("UTBLLNFEEGRP"))
                    {
                        temp = WebAdminPageFactory.LoanFeePlanTransactionCodesPage.EnterRecordsForTableUTBLLNFEEGRP(detailsdelimitedbysemicolon);
                        PageHeader = WebAdminPageFactory.LoanFeePlanTransactionCodesPage.GetPageHeader();
                        PageHeader1 = PageHeader.Remove(PageHeader.Length - 1, 1);
                        if (WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyMessageInLoanFeePage("The " + PageHeader + " has been created.") ||
                        WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyMessageInLoanFeePage("The " + PageHeader1 + " has been created."))
                        {
                            Report.Pass("Record has been added to  General Table Managment", "recpass", "True", appHandle);
                        }
                        else
                        {
                            Report.Fail("Record has not been added to General Table Managment", "recfail", "True", appHandle);
                        }
                    }
                    break;
                case "UTBLPHC":

                    if (tablename.Equals("UTBLPHC"))
                    {
                        temp = WebAdminPageFactory.GeneralTableManagementPage.EnterPermanentHoldCode();

                    }
                    break;
                case "PDAG":
                    if (tablename.Equals("PDAG"))
                    {
                        WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                        WebAdminPageFactory.PaymentApplicationPage.AddDetailsInPaymentDueActionGrid(detailsdelimitedbysemicolon, sdate, tableValuePipeDelimited);
                        if (WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyMessageInLoanFeePage("The Payment Due Action Grid has been created."))
                        {
                            Report.Pass("The Payment Due Action Grid has been added.", "recpass", "True", appHandle);
                        }
                        else
                        {
                            Report.Fail("The Payment Due Action Grid has not been added.", "recfail", "True", appHandle);
                        }
                    }
                    break;
                case "LNTRS":
                    if (tablename.Equals("LNTRS"))
                    {
                        WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                        WebAdminPageFactory.LoanFeePlanTransactionCodesPage.AddDetailsForEscrowType(detailsdelimitedbysemicolon, sdate);

                    }
                    break;
                case "LNTRS1":
                    if (tablename.Equals("LNTRS1"))
                    {
                        WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                        WebAdminPageFactory.LoanFeePlanTransactionCodesPage.AddDetailsForEscrowPayeeDefinition(detailsdelimitedbysemicolon);
                    }
                    break;
                case "LNPAS2":
                    if (tablename.Equals("LNPAS2"))
                    {
                        WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                        WebAdminPageFactory.LoanFeePlanTransactionCodesPage.AddDetailsForLNPAS2(detailsdelimitedbysemicolon, sdate, edate);
                    }
                    break;
                case "LNPATH":
                    if (tablename.Equals("LNPATH"))
                    {
                        WebAdminPageFactory.WebAdminMasterPage.ClickOnAddButton();
                        Profile7CommonLibrary.EnterDataByLabelNameLabelValue(detailsdelimitedbysemicolon);
                        WebAdminPageFactory.LoanFeePlanTransactionCodesPage.ClickOnSubmitButton();
                        if (WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyMessageInLoanFeePage("The Payment Application Path has been created."))
                        {
                            Report.Pass("The Payment Due Action Grid has been added.", "recpass", "True", appHandle);
                        }
                        else
                        {
                            Report.Fail("The Payment Due Action Grid has not been added.", "recfail", "True", appHandle);
                        }
                    }
                    break;
                case "ESCGRP":
                    if (tablename.Equals("ESCGRP"))
                    {
                        WebAdminPageFactory.WebAdminMasterPage.ClickAddButton();
                        Profile7CommonLibrary.EnterDataByLabelNameLabelValue(detailsdelimitedbysemicolon);
                        WebAdminPageFactory.LoanFeePlanTransactionCodesPage.ClickOnSubmitButton();
                    }
                    break;
                case "UTBLTRNGRPT":
                    if (tablename.Equals("UTBLTRNGRPT"))
                    {
                        temp = WebAdminPageFactory.AddServiceFeeTransactionCodeGroupPage.AddRecordForTableUTBLTRNGRPT(sdate, description, noOfRec, detailsdelimitedbysemicolon);
                    }
                    break;
            }

            return temp;
        }

        public virtual void VerifyDropdownValuesOfContextInContextFieldPage(string channelname, string userclassname, string contextname, string contextlabelname, string permissionval)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem("Security Configuration" + "|" + Data.Get("SetPermisssions"));
            WebAdminPageFactory.ContextAndFieldPage.SelectValuesInContextFieldPage(channelname, userclassname, contextname);
            bool retval = WebAdminPageFactory.ContextAndFieldPage.CheckPermissionValueInDropdown(contextname, permissionval);
            if (retval)
            {
                Report.Pass("The expected values " + permissionval + " Present in dropdown", "permisssionpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The expected values " + permissionval + " Not Present in dropdown", "permisssionfail", "True", appHandle);

            }
        }


        public virtual void CheckDropdownValueBasedOnLabelInContextField(string label, string permissionvalue)
        {
            bool retval = WebAdminPageFactory.ContextAndFieldPage.CheckValuePresentInDropdwonBasedOnLabel(label, permissionvalue);
            if (retval)
            {
                Report.Pass("The expected value " + permissionvalue + "is Present in dropdown", "valpasstemp", "True", appHandle);
            }
            else
            {
                Report.Fail("The expected value " + permissionvalue + "is not Present in dropdown", "valfailtemp", "True", appHandle);
            }
        }

        public virtual void VerifyNegativeScenariosForContextField()
        {
            WebAdminPageFactory.ContextFieldListPage.CheckNegativeScenariosSet();
        }


        public virtual void EnterValuesForContextNameCustomerPersonalGenralTab()
        {
            bool retval = WebAdminPageFactory.ContextFieldListPage.EnterValuesForContextNameCustomerPersonalGenralTab();
            if (retval)
            {
                Report.Pass("The Customer Personal Genral Tab information has been updated successfully for multiple fields", "mulpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Customer Personal Genral Tab information has not been updated for multiple fields", "mulfail", "True", appHandle);

            }

        }

        public virtual void SelectValueFromContextDropdownInContextField(string value)
        {
            WebAdminPageFactory.ContextFieldListPage.SelectValueFromContextDropDown(value);

        }


        public virtual string CreateNewUserClas(string menulinkagename)
        {


            Application.WebAdmin.NavigatetoUserClassMaintenancePage();
            WebAdminPageFactory.UserClassListPage.ClickOnAddButton();
            string newuserclass = WebAdminPageFactory.AddUserClassPage.CreateNewUserClass(menulinkagename);
            if (!string.IsNullOrEmpty(newuserclass))
            {
                Report.Pass("The UserClass is successfully created", "ucls", "True", appHandle);
            }
            else
            {
                Report.Fail("The UserClass is not created", "uclsfail", "True", appHandle);

            }
            return newuserclass;
        }


        public virtual void PerformOperationsinprocedureTab(string authvalue, string userclassvalue, string transactioncodeval, string transactioncodegroupval, string valuetocheck)
        {
            WebAdminPageFactory.ContextAndFieldPage.SelectTabInContextFieldPage("Procedure");
            WebAdminPageFactory.ProcedurePage.SelectValueFromAuthorizationdropdown(authvalue);
            WebAdminPageFactory.ProcedurePage.CheckDropdownvalueexist(userclassvalue);
            SelectLinkFromLeftPaneInWebAdmin("Table Configuration|Transaction Codes");
            WebAdminPageFactory.TransactionCodesPage.EnterDetailsofTransactionCodes(transactioncodeval, transactioncodegroupval);
            WebAdminPageFactory.TransactionCodesPage.ClickOnSearchButton();
            WebAdminPageFactory.TransactionCodesPage.SelectRadiobuttonBasedonTrancode("D1843");
            WebAdminPageFactory.TransactionCodesPage.ClickOnAuthorizebutton();
            WebAdminPageFactory.TransactionCodeAuthorizationPage.CheckTableDataExist(valuetocheck);

        }


        public virtual void UpdatePostingFrequencyInPostingOptions(string sProductClass, string sProductGroup, string sProductNumber, string Frequency)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Posting Options"));
            WebAdminPageFactory.DepositPostingOptionsPage.updatePostingOptionsPostingFrequency(Frequency);
            WebAdminPageFactory.DepositInterestCalculationPage.SelectSubmitButton();
            if (WebAdminPageFactory.DepositInterestCalculationPage.VerifyMessageDepositInterestCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Posting Frequency is updated in Interest Posting option Page.", "InterestPostingOptionfieldUpdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Posting Frequency is  not updated in Interest Posting option Page.", "InterestPostingOptionfieldNotUpdated", "True", appHandle, true);
            }

        }
        public virtual void UpdateMinimumBalanceToAccureInCalculationPage(string sProductClass, string sProductGroup, string sProductNumber, string MinimumBalance)
        {

            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"));
            if (WebAdminPageFactory.DepositInterestCalculationPage.WaitUntilInterestPageloads())
            {
                WebAdminPageFactory.DepositInterestCalculationPage.UpdateMinimumBalance(MinimumBalance);
                WebAdminPageFactory.DepositInterestCalculationPage.SelectSubmitButton();
                if (WebAdminPageFactory.DepositInterestCalculationPage.VerifyMessageDepositInterestCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Minimum Balance to Accrue is updated in Interest Calculation Page.", "InterestCalculationfieldUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Minimum Balance to Accrue is not updated in Interest Calculation Page..", "InterestCalculationfieldNotUpdated", "True", appHandle, true);
                }
            }
        }

        public virtual void UpdateMinimunDaysRequiredForPaymentOrderInPaymentSystemPage(string OrderDays)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Payment System"));
            WebAdminPageFactory.TransactionProcessingPaymentSystemPage.UpdateMinimumDaysReqForPaymentOrder(OrderDays);
            WebAdminPageFactory.TransactionProcessingPaymentSystemPage.ClickOnSubmit();
            if (WebAdminPageFactory.TransactionProcessingPaymentSystemPage.VerifyMessageInWebAdminPaymentSystemPage())
            {
                Report.Pass("Minimum Days Required for Payment Order was updated In Payment System Page", "PaymentSystemPage", "true", appHandle);

            }
            else
            {
                Report.Fail("Minimum Days Required for Payment Order was not updated In Payment System Page", "PaymentSystemPagefails", "true", appHandle, true);
            }


        }
        public virtual void UpdateDebitAuthorizationOptionInPaymentSystem(bool CheckBoXOnorOff)
        {

            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Payment System"));
            WebAdminPageFactory.TransactionProcessingPaymentSystemPage.ClickOnDebitAuthorizationCheckBox(CheckBoXOnorOff);
            WebAdminPageFactory.TransactionProcessingPaymentSystemPage.ClickOnSubmit();
            if (WebAdminPageFactory.TransactionProcessingPaymentSystemPage.VerifyMessageInWebAdminPaymentSystemPage())
            {
                Report.Pass("Debit Authorization Option in Payment System page under Transaction Processing is successfully updated.", "PaymentSystem", "true", appHandle);
            }
            else
            {
                Report.Fail("Debit Authorization Option in Payment System page under Transaction Processing is not successfully updated.", "PaymentSystemfail", "true", appHandle, true);
            }

        }
        public virtual void UpdateFundsTransferPaymentOrderOption(string sProductClass, string sProductGroup, string sProductNumber, bool ONorOFF)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.ClickOnFundsTransferPermitPaymentOrderCheckbox(ONorOFF);
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.ClickOnFundsTransferPermitCollectionOrderCheckbox(ONorOFF);
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.ClickOnFundsTransferPermitDirectDebitCheckbox(ONorOFF);
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.EnterReconcillationDetails();
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.select_submit_button();
            if (WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.VerifyMessageInWebAdminProductTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Payment order is updated in Product Transaction Processing Page.", "Permitpaymentorder", "True", appHandle);
            }
            else
            {
                Report.Fail("Payment order is not updated in Product Transaction Processing Page.", "Permitpaymentorderfail", "True", appHandle, true);
            }
        }
        public virtual void UpdateMaximumFundsTransferPerDay(string sProductClass, string sProductGroup, string sProductNumber, string NoofTransfer = null)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.UpdateMaximumFundsTrnsferPerDay(NoofTransfer);
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.EnterReconcillationDetails();
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.select_submit_button();
            if (WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.VerifyMessageInWebAdminProductTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Maximum Funds Transfer Per day is updated in Product Transaction Processing Page.", "Permitpaymentorder", "True", appHandle);
            }
            else
            {
                Report.Fail("Maximum Funds Transfer Per day is not updated in Product Transaction Processing Page.", "Permitpaymentorderfail", "True", appHandle, true);
            }
        }

        public virtual void UpdateStatementFrequencyInProductsStatements(string ProductClass, string ProductGroup, string ProductNumber, string frequency)
        {
            GetProduct(ProductClass, ProductGroup, ProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Statements"));
            WebAdminPageFactory.WebAdminProductStatementsPage.EnterStatementFrequency(frequency);
            WebAdminPageFactory.WebAdminProductStatementsPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.WebAdminProductStatementsPage.VerifyMessageInWebAdminProductStatementsPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Statement Frequency is updated as " + frequency + " in Products | Statements page", "freupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Statement Frequency is not updated as " + frequency + " in Products | Statements page", "freupdate", "True", appHandle, true);
            }
        }

        public virtual string CreateTableConfigurationRateSchedule(string TermIncrement, string RoundingOption, string CalculationOption, string RateSchedule = "", string Description = "")
        {
            string OutputRateSchedule = "";
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Rate Schedules"));
            WebAdminPageFactory.TableConfigurationRatesSchedulePage.WaitUntilRateSchedulePageLoads();
            WebAdminPageFactory.TableConfigurationRatesSchedulePage.ClickOnAddButton();
            OutputRateSchedule = WebAdminPageFactory.TableConfigurationRatesSchedulePage.EnterRateScheduleDetails(TermIncrement, RoundingOption, CalculationOption, RateSchedule, Description);
            string tempRateSchedule = WebAdminPageFactory.TableConfigurationRatesSchedulePage.ClickOnSubmitButton();
            if (!string.IsNullOrEmpty(tempRateSchedule))
            {
                OutputRateSchedule = tempRateSchedule;
            }
            if (WebAdminPageFactory.TableConfigurationRatesSchedulePage.VerifyRateScheduleInRatesScheduleList(OutputRateSchedule)
            && WebAdminPageFactory.TableConfigurationRatesSchedulePage.VerifyMessageInRateSchedulesPage(Data.Get("The rate schedule has been created.")))
            {
                Report.Pass(OutputRateSchedule + " is added in Rate Schecule list in WebAdmin.", "ratescheduleadd", "True", appHandle);
            }
            else
            {
                Report.Fail(OutputRateSchedule + " is not added in Rate Schecule list in WebAdmin.", "ratescheduleadd", "True", appHandle, true);
            }
            return OutputRateSchedule;
        }
        public virtual void AddRatesToRateSchedule(string RateSchedule, string RateDetailsPipeDelimited, string EffectiveDate = "", string MinimumBalance = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Rate Schedules"));
            if (WebAdminPageFactory.TableConfigurationRatesSchedulePage.VerifyRateScheduleInRatesScheduleList(RateSchedule))
            {
                WebAdminPageFactory.TableConfigurationRatesSchedulePage.SelectRateScheduleInRatesScheduleList(RateSchedule);
                WebAdminPageFactory.TableConfigurationRatesSchedulePage.ClickOnRatesButton();
                bool DataEntered = WebAdminPageFactory.TableConfigurationRatesSchedulePage.EnterRatesInRateScheduleEffectiveDateList(RateDetailsPipeDelimited, EffectiveDate, MinimumBalance);
                if (DataEntered)
                {
                    WebAdminPageFactory.TableConfigurationRatesSchedulePage.SelectSubmitButton();

                    if (WebAdminPageFactory.TableConfigurationRatesSchedulePage.VerifyMessageInRateSchedulesPage(Data.Get("The rate schedule has been modified.")))
                    {
                        Report.Pass("| " + Data.Get("The rate schedule has been modified.") + " | is displayed.", "ratesrateschedule", "True", appHandle);

                    }
                    else
                    {
                        Report.Fail("| " + Data.Get("The rate schedule has been modified.") + " | is displayed.", "ratesrateschedule", "True", appHandle, true);
                    }
                }
            }
            else
            {
                Report.Fail("Specified rate schedule = " + RateSchedule + " is not available in Rate Schedule List. Please check the iput parameter.", "rateschedulenotpresent", "True", appHandle, true);
            }
        }
        ////
        public virtual string CreateGLAccount(string AccountType, Boolean flag, int NumberofAccounts)
        {
            if (appHandle.GetTitle().Contains("General Ledger Account List")) { }
            else
            {
                WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("General Ledger") + "|" + Data.Get("Accounts"));
            }
            string Accounts = WebAdminPageFactory.WebAdminGeneralLedgerPage.CreateGLAccount(AccountType, NumberofAccounts, false);
            if (!string.IsNullOrEmpty(Accounts))
            {
                Report.Pass("General Ledger Account's Generated Successfully.", "CreateGLAccount", "True", appHandle);
            }
            else
            {
                Report.Fail("General Ledger Account's not Generated Successfully.", "CreateGLAccount", "True", appHandle, true);
            }
            return Accounts;
        }
        public virtual string CreateGLSetCodes(string ProductClass, string ProductGroup, string BalanceDetailswithSemecolonDelimited)
        {
            if (appHandle.GetTitle().Contains("General Ledger Set Code List")) { }
            else
            {
                WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("General Ledger") + "|" + Data.Get("Set Codes"));
            }
            string GLSetCodeNumber = WebAdminPageFactory.WebAdminGeneralLedgerPage.CreateSetCodes(ProductClass, ProductGroup, BalanceDetailswithSemecolonDelimited);
            if (!string.IsNullOrEmpty(GLSetCodeNumber))
            {
                Report.Pass("General Ledger Code's Generated Successfully.", "CreateGLSetCodes", "True", appHandle);
            }
            else
            {
                Report.Fail("General Ledger Code's not Generated Successfully.", "CreateGLSetCodes", "True", appHandle, true);
            }
            return GLSetCodeNumber;
        }

        public virtual void UpdateTransactionCodesAdjustments(string sProductClass = "", string sProductGroup = "", string sProductNumber = " ", bool AllowNegativeInterest = false, string NegativeInterestAccrualOption = "", string NegativeInterestPostingOption = "", string NegativeInterestPostingFrequency = "", bool AccruePositiveInterestOnNegativeBalance = false, bool PostZeroNetInterest = false)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Negative Interest"));
            if (WebAdminPageFactory.DepositPostingOptionsPage.WaitUntilNegativeInterestPageloads())
            {
                WebAdminPageFactory.DepositPostingOptionsPage.EnterNegativeInterestDetails(AllowNegativeInterest, NegativeInterestAccrualOption, NegativeInterestPostingOption, NegativeInterestPostingFrequency, AccruePositiveInterestOnNegativeBalance, PostZeroNetInterest);
                WebAdminPageFactory.DepositPostingOptionsPage.SelectSubmitButton();
                if (WebAdminPageFactory.DepositPostingOptionsPage.VerifyMessageDepositInterestPostingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Negative Interest fields are updated in Negative Interest Page", "PaymentOptionFieldUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Negative Interest fields are not updated in Negative Interest Page.", "PaymentOptionFieldNotUpdated", "True", appHandle, true);
                }
            }
        }
        /// <summary>
        /// This Method is used to update Nominal Rate, Variable Rate Index and Change Frequency in Interest Rate Determination Page.
        /// 
        /// </summary>
        /// <param name="sProductClass"></param>
        /// <param name="sProductGroup"></param>
        /// <param name="sProductNumber"></param>
        /// <param name="FRate"></param>
        /// <param name="VRIndex"></param>
        /// <param name="CFOption"></param>
        public virtual void UpdateDepositInterestRateDeterminationPageOption(string sProductClass, string sProductGroup, string sProductNumber, string FRate = "", string VRIndex = "", string CFOption = "", string AdjustableRateLimitsMaximumRateField = "", string VariableRateLimitsMinimumRateField = "", string AdjustableRatePositiveInterestSpreadField = "", string AdjustableRateInterestSpreadField = "",string matrix = "",string UnAuthNegSpread="",string AuthNegSpread="")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Rate Determination"));
            if (WebAdminPageFactory.WebAdminDepositRateDeterminationPage.WaitUntilRateDeterminationPageLoad())
            {
                WebAdminPageFactory.WebAdminDepositRateDeterminationPage.EnterRateDeterminationOptions(FRate, VRIndex, CFOption, AdjustableRateLimitsMaximumRateField, VariableRateLimitsMinimumRateField, AdjustableRatePositiveInterestSpreadField, AdjustableRateInterestSpreadField,matrix,UnAuthNegSpread,AuthNegSpread);
                WebAdminPageFactory.WebAdminDepositRateDeterminationPage.SelectSubmitButton();
                if (WebAdminPageFactory.WebAdminDepositRateDeterminationPage.VerifyMessageDepositRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Nominal Rate, Variable Rate Index and Change Frequency fields are updated in Rate Determination Page.", "RateDeterminationFieldUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Nominal Rate, Variable Rate Index and Change Frequency fields are not updated in Rate Determination Page.", "RateDeterminationFieldNotUpdated", "True", appHandle, true);
                }
            }
        }
        public virtual void UpdateInterestPostingOptionPageDetails(string sProductClass = "", string sProductGroup = "", string sProductNumber = " ", string DisbursmentOpt = "", string PostingFreq = "", string MinBalancetoCreditInterest = "")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Posting Options"));
            if (WebAdminPageFactory.DepositPostingOptionsPage.WaitUntilInterestPostingOptionPageloads())
            {
                WebAdminPageFactory.DepositPostingOptionsPage.EnterInterestPostingOptions(DisbursmentOpt, PostingFreq, MinBalancetoCreditInterest);
                WebAdminPageFactory.DepositPostingOptionsPage.SelectSubmitButton();
                if (WebAdminPageFactory.DepositPostingOptionsPage.VerifyMessageDepositInterestPostingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Disbursment Option and Posting Frequency fields are updated in Posting Option Page", "PaymentOptionFieldUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Disbursment Option and Posting Frequency fields are not updated in Posting Option Page.", "PaymentOptionFieldNotUpdated", "True", appHandle, true);
                }
            }
        }
        public virtual void ClickOnSubmitButtonInContext()
        {
            WebAdminPageFactory.ContextAndFieldPage.Submit();
        }

        public virtual void updateTransactionCodeAdjustmentPageOption(string sProductClass = "", string sProductGroup = "", string sProductNumber = "", string NegAcrIntDebit = "", string NegAcrIntCredit = "", string UnAcrIntDebit = "", string UnAcrIntCredit = "", string AdjustmentsResidualInterestDebit = "", string AdjustmentsResidualInterestCredit = "", string AdjustmentsNegativeAIOnPositiveBalanceDebit = "", string AdjustmentsNegativeAIOnPositiveBalanceCredit = "", string AdjustmentsPositiveAIOnNegativeBalanceDebit = "", string AdjustmentsPositiveAIOnNegativeBalanceCredit = "", string AdjustmentsInterestAvailableNotCredited = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Codes"));
            if (WebAdminPageFactory.DepositTransactionCodePage.WaitUntilTransactionCodeAdjustmentPageloads())
            {
                WebAdminPageFactory.DepositTransactionCodePage.EnterTransactionCodeAdjustmentDetails(NegAcrIntDebit, NegAcrIntCredit, UnAcrIntDebit, UnAcrIntCredit, AdjustmentsResidualInterestDebit, AdjustmentsResidualInterestCredit, AdjustmentsNegativeAIOnPositiveBalanceDebit, AdjustmentsNegativeAIOnPositiveBalanceCredit, AdjustmentsPositiveAIOnNegativeBalanceDebit, AdjustmentsPositiveAIOnNegativeBalanceCredit);
                WebAdminPageFactory.DepositTransactionCodePage.SelectSubmitButton();
                if (WebAdminPageFactory.DepositTransactionCodePage.VerifyMessageDepositTransactionCodeAdjustmentPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Loan Maturity option is updated in Maturity Processing Page", "MaturityProcessingFieldupdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Loan Maturity option not updated in Posting Option Page.", "MaturityProcessingFieldNotUpdated", "True", appHandle, true);
                }
            }



        }
        public virtual void VerifyExistingUserIDMessageInWebAdmin(string UserID, string userclassname = "SCA")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            WebAdminPageFactory.UserAddPage.ClickOnAddButton();
            WebAdminPageFactory.UserAddPage.EnterUserDetails(UserID, userclassname);
            WebAdminPageFactory.UserAddPage.ClickOnSubmitbutton();
            if (WebAdminPageFactory.UserAddPage.VerifyRecordExistsMessage())
            {
                Report.Pass("Error Message for Existing User Id is displayed successfully", "usercreate", "true", appHandle);
            }
            else
            {
                Report.Fail("Error Message for Existing User Id was no displayed successfully", "usercreatefails", "true", appHandle, true);
            }

        }
        public virtual void VerifyStatusOfUser(string UserID, string status)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            WebAdminPageFactory.UserAddPage.EnterUserID(UserID);
            WebAdminPageFactory.UserAddPage.ClickOnListButton();
            WebAdminPageFactory.UserAddPage.SelectUserInUserList(UserID);
            WebAdminPageFactory.UserAddPage.VerifyDataFromUserIDTable(status);
            Report.Info("The Status of the user is Active in Web Admin Page", "UserList", "true", appHandle);

        }
        public virtual void ModifyUserDetailsOnlineTeller(string UserID, bool ONorOFF)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            WebAdminPageFactory.UserAddPage.EnterUserID(UserID);
            WebAdminPageFactory.UserAddPage.ClickOnListButton();
            WebAdminPageFactory.UserAddPage.SelectUserInUserList(UserID);
            WebAdminPageFactory.UserAddPage.ClickOnEditButton();
            WebAdminPageFactory.UserAddPage.ClickOnPMingAllowedCheckbox(ONorOFF);
            WebAdminPageFactory.UserAddPage.ClickOnSubmitbutton();
            WebAdminPageFactory.UserAddPage.EnterAgentAuthorization();
            WebAdminPageFactory.UserAddPage.ClickOnAgentAuthorizationSubmitbutton();
            if (WebAdminPageFactory.UserAddPage.VerifyUserModificationSuccess(UserID))
            {
                Report.Pass("User detail was Modified successfully", "UserList", "true", appHandle);

            }
            else
            {
                Report.Fail("User detail was not Modified successfully", "UserListfails", "true", appHandle, true);
            }


        }
        public virtual void EditUserclassForPasswordHistory(string Userclass, string HistoryDays, string HistoryNo)
        {
            WebAdminPageFactory.UserClassListPage.SelectUserClassFromTable(Userclass);
            WebAdminPageFactory.EditUserClassPage.UpdatePasswordHistory(HistoryDays, HistoryNo);
            WebAdminPageFactory.EditUserClassPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.EditUserClassPage.CheckSuccessMessage())
            {
                Report.Pass("The Userclass " + Userclass + " is modified successfully", "modpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Userclass " + Userclass + " is not modified", "modfail", "True", appHandle);


            }

        }
        /// <summary>
        /// This method is used to validate product level all pages . 
        /// sProductClass : Product class , sProductGroup : Product group , sProductNumber : Product Number
        /// sTabName : Interest or Payment 
        /// sSubTabName : Calculation or Rate determination
        /// Data to be passed for LabelNameLabelValuePipeDelimited :
        /// For label name validation just pass label name as input. Multiple label names can be sent . Multiple label names has to be sent as Label1;Label2;Label3
        /// Same is applicable for headers.
        /// For Single value validation data has to be passed as labelname1|labelvalue1 .
        /// For multiple label value validation data has to be passed as labelname1|labelvalue1;labelname2|labelvalue2
        /// </summary>
        /// <param name="sProductClass"></param>
        /// <param name="sProductGroup"></param>
        /// <param name="sProductNumber"></param>
        /// <param name="sTabName"></param>
        /// <param name="LabelNameLabelValuePipeDelimited"></param>
        /// <param name="sSubTabName"></param>
        public virtual void VerifyValuesByLabelNameLabelValueInProductsPage(string sProductClass, string sProductGroup, string sProductNumber, string sTabName, string LabelNameLabelValuePipeDelimited, string sSubTabName = "")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(sTabName, sSubTabName);
            Profile7CommonLibrary.VerifyValueByLabelNameLabelValue(LabelNameLabelValuePipeDelimited);
        }
        public virtual void UpdateMaturityProcessingPageOption(string sProductClass = "", string sProductGroup = "", string sProductNumber = "", string MaturityInformationTerm = "", string PrincipalMaturityoption = "", string InterestMaturityoption = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Term Accounts"), Data.Get("Maturity/Renewal"));
            WebAdminPageFactory.LoanMaturityProcessingPage.EnterMaturityRenewalProcessingPageOption(MaturityInformationTerm, PrincipalMaturityoption, InterestMaturityoption);
            WebAdminPageFactory.LoanMaturityProcessingPage.SelectSubmitButton();
            if (WebAdminPageFactory.LoanMaturityProcessingPage.VerifyMessageLoanMaturityProcessingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Maturity option is updated in Maturity Processing Page", "UpdateMaturityProcessingPageOption", "True", appHandle);
            }
            else
            {
                Report.Fail("Maturity option not updated in Posting Option Page.", "UpdateMaturityProcessingPageOption", "True", appHandle, true);
            }

        }

        public virtual void UpdateMortgageDisbursementProcessing(string sProductClass, string sProductGroup, string sProductNumber, string MaximumNumberofDisbursements, string AutomaticDisbursementPlan, string AutomaticDisbursementMethod, string AutomaticDisbursementCheckType, bool DisbursementScheduleProcessing)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }

            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.UpdateDisbursementProcessing(MaximumNumberofDisbursements, AutomaticDisbursementPlan, AutomaticDisbursementMethod, AutomaticDisbursementCheckType, DisbursementScheduleProcessing);
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.select_submit_button();
            if (WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.VerifyMessageInWebAdminProductTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Disbursement Processing is updated in Product Transaction Processing Page.", "UpdateMortgageDisbursementProcessing", "True", appHandle);
            }
            else
            {
                Report.Fail("Disbursement Processing is not updated in Product Transaction Processing Page.", "UpdateMortgageDisbursementProcessing", "True", appHandle, true);
            }


        }

        public virtual void UpdateTermAccountsMaturityRenewal(string sProductClass = "", string sProductGroup = "", string sProductNumber = " ", string PrincipalMaturityOption = "",string BusinessDateOption="",string BusinessDateCalc="")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Term Accounts"), Data.Get("Maturity/Renewal"));
            WebAdminPageFactory.DepositPostingOptionsPage.UpdateTermAccountsMaturityRenewal(PrincipalMaturityOption,BusinessDateOption , BusinessDateCalc);
            WebAdminPageFactory.DepositPostingOptionsPage.SelectSubmitButton();
            if (WebAdminPageFactory.DepositPostingOptionsPage.VerifyMessageDepositInterestPostingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Principal Maturity Option field are updated in Maturity/Renewal Page", "UpdateTermAccountsMaturityRenewal", "True", appHandle);
            }
            else
            {
                Report.Fail("Principal Maturity Option field is not updated in Maturity/Renewal Page.", "UpdateTermAccountsMaturityRenewal", "True", appHandle, true);
            }
        }

        public virtual void UpdateUSRegulatoryOptions(string sProductClass = "", string sProductGroup = "", string sProductNumber = " ", string IRSReportingOption = "")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));
            WebAdminPageFactory.DepositPostingOptionsPage.UpdateUSRegulatoryOptions(IRSReportingOption);
            WebAdminPageFactory.DepositPostingOptionsPage.SelectSubmitButton();
            if (WebAdminPageFactory.DepositPostingOptionsPage.VerifyMessageDepositInterestPostingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("IRS Reporting option field is updated in U.S. Regulatory Page", "UpdateUSRegulatoryOptions", "True", appHandle);
            }
            else
            {
                Report.Fail("IRS Reporting option field is not updated in U.S. Regulatory Page.", "UpdateUSRegulatoryOptions", "True", appHandle, true);
            }
        }
        public virtual void UpdateProductNewAccounts(string sProductClass = "", string sProductGroup = "", string sProductNumber = " ", string StudentLoanProduct = "", string StudentLoanStatus = "", string CommitmentProcessing = "", string CommitmentBilling = "", string CommitmentDelinquency = "")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);

            if (!string.IsNullOrEmpty(CommitmentProcessing) || !string.IsNullOrEmpty(CommitmentBilling) || !string.IsNullOrEmpty(CommitmentDelinquency))
            {
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("New Accounts"));
                WebAdminPageFactory.NewAccountspage.UpdateCommitmentOptions(CommitmentProcessing, CommitmentBilling, CommitmentDelinquency);
                WebAdminPageFactory.NewAccountspage.SelectSubmitButton();
            }

            if (!string.IsNullOrEmpty(StudentLoanProduct) || !string.IsNullOrEmpty(StudentLoanStatus))
            {
                WebAdminPageFactory.DepositPostingOptionsPage.UpdateProductNewAccounts(StudentLoanProduct, StudentLoanStatus);
                WebAdminPageFactory.DepositPostingOptionsPage.SelectSubmitButton();
            }

            if (WebAdminPageFactory.DepositPostingOptionsPage.VerifyMessageDepositInterestPostingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Student Loan Product and Student Loan status fields are updated in New Accounts Page", "UpdateProductNewAccounts", "True", appHandle);
            }
            else
            {
                Report.Fail("Student Loan Product and Student Loan status fields are not updated in New Accounts Page", "UpdateProductNewAccounts", "True", appHandle, true);
            }
        }

        public virtual void UpdateConsumerLoansTransactionProcessing(string sProductClass = "", string sProductGroup = "", string sProductNumber = " ", string OriginationFeePercentage = "")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebAdminPageFactory.DepositPostingOptionsPage.UpdateConsumerLoansTransactionProcessing(OriginationFeePercentage);
            WebAdminPageFactory.DepositPostingOptionsPage.SelectSubmitButton();
            if (WebAdminPageFactory.DepositPostingOptionsPage.VerifyMessageDepositInterestPostingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("OriginationFeePercentage field is updated in Transaction Processing Page", "UpdateConsumerLoansTransactionProcessing", "True", appHandle);
            }
            else
            {
                Report.Fail("OriginationFeePercentage field is not updated in Transaction Processing Page.", "UpdateConsumerLoansTransactionProcessing", "True", appHandle, true);
            }
        }

        public virtual void VerifyValueByLabelNameLabelValueInWebAdmin(string UserID, string sLabelNameLabelValuePipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            WebAdminPageFactory.UserAddPage.SelectUSerIDfromUserList(UserID);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
            string msg = "";
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
                msg = string.Join(" , ", msg.Split(';'));
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
            }
            if (WebAdminPageFactory.UserAddPage.VerifyTableDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(msg + " is / are successfully matched in application.", "tablelabelvalue", "true", appHandle);
            }
            else
            {
                Report.Fail(msg + " is / are not successfully matched in application", "tablelabelvaluefail", "true", appHandle);
            }
        }
        public virtual void VerifyValuesByLabelNameLabelValueInWebAdminUserPage(string UserID, string sLabelNameLabelValuePipeDelimited)
        {
            WebAdminPageFactory.UserAddPage.SelectUSerIDfromUserList(UserID);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
            Profile7CommonLibrary.VerifyValueByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
        }
        public virtual void UpdateTotalNumberOfDisbursment()
        {
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebAdminPageFactory.TransactionProcessingPaymentSystemPage.EnterDisbursmentProcessingOption();
            WebAdminPageFactory.TransactionProcessingPaymentSystemPage.ClickOnSubmit();
            if (WebAdminPageFactory.TransactionProcessingPaymentSystemPage.VerifyMessageInWebAdminPaymentSystemPage())
            {
                Report.Pass("Total number of disbursment updated successfully.", "updated", "True", appHandle);
            }
            else
            {
                Report.Fail("Total number of disbursment is not updated successfully.", "notupdated", "True", appHandle);
            }

        }
        public virtual void VerifyDropdownInProductFactory(string sProductClass, string LabelNameLabelValuePipeDelimited, string ProductGroup = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, ProductGroup);
            Profile7CommonLibrary.VerifyDropdownSpecifiedValueExists(LabelNameLabelValuePipeDelimited);
        }
        public virtual void UpdateDataInUserClassMaintenance(string UserID, string sLabelNameLabelValuePipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Userclass Maintenance"));
            WebAdminPageFactory.UserClassListPage.SelectUSerClassFromUserList(UserID);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
            string msg = "";
            string failmsg = "";
            string temp = "";
            string[] arr = null;
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is found as " + arr[b].Split('|')[1] + " successfully in Interest Accrual Page.";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is found as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " successfully in Interest Accrual Page.";
                failmsg = msg.Replace(" is ", " is not ");
            }
            WebAdminPageFactory.UserClassListPage.EnterDataInUserMaintenancePage(sLabelNameLabelValuePipeDelimited);
            if (WebAdminPageFactory.UserClassListPage.VerifyMessageInWebAdminUserPage())
            {
                Report.Pass("User Maintenance Page details Updated.", "freupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("User Maintenance Page details is/are not Updated.", "freupdate", "True", appHandle, true);
            }
        }
        public virtual void VerifyTabsInInstitutionVariablePage(string sTabName, string LabelNameLabelValuePipeDelimited, string sSubTabName = "")
        {
            Profile7CommonLibrary.SelectTabSubTabInApplication(sTabName, sSubTabName);
            Profile7CommonLibrary.VerifyValueByLabelNameLabelValue(LabelNameLabelValuePipeDelimited);
        }
        public virtual void ModifyRecordInGeneralTableManagement(string tablename, string detailsdelimitedbysemicolon, string code)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(tablename);
            WebAdminPageFactory.LoanFeePlanTransactionCodesPage.SelectTranCodeFromTable(code);
            WebAdminPageFactory.LoanFeePlanTransactionCodesPage.ClickOnEditButton();
            switch (tablename)
            {

                case "UTBLTRNGRPLT":
                    if (tablename.Equals("UTBLTRNGRPLT"))
                    {
                        WebAdminPageFactory.LoanFeePlanTransactionCodesPage.ModifyRecordsForTableUTBLTRNGRPLT(detailsdelimitedbysemicolon);
                    }
                    break;
                case "UTBLLNFEEGRP":
                    if (tablename.Equals("UTBLLNFEEGRP"))
                    {
                        WebAdminPageFactory.LoanFeePlanTransactionCodesPage.ModifyRecordsForTableUTBLLNFEEGRP(detailsdelimitedbysemicolon);
                    }
                    break;

            }
            string PageHeader = WebAdminPageFactory.LoanFeePlanTransactionCodesPage.GetPageHeader();
            PageHeader = PageHeader.Remove(PageHeader.Length - 1, 1);
            if (WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyMessageInLoanFeePage("The " + PageHeader + " Code Group has been updated."))
            {
                Report.Pass("The Records are modified in General Table Managment", "recpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Records are not modified in General Table Managment", "recfail", "True", appHandle);
            }
        }
        public virtual void DeleteRecordInGeneralTableManagement(string tablename, string feecode)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(tablename);
            WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyValueIsSelectInTransactionFeeTable(feecode);
            WebAdminPageFactory.LoanFeePlanTransactionCodesPage.ClickOnDeleteButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            string PageHeader = WebAdminPageFactory.LoanFeePlanTransactionCodesPage.GetPageHeader();
            string PageHeader1 = PageHeader.Remove(PageHeader.Length - 1, 1);
            if (WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyMessageInLoanFeePage("The " + PageHeader + " has been deleted.") ||
            (WebAdminPageFactory.LoanFeePlanTransactionCodesPage.VerifyMessageInLoanFeePage("The " + PageHeader1 + " has been deleted.")))
            {
                Report.Pass("Record has been deleted Successfully", "AssetCatagoryDeleted", "True", appHandle);
            }
            else
            {
                Report.Fail("Record has not been deleted.", "AssetcatagorynotDeleted", "True", appHandle, true);
            }

        }
        public virtual string AddLoanFeePlan(string date, bool PayoffFeeONOFF, string HistoryCommentatAssessment = "", string FeeAssessmentMethod = "", string FeeAssesmetRuleSemecolondelimited = "", string FeeCalculationDetailsSemecolnDelimited = "", string TransactionCodegroup = "", string feeassesment = "", string increaseadjust = "", string decreaseadjust = "", string transactioncodesemicolondelimitd = "", string InComeDeferralOptionsSemecolnDelimited = "", string OperationDetailsSemecolonDelimited = "", string GLAccountLinkagesandOffsetTransactions = "")
        {
            string loanfeeplan = "";
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Loan Fee Plans"));
            loanfeeplan = WebAdminPageFactory.LoanFeePlanIdentificationPage.EnterRecordsForAddLoanFeePlan(date, PayoffFeeONOFF, HistoryCommentatAssessment, FeeAssessmentMethod, FeeAssesmetRuleSemecolondelimited, FeeCalculationDetailsSemecolnDelimited, TransactionCodegroup, feeassesment, increaseadjust, decreaseadjust, transactioncodesemicolondelimitd, InComeDeferralOptionsSemecolnDelimited, OperationDetailsSemecolonDelimited, GLAccountLinkagesandOffsetTransactions);

            if (WebAdminPageFactory.LoanFeePlanIdentificationPage.VerifyMessageInLoanFeePlanIdentificationPage("The " + loanfeeplan + " has been created."))
            {
                Report.Pass("Loan fee plan added to table", "recpass", "True", appHandle);
            }
            else
            {
                Report.Pass("Loan Fee plan not added to the table", "recfail", "True", appHandle);
            }
            return loanfeeplan;
        }
        public virtual void UpdateFATCAWitholdingPercentageInInstitutionVariable(string Percentage)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Accounts"), Data.Get("Deposit"));
            WebAdminPageFactory.InstitutionVariablePage.EnterWitholdingPercentage(Percentage);
            WebAdminPageFactory.InstitutionVariablePage.SelectSubmitButton();
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("FATCA Withholding Percentage is update in Institution Variable Page ", "Deposit", "True", appHandle);
            }
            else

            {
                Report.Fail("FATCA Withholding Percentage is  not update in Institution Variable Page ", "Depositfails", "True", appHandle, true);
            }
        }
        public virtual void UpdateInstitutionDemographicsInInstitutionVariable(string City, string Country, string State, string ZipCode, string Telephone)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            WebAdminPageFactory.InstitutionVariablePage.UpdateInstitutionDemographics(City, Country, State, ZipCode, Telephone);
            WebAdminPageFactory.InstitutionVariablePage.SelectSubmitButton();
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Institution Demographics is updated successfully in Institution Variable", "General", "true", appHandle);
            }
            else
            {
                Report.Fail("The Institution Demographics is  not updated successfully in Institution Variable", "Generalfails", "true", appHandle, true);
            }


        }

        public virtual void UpdateServiceFeeInTransactionCodePage(string sProductClass, string sProductGroup, string sProductNumber, string ServiceFee, string ATMOverdraftFee, string MiscFee = "")
        {
            this.GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Codes"), Data.Get("Service Fees"));
            WebAdminPageFactory.TransactionCodeConfigurationPage.UpdateServiceFeeDetails(ServiceFee, ATMOverdraftFee, MiscFee = "");
            WebAdminPageFactory.TransactionCodeConfigurationPage.ClickOnSubmit();
            if (WebAdminPageFactory.TransactionCodeConfigurationPage.VerifyMessageInWebAdminTransactionCodePage())
            {
                Report.Pass("Minimum Balance is updated in Product Transaction Processing Page.", "ServiceFees", "True", appHandle);
            }
            else
            {
                Report.Fail("Minimum Balance is not updated in Product Transaction Processing Page.", "ServiceFeesfail", "True", appHandle, true);
            }

        }
        public virtual void UpdateServiceFeeForProductInServiceFeePage(string sProductClass, string sProductGroup, string sProductNumber, string FeeforReturn, string FeeForPaid, string FeeFrequency = "", string FeeOption = "", string ServiceChargeCode = "", string TaxPlanGroup = "", string FeePlan = "")
        {
            this.GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Service Fees"));
            WebAdminPageFactory.ProductServiceFeesPage.UpdateDailyFee(FeeforReturn, FeeForPaid, FeeFrequency, FeeOption, ServiceChargeCode, TaxPlanGroup, FeePlan);
            WebAdminPageFactory.ProductServiceFeesPage.Clickonsubmit();
            if (WebAdminPageFactory.ProductServiceFeesPage.VerifyMessageInServiceFeePage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Service Fees Details are Updated in Service Fees Page", "servicefees", "true", appHandle);

            }
            else
            {
                Report.Fail("The Service Fees Details was not Updated in Service Fees Page", "servicefeesfails", "true", appHandle, true);
            }

        }
        public virtual void UpdateMinimumBalanceInTransactionProcessingPage(string sProductClass, string sProductGroup, string sProductNumber, string Balance)
        {
            this.GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.UpdateTransRestrictMinimumBalance(Balance);
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.EnterReconcillationDetails();
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.select_submit_button();
            if (WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.VerifyMessageInWebAdminProductTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Minimum Balance is updated in Product Transaction Processing Page.", "Permitpaymentorder", "True", appHandle);
            }
            else
            {
                Report.Fail("Minimum Balance is not updated in Product Transaction Processing Page.", "Permitpaymentorderfail", "True", appHandle, true);
            }

        }
        public virtual void AccessPermissiontoUserclassInProcedurePage(string userClass)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("SetPermisssions"));
            WebAdminPageFactory.ContextAndFieldPage.SelectTabInContextFieldPage("Procedure");
            WebAdminPageFactory.ProcedurePage.SetPermissionforUserclass(userClass);

        }
        public virtual void VerifyWebAdminResetPasswordErrorMsg(string Password, string NewPassword, string Msg)
        {
            Report.Info("Enter Reset Password details");
            WebAdminPageFactory.WebAdminLoginPage.FillResetPasswordDetailsWebAdmin(Password, NewPassword);
            WebAdminPageFactory.WebAdminLoginPage.SubmitPage();
            if (WebAdminPageFactory.WebAdminLoginPage.VerifyResetPasswordMessage(Msg))
            {
                Report.Pass("The Message " + Msg + "is verified in Change Password Page", "ChangePassword", "true", appHandle);
            }
            else
            {
                Report.Fail("The Message " + Msg + "is verified in Change Password Page", "ChangePassword", "true", appHandle, true);
            }

        }

        public virtual void UpdateRestrictedCustomerInWebAdmin(string CustomerNo, string UserID)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            WebAdminPageFactory.UserAddPage.EnterUserID(UserID);
            WebAdminPageFactory.UserAddPage.ClickOnListButton();
            WebAdminPageFactory.UserAddPage.SelectUserInUserList(UserID);
            WebAdminPageFactory.UserAddPage.ClickOnEditButton();
            WebAdminPageFactory.UserAddPage.ClickOnSearchRestrictedCustomerButton();
            WebAdminPageFactory.UserAddPage.SearchCustomerByCustomerNumber(CustomerNo);
            WebAdminPageFactory.UserAddPage.ClickOnSubmitbutton();
            WebAdminPageFactory.UserAddPage.EnterAgentAuthorization();
            WebAdminPageFactory.UserAddPage.ClickOnAgentAuthorizationSubmitbutton();
            if (WebAdminPageFactory.UserAddPage.VerifyUserModificationSuccess(UserID))
            {
                Report.Pass("User detail was Modified successfully", "UserList", "true", appHandle);

            }
            else
            {
                Report.Fail("User detail was not Modified successfully", "UserListfails", "true", appHandle, true);
            }



        }

        public virtual void UpdateUserBranchCodeInWebAdmin(string UserID, string BranchCode)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Security Configuration") + "|" + Data.Get("User/Userclass Maintenance"));
            WebAdminPageFactory.UserAddPage.EnterUserID(UserID);
            WebAdminPageFactory.UserAddPage.ClickOnListButton();
            WebAdminPageFactory.UserAddPage.SelectUserInUserList(UserID);
            WebAdminPageFactory.UserAddPage.ClickOnEditButton();
            WebAdminPageFactory.UserAddPage.UpdateBranchCode(BranchCode);
            WebAdminPageFactory.UserAddPage.ClickOnSubmitbutton();
            WebAdminPageFactory.UserAddPage.EnterAgentAuthorization();
            WebAdminPageFactory.UserAddPage.ClickOnAgentAuthorizationSubmitbutton();
            if (WebAdminPageFactory.UserAddPage.VerifyUserModificationSuccess(UserID))
            {
                Report.Pass("Branch Code is added to the user in User Maintenance Page", "UserMaintenance", "true", appHandle);

            }
            else
            {
                Report.Fail("Branch Code is not added to the user in User Maintenance Page", "UserMaintenancefails", "true", appHandle, true);
            }



        }
        public virtual void WebAdminResetPassword(string Password, string NewPassword, string Msg)
        {
            Report.Info("Enter Reset Password details");
            WebAdminPageFactory.WebAdminLoginPage.FillResetPasswordDetailsWebAdmin(Password, NewPassword);
            WebAdminPageFactory.WebAdminLoginPage.SubmitPage();
            WebAdminPageFactory.WebAdminLoginPage.VerifyResetPasswordMessage(Msg);
            Report.Info("Reset Password details completed");
        }
        public virtual string AddNewCardTypeInCRDTYPTable(string TableName, string BinNo, string WDLimit, string FeeAmt, string Term, string RenewalPeriod = null, string RenewalReportPeriod = null, string CreationStatus = null)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
            string CardType = WebAdminPageFactory.GeneralTableManagementPage.AddCardTypeInCRDTYP(BinNo, WDLimit, FeeAmt, Term, RenewalReportPeriod, RenewalReportPeriod, CreationStatus);
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButtonForCard();

            return CardType;

        }
        public virtual void UpdateEligibleForCardInGeneralPage(string sProductClass, string sProductGroup, string sProductNumber, bool ONorOFF)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            WebAdminPageFactory.WebAdminProductsGeneralPage.ClickOnEligibleForCardProcessingCheckBox(ONorOFF);
            WebAdminPageFactory.WebAdminProductsGeneralPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.WebAdminProductsGeneralPage.VerifyMessageWebAdminProductGeneralPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Eligible For Card Processing Checkbox is Enabled in product General Page in WebAdmin.", "prodgeneralcalcode", "True", appHandle);
            }
            else
            {
                Report.Fail("Eligible For Card Processing Checkbox was not Enabled in product General Page in WebAdmin.", "prodgeneralcalcodefail", "True", appHandle, true);
            }

        }
        public virtual void UpdateDetailsForDebitCardInRegulatory2Page(string Amount, string DepositAmount)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory2"));
            WebAdminPageFactory.USRegulatoryRegulatory2Page.UpdateCardDetails(Amount, DepositAmount);
            WebAdminPageFactory.USRegulatoryRegulatory2Page.ClickOnSubmitButton();
            if (WebAdminPageFactory.USRegulatoryRegulatory2Page.VerifyMessageInRegulatory2Page(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Debit card Details are Updated in US Regulatory2 Page", "Regulatory2", "true", appHandle);

            }
            else
            {
                Report.Fail("The Debit card Details was not Updated in US Regulatory Management Page", "Regulatory2fails", "true", appHandle, true);
            }

        }
        public virtual string AddNewCardBINInCRDBINTable(string TableName, string Desc = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
            string BinNo = WebAdminPageFactory.GeneralTableManagementPage.AddNewCardBin(Desc);
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButtonForCard();

            return BinNo;

        }
        public virtual void UpdateDebitCardDetailsInSystemManagementPage(string AcctValidation, string ATMCardOption)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("System"), Data.Get("System Management"));
            WebAdminPageFactory.TableConfigurationInstitutionVariablesPage.UpdateCardDetails(AcctValidation, ATMCardOption);
            WebAdminPageFactory.TableConfigurationInstitutionVariablesPage.ClickOnSubmitButton();
            appHandle.Wait_For_Specified_Time(5);
            appHandle.PerformActionOnAlert(PopUpAction.Verify, Data.Get("Are you sure you want to delete this order?"));
            appHandle.Wait_For_Specified_Time(4);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            if (WebAdminPageFactory.TableConfigurationInstitutionVariablesPage.VerifyMessageInTableConfiguration(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Debit card Details are Updated in System Management Page", "SystemManagement", "true", appHandle);

            }
            else
            {
                Report.Fail("The Debit card Details was not Updated in System Management Page", "SystemManagementfails", "true", appHandle, true);
            }
        }
        public virtual string CreateServiceFeeSchedule(string TypeOfSchedule, string TypeOfTier, string TierValuesPipeDemilited, string Description = "", string FeeSchedule = "", string EffectiveDate = "", string CustomProgram = "")
        {
            string ServiceSchedule = "";
            bool flag = true;
            bool AddedRecord = false;
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("General Table Management"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(Data.Get("UTBLFEESCH"));
            WebAdminPageFactory.FeeScheduleParametersPage.ClickOnAddButton();
            ServiceSchedule = WebAdminPageFactory.FeeScheduleParametersPage.EnterServiceFeeScheduleDetails(TypeOfSchedule, TypeOfTier, TierValuesPipeDemilited, Description, FeeSchedule, EffectiveDate, CustomProgram);
            WebAdminPageFactory.FeeScheduleParametersPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.FeeScheduleParametersPage.VerifyFeeScheduleInList(ServiceSchedule))
            {
                AddedRecord = true;
            }

            if (WebAdminPageFactory.FeeScheduleParametersPage.VerifyFeeScheduleExists())
            {
                do
                {
                    ServiceSchedule = (string)appHandle.CreateRamdomData(FieldType.ALPHABETS, 11111, 99999, 5);
                    ServiceSchedule = ServiceSchedule.ToUpper();
                    WebAdminPageFactory.FeeScheduleParametersPage.EnterFeeScheduleOnFeeExistsMessage(ServiceSchedule);
                    WebAdminPageFactory.FeeScheduleParametersPage.ClickOnSubmitButton();
                    flag = WebAdminPageFactory.FeeScheduleParametersPage.VerifyFeeScheduleExists();
                    if (flag == false && WebAdminPageFactory.FeeScheduleParametersPage.VerifyFeeScheduleInList(ServiceSchedule))
                    {
                        AddedRecord = true;
                    }
                }
                while (flag == true);
            }

            if (AddedRecord)
            {
                Report.Pass(ServiceSchedule + " is  added successfullyin Fee Schedule Parameters List in WebAdmin. ", "feeschedulecreate", "True", appHandle);
            }
            else
            {
                Report.Fail(ServiceSchedule + " is not  added successfully in Fee Schedule Parameters List in WebAdmin. ", "feeschedulecreate", "True", appHandle);
            }

            return ServiceSchedule;
        }

        public virtual void UpdateValueForPaymentTolerancePercentageField(string tolerancevalue)
        {
            if (WebAdminPageFactory.DelinquencyOptionssPage.UpdateValueForPaymentTolerancePercentageField(tolerancevalue))
            {
                Report.Pass("The Payment Tolerence Percentage Value is updated in Delinquency Options page", "ptvp", "Ture", appHandle);
            }
            else
            {
                Report.Fail("The Payment Tolerence Percentage Value is not  updated in Delinquency Options page", "ptvf", "Ture", appHandle);
            }
        }

        public virtual void EnterDetailsInProvisionOrClassification(bool provprocessing, bool reclassprocess, bool reclassprocessifcurrent)
        {
            if (WebAdminPageFactory.DelinquencyOptionssPage.EnterDetailsInProvisionOrClassification(provprocessing, reclassprocess, reclassprocessifcurrent))
            {
                Report.Pass("The Details entered in Provison/Reclassification section", "prvp", "True", appHandle);
            }
            else
            {
                Report.Fail("The Details not entered in Provison/Reclassification section", "prvf", "True", appHandle);
            }

        }


        public virtual void UpdateMaturityOptionAndPaymenttermForCopiedProduct(string payterm, string matopt)
        {
            if (WebAdminPageFactory.LoanMaturityProcessingPage.EnterDetailsForMatOptionAndPayTerm(payterm, matopt))
            {
                Report.Pass("The details entered in Maturity/Renewal tab", "matrp", appHandle);
            }
            else
            {
                Report.Fail("The details not entered in Maturity/Renewal tab", "matrf", appHandle);
            }
        }


        public virtual void AddDetailsForGeneralSetCode(string prodnum)
        {
            SelectLinkFromLeftPaneInWebAdmin("General Ledger|Set Codes");
            WebAdminPageFactory.GeneralLedgerSetCodeListPage.EnterDetailsForProdClassAndProdGroup(prodnum);

        }

        public virtual void addvaluestodropdownset1(string gl1, string gl2, string gl3, string gl4, string gl5)
        {
            WebAdminPageFactory.GeneralLedgerSetCodeListPage.addvaluestodropdownset1(gl1, gl2, gl3, gl4, gl5);
        }

        public virtual void addvaluestodropdownset2(string gl1, string gl2, string gl3, string gl4, string gl5)
        {
            WebAdminPageFactory.GeneralLedgerSetCodeListPage.advaluestodropdownset2(gl1, gl2, gl3, gl4, gl5);
        }
        public virtual void addvaluestodropdownset3(string gl1, string gl2, string gl3, string gl4, string gl5)
        {
            WebAdminPageFactory.GeneralLedgerSetCodeListPage.advaluestodropdownset3(gl1, gl2, gl3, gl4, gl5);
        }
        public virtual void addvaluestodropdownset4(string gl1, string gl2, string gl3, string gl4, string gl5, string gl6, string gl7, string gl8)
        {
            WebAdminPageFactory.GeneralLedgerSetCodeListPage.advaluestodropdownset4(gl1, gl2, gl3, gl4, gl5, gl6, gl7, gl8);
            if (WebAdminPageFactory.GeneralLedgerSetCodeListPage.ClickOnSubmit())
            {
                Report.Pass("The data Entered in all dropdown of setcodes", "setp", "True", appHandle);
            }
            else
            {
                Report.Fail("The data not Entered in all dropdown of setcodes", "setp", "True", appHandle);
            }
        }


        public virtual void UpdateDataInTransactionProcessing(string prodnum)
        {
            WebAdminPageFactory.WebAdminProductsTransactionProcessingPage.UpdateDataInTransactionProcessingTab(prodnum);

        }

        public virtual void EnterDetailsInPaymentCalculation()
        {
            if (WebAdminPageFactory.PaymentCalculationOptionsPage.EnterDetailsInPaymentCalculation())
            {
                Report.Pass("the data entered for payment calculation options", "popp", "True", appHandle);
            }
            else
            {
                Report.Fail("the data entered for payment calculation options", "popf", "True", appHandle);
            }
        }

        public virtual void EnterValueForPaymentTerm(string termval)
        {
            WebAdminPageFactory.LoanMaturityProcessingPage.EnterValueForPaymentTerm(termval);

        }

        public virtual void AddRecordInGenralTableManagementForTableUTBLKill(string tablename, string description, string noofdaystosave, string datekeyval, string dateformat)
        {
            SelectLinkFromLeftPaneInWebAdmin("Table Configuration|General Table Management");
            WebAdminPageFactory.GeneralTableManagementPage.EnterTableName("UTBLKILL");
            WebAdminPageFactory.GeneralTableManagementPage.ClickOnSearchButton();
            WebAdminPageFactory.GeneralTableManagementPage.SelectPackageTableRadioButton("UTBLKILL");
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButton();
            // WebAdminPageFactory.GeneralTableManagementPage.VerifyRecordUTBLKILLAddedAlreadyAndDelete(description);
            if (WebAdminPageFactory.GeneralTableManagementPage.EnterDetailsForAddPurgeFiles(tablename, description, noofdaystosave, datekeyval, dateformat))
            {
                Report.Pass("Record added in Table for UTBLKILL", "utbp", "True", appHandle);
            }
            else
            {
                Report.Fail("Record not added in Table for UTBLKILL", "utbp", "True", appHandle);
            }


        }


        public virtual void UpdateDataInAdjustableRateSectionOfInterestTab(string indexval, string interestreviewoffsetdaysval, string changefrequency, string fixedratenominalrate = "")
        {
            if (WebAdminPageFactory.LoanRateDeterminationPage.UpdateDataInAdjustableRateSectionOfInterestTab(indexval, interestreviewoffsetdaysval, changefrequency, fixedratenominalrate))
            {
                Report.Pass("The Date is entered in rate determination tab", "adtp", "True", appHandle);
            }
            else
            {
                Report.Fail("The Date is not entered in rate determination tab", "adtf", "True", appHandle);
            }

        }

        public virtual void UpdateDataInAdjustablePaymentOfPaymentCalculation(string paymentchangemethod, string offsetdays, string changefrequency)
        {
            if (WebAdminPageFactory.PaymentCalculationAdjustablePaymentPage.UpdateDataInAdjustablePaymentOfPaymentCalculation(paymentchangemethod, offsetdays, changefrequency))
            {
                Report.Pass("The data entered in Adjustable Rate section of payment calcualtion", "adtr", "True", appHandle);
            }
            else
            {
                Report.Fail("The data entered in Adjustable Rate section of payment calcualtion", "adtr", "True", appHandle);
            }

        }

        public virtual string GetBackupWithholdingPercentageValFromInstitution()
        {
            SelectLinkFromLeftPaneInWebAdmin("Table Configuration|Institution Variables");
            ClickonTabinProductPage("Accounts");
            Application.WebCSR.ClickonLink("Deposit");
            string val = WebAdminPageFactory.InstitutionVariableDepositPage.GetBackupWithholdingPercentageValue();
            if (!string.IsNullOrEmpty(val))
            {
                Report.Pass("Backup Withholding percentage value is fetched", "hty", "True", appHandle);
            }
            else
            {
                Report.Fail("Backup Withholding percentage value is not fetched", "hty", "True", appHandle);
            }

            return val;
        }

        public virtual string GetValueofTaxAndFinYearEndAndUpdateInInstitutionTab(string appdate)
        {
            return WebAdminPageFactory.InstitutionVariablePage.GetValueofTaxAndFinYearEndAndUpdateInInstitutionTab(appdate);
        }

        public virtual void UpdateTaxYearEndAndFinYearEnd(string finyearend, string taxyearend)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));
            if (WebAdminPageFactory.InstitutionVariablePage.UpdateTaxYearEndAndFinYearEnd(finyearend, taxyearend))
            {
                Report.Pass("The Year end data is updated", "rtg", "True", appHandle);
            }
            else
            {
                Report.Fail("The Year end data is not updated", "rtg", "True", appHandle);
            }
        }


        public virtual void EnterValueInMinimumOpeningDepositField(string sProductClass, string sProductGroup, string ProductToBeEdited, string mindepval)
        {
            GetProduct(sProductClass, sProductGroup, ProductToBeEdited);
            if (WebAdminPageFactory.GeneralPage.EnterValueInMinimumOpeningDepositField(mindepval))
            {
                Report.Pass("Minimum Opening Deposit Field is updated successfully", "mdep", "True", appHandle);

            }
            else
            {
                Report.Fail("Minimum Opening Deposit Field is not updated", "mdep", "True", appHandle);
            }
        }

        public virtual void SelectOriginalIssueDiscountCheckBoxInProductGeneralPage(string sProductClass, string sProductGroup, string ProductToBeEdited, bool ONorOFF)
        {


            GetProduct(sProductClass, sProductGroup, ProductToBeEdited);
            if (WebAdminPageFactory.WebAdminProductsGeneralPage.ClickOnOriginalIssueDiscountCheckBox(ONorOFF))
            {
                WebAdminPageFactory.WebAdminProductsGeneralPage.ClickOnSubmitButton();

                if (WebAdminPageFactory.WebAdminProductsGeneralPage.VerifyMessageWebAdminProductGeneralPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Original issue discount is selected in Product General Page.", "checkboxSelected", "True", appHandle);
                }
                else
                {
                    Report.Fail("Original issue discount is not selected in Product General Page.", "checkboxSelectedFail", "True", appHandle);
                }
            }
        }
        public virtual void UpdateIRCBValueAsSalesPriceInUTBLIRCBTable()
        {
            bool res = false;
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(Data.Get("UTBLIRCB"));
            if (!Profile7CommonLibrary.VerifyDataInTableByColumnValues(Data.Get("CD") + ";" + Data.Get("GLOBAL_VALUE_4"), 1))
            {
                WebAdminPageFactory.GeneralTableManagementPage.ClickOnAddButton();
                Profile7CommonLibrary.EnterDataByLabelNameLabelValue("Product Group:|" + Data.Get("CD - Certificates of Deposit") + ";Interest Rate Calculation Base|" + Data.Get("4 - Sales Price") + ";Description|" + Data.Get("Sales Price"));
                WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButton();
                do
                {
                    try
                    {
                        res = Profile7CommonLibrary.VerifyDataInTableByColumnValues(Data.Get("CD") + ";" + Data.Get("GLOBAL_VALUE_4"));
                    }
                    catch (Exception e) { };
                }
                while (res == false);
            }
            else
            {
                res = true;
            }
            if (res)
            {
                Report.Info("IRCB for CD product type is available in UTBLIRCB table in General Table Management.", "IRCB", "True", appHandle);
            }
            else
            {
                Report.Fail("IRCB for CD product type is not available in UTBLIRCB table in General Table Management.", "IRCBFail", "True", appHandle);
            }
        }

        public virtual void ModifyDataInGeneralLedgerSetCodeTable(string productclass, string productgroup, string glsetcode, string FATCAWithholding)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("General Ledger") + "|" + Data.Get("Set Codes"));
            WebAdminPageFactory.GeneralLedgerAccountPage.SelectProductClassGroup(productclass, productgroup);
            WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnSearchButton();
            WebAdminPageFactory.GeneralLedgerAccountPage.SelectGlSetcodeExistsInTable(glsetcode);
            WebAdminPageFactory.GeneralLedgerAccountPage.SelectFATCAWithholdingInSetCode(FATCAWithholding);
            WebAdminPageFactory.GeneralLedgerAccountPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.GeneralLedgerAccountPage.VerifyMessageInInterestAddPage(Data.Get("The general ledger set code has been modified.")))
            {
                Report.Pass("The FATCA Withholding was updated in Edit General Ledger Set Code Page", "GeneralLedgerSetCode", "true", appHandle);
            }
            else
            {
                Report.Fail("The FATCA Withholding was not updated in Edit General Ledger Set Code Page", "GeneralLedgerSetCodefail", "true", appHandle, true);

            }
        }
        public virtual void UpdateCalculatioOptionFullPeriodtoFirstPayment(string sProductClass, string sProductGroup, string sProductNumber, bool CheckBoXOnorOff)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("GLOBAL_PAYMENT_CALCULATION_TAB"));
            WebAdminPageFactory.LoanPaymentCalculationPage.ClickOnFullPeriodtoFirstPaymentCheckbox(CheckBoXOnorOff);
            WebAdminPageFactory.LoanPaymentCalculationPage.ClickOnSubmit();
            if (WebAdminPageFactory.LoanPaymentCalculationPage.VerifyMessageInWebAdminLoanPaymentCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Full Period to First Payment is updated in Payment Calculation Page", "calculationOptions", "true", appHandle);
            }
            else
            {
                Report.Fail("The Full Period to First Payment is  not updated in Payment Calculation Page", "calculationOptionsfail", "true", appHandle, true);
            }


        }
        public virtual void UpdateAccuralCalculationMethodInLoanCalculationPage(string sProductClass, string sProductGroup, string sProductNumber, string CalculationMethod, bool CheckBoXOnorOff, string CalculationOption, string CollectionMethod)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"));
            WebAdminPageFactory.LoanInterestCalculationPage.UpdateAccuralCalculationMethod(CalculationMethod);
            WebAdminPageFactory.LoanInterestCalculationPage.ClickOnCalculateInterestCheckbox(CheckBoXOnorOff);
            WebAdminPageFactory.LoanInterestCalculationPage.UpdateCalculationandColletionMethod(CalculationOption, CollectionMethod);
            WebAdminPageFactory.LoanInterestCalculationPage.ClickOnSubmit();
            if (WebAdminPageFactory.LoanInterestCalculationPage.VerifyMessageInWebAdminLoanInterestCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Accural Calculation Method is updated in Interesr Calculation Page", "Interestcalculation", "true", appHandle);
            }
            else
            {
                Report.Fail("The Accural Calculation Method is  not updated in Interest Calculation Page", "Interestcalculationfail", "true", appHandle, true);
            }


        }
        public virtual void UpdateMaximumNoOfDisbursementInLoanTransactionProcesstingPage(string sProductClass, string sProductGroup, string sProductNumber, string MaxNo)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebAdminPageFactory.LoanTransactionProcessingPage.UpdateMaximumNoOfDisbursement(MaxNo);
            WebAdminPageFactory.LoanTransactionProcessingPage.ClickOnSubmit();
            if (WebAdminPageFactory.LoanTransactionProcessingPage.VerifyMessageInWebAdminLoanInterestCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Maximum No of Disbursement is updated in Loan Transaction Processing Page", "Interestcalculation", "true", appHandle);
            }
            else
            {
                Report.Fail("The Maximum No of Disbursement is  not updated in Loan Transaction Processing Page", "Interestcalculationfail", "true", appHandle, true);
            }


        }
        public virtual void UpdatePaymentTermInMaturityProcessingPage(string sProductClass, string sProductGroup, string sProductNumber, string PaymentTerm = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Maturity/Renewal"));
            WebAdminPageFactory.LoanMaturityProcessingPage.UpdatePaymentTerm(PaymentTerm);
            WebAdminPageFactory.LoanMaturityProcessingPage.SelectSubmitButton();
            if (WebAdminPageFactory.LoanMaturityProcessingPage.VerifyMessageLoanMaturityProcessingOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Payment Term is updated in Maturity Processing Page", "UpdateMaturityProcessingPageOption", "True", appHandle);
            }
            else
            {
                Report.Fail("Payment Term not updated in Posting Option Page.", "UpdateMaturityProcessingPageOption", "True", appHandle, true);
            }

        }
        public virtual string GetCompanyNameFromInstitutionInformationPage()
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            string CompanyName = WebAdminPageFactory.InstitutionVariablePage.GetCompanyShortName();
            return CompanyName;

        }

        public virtual string AddStateIDInUTBLSTATIDTable(string TableName)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
            string stateid = WebAdminPageFactory.GeneralTableManagementPage.AddStateIDNo();
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButtonForCard();
            return stateid;
        }
        public virtual void CopySamePermissionOfOneUserClasstoAnotherUserClass(string fromuserclass, string touserclass)
        {
            Application.WebAdmin.SelectLinkFromLeftPaneInWebAdmin("Security Configuration|User/Userclass Maintenance");
            WebAdminPageFactory.UserListPage.ClickOnTabUserClassPermission();
            if (WebAdminPageFactory.CopyUserClassPermissionPage.CopyPermissionfromOneUserClasstoAnother(fromuserclass, touserclass))
            {
                Report.Pass("The Copy Permisssion details are Copied from one UserClass to Another Successfully", "cpperpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Copy Permisssion details are not Copied from one UserClass to Another", "cpperfail", "True", appHandle);

            }

        }
        public virtual void AddRatesInInterestMatrixesTable(string InterestMatrix, string MatrixRateDetailsPipeDelimited, string EffectiveDate = "", bool IsAnticipatedRun = true, bool IsRunAtDayEnd = true)
        {
            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (MatrixRateDetailsPipeDelimited.Contains(";"))
            {
                arr = MatrixRateDetailsPipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split('|')) + " is updated successfully in  Interest Matrix Rates List in WebAdmin.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", MatrixRateDetailsPipeDelimited.Split('|')) + " is updated successfully in  Interest Matrix Rates List in WebAdmin.";
                failmsg = msg.Replace(" is ", " is not ");
            }
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Matrixes"));
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.SelectInterestMatrixInInterestMatrixList(InterestMatrix);
            Report.Info(MatrixRateDetailsPipeDelimited + " is selected in interest matrix List.", "selectinterestmatrix", "True", appHandle);
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.ClickOnRatesButton();
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.ModifyDataInterestMatrixRatesPostDayEnd(MatrixRateDetailsPipeDelimited, EffectiveDate, IsAnticipatedRun, IsRunAtDayEnd);
            if (WebAdminPageFactory.TableConfigurationInterestMatrixesPage.VerifyMessageInInterestMatrixPage("Rates have been updated to the matrix in anticpation mode."))
            {
                Report.Pass(msg, "updateratematrix", "True", appHandle);
            }
            else

            {
                Report.Fail(msg, "updateratematrixfail", "True", appHandle, true);
            }
        }
        public virtual void DeleteRatesFromMatrixByEffectiveDate(string InterestMatrix, string sEffectiveDate)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Matrixes"));
            WebAdminPageFactory.TableConfigurationInterestMatrixesPage.SelectSpecifiedMatrixName(InterestMatrix);
            WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
            WebAdminPageFactory.IndexEffectiveDatesListPage.SelectEffectiveDateForIndex(sEffectiveDate);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnDeleteButton();
            WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            if (WebAdminPageFactory.WebAdminMasterPage.CheckSuccessMessage("Rates for matrix " + InterestMatrix + " have been deleted."))
            {
                Report.Pass("Successfully deleted the rate of index", "DeleteRatesOfIndexByEffectiveDate", "True");
            }
            else
            {
                Report.Fail("Failed to delete rate of index", "DeleteRatesOfIndexByEffectiveDate", "True");
            }
        }
        public virtual void UpdateFilerCateogaryInInstitutionInformationGeneralPage(string FilerCategory)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            WebAdminPageFactory.InstitutionVariablePage.UpdateFilerCategoryforFORM8966(FilerCategory);
            WebAdminPageFactory.InstitutionVariablePage.SelectSubmitButton();
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Filer Category for FORM8966 was updated Sucessfully in Institution Information Page", "GeneralPage", "true", appHandle);
            }
            else
            {
                Report.Fail("The Filer Category for FORM8966 was  not updated Sucessfully in Institution Information Page", "GeneralPage", "true", appHandle, true);
            }


        }
        public virtual void UpdateEarlyPayoffPenaltyMethodInLoanTransactionProcessingPage(string sProductClass, string sProductGroup, string sProductNumber, string PenaltyMethod)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebAdminPageFactory.LoanTransactionProcessingPage.SelectEarlyPayOffPenaltyMethod(PenaltyMethod);
            WebAdminPageFactory.LoanTransactionProcessingPage.SelectSubmitButton();
            if (WebAdminPageFactory.LoanTransactionProcessingPage.VerifyMessageInLoanTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Early Pay off penalty method in Loan transaction processing page in WebAdmin is updated as " + PenaltyMethod, "updatearlymethod", "True", appHandle);
            }
            else
            {
                Report.Fail("Early Pay off penalty method in Loan transaction processing page in WebAdmin is not updated as " + PenaltyMethod, "updatearlymethod", "True", appHandle);
            }
        }
        public virtual void EnterValueInDailyCalculationCompoundingFrequencyField(string comfreqval)
        {
            Application.WebAdmin.ClickonTabinProductPage("Interest");
            if (WebAdminPageFactory.DepositInterestCalculationPage.EnterValueInDailyCalculationCompoundingFrequencyField(comfreqval))
            {
                Report.Pass("Daily Calculation Compunding Frequency field is updated", "comfreq", "True", appHandle);
            }
            else
            {
                Report.Fail("Daily Calculation Compunding Frequency field is not updated", "comfreq", "True", appHandle);
            }
        }

        public virtual void EnterValueInDailyCalculationCompoundingFrequencyField(string comfreqval, string accrualmethod = "")
        {
            if (WebAdminPageFactory.DepositInterestCalculationPage.EnterValueInDailyCalculationCompoundingFrequencyField(comfreqval))
            {
                Report.Pass("Daily Calculation Compunding Frequency field is updated", "comfreq", "True", appHandle);
            }
            else
            {
                Report.Fail("Daily Calculation Compunding Frequency field is not updated", "comfreq", "True", appHandle);
            }

        }

        public virtual void UpdateValuesOfPromotionalRateInRateDeterminationPage(string rateval, string indexval, string expdateval, string termval)
        {
            Application.WebCSR.ClickonLink("Rate Determination");
            if (WebAdminPageFactory.DepositRateDeterminationPage.UpdateValuesOfPromotionalRateInRateDeterminationPage(rateval, indexval, expdateval, termval))
            {
                Report.Pass("Data is updated in Promotional Rate section under Rate Determination page", "pr", "True", appHandle);
            }
            else
            {
                Report.Fail("Data is updated in Promotional Rate section under Rate Determination page", "pr", "True", appHandle);
            }

        }

        public virtual void EnterValueInGeneralInformationFrequencgField(string freqval)
        {
            Application.WebAdmin.ClickonTabinProductPage("Statements");
            if (WebAdminPageFactory.WebAdminProductStatementsPage.EnterValueInGeneralInformationFrequencgField(freqval))
            {
                Report.Pass("Frequency value updated in general information section of statements page", "drt", "True", appHandle);
            }
            else
            {
                Report.Fail("Frequency value not updated in general information section of statements page", "drt", "True", appHandle);
            }

        }

        public virtual void UpdateValuesInMaturityInformationSection(string termval, string prinmatoptval, string intmatoptval)
        {
            Application.WebAdmin.ClickonTabinProductPage("Term Accounts");
            if (WebAdminPageFactory.TermAccountsMaturityRenewalPage.UpdateValuesInMaturityInformationSection(termval, prinmatoptval, intmatoptval))
            {
                Report.Pass("Maturity information data updated under term accounts", "tyu", "True", appHandle);
            }
            else
            {
                Report.Fail("Maturity information data updated under term accounts", "tyu", "True", appHandle);
            }


        }


        public virtual void UpdateRegDDAndCourtesyODCheckbox(bool checkboxregddturnONorOFFFlag = true)
        {

            Application.WebAdmin.ClickonTabinProductPage("U.S. Regulatory");
            if (WebAdminPageFactory.USRegulatoryRegulatoryPage.UpdateRegDDAndCourtesyODCheckbox(checkboxregddturnONorOFFFlag))
            {
                Report.Pass("The checkbox RegDD and CourtesyOD have been selected", "regdd", "True", appHandle);
            }
            else
            {
                Report.Fail("The checkbox RegDD and CourtesyOD have been selected", "regdd", "True", appHandle);
            }
        }

        public virtual void EnterDataForOptionsAndLimitInLinkedOverdraftPage(string optionval, string limitval)
        {
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Overdraft"), Data.Get("Linked Overdraft"));
            if (WebAdminPageFactory.OverdraftAuthorizedPage.EnterDataForOptionsAndLimitInLinkedOverdraftPage(optionval, limitval))
            {
                Report.Pass("Data for Linked overdraft updated", "linkod", "True", appHandle);
            }
            else
            {
                Report.Fail("Data for Linked overdraft not updated", "linkod", "True", appHandle);
            }


        }

        public virtual void EnterDataForFreqAndSelectChecboxForPrintComStatebillPer(string frqval)
        {
            Application.WebAdmin.ClickonTabinProductPage("Statements");
            if (WebAdminPageFactory.WebAdminProductStatementsPage.EnterDataForFreqAndSelectChecboxForPrintComStatebillPer(frqval))
            {
                Report.Pass("Data Entered for Statements tab", "tb", "True", appHandle);
            }
            else
            {
                Report.Fail("Data not Entered for Statements tab", "tb", "True", appHandle);
            }

        }

        public virtual string CreateServiceFeePlanNew(string effdate, string plantype, string balusedforcomp, string basefeeamont, string balroundmethod = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("ServiceFeePlans"));
            WebAdminPageFactory.ServiceFeePlanListPage.ClickOnAddButton();
            string servicefeeplan = WebAdminPageFactory.AddServiceFeePlanPage.CreateServiceFeePlanNew(effdate, plantype, balusedforcomp, basefeeamont, balroundmethod);
            if (servicefeeplan == "false")
            {
                Report.Fail("Service fee plan is not created " + servicefeeplan, "serplan", "True", appHandle);
            }
            else
            {
                Report.Pass("Service fee plan is created", "serplan " + servicefeeplan, "True", appHandle);
            }
            return servicefeeplan;

        }

        // public virtual void EnterInstitutionVariableRegulatory2PageOption(string sLabelNameLabelValuePipeDelimited)
        // {
        //     WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
        //     Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory 2"));
        //     string msg = "";
        //     if (sLabelNameLabelValuePipeDelimited.Contains(";"))
        //     {
        //         msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
        //         msg = string.Join(" , ", msg.Split(';'));
        //     }
        //     else
        //     {
        //         msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
        //     }
        //     WebAdminPageFactory.USRegulatoryRegulatory2Page.EnterRegulatory2PageOption(sLabelNameLabelValuePipeDelimited);
        //     if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
        //     {
        //         Report.Pass("Institution Variable Page option updated ", "InstitionVariableOptionSelected", "True", appHandle);
        //     }
        //     else
        //     {
        //         Report.Fail("Institution Variable Page option is not updated ", "InstitionVariableOptionNotSelected", "True", appHandle, true);
        //     }
        // }    




        public virtual void EnterDetailsForServiceFeePage(string feeplan, string feefrequency, string feeoption, string atmposval, string product)
        {
            Application.WebAdmin.GetProduct(Data.Get("GLOBAL_DEPOSIT_ACCT_CLASS"), Data.Get("DDA - Demand Deposits"), product);
            Application.WebAdmin.ClickonTabinProductPage(Data.Get("Service Fees"));

            if (WebAdminPageFactory.DepositProductServiceFeesPage.EnterDetailsForServiceFeePage(feeplan, feefrequency, feeoption, atmposval))
            {
                Report.Pass("Service Fee page data entered", "rg", "True", appHandle);
            }
            else
            {
                Report.Fail("Service Fee page data not entered", "rg", "True", appHandle);
            }

        }


        public virtual void UpdateWithholdPercentageForSpecificWithCalcMethod(string tablename, string withcalmethod, string withholdperval, string InterestandResidentRSPWithholdingSchedule = "", string InterestandResidentRSPWithholdingFixedAmount = "")
        {
            SelectLinkFromLeftPaneInWebAdmin("Table Configuration|General Table Management");
            if (WebAdminPageFactory.GeneralTableManagementPage.UpdateWithholdPercentageForSpecificWithCalcMethod(tablename, withcalmethod, withholdperval, InterestandResidentRSPWithholdingSchedule, InterestandResidentRSPWithholdingFixedAmount))
            {
                Report.Pass("Updated the withholding percentage for calculation method " + withcalmethod, "calimg", "True", appHandle);
            }
            else
            {
                Report.Fail("not updated the withholding percentage for calculation method " + withcalmethod, "calimg", "True", appHandle);
            }

        }


        public virtual void UpdateRetirementSavingbasedonplantype(string tablename, string rettype, string retdescription)
        {
            SelectLinkFromLeftPaneInWebAdmin("Table Configuration|General Table Management");
            if (WebAdminPageFactory.GeneralTableManagementPage.UpdateRetirementSavingbasedonplantype(tablename, rettype, retdescription))
            {
                Report.Pass("Retirment plan data updated", "retimghj", "True", appHandle);
            }
            else
            {
                Report.Fail("Retirment plan data not updated", "retimghj", "True", appHandle);
            }

        }

        public virtual void UpdateRetirementPlanSchedulerate(string tablename, string description, string RSPwithholdpercentageval, string indexnumofradiobtn)
        {
            SelectLinkFromLeftPaneInWebAdmin("Table Configuration|General Table Management");
            WebAdminPageFactory.GeneralTableManagementPage.UpdateRetirementPlanSchdulerate(tablename, description, RSPwithholdpercentageval, indexnumofradiobtn);
        }

        public virtual void ClickOnCheckboxNetDistributionswithWithholdingInRetirementtab()
        {
            SelectLinkFromLeftPaneInWebAdmin("Table Configuration|Institution Variables");
            Application.WebAdmin.ClickonTabinProductPage("Accounts");
            Application.WebCSR.ClickonLink("Retirement");
            if (WebAdminPageFactory.InstitutionVariablePage.ClickOnCheckboxNetDistributionswithWithholdingInRetirementtab())
            {
                Report.Pass("The checkbox is de-selected in retirement tab in institution variables", "intiimg", "True", appHandle);
            }
            else
            {
                Report.Fail("The checkbox is selected in retirement tab in institution variables", "intiimg", "True", appHandle);
            }
        }


        public virtual void UpdateFreqAndSubToWithholdcheckboxinPostingOptions(string freqval)
        {
            if (WebAdminPageFactory.DepositPostingOptionsPage.UpdateFreqAndSubToWithholdcheckboxinPostingOptions(freqval))
            {
                Report.Pass("Freq and subject to withholding checkbox checked in posting options", "postimg", "True", appHandle);
            }
            else
            {
                Report.Fail("Data not updated for Freq and subject to withholding checkbox in posting options", "postimg", "True", appHandle);
            }


        }
        public virtual void UpdateRegulationCCControlOptionInRegulatory2Page(string Amount, string DepositAmount, bool ONorOFF, string DaystoextendrepeatedOD, string Maximumnoofdaysfornewacct, string Daystoextendchecktype3RTtableholdsonamountsover5000, string Daystoextendchecktype3RTtableholddays)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory2"));
            WebAdminPageFactory.USRegulatoryRegulatory2Page.ClickOnInClearingNewAccountCalculationMethodCheckBox(ONorOFF);
            WebAdminPageFactory.USRegulatoryRegulatory2Page.UpdateCardDetails(Amount, DepositAmount);
            WebAdminPageFactory.USRegulatoryRegulatory2Page.UpdateRegulationCCControlOptions(DaystoextendrepeatedOD, Maximumnoofdaysfornewacct, Daystoextendchecktype3RTtableholdsonamountsover5000, Daystoextendchecktype3RTtableholddays);
            WebAdminPageFactory.USRegulatoryRegulatory2Page.ClickOnSubmitButton();
            if (WebAdminPageFactory.USRegulatoryRegulatory2Page.VerifyMessageInRegulatory2Page(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Regulation CC Control Options are Updated in US Regulatory2 Page", "Regulatory2", "true", appHandle);

            }
            else
            {
                Report.Fail("The Regulation CC Control Options was not Updated in US Regulatory Management Page", "Regulatory2fails", "true", appHandle, true);
            }
        }
        public virtual void VerifyRegulationCCControlOptionInRegulatory2Page(string LabelNamePipeDelimitedExpectedvalue)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory2"));
            if (WebAdminPageFactory.USRegulatoryRegulatory2Page.VerifyRegulatory2DetailsbyFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in US Regulatory 2 Page.", "USRegulatory2", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + "  in US Regulatory 2 Page.", "USRegulatory2", "True", appHandle, true);
            }

        }
        public virtual void VerifyFundsAvaliabliityDetails(string sProductClass, string sProductGroup, string sProductNumber, string LabelNamePipeDelimitedExpectedvalue)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Funds Availability"));
            if (WebAdminPageFactory.FundsAvailabilityPage.VerifyRegulatory2DetailsbyFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in Funds Availability Page.", "FundsAvailability", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + "  in Funds Availability Page.", "FundsAvailability", "True", appHandle, true);
            }

        }
        public virtual void UpdateMinimunDaysOriginateCollectionOrderInPaymentSystemPage(string OrderDays)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Payment System"));
            WebAdminPageFactory.TransactionProcessingPaymentSystemPage.UpdateMinimumDaysOriginateCollectionOrder(OrderDays);
            WebAdminPageFactory.TransactionProcessingPaymentSystemPage.ClickOnSubmit();
            if (WebAdminPageFactory.TransactionProcessingPaymentSystemPage.VerifyMessageInWebAdminPaymentSystemPage())
            {
                Report.Pass("Minimum Days Required for Originate Collection Order was updated In Payment System Page", "PaymentSystemPage", "true", appHandle);

            }
            else
            {
                Report.Fail("Minimum Days Required for Originate Collection Order was not updated In Payment System Page", "PaymentSystemPagefails", "true", appHandle, true);
            }


        }
        public virtual void UpdateReportAllNonResidentAlienson1042S(bool ONorOFF)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory"));
            WebAdminPageFactory.USRegulatoryRegulatoryPage.ClickOnReportAllNonresidentAliensOn1042sCheckBox(ONorOFF);
            WebAdminPageFactory.USRegulatoryRegulatoryPage.SelectSubmitButton();
            if (WebAdminPageFactory.USRegulatoryRegulatoryPage.VerifyMessageDepositRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Report All NonResident Aliens On 1042s Options is Updated in US Regulatory2 Page", "Regulatory", "true", appHandle);

            }
            else
            {
                Report.Fail("The Report All NonResident Aliens On 1042s option not Updated in US Regulatory Management Page", "Regulatoryfails", "true", appHandle, true);
            }

        }
        public virtual void EnterInstitutionVariableRegulatory2PageOption(string sLabelNameLabelValuePipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory 2"));
            string msg = "";
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
                msg = string.Join(" , ", msg.Split(';'));
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
            }
            WebAdminPageFactory.USRegulatoryRegulatory2Page.EnterRegulatory2PageOption(sLabelNameLabelValuePipeDelimited);
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Institution Variable Page option updated ", "InstitionVariableOptionSelected", "True", appHandle);
            }
            else

            {
                Report.Fail("Institution Variable Page option is not updated ", "InstitionVariableOptionNotSelected", "True", appHandle, true);
            }
        }
        public virtual void UpdateRelationshipofTheProduct(string sProductClass, string sProductGroup, string sProductNumber, string Channelname, string RelationshipCode)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Product Offers"));

            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SelectChannel(Channelname);
            Report.Info(Channelname + " channel is selected.", "channelselected", "True", appHandle);
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.SetRelationshipForSpecificedProductNumber(sProductNumber, RelationshipCode);
            WebAdminPageFactory.WebAdminProductOfferConfigurationPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.WebAdminProductOfferConfigurationPage.VerifyMessageProductOfferConfigurationPage(Data.Get("The relationship(s) for the product type has been modified.")))
            {
                Report.Pass("Relationship for " + sProductNumber + " Product type is modified successfully. " + Channelname + " application.", "RelationModified" + Channelname + "", "True", appHandle);
            }
            else
            {
                Report.Fail("Relationship for " + sProductNumber + " Product type is modified successfully. ", "RelationModified" + Channelname + "", "True", appHandle, true);
            }



        }
        public virtual void UpdateFDIC370MaximumInsuranceAmount(string amount)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory2"));
            WebAdminPageFactory.USRegulatoryRegulatory2Page.UpdateFDIC370MaximumInssuranceAmount(amount);
            WebAdminPageFactory.USRegulatoryRegulatory2Page.ClickOnSubmitButton();
            if (WebAdminPageFactory.USRegulatoryRegulatory2Page.VerifyMessageInRegulatory2Page(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The FDIC370 Maximum Insurance Amount are Updated in US Regulatory2 Page", "Regulatory2", "true", appHandle);

            }
            else
            {
                Report.Fail("The FDIC370 Maximum Insurance Amount was not Updated in US Regulatory Management Page", "Regulatory2fails", "true", appHandle, true);
            }



        }
        public virtual void UpdateGeneralPageOption(string sProductClass, string sProductGroup, string sProductNumber, string sLabelNameLabelValuePipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();
            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            string msg = "";
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
                msg = string.Join(" , ", msg.Split(';'));
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
            }
            WebAdminPageFactory.GeneralPage.EnterValuesForGeneralPageField(sLabelNameLabelValuePipeDelimited);
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Fields are updated in product General Page.", "GeneralFieldUpdated", "True", appHandle);
            }
            else

            {
                Report.Fail("Fields are not updated in product General Page.", "GeneralFieldUpdated", "True", appHandle, true);
            }

        }
        public virtual void FDIC370DepositInsuranceCalculation()
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("FDIC 370") + "|" + Data.Get("Deposit Insurance Calculation"));
            WebAdminPageFactory.FDIC370Page.ClickonRun();
            WebAdminPageFactory.FDIC370Page.VerifyMessageInFDIC370(Data.Get("Function Deposit Insurance Calculation has been submitted"));
            Report.Info("FDIC 370 Deposit Insurance Calculation function is runned", "FDIC370", "True", appHandle);


        }
        public virtual void FDIC370AccountParticipationExtract()
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("FDIC 370") + "|" + Data.Get("Account Participant Extract"));
            WebAdminPageFactory.FDIC370Page.ClickonRun();
            WebAdminPageFactory.FDIC370Page.VerifyMessageInFDIC370(Data.Get("Function Account Participant Extract has been submitted"));
            Report.Info("FDIC 370 Deposit Insurance Calculation function is runned", "AcctParticipantExtract", "True", appHandle);


        }
        public virtual void FDIC370AccountExtract(string HoldType)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("FDIC 370") + "|" + Data.Get("Account Participant Extract"));
            WebAdminPageFactory.FDIC370Page.SelectHoldType(HoldType);
            WebAdminPageFactory.FDIC370Page.ClickonRun();
            WebAdminPageFactory.FDIC370Page.VerifyMessageInFDIC370(Data.Get("Function Account Extract has been submitted"));
            Report.Info("FDIC 370 Deposit Insurance Calculation function is runned", "AcctParticipantExtract", "True", appHandle);


        }


        // public virtual void UpdateGeneralPageOption(string sProductClass,string sProductGroup,string sProductNumber,string sLabelNameLabelValuePipeDelimited)
        // {
        //     WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
        //     WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
        //     WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();
        //     if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
        //     {
        //         Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
        //     }
        //     WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
        //     string msg = "";
        //     if (sLabelNameLabelValuePipeDelimited.Contains(";"))
        //     {
        //         msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
        //         msg = string.Join(" , ", msg.Split(';'));
        //     }
        //     else
        //     {
        //         msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
        //     }
        //     WebAdminPageFactory.GeneralPage.EnterValuesForGeneralPageField(sLabelNameLabelValuePipeDelimited);
        //     if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
        //     {
        //         Report.Pass("Institution Variable Page option updated ", "InstitionVariableOptionSelected", "True", appHandle);
        //     }
        //     else

        //     {
        //         Report.Fail("Institution Variable Page option is not updated ", "InstitionVariableOptionNotSelected", "True", appHandle, true);
        //     }


        // }    
        public virtual void AddNewCardBINInCRDBINTableInWebadmin(string TableName, string BinNo, string Desc = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
            WebAdminPageFactory.GeneralTableManagementPage.AddNewCardBin(BinNo, Desc);
            Report.Info("Data enter in the CardBin Page Successfully", true);
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButtonForCard();
            Report.Pass(BinNo + "added to UTBLCRDBIN table successfully", "BINAddedtoTable", "True", appHandle);

        }

        public virtual void VerifyErrorMessegeForInvalidBin(string TableName, string InvalidBin, string Desc = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
            WebAdminPageFactory.GeneralTableManagementPage.EnterInvalidBinNumber(InvalidBin, Desc);
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButtonForCard();
            InvalidBin = InvalidBin.TrimStart('0');
            if (WebAdminPageFactory.GeneralTableManagementPage.VerifyMessageInstitutionVariable(InvalidBin + "|Invalid BIN " + InvalidBin + ". Length must be 6 or 8."))
            {
                Report.Pass(InvalidBin + "|Invalid BIN " + InvalidBin + ".Length must be 6 or 8. is displayed in CRDBIN page.", "ErrorMessegeDisplayed", "True", appHandle);
            }
            else

            {
                Report.Fail("Error Messege is not Displayed in CardBin Page. ", "ErrorMessegeNotDisplayed", "True", appHandle, true);
            }


        }
        public virtual void EnterDetailsForCardTypePageOption(string TableName, string sLabelNameLabelValuePipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
            WebAdminPageFactory.GeneralTableManagementPage.ClickOnAddButton();
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
            Report.Info("Data Entered in CRDTYPE page.", "tblpass", "True", appHandle);
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButtonForCard();


        }

        public virtual void VerifyErrorMessage(string msg)
        {
            if (WebAdminPageFactory.GeneralTableManagementPage.VerifyMessageInstitutionVariable(msg))
            {
                Report.Pass(msg, "ErrorMessegeDisplayed", "True", appHandle);
            }
            else
            {
                Report.Fail("Error Messege is not Displayed in CardBin Page. ", "ErrorMessegeNotDisplayed", "True", appHandle, true);
            }
        }

        public virtual void VerifyCardTypeDetails(string TableName, string crdtyp, string sLabelNameLabelValuePipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
            WebAdminPageFactory.GeneralTableManagementPage.SearchCardTypeFromTable(crdtyp);
            WebAdminPageFactory.GeneralTableManagementPage.ClickOnEditButton();
            Profile7CommonLibrary.VerifyValueByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
            Report.Info("Data verified in CRDTYPE page.", "tblpass", "True", appHandle);
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButtonForCard();

        }

        public virtual void UpdateCardTypeData(string TableName, string crdtyp, string sLabelNameLabelValuePipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
            WebAdminPageFactory.GeneralTableManagementPage.SearchCardTypeFromTable(crdtyp);
            WebAdminPageFactory.GeneralTableManagementPage.ClickOnEditButton();
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
            Report.Info("Data Entered in CRDTYPE page.", "tblpass", "True", appHandle);
            WebAdminPageFactory.GeneralTableManagementPage.ClickSubmitButtonForCard();
        }

        public virtual string AddCardTypeInCRDTYPTable(string TableName, string sLabelNameLabelValuePipeDelimited)
        {
            bool flag = false;
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
            WebAdminPageFactory.GeneralTableManagementPage.ClickOnAddButton();
            string CardType = WebAdminPageFactory.GeneralTableManagementPage.AddCardType(sLabelNameLabelValuePipeDelimited);
            Report.Info(CardType + "Card Added Successfully .", "tblpass", "True", appHandle);
            if (WebAdminPageFactory.WebAdminProductCopyPage.IsProdExistsMsg())
            {
                do
                {
                    WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
                    WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(TableName);
                    WebAdminPageFactory.GeneralTableManagementPage.ClickOnAddButton();
                    CardType = WebAdminPageFactory.GeneralTableManagementPage.AddCardType(sLabelNameLabelValuePipeDelimited);
                    if (!WebAdminPageFactory.WebAdminProductCopyPage.IsProdExistsMsg())
                    {
                        flag = true;
                        Report.Info(CardType + " data is existing.", "prodcopyDataexist", "True", appHandle);
                        break;
                    }
                    else
                    {
                        continue;
                    }

                }
                while (flag == false);

            }
            return CardType;

        }
        public virtual void EditRatesOfTiredInterestIndex(string InterestIndex, string EffectiveDate = "", string TiredIndexRateDetailsPipeDelimited = "",bool AnticipatedONorOFF=true,bool DayendONorOFF=true)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
            WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(InterestIndex);
            WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
            WebAdminPageFactory.IndexListPage.SelectEffectiveDate(EffectiveDate);
            WebAdminPageFactory.IndexListPage.ClickOnEditButton();

            if (!string.IsNullOrEmpty(TiredIndexRateDetailsPipeDelimited))
            {
                WebAdminPageFactory.IndexListPage.IsAnticipatedDayend(AnticipatedONorOFF,DayendONorOFF);
                if (WebAdminPageFactory.IndexListPage.EnterDataInTieredInterestIndexRates(TiredIndexRateDetailsPipeDelimited))
                { }
                else
                {
                    Report.Fail("Please check the input values passed.", "dataentrfailed", "True", appHandle, true);
                }
            }

            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            if (WebAdminPageFactory.IndexAddPage.VerifyMessageInInterestAddPage("Rates for index " + InterestIndex + " have been modified.")||
            WebAdminPageFactory.IndexAddPage.VerifyMessageInInterestAddPage("Rates for index " + InterestIndex + " have been modified in anticipated mode."))
            {
                Report.Pass("Rates for index " + InterestIndex + " have been modified.", "interestrateedit", "True", appHandle);
            }
            else
            {
                Report.Fail("Rates for index " + InterestIndex + " have not been modified.", "interestrateeditFail", "True", appHandle, true);
            }
        }

        public virtual void RatesOfTiredInterestIndexErrorMessage(string InterestIndex, string EffectiveDate = "", string TiredIndexRateDetailsPipeDelimited = "", string messag = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
            WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(InterestIndex);
            WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
            WebAdminPageFactory.IndexListPage.ClickOnAddButton();
            if (string.IsNullOrEmpty(EffectiveDate))
            {
                EffectiveDate = this.GetApplicationDate();
            }
            WebAdminPageFactory.IndexListPage.EnterEffectiveDate(EffectiveDate);
            Report.Info(EffectiveDate + " has been entered as entered as effective date.", "effectivedate", "True", appHandle);
            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();

            if (!string.IsNullOrEmpty(TiredIndexRateDetailsPipeDelimited))
            {
                if (WebAdminPageFactory.IndexListPage.EnterDataInTieredInterestIndexRates(TiredIndexRateDetailsPipeDelimited))
                { }
                else
                {
                    Report.Fail("Please check the input values passed.", "dataentrfailed", "True", appHandle, true);
                }
            }

            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.IndexListPage.VerifyMessageInIndexListPage(messag))
            {
                Report.Pass(messag, "interestratevalidated", "True", appHandle);
            }
            else
            {
                Report.Fail("Error not displayed", "True", appHandle, true);
            }
        }
        public virtual void EditRatesOfTiredInterestIndexErrorMessage(string InterestIndex, string EffectiveDate = "", string TiredIndexRateDetailsPipeDelimited = "", string messag = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
            WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(InterestIndex);
            WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
            WebAdminPageFactory.IndexListPage.SelectEffectiveDate(EffectiveDate);
            WebAdminPageFactory.IndexListPage.ClickOnEditButton();

            if (!string.IsNullOrEmpty(TiredIndexRateDetailsPipeDelimited))
            {
                if (WebAdminPageFactory.IndexListPage.EnterDataInTieredInterestIndexRates(TiredIndexRateDetailsPipeDelimited))
                { }
                else
                {
                    Report.Fail("Please check the input values passed.", "dataentrfailed", "True", appHandle, true);
                }
            }

            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.IndexListPage.VerifyMessageInIndexListPage(messag))
            {
                Report.Pass(messag, "interestratevalidated", "True", appHandle);
            }
            else
            {
                Report.Fail("Error not displayed", "True", appHandle, true);
            }
        }

        public virtual void VerifyInterestIndexTableValues(string refColumnValuesSemicolonDelimited, string InterestIndex, string sEffectiveDate)
        {
            if (!appHandle.GetTitle().Contains(Data.Get("Edit Tiered Index Rates")))
            {
                WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
                WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(InterestIndex);
                WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
                WebAdminPageFactory.IndexEffectiveDatesListPage.SelectEffectiveDateForIndex(sEffectiveDate);
                WebAdminPageFactory.IndexListPage.ClickOnEditButton();

            }
            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (refColumnValuesSemicolonDelimited.Contains("|"))
            {
                arr = refColumnValuesSemicolonDelimited.Split('|');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split(';')) + " is captured successfully in  Interest Index Summary table in WebCSR.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", refColumnValuesSemicolonDelimited.Split(';')) + " is captured successfully in  Interest Index Summary table in WebCSR.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebAdminPageFactory.IndexListPage.VerifyDataInInterestIndexPage(refColumnValuesSemicolonDelimited))
            {
                Report.Pass(msg, "InterestIndexSummaryCheck", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "InterestIndexSummaryCheck", "True", appHandle, true);
            }
        }
        public virtual void updateLoanCalculationPageOption(string sProductClass = "", string sProductGroup = "", string sProductNumber = "", string sAccrualCalcMethod = "", string sAccrualCalcBalOpt = "", string sMinBalToAccrue = "", string AccountingAccrCalMethod = "", bool ckbCalInt = true, string InterestRateDisclosureMethod = "", string calculationnominalinterestratecalculationmethod = "", string InterestColletionMethod = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"));

            WebAdminPageFactory.LoanInterestCalculationPage.EnterInterestCalculationOptions(sAccrualCalcMethod, sAccrualCalcBalOpt, sMinBalToAccrue, AccountingAccrCalMethod, ckbCalInt, InterestRateDisclosureMethod, calculationnominalinterestratecalculationmethod, InterestColletionMethod);
            WebAdminPageFactory.LoanInterestCalculationPage.ClickOnSubmit();
            if (WebAdminPageFactory.LoanInterestCalculationPage.VerifyMessageInWebAdminLoanInterestCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Loan Calculation option is updated in Calculation Page", "CalculationFieldupdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Loan Calculation option not updated in Calculation Page.", "CalculationFieldNotUpdated", "True", appHandle, true);
            }

        }
        public virtual void UpdateLoanCalculationOptionsPage(string sProductClass, string sProductGroup, string sProductNumber, bool ciampcCheckBoXOnorOff, bool fpfpCheckBox, string amortizationTerm = "", string paymentCalMet = "", string intDeterminationPoint = "", string PaymentFrequency = "", string PaymentRecalculationMethod = "", string AdjustmentsAfterInterestRateChange = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("GLOBAL_PAYMENT_CALCULATION_TAB"));
            WebAdminPageFactory.LoanPaymentCalculationPage.EnterLoanCalculationOptions(ciampcCheckBoXOnorOff, fpfpCheckBox, amortizationTerm, paymentCalMet, intDeterminationPoint, PaymentFrequency, PaymentRecalculationMethod, AdjustmentsAfterInterestRateChange);
            WebAdminPageFactory.LoanPaymentCalculationPage.ClickOnSubmit();
            if (WebAdminPageFactory.LoanPaymentCalculationPage.VerifyMessageInWebAdminLoanPaymentCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Full Period to First Payment is updated in Payment Calculation Page", "calculationOptions", "true", appHandle);
            }
            else
            {
                Report.Fail("The Full Period to First Payment is  not updated in Payment Calculation Page", "calculationOptionsfail", "true", appHandle, true);
            }
        }


        public virtual void EditAndAddRatesToInterestIndex(string IndexType, string InterestIndex, string EffectiveDate = "", string BasisIndexRate = "", string ComparativeIndexAccountLevelRate = "", string ComparativeIndexIndexLevelRate = "", string TiredIndexRateDetailsPipeDelimited = "", bool AnticipatedONorOFF = true, string BalancePipeDelimitedRate = "", bool DayendONorOFF = true)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Interest Indexes"));
            WebAdminPageFactory.IndexListPage.SelectSpecifiedIndexName(InterestIndex);
            WebAdminPageFactory.IndexListPage.ClickOnRatesButton();
            WebAdminPageFactory.IndexEffectiveDatesListPage.SelectEffectiveDateForIndex(EffectiveDate);
            WebAdminPageFactory.IndexListPage.ClickOnEditButton();

            switch (IndexType)
            {
                case "1 - Tiered Index":
                    if (!string.IsNullOrEmpty(TiredIndexRateDetailsPipeDelimited))
                    {
                        if (WebAdminPageFactory.IndexEffectiveDatesListPage.ModifyRatesInInterestIndex(TiredIndexRateDetailsPipeDelimited, EffectiveDate, AnticipatedONorOFF, DayendONorOFF))
                        { }
                        else
                        {
                            Report.Fail("Please check the input values passed.", "dataentrfailed", "True", appHandle, true);
                        }
                    }
                    break;

            }
            WebAdminPageFactory.IndexAddPage.ClickOnSubmitButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            if (WebAdminPageFactory.IndexAddPage.VerifyMessageInInterestAddPage("Rates for index " + InterestIndex + " have been modified"))
            {
                Report.Pass("Rates have been added to the index.", "interestrateadd", "True", appHandle);
            }
            else
            {
                Report.Fail("Rates have not been added to the index.", "interestrateaddFail", "True", appHandle, true);
            }
        }
        public virtual void EnterPaymentCalculationDetails(string sProductClass, string sProductGroup, string sProductNumber, string PaymentCalculationDetailsSemecolonDelimited)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Payment Calculation"));
            WebAdminPageFactory.PaymentCalculationOptionsPage.EnterDetailsForPaymentCalculation(PaymentCalculationDetailsSemecolonDelimited);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.LoanUSRegulatoryPage.VerifyMessageLoanUSRegulatoryOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Loan PaymentCalculation details updated successfully.", "MaturityProcessingFieldupdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Loan PaymentCalculation details are not updated successfully.", "MaturityProcessingFieldNotUpdated", "True", appHandle, true);
            }

        }
        public virtual void EnterGeneralPageDetails(string sProductClass, string sProductGroup, string sProductNumber, string GeneralPageDetailsSemecolonDelimited)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(GeneralPageDetailsSemecolonDelimited);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.LoanUSRegulatoryPage.VerifyMessageLoanUSRegulatoryOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Loan General Page option is updated successfully.", "MaturityProcessingFieldupdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Loan General Page options are not updated.", "MaturityProcessingFieldNotUpdated", "True", appHandle, true);
            }

        }
        public virtual void EnterPaymentApplicationPageDetails(string sProductClass, string sProductGroup, string sProductNumber, string PaymentApplicationDetailsSemecolonDelimited)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Payment Application"));
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(PaymentApplicationDetailsSemecolonDelimited);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.LoanUSRegulatoryPage.VerifyMessageLoanUSRegulatoryOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Payment Appliation page details updated successfully.", "MaturityProcessingFieldupdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Payment Application page details are not updated successfully.", "MaturityProcessingFieldNotUpdated", "True", appHandle, true);
            }
        }

        public virtual void EnterDelinquencyPageDetails(string sProductClass, string sProductGroup, string sProductNumber, string DelinquecyPageDetailsSemecolonDelimited)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Delinquency"));
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(DelinquecyPageDetailsSemecolonDelimited);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
            if (WebAdminPageFactory.LoanUSRegulatoryPage.VerifyMessageLoanUSRegulatoryOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Loan Delinquency page details updated successfully.", "MaturityProcessingFieldupdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Loan Delinquency page details are not updated successfully.", "MaturityProcessingFieldNotUpdated", "True", appHandle, true);
            }
        }

        public virtual void EditTransactionCodeDetails(string transactioncode)
        {
            WebAdminPageFactory.TransactionCodeCopyPage.selecttransactioncode(transactioncode);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnEditButton();
        }
        public virtual void UpdateTransactionCodeDetails(string transactioncodedetailspipedelimited)
        {
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(transactioncodedetailspipedelimited);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();

        }
        public virtual void RunTableCompilation()
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Table Compilation"));
            WebAdminPageFactory.GeneralTableManagementPage.RecomipleAll();
            appHandle.SwitchTo(SwitchInto.ALERT);
            appHandle.Wait_For_Specified_Time(3);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);
            appHandle.SwitchTo(SwitchInto.DEFAULT);
        }


        public virtual void EnterInstitutionVariablePageOption(string tabName, string sLabelNameLabelValuePipeDelimited)
        {

            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
            switch (tabName)
            {
                case "Accounts":

                    if (tabName.Equals("Accounts"))
                    {
                        Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Accounts"));
                    }
                    break;

                case "Deposit":
                    if (tabName.Equals("Deposit"))
                    {
                        Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Accounts"), Data.Get("Deposit"));
                    }
                    break;
                case "Payment System":
                    if (tabName.Equals("Payment System"))
                    {
                        Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Payment System"));
                    }
                    break;
                case "Regulatory2":
                    if (tabName.Equals("Regulatory2"))
                    {
                        Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory2"));
                    }
                    break;
                case "System Management":
                    if (tabName.Equals("System Management"))
                    {
                        Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("System"), Data.Get("System Management"));
                    }
                    break;
                case "U.S. Regulatory":
                    if (tabName.Equals("U.S. Regulatory"))
                    {
                        Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));
                    }
                    break;

                case "Retirement":
                    if (tabName.Equals("Retirement"))
                    {
                        Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Accounts"), Data.Get("Retirement"));
                    }
                    break;
                case "Regulatory":
                    if (tabName.Equals("Regulatory"))
                    {
                        Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory"));
                    }
                    break;

                default:
                    WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("Institution Variables"));
                    break;

            }
            string msg = "";
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
                msg = string.Join(" , ", msg.Split(';'));
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Replace("|", " = ");
            }
            WebAdminPageFactory.USRegulatoryRegulatory2Page.EnterRegulatory2PageOption(sLabelNameLabelValuePipeDelimited);
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Institution Variable Page option updated ", "InstitionVariableOptionSelected", "True", appHandle);
            }
            else

            {
                Report.Fail("Institution Variable Page option is not updated ", "InstitionVariableOptionNotSelected", "True", appHandle, true);
            }
        }

        public virtual string GetRespondentIDFR2420FromInstitution()
        {
            SelectLinkFromLeftPaneInWebAdmin("Table Configuration|Institution Variables");
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Regulatory2"));
            string val = WebAdminPageFactory.USRegulatoryRegulatory2Page.GetRespondentIDFR2420();
            if (!string.IsNullOrEmpty(val))
            {
                Report.Pass("Respondent id is fetched", "hty", "True", appHandle);
            }
            else
            {
                Report.Fail("Respondent id value is not fetched", "hty", "True", appHandle);
            }

            return val;
        }

        public virtual void VerifyDataNotInProfileReports(string ReportIDOrDESC, string ToVerifyValuesByPipeDelimited, string SearchCriteriaPipeDelimited = "")
        {
            if (this.VerifyProfileReports(ReportIDOrDESC, ToVerifyValuesByPipeDelimited, SearchCriteriaPipeDelimited))
            {
                Report.Fail("The data is present in specified file. Please check the parameter");

            }
            else
            {
                Report.Pass("The data is not present in specified file");

            }

        }


        public virtual void updateTransactionCodeBackOfficePage(string sProductClass = "", string sProductGroup = "", string sProductNumber = "", string unInsurePrincipal = "", string BackOfficeUninsuredPositiveAccruedInterestDebit = "", string BackOfficeUninsuredPositiveAccruedInterestCredit = "", string BackOfficeUninsuredNegAccIntonPosBalCredit = "", string BackOfficeUninsuredNegAccIntCredit = "", string BackOfficeUninsuredPosIntAccOnNegBalCredit = "", string BackOfficeUninsuredUncollIntCredit = "")
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Product Factory") + "|" + Data.Get("Products"));
            WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductClassGroup(sProductClass, sProductGroup);
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnSearchBUtton();

            if (WebAdminPageFactory.WebAdminProductsCommonPage.SelectProductToBeCopied(sProductNumber))
            {
                Report.Info(sProductNumber + " is selected from Products List.", "prodselect", "True", appHandle);
            }
            WebAdminPageFactory.WebAdminProductsCommonPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Codes"), Data.Get("Back Office"));
            if (WebAdminPageFactory.DepositTransactionCodePage.WaitUntilTransactionCodeBackOfficePageloads())
            {
                WebAdminPageFactory.DepositTransactionCodePage.EnterTransactionCodeBackOfficeDetails(unInsurePrincipal, BackOfficeUninsuredPositiveAccruedInterestDebit, BackOfficeUninsuredPositiveAccruedInterestCredit, BackOfficeUninsuredNegAccIntonPosBalCredit, BackOfficeUninsuredNegAccIntCredit, BackOfficeUninsuredPosIntAccOnNegBalCredit, BackOfficeUninsuredUncollIntCredit);
                WebAdminPageFactory.DepositTransactionCodePage.SelectSubmitButton();
                if (WebAdminPageFactory.DepositTransactionCodePage.VerifyMessageDepositTransactionCodeAdjustmentPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Transaction codes are updated in Transaction Code Back Office Page", "TransactionCodeBackOfficeUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Transaction codes are updated in Transaction Code Back Office Page", "TransactionCodeBackOfficeNotUpdated", "True", appHandle, true);
                }
            }

        }

        public virtual void GenerateFDICExtract(string pageName, string holdtype = "")
        {
            switch (pageName)
            {
                case "Account Extract":

                    if (pageName.Equals("Account Extract"))
                    {
                        WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("FDIC 370") + "|" + Data.Get("Account Extract"));
                        WebAdminPageFactory.ApplyHoldandRestrictAccess.EnterHoldTypefromOption(holdtype);
                        WebAdminPageFactory.ApplyHoldandRestrictAccess.ClickOnRunButton();

                    }
                    break;

                case "Pending Extract":
                    if (pageName.Equals("Pending Extract"))
                    {
                        WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("FDIC 370") + "|" + Data.Get("Pending Extract"));
                        WebAdminPageFactory.DepositInsuranceCalculation.ClickOnRunButton();
                    }
                    break;

                case "Deposit Insurance Calculation":
                    if (pageName.Equals("Deposit Insurance Calculation"))
                    {
                        WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("FDIC 370") + "|" + Data.Get("Deposit Insurance Calculation"));
                        WebAdminPageFactory.DepositInsuranceCalculation.ClickOnRunButton();
                    }
                    break;
                default:

                    break;
            }
            if (WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable("Function Pending Extract has been submitted.") ||
            WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable("Function Deposit Insurance Calculation has been submitted.") ||
            WebAdminPageFactory.InstitutionVariablePage.VerifyMessageInstitutionVariable("Function Account Extract has been submitted."))
            {
                Report.Pass("Function Pending Extract has been submitted. ", "FunctionPendingExtractGenerated", "True", appHandle);
            }
            else

            {
                Report.Fail("Function Pending Extract has not been submitted. ", "FunctionPendingExtractNotGenerated", "True", appHandle, true);
            }

        }

        public virtual string GetDataFromFunctionalProcessingStatusPopupWidow(string functionname, string linkname, string labelname)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Utilities") + "|" + Data.Get("Function Processing Status"));
            string labelvalue = WebAdminPageFactory.FunctionProcessingStatusPage.SearchforFunction(functionname, linkname, labelname);
            Report.Pass("Function Processing Details ", "popup", "true", appHandle);
            WebAdminPageFactory.FunctionProcessingStatusPage.ClosePopup();
            return labelvalue;

        }

        public virtual void EnterTransactionProcessingDetails(string sProductClass, string sProductGroup, string sProductNumber, string TransactionProcessingDetailsSemecolonDelimited)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication("Transaction Processing");
            Profile7CommonLibrary.EnterDataByLabelNameLabelValue(TransactionProcessingDetailsSemecolonDelimited);
            WebAdminPageFactory.WebAdminMasterPage.ClickOnSubmitButton();
            if (WebAdminPageFactory.LoanUSRegulatoryPage.VerifyMessageLoanUSRegulatoryOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Loan PaymentCalculation details updated successfully.", "MaturityProcessingFieldupdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Loan PaymentCalculation details are not updated successfully.", "MaturityProcessingFieldNotUpdated", "True", appHandle, true);
            }

        }

        public virtual void UpdateTransactionCodePageOption(string sProductClass, string sProductGroup, string sProductNumber, string strLabelNamePipeDelimitedLabelValuecolonDelimited)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Codes"));
            WebAdminPageFactory.TransactionCodesPage.EnterDataByLabelNameInTransactionCodePage(strLabelNamePipeDelimitedLabelValuecolonDelimited);
            WebAdminPageFactory.WebAdminDepositRateDeterminationPage.SelectSubmitButton();
            if (WebAdminPageFactory.WebAdminDepositRateDeterminationPage.VerifyMessageDepositRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Transaction Code page has been updated", "TransactionCodeUpdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Transaction Code page has not been updated", "TransactionCodesNotUpdated", "True", appHandle, true);
            }
        }
        public virtual void UpdateDepositProductGeneralPageDetails(string sProductClass, string sProductGroup, string sProductNumber, string depositProdGeneraloptionssemecolondelemited = "")
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("General"), "");
            if (WebAdminPageFactory.WebAdminProductsGeneralPage.WaitUntilDepositProductGeneralPageLoad())
            {
                WebAdminPageFactory.WebAdminProductsGeneralPage.EnterDepositProdGeneralOptions(depositProdGeneraloptionssemecolondelemited);
                WebAdminPageFactory.WebAdminProductsGeneralPage.select_submit_button();
                if (WebAdminPageFactory.WebAdminProductsGeneralPage.VerifyMessageWebAdminProductGeneralPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Fields are updated in deposit product General Page.", "DepositGeneralFieldUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Fields are not updated in deposit product General Page.", "DepositGeneralFieldUpdated", "True", appHandle, true);
                }
            }
        }
        public virtual void VerifyServiceFeePlanParameters(string feePlan, string effectiveDate, string LabelNameLabelValueSemiPipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("ServiceFeePlans"));
            WebAdminPageFactory.ServiceFeePlanListPage.SelectFeePlanFromFeePlanTable(feePlan);
            WebAdminPageFactory.ServiceFeePlanListPage.ClickEditButton();
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.SelectRadioButtonInFeePlanTable(effectiveDate);
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.ClickOnEditButton();
            Profile7CommonLibrary.VerifyValueByLabelNameLabelValue(LabelNameLabelValueSemiPipeDelimited);
        }
        public virtual void AddServiceFeePlanFees(string feePlan, string effectiveDate, string feesCategory, string LabelNameLabelValueSemiPipeDelimited)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("ServiceFeePlans"));
            WebAdminPageFactory.ServiceFeePlanListPage.SelectFeePlanFromFeePlanTable(feePlan);
            WebAdminPageFactory.ServiceFeePlanListPage.ClickEditButton();
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.SelectRadioButtonInFeePlanTable(effectiveDate);
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication("Fees");
            WebAdminPageFactory.ServiceFeePlanListPage.ClickOnAddButton();
            WebAdminPageFactory.AddServiceFeePlanPage.SelectServiceFeePlanFeesCategory(feesCategory);
            WebAdminPageFactory.AddServiceFeePlanPage.EnterDetailsOfServiceFeePlanFees(LabelNameLabelValueSemiPipeDelimited);
            WebAdminPageFactory.AddServiceFeePlanPage.ClickSubmitButton();
            if (WebAdminPageFactory.PlanFeesPage.CheckSuccessMsg("The fees for the service fee plan have been created."))
            {
                Report.Pass("The fees for the service fee plan is added successfully.", "serviceFeePlanFees", "True", appHandle);
            }
            else
            {
                Report.Fail("The fees for the service fee plan is not added.", "serviceFeePlanFees", "True", appHandle);
            }
        }
        public virtual void DeleteServiceFeePlansFees(string feePlan, string date, string category)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("ServiceFeePlans"));
            WebAdminPageFactory.ServiceFeePlanListPage.SelectFeePlanFromFeePlanTable(feePlan);
            WebAdminPageFactory.ServiceFeePlanListPage.ClickEditButton();
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.SelectRadioButtonInFeePlanTable(date);
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.ClickOnEditButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication("Fees");
            WebAdminPageFactory.PlanFeesPage.DeletePlanFees(category);
            if (WebAdminPageFactory.PlanFeesPage.VerifyMessageInPlanFeesPage("The fees for the service fee plan have been deleted."))
            {
                Report.Pass("The fees for the service fee plan is deleted successfully.", "serviceFeePlanFees", "True", appHandle);
            }
            else
            {
                Report.Fail("The fees for the service fee plan is not deleted.", "serviceFeePlanFees", "True", appHandle);
            }
        }
        public virtual void DeleteRecordInGeneralTableManagementUTBLTRNGRPT(string tablename, string TransactionCodeGroup, string TranCodeGroupDate)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("Table Configuration") + "|" + Data.Get("NameGeneralTableManagment"));
            WebAdminPageFactory.GeneralTableManagementPage.SelectTableFromGeneralTableManagment(tablename);
            WebAdminPageFactory.AddServiceFeeTransactionCodeGroupPage.DeleteRecordInTableUTBLTRNGRPT(TransactionCodeGroup, TranCodeGroupDate);
        }
        public virtual void DeleteServiceFeePlans(string feePlan, string date)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("TableConfiguration") + "|" + Data.Get("ServiceFeePlans"));
            WebAdminPageFactory.ServiceFeePlanListPage.SelectFeePlanFromFeePlanTable(feePlan);
            WebAdminPageFactory.ServiceFeePlanListPage.ClickEditButton();
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.SelectRadioButtonInFeePlanTable(date);
            WebAdminPageFactory.ServiceFeePlanEffectDateListPage.ClickOnDeleteButton();
            if (WebAdminPageFactory.PlanFeesPage.VerifyMessageInPlanFeesPage("The effective date for the service fee plan has been deleted."))
            {
                Report.Pass("The fees for the service fee plan is deleted successfully.", "serviceFeePlanFees", "True", appHandle);
            }
            else
            {
                Report.Fail("The fees for the service fee plan is not deleted.", "serviceFeePlanFees", "True", appHandle);
            }
        }
        public virtual void AddApplyHoldandRestricAccessInFDIC370Page(string holdtype)
        {
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("FDIC 370") + "|" + Data.Get("Apply Hold and Restrict Access"));
            WebAdminPageFactory.ApplyHoldandRestrictAccess.EnterHoldTypefromOption(holdtype);
            WebAdminPageFactory.ApplyHoldandRestrictAccess.ClickOnRunButton();
            WebAdminPageFactory.AdministrationCenterPage.ClickLinkFromMenuItem(Data.Get("FDIC 370") + "|" + Data.Get("Deposit Insurance Calculation"));
            WebAdminPageFactory.DepositInsuranceCalculation.ClickOnRunButton();

            
        }
        public virtual void UpdateLoanInterestCapitalizedInterestProcessingPageOption(string sProductClass, string sProductGroup, string sProductNumber, string sLabelNameLabelValuePipeDelimited)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Capitalized Interest Processing"));
            if (WebAdminPageFactory.LoanInterestCapitalizedInterestProcessingPage.WaitUntilCapitalizedInterestProcessingPageLoad())
			{
                WebAdminPageFactory.LoanInterestCapitalizedInterestProcessingPage.EnterValuesForCapitalizedInterestProcessingPageField(sLabelNameLabelValuePipeDelimited);
                
                if (WebAdminPageFactory.LoanInterestCapitalizedInterestProcessingPage.VerifyMessageCapitalizedInterestProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Capitalized Interest Processing fields are updated in Rate Determination Page.", "CapitalizedInterestProcessingFieldsUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Capitalized Interest Processing fields are not updated in Rate Determination Page.", "CapitalizedInterestProcessingFieldsNotUpdated", "True", appHandle, true);
                }
			}
        }        

        }

     /*   public virtual void UpdateTransactionCodeBackOfficePageOption(string sProductClass, string sProductGroup, string sProductNumber, string strLabelNamePipeDelimitedLabelValuecolonDelimited)
        {
            GetProduct(sProductClass, sProductGroup, sProductNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Codes"),Data.Get("Back Office"));
            WebAdminPageFactory.TransactionCodesPage.EnterDataByLabelNameInTransactionCodePage(strLabelNamePipeDelimitedLabelValuecolonDelimited);
            WebAdminPageFactory.WebAdminDepositRateDeterminationPage.SelectSubmitButton();
            if (WebAdminPageFactory.WebAdminDepositRateDeterminationPage.VerifyMessageDepositRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Transaction Code page has been updated", "TransactionCodeUpdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Transaction Code page has not been updated", "TransactionCodesNotUpdated", "True", appHandle, true);
            }
        }*/
    }

