﻿using GTS_OSAF;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.ObjectFactory.Teller;
using System;
using System.Windows.Forms;
using Profile7Automation.Libraries.Util;
using System.Text.RegularExpressions;
using System.Globalization;

namespace Profile7Automation.BusinessFunctions.Applications
{
    public class Teller
    {
        WindowsApplication applicationHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        static string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        static string PWD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
        static bool TellerLogOut = StartupConfiguration.EnvironmentDetails.TellerLogOut;
        static string Branch = Data.Get("GLOBAL_BRANCH");
        public virtual void DepositFund(string AccountNo, string Amount)
        {

            TellerPageFactory.DepositFundWindows.DepositFund(AccountNo, Amount);
        }
        public virtual void enter_teller_deposit_details(string sEffectiveDate, string[] arrActionEntries)
        {
            TellerPageFactory.DepositFundWindows.enter_teller_deposit_details(sEffectiveDate, arrActionEntries);
        }
        public virtual void WithDrawFund(string accountNo, string amount, string type)
        {
            TellerPageFactory.WithdrawFundsWindow.WithDrawFund(accountNo, amount, type);
        }
        public virtual void enter_teller_withdraw_details(string sEffectiveDate, string[] arrActionEntries)
        {
            TellerPageFactory.WithdrawFundsWindow.enter_teller_withdraw_details(sEffectiveDate, arrActionEntries);
        }
        public virtual void Login(String userId, String Password, String branch)
        {
            if (TellerPageFactory.LoginWindow.VerifyPresenceOfProfileTellerWindow())
            { }
            else
            {
                if (TellerPageFactory.LoginWindow.Login(userId, Password, branch))
                {
                    Report.Pass("Teller is successfully logged in.", "TellerLoginPass", "true", applicationHandle);
                }
                else
                {
                    Report.Fail("Teller is not successfully logged in.", "TellerLoginFail", "True", applicationHandle);
                }
            }
        }
        public virtual void login_specified_application(string ApplicationName)
        {
            this.Login(UID, PWD, Branch);

        }

        internal void DisburseFund(string accountNumber1, string Amount1)
        {
            TellerPageFactory.LoanDisbursementWindow.DisburseFund(accountNumber1, Amount1);
        }
        internal void enter_loan_disbursement_details(string sEffectiveDate, string[] arrActionEntries)
        {
            TellerPageFactory.LoanDisbursementWindow.enter_loan_disbursement_details(sEffectiveDate, arrActionEntries);
        }
        internal void post_teller_details(string sOverride)
        {
            //TellerPageFactory.MasterWindow.post_teller_details(sOverride);
            if (sOverride.ToUpper().Equals("YES"))
            {
                TellerPageFactory.MasterWindow.post_teller_details_override_yes();
            }
            else
            {
                TellerPageFactory.MasterWindow.post_teller_details();
            }

        }
        internal void enetr_loan_payment_details(string[] arrActionEntries, string sEffectiveDate = null)
        {
            TellerPageFactory.LoanPaymentWindow.enter_loan_payment_details(arrActionEntries, sEffectiveDate);
        }
        internal string get_loan_payment_amount_value(string[] arrActionEntries)
        {
            return TellerPageFactory.LoanPaymentWindow.get_loan_payment_amount_value(arrActionEntries);
        }
        internal void errorcorrect_teller_transaction(string SelectionInfo, string OverrideFlag)
        {
            TellerPageFactory.MasterWindow.errorcorrect_teller_transaction(SelectionInfo, OverrideFlag);
        }
        internal void errorcorrect_teller_transaction_false(string SelectionInfo, string OverrideFlag)
        {
            //TellerPageFactory.MasterWindow.errorcorrect_teller_transaction_false(SelectionInfo, OverrideFlag);
        }

        public virtual void AdvanceTransaction(string[] transactionDetails, string effectiveDate, bool isPost = true)
        {
            TellerPageFactory.AdvanceTransactionWindow.AdvanceTransaction(transactionDetails, effectiveDate, isPost);
        }

        public virtual void AdvanceTransactionbyCodeSearch(string[] transactionDetails, string effectiveDate, bool isPost = true)
        {
            TellerPageFactory.AdvanceTransactionWindow.AdvanceTransactionbyCodeSearch(transactionDetails, effectiveDate, isPost);
        }

        /// <summary>
        /// This method is used to compare two string values.
        /// <param name= "string1"></param> 
        /// <param name= "string2"></param>
        /// <returns></returns> 
        /// <example>comparestringvalues("Annual Yield","Annual Yield");<example>
        public virtual void comparestringvalues(string string1, string string2)
        {
            try
            {

                if (TellerPageFactory.MasterWindow.comparestringvalues(string1, string2))
                    Report.Pass("Strings compared successfully, both strings have same values", "value", "True", applicationHandle);
                else
                    Report.Fail("Strings compared failed, both strings do not have same values", "value", "True", applicationHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }
        /// <summary>
        /// This method is used to Select the transaction option such as Deposit Funds, Withdraw Funds .
        /// </summary>
        /// <param name="TransactionOption"></param>
        public virtual void SelectTransactionOption(string TransactionOption)
        {
            TransactionOption = TransactionOption.Replace(" ", string.Empty).ToUpper();
            string MainWindow = "jp2launcher;Profile Teller";
            bool AppLaunched = false;
            do
            {
                AppLaunched = applicationHandle.Launch_Application(MainWindow, 200, false, true);
            }
            while (AppLaunched == false);
            switch (TransactionOption)
            {
                case "DEPOSITFUNDS":
                    TellerPageFactory.MasterWindow.SelectTransaction(1);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Deposit Funds");
                    break;

                case "WITHDRAWFUNDS":
                    TellerPageFactory.MasterWindow.SelectTransaction(2);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Withdraw Funds");
                    break;
                case "TRANSFERFUNDS":
                    TellerPageFactory.MasterWindow.SelectTransaction(3);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Transfer Funds");
                    break;
                case "LOANPAYMENT":
                    TellerPageFactory.MasterWindow.SelectTransaction(4);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Loan Payment");
                    break;
                case "LOANDISBURSEMENT":
                    TellerPageFactory.MasterWindow.SelectTransaction(5);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Loan Disbursement");
                    break;
                case "LOANPAYOFF":
                    TellerPageFactory.MasterWindow.SelectTransaction(6);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Loan Payoff");
                    break;
                case "CREDITCARDPAYOFF":
                    TellerPageFactory.MasterWindow.SelectTransaction(7);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Credit Card Payoff");
                    break;
                case "OFFICIALCHECK":
                    TellerPageFactory.MasterWindow.SelectTransaction(8);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Official Check");
                    break;
                case "ADVANCEDTRANSACTIONS":
                    TellerPageFactory.MasterWindow.SelectTransaction(9);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Advanced Transactions");
                    break;
                case "REVERSETRANSACTIONS":
                    TellerPageFactory.MasterWindow.SelectTransaction(10);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Reverse Transactions");
                    break;
                case "TRANSFERCASH":
                    TellerPageFactory.MasterWindow.SelectTransaction(11);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Tranfer Cash");
                    break;
                case "CASHCHECKS":
                    TellerPageFactory.MasterWindow.SelectTransaction(12);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Cash Checks");
                    break;
                case "DISBURSEMENTCHECK":
                    TellerPageFactory.MasterWindow.SelectTransaction(13);
                    Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=TabItem;Text=Disbursement Check");
                    break;
            }
        }
        public virtual void LoanDisbursement(string AccountNumber, string Amount, string Effectivedate = "", bool IsOverride = false, string Currency = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Loan Disbursement"));

            if (TellerPageFactory.LoanDisbursementWindow.EnterLoanDisbursementDetails(AccountNumber, Amount, IsOverride, Currency))
            {
                Report.Info("Account number : " + AccountNumber + " is entered. Amount : " + Amount + " is entered. Transaction list is displayedto show Cash Out GL account and Disburse Loan Account.", "accamountLoanDisb", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Account number and amount is not entered successfully.", "failureentry", "True", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.LoanDisbursementWindow.VerifyLoanDisbursementTabClosedAfterTransaction())
            {
                Report.Pass("Loan Disbursement is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Loan Disbursement is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }
        }
        public virtual void DepositFunds(string AccountNumber, string Amount, string Effectivedate = "", string Currency = "", bool IsOverride = false, string contributioncode = "", bool withHoldingpercentage = false, string amount1 = "", string amount2 = "", string taxrate = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Deposit Funds"));
            if (TellerPageFactory.DepositFundWindows.EnterDepositFundDetails(AccountNumber, Amount, Currency, IsOverride))
            {
                Report.Info("Account number : " + AccountNumber + " is entered. Amount : " + Amount + " is entered. Transaction list is displayedto show Debit GL account and Credit Deposit Account.", "accamountdepfund", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Account number and amount is not entered successfully.", "failureentry", "True", applicationHandle);
            }
            string ACCTProdType = AccountNumber.Substring(0, 3);

            if (!string.IsNullOrEmpty(contributioncode))
            {
                TellerPageFactory.DepositFundWindows.ClickOnRedFlag();
                if (contributioncode == "120 - Postponed Contribution")
                {
                    TellerPageFactory.TransactionDetailWindow.Enter120ContributionTransactionDetails(contributioncode, amount1, amount2);
                }
                else
                {
                    TellerPageFactory.TransactionDetailWindow.EnterTransactionDetails(contributioncode);
                }

            }
            if (withHoldingpercentage)
            {
                TellerPageFactory.DepositFundWindows.EnterWithHoldingDetails(taxrate);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.DepositFundWindows.VerifyDepositFundTabClosedAfterTransaction())
            {
                Report.Pass("Deposit funds is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Deposit funds is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }

        }

        public virtual void logoff_specified_application(string SpecifiedApplicattion)
        {
            if (TellerLogOut)
            {
                TellerPageFactory.MasterWindow.Quit_Teller();
            }

        }
        public virtual void LoanPayment(string AccountNumber, string Amount = "", string Effectivedate = "", bool IsOverride = false)
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Loan Payment"));

            if (TellerPageFactory.LoanPaymentWindow.EnterLoanPaymentDetails(AccountNumber, Amount, IsOverride))
            {
                Report.Info("Account number : " + AccountNumber + " is entered. Amount : " + Amount + " is entered. Transaction list is displayedto show Cash In GL account and MP-Payment Loan Account.", "accamountLoanPay", "true", applicationHandle);
            }
            else
            {
                Report.Info("Account number : " + AccountNumber + " is not entered. Amount : " + Amount + " is not entered. Transaction list is displayedto show Cash In GL account and MP-Payment Loan Account.", "accamountLoanPayfail", "true", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.LoanPaymentWindow.VerifyLoanPaymentTabClosedAfterTransaction())
            {
                Report.Pass("Loan Payment is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Loan Payment is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }
        }
        public virtual void WithdrawFunds(string AccountNumber, string Amount, string Effectivedate = "", string Currency = "", bool IsOverride = false, string distributioncode = "", string customernumber = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Withdraw Funds"));
            if (TellerPageFactory.WithdrawFundsWindow.EnterWithdrawFundsDetails(AccountNumber, Amount, Currency, IsOverride))
            {
                Report.Info("Account number : " + AccountNumber + " is entered. Amount : " + Amount + " is entered. Transaction list is displayedto show Credit GL account and Debit Deposit Account.", "accamountdepfund", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Account number and amount is not entered successfully.", "failureentry", "True", applicationHandle);
            }
            string ACCTProdType = AccountNumber.Substring(0, 3);
            if (!string.IsNullOrEmpty(distributioncode))
            {
                TellerPageFactory.WithdrawFundsWindow.ClickOnRedFlag();
                TellerPageFactory.TransactionDetailWindow.EnterDistributionTransactionDetails(distributioncode);
                switch (distributioncode)
                {
                    case "104 - 104 Premature W/D":

                        if (!string.IsNullOrEmpty(customernumber))
                        {
                            string federalperc = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT WTHPCT FROM IRATYPE WHERE ACN = '" + customernumber + "'", "WTHPCT");
                            string stateperc = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT STWHPCT FROM IRATYPE WHERE ACN = '" + customernumber + "'", "STWHPCT");

                            double RSPFederalWithholdingAmount = Convert.ToDouble(Amount) * Convert.ToDouble(federalperc) / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                            double RSPStateWithholdingAmount = Convert.ToDouble(Amount) * Convert.ToDouble(stateperc) / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                            double NewAmount = Convert.ToDouble(Amount) - RSPFederalWithholdingAmount - RSPStateWithholdingAmount;
                            TellerPageFactory.WithdrawFundsWindow.EnterWithdrawFundsNewAmount(Convert.ToString(NewAmount));
                        }
                        break;

                }
            }

            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.WithdrawFundsWindow.VerifyWithdrawFundsTabClosedAfterTransaction())
            {
                Report.Pass("Withdraw funds is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Withdraw funds is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }

        }

        public virtual void VerifyTextInDialogWindow(string WindowName, string refTextToVerify)
        {
            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            refTextToVerify = refTextToVerify + "|";
            arr = refTextToVerify.Split('|');
            for (int b = 0; b < arr.Length - 1; b++)
            {
                temp = temp + " , " + string.Join(" , ", arr[b].Split('|')) + " is verified successfully in  " + WindowName + " window.";

            }
            msg = temp.Substring(3, temp.Length - 3);
            failmsg = msg.Replace(" is ", " is not ");

            bool Result = false;
            int counter = 0;
            arr = refTextToVerify.Split('|');
            applicationHandle.Launch_Application("jp2launcher;" + WindowName);
            for (int r = 0; r < arr.Length - 1; r++)
            {
                if (Profile7CommonLibrary.VerifyWindowObjectExists("ClassName=Static;Text=" + arr[r].Trim(), 1))
                {
                    counter++;
                }
                if (counter == arr.Length - 1)
                {
                    Result = true;
                    break;
                }
            }
            if (Result)
            {
                Report.Pass(msg, "windowtextvalidation", "True", applicationHandle);
            }
            else
            {
                Report.Fail(failmsg, "windowtextvalidationFail", "True", applicationHandle);
            }
        }
        public virtual void ClickOnButtonByButtonName(string buttonNameToCloseDialog)
        {
            if (Profile7CommonLibrary.VerifyWindowObjectExists("ControlType=Button;Text=" + buttonNameToCloseDialog))
            {
                applicationHandle.ClickObeject("ControlType=Button;Text=" + buttonNameToCloseDialog);
            }
            else
            {
                Report.Fail("Please check button name. " + buttonNameToCloseDialog + " is not present in the dialog.", "buttonnotfound", "True", applicationHandle);
            }
        }
        public virtual void LoanPayoff(string AccountNumber, string Amount, string Effectivedate = "", bool IsOverride = false, string Currency = "", string CloseOutReason = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Loan Payoff"));

            if (TellerPageFactory.LoanPayoffWindow.EnterLoanPayoffDetails(AccountNumber, Amount, IsOverride, Currency, CloseOutReason))
            {
                Report.Info("Account number : " + AccountNumber + " is entered. Amount : " + Amount + " is entered. Transaction list is displayedto show Cash In GL account and LPO-Payoff Close Loan Account.", "accamountLoanPay", "true", applicationHandle);
            }
            else
            {
                Report.Info("Account number : " + AccountNumber + " is not entered. Amount : " + Amount + " is not entered. Transaction list is displayedto show Cash In GL account and LPO-Payoff Close Loan Account.", "accamountLoanPayfail", "true", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.LoanPayoffWindow.VerifyLoanPayoffTabClosedAfterTransaction())
            {
                Report.Pass("Loan Payoff is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Loan Payoff is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }
        }
        /// <summary>
        /// This method is used to perform Analyze Transactions in Teller.
        /// TabNameToBeSelected : This is the tab name under which we need to validate the data.
        /// UniqueCellValuesOfSameRowPipeDelimited : Reference values to be passed.
        /// Example: 
        /// Application.Teller.AnalyzeTellerTransaction("Attribute Changes","DEP.TLD");
        /// Application.Teller.AnalyzeTellerTransaction("Attribute Changes","DEP.TLD|Transaction - Last Date|06/29/2020");
        /// Application.Teller.AnalyzeTellerTransaction("Attribute Changes","DEP.TLD|Transaction - Last Date|06/29/2020;400000065455|5000.00");
        /// Application.Teller.AnalyzeTellerTransaction("Attribute Changes","DEP.TLD|Transaction - Last Date|06/29/2020;400000065455|5000.00;Dollar Days Balance For curren");
        /// As shown in example all types of inputs can be passed.
        /// </summary>
        /// <param name="TabNameToBeSelected"></param>
        /// <param name="UniqueCellValuesOfSameRowPipeDelimited"></param>
        public virtual void AnalyzeTellerTransaction(string TabNameToBeSelected, string UniqueCellValuesOfSameRowPipeDelimited)
        {
            int numberOfColumns = 0;

            switch (TabNameToBeSelected)
            {
                case "Attribute Changes":
                    numberOfColumns = Int32.Parse((string)Data.Get("GLOBAL_VALUE_5"));
                    break;
                case "Amount Breakdowns":
                    numberOfColumns = Int32.Parse((string)Data.Get("GLOBAL_VALUE_4"));
                    break;
                case "Payments Satisfied":
                    numberOfColumns = Int32.Parse((string)Data.Get("6"));
                    break;
                case "Application Order":
                    numberOfColumns = Int32.Parse((string)Data.Get("GLOBAL_VALUE_5"));
                    break;
                case "Hold Summary":
                    numberOfColumns = Int32.Parse((string)Data.Get("GLOBAL_VALUE_14"));
                    break;
                case "Transaction List":
                    numberOfColumns = Int32.Parse((string)Data.Get("GLOBAL_VALUE_10"));
                    break;
                case "Accounting":
                    numberOfColumns = Int32.Parse((string)Data.Get("9"));
                    break;
            }
            bool saveresource = false; ;


            bool LoginWindowLoaded1 = Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
            TellerPageFactory.MasterWindow.ClickOnAnalyseTransactionsButton();

            if (applicationHandle.Launch_Application("jp2launcher;Transaction Analysis", 5, false, true))
            {
                saveresource = false;
            }
            else if (applicationHandle.Launch_Application("jp2launcher;Save Resource", 5, false, true))
            {
                saveresource = true;
            }

            if (saveresource)
            {
                Report.Info("Save Resource dialog is displayed. Yes button will be clicked to navigate to Transaction Analysis Window.", "saveresource", "True", applicationHandle);
                TellerPageFactory.TransactionAnalysisWindow.ClickOnYesButtonOnSaveResourceDialog();
            }
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Transaction Analysis");
            TellerPageFactory.TransactionAnalysisWindow.ClickOnSpecifiedTab(TabNameToBeSelected);
            Report.Info(TabNameToBeSelected + " is selected in Transaction Analysis window.", "tabselect", "True", applicationHandle);
            this.VerifyDataInTransactionAnalysis(TabNameToBeSelected, UniqueCellValuesOfSameRowPipeDelimited, numberOfColumns);
            applicationHandle.ClickObeject("Text=OK");
            Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");
        }

        public virtual void LoanPayOffAdvancedTransactions(string AccountNumber, string AccountProdSpecificTransactionCode, string Amount = "", string Effectivedate = "", bool IsOverride = false, string Currency = "", string CloseOutReason = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            Amount = Profile7CommonLibrary.ExtractDataFromDataBase("select POAM from LN where CID='" + AccountNumber + "'", "POAM");
            string GLTranCode = "";

            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Advanced Transactions"));
            if (AccountNumber.Substring(0, 3).Equals(Data.Get("GLOBAL_STD_PROD_NUM_900")))
            {
                GLTranCode = Data.Get("CO");
            }
            else
            {
                GLTranCode = Data.Get("CI");
            }
            if (TellerPageFactory.AdvanceTransactionWindow.EnterLoanPayOffAdvanceTransactionsDetails(AccountNumber, GLTranCode, AccountProdSpecificTransactionCode, Amount, Currency, CloseOutReason))
            {
                Report.Pass("Loan pay off transaction details are entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            else
            {
                Report.Fail("Loan pay off transaction details are not entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.AdvanceTransactionWindow.VerifyAdvancedTransactionTabClosedAfterTransaction())
            {
                Report.Pass("Loan Payoff  in Advanced Transactions is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Loan Payoff in Advanced Transactions  is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }
        }
        public virtual void LoanDisbursementAdvancedTransactions(string AccountNumber, string AccountProdSpecificTransactionCode, string Amount, string Effectivedate = "", bool IsOverride = false, string Currency = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            string GLTranCode = "";

            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Advanced Transactions"));
            if (AccountNumber.Substring(0, 3).Equals(Data.Get("GLOBAL_STD_PROD_NUM_900")))
            {
                GLTranCode = Data.Get("CI");
            }
            else
            {
                GLTranCode = Data.Get("CO");
            }
            if (TellerPageFactory.AdvanceTransactionWindow.EnterLoanDisbursementAdvanceTransactionsDetails(AccountNumber, GLTranCode, AccountProdSpecificTransactionCode, Amount, Currency))
            {
                Report.Pass("Loan Disbursement transaction details are entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            else
            {
                Report.Fail("Loan Disbursement transaction details are not entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.AdvanceTransactionWindow.VerifyAdvancedTransactionTabClosedAfterTransaction())
            {
                Report.Pass("Loan Disbursement  in Advanced Transactions is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Loan Disbursement in Advanced Transactions  is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }
        }
        /// <summary>
        /// This method is used to perform Error correction in teller.
        /// Single  critera : TransactionDetailsPipeDelimited : Send parameter without delimiter.
        /// Multiple critera : TransactionDetailsPipeDelimited : Send parameter with pipe  delimiter.
        /// </summary>
        /// <param name="TransactionDetailsPipeDelimited"></param>

        public virtual void ErrorCorrectionTellerTransaction(string TransactionDetailsPipeDelimited)
        {
            string tempmsg = Data.Get("Continue to perform error corrections on the selected transactions?");
            TransactionDetailsPipeDelimited = TransactionDetailsPipeDelimited + ";";
            string[] arr = TransactionDetailsPipeDelimited.Split(";");
            TellerPageFactory.ErrorCorrectWindow.ClickOnErrorCorrectionButton();
            int counter = 0;
            int flag = 0;
            int temp = arr.Length - 1;
            for (int i = 0; i < temp; i++)
            {

                if (TellerPageFactory.ErrorCorrectWindow.CheckIfPostButtonEnabled() == false)
                {
                    Report.Info("Error Correct window is loaded successfully.", "Errorcorrectscreen", "True", applicationHandle);
                    string SelectedTransactions = TellerPageFactory.ErrorCorrectWindow.EnterErrorCorrectDetails(arr[i]);
                    if (string.IsNullOrEmpty(SelectedTransactions))
                    {
                        Report.Fail("The Transaction details are not selected.", "selectedentryfail", "True", applicationHandle);
                        if (temp == 1)
                        {
                            TellerPageFactory.ErrorCorrectWindow.ClickOnCancelButton();
                        }
                        else
                        {
                            flag = 1;
                            counter++;
                        }
                    }
                    else
                    {
                        Report.Info(SelectedTransactions + " are selected in Error correct window.", "dataentry", "True", applicationHandle);
                        if (TellerPageFactory.ErrorCorrectWindow.ClickOnPostButton())
                        {
                            Report.Info(tempmsg + " : is displayed as confirmation message to continue Error correction .", "confirmationmsg", "True", applicationHandle);
                        }
                        TellerPageFactory.ErrorCorrectWindow.ClickOnYesButton();
                        if (TellerPageFactory.ErrorCorrectWindow.CheckIfPostButtonEnabled() == false)
                        {
                            Report.Pass("Error correction for the selected transaction is completed successfully.", "ErrorCorrectionSuccess", "True", applicationHandle);
                        }
                        counter++;
                    }
                }
            }
            if (flag == 1)
            {
                TellerPageFactory.ErrorCorrectWindow.ClickOnCancelButton();
            }
            else
            {
                if (counter == temp)
                {
                    TellerPageFactory.ErrorCorrectWindow.ClickOnCancelButton();
                }
            }

        }
        public virtual void ReverseTransactions(string AccountNumber, string TransactionCode, string TransactionToBeSelectedPipeDelimited, string Amount, string FromDate = "", string ToDate = "", string Effectivedate = "", string Currency = "", bool IsOverride = false)
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Reverse Transactions"));
            if (TellerPageFactory.ReverseTransactions.EnterReverseTransactionsDetails(AccountNumber, TransactionCode, TransactionToBeSelectedPipeDelimited, Amount, FromDate, ToDate, Currency))
            {
                Report.Info("Reverse Transaction details have been entered successfully.", "reversetran", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Reverse Transaction details have not been entered successfully.", "failureentry", "True", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.ReverseTransactions.VerifyReverseTransactionsTabClosedAfterTransaction())
            {
                Report.Pass("Deposit funds is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Deposit funds is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }
        }
        public virtual void PostByAdvanceTransactions(string AccountNumber, string glnumber, string AccountProdSpecificTransactionCode, string GLcode, string Amount, string Effectivedate = "", bool IsOverride = false, string Currency = "")
        {
            bool LoginWindowLoaded = Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");


            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Advanced Transactions"));

            if (TellerPageFactory.AdvanceTransactionWindow.AdvanceTransactions(AccountNumber, glnumber, AccountProdSpecificTransactionCode, GLcode, Amount, Currency))
            {
                Report.Pass("Transaction details are entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            else
            {
                Report.Fail("Transaction details are not entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.AdvanceTransactionWindow.VerifyAdvancedTransactionTabClosedAfterTransaction())
            {
                Report.Pass("Transaction is completed using Advanced transactions.", "advtranpost", "True", applicationHandle);
            }
            else
            {
                Report.Fail("Transaction is not completed using Advanced transactions.", "advtranpost", "True", applicationHandle);
            }

        }
        public virtual void EnterTransactionDetailsInAdvanceTransactions(string AccountNumber, string glnumber, string AccountProdSpecificTransactionCode, string GLcode, string Amount, string Effectivedate = "", string Currency = "", bool IsOverride = false)
        {
            bool LoginWindowLoaded = Profile7CommonLibrary.WaitUntilWindowLoads("jp2launcher;Profile Teller");


            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Advanced Transactions"));

            if (TellerPageFactory.AdvanceTransactionWindow.AdvanceTransactions(AccountNumber, glnumber, AccountProdSpecificTransactionCode, GLcode, Amount, Currency))
            {
                Report.Pass("Transaction details are entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            else
            {
                Report.Fail("Transaction details are not entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
        }
        public virtual void VerifyDataInTransactionAnalysis(string TabNameToBeSelected, string UniqueCellValuesOfSameRowPipeDelimited, int numberOfColumns)
        {
            string text = "";
            for (int i = 1; i <= numberOfColumns; i++)
            {
                text = text + "|";
            }
            string firstcell = "";
            bool flag = false;
            int count = 0;
            int n = 1;
            int m = 1;
            int matchcount = 0;
            bool firstcheck = false;
            UniqueCellValuesOfSameRowPipeDelimited = UniqueCellValuesOfSameRowPipeDelimited + ";";
            string[] arr = UniqueCellValuesOfSameRowPipeDelimited.Split(';');
            string temp = "";
            if (UniqueCellValuesOfSameRowPipeDelimited.Split(';')[0].Trim().Contains("|"))
            {
                try
                {
                    if (((string)applicationHandle.GetObjectProperty("Text=" + UniqueCellValuesOfSameRowPipeDelimited.Split(';')[0].Split('|')[0].Trim(), ObjectProperty.Name)).Equals(UniqueCellValuesOfSameRowPipeDelimited.Split(';')[0].Split('|')[0].Trim()))
                    {
                        firstcheck = true;
                    }
                }
                catch (Exception e)
                {
                    firstcheck = false;
                }

            }
            else
            {
                try
                {
                    if (((string)applicationHandle.GetObjectProperty("Text=" + UniqueCellValuesOfSameRowPipeDelimited.Split(';')[0].Trim(), ObjectProperty.Name)).Equals(UniqueCellValuesOfSameRowPipeDelimited.Split(';')[0].Trim()))
                    {
                        firstcheck = true;
                    }
                }
                catch (Exception e)
                {
                    firstcheck = false;
                }
            }
            if (firstcheck)
            {
                for (int a = 0; a < arr.Length - 1; a++)
                {

                    if (arr[a].Contains("|"))
                    {
                        n = 1;
                        firstcell = (string)applicationHandle.GetObjectProperty("Text=Header" + ";LabelRelationShip=" + LabelRelationShip.NextSibling, ObjectProperty.Name);
                        temp = (string)applicationHandle.GetObjectProperty("Text=" + firstcell + "" + ";LabelRelationShip=" + LabelRelationShip.NextChild, ObjectProperty.Name);
                        do
                        {
                            if (n == 1)
                            {
                                for (int b = 1; b <= numberOfColumns; b++)
                                {

                                    temp = temp + "|" + (string)applicationHandle.GetObjectProperty("Text=" + firstcell + "" + ";LabelRelationShip=" + LabelRelationShip.NthChild + ";" + b + "", ObjectProperty.Name);

                                }
                            }
                            else
                            {


                                temp = "";
                                for (int b = 1; b <= numberOfColumns; b++)
                                {

                                    temp = temp + "|" + (string)applicationHandle.GetObjectProperty("Text=" + firstcell + "" + ";LabelRelationShip=" + LabelRelationShip.NthNextSiblingKthChild + ";" + m + ";" + b + "", ObjectProperty.Name);

                                }
                                m++;
                            }
                            if (temp.Equals(text))
                            {
                                Report.Fail(string.Join(" , ", arr[a].Split('|')) + " are not found in Transaction Analysis in " + TabNameToBeSelected + " tab .", "transanalysisfail", "True", applicationHandle);
                                break;
                            }
                            count = temp.Split('|').Length - 1;

                            foreach (string temp2 in arr[a].Split('|'))
                            {
                                if (!string.IsNullOrEmpty(Array.Find(temp.Split('|'), t => t.Equals(temp2))))
                                {
                                    matchcount++;
                                }

                            }
                            if (matchcount == arr[a].Split('|').Length)
                            {
                                flag = true;
                                matchcount = 0;
                                temp = "";
                                Report.Pass(string.Join(" , ", arr[a].Split('|')) + " are found in Transaction Analysis in " + TabNameToBeSelected + " tab .", "transanalysispass", "True", applicationHandle);
                                break;
                            }
                            else
                            {
                                matchcount = 0;
                                n = 0;
                            }

                        } while (temp.Equals(text) == false);

                    }
                    else
                    {
                        try
                        {
                            if (((string)applicationHandle.GetObjectProperty("Text=" + arr[a].Trim(), ObjectProperty.Name)).Equals(arr[a].Trim()))
                            {
                                Report.Pass(arr[a].Trim() + " is successfully found in Transaction Analysis table in " + TabNameToBeSelected + " tab .", "singlevalcheck", "True", applicationHandle);
                            }
                        }
                        catch (Exception e)

                        {
                            Report.Fail(arr[a].Trim() + " is not  found in Transaction Analysis table in " + TabNameToBeSelected + " tab .", "singlevalcheckfail", "True", applicationHandle);
                        }
                    }
                }
            }
            else
            {
                Report.Fail("The expected values are not available in transaction analysis table in " + TabNameToBeSelected + " tab . Please check the input parameters.", "trananalysisfail", "True", applicationHandle);
            }

        }
        public virtual void PostTransactions(bool IsOverride = false, string MessageToVerifyOnOverride = "", bool SubmitOverrideOrCancel = true)
        {
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride, MessageToVerifyOnOverride, SubmitOverrideOrCancel);
        }
        public virtual void DepositAccountCloseOutAdvanceTransactions(string AccountNumber, string AccountProdSpecificTransactionCode, string Amount = "", string Effectivedate = "", bool IsOverride = false, string Currency = "", string CloseOutReason = "", string MessageToVerifyOnOverride = "", bool SubmitOverrideOrCancel = true)
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");

            string GLTranCode = "";

            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Advanced Transactions"));
            GLTranCode = Data.Get("CO");
            if (TellerPageFactory.AdvanceTransactionWindow.EnterDepositAccountCloseOutAdvanceTransactionsDetails(AccountNumber, GLTranCode, AccountProdSpecificTransactionCode, Amount, Currency, CloseOutReason))
            {
                Report.Pass("Deposit closeout transaction details are entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            else
            {
                Report.Fail("Deposit closeout transaction details are not entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride, MessageToVerifyOnOverride, SubmitOverrideOrCancel);
            if (SubmitOverrideOrCancel)
            {
                if (TellerPageFactory.AdvanceTransactionWindow.VerifyAdvancedTransactionTabClosedAfterTransaction())
                {
                    Report.Pass("Deposit closeout  in Advanced Transactions is successfully completed.", "Transactionpass", "true", applicationHandle);
                }
                else
                {
                    Report.Fail("Deposit closeout in Advanced Transactions  is not completed successfully.", "TransactionFail", "True", applicationHandle);
                }
            }
            else
            {
                CloseAdvancedTransactionTab();
            }
        }
        public virtual void PostIRADistributionAdvancedTransactions(string AccountNumber, string AccountProdSpecificTransactionCode, string WithDrawAmount, string ContrCode1, string ContrCode2, string ContributionAmount1, string ContributionAmount2, string Effectivedate = "", bool IsOverride = false, string Currency = "")
        {

            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            string GLTranCode = "";
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Advanced Transactions"));
            GLTranCode = Data.Get("CO");
            if (TellerPageFactory.AdvanceTransactionWindow.EnterDetailsIRADistributionAdvancedTransactions(AccountNumber, GLTranCode, AccountProdSpecificTransactionCode, WithDrawAmount, ContrCode1, ContrCode2, ContributionAmount1, ContributionAmount2, Currency))
            {
                Report.Pass("IRA Account distribution transaction details are entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            else
            {
                Report.Fail("IRA Account distribution transaction details are not entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.AdvanceTransactionWindow.VerifyAdvancedTransactionTabClosedAfterTransaction())
            {
                Report.Pass("IRA Account distribution  in Advanced Transactions is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("IRA Account distribution in Advanced Transactions  is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }
        }
        public virtual void PostContributionTransactionIRAAccount(string AccountNumber, string DepositAmount, string ReasonCode1, string ReasonCode2, string ContributionAmount1, string ContributionAmount2, string Effectivedate = "", bool IsOverride = false, string Currency = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Deposit Funds"));
            if (TellerPageFactory.DepositFundWindows.EnterDepositFundDetails(AccountNumber, DepositAmount, Currency, IsOverride))
            {
                Report.Info("Account number : " + AccountNumber + " is entered. Amount : " + DepositAmount + " is entered. Transaction list is displayedto show Debit GL account and Credit Deposit Account.", "accamountdepfund", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Account number and amount is not entered successfully.", "failureentry", "True", applicationHandle);
            }
            string ACCTProdType = AccountNumber.Substring(0, 3);
            TellerPageFactory.DepositFundWindows.ClickOnRedFlag();
            TellerPageFactory.DepositFundWindows.EnterIRAContributionTransactionDetails(AccountNumber, ReasonCode1, ReasonCode2, ContributionAmount1, ContributionAmount2);
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.DepositFundWindows.VerifyDepositFundTabClosedAfterTransaction())
            {
                Report.Pass("Contribution transaction for IRA acount is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Contribution transaction for IRA acount is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }

        }
        public virtual void CloseAdvancedTransactionTab()
        {
            bool saveresource = false;
            applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            applicationHandle.SelectContextMenuItem("ControlType=TabItem;Text=Advanced Transactions", true, "Close");
            if (applicationHandle.Launch_Application("jp2launcher;Transaction Analysis", 5, false, true))
            {
                saveresource = false;
            }
            else if (applicationHandle.Launch_Application("jp2launcher;Save Resource", 5, false, true))
            {
                saveresource = true;
            }
            if (saveresource)
            {
                Report.Info("Save Resource dialog is displayed. Yes button will be clicked to close Advanced Transaction tab", "saveresource", "True", applicationHandle);
                TellerPageFactory.TransactionAnalysisWindow.ClickOnYesButtonOnSaveResourceDialog();
            }
            if (TellerPageFactory.AdvanceTransactionWindow.VerifyAdvancedTransactionTabClosedAfterTransaction())
            {
                Report.Pass("Advanced Transaction tab is closed.", "advtrantabclose", "True", applicationHandle);
            }
            else
            {
                Report.Info("Advanced Transaction tab is not closed.", "advtrantabclose", "True", applicationHandle);
            }
        }
        public virtual void EnterLoanPayOffUsingAdvancedTransactions(string AccountNumber, string AccountProdSpecificTransactionCode, string Amount = "", string Effectivedate = "", string Currency = "", string CloseOutReason = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            // Amount = Profile7CommonLibrary.ExtractDataFromDataBase("select POAM from LN where CID='" + AccountNumber + "'", "POAM");
            string GLTranCode = "";

            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Advanced Transactions"));
            if (AccountNumber.Substring(0, 3).Equals(Data.Get("GLOBAL_STD_PROD_NUM_900")))
            {
                GLTranCode = Data.Get("CO");
            }
            else
            {
                GLTranCode = Data.Get("CI");
            }
            if (TellerPageFactory.AdvanceTransactionWindow.EnterLoanPayOffAdvanceTransactionsDetails(AccountNumber, GLTranCode, AccountProdSpecificTransactionCode, Amount, Currency, CloseOutReason))
            {
                Report.Pass("Loan pay off transaction details are entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
            else
            {
                Report.Fail("Loan pay off transaction details are not entered in Advanced Transaction Window.", "adventry", "True", applicationHandle);
            }
        }
        public virtual void CheckDepositFunds(string AccountNumber, string Amount, string Effectivedate = "", string Currency = "", bool IsOverride = false, string RTNumber = "", string CheckType = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Deposit Funds"));
            if (TellerPageFactory.DepositFundWindows.EnterCheckDepositFundDetails(AccountNumber, Amount, Currency, RTNumber, CheckType))
            {
                Report.Info("Account number : " + AccountNumber + " is entered. Amount : " + Amount + " is entered. Transaction list is displayedto show Debit GL account and Credit Deposit Account.", "accamountdepfund", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Account number and amount is not entered successfully.", "failureentry", "True", applicationHandle);
            }

            TellerPageFactory.DepositFundWindows.ClickRedFlagForCheckTransaction();
            TellerPageFactory.TransactionDetailWindow.EnterCheckTransactionDetails(RTNumber, CheckType);

            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.DepositFundWindows.VerifyDepositFundTabClosedAfterTransaction())
            {
                Report.Pass("Check Deposit funds is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Check Deposit funds is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }

        }
        /// <summary>
        /// This method is used for deposit fund for IRA account with  single or multiple Contributions
        /// 
        /// Example: 
        /// Single Contribution:
        /// Application.Teller.PostSingleMultipleContributionTransactionIRAAccount("370000000705","2000","101 - Reportable - Current Tax Year","2000");
        /// Multiple Contribution:
        /// Application.Teller.PostSingleMultipleContributionTransactionIRAAccount("370000000705","2000","101 - Reportable - Current Tax Year|102 - Reportable - Prior Tax Year|110 - Non-Deductible - Prior Year|120 - Postponed Contribution","800|800|200|200");
        /// </summary>
        /// <param name="AccountNumber"></param>
        /// <param name="DepositAmount"></param>
        /// <param name="ContributionCodePipeDelimited"></param>
        /// <param name="ContributionAmountPipeDelimited"></param>
        /// <param name="Effectivedate"></param>
        /// <param name="IsOverride"></param>
        /// <param name="Currency"></param>
        public virtual void PostSingleMultipleContributionTransactionIRAAccount(string AccountNumber, string DepositAmount, string ContributionCodePipeDelimited, string ContributionAmountPipeDelimited, string Effectivedate = "", bool IsOverride = false, string Currency = "")

        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Deposit Funds"));
            if (TellerPageFactory.DepositFundWindows.EnterDepositFundDetails(AccountNumber, DepositAmount, Currency, IsOverride))
            {
                Report.Info("Account number : " + AccountNumber + " is entered. Amount : " + DepositAmount + " is entered. Transaction list is displayedto show Debit GL account and Credit Deposit Account.", "accamountdepfund", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Account number and amount is not entered successfully.", "failureentry", "True", applicationHandle);
            }
            TellerPageFactory.DepositFundWindows.ClickOnRedFlag();
            TellerPageFactory.DepositFundWindows.EnterIRAContributionMultiTransactionDetails(AccountNumber, ContributionCodePipeDelimited, ContributionAmountPipeDelimited);
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.DepositFundWindows.VerifyDepositFundTabClosedAfterTransaction())
            {
                Report.Pass("Contribution transaction for IRA acount is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Contribution transaction for IRA acount is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }

        }

        public virtual void PostSingleMultipleDistributionTransactionIRAAccount(string AccountNumber, string Amount, string DistributionCodePipeDelimited, string DistributionAmountPipeDelimited, string Effectivedate = "", bool IsOverride = false, string Currency = "", string RSPFederalAmtPipeDelimited = "", string RSPStateAmtPipeDelimited = "")
        {
            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            string[] Amt = DistributionAmountPipeDelimited.Split('|');
            string[] FederalAmtArray = RSPFederalAmtPipeDelimited.Split('|');
            string[] stateArray = RSPStateAmtPipeDelimited.Split('|');
            double FederalWHamount = 0;
            double NewAmount = 0;
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Withdraw Funds"));
            if (TellerPageFactory.WithdrawFundsWindow.EnterWithdrawFundsDetails(AccountNumber, Amount, Currency, IsOverride))
            {
                Report.Info("Account number : " + AccountNumber + " is entered. Amount : " + Amount + " is entered. Transaction list is displayedto show Credit GL account and Debit Deposit Account.", "accamountdepfund", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Account number and amount is not entered successfully.", "failureentry", "True", applicationHandle);
            }
            TellerPageFactory.WithdrawFundsWindow.ClickOnRedFlag();
            TellerPageFactory.WithdrawFundsWindow.EnterIRADistributionMultiTransactionDetails(AccountNumber, DistributionCodePipeDelimited, DistributionAmountPipeDelimited, RSPFederalAmtPipeDelimited, RSPStateAmtPipeDelimited);

            if (!string.IsNullOrEmpty(RSPFederalAmtPipeDelimited) || !string.IsNullOrEmpty(RSPStateAmtPipeDelimited))
            {
                for (int a = 0; a <= Amt.Length - 1; a++)
                {
                    NewAmount = NewAmount + Convert.ToDouble(Amt[a]) - Convert.ToDouble(FederalAmtArray[a]) - Convert.ToDouble(stateArray[a]);
                }
                TellerPageFactory.WithdrawFundsWindow.EnterWithdrawFundsNewAmount(Convert.ToString(NewAmount));
            }
            else
            {
                for (int a = 0; a <= Amt.Length - 1; a++)
                {
                    string RPASEQ = Profile7CommonLibrary.ExtractDataFromDataBase("select RPASEQ FROM DEP WHERE CID ='" + AccountNumber + "'", "RPASEQ");
                    string ACN = Profile7CommonLibrary.ExtractDataFromDataBase("Select ACN FROM DEP WHERE CID = '" + AccountNumber + "'", "ACN");
                    string RSPWSCH = Profile7CommonLibrary.ExtractDataFromDataBase("select RSPWSCH from IRATYPE where RPASEQ ='" + RPASEQ + "' and ACN ='" + ACN + "'", "RSPWSCH");
                    string WTHAMT = Profile7CommonLibrary.ExtractDataFromDataBase("select WTHAMT from IRATYPE where RPASEQ ='" + RPASEQ + "' and ACN ='" + ACN + "'", "WTHAMT");
                    string WTHPCT = Profile7CommonLibrary.ExtractDataFromDataBase("select WTHPCT from IRATYPE where RPASEQ ='" + RPASEQ + "' and ACN ='" + ACN + "'", "WTHPCT");

                    // string WTHAMT = Profile7CommonLibrary.ExtractDataFromDataBase("select DISTINCT IRATYPE.WTHAMT,IRATYPE.RPASEQ,DEP.RPASEQ FROM IRATYPE,DEP WHERE IRATYPE.WTHAMT IS NOT NULL and IRATYPE.RPASEQ = DEP.RPASEQ and DEP.ACN = '" + ACN + "' and IRATYPE.RPASEQ = '" +RPASEQ +"'", "IRATYPE.WTHAMT");
                    // string WTHPCT = Profile7CommonLibrary.ExtractDataFromDataBase("select DISTINCT IRATYPE.WTHPCT,IRATYPE.RPASEQ,DEP.RPASEQ FROM IRATYPE,DEP WHERE IRATYPE.WTHPCT IS NOT NULL and IRATYPE.RPASEQ = DEP.RPASEQ and DEP.ACN = '" + ACN + "' and IRATYPE.RPASEQ = '" +RPASEQ +"'", "IRATYPE.WTHPCT");
                    if (RSPWSCH == "null" && WTHAMT == "null" && WTHPCT == "null")
                    {
                        string RSPWCALC = Profile7CommonLibrary.ExtractDataFromDataBase("select RSPWCALC from IRATYPE where RPASEQ ='" + RPASEQ + "' and ACN ='" + ACN + "'", "RSPWCALC");
                        string WPCT = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT WPCT FROM UTBLWCALC  WHERE UTBLWCALC.KEY='" + RSPWCALC + "'", "WPCT");

                        FederalWHamount = Convert.ToDouble(Amt[a]) * Convert.ToDouble(WPCT);
                        FederalWHamount = FederalWHamount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                        FederalWHamount = Convert.ToDouble(Amt[a]) - FederalWHamount;

                    }
                    else if (RSPWSCH != "null" && WTHAMT == "null" && WTHPCT != "null")
                    {
                        FederalWHamount = Convert.ToDouble(WTHPCT) + Convert.ToDouble(RSPWSCH);
                        FederalWHamount = FederalWHamount * Convert.ToDouble(Amt[a]);
                        FederalWHamount = FederalWHamount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                        FederalWHamount = Convert.ToDouble(Amt[a]) - FederalWHamount;
                    }
                    else if (RSPWSCH == "null" && WTHAMT != "null" && WTHPCT != "null")
                    {
                        FederalWHamount = Convert.ToDouble(WTHPCT) * Convert.ToDouble(Amt[a]);
                        FederalWHamount = FederalWHamount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                        FederalWHamount = FederalWHamount + Convert.ToDouble(WTHAMT);
                        FederalWHamount = Convert.ToDouble(Amt[a]) - FederalWHamount;
                    }
                    else
                    {
                        FederalWHamount = Convert.ToDouble(WTHPCT) + Convert.ToDouble(RSPWSCH);
                        FederalWHamount = FederalWHamount * Convert.ToDouble(Amt[a]);
                        FederalWHamount = FederalWHamount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                        FederalWHamount = FederalWHamount + Convert.ToDouble(WTHAMT);
                        FederalWHamount = Convert.ToDouble(Amt[a]) - FederalWHamount;
                    }
                    NewAmount = NewAmount + FederalWHamount;

                }
                TellerPageFactory.WithdrawFundsWindow.EnterWithdrawFundsNewAmount(Convert.ToString(NewAmount));
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.WithdrawFundsWindow.VerifyWithdrawFundsTabClosedAfterTransaction())
            {
                Report.Pass("Distribution transaction for IRA acount is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("Distribution transaction for IRA acount is not completed successfully.", "TransactionFail", "True", applicationHandle);
            }
        }

        public virtual void PostIRAContributionAdvancedTransactions(string AccountNumber, string AccountProdSpecificTransactionCode, string Amount, string ContributionCodePipeDelimited, string AmountPipeDelimited, string Effectivedate = "", bool IsOverride = false, string Currency = "")
        {

            bool LoginWindowLoaded = applicationHandle.Launch_Application("jp2launcher;Profile Teller");
            string GLTranCode = "";
            if (!string.IsNullOrEmpty(Effectivedate))
            {
                TellerPageFactory.MasterWindow.set_effective_date(Effectivedate);
            }
            this.SelectTransactionOption(Data.Get("Advanced Transactions"));
            GLTranCode = Data.Get("CI");
            if (TellerPageFactory.AdvanceTransactionWindow.EnterDetailsIRAContributionAdvancedTransactions(AccountNumber, GLTranCode, AccountProdSpecificTransactionCode, Amount, ContributionCodePipeDelimited, AmountPipeDelimited, Currency))
            {
                Report.Info("IRA Account Contribution transaction details are entered in Advanced Transaction Window.", "EnteredDetailsInAdvancedTransaction", "true", applicationHandle);
            }
            else
            {
                Report.Info("IRA Account Contribution transaction details are entered in Advanced Transaction Window.", "EDetailsAreNotEnteresinAdvTransaction", "true", applicationHandle);
            }
            TellerPageFactory.MasterWindow.PostTransactions(IsOverride);
            if (TellerPageFactory.AdvanceTransactionWindow.VerifyAdvancedTransactionTabClosedAfterTransaction())
            {
                Report.Pass("IRA Account Contribution  in Advanced Transactions is successfully completed.", "Transactionpass", "true", applicationHandle);
            }
            else
            {
                Report.Fail("IRA Account Contribution in Advanced Transactions  is not completed successfully.", "TransactionFail", "true", applicationHandle);
            }
        }

    }
}
