using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;
using GTS_OSAF.Util;
using Profile7Automation.ObjectFactory.WebCSR;
using Profile7Automation.ObjectFactory.WebCSR.Pages;
using System;
using System.Threading;
using GTS_OSAF;
using System.Collections.Generic;

using OpenQA.Selenium;
using System.Linq;
using Profile7Automation.Libraries.Util;
using System.Globalization;
using Microsoft.VisualBasic;
using System.IO;

namespace Profile7Automation.BusinessFunctions.Applications
{
    [App]
    public class WebCSR
    {
        static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        static string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        static string PWD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;

        static string Branch = Data.Get("GLOBAL_BRANCH");
        public virtual void Login(String userID, String password, String Branch)
        {
            //Profile7CommonLibrary.KillProcessByProcessName("chrome");

            WebCSRPageFactory.WebCSRMasterPage.launch_webcsr_url();

            if (appHandle.GetTitle().Contains("Branch"))
            {

            }
            else
            {
                WebCSRPageFactory.LoginPage.enter_login_details(userID, password, Branch);
                WebCSRPageFactory.LoginPage.select_submit_button();

            }
            if (WebCSRPageFactory.LoginPage.VerifyCustomerSearchPageLoads())
            {
                Report.Pass("WebCSR application is Logged in successfully.", "Login Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("WebCSR application is not Logged in successfully.", "Login Screen Fail", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB), true);
            }
        }
        public virtual void login_specified_application(string ApplicationName)
        {
            this.Login(UID, PWD, Branch);
        }
        public virtual string CreatePersonalCustomer()
        {
            string taxid = TaxIdGenerator.Generate();
            string lastName = LastNameGenerator.Generate();
            string searchType = "TAXID";
            WebCSRPageFactory.WebCSRMasterPage.select_basic_secivces_menu_link();
            string UserFirstName = StartupConfiguration.EnvironmentDetails.UserFirstName;
            string EmailID=StartupConfiguration.EnvironmentDetails.UserMailID;
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_personal_information_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.set_date_of_birth_field_value("10/10/2000");
            //WebCSRPageFactory.CreatePersonalCustomerPage.select_country_of_citizenship_dropdown_value("INDIA");
            // WebCSRPageFactory.CreatePersonalCustomerPage.FillIdentification(Data.Get("GLOBAL_DLNUMBER"), Data.Get("GLOBAL_DLISSUEDATE"), Data.Get("GLOBAL_DLEXPIREDATE"), Data.Get("GLOBAL_DLSTATE"));
            // WebCSRPageFactory.CreatePersonalCustomerPage.FillEmailAndPhone(EmailID);
            // WebCSRPageFactory.CreatePersonalCustomerPage.FillAddress(Data.Get("GLOBAL_ADDLINE1"), Data.Get("GLOBAL_ADDLINE2"), Data.Get("GLOBAL_CITY"), Data.Get("GLOBAL_ADDCOUNTRY"), Data.Get("GLOBAL_ADDSTATE"), Data.Get("GLOBAL_ADDZIP"), Data.Get("GLOBAL_ADDYEARS"));
            // WebCSRPageFactory.CreatePersonalCustomerPage.FillAllowOnlineAccess();
            // WebCSRPageFactory.CreatePersonalCustomerPage.FillSecretQuestion(Data.Get("GLOBAL_SECRETQUESTION"), Data.Get("GLOBAL_SECRETANSWER"));
            // WebCSRPageFactory.WebCSRMasterPage.select_continue_button();

            WebCSRPageFactory.WebCSRMasterPage.PersonalCustSubmit();

            Thread.Sleep(5000);
            string customerNumber = WebCSRPageFactory.CustomerSearchPage.SearchCustomer(taxid, searchType);
            Report.Pass("Customer Created Successfully. Customer No:" + customerNumber, "Customer Creation Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            return customerNumber;
        }

        public virtual void searchByCustomerId(string searchType, string value)
        {
            WebCSRPageFactory.CustomerSearchPage.get_customer_number(searchType, value);
            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
            WebCSRPageFactory.AccountListPage.waitForAccountListPage();
        }

         public virtual void searchByAll(string value, string searchType)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(value, searchType);
            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
            WebCSRPageFactory.AccountListPage.waitForAccountListPage();
        } 

        public virtual void openMakerCheckerLiteMenuAndMyActivityQueueTab()
        {
            
            WebCSRPageFactory.MakerAndCheckerLitePage.OpenMakerCheckerLiteMenu();
            WebCSRPageFactory.MakerAndCheckerLitePage.OpenMyActivityQueue();
        } 
        
        public virtual void GetCustomer(string customerId)
        {
            string temptitle = appHandle.GetTitle();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), customerId);
            }
            else if (temptitle.Contains(Data.Get("Verify Customer"))) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), customerId);
            }

        }

        internal void CloseBrowser()
        {
            WebCSRPageFactory.WebCSRMasterPage.CloseBrowser();
        }


        public virtual string CreateAccount(string sAccountClass, string relationType, string productType, string customerId, string[] accDetails)
        {
            string prodType;
            string NoOfAcc;
            if (productType.Contains(";"))
            {
                string[] x = productType.Split(';');
                prodType = x[0];
                NoOfAcc = x[1];
            }
            else
            {
                prodType = productType;
                NoOfAcc = "1";
            }
            GetCustomer(customerId);
            //Select value from verification Action dropdown
            WebCSRPageFactory.VerifyCustomerPage.VerificationAction(Data.Get("GLOBAL_AccountCreate"));
            WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
            WebCSRPageFactory.WebCSRMasterPage.select_submit_button();

            // To select Account Relationship and click on Continue button.
            Application.WebCSR.SelectAccountRelationshipandOwners(relationType);
            WebCSRPageFactory.WebCSRMasterPage.Continue();
            WebCSRPageFactory.WebCSRMasterPage.Continue();

            // If the Profile Release Under Test is greater-than V734, then click on Continue button on 'Select Package' page.
            string sProfileReleaseV734 = Data.Get("GLOBAL_PROFILE_RELEASE_V734");
            //string sProfileReleaseUnderTest = WebCSRPageFactory.WebCSRMasterPage.get_application_under_test();
           // int iProfileReleaseUnderTest = HostPageFactory.CommonScreen.GetProfileReleaseUnderTest();
           // if (iProfileReleaseUnderTest >= Convert.ToInt32(sProfileReleaseV734))
           // {
               // WebCSRPageFactory.WebCSRMasterPage.Continue();
            //}

            // To select product                       
            Application.WebCSR.SelectAccountsforProductinSelectAccountPage(prodType, NoOfAcc);
            WebCSRPageFactory.WebCSRMasterPage.Continue();
            WebCSRPageFactory.CreateAccountPage.AccountDetails(sAccountClass, productType, "0", accDetails);
            WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
            bool flag = WebCSRPageFactory.WebCSRMasterPage.VerifytheObjectExists(WebCSRMasterPage.CreateAccountContinueButton);
            if (flag)
                WebCSRPageFactory.WebCSRMasterPage.Continue();
            WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
            Thread.Sleep(5000);
            string accNumber = WebCSRPageFactory.CreateAccountPage.AccountInfo();
            Report.Pass("Account Created Successfully. Account No:" + accNumber, "Account Creation Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            return accNumber;
        }


        public virtual string GetAccount(string accNumber, bool IsJoint = false)
        {
            this.get_account(accNumber, IsJoint);
            return accNumber;
        }
        public virtual void get_account(string sAcctNumber, bool IsJoint = false)
        {
            string searchType = "AccountNumber";
            if (IsJoint)
            {
                WebCSRPageFactory.CustomerSearchPage.SelectCustomerNumberByJointAccountNumber(sAcctNumber);
            }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(sAcctNumber, searchType);
            }
            WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_ACCOUNTLIST"));
            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(sAcctNumber);
            Report.Info("Account Number : " + sAcctNumber + " is fetched  successfully.", "Account_Overview_Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
        }


        public virtual void select_submit_button()
        {
            WebCSRPageFactory.LoginPage.select_submit_button();
            //Report.Pass("Fetched the account successfully.", "Account Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
        }

        public virtual void NavigateToAccountHistoryPage(string AccNum)
        {
            WebCSRPageFactory.AccountHistoryPage.NavigateToAccountHistoryPage(AccNum);
        }
        public virtual void navigate_to_account_history_page()
        {
            WebCSRPageFactory.AccountHistoryPage.navigate_to_account_history_page();
        }

        public virtual void ClickAdvancedSearch()
        {
            WebCSRPageFactory.AccountHistoryPage.ClickAdvancedSearch();
        }
        public virtual void SelectTransactionTypeAll()
        {
            WebCSRPageFactory.AccountHistoryPage.SelectTransactionTypeAll();
        }
        public virtual void select_advanced_search_transaction_type_all()
        {
            WebCSRPageFactory.AccountHistoryPage.ClickAdvancedSearch();
            WebCSRPageFactory.AccountHistoryPage.SelectTransactionTypeAll();
        }

        public virtual void ClickSetUpNewAccount(string AppDate, string LinkName)
        {
            WebCSRPageFactory.AccountHistoryPage.ClickSetUpNewAccount(AppDate, LinkName);
        }
        public virtual void VerifyNewAccountDetails(string[] sTransactionDetailInfo)
        {
            WebCSRPageFactory.AccountHistoryPage.VerifyNewAccountDetails(sTransactionDetailInfo);
        }
        public virtual void NavigateToAccountSummaryPage()
        {
            WebCSRPageFactory.AccountHistoryPage.NavigateToAccountSummaryPage();
        }
        public virtual void VerifyTabsonAccountSummaryPage()
        {
            WebCSRPageFactory.AccountHistoryPage.VerifyTabsonAccountSummaryPage();
        }
        public virtual void ClickOnPaymentTab()
        {
            WebCSRPageFactory.AccountSummaryPage.ClickOnPaymentTab();
        }
        public virtual void SelectPaymentCalculationLink()
        {
            WebCSRPageFactory.AccountSummaryPage.SelectPaymentCalculationLink();
        }

        public virtual void SelectSpecifiedValueFromCalculationRulesAmortizationCalculationMethodDropdown(string AmortizationOption)
        {
            WebCSRPageFactory.AccountSummaryPage.SelectSpecifiedValueFromCalculationRulesAmortizationCalculationMethodDropdown(AmortizationOption);
        }
        public virtual void VerifyInformationUpdatedMessage()
        {
            WebCSRPageFactory.AccountSummaryPage.VerifyInformationUpdatedMessage();
        }
        public virtual void ClickOnGeneralTab()
        {
            WebCSRPageFactory.AccountSummaryPage.ClickOnGeneralTab();
        }
        public virtual void ModifyCustomerCodeOnLoanGeneralPage(string CustomerCode)
        {
            WebCSRPageFactory.AccountSummaryPage.ModifyCustomerCodeOnLoanGeneralPage(CustomerCode);
        }
        public virtual void ClickOnTitleTab()
        {
            WebCSRPageFactory.AccountSummaryPage.ClickOnTitleTab();
        }
        public virtual void ModifyMailingAddressOnAccountSummaryPage(string AddressVal2)
        {
            WebCSRPageFactory.AccountSummaryPage.ModifyMailingAddressOnAccountSummaryPage(AddressVal2);
        }
        public virtual void ClickLoanAccountMaintenance(string sDate, string sLinkName)
        {
            WebCSRPageFactory.AccountHistoryPage.ClickLoanAccountMaintenance(sDate, sLinkName);
        }
        public virtual void VerifyLoanAccountMaintDetails(string[] sTransactionDetailInfo)
        {
            WebCSRPageFactory.AccountHistoryPage.VerifyLoanAccountMaintDetails(sTransactionDetailInfo);
        }
        public virtual void ClickLoanAccountMaintenanceLink2(string sLinkName)
        {
            WebCSRPageFactory.AccountHistoryPage.ClickLoanAccountMaintenance2(sLinkName);
        }
        public virtual void VerifyLoanAccountMaintDetails2(string[] sTransactionDetailInfo)
        {
            WebCSRPageFactory.AccountHistoryPage.VerifyLoanAccountMaintDetails2(sTransactionDetailInfo);
        }
        public virtual void check_account_verification_link_exist()
        {
            WebCSRPageFactory.WebCSRMasterPage.check_account_verification_link_exist();
        }
        public virtual void navigate_to_account_verification_page()
        {
            WebCSRPageFactory.WebCSRMasterPage.navigate_to_account_verification_page();
        }
        public virtual string GetApplicationDate()
        {
            string Date = WebCSRPageFactory.AddressPage.GetApplicationDate();
            return Date;
        }
        public virtual string CalculateNewDate(string startdate, string dparam, int numberofDay)
        {
            return WebCSRPageFactory.WebCSRMasterPage.CalculateDate(startdate, dparam, numberofDay);
        }
        public virtual void TransferFund(string FromAccountNo, string ToAccountNo, string Amount, string systemDate = "")
        {
            WebCSRPageFactory.FundTransferPage.EnterFundTransferDetails(FromAccountNo, ToAccountNo, Amount, systemDate);
        }
        public virtual void NavigateToFundsTransferPage()
        {
            WebCSRPageFactory.FundTransferPage.NavigateToFundsTransferPage();
        }
        public virtual void NavigateToPendingFundsTransferPage()
        {
            WebCSRPageFactory.PendingTransferPage.NavigateToPendingFundsTransferPage();
        }
        public virtual void ModifyPendingTransfer(string date, string amount)
        {
            this.ClickLinkFromMenuItem(Data.Get("Funding Services") + "|" + Data.Get("Pending Transfers"));
            WebCSRPageFactory.PendingTransferPage.ModifyPendingTransfer(date, amount);
            if (WebCSRPageFactory.PendingTransferPage.VerifyMessagePendingPage("The transfer information has been updated"))
            {
                Report.Pass("The transfer information has been updated ", "TransferModified", "true", appHandle);
            }
            else
            {
                Report.Fail("The transfer information has been updated", "TransferNotModified", "true", appHandle, true);
            }

        }
        public virtual void VerifyTransferUpdateMsg()
        {
            WebCSRPageFactory.PendingTransferPage.VerifyTransferUpdateMsg();
        }
        public virtual void DeletePendingTransfer(string date)
        {
            this.ClickLinkFromMenuItem(Data.Get("Funding Services") + "|" + Data.Get("Pending Transfers"));
            WebCSRPageFactory.PendingTransferPage.DeletePendingTransfer(date);
            if (WebCSRPageFactory.PendingTransferPage.VerifyMessagePendingPage("The transfer has been deleted."))
            {
                Report.Pass("The transfer has been deleted. ", "TransferDeleted", "true", appHandle);
            }
            else
            {
                Report.Fail("The transfer has not been deleted.", "TransferNotDeleted", "true", appHandle, true);
            }
        }
        public virtual string GetUserID(string Customer)
        {
            GetCustomer(Customer);
            string UserID = WebCSRPageFactory.CustomerSearchPage.GetUserID();
            return UserID;

        }
        public virtual void VerifyCustomerHistory(string HistoryLinkName)
        {
            // WebCSRPageFactory.CustomerHistoryPage.NavigateToCustomerHistoryPage();
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("History"));
            WebCSRPageFactory.CustomerHistoryPage.VerifyCustomerHistory(HistoryLinkName);

        }
        public virtual void UpdateCustomerIdentity(string custno)
        {
            WebCSRPageFactory.VerifyCustomerPage.VerificationAction(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.LoginPage.select_submit_button();
            WebCSRPageFactory.CustomerInformationPage.UpdateCustomerIdentity();
        }
        /// <summary>
        /// This method is used to create Customer. There are two mandatory parameters : sCustomerType and  sSearchType . Based on requirement IdentificationType, intNumberOfYearsAtPresentAddress, MailAddrSameAsHomeAddr, AllowOnlineAccess , CreateTelephoneBankingPIN can be provided. Default values are string IdentificationType = null, int intNumberOfYearsAtPresentAddress = 0, bool MailAddrSameAsHomeAddr = true, bool AllowOnlineAccess = true, bool CreateTelephoneBankingPIN = true .
        /// </summary>
        /// <param name="sCustomerType"></param>
        /// <param name="sSearchType"></param>
        /// <param name="IdentificationType"></param>
        /// <param name="intNumberOfYearsAtPresentAddress"></param>
        /// <param name="MailAddrSameAsHomeAddr"></param>
        /// <param name="AllowOnlineAccess"></param>
        /// <param name="CreateTelephoneBankingPIN"></param>
        /// <returns>It returns Customer number.</returns>
        public virtual string create_customer(string sCustomerType, string sSearchType, string IdentificationType = null, int intNumberOfYearsAtPresentAddress = 0, bool MailAddrSameAsHomeAddr = true, bool AllowOnlineAccess = true, bool CreateTelephoneBankingPIN = true)
        {
            string NumberOfYearsAtCurrentAddress = "";
            string sTaxIdValue1 = "";
            string sCustomerNumber = "";
            if (sCustomerType.Equals(Data.Get("GLOBAL_PERSONAL_CUSTOMER")))
            {
                WebCSRPageFactory.WebCSRMasterPage.select_create_personal_customer_link();
                // Enter Personal Information details.
                WebCSRPageFactory.CreatePersonalCustomerPage.enter_personal_information_details();
                if (string.IsNullOrEmpty(IdentificationType))
                {
                    // Enter Drivers License details.
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_drivers_license_identification_details();
                }
                else if (IdentificationType.Equals(Data.Get("GLOBAL_IDENTIFICATION_PASSPORT")))
                {
                    // Enter Passport details.
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_passport_identification_details();
                }
                else if (IdentificationType.Equals(Data.Get("GLOBAL_IDENTIFICATION_OTHER")))
                {
                    // Enter Other details.
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_other_identification_details();
                }
                // Enter Email and Phone details.
                WebCSRPageFactory.CreatePersonalCustomerPage.enter_email_and_phone_details();
                // Enter Home Address details.
                if (intNumberOfYearsAtPresentAddress == 0)
                {
                    NumberOfYearsAtCurrentAddress = (string)Data.Get("GLOBAL_YEAR_AT_ADDRESS_ONE_OR_LESS");
                }
                else
                {
                    NumberOfYearsAtCurrentAddress = intNumberOfYearsAtPresentAddress + "";
                }

                WebCSRPageFactory.CreatePersonalCustomerPage.enter_home_address_details(NumberOfYearsAtCurrentAddress);
                // Enter Mailing Address details.
                if (MailAddrSameAsHomeAddr)
                {
                    WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_mailing_address_same_as_home_address_yes();

                }
                else
                {
                    WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_mailing_address_same_as_home_address_no();
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_mailing_address_details();

                }
                if (intNumberOfYearsAtPresentAddress < 5)
                {
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_previous_address_details();
                }
                else
                {
                    WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_mailing_address_same_as_home_address_no();
                }
                // Enter Online Access details.
                if (AllowOnlineAccess)
                {
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_online_access_details();
                }
                else
                {
                    WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_allow_online_access_no();
                }
                // Enter Security Question details.
                WebCSRPageFactory.CreatePersonalCustomerPage.enter_security_question_details();
                // Enter Telephone Banking details.
                if (CreateTelephoneBankingPIN)
                {
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_telephone_banking_details();
                }
                sTaxIdValue1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_tax_id_number_field_value();
                WebCSRPageFactory.CreatePersonalCustomerPage.select_continue_button();
                WebCSRPageFactory.CreatePersonalCustomerPage.select_submit_button();

                if (WebCSRPageFactory.CreatePersonalCustomerPage.VerifyPersonalCustomerCreationSuccess())
                {
                    Report.Pass("Personal Customer application is created successfully", "PersonalCustCreate", "true", appHandle);

                    sCustomerNumber = WebCSRPageFactory.CustomerSearchPage.get_customer_number(sSearchType, sTaxIdValue1);
                    if (!string.IsNullOrEmpty(sCustomerNumber))
                    {
                        Report.Pass("Personal customer number is captured as: " + sCustomerNumber, "custpersonal", "true", appHandle);
                    }
                }
                else
                {
                    Report.Fail("Personal Customer application is not created due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "CreatePersonalcustFail", "true", appHandle, true);
                }
            }

            return sCustomerNumber;
        }
        public virtual void LogOutofWebCSR()
        {
            WebCSRPageFactory.LoginPage.WebCSRLogOut();
        }
        public virtual void logoff_specified_application(string SpecifiedApplicattion)
        {
            LogOutofWebCSR();

        }

        
        
        public virtual void select_account_summary_tab()
        {
            WebCSRPageFactory.AccountOverviewPage.select_account_summary_tab();
        }
        public virtual void select_account_history_tab()
        {
            WebCSRPageFactory.AccountOverviewPage.select_account_history_tab();
        }
        public virtual void select_payment_tab()
        {
            WebCSRPageFactory.AccountInformationPage.select_payment_tab();
        }
        // public virtual string get_date_Of_last_payment_transaction_field_value()
        // {
        //     return WebCSRPageFactory.LoanPaymentPaymentDetailPage.get_date_Of_last_payment_transaction_field_value();
        // }
        public virtual void check_date_of_last_payment_transaction_field_value(string sDate)
        {
            string LN_LPDT = WebCSRPageFactory.LoanPaymentDetailPage.get_date_Of_last_payment_transaction_field_value();

            if (!string.IsNullOrEmpty(sDate))
            {
                if (sDate.Equals(LN_LPDT))
                {
                    Report.Pass("The label - <Date of Last Payment Transaction> has expected value - <" + sDate + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                }
                else
                {
                    Report.Fail("The label - <Date of Last Payment Transaction> does not have the expected value - <" + sDate + ">.The actual value  is  - <" + LN_LPDT + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                }
            }
            if (string.IsNullOrEmpty(sDate))
            {
                if (string.IsNullOrEmpty(sDate) & string.IsNullOrEmpty(LN_LPDT))
                {
                    Report.Pass("The label - <Date of Last Payment Transaction> has expected value - Null.", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                }
                else
                {
                    Report.Fail("The label - <Date of Last Payment Transaction> does not have the expected value - Null.", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                }
            }
        }

        public virtual void select_payment_detail_link()
        {
            WebCSRPageFactory.LoanPaymentTabPage.select_payment_detail_link();
        }
        public virtual void navigate_to_payment_detail_page()
        {
            WebCSRPageFactory.LoanPaymentDetailPage.navigate_to_payment_detail_page();
        }
        public virtual void navigate_to_transaction_processing_general_page()
        {
            WebCSRPageFactory.DepositTransactionProcessingGeneralPage.navigate_to_transaction_processing_general_page();
        }
        public virtual void check_specified_data_available_in_history_table(string referenceValues)
        {
            WebCSRPageFactory.AccountHistoryPage.check_specified_data_available_in_history_table(referenceValues);
        }
        public virtual void check_text_exists_in_table(string referenceValue)
        {
            bool blnExists = WebCSRPageFactory.AccountHistoryPage.check_text_exists_in_table(referenceValue);
            if (blnExists)
            {
                Report.Pass("Specified Data: " + referenceValue + " is Available in table.", "Account_Summary_Page.", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("Specified Data: " + referenceValue + " is not Available in table.", "Account_Summary_Page.", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }

        public virtual void check_number_of_payments_satisfied_field_value(string sNumPaymentSatisfied)
        {
            string LN_CNTCR = WebCSRPageFactory.LoanPaymentDetailPage.get_number_of_payments_satisfied_field_value();

            if (sNumPaymentSatisfied.Equals(LN_CNTCR))
            {
                Report.Pass("The label - <Number of Payments Satisfied> has the expected value - <" + sNumPaymentSatisfied + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Date of Last Payment Transaction> does not have the expected value - <" + sNumPaymentSatisfied + ">.The actual value  is  - <" + LN_CNTCR + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }
        public virtual void check_ledger_balance_field_value(string sLedgerBalanceAmount)
        {
            string ACN_BAL = WebCSRPageFactory.AccountInformationPage.get_ledger_balance_field_value();

            if (sLedgerBalanceAmount.Equals(ACN_BAL))
            {
                Report.Pass("The label - <Ledger Balance> has the expected value - <" + sLedgerBalanceAmount + ">", "Loan_General_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Ledger Balance> has the expected value - <" + sLedgerBalanceAmount + ">", "Loan_General_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }

        public virtual void check_available_balance_field_value(string sAvailableBalanceAmount)
        {
            string DEP_BALAVL = WebCSRPageFactory.AccountInformationPage.get_available_balance_field_value();

            if (sAvailableBalanceAmount.Equals(DEP_BALAVL))
            {
                Report.Pass("The label - <Available Balance> has the expected value - <" + sAvailableBalanceAmount + ">", "AccountInformation_General_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Available Balance> does not have the expected value - <" + sAvailableBalanceAmount + ">", "AccountInformation_General_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }

        public virtual void check_computed_balance_field_value(string sComputedBalanceAmount)
        {
            string LN_BALCMP = WebCSRPageFactory.AccountInformationPage.get_computed_balance_field_value();

            if (sComputedBalanceAmount.Equals(LN_BALCMP))
            {
                Report.Pass("The label - <Computed Balance> has the expected value - <" + sComputedBalanceAmount + ">", "Loan_General_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Computed Balance> does not have the expected value - <" + sComputedBalanceAmount + ">", "Loan_General_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }
        public virtual void check_collected_balance_field_value(string sCollectedBalanceAmount)
        {
            string ACN_BALCOL = WebCSRPageFactory.AccountInformationPage.get_collected_balance_field_value();

            if (sCollectedBalanceAmount.Equals(ACN_BALCOL))
            {
                Report.Pass("The label - <Collected Balance> has the expected value - <" + sCollectedBalanceAmount + ">", "AccountInformation_General_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Collected Balance> does not have the expected value - <" + sCollectedBalanceAmount + ">", "AccountInformation_General_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }
        public virtual void navigate_to_loan_calculation_options_page()
        {
            WebCSRPageFactory.AccountInformationPage.select_interest_tab();
            WebCSRPageFactory.LoanInterestTab.select_calculation_options_link();
        }

        public virtual void check_accrual_calculation_balance_field_value(string sBalanceAmount)
        {
            string LN_BALINT = WebCSRPageFactory.LoanCalculationOptionsPage.get_accrual_calculation_balance_field_value();

            if (sBalanceAmount.Equals(LN_BALINT))
            {
                Report.Pass("The label - <Accrual Calculation Balance> has the expected value - <" + sBalanceAmount + ">", "Loan_Interest_CalculationOptions_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Accrual Calculation Balance> does not have the expected value - <" + sBalanceAmount + ">", "Loan_Interest_CalculationOptions_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }

        public virtual void check_last_credit_amount_field_value(string sLastCreditAmount)
        {
            string DEP_AMTLC = WebCSRPageFactory.DepositTransactionProcessingGeneralPage.get_last_credit_amount_field_value();
            if (sLastCreditAmount.Equals(DEP_AMTLC))
            {
                Report.Pass("The label - <Last Credit Amount> has the expected value - <" + sLastCreditAmount + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Last Credit Amount> does not have the expected value - <" + sLastCreditAmount + ">.The actual value  is  - <" + DEP_AMTLC + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }
        public virtual void check_date_of_last_credit_field_value(string sDateOfLastCredit)
        {
            string DEP_DTLC = WebCSRPageFactory.DepositTransactionProcessingGeneralPage.get_date_of_last_credit_field_value();
            if (sDateOfLastCredit.Equals(DEP_DTLC))
            {
                Report.Pass("The label - <Date of Last Credit> has the expected value - <" + sDateOfLastCredit + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Date of Last Credit> does not have the expected value - <" + sDateOfLastCredit + ">.The actual value  is  - <" + DEP_DTLC + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }
        public virtual void check_last_debit_amount_field_value(string sLastDebitAmount)
        {
            string DEP_AMTLD = WebCSRPageFactory.DepositTransactionProcessingGeneralPage.get_last_debit_amount_field_value();

            // if (string.IsNullOrEmpty(sLastDebitAmount))
            // {
            //     if (string.IsNullOrEmpty(DEP_AMTLD))
            //     {
            //         Report.Pass("The label - <Last Debit Amount> has the expected value - <" + sLastDebitAmount + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));    
            //     }
            //     else
            //     {
            //         Report.Fail("The label - <Last Debit Amount> does not have the expected value - <" + sLastDebitAmount + ">.The actual value  is  - <" + DEP_AMTLD + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));        
            //     }                
            // }             
            // else 
            // {
            if (sLastDebitAmount.Equals(DEP_AMTLD))
            {
                Report.Pass("The label - <Last Debit Amount> has the expected value - <" + sLastDebitAmount + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Last Debit Amount> does not have the expected value - <" + sLastDebitAmount + ">.The actual value  is  - <" + DEP_AMTLD + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            // }
        }
        public virtual void check_date_of_last_debit_field_value(string sDateOfLastDebit)
        {
            string DEP_DTLD = WebCSRPageFactory.DepositTransactionProcessingGeneralPage.get_date_of_last_debit_field_value();

            // if (string.IsNullOrWhiteSpace(sDateOfLastDebit))
            // {
            //     if (string.IsNullOrEmpty(DEP_DTLD))
            //     {
            //         Report.Pass("The label - <Date of Last Debit> has the expected value - <" + sDateOfLastDebit + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));                    
            //     }
            //     else
            //     {
            //         Report.Fail("The label - <Date of Last Debit> does not have the expected value - <" + sDateOfLastDebit + ">.The actual value  is  - <" + DEP_DTLD + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));                    
            //     }
            // }
            // else
            // {
            if (sDateOfLastDebit.Equals(DEP_DTLD))
            {
                Report.Pass("The label - <Date of Last Debit> has the expected value - <" + sDateOfLastDebit + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Date of Last Debit> does not have the expected value - <" + sDateOfLastDebit + ">.The actual value  is  - <" + DEP_DTLD + ">", "Payment_Detail_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            // }


        }

        /// <summary>
        /// This method is used for Navigate to the customer home page.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        ///Application.WebCSR.NavigateToCustomerHomePage();
        /// </example>

        public virtual void NavigateToCustomerHomePage(string customerNumber)
        {
            try
            {
                GetCustomer(customerNumber);
                WebCSRPageFactory.CustomerHistoryPage.NavigateToCustomerHistoryPage();
            }

            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }
        /// <summary>
        /// This method is used for Navigate to the create account relationship page.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        ///Application.WebCSR.NavigateToCreateAccountRelatioshippage();
        /// </example>
        public virtual void NavigateToCreateAccountRelatioshippage(string customerNumber, string searchType, string actionType)
        {

            try
            {

                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(customerNumber, searchType);
                WebCSRPageFactory.VerifyCustomerPage.VerificationAction(actionType);
                WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
                WebCSRPageFactory.WebCSRMasterPage.select_submit_button();

            }


            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used for Navigate to the create account selected accounts page.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        ///Application.WebCSR.NavigatetoCreateAccountselectaccountsPage();
        /// </example>

        public virtual void NavigatetoCreateAccountSelectAccountsPage(string customerNumber, string relationType)
        {
            try
            {
                GetCustomer(customerNumber);
                WebCSRPageFactory.VerifyCustomerPage.VerificationAction(Data.Get("GLOBAL_AccountCreate"));
                WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
                WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
                Application.WebCSR.SelectAccountRelationshipandOwners(relationType);
                WebCSRPageFactory.WebCSRMasterPage.Continue();
                WebCSRPageFactory.CreateAccountPage.ConfirmPackagePage();
                WebCSRPageFactory.WebCSRMasterPage.Continue();
                bool blnConfirmedMsg = WebCSRPageFactory.CreateAccountPage.ConfirmSelectAccountsPage();
                if (blnConfirmedMsg)
                {
                    Report.Pass("Successfully navigated to select accounts page", "True", appHandle);
                }
                else
                {
                    Report.Fail("Not navigated to the accounts page", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }


        /// <summary>
        /// This method is used to get account verification status
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.GetAccountVerificationStatus();
        /// </example>
        public virtual void GetAccountVerificationStatus(string sAccName, string sAccNumber)
        {
            try
            {
                GetAccount(sAccNumber);
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkinTab(BankingCenterPage.GeneralAccServicesTab, BankingCenterPage.GeneralAccServicesAccountVerificationLink);
                WebCSRPageFactory.AccountVerificationPage.selectAccountFromAccountDropdown(sAccName, sAccNumber);
                bool bCheck = WebCSRPageFactory.AccountVerificationPage.VerifyIntegrityError();
                if (bCheck == true)
                {
                    Report.Pass("Account integrity verification success", "AccountVerificationStatus", "True");
                }
                else
                {
                    Report.Fail("Account integrity verification failed", "AccountVerificationStatus", "True");
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// To update the Next Statement Date for the nearest statement date or some specific date.
        /// <param name="GroupNumberDetails"></param>
        /// GroupNumberDetails[0] = "Near to Frequency" or "Set to Specific Date" //type of frequenct to be set
        /// GroupNumberDetails[1] = "1"   'Group Number: 1-> DDA group accounts, 98-> CD accounts, 2-> IRA accounts
        /// GroupNumberDetails[2] = "" or "2;d" 'Number of days to add to current system date (T+n)
        /// <returns>string</returns>
        /// List<string> GroupNumberDetails1 = new List<string>();
        /// GroupNumberDetails1.Add("Near to Frequency");
        /// GroupNumberDetails1.Add("1");
        /// GroupNumberDetails1.Add(""); 
        /// <example>string Statementout = UpdateStatementDate(GroupNumberDetails1)</example>
        /// List<string> GroupNumberDetails2 = new List<string>();
        /// GroupNumberDetails2.Add("Set to Specific Date");
        /// GroupNumberDetails2.Add("1");
        /// GroupNumberDetails2.Add("2;d"); 
        /// <example>string Statementout = UpdateStatementDate(GroupNumberDetails2)</example>
        public virtual string UpdateStatementDate(List<string> GroupNumberDetails)
        {
            string StatmentDateValuesOut = null;
            try
            {
                string FrequencyToBeSet = null;
                string NextStatementDate = null;
                string CurrentSystemDate = Application.WebCSR.GetApplicationDate();
                bool ctr = false;
                switch (GroupNumberDetails[0].ToUpper())
                {

                    case "NEAR TO FREQUENCY":
                        string sday = WebCSRPageFactory.WebCSRMasterPage.SplitSideString(CurrentSystemDate, "LEFT", 5);
                        int CurrentDay = Int32.Parse(WebCSRPageFactory.WebCSRMasterPage.SplitSideString(sday, "RIGHT", 2));
                        int CurrentMonth = Int32.Parse(WebCSRPageFactory.WebCSRMasterPage.SplitSideString(sday, "LEFT", 2));
                        string CurrentYear = WebCSRPageFactory.WebCSRMasterPage.SplitSideString(CurrentSystemDate, "RIGHT", 2);
                        string FullCurrentYear = WebCSRPageFactory.WebCSRMasterPage.SplitSideString(CurrentSystemDate, "RIGHT", 4);
                        if (CurrentDay >= 1 && CurrentDay < 5)
                        {
                            FrequencyToBeSet = "1MA5";
                            ctr = true;
                        }
                        if (CurrentDay >= 6 && CurrentDay < 10)
                        {
                            FrequencyToBeSet = "1MA10";
                            ctr = true;
                        }
                        if (CurrentDay >= 11 && CurrentDay < 15)
                        {
                            FrequencyToBeSet = "1MA15";
                            ctr = true;
                        }
                        if (CurrentDay >= 16 && CurrentDay < 20)
                        {
                            FrequencyToBeSet = "1MA20";
                            ctr = true;
                        }
                        if (CurrentDay >= 21 && CurrentDay < 25)
                        {
                            FrequencyToBeSet = "1MA25";
                            ctr = true;
                        }
                        if (CurrentDay == 26 || CurrentDay == 27)
                        {
                            FrequencyToBeSet = "1MAE";
                            ctr = true;
                        }
                        if (CurrentDay == 5 || CurrentDay == 10 || CurrentDay == 15 || CurrentDay == 20 || CurrentDay == 25)
                        {
                            NextStatementDate = CurrentSystemDate;
                            ctr = false;
                        }
                        if (CurrentDay == 28 || CurrentDay == 29 || CurrentDay == 30 || CurrentDay == 31)
                        {
                            if (CurrentMonth == 2)
                            {
                                if (appHandle.IsLeapYear(Int32.Parse(FullCurrentYear)))
                                {
                                    if (CurrentDay != 29)
                                    {
                                        FrequencyToBeSet = "1MAE";
                                        ctr = true;
                                    }
                                    else
                                    {
                                        NextStatementDate = "02/29/" + FullCurrentYear;
                                        ctr = false;
                                    }
                                }
                                else
                                {
                                    NextStatementDate = "02/28/" + FullCurrentYear;
                                    ctr = false;
                                }

                            }
                            if (CurrentMonth == 1 || CurrentMonth == 3 || CurrentMonth == 5 || CurrentMonth == 7 || CurrentMonth == 8 || CurrentMonth == 10 || CurrentMonth == 12)
                            {
                                if (CurrentDay != 31)
                                {
                                    FrequencyToBeSet = "1MAE";
                                    ctr = true;
                                }
                                else
                                {
                                    NextStatementDate = (CurrentMonth.ToString()) + "/31/" + FullCurrentYear;
                                    ctr = false;
                                }
                            }
                            if (CurrentMonth == 4 || CurrentMonth == 6 || CurrentMonth == 9 || CurrentMonth == 11)
                            {
                                NextStatementDate = (CurrentMonth.ToString()) + "/30/" + FullCurrentYear;
                                ctr = false;
                            }
                        }
                        break;

                    case "SET TO SPECIFIC DATE":
                        string[] arrloc = WebCSRPageFactory.WebCSRMasterPage.SplitString(GroupNumberDetails[2], ";");
                        NextStatementDate = WebCSRPageFactory.WebCSRMasterPage.CalculateNewDate(CurrentSystemDate, arrloc[1], (Int32.Parse(arrloc[0])));
                        ctr = false;
                        break;
                }

                WebCSRPageFactory.WebCSRMasterPage.SelectLinkinTab(BankingCenterPage.CustServicesLink, BankingCenterPage.CustServiceStatementGroupLink);
                WebCSRPageFactory.StatementGroupPage.SelectStatementGroup(GroupNumberDetails[1]);
                WebCSRPageFactory.StatementGroupPage.ClickOnStatementGroupEditButton();

                if (ctr == true)
                    WebCSRPageFactory.UpdateStatementGroupPage.SetFrequencyInEditStatementGroup(FrequencyToBeSet);
                else
                    WebCSRPageFactory.UpdateStatementGroupPage.SetNextDateInEditStatementGroup(NextStatementDate);

                string Frequency = WebCSRPageFactory.UpdateStatementGroupPage.GetValuefromFrequencyInEditStatementGroup();
                string StatementDate = WebCSRPageFactory.UpdateStatementGroupPage.GetValuefromNextDateInEditStatementGroup();

                WebCSRPageFactory.UpdateStatementGroupPage.ClickOnEditStatementGroupSubmitButton();
                bool bcheck = WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_CONTEXT_STMTGRP_UPDATED_MSG"));
                StatmentDateValuesOut = StatementDate + "," + Frequency;
                if (!bcheck)
                {
                    Report.Fail("failed to update statement group", "statement", "True", appHandle);
                }
                else
                    Report.Pass("The statement group has been updated successfully.", "statement", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return StatmentDateValuesOut;
        }

        /// <summary>
        /// To create the Collection Payment order.
        /// </summary>
        /// <param Customer Account = Account for which Collection or Payment order has to be created./>
        /// <param Payment Type = GLOBAL_PAYMENT_TYPE_COLLECTIONORDER, GLOBAL_PAYMENT_TYPE_PAYMENTORDER etc./>
        /// <param name = "TransferDetails"></param>
        /// TransferDetails[0] = "1"        'RecipientAccountInstitutionField'
        /// TransferDetails[1] = "823648"   'RecipientAccountAccountField'
        /// TransferDetails[2] = "1 - DDA Account"  'RecipientAccountAccountType'
        /// TransferDetails[3] = "1 - Fixed Amount" 'AmountDetailsAmountTypeDropDown'
        /// TransferDetails[4] = "1000" 'AmountDetailsAmountField'
        /// TransferDetails[5] = "02/01/2015" 'OccurenceEffectiveDate'
        /// TransferDetails[6] = "GLOBAL_ON" 'To click the PriorityCheckbox' otherwise TransferDetails[6]=""
        /// TransferDetails[7] = "GLOBAL_ON" 'To click the OverrideStopCheckbox' otherwise TransferDetails[7]=""
        /// TransferDetails[8] = "GLOBAL_ON" 'To click the HoldAutoPlacedCheckbox' otherwise TransferDetails[8]=""
        /// TransferDetails[9] = "21 - DDA Return - Credit" 'EconomicActivityCodeDropDown'
        /// TransferDetails[10] = "Telephone" 'AuthorizationReceivedDropDown'
        /// TransferDetails[11] = "Test" 'SpecificDescription'
        /// <returns></returns>
        /// <example>
        /// Application.WebCSR.CreateCollectionPaymentOrder();
        /// </example>

        public virtual void CreateCollectionPaymentOrder(string saccountName, string spaymentType, string[] TransferDetails)
        {
            try
            {
                WebCSRPageFactory.BankingCenterPage.selectPaymentServicesDomesticPaymentsCustomerLink();
                WebCSRPageFactory.DomesticPaymentPage.selectAccountFromDropDown(saccountName);
                WebCSRPageFactory.DomesticPaymentPage.clickonAddButton();
                WebCSRPageFactory.DomesticPaymentAddPage.SelectPaymentTypeFromDropDown(spaymentType);
                bool bCheck = WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.AddCollectionOrder(TransferDetails);
                if (bCheck == true)
                    Report.Pass("The order was successfully placed", "Collection Order", "True");
                else
                    Report.Fail("The order was not placed", "Collection Order", "True");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// To create the Retirement Plan.
        /// </summary>
        /// <param name = sCustomerNumber./>
        /// <param name = sRetirementPlanName/>
        /// <param name = "RetirementDetails"/>
        /// RetirementDetails[0] = ""        'Retirement Plan Date' 'By default application date'
        /// RetirementDetails[1] = ""   'Retirement Plan ID'
        /// RetirementDetails[2] = "1"  'Retirement No Of Death Beneficiaries'
        /// RetirementDetails[3] = "GLOBAL_ON" 'To check Spousal Consent Required check box' 'otherwise RetirementDetails[3]=""'
        /// RetirementDetails[4] = "GLOBAL_ON" 'To check Spousal Consent on File check box'  'otherwise RetirementDetails[4]=""' 
        /// <param name = "DeathBeneficiariesDetails"></param>
        /// DeathBeneficiariesDetails[0] = "PRIMARY"  'Death Beneficiary 1 Type
        /// DeathBeneficiariesDetails[1] =  "Ravi"  ''Death Beneficiary 1 Name
        /// DeathBeneficiariesDetails[2] = "456-92-7195"  ''Death Beneficiary 1 Tax ID
        /// DeathBeneficiariesDetails[3] = "01/01/1969"  ''Death Beneficiary 1 Date Of Birth
        /// DeathBeneficiariesDetails[4] = "Brother"  ''Death Beneficiary 1 Relationship to Owner
        /// DeathBeneficiariesDetails[5] = "100.00000"  ''Death Beneficiary 1 Percentage
        /// DeathBeneficiariesDetails[6] = GLOBAL_FALSE ''Death Beneficiary 1 Eligible for Fair Market Value Calculation
        /// DeathBeneficiariesDetails[7] = "GLOBAL_ON" 'To click the OverrideStopCheckbox' otherwise TransferDetails[7]=""
        /// DeathBeneficiariesDetails[8] = GLOBAL_TRUE  ''Death Beneficiary 1  Address Same As Owner
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.createRetirementPlan();
        /// </example>
        public virtual void createRetirementPlan(string sCustomerNumber, string sRetirementPlanName, string[] RetirementDetails, string[] DeathBeneficiariesDetails)
        {
            try
            {
                GetCustomer(sCustomerNumber);
                WebCSRPageFactory.VerifyCustomerPage.SelectCreateRetirementPlanFromDropdown();
                WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
                WebCSRPageFactory.CreateRetirementPlanPage.SelectRetirementPlan(sRetirementPlanName);
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                WebCSRPageFactory.CreateRetirementPlanPage.EnterPlanDetails(RetirementDetails);
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                WebCSRPageFactory.AddDeathBeneficiariesPage.EnterDeathBeneficiariesDetails(DeathBeneficiariesDetails);
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
                bool bCheck = WebCSRPageFactory.CreateRetirementPlanPage.CheckSuccessMessageForRetirementPlanCreation();
                if (bCheck == true)
                    Report.Pass("Retirement plan is created successfully", "Retirementplan", "True");
                else
                    Report.Fail("Retirement plan creation failed", "Retirementplan Order", "True");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }


        /// <summary>
        /// This function is used for check values in Balances Table.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        ///
        /// </example>

        public virtual bool verifysubcheckvaluesinbalancestable(string sAccountNumber, string sColumnName)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            //Added all quick look options to a array
            string[][] QLArrayVal = new string[02][]
            {
                new string[08]{"Alert","Account Name","Status","Interest YTD","Balance","Currency","Account Available Balance","Aggregate Available Balance"},
                new string[08]{"1","2","3","4","5","6","7","8"},
            };

            string sColumnNumber = "", sResult = "\n" + "Column Name" + "\t" + "Actual Value" + "\t" + "Expected Value" + "\n" + "--------------------------------------------------------------------\n"; ;
            bool bChkStatus = false;//,bChkFinalStatus=false;
            string[] sColumnNameSplit;
            sColumnNameSplit = sColumnName.Split(';');
            if (sColumnNameSplit.Length > 0 & sAccountNumber.Length > 0)
            {
                for (int j = 0; j < sColumnNameSplit.Length; j += 2)
                {
                    for (int k = 0; k < QLArrayVal[0].Length; k++)
                    {
                        //To verfify eatch column vlaue. if one of the column is not displayed test will fail.
                        if (QLArrayVal[0][k].Trim() == sColumnNameSplit[j])
                        {
                            sColumnNumber = QLArrayVal[1][k];
                            //Dynamic xpath creating.
                            string sTableColunValue = "XPath;//a[text()='" + sAccountNumber + "']/following::td[" + sColumnNumber + "]";
                            //Verifing epected value exist or not;
                            string sActualValue = appHandle.GetObjectText(sTableColunValue);
                            //bChkStatus=appHandle.CheckObjectExist(sTableColunValue);
                            if (sActualValue == sColumnNameSplit[j + 1])
                            {
                                bChkStatus = true;
                                //sResult=sResult+sColumnNameSplit[j]+"\t"+sActualValue+"\t"+sColumnNameSplit[j+1];
                            }
                            else
                            {
                                bChkStatus = false;
                                //sResult=sResult+sColumnNameSplit[j]+"\t"+sActualValue+"\t"+sColumnNameSplit[j+1];    
                            }
                            break;

                        }
                    }
                }
            }
            else
            {
                Report.Fail("Please provied valid input for 'QuicklookOption' argument", true, true);
            }
            //Report.Info("-----------------------Result-------------------------\n"+sResult); 
            //Report.Step("-----------------------Result-------------------------\n"+sResult);
            if (bChkStatus)
            {
                Report.Pass("The expected Option is displayed.", "Verify option", "true", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                return true;
            }
            else
            {
                Report.Fail("The expected Option is not displayed.", "Verify option", "true", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                return false;
            }
        }

        /// <summary>
        /// This function is used for select the grantor information details for the trust customer.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        ///Application.WebCSR.subselecttrustgrantorwebcsr();
        /// </example>

        public virtual void subselecttrustgrantorwebcsr(string sCustomerNumber)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectTrustCustomerLink();
                WebCSRPageFactory.CreateTrustCustomerPage.ClickonSearchbutton();
                WebCSRPageFactory.CreateTrustCustomerPage.selectradiobutton();
                WebCSRPageFactory.CreateTrustCustomerPage.EnterSearchForFieldDetails(sCustomerNumber);
                WebCSRPageFactory.CreateTrustCustomerPage.ClickonSearchbuttonforInnerpage();
                WebCSRPageFactory.CreateTrustCustomerPage.selectbuttonforcustomerfound();

                bool bChkStatus = WebCSRPageFactory.CreateTrustCustomerPage.ConfirmExpectedMessageforGrantInfoDetailstoTrustCustomer();


                if (bChkStatus == true)
                    Report.Pass("Grantor/Primary Trustee Information", "True");
                else
                    Report.Info("False");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This function is used to select Account Relationship and the no of owners while creating any account in account relationship page.
        /// <param name = "AccountRelationship;No.of owners in first dropdown;No.of owners in Second dropdown"/>
        /// <returns></returns> 
        /// <example>
        ///Application.WebCSR.SelectAccountRelationshipandOwners("Revocable Trust (Grantor NT);1;1");
        /// </example>
        public virtual void SelectAccountRelationshipandOwners(string sRelationType)
        {
            try
            {
                string[] arr = sRelationType.Split(';');
                WebCSRPageFactory.CreateAccountRelationshipPage.SelectAccountRelationship(arr[0]);
                if (arr.Length > 1)
                {
                    for (int i = 1; i < arr.Length; i++)
                    {
                        WebCSRPageFactory.CreateAccountRelationshipPage.SelectNumberofCustomers(arr[0], arr[i], i);
                    }
                }
                Report.Info("Account Relationship Details.", "AR", "True", appHandle);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to check column exists in AvailableBalanceCalculationTable.
        /// </summary>
        /// <param name="sAccNumber"></param>
        /// <param name="sTableName"></param>
        /// <param name="sColumnName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckColumnExistsInAvailableBalanceCalculationTable();
        /// </example>
        public virtual void CheckColumnExistsInAvailableBalanceCalculationTable(string sAccNumber, string sTableName, string sColumnName)
        {
            try
            {
                GetAccount(sAccNumber);
                WebCSRPageFactory.DepositAccountOverviewPage.ClickOnAggregateAvailableBalanceImg();
                bool bCheck = WebCSRPageFactory.DepositAccountOverviewPage.CheckColumnExistsInTable(sTableName, sColumnName);
                if (bCheck == true)
                    Report.Pass("Column exists in table", "BalanceCalculationTable", "True", appHandle);
                else
                    Report.Fail("Column not exists in table", "BalanceCalculationTable", "True", appHandle);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used to check column exists in CheckHoldsTable.
        /// </summary>
        /// <param name="sAccNumber"></param>
        /// <param name="sTableName"></param>
        /// <param name="sColumnName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckColumnExistsInCheckHoldsTable();
        /// </example>
        public virtual void CheckColumnExistsInCheckHoldsTable(string sAccNumber, string sTableName, string sColumnName, string sAccName)
        {
            try
            {
                GetAccount(sAccNumber);
                WebCSRPageFactory.DepositAccountOverviewPage.ClickOnHoldsLink();
                WebCSRPageFactory.HoldsPage.SelectAccountFromDropdown(sAccName);
                bool bCheck = WebCSRPageFactory.HoldsPage.CheckColumnExistsInTable(sTableName, sColumnName);
                if (bCheck == true)
                    Report.Pass("Column exists in table", "CheckHoldsTable", "True", appHandle);
                else
                    Report.Fail("Column not exists in table", " ", "True", appHandle);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is get all accounts created in CustomerAccountsCreatedPage.
        /// </summary>
        /// <returns>List<string></returns> 
        /// <example>
        /// Application.WebCSR.GetAccountNumberInWebcsr();
        /// </example>
        public virtual List<string> GetAccountNumberInWebcsr()
        {
            List<string> AccountNumbersList = WebCSRPageFactory.CustomerAccountsCreatedPage.GetAccountNumbers();
            if (AccountNumbersList.Count != 0)
                Report.Pass("Successfully fetched account numbers", "AccountNumbers", "true", appHandle);
            else
                Report.Pass("Failed to fetch account numbers", "AccountNumbers", "true", appHandle);
            return AccountNumbersList;
        }

        /// <summary>
        /// This method is used to navigate Create Account Confirmation Page.
        /// </summary>
        /// <returns><string></returns> 
        /// <example>
        /// Application.WebCSR.NavigateToCreateAccountConfirmationPage();
        /// </example>
        public virtual void NavigateToCreateAccountConfirmationPage(string sAccountClass, string relationType, string productType, string customerId, string[] accDetails)
        {
            CreateAccount(sAccountClass, relationType, productType, customerId, accDetails);
        }



        /// <summary>
        /// This method is used to check column exists in Balances table.
        /// </summary>
        /// <param name="sAccNumber"></param>
        /// <param name="sTableName"></param>
        /// <param name="sColumnName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckColumnExistsInBalancesTable();
        /// </example>
        public virtual void CheckColumnExistsInBalancesTable(string sAccNumber, string sTableName, string sColumnName)
        {
            try
            {
                GetAccount(sAccNumber);
                WebCSRPageFactory.AccountListPage.ClickOnBalancesImg();
                bool bCheck = WebCSRPageFactory.AccountListPage.CheckColumnExistsInTable(sTableName, sColumnName);
                if (bCheck == true)
                    Report.Pass("Column exists in table", "Balances Table", "True", appHandle);
                else
                    Report.Fail("Column not exists in table", "Balances Table", "True", appHandle);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }


        /// <summary>
        /// This method is used to check EXPECTED value in the check holds table table under Account List Page.
        /// </summary>
        /// <param name="sAccNumber"></param>
        /// <param name="sTableName"></param>
        /// <param name="sColumnName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckValuesinCheckHoldsTable();
        /// </example>
        public virtual void CheckValuesinCheckHoldsTable(string sAccNumber, string sTableName, string sAccName, string sHoldType, string sAmount, string sExpDate, string sColumnValue, string sColumnName)
        {
            try
            {
                GetAccount(sAccNumber);
                WebCSRPageFactory.DepositAccountOverviewPage.ClickOnHoldsLink();
                WebCSRPageFactory.HoldsPage.SelectAccountFromDropdown(sAccName);
                WebCSRPageFactory.AddHoldPage.EnterCheckHoldDetails(sHoldType, sAmount, sExpDate);
                GetAccount(sAccNumber);
                WebCSRPageFactory.AccountListPage.ClickOnBalancesImg();
                bool bCheck = WebCSRPageFactory.AccountListPage.CheckvalueExistsinTable(sColumnValue, sTableName, sColumnName);

                if (bCheck == true)
                    Report.Pass("Column value exists in table", "CheckHoldsTable", "True", appHandle);
                else
                    Report.Fail("Column value not exists in table", " ", "True", appHandle);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }


        /// <summary>
        /// This method is used to check EXPECTED value in the avaialable balance calculation table under Account List Page.
        /// </summary>
        /// <param name="sAccNumber"></param>
        /// <param name="sTableName"></param>
        /// <param name="sColumnName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckValuesAvailableBalanceCalculationtable();
        /// </example>
        public virtual void CheckValuesAvailableBalanceCalculationtable(string sAccNumber, string sTableName, string sColumnName, string sColumnValue)
        {
            try
            {
                GetAccount(sAccNumber);
                WebCSRPageFactory.AccountListPage.ClickOnBalancesImg();
                bool bCheck = WebCSRPageFactory.AccountListPage.CheckvalueExistsinTable(sColumnValue, sTableName, sColumnName);
                if (bCheck == true)
                    Report.Pass("Columnvalue exists in table", "Available Balances calculationTable", "True", appHandle);
                else
                    Report.Fail("Column not exists in table", "Available Balances calculationTable", "True", appHandle);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used to check Alert Message exists in Table.
        /// </summary>
        /// <param name="sRefValue"></param>
        /// <param name="sTableName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckAlertMessageExistinTable(Date;10/11/2010;Description;Debit,tableXpath);
        /// </example>
        public virtual void CheckAlertMessageExistinTable(string sRefValue, string sTableName)
        {
            bool bCheck = false;
            try
            {
                bCheck = WebCSRPageFactory.WebCSRMasterPage.CheckMessageExistsInTable(sRefValue, sTableName);
                if (bCheck)
                {
                    Report.Pass("Alert message exists in table", "AlertMessage", "True", appHandle);
                }
                else
                {
                    Report.Fail("Alert message not found in table", "AlertMessage", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used for Navigate to the create account select package page..
        /// </summary>
        /// <returns></returns> 
        /// <example>
        ///Application.WebCSR.NavigatetoCreateAccountSelectPackagePage();
        /// </example>

        public virtual void NavigatetoCreateAccountSelectPackagePage(string customerNumber, string relationType)
        {
            try
            {
                GetCustomer(customerNumber);
                WebCSRPageFactory.VerifyCustomerPage.VerificationAction(Data.Get("GLOBAL_AccountCreate"));
                WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
                WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
                Application.WebCSR.SelectAccountRelationshipandOwners(relationType);
                WebCSRPageFactory.WebCSRMasterPage.Continue();
                bool blnConfirmedMsg = WebCSRPageFactory.CreateAccountPage.ConfirmPackagePage();
                if (blnConfirmedMsg)
                {
                    Report.Pass("Successfully navigated to select package page", "True", appHandle);
                }
                else
                {
                    Report.Fail("Not navigated to the packages page", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used to override or Cancel the Popup window in web CSR.
        /// </summary>
        /// <param bOverride=true/false></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.HandleAuthorizationPopupWindow(false);
        /// </example>
        public virtual void HandleAuthorizationPopupWindow(bool bOverride)
        {
            bool bCheck = false;
            try
            {
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.EnterAuthorizationDetails();
                if (bOverride)
                {
                    Report.Info("Click on override pop after entering valid credentials", "OverridePopUp", "True", appHandle);
                    WebCSRPageFactory.WebCSRMasterPage.ClickOnOverrideButton();
                    bCheck = WebCSRPageFactory.WebCSRMasterPage.IsAuthorizationWindowExists();
                    if (bCheck)
                    {
                        Report.Fail("Enter valid credintials", "AuthWindow", "True", appHandle);
                    }
                    else
                    {
                        Report.Pass("Authentication successfully verified", "AuthWindow", "True", appHandle);
                    }
                }
                else
                    WebCSRPageFactory.WebCSRMasterPage.ClickOnCancelButton();
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to reset and retrieve UserId and Password for webclient login.
        /// </summary>
        /// <param name="AccCustNumber"></param>
        /// <param name="AcctCustType"></param> 
        /// <returns>List<string> UserDetails</returns> 
        /// <example>
        /// Application.WebCSR.ResetAndRetrieveUserIdAndPasswordForWebclientLogin("459","Customer") - If you have custNumber.
        /// Application.WebCSR.ResetAndRetrieveUserIdAndPasswordForWebclientLogin("300000011164","Account") - If you have Account Number.
        /// </example>
        public virtual List<string> ResetAndRetrieveUserIdAndPasswordForWebclientLogin(string AccCustNumber, string AcctCustType)
        {
            string sWebClientUserID1 = null;
            string[] arrOnlineAccessSecurityDetails = null;
            List<string> UserDetails = new List<string>();
            bool bCheck = false;
            if (AcctCustType == "Customer")
            {
                Report.Info("Get Customer");
                GetCustomer(AccCustNumber);
                WebCSRPageFactory.AccountVerificationPage.VerificationAction(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
                WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
                Report.Info("Successfully fetched customer", "CustomerInfo", "True", appHandle);
            }
            else
            {
                Report.Info("Get Account");
                GetAccount(AccCustNumber);
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkinTab(BankingCenterPage.CustServicesLink, BankingCenterPage.CustServiceInformationLink);
                Report.Info("Successfully fetched account", "AccountInfo", "True", appHandle);
            }
            WebCSRPageFactory.WebCSRMasterPage.SelectTabInTable(WebCSRMasterPage.tblCustomerInformation, "Security");
            string sRandomValue = RandomNumberGenerator.Generate();
            sRandomValue = sRandomValue.Substring(0, sRandomValue.Length - 1);
            string sUserName = StartupConfiguration.EnvironmentDetails.UserFirstName;
            string sUserIDString = appHandle.SplitSideString(sUserName.ToUpper(), "LEFT", 4);
            string sUserID = sUserIDString + sRandomValue;
            string sAllowOnlineAccess = Data.Get("GLOBAL_PERSONAL_CUSTOMER_ALLOW_ONLINE_ACCESS");
            if (sAllowOnlineAccess.ToUpper().Equals("YES"))
            {
                WebCSRPageFactory.SecurityPage.SetRadioButtonAllowOnlineAccessYes();
                WebCSRPageFactory.SecurityPage.SetOnlineAccessUserId(sUserID);
                // To enter Online Access Details
                Report.Info("Enter Online Access Details");
                string[] arrOnlineAccessDetails = Data.Get("GLOBAL_ONLINEACCESS_DETAILS1");
                WebCSRPageFactory.SecurityPage.EnterOnlineAccessDetails(arrOnlineAccessDetails);

                // Get the Value in the User ID Field
                Report.Info("Enter UserId Details");
                sWebClientUserID1 = WebCSRPageFactory.SecurityPage.GetOnlineAccessUserId();
                Report.Info("UserId for webclient login is : " + sWebClientUserID1, "UserId", "True", appHandle);
                UserDetails.Add(sWebClientUserID1);
                string sOnlineAccessSecurityDetails = Data.Get("GLOBAL_ONLINESECURITY_DETAILS");
                arrOnlineAccessSecurityDetails = sOnlineAccessSecurityDetails.Split('_');
                UserDetails.Add(arrOnlineAccessSecurityDetails[0]);

                // To enter new password and confirm password details.
                Report.Info("Enter new password and confirm password details");
                WebCSRPageFactory.SecurityPage.EnterOnlineAccessSecurityDetails(arrOnlineAccessSecurityDetails);
                Report.Info("Password for webclient login is : " + arrOnlineAccessSecurityDetails[0], "Password", "True", appHandle);
            }
            else
            {
                WebCSRPageFactory.SecurityPage.SetRadioButtonAllowOnlineAccessNo();
            }
            // Enter Security Question details.
            Report.Info("Enter Security Question details");
            string[] arrSecurityQuestionDetails = Data.Get("GLOBAL_SECRETQUESTION_DETAILS1");
            WebCSRPageFactory.SecurityPage.EnterSecurityQuestionDetails(arrSecurityQuestionDetails);
            WebCSRPageFactory.WebCSRMasterPage.ClickOnSubmitButton();
            bCheck = WebCSRPageFactory.WebCSRMasterPage.CheckMessageExists(Data.Get("GLOBAL_INFORMATION_UPDATED"));
            if (bCheck)
            {
                Report.Pass("Successfully Reset and retrieved password for webclient login", "SecurityInformation", "True", appHandle);
            }
            else
            {
                Report.Fail("Failed to reset and retrieve password for webclient login", "SecurityInformation", "True", appHandle);
            }
            return UserDetails;
        }


        /// <summary>
        /// This function is used to update the marital status of the customer while creating retirement account in WebCSR application.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        ///Application.WebCSR.UpdatetheMaritalStatusofCustomer();
        /// </example>

        public virtual void UpdatetheMaritalStatusofCustomer(string customerNumber, string[] RetirementDetails, string mStatus)
        {

            if (RetirementDetails[5].Length > 0)
            {
                try
                {
                    GetCustomer(customerNumber);
                    WebCSRPageFactory.VerifyCustomerPage.VerificationAction(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
                    WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
                    WebCSRPageFactory.CustomerInformationPage.UpdateMaritalStatus(mStatus);
                    WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
                    bool blnConfirmedMsg = WebCSRPageFactory.CustomerInformationPage.VerifyCustomerInformationUpdateMsg();
                    if (blnConfirmedMsg)
                        Report.Pass("Marital Status of customer is updated.", "True", appHandle);
                    else
                        Report.Fail("Marital Status is not updated", "True", appHandle);
                }
                catch (Exception e)
                {
                    Report.Info("Exception logged : " + e);
                }
            }

        }


        ///  </summary>
        ///  This function is used to check default value present in  the specified product  dropdown in webcsr application.
        /// </summary>
        /// <returns></returns> 
        /// <example>
        /// Example: CheckDefaultValueExistsforSpecicifiedProductinWebCSR("DEP PPROD 123", "2");
        /// </example>

        public virtual bool CheckDefaultValueExistsforSpecicifiedProductinWebCSR(string productname, string DefaultValue)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            bool blnSelectAccountsMsg = WebCSRPageFactory.CreateAccountPage.ConfirmSelectAccountsPage();

            if (blnSelectAccountsMsg)
                Report.Pass("Product selection page is there", "True", appHandle);
            else
                Report.Fail("Product selection page is not there.", "True", appHandle);

            string DefValue = "XPath;//*[text()='" + productname + "']/preceding::select[1]";
            string sActualDefaultValue = appHandle.GetElementValue(DefValue).Trim();

            if (DefaultValue.Trim() == sActualDefaultValue.Trim())
            {
                return true;
            }

            else
            {
                return false;
            }

        }

        /// <summary>
        /// This method is used to check most popular label exists for the specified package.
        /// </summary>
        /// <param name="PackageName"></param>
        /// <returns>true/false</returns> 
        /// <example>
        /// Application.WebCSR.CheckMostPopularLabelExistsForSpecifiedPackage("packYE1244962");
        /// </example>
        public virtual bool CheckMostPopularLabelExistsForSpecifiedPackage(string PackageName)
        {
            bool bCheck = false;
            try
            {
                bCheck = WebCSRPageFactory.SelectPackagePage.CheckMostPopularLabelExists(PackageName);
                if (bCheck)
                {
                    Report.Pass("Most poular label exists for the specified package", "MostPopularLabel", "True", appHandle);
                }
                else
                {
                    Report.Fail("Most poular label not found for the specified package", "MostPopularLabel", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;
        }
        /// <summary>
        /// This method is used to check product exists for the specified package.
        /// </summary>
        /// <param name="PackageName"></param>
        /// <param name="ProductName"></param>
        /// <returns>true/false</returns> 
        /// <example>
        /// Application.WebCSR.CheckProductExistsUnderSpecifiedPackage("packYE1244962","SAV8991");
        /// </example>
        public virtual bool CheckProductExistsUnderSpecifiedPackage(string PackageName, string ProductName)
        {
            bool bCheck = false;
            try
            {
                bCheck = WebCSRPageFactory.SelectPackagePage.CheckProductExistsUnderSpecifiedPackage(PackageName, ProductName);
                if (bCheck)
                {
                    Report.Pass("Product exists under specified package", "Product", "True", appHandle);
                }
                else
                {
                    Report.Fail("Product not found under specified package", "Product", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return bCheck;
        }

        /// <summary>
        /// To select Number of Account for specified product in CreateAccountSelectAccountsPage.
        /// <param name= "product Desc"></param> 
        /// <param name= "noofaccounts"></param> 
        /// <returns></returns>
        /// <example>SelectAccountsforProductinSelectAccountPage("SAV1421","2")</example>
        public virtual void SelectAccountsforProductinSelectAccountPage(string sProductDesc, string sNoofaccounts)
        {
            try
            {
                bool bcheck = WebCSRPageFactory.CreateAccounSelectAccountsPage.SelectAccountsinWebCSR(sProductDesc, sNoofaccounts);
                if (bcheck)
                    Report.Info("Specified Number of Accounts Selected.", "AP", "True", appHandle);
                else
                    Report.Fail("Product Description does not match, Please check.", "AP", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        ///  This function is used to navigate to relationship page while creating aacount for new customer in WebCSR.
        /// </summary>
        /// <param name= "First Name"></param> 
        /// <param name= "Last name"></param> 
        /// <param name= "Email"></param> 
        /// <returns></returns> 
        /// <example>
        ///Application.WebCSR.NavigatetoCreateAccountwiltNewCustWebCSRRelationshipPage(FirstName, LastName, Email);
        /// </example>

        public virtual void NavigatetoCreateAccountwiltNewCustWebCSRRelationshipPage(string sFName, string sLName, string sEmail)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                WebCSRPageFactory.CustomerSearchPage.ClickOnCreateAccountLink();
                WebCSRPageFactory.CreateAccountPage.EnterDetailsforNewCustomerInfo(sFName, sLName, sEmail);
                WebCSRPageFactory.WebCSRMasterPage.ClickOnSubmitButton();
                bool blnConfirmedMsg = WebCSRPageFactory.CreateAccountRelationshipPage.RelationshipPageConfirmation();

                if (blnConfirmedMsg)
                    Report.Pass("Navigated to Relationship Page with New customer", "True", appHandle);
                else
                    Report.Fail("Not Navigated to Rrelation ship page", "True", appHandle);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        ///  </summary>
        ///  This function is used to check EXPECTED  value present in  the specified product  dropdown.
        /// </summary>
        /// <param name= "Application Name"></param> 
        /// <param name= "Product Name"></param> 
        /// <param name= "Expected value"></param> 
        /// <returns></returns> 
        /// <example>
        /// Example: CheckValueExistsforSpecifiedProduct("WebCSR", "DEP PPROD 1234", "2");
        /// Example: CheckValueExistsforSpecifiedProduct("WebCSR", "DEP PPROD 456", "3");
        /// </example>

        public virtual bool CheckValueExistsforSpecifiedProduct(string ApplicationName, string productname, string ExpectedValue)
        {

            bool bcheck1 = false;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                bool blnSelectAccountsMsg = WebCSRPageFactory.CreateAccountPage.ConfirmSelectAccountsPage();
                bcheck1 = WebCSRPageFactory.CreateAccounSelectAccountsPage.CheckExpectedValueinDropdown(productname, ExpectedValue);
                if (bcheck1)
                {
                    Report.Pass("Expected value is there in Dropdown.", "True", appHandle);
                }
                else
                {
                    Report.Fail("Expected value is not there in Dropdown", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
            return bcheck1;
        }

        ///  </summary>
        ///  This function is used to select the multiple customers in create account page.
        /// </summary>
        /// <param name= "Customer Number"></param> 
        /// <returns></returns> 
        /// <example>
        /// Example: SelectMultipleCustomersinCreateAccountPage("112;113;114");
        /// </example>
        public virtual void SelectMultipleCustomersinCreateAccountPage(string CustomerNumbers)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                string[] arr = CustomerNumbers.Split(';');
                if (arr.Length > 1)
                {
                    for (int i = 1; i < arr.Length; i++)
                    {
                        WebCSRPageFactory.CreateAccountPage.SelectButtonbyIndexinCreateAccountCustomerSearchPage("Search", i);
                        WebCSRPageFactory.CustomerSearchPage.selectCustomerNumberradiobutton();
                        WebCSRPageFactory.CustomerSearchPage.EnterSearchForField(arr[i]);
                        WebCSRPageFactory.CustomerSearchPage.ClickonSearchbuttonforInnerpage();
                        WebCSRPageFactory.WebCSRMasterPage.selectbuttonforcustomerfound();
                    }
                    Report.Info("Customer Details.", "CACS", "True", appHandle);
                }
            }
            catch (Exception e) { Report.Info("Exception logged :" + e); }
        }

        /// <summary>
        /// Navigate to the Create Retirement Account Information page
        /// </summary>
        /// <param name = sCustomerNumber./>
        /// <param name = ProductType./>
        /// <param name = sRetirementPlanName/>
        /// <param name = "RetirementDetails"/>
        /// <param name = "DeathBeneficiariesDetails"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.NavigatetoCreateRetirementAccountInformationPage();
        /// </example>
        public virtual void NavigatetoCreateRetirementAccountInformationPage(string producttype, string sCustomerNumber, string sRetirementPlanName, string[] RetirementDetails, string[] DeathBeneficiariesDetails, string noofaccounts)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                GetCustomer(sCustomerNumber);
                WebCSRPageFactory.VerifyCustomerPage.SelectCreateRetirementPlanFromDropdown();
                WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
                WebCSRPageFactory.CreateRetirementPlanPage.SelectRetirementPlan(sRetirementPlanName);
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                WebCSRPageFactory.CreateRetirementPlanPage.EnterPlanDetails(RetirementDetails);
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                WebCSRPageFactory.AddDeathBeneficiariesPage.EnterDeathBeneficiariesDetails(DeathBeneficiariesDetails);
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
                WebCSRPageFactory.CreateRetirementAccountSelectAccountsPage.SelectProductinRetirementSelectAccountsPage(producttype, noofaccounts);
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                bool bCheck = WebCSRPageFactory.CreateRetirementAccountInformationPage.ConfirmRetirementAccountInformationPage();
                if (bCheck == true)
                    Report.Pass("Successfully navigate to Retirement Account Information page", "appHandle", "True");
                else
                    Report.Fail("Not navigated to Retirement Account Information page", "appHandle", "True");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// Verify the product is there or not in Product selection page while creating retirement account.
        /// </summary>
        /// <param name = Productname./>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.VerifyProductinRetirementSelectAccountsPage();
        /// </example>
        public virtual void VerifyProductinRetirementSelectAccountsPage(string ProductDesc)
        {
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                bool bCheck = WebCSRPageFactory.CreateRetirementAccountSelectAccountsPage.ConfirmProductinRetirementSelectAccountsPage(ProductDesc);
                if (bCheck == true)
                    Report.Pass("Specified product is there in product selection page", "appHandle", "True");
                else
                    Report.Fail("Specified product is not there in product selection page", "appHandle", "True");
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used to check specified data exists in PostedTransaction Table.
        /// </summary>
        /// <param name="sRefValue"></param>
        /// <returns>true/false</returns> 
        /// <example>
        /// Application.WebCSR.CheckSpecifiedDataExistsinPostedTransactionTable(Date;10/11/2010;Description;Debit);
        /// </example>
        public virtual void CheckSpecifiedDataExistsinPostedTransactionTable(string sRefValue, bool NavgtoPostDateTbl = true)
        {
            bool bCheck = false;
            try
            {
                if (NavgtoPostDateTbl)
                    WebCSRPageFactory.DepositAccountOverviewPage.NavigateToPostedTransactionDateTable();
                bCheck = WebCSRPageFactory.DepositAccountOverviewPage.CheckDataExistsInPostedTransactionTable(sRefValue);
                if (bCheck)
                {
                    Report.Pass("Specified data exists in table", "AlertMessage", "True", appHandle);
                }
                else
                {
                    Report.Fail("Specified data not found in table", "AlertMessage", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        public virtual string GetValueFromCustomerInformation(string sFieldName, string sFieldType)
        {
            string Value = "";
            try
            {
                Value = WebCSRPageFactory.CustomerInformationPage.GetEditValue(sFieldName, sFieldType);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return Value;
        }

        public virtual void SelectTabInCustomerInformationGeneralPage(string sTabName)
        {
            try
            {
                WebCSRPageFactory.CustomerInformationPage.SelectTab(sTabName);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// Navigate to the Select Package Page.
        /// <param name = CustomerNumber./>
        /// <param name = sRelationType./>
        /// <returns>bool</returns> 
        /// <example>Application.WebCSR.NavigatetoSelectPackagePageinWebcsr("123;456;876","Joint;2");</example>
        public virtual bool NavigatetoSelectPackagePageinWebcsr(string CustomerNumber, string sRelationType)
        {
            bool bCheck = false;
            try
            {
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                string[] arr = CustomerNumber.Split(';');
                GetCustomer(arr[0]);
                //Select value from verification Action dropdown
                WebCSRPageFactory.VerifyCustomerPage.VerificationAction(Data.Get("GLOBAL_AccountCreate"));
                WebCSRPageFactory.WebCSRMasterPage.CustomerSubmit();
                WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
                // To select Account Relationship and click on Continue button.
                SelectAccountRelationshipandOwners(sRelationType);
                WebCSRPageFactory.WebCSRMasterPage.Continue();
                SelectMultipleCustomersinCreateAccountPage(CustomerNumber);
                WebCSRPageFactory.WebCSRMasterPage.Continue();
                bool bcheck = WebCSRPageFactory.WebCSRMasterPage.CheckMessageExists("Choose the package to establish.");
                if (bcheck)
                    Report.Info("Navigated to Select Package Page.", "SP", "True", appHandle);
                else
                    Report.Fail("Navigation to Select Package Page failed.", "SP", "True", appHandle);
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            return bCheck;
        }

        /// <summary>
        /// To select specified Package and Number of Account for package products.
        /// <param name= "Package Name"></param> 
        /// <param name= "lstProductswithNoofAcc"></param>
        /// lstProductswithNoofAcc.Add("Savings;2");'--> ("sProductDesc;sNoofaccounts")
        /// lstProductswithNoofAcc.Add("CD Product 2608;2");
        /// <returns>bool</returns>
        /// <example>SelectPackageinWebCSR("Dep packYF6711210",lstProductswithNoofAcc)</example>
        public virtual bool SelectPackageinWebCSR(string sPackage, List<string> lstProductswithNoofAcc)
        {
            bool bCheck = false;
            try
            {
                if (WebCSRPageFactory.SelectPackagePage.SelectSpecifiedPackage(sPackage))
                {
                    WebCSRPageFactory.WebCSRMasterPage.ClickOnContinueButton();
                    for (int i = 0; i < lstProductswithNoofAcc.Count; i++)
                    {
                        string[] arrDetails = lstProductswithNoofAcc[i].Split(';');
                        WebCSRPageFactory.SelectPackagePage.SelectSpecifiedProductinPackage(arrDetails[0]);
                        WebCSRPageFactory.SelectPackagePage.SelectNoOfAccforProductinPackage(arrDetails[0], arrDetails[1]);
                    }
                    bCheck = true;
                    Report.Info("Specified Package and its product are selected.");
                }
                else
                    Report.Fail("Specified Package does not exist, please check.", "Pack", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return bCheck;
        }

        /// <summary>
        /// To enter values in multiple deposit product type in same page
        /// <param name="List<string> lstProducts"></param>
        /// lstProducts.Add("SAV1169;2");
        /// lstProducts.Add("CD Product 2608;2");
        /// <param name="string[] ArrAccDeatails"></param>
        ///  ArrAccDeatails[0] = "Deposite Account1;Deposite Account2;CD1;CD2" --> Account Names for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[1]= "01/16/2015;01/16/2015;01/16/2015;01/16/2015" --> Account Opening date should pass as same order as in product Desc list.
        ///  ArrAccDeatails[2]= "1000;2000;3000;3500" --> Amount for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[3]= "USD - United States Dollars;;USD - United States Dollars;3500" --> Currency Code hould pass as same order as in product Desc list.
        ///  ArrAccDeatails[4] =";;;" --> Account Purpose should pass as same order as in product Desc list.
        ///  ArrAccDeatails[5] =";;;" --> Funding Deposit Account should pass as same order as in product Desc list.
        /// <returns></returns>
        /// <example>EnterDatainMultipleDepositAccounts(ArrAccDeatails,lstProducts)</example>
        public virtual void EnterDatainMultipleDepositAccounts(string[] ArrAccDeatails, List<string> lstProducts)
        {
            try
            {

                int NoofAcc = 0;
                for (int a = 0; a < lstProducts.Count; a++)
                {
                    string[] arrDetails = new string[3];
                    arrDetails = lstProducts[a].Split(';');
                    NoofAcc = NoofAcc + (Int32.Parse(arrDetails[1]));
                }

                string[] arr1 = new string[NoofAcc];
                string[] Prodcudes1 = ArrAccDeatails[0].Split(';');
                string[] Prodcudes2 = ArrAccDeatails[1].Split(';');
                string[] Prodcudes3 = ArrAccDeatails[2].Split(';');
                string[] Prodcudes4 = ArrAccDeatails[3].Split(';');
                string[] Prodcudes5 = ArrAccDeatails[4].Split(';');
                string[] Prodcudes6 = ArrAccDeatails[5].Split(';');

                for (int i = 0; i < NoofAcc; i++)
                {
                    arr1[i] = Prodcudes1[i] + ";" + Prodcudes2[i] + ";" + Prodcudes3[i] + ";" + Prodcudes4[i] + ";" + Prodcudes5[i] + ";" + Prodcudes6[i];
                }
                int t = 0;
                string[] ArrFieldNames = Data.Get("GLOBAL_WEBCSR_DEPOISTACCOUNT_INFORMATION_FIELD_NAMES");
                for (int j = 0; j < lstProducts.Count; j++)
                {
                    string[] arrDetails = new string[3];
                    arrDetails = lstProducts[j].Split(';');

                    for (int k = 1; k <= Int32.Parse(arrDetails[1]); k++)
                    {
                        string[] ArrFieldValues = arr1[t].Split(';');
                        for (int m = 0; m < ArrFieldNames.Length; m++)
                        {
                            string[] ArrFldNames = ArrFieldNames[m].Split('|');

                            if (ArrFieldValues[m] != "" && ArrFieldValues[m] != null)
                            {
                                if (ArrFldNames[1].ToUpper() == "FIELD")
                                {
                                    string obj = WebCSRPageFactory.CreateDepositAccountInformationPage.GenerateXpathforDepositAccFields(arrDetails[0], ArrFldNames[0], "input", k);
                                    WebCSRPageFactory.CreateDepositAccountInformationPage.SetEditValueforDepositAccFields(obj, ArrFieldValues[m]);
                                }
                                if (ArrFldNames[1].ToUpper() == "DROPDOWN")
                                {
                                    string obj1 = WebCSRPageFactory.CreateDepositAccountInformationPage.GenerateXpathforDepositAccFields(arrDetails[0], ArrFldNames[0], "select", k);
                                    WebCSRPageFactory.CreateDepositAccountInformationPage.SelectDropdownValueforDepositAccFields(obj1, ArrFieldValues[m]);
                                }
                            }
                        }
                        t++;
                    }
                }
                Report.Info("Account details Entered.", "SP", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// To enter values in multiple Loan product type in same page
        /// <param name="List<string> lstProducts"></param>
        /// lstProducts.Add("RC;2");
        /// lstProducts.Add("MTG;2");
        /// <param name="string[] ArrAccDeatails"></param>
        ///  ArrAccDeatails[0] = "Ln Account1;Ln Account2;Mtg1;Mtg2" --> Account Names for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[1]= "1000;2000;3000;3500" --> Amount for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[2]= "1Y;2Y;3Y;3Y" --> Term for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[3]= "USD - United States Dollars;;USD - United States Dollars;3500" --> Currency Code hould pass as same order as in product Desc list.
        ///  ArrAccDeatails[4]= "01/16/2015;01/16/2015;01/16/2015;01/16/2015" --> Disbursement Date should pass as same order as in product Desc list.
        ///  ArrAccDeatails[5]= "01/16/2015;01/16/2015;01/16/2015;01/16/2015" --> Loan Origination Date should pass as same order as in product Desc list.
        ///  ArrAccDeatails[6] =";;;" --> Account Purpose should pass as same order as in product Desc list.
        ///  ArrAccDeatails[7] ="1MAE;1MAE;1MAE;" --> Payment Frequency should pass as same order as in product Desc list.
        ///  ArrAccDeatails[8] =";;;" --> Internal Source Account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[9] ="0 - Unsecured;0 - Unsecured;0 - Unsecured;0 - Unsecured" --> Collateral Type should pass as same order as in product Desc list.
        ///  ArrAccDeatails[10] =";;;" --> Commitment Link should pass as same order as in product Desc list.
        ///  ArrAccDeatails[11] ="on;off;on;off" --> Revolving Credit should pass as same order as in product Desc list.
        /// <returns></returns>
        /// <example>EnterDatainMultipleLoanAccounts(ArrAccDeatails,lstProducts)</example>
        public virtual void EnterDatainMultipleLoanAccounts(string[] ArrAccDeatails, List<string> lstProducts)
        {
            try
            {

                int NoofAcc = 0;
                for (int a = 0; a < lstProducts.Count; a++)
                {
                    string[] arrDetails = new string[3];
                    arrDetails = lstProducts[a].Split(';');
                    NoofAcc = NoofAcc + (Int32.Parse(arrDetails[1]));
                }

                string[] arr1 = new string[NoofAcc];
                string[] Prodcudes1 = ArrAccDeatails[0].Split(';');
                string[] Prodcudes2 = ArrAccDeatails[1].Split(';');
                string[] Prodcudes3 = ArrAccDeatails[2].Split(';');
                string[] Prodcudes4 = ArrAccDeatails[3].Split(';');
                string[] Prodcudes5 = ArrAccDeatails[4].Split(';');
                string[] Prodcudes6 = ArrAccDeatails[5].Split(';');
                string[] Prodcudes7 = ArrAccDeatails[6].Split(';');
                string[] Prodcudes8 = ArrAccDeatails[7].Split(';');
                string[] Prodcudes9 = ArrAccDeatails[8].Split(';');
                string[] Prodcudes10 = ArrAccDeatails[9].Split(';');
                string[] Prodcudes11 = ArrAccDeatails[10].Split(';');
                string[] Prodcudes12 = ArrAccDeatails[11].Split(';');

                for (int i = 0; i < NoofAcc; i++)
                {
                    arr1[i] = Prodcudes1[i] + ";" + Prodcudes2[i] + ";" + Prodcudes3[i] + ";" + Prodcudes4[i] + ";" + Prodcudes5[i] + ";" + Prodcudes6[i] + ";" + Prodcudes7[i] + ";" + Prodcudes8[i] + ";" + Prodcudes9[i] + ";" + Prodcudes10[i] + ";" + Prodcudes11[i] + ";" + Prodcudes12[i];
                }
                int t = 0;
                string[] ArrFieldNames = Data.Get("GLOBAL_WEBCSR_LOANACCOUNT_INFORMATION_FIELD_NAMES");
                for (int j = 0; j < lstProducts.Count; j++)
                {
                    string[] arrDetails = new string[3];
                    arrDetails = lstProducts[j].Split(';');

                    for (int k = 1; k <= Int32.Parse(arrDetails[1]); k++)
                    {
                        string[] ArrFieldValues = arr1[t].Split(';');
                        for (int m = 0; m < ArrFieldNames.Length; m++)
                        {
                            string[] ArrFldNames = ArrFieldNames[m].Split('|');

                            if (ArrFieldValues[m] != "" && ArrFieldValues[m] != null)
                            {
                                if (ArrFldNames[1].ToUpper() == "FIELD")
                                {
                                    string obj = WebCSRPageFactory.CreateLoanAccountInformationPage.GenerateXpathforLoanAccFields(arrDetails[0], ArrFldNames[0], "input", k);
                                    WebCSRPageFactory.CreateLoanAccountInformationPage.SetEditValueforLoanAccFields(obj, ArrFieldValues[m]);
                                }
                                if (ArrFldNames[1].ToUpper() == "DROPDOWN")
                                {
                                    string obj1 = WebCSRPageFactory.CreateLoanAccountInformationPage.GenerateXpathforLoanAccFields(arrDetails[0], ArrFldNames[0], "select", k);
                                    WebCSRPageFactory.CreateLoanAccountInformationPage.SelectDropdownValueforLoanAccFields(obj1, ArrFieldValues[m]);
                                }
                                if (ArrFldNames[1].ToUpper() == "CHECKBOX")
                                {
                                    string obj = WebCSRPageFactory.CreateLoanAccountInformationPage.GenerateXpathforLoanAccFields(arrDetails[0], ArrFldNames[0], "input", k);
                                    WebCSRPageFactory.CreateLoanAccountInformationPage.SelectCheckboxforLoanAccFields(obj, ArrFieldValues[m]);
                                }
                            }
                        }
                        t++;
                    }
                }
                Report.Info("Account details Entered.", "SP", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used to create a new deposit and Loan account with Single/ Joint owner relationship for Existing customers with package using WebCSR.
        /// <param name = CustomerNumber./>
        /// <param name = sRelationType./>
        /// <param name= "Package Name"></param> 
        /// <param name= "lstProductswithNoofAcc"></param>
        /// lstProductswithNoofAcc.Add("Savings;2");'--> ("sProductDesc;sNoofaccounts")
        /// lstProductswithNoofAcc.Add("CD Product 2608;2");
        /// <param name= "AccountRelationship"></param>
        /// <param name= "[] ArrAccDeatails"></param> 
        /// below for deposit account
        /// <param name="string[] ArrAccDeatails"></param>
        ///  ArrAccDeatails[0] = "Deposite Account1;Deposite Account2;CD1;CD2" --> Account Names for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[1]= "01/16/2015;01/16/2015;01/16/2015;01/16/2015" --> Account Opening date should pass as same order as in product Desc list.
        ///  ArrAccDeatails[2]= "1000;2000;3000;3500" --> Amount for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[3]= "USD - United States Dollars;;USD - United States Dollars;3500" --> Currency Code hould pass as same order as in product Desc list.
        ///  ArrAccDeatails[4] =";;;" --> Account Purpose should pass as same order as in product Desc list.
        ///  ArrAccDeatails[5] =";;;" --> Funding Deposit Account should pass as same order as in product Desc list.
        /// below for Loan Account
        /// <param name="string[] ArrAccDeatails"></param>
        ///  ArrAccDeatails[0] = "Ln Account1;Ln Account2;Mtg1;Mtg2" --> Account Names for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[1]= "1000;2000;3000;3500" --> Amount for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[2]= "1Y;2Y;3Y;3Y" --> Term for mutiple account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[3]= "USD - United States Dollars;;USD - United States Dollars;3500" --> Currency Code hould pass as same order as in product Desc list.
        ///  ArrAccDeatails[4]= "01/16/2015;01/16/2015;01/16/2015;01/16/2015" --> Disbursement Date should pass as same order as in product Desc list.
        ///  ArrAccDeatails[5]= "01/16/2015;01/16/2015;01/16/2015;01/16/2015" --> Loan Origination Date should pass as same order as in product Desc list.
        ///  ArrAccDeatails[6] =";;;" --> Account Purpose should pass as same order as in product Desc list.
        ///  ArrAccDeatails[7] ="1MAE;1MAE;1MAE;" --> Payment Frequency should pass as same order as in product Desc list.
        ///  ArrAccDeatails[8] =";;;" --> Internal Source Account should pass as same order as in product Desc list.
        ///  ArrAccDeatails[9] ="0 - Unsecured;0 - Unsecured;0 - Unsecured;0 - Unsecured" --> Collateral Type should pass as same order as in product Desc list.
        ///  ArrAccDeatails[10] =";;;" --> Commitment Link should pass as same order as in product Desc list.
        ///  ArrAccDeatails[11] ="on;off;on;off" --> Revolving Credit should pass as same order as in product Desc list.
        /// <returns>List of Account Numbers</returns>
        /// <example>string[] av14 = Application.WebClient.CreateAccountinWebclient("12;23;45","Joint (Or);3","Dep packYF6711210",lstProductswithNoofAcc,Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"), ArrAccDeatails);</example>
        /// <example>string[] av1 = Application.WebClient.CreateAccountinWebclient("12","Single","Dep packYF6711210",lstProductswithNoofAcc,Data.Get("GLOBAL_DEPOSIT_ACCOUNTCLASS"), ArrAccDeatails);</example>
        /// <example>string[] av4 = Application.WebClient.CreateAccountinWebclient("12","Individual Primary Borrower","Dep packYF6711210",lstProductswithNoofAcc,Data.Get("GLOBAL_LOAN_ACCOUNTCLASS"), ArrAccDeatails);</example>
        public virtual List<string> CreateAccountWithPackageinWebCSR(string sCustomerNumber, string sRelationType, string sPackage, List<string> lstProductswithNoofAcc, string AccountType, string[] ArrAccDeatails)
        {
            List<string> AccNumbers = null;
            try
            {
                if (NavigatetoSelectPackagePageinWebcsr(sCustomerNumber, sRelationType))
                {
                    if (SelectPackageinWebCSR(sPackage, lstProductswithNoofAcc))
                    {
                        WebCSRPageFactory.WebCSRMasterPage.ClickOnContinueButton();
                        if (AccountType.ToUpper() == "DEPOSIT")
                            EnterDatainMultipleDepositAccounts(ArrAccDeatails, lstProductswithNoofAcc);
                        else
                            EnterDatainMultipleLoanAccounts(ArrAccDeatails, lstProductswithNoofAcc);
                        WebCSRPageFactory.WebCSRMasterPage.ClickOnSubmitButton();
                        if (appHandle.IsObjectExists(WebCSRMasterPage.btnContinue))
                            WebCSRPageFactory.WebCSRMasterPage.ClickOnContinueButton();
                        WebCSRPageFactory.WebCSRMasterPage.ClickOnSubmitButton();
                        if (WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_CONFIRMATION_MESSAGE")))
                        {
                            AccNumbers = WebCSRPageFactory.CustomerAccountsCreatedPage.GetAccountNumbersbyIndexforDiffProds(lstProductswithNoofAcc);
                            Report.Pass("Accounts created successfully.", "CA", "True", appHandle);
                        }
                        else
                            Report.Fail("Accounts creation failed.", "CA", "True", appHandle);
                    }
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return AccNumbers;
        }

        /// <summary>
        /// This method is used to Calculate Annual Percentage Yield.
        /// </summary>
        /// <param name="IRN"></param>
        /// <param name="CompoundingFrequency"></param>
        /// <returns>Longvalue</returns> 
        /// <example>
        /// Application.WebCSR.CalculateAnnualPercentageYield(.08,"1DA");
        /// Application.WebCSR.CalculateAnnualPercentageYield(0.08,"Custom;24");
        /// </example>
        public virtual double CalculateAnnualPercentageYield(double IRN, string CompoundingFrequency)
        {
            string[] CompoundingFrequencyArry = CompoundingFrequency.Split(';');
            int CompoundingFrequencyValue = 0;
            if (CompoundingFrequencyArry.Length > 1)
            {
                CompoundingFrequency = CompoundingFrequencyArry[0];
                CompoundingFrequencyValue = int.Parse(CompoundingFrequencyArry[1]);
            }
            double CF = 0;
            switch (CompoundingFrequency)
            {
                case "1DA":
                    string sysdate = WebCSRPageFactory.WebCSRMasterPage.GetApplicationDate();
                    string[] arr1 = sysdate.Split('/');
                    int days = appHandle.GetTotalNoOfDaysInYear(int.Parse(arr1[2]));
                    CF = days;
                    break;
                case "1WA":
                    CF = 52;
                    break;
                case "1MAE":
                    CF = 12;
                    break;
                case "1QAE":
                    CF = 4;
                    break;
                case "1YAE":
                    CF = 1;
                    break;
                case "2YAE":
                    CF = 2;
                    break;
                case "CUSTOM":
                    CF = CompoundingFrequencyValue;
                    break;
                default:
                    Report.Fail("Wrong parameters passed");
                    break;
            }
            double AnnualYield = (1 + IRN / CF);
            AnnualYield = (Math.Pow(AnnualYield, CF) - 1) * 100;
            AnnualYield = Math.Round(AnnualYield, 2);
            return AnnualYield;
        }

        /// <summary>
        /// This method is used to click Tab in Deposit Account Overview Page.
        /// </summary>
        /// <param name="sTabName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.ClickTabInDepositAccountOverviewPage(Account Summary);
        /// Application.WebCSR.ClickTabInDepositAccountOverviewPage(Account History);
        /// </example>
        public virtual void ClickTabInDepositAccountOverviewPage(string sTabName)
        {
            try
            {
                switch (sTabName)
                {
                    case "Account Summary":
                        WebCSRPageFactory.WebCSRMasterPage.ClickObject(DepositAccountOverviewPage.tabAccountSummary);
                        break;
                    case "Account History":
                        WebCSRPageFactory.WebCSRMasterPage.ClickObject(DepositAccountOverviewPage.tabAccountHistory);
                        break;
                    case "Stops":
                        WebCSRPageFactory.WebCSRMasterPage.ClickObject(DepositAccountOverviewPage.tabStops);
                        break;
                    case "Account Notes":
                        WebCSRPageFactory.WebCSRMasterPage.ClickObject(DepositAccountOverviewPage.tabAccountNotes);
                        break;
                    case "Cards":
                        WebCSRPageFactory.WebCSRMasterPage.ClickObject(DepositAccountOverviewPage.tabCards);
                        break;
                    case "Interest Pool":
                        WebCSRPageFactory.WebCSRMasterPage.ClickObject(DepositAccountOverviewPage.tabInterestPool);
                        break;
                    case "Collection Records":
                        WebCSRPageFactory.WebCSRMasterPage.ClickObject(DepositAccountOverviewPage.tabCollectionRecords);
                        break;
                    case "Payment Summary":
                        WebCSRPageFactory.WebCSRMasterPage.ClickObject(LoanAccountOverviewPage.tabPaymentSummary);
                        break;
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used to click Tab in Account Information Page.
        /// </summary>
        /// <param name="sTabName"></param>
        /// <param name="sLinkName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.ClickTabInAccountInformationPage("Interest", AccountInformationPage.lnkRateDetermination);
        /// Application.WebCSR.ClickTabInDepositAccountOverviewPage("Term Acounts", AccountInformationPage.lnkPenalty);
        /// </example>
        public virtual void ClickTabInAccountInformationPage(string sTabName, string sLinkName = null)
        {
            string xpath = null;
            try
            {
                xpath = WebCSRPageFactory.WebCSRMasterPage.GetTabXpath(sTabName);
                WebCSRPageFactory.WebCSRMasterPage.ClickObject(xpath);
                if (sLinkName != null)
                {
                    WebCSRPageFactory.WebCSRMasterPage.SelectLink(sLinkName);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to enter values in specified page.
        /// </summary>
        /// <param name=List<string> Values></param>
        /// Each string in list should contain Xpath|fieldtype|value
        /// values.Add(AccountInformationPage.txtMaturityInformationAccountTerm + "|field|" + MaturityTerm);
        /// values.Add(AccountInformationPage.drpRenewalInformationPrincipalMaturityOption + "|dropdown|" + PrincipalMaturityOption);
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.EnterValuesInWebCSRSpecifiedPage(values);
        /// </example>
        public virtual void EnterValuesInWebCSRSpecifiedPage(List<string> Values)
        {

            try
            {
                foreach (string value in Values)
                {
                    string[] temp = value.Split('|');

                    switch (temp[1].ToUpper())
                    {
                        case "FIELD":
                            WebCSRPageFactory.WebCSRMasterPage.SetFieldValue(temp[0], temp[2]);
                            break;
                        case "DROPDOWN":
                            WebCSRPageFactory.WebCSRMasterPage.SelectDropdownValue(temp[0], temp[2]);
                            break;
                        case "CHECKBOX":
                            WebCSRPageFactory.WebCSRMasterPage.SelectCheckBox(temp[0], temp[2]);
                            break;
                        case "RADIOBUTTON":
                            WebCSRPageFactory.WebCSRMasterPage.SetRadioButton(temp[0]);
                            break;
                    }
                }
            }

            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to enter values in specified page and verify the expected msg.
        /// </summary>
        /// <param name=List<string> Values></param>
        /// Each string in list should contain Xpath|fieldtype|value
        /// values.Add(AccountInformationPage.txtMaturityInformationAccountTerm + "|field|" + MaturityTerm);
        /// values.Add(AccountInformationPage.drpRenewalInformationPrincipalMaturityOption + "|dropdown|" + PrincipalMaturityOption);
        /// <param name="sExpectedMsg"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.UpdateInformationInWebCSRSpecifiedPage(values,"The infoemation has been updated".);
        /// </example>
        public virtual void UpdateInformationInWebCSRSpecifiedPage(List<string> FieldValues, string sExpectedMsg)
        {
            try
            {
                EnterValuesInWebCSRSpecifiedPage(FieldValues);
                WebCSRPageFactory.WebCSRMasterPage.ClickOnSubmitButton();
                bool bcheck = WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(sExpectedMsg);
                if (bcheck)
                    Report.Pass("Successfully updated the information", "UpdateInformation", "True", appHandle);
                else
                    Report.Fail("Failed to update the information", "UpdateInformation", "True", appHandle);

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to get value from the specified label name.
        /// </summary>
        /// <param name="sLabelName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.GetCellValueByLabel("Annual Yield:");
        /// Application.WebCSR.GetCellValueByLabel("Rate at Last Maturity:");
        /// </example>
        public virtual string GetCellValueByLabel(string sLabelName)
        {
            string LabelValue = null;
            try
            {
                string objXpath = WebCSRPageFactory.WebCSRMasterPage.GenerateXpathForLabel(sLabelName);
                LabelValue = WebCSRPageFactory.WebCSRMasterPage.GetTextBasedOnLabel(objXpath);
                if (LabelValue != null)
                    Report.Info("Successfully fetched the label value", "labelvalue", "False", appHandle);
                else
                    Report.Fail("Failed to fetch the label value", "labelvalue", "True", appHandle);


            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return LabelValue;
        }

        /// <summary>
        /// This method is used to get value from the specified page.
        /// </summary>
        /// <param name="xpath"></param>
        /// <param name="type"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.GetValueFromSpecifiedPage(CreateAccountPage.txtFirstName,field);
        /// Application.WebCSR.GetValueFromSpecifiedPage(VerifyCustomerPage.drpVerificationMethod,dropdown);
        /// </example>
        public virtual string GetValueFromSpecifiedPage(string xpath, string type)
        {
            string output = null;
            try
            {
                switch (type.ToUpper())
                {
                    case "FIELD":
                        output = WebCSRPageFactory.WebCSRMasterPage.GetFieldValue(xpath);
                        break;
                    case "DROPDOWN":
                        output = WebCSRPageFactory.WebCSRMasterPage.GetDropdownValue(xpath);
                        break;
                    case "CHECKBOX":
                        output = WebCSRPageFactory.WebCSRMasterPage.GetCheckBoxStatus(xpath);
                        break;
                }

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return output;
        }

        /// <summary>
        /// This method is used to get value from the specified page.
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="Interval"></param>
        /// <param name = 12></param>
        /// <returns></returns>
        /// <example>
        /// Application.WebCSR.CalculateBackOrFutureDateFromApplication("BankingCenterList","m",12);
        /// </example>
        public virtual string CalculateBackOrFutureDateFromApplication(string TableName, string Interval, int Num)
        {
            string NewDate = null;
            try
            {
                string ApplicationDate = GetApplicationDate();
                NewDate = CalculateNewDate(ApplicationDate, Interval, Num);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return NewDate;
        }

        /// <summary>
        /// This method is used to compare two string values.
        /// <param name= "string1"></param> 
        /// <param name= "string2"></param>
        /// <returns></returns> 
        /// <example>comparestringvalues("Annual Yield","Annual Yield");<example>
        public virtual void comparestringvalues(string string1, string string2)
        {
            try
            {
                if (WebCSRPageFactory.WebCSRMasterPage.comparestringvalues(string1, string2))
                    Report.Pass("Strings compared successfully, both strings have same values", "value", "True", appHandle);
                else
                    Report.Fail("Strings compared failed, both strings do not have same values", "value", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to get total number of days in a year.
        /// <param name= int></param> 
        /// <returns>integer</returns> 
        /// <example>GetTotalNoOfDaysInYear(1998);<example>
        public virtual int GetTotalNoOfDaysInYear(int Year)
        {
            int DaysCount = 0;
            try
            {
                DaysCount = WebCSRPageFactory.WebCSRMasterPage.CountNumberOfDaysInYear(Year);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return DaysCount;
        }


        /// <summary>
        /// This function is used for verify the status of checked and unchecked check boxes.
        /// </summary>
        /// <param name="string Checkbox1"></param>
        /// <param name="string status"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.VeifytheStatusofCheckbox("string Checkbox1, string status");
        /// </example>

        public virtual void VeifytheStatusofCheckbox(string Checkbox1, string status)
        {
            try
            {
                WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                bool output = false;
                if (status.ToUpper() == "SELECTED")
                    output = WebCSRPageFactory.FDIC370InformationPage.VerifytheStatusofcheckedCheckbox(status);

                if (status.ToUpper() == "DESELECTED")
                    output = WebCSRPageFactory.FDIC370InformationPage.VeifytheStatusofUncheckedCheckbox(Checkbox1);

                if (output == true)
                    Report.Pass("Successfully fetched the label value", "output", "True", appHandle);
                else
                    Report.Fail("Failed to fetch the label value", "output", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used for verify the Object is exists.
        /// </summary>
        /// <param name="string obj1"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.VerifytheObjectExists("string obj1");
        /// </example>

        public virtual bool VerifytheObjectExists(List<string> objs)
        {
            bool output = false;
            try
            {
                foreach (string value in objs)
                {
                    output = WebCSRPageFactory.FDIC370InformationPage.VerifytheObjectExists(value);
                    if (output == true)
                        Report.Pass("Object exists in this Page", "VerifytheObjectExists,", "True", appHandle);
                    else
                        Report.Fail("Object not exists in this Page", "VerifytheObjectExists", "True", appHandle);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return output;
        }

        /// <summary>
        /// This function is used for verify the expected message.
        /// </summary>
        /// <param name="string msg"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckSuccessMessage("string msg");
        /// </example>

        public virtual void CheckSuccessMessage(string msg)
        {
            try
            {
                bool output = WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(msg);
                if (output == true)
                    Report.Pass("Object exists in FDIC Page", "True", appHandle);
                else
                    Report.Fail("Object not exists in FDIC Page", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used for verify the drop down values.
        /// </summary>
        /// <param name="string drpxpath"></param>
        /// <param name="string[] ValuesofORC"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.VerifytheValuesinDropdown("string drpxpath,string[] ValuesofORC");
        /// </example>
        public virtual void VerifytheValuesinDropdown(string drpxpath, string[] ValuesofORC)
        {
            try
            {
                WebCSRPageFactory.FDIC370InformationPage.VerifytheValuesinDropdown(drpxpath, ValuesofORC);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to edit and update statement group.
        /// <param name= "AccountStatementGroupNumber"></param> 
        /// <param name= "List<string> values"></param>
        /// <param name= "ExceptedMsg"></param>
        /// <returns></returns> 
        /// <example>EditAndUpdateStatementGroup("1",values,"The statement group has been updated.")<example>
        public virtual void EditAndUpdateStatementGroup(string AccountStatementGroupNumber, List<string> values, string ExceptedMsg)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkinTab(BankingCenterPage.CustServicesLink, BankingCenterPage.CustServiceStatementGroupLink);
                WebCSRPageFactory.StatementGroupPage.SelectStatementGroup(AccountStatementGroupNumber);
                WebCSRPageFactory.StatementGroupPage.ClickOnStatementGroupEditButton();
                EnterValuesInWebCSRSpecifiedPage(values);
                WebCSRPageFactory.StatementGroupPage.ClickOnSubmitButton();
                bool bcheck = WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(ExceptedMsg);
                if (bcheck)
                    Report.Pass("Successfully updated the statement group information", "UpdateStatementGroupInformation", "True", appHandle);
                else
                    Report.Fail("Failed to update the statement group information", "UpdateStatementGroupInformation", "True", appHandle);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This method is used to relase specified collateral type.
        /// <param name= "Xpath"></param> 
        /// <param name= "sCode"></param>
        /// <param name= "ExceptedMsg"></param>
        /// <returns></returns> 
        /// <example>ReleaseCollateralType(CollateralPage.tblCollateralAction, "0 - Unsecured", "Collateral released.")<example>

        public virtual void ReleaseCollateralType(string Xpath, string sCode, string sExpectedMsg = null)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectRadioButtonInTable(Xpath, sCode);
                WebCSRPageFactory.WebCSRMasterPage.ClickOnReleaseButton();
                WebCSRPageFactory.WebCSRMasterPage.ActionOnPopButton("OK");
                bool bcheck = WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(sExpectedMsg);
                if (bcheck)
                    Report.Pass("Successfully released the Collateral Type", "ReleaseCollateralType", "True", appHandle);
                else
                    Report.Fail("Failed to Releases the Collateral Type", "ReleaseCollateralType", "True", appHandle);

            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to create new Collateral.
        /// <param name= "CollateralDetails1"></param>
        ///  CollateralDetails1.Add(CollateralPage.drpCollateralType + "|dropdown|" + COLL_TYPE_BOAT);
        ///  CollateralDetails1.Add(CollateralPage.txtVehicleMake + "|field|Boat as Collateral");
        ///  CollateralDetails1.Add(CollateralPage.drpVehicleCurrencyCode + "|dropdown|" + Data.Get("GLOBAL_CURRENCY_CODE_USD"));
        ///  CollateralDetails1.Add(CollateralPage.txtVehicleCurrentValue + "|field|" + Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K"));
        ///  CollateralDetails1.Add(CollateralPage.cbkPledgedAmountsMayBeReleased + "|checkbox|ON");
        /// <returns></returns> 
        /// <example>CreateNewCollateral(CollateralDetails1)<example>
        public virtual void CreateNewCollateral(List<string> CollateralDetails)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.ClickOnAddButton();
                EnterValuesInWebCSRSpecifiedPage(CollateralDetails);
                WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
        }

        /// <summary>
        /// This method is used to check Alert Message exists in Table.
        /// </summary>
        /// <param name="sRefValue"></param>
        /// <param name="sTableName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckDataExistinTable(Date;10/11/2010;Description;Debit,tableXpath);
        /// </example>
        public virtual void CheckDataExistinTable(string sRefValue, string sTableName)
        {
            bool bCheck = false;
            try
            {
                bCheck = WebCSRPageFactory.WebCSRMasterPage.CheckMessageExistsInTable(sRefValue, sTableName);
                if (bCheck)
                {
                    Report.Pass("Alert message exists in table", "AlertMessage", "True", appHandle);
                }
                else
                {
                    Report.Fail("Alert message not found in table", "AlertMessage", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }

        }

        /// <summary>
        /// This function is used for Navigating to the Link Beneficiaries page.
        /// </summary>
        /// <param name="string accName"></param>
        /// <param name="string accNumber"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.NavigatingtoLinkBeneficiariesPage("string accName, string accNumber");
        /// </example>

        //Business function for Naviogating to the Link Beneficiaries page.
        public virtual void NavigatingtoLinkBeneficiariesPage(string accName, string accNumber)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkinTab(BankingCenterPage.GeneralAccServicesTab, BankingCenterPage.GeneralAccServiceBeneficiariesLink);
                string BenActNum = accName + " - " + accNumber + " - USD";
                WebCSRPageFactory.BeneficiariesPage.selectAccountFromDropdown(BenActNum);
                WebCSRPageFactory.WebCSRMasterPage.ClickObject(BeneficiariesPage.btnLinkBeneficiary);
                bool blnConfirmedMsg = WebCSRPageFactory.BeneficiarySearchPage.ConfirmBeneficiarySearchPage();
                if (blnConfirmedMsg == true)
                    Report.Pass("Successfully navigated to Beneficiary search page", "blnConfirmedMsg", "True", appHandle);
                else
                    Report.Fail("Not navigated to the search page", "blnConfirmedMsg", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used for Navigating to the Add Beneficiaries page.
        /// </summary>
        /// <param name="string accName"></param>
        /// <param name="string accNumber"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.NavigatingtoAddBeneficiariesPage("string accName, string accNumber");
        /// </example>
        public virtual void NavigatingtoAddBeneficiariesPage(string accName, string accNumber)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkinTab(BankingCenterPage.GeneralAccServicesTab, BankingCenterPage.GeneralAccServiceBeneficiariesLink);
                string BenActNum = accName + " - " + accNumber + " - USD";
                WebCSRPageFactory.BeneficiariesPage.selectAccountFromDropdown(BenActNum);
                WebCSRPageFactory.BeneficiariesPage.ClickAddButton();
                bool blnConfirmedMsg = WebCSRPageFactory.AddBeneficiaryPage.ConfirmAddBeneficiaryPage();
                if (blnConfirmedMsg == true)
                    Report.Pass("Successfully navigated to Add Beneficiary page", "blnConfirmedMsg", "True", appHandle);
                else
                    Report.Fail("Not navigated to the Add Beneficiary page", "blnConfirmedMsg", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used for Add Beneficiaries page.
        /// </summary>
        /// <param name="List<string> FieldsValues"></param>
        /// <param name="string accName"></param>
        /// <param name="string accNumber"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.AddBeneficiary("List<string> FieldsValues, string acctname, string acctnumber, string ExpectedMsg");
        /// </example>
        public virtual void AddBeneficiary(List<string> FieldsValues, string ExpectedMsg)
        {
            try
            {
                EnterValuesInWebCSRSpecifiedPage(FieldsValues);
                WebCSRPageFactory.WebCSRMasterPage.ClickOnSubmitButton();
                bool bcheck = WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(ExpectedMsg);
                if (bcheck)
                    Report.Pass("Beneficiary Added Successfully", "UpdateInformation", "True", appHandle);
                else
                    Report.Fail("Beneficiary is not Added Successfully", "UpdateInformation", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used for Get the value from Beneficiary table.
        /// </summary>
        /// <param name="string sRefvalues"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.GetValuefromBeneficiaryTable("string sRefvalues");
        /// </example>
        public virtual string GetValuefromBeneficiaryTable(string sRefvalues)
        {
            string bcheck = "false";
            try
            {
                bcheck = WebCSRPageFactory.BeneficiariesPage.GetValuefromBeneficiaryTable(sRefvalues);
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return bcheck;
        }

        /// <summary>
        /// This function is used for Bensearchpage Validations
        /// </summary>
        /// <param name="List<string> FieldsValues"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.BensearchpageValidations("string sRefvalues");
        public virtual void BensearchpageValidations(List<string> FieldsValues, string ExpectedMsg)
        {
            try
            {
                EnterValuesInWebCSRSpecifiedPage(FieldsValues);
                WebCSRPageFactory.BeneficiarySearchPage.ClickonSearchbutton();
                bool bcheck = WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(ExpectedMsg);
                if (bcheck)
                    Report.Pass("Validations are coming correctly", "output", "True", appHandle);
                else
                    Report.Fail("Validations are not coming correctly", "output", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }

        }

        //Method for clcik the cancel button.
        public virtual void ClickonCancelButton()
        {
            WebCSRPageFactory.BeneficiarySearchPage.ClickonCancelButton();
        }

        //Method for clcik the submit button.
        public virtual void ClickonSubmitButton()
        {
            WebCSRPageFactory.BeneficiarySearchPage.ClickonsubmitButton();
        }

        /// <summary>
        /// This function is used for check the value from Beneficiary table.
        /// </summary>
        /// <param name="string sRefvalues"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckValuefromBeneficiaryTable("string sRefvalues");
        /// </example>
        public virtual void CheckValuefromBeneficiaryTable(string sRefvalues)
        {
            bool bcheck;
            try
            {
                bcheck = WebCSRPageFactory.BeneficiariesPage.CheckValuefromBeneficiaryTable(sRefvalues);
                if (bcheck == true)
                    Report.Pass("Value is verified", "bcheck", "True", appHandle);
                else
                    Report.Fail("Value is not verified", "bcheck", "True", appHandle);
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

        /// <summary>
        /// This function is used for Verify the Object is disabled.
        /// </summary>
        /// <param name="List<string> FieldsValues"></param>
        /// <param name="string Obj"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.VerifyObjectisDisabled("string sRefvalues");
        /// </example>
        public bool VerifyObjectisDisabled(List<string> FieldsValues, string Obj)
        {
            bool output = false;
            try
            {
                EnterValuesInWebCSRSpecifiedPage(FieldsValues);
                output = appHandle.CheckObjectDisabled(Obj);
                if (output == true)
                    Report.Pass("Object is disabled correctly", "output", "True", appHandle);
                else
                    Report.Fail("Object is not disabled", "output", "True", appHandle);
            }
            catch (System.Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return output;
        }


        //Method for click the pop up on browser.
        public virtual void ActionOnPopButton(bool ActionType)
        {
            try
            {
                if (ActionType == true)
                    appHandle.PerformActionOnAlert(PopUpAction.Accept);
                else
                    appHandle.PerformActionOnAlert(PopUpAction.Decline);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used for Verify the Expected value in Drop down.
        /// </summary>
        /// <param name="string DropdownName"></param>
        /// <param name="string sExpVal"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckExpectedValueinDropdown("string DropdownName, string sExpVal");
        /// </example>

        public virtual void CheckExpectedValueinDropdown(string DropdownName, string sExpVal)
        {
            bool output;
            try
            {
                output = WebCSRPageFactory.WebCSRMasterPage.CheckExpectedValueinDropdown(DropdownName, sExpVal);
                if (output == true)
                    Report.Pass("Expected value is there in Dropdown", "output", "True", appHandle);
                else
                    Report.Fail("Expected value is not there in Dropdown", "output", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }


        /// <summary>
        /// This function is used for Verify the Expected value in EDit field.
        /// </summary>
        /// <param name="string ObjectName"></param>
        /// <param name="string sExpVal"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckExpectedValueinEditField("string ObjectName, string sExpVal");
        /// </example>
        public virtual void CheckExpectedValueinEditField(string ObjectName, string sExpVal)
        {
            try
            {
                string ActVal = WebCSRPageFactory.WebCSRMasterPage.GetFieldValue(ObjectName);
                if (sExpVal.Equals(ActVal))
                    Report.Pass("Expected value is there in Field", "output", "True", appHandle);
                else
                    Report.Fail("Expected value is not there in Field", "output", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used for Verify the edit field is blank.
        /// </summary>
        /// <param name="string ObjectName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.Checkeditblanktrue("string ObjectName");
        /// </example>
        public virtual void Checkeditblanktrue(string Objname)
        {
            try
            {
                WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                WebCSRPageFactory.WebCSRMasterPage.Checkeditblanktrue(Objname);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to Navigate to any edit page by selecting radiobutton in Table.
        /// <param name= "Table"></param> 
        /// <param name= "Refervalues"></param>
        /// <returns></returns> 
        /// <example>NavigatetoEditPagebySelectingRadiobutton(UnpaidPaymentPage.unpaidtable,"Due Date;" + systemdate3 + ";Total;868.56");<example>
        public virtual void NavigatetoEditPagebySelectingRadiobutton(string Table, string Refervalues)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectRadioButtoninTable(Table, Refervalues);
                WebCSRPageFactory.WebCSRMasterPage.ClickOnEditButton();
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to delete any items by selecting radiobutton in Table.
        /// <param name= "Table"></param> 
        /// <param name= "Refervalues"></param>
        /// <param name= "sExpectedMsg"></param>
        /// <returns></returns> 
        /// <example>DeleteItembySelectingRadiobuttoninTable(UnpaidPaymentPage.unpaidtable,"Due Date;" + systemdate3 + ";Total;868.56","Payment deleted successfully.");<example>
        public virtual void DeleteItembySelectingRadiobuttoninTable(string Table, string Refervalues, string sExpectedMsg)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectRadioButtoninTable(Table, Refervalues);
                WebCSRPageFactory.WebCSRMasterPage.ClickOnDeleteButton();
                WebCSRPageFactory.WebCSRMasterPage.ActionOnPopButton(true);
                bool bcheck = WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(sExpectedMsg);
                if (bcheck)
                    Report.Pass("Deletion Successfully ", "Updformation", "True", appHandle);
                else
                    Report.Fail("Failed to Delete", "Updaormation", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This function is used for Navigating to the Deposit Account Product Transfer page.
        /// </summary>
        /// <param name="string accName"></param>
        /// <param name="string accNumber"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.NavigatingtoAddBeneficiariesPage("string accName, string accNumber");
        /// </example>
        public virtual void ActionsinDepositProductTransferPage(string accName, string accNumber, string ProductNumber = null)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkinTab(BankingCenterPage.DepositAccountServicesTab, BankingCenterPage.DepositAccServiceProductTrnasferLink);
                if (accNumber != null)
                {
                    string DepActNum = accName + " - " + accNumber + " - USD";
                    WebCSRPageFactory.DepositAccountProductTransferPage.selectAccountFromDropdown(DepActNum);
                }
                if (ProductNumber != null)
                {
                    string ToAcctNum = ProductNumber + " - " + accName;
                    WebCSRPageFactory.DepositAccountProductTransferPage.selectAccountFromDropdown(ToAcctNum);
                }
                bool blnConfirmedMsg = WebCSRPageFactory.DepositAccountProductTransferPage.ConfirmDepositProductTransferPage();
                if (blnConfirmedMsg == true)
                    Report.Pass("Selected in Product Transfer page", "blnConfirmedMsg", "True", appHandle);
                else
                    Report.Fail("Not Selected in Product Transfer page", "blnConfirmedMsg", "True", appHandle);

            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        //Function for Click the Continue Button.
        public virtual void ClickonContinueButton()
        {
            WebCSRPageFactory.WebCSRMasterPage.ClickOnContinueButton();
        }
        public virtual void Click_Continue_Button()
        {
            WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
        }

        //##########################################################################

        //Function for Create the Corporate Customer.
        public virtual string createcorporatecustomer(string sCustomerType, string sSearchType)
        {

            string sWebClientUserID1 = null;
            string sUserID = null;
            string sSearchvalue = null;
            string sCustomerNumber = null;
            string[] arrOnlineAccessSecurityDetails = null;

            if (sCustomerType.Equals(Data.Get("GLOBAL_CORPORATE_CUSTOMER")))
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectCorporateCustomerLink();
                // Enter Personal Information details.
                //string sPersonalInformationDetails = Data.Get("GLOBAL_CORPORATE_INFORMATION_DETAILS");
                WebCSRPageFactory.CreateCorporateCustomerPage.EnterCorporateInformation();

                // Enter Email and Phone details.
                WebCSRPageFactory.CreateCorporateCustomerPage.EnterEmailAndPhoneDetails();

                // Enter Home Address details.
                WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddress();


                // Enter Mailing Address details.
                string sMailingAddress = Data.Get("GLOBAL_MAILINGADDRESS");
                if (sMailingAddress.Equals(Data.Get("GLOBAL_MAILINGADDRESS_SAMEAS_HOMEADDRESS")))
                {
                    WebCSRPageFactory.CreateCorporateCustomerPage.SelectAddressSameAsPrincipalAddressRadioButton("yes");
                }
                else
                {
                    WebCSRPageFactory.CreateCorporateCustomerPage.SelectAddressSameAsPrincipalAddressRadioButton("no");
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterMailingAddress();
                }

                // Generate random value to get the User Name.
                string sRandomValue = RandomNumberGenerator.Generate();
                sRandomValue = sRandomValue.Substring(0, sRandomValue.Length - 1);

                // Enter Online Access details.
                sUserID = StartupConfiguration.EnvironmentDetails.UserFirstName;
                sUserID = appHandle.SplitSideString(sUserID.ToUpper(), "LEFT", 4) + sRandomValue;
                // Enter Online Access | User ID value.
                string sAllowOnlineAccess = Data.Get("GLOBAL_PERSONAL_CUSTOMER_ALLOW_ONLINE_ACCESS");
                if (sAllowOnlineAccess.ToUpper().Equals("YES"))
                {
                    WebCSRPageFactory.CreateCorporateCustomerPage.SelectAllowOnlineAccessRadioButton("yes");

                    // To enter Online Access Details
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterOnlineAccessDetails();

                    // To get the Temporary Password Action dropdown value 
                    string sTemporaryPasswordAction = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_tmporary_password_action_field_value();
                    // Get the Value in the User ID Field
                    sWebClientUserID1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_user_id_field_value();

                    if (sTemporaryPasswordAction.Equals(Data.Get("GLOBAL_TEMPORARY_PASSWORD_ACTION_RESET")))
                    {
                        string sOnlineAccessSecurityDetails = Data.Get("GLOBAL_ONLINESECURITY_DETAILS");
                        arrOnlineAccessSecurityDetails = sOnlineAccessSecurityDetails.Split('_');
                        WebCSRPageFactory.CreatePersonalCustomerPage.enter_online_access_security_details(arrOnlineAccessSecurityDetails);
                    }
                }
                else
                {
                    WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_allow_online_access_no();
                }

                // Enter Security Question details.
                WebCSRPageFactory.CreateCorporateCustomerPage.EnterSecretQuestionDetails();

                // Enter Telephone Banking details.
                WebCSRPageFactory.CreateCorporateCustomerPage.SelectCreateATelePhonebankingPINRadioButton("Yes");
                string sTaxIdValue1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_tax_id_number_field_value();
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnContinueButton();
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnSubmitButton();
                if (WebCSRPageFactory.CreateCorporateCustomerPage.VerifyCorporateCustomerCreationSuccess())
                {
                    Report.Info("Corporate Customer application is created successfully", "CorporateCustCreate", "true", appHandle);
                    string sGlobalSearchType = Data.Get("GLOBAL_SEARCHTYPE");
                    if (sGlobalSearchType.Equals(Data.Get("GLOBAL_SEARCHTYPE_TAXID")) || sSearchType.Equals(Data.Get("GLOBAL_SEARCHTYPE_TAXID")))
                    {
                        sSearchvalue = sTaxIdValue1;
                        sSearchType = Data.Get("GLOBAL_SEARCHTYPE_TAXID");
                    }
                    sCustomerNumber = WebCSRPageFactory.CustomerSearchPage.get_customer_number(sSearchType, sSearchvalue);
                    if (!string.IsNullOrEmpty(sCustomerNumber))
                    {
                        Report.Info("Corporate customer number is captured as: " + sCustomerNumber, "custcorp", "true", appHandle);
                    }
                }
                else
                {
                    Report.Fail("Corporate Customer application is not created due to :" + WebCSRPageFactory.CreateCorporateCustomerPage.GetMessageText(), "CreatecorpcustFail", "true", appHandle, true);
                }

            }
            return sCustomerNumber;
        }

        /// <summary>
        /// This method is used to click Tab in Customer Information Page.
        /// </summary>
        /// <param name="sTabName"></param>
        /// <param name="sLinkName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.ClickTabInCustomerInformationPage("Interest", CustomerInformationResidencyPage.lnkFATCA);
        /// </example>
        public virtual void ClickTabInCustomerInformationPage(string sTabName, string sLinkName = null)
        {
            string xpath = null;
            try
            {
                xpath = WebCSRPageFactory.WebCSRMasterPage.GetTabXpath(sTabName);
                WebCSRPageFactory.WebCSRMasterPage.ClickObject(xpath);
                if (sLinkName != null)
                {
                    WebCSRPageFactory.WebCSRMasterPage.SelectLink(sLinkName);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to verify the unchecked checkbox status.
        /// <param name= "sCheckboxXpath"></param> 
        /// <returns>true/false</returns> 
        /// <example>WebCSRMasterPage.ChecktheCheckboxDisabled(sCheckboxXpath)<example>
        public virtual bool ChecktheCheckboxDisabled(string sCheckboxXpath)
        {
            bool CheckboxStatus = false;
            try
            {
                CheckboxStatus = WebCSRPageFactory.WebCSRMasterPage.VerifytheCheckBoxUnchecked(sCheckboxXpath);
                if (CheckboxStatus)
                {
                    Report.Pass("Checkbox status is disabled", "ChecktheCheckboxDisabled", "True", appHandle);
                }
                else
                {
                    Report.Fail("Checkbox status is not disabled", "ChecktheCheckboxDisabled", "True", appHandle);
                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return CheckboxStatus;
        }

        /// <summary>
        /// This method is used to verify the unchecked checkbox status.
        /// <param name= "sCheckboxXpath"></param> 
        /// <returns>true/false</returns> 
        /// <example>WebCSRMasterPage.ChecktheCheckboxisEnabled(sCheckboxXpath)<example>
        public virtual bool ChecktheCheckboxisEnabled(string sCheckboxXpath)
        {
            bool CheckboxStatus = false;
            try
            {
                CheckboxStatus = WebCSRPageFactory.WebCSRMasterPage.VerifytheCheckBoxisChecked(sCheckboxXpath);
                if (CheckboxStatus)
                    Report.Pass("Checkbox status is Selected", "CheckboxStatus", "True", appHandle);
                else
                    Report.Fail("Checkbox status is not Selected", "CheckboxStatus", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return CheckboxStatus;
        }
        public virtual string GetCustomerLabelsBySearch(string sSearchType, string sSearchvalue, string slabelName)
        {
            string outputValue = null;
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLink(CustomerSearchPage.SearchCustomerLink);
                WebCSRPageFactory.CustomerSearchPage.SelectSearchTypeRadioButton(sSearchType);
                WebCSRPageFactory.WebCSRMasterPage.SetFieldValue(CustomerSearchPage.SearchField, sSearchvalue);
                WebCSRPageFactory.WebCSRMasterPage.ClickOnSubmitButton();
                outputValue = WebCSRPageFactory.CustomerSearchPage.GetLabelValue(slabelName);
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return outputValue;
        }

        public virtual void ApplicationSearch(string sSearchType, string sSearchField, string sSearchvalue)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkinTab(BankingCenterPage.tabAppicationService, BankingCenterPage.lnkApplicationManagement);
                WebCSRPageFactory.WebCSRMasterPage.SetRadioButton(sSearchType);
                WebCSRPageFactory.WebCSRMasterPage.SetFieldValue(sSearchField, sSearchvalue);
                WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

        public virtual void VerifyCellValuesByLabelInApplicationSummaryPage(List<string> LabelNames, List<string> ExpectedLabelValues, string sDetailsButton = null)
        {
            try
            {
                if (sDetailsButton != null)
                {
                    WebCSRPageFactory.WebCSRMasterPage.ClickObject(sDetailsButton);
                }
                for (int i = 0; i < LabelNames.Count; i++)
                {
                    string actualValue = GetCellValueByLabel(LabelNames[i]);
                    comparestringvalues(actualValue, ExpectedLabelValues[i]);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
        }

        public virtual string CreateCorporateCustomer(string sCustomerType, string sSearchType, bool beneficaryCheckBox = false)
        {
            string sWebClientUserID1 = null;
            string sUserID = null;
            string sSearchvalue = null;
            string sCustomerNumber = null;

            try
            {
                if (sCustomerType.Equals(Data.Get("GLOBAL_CORPORATE_CUSTOMER")))
                {
                    WebCSRPageFactory.WebCSRMasterPage.SelectCorporateCustomerLink();

                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterCorporateInformation();

                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterFATCADetails();

                    // Enter Email and Phone details.
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterEmailAndPhoneDetails();

                    // Enter Home Address details.
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddress();

                    // Enter Mailing Address details.
                    string sMailingAddress = Data.Get("GLOBAL_MAILINGADDRESS");
                    if (sMailingAddress.Equals(Data.Get("GLOBAL_MAILINGADDRESS_SAMEAS_HOMEADDRESS")))
                    {
                        WebCSRPageFactory.CreateCorporateCustomerPage.SelectAddressSameAsPrincipalAddressRadioButton("yes");
                    }
                    else
                    {
                        WebCSRPageFactory.CreateCorporateCustomerPage.SelectAddressSameAsPrincipalAddressRadioButton("no");
                        WebCSRPageFactory.CreateCorporateCustomerPage.EnterMailingAddress();
                    }
                    if (beneficaryCheckBox)
                    {
                        WebCSRPageFactory.WebCSRMasterPage.SelectCheckBox(CreateCorporateCustomerPage.cbkBeneficialOwners, "ON");
                        WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnBeneficiaryAddButton();
                        WebCSRPageFactory.WebCSRMasterPage.ClickOnAddButton();
                        WebCSRPageFactory.AddBeneficialOwnerstoCreateCorporateCustomerPage.EnterBeneficiaryDetails();
                        WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                        WebCSRPageFactory.BeneficialOwnersInformationProviderPage.EnterBasicDetails();
                        WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
                    }

                    // Generate random value to get the User Name.
                    string sRandomValue = RandomNumberGenerator.Generate();
                    sRandomValue = sRandomValue.Substring(0, sRandomValue.Length - 1);

                    // Enter Online Access details.
                    sUserID = StartupConfiguration.EnvironmentDetails.UserFirstName;
                    sUserID = appHandle.SplitSideString(sUserID.ToUpper(), "LEFT", 4) + sRandomValue;
                    // Enter Online Access | User ID value.
                    string sAllowOnlineAccess = Data.Get("GLOBAL_PERSONAL_CUSTOMER_ALLOW_ONLINE_ACCESS");
                    if (sAllowOnlineAccess.ToUpper().Equals("YES"))
                    {
                        WebCSRPageFactory.CreateCorporateCustomerPage.SelectAllowOnlineAccessRadioButton("yes");

                        // To enter Online Access Details
                        WebCSRPageFactory.CreateCorporateCustomerPage.EnterOnlineAccessDetails();

                        // To get the Temporary Password Action dropdown value 
                        string sTemporaryPasswordAction = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_tmporary_password_action_field_value();
                        // Get the Value in the User ID Field
                        sWebClientUserID1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_user_id_field_value();

                    }
                    else
                    {
                        WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_allow_online_access_no();
                    }

                    // Enter Security Question details.
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterSecretQuestionDetails();

                    // Enter Telephone Banking details.
                    string sTaxIdValue1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_tax_id_number_field_value();
                    string sGlobalSearchType = Data.Get("GLOBAL_SEARCHTYPE");
                    if (sGlobalSearchType.Equals(Data.Get("GLOBAL_SEARCHTYPE_TAXID")) || sSearchType.Equals(Data.Get("GLOBAL_SEARCHTYPE_TAXID")))
                    {
                        sSearchvalue = sTaxIdValue1;
                        sSearchType = Data.Get("GLOBAL_SEARCHTYPE_TAXID");
                    }

                    WebCSRPageFactory.WebCSRMasterPage.select_continue_button();
                    WebCSRPageFactory.WebCSRMasterPage.select_submit_button();
                    sCustomerNumber = WebCSRPageFactory.CustomerSearchPage.get_customer_number(sSearchType, sSearchvalue);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception Logged:" + e);
            }
            return sCustomerNumber;
        }

        public virtual bool CheckSpecifiedDataAvailableInTable(string sTableHeaderXpath, string sTableBodyXpath, string sReferenceValues)
        {
            bool bExists = false;
            try
            {
                string[] refValues = sReferenceValues.Split(';');
                int refValueCount = (refValues.Length) - 1;
                List<int> lstColIndex = new List<int>();
                List<string> lstRefValue = new List<string>();
                string strExpValue = refValues[refValueCount];
                string strExpColumn = refValues[refValueCount - 1];
                IList<object> validRow = new List<object>();
                if (appHandle.IsObjectExists(sTableHeaderXpath))
                {
                    List<object> ColumnsInTable = appHandle.GetColumnInTable(sTableHeaderXpath);
                    IList<object> col = ((List<object>)ColumnsInTable);
                    appHandle.GetColumnIndexesFromColumnValues(refValues, lstColIndex, lstRefValue, col);
                    validRow = FindMatchingRows(sTableBodyXpath, lstColIndex, lstRefValue);
                    if (validRow.Count > 0)
                    {
                        bExists = true;
                        Report.Pass("Data found in specified table", "DataFound", "True", appHandle);
                    }
                    else
                    {
                        Report.Fail("Data not found in specified table", "DataFound", "True", appHandle);
                    }

                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
            return bExists;
        }

        private IList<object> FindMatchingRows(object oObjectTable, List<int> lstColIndex, List<string> lstRefValue, object oParentObject = null)
        {
            try
            {

                IWebElement element = (IWebElement)appHandle.FindElement(oObjectTable);
                IList<IWebElement> rows = element.FindElements(By.TagName("tr"));
                int rowCount = rows.Count;
                bool bMatch = true;
                List<int> newlstColIndex = new List<int>();
                IList<object> matchingElement = new List<object>();
                for (int i = 0; i < rows.Count; i++)
                {
                    bMatch = true;
                    for (int j = 0; j < lstColIndex.Count; j++)
                    {
                        string columnValue = appHandle.GetObjectText("XPATH;.//td[" + lstColIndex[j] + "]", rows[i]);
                        if (columnValue == null)
                        {
                            bMatch = false;
                            break;
                        }
                        else if (columnValue.ToUpper().Trim() != lstRefValue[j].ToUpper().Trim())
                        {
                            bMatch = false;
                            break;
                        }
                    }
                    if (bMatch)
                        matchingElement.Add(rows[i]);
                }
                return matchingElement;
            }
            catch (NoSuchElementException e)
            {
                Report.Fail("FindMatchingRows: " + oObjectTable + " not found in the current page." + e);
                return null;
            }
        }

        public virtual List<string> GetColumnValuesForSpecifiedColumn(string sTableHeaderXpath, string sTableBodyXpath, string sColumnName)
        {
            List<string> columnValues = new List<string>();
            int columnIndex = 0;
            try
            {
                if (appHandle.IsObjectExists(sTableHeaderXpath))
                {
                    List<object> columns = appHandle.GetColumnInTable(sTableHeaderXpath);

                    for (int i = 0; i < columns.Count; i++)
                    {
                        string output1 = ((IWebElement)columns[i]).Text;
                        if (output1.Equals(sColumnName))
                        {
                            columnIndex = i;
                            break;
                        }
                    }
                    columnValues = GetCoulmnValuesThroughIndex(sTableBodyXpath, columnIndex);

                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
            return columnValues;

        }

        public virtual List<string> GetCoulmnValuesThroughIndex(string sTableXpath, int index)
        {
            List<string> columnValues = new List<string>();
            try
            {
                object obj = appHandle.FindElement(sTableXpath);
                IWebElement ele = (IWebElement)obj;
                IList<IWebElement> rows = ele.FindElements(By.TagName("tr"));
                for (int i = 0; i < rows.Count; i++)
                {
                    IList<IWebElement> columns = rows[i].FindElements(By.TagName("td"));
                    for (int j = index; j < columns.Count; j++)
                    {
                        string ColumnValue = "";
                        if (j == index)
                        {
                            ColumnValue = ((IWebElement)columns[j]).Text;
                            columnValues.Add(ColumnValue);
                            break;
                        }
                    }

                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
            return columnValues;
        }

        public virtual int GetNoofDaysBetweenTwoDates(string date1, string date2)
        {
            int days = 0;
            try
            {
                DateTime dt1 = DateTime.Parse(date1);
                DateTime dt2 = DateTime.Parse(date2);
                days = (dt1 - dt2).Days;
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
            return days;
        }

        public virtual void ClickonLink(string sLink)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLink(sLink);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
        }

        public virtual string GenerateTaxId(string Format)
        {
            string sRequiredPatternTaxId = null;
            try
            {
                sRequiredPatternTaxId = WebCSRPageFactory.CreateCorporateCustomerPage.GenerateRandomNumberByFormat(Format);
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
            return sRequiredPatternTaxId;

        }

        public virtual void VerifyObjectByLabel(string sTableName, string sLabelName, ObjType objType)
        {
            bool bExists = false;
            try
            {
                bool isTableExists = WebCSRPageFactory.WebCSRMasterPage.VerifytheObjectExists(sTableName);
                if (isTableExists)
                {
                    bExists = WebCSRPageFactory.WebCSRMasterPage.CheckObjectExistsByLabel(sTableName, sLabelName, objType);
                    if (bExists)
                    {
                        Report.Pass("Object exists", "VerifyObjectByLabel", "True", appHandle);
                    }
                    else
                    {
                        Report.Fail("Object not exists", "VerifyObjectByLabel", "True", appHandle);
                    }
                }
                else
                {
                    Report.Info("Table not  found", "VerifyObjectByLabel", "True", appHandle);
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged :" + e);
            }
        }

        public virtual string GetAlphaNumericString(int size)
        {
            try
            {
                Random random = new Random();
                const string chars = "ABCDEFGHIJKLMNPQRSTUVWXYZ";
                return new string(Enumerable.Repeat(chars, size)
                                .Select(s => s[random.Next(s.Length)]).ToArray());
            }
            catch (Exception e)
            {
                Report.Info("Exception logged " + e);
                return null;
            }
        }
        public virtual string RandomDigits(int length)
        {
            Random random = new Random();
            string str = string.Empty;
            try
            {
                for (int i = 0; i < length; i++)
                {
                    str = String.Concat(str, random.Next(10).ToString());
                }
            }
            catch (Exception e)
            {
                Report.Info("Exception logged " + e);
            }
            return str;
        }

        public virtual void SetFrequencyFromFrequencyCalculator(string sCalculatorXpath, string FrequencyInMonths)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.ClickObject(sCalculatorXpath);
                WebCSRPageFactory.WebCSRMasterPage.SelectDropdownValue(WebCSRMasterPage.drpFrequencyInFrequencyCalculator, FrequencyInMonths);
                WebCSRPageFactory.WebCSRMasterPage.WaitUntilValueChanges(2);
                WebCSRPageFactory.WebCSRMasterPage.ClickObject(WebCSRMasterPage.btnSubmitInFrequencyCalculator);

            }
            catch (Exception e)
            {
                Report.Info("Exception logged " + e);
            }
        }

        //Function for get the date parameters.
        public virtual string[] GetDateParameters(string date1)
        {
            string[] Datepars = appHandle.GetDateParameters(date1);
            return Datepars;

        }

        /// <summary>
        /// This function is used to calculate interest accrued for given accrual calculation method.
        /// <param name= "Principal amount/Ledger balnce"></param> 
        /// <param name= "Rate of Interest"></param>
        /// <param name= "Interest Accrual Calculation method"></param>
        /// <param name= "System Date"></param>
        /// <param name= "No.of days to calculate compounded accrual"></param>
        /// <returns>intaccrued</returns> 
        /// <example>calculateaccruedinterest(10000,9,"Actual/Standard (31/360)","02/16/2012","350");<example>
        public virtual double calculateaccruedinterest(int principalAmount, int intRate, string accrualMethod, string date, string numberofDays = null)
        {
            double intaccrued = 0;
            try
            {
                string lastdate = WebCSRPageFactory.WebCSRMasterPage.GetMonthLastDate(date);
                string[] dateparam = WebCSRPageFactory.WebCSRMasterPage.GetDateParameters(lastdate);
                string DIY = "360";
                string ACCRUAL_CALC_METHOD = null;
                if (accrualMethod.Equals("00 - Standard/Standard  (30/360)"))
                    ACCRUAL_CALC_METHOD = "0";
                if (accrualMethod.Equals("Standard/Actual (30/365,6)"))
                    ACCRUAL_CALC_METHOD = "1";
                if (accrualMethod.Equals("Standard/365 (30/365)"))
                    ACCRUAL_CALC_METHOD = "3";
                if (accrualMethod.Equals("Actual/Standard (31/360)"))
                    ACCRUAL_CALC_METHOD = "10";
                if (accrualMethod.Equals("Actual/Actual (31/365,6)"))
                    ACCRUAL_CALC_METHOD = "11";
                if (accrualMethod.Equals("Actual/365 (31/365)"))
                    ACCRUAL_CALC_METHOD = "13";
                if (accrualMethod.Equals("Standard/Actual (30/365,6)"))
                    ACCRUAL_CALC_METHOD = "1";
                if (accrualMethod.Equals("Continuous/Standard"))
                    ACCRUAL_CALC_METHOD = "20";
                if (accrualMethod.Equals("Continuous/Actual"))
                    ACCRUAL_CALC_METHOD = "21";
                if (accrualMethod.Equals("Continuous/365"))
                    ACCRUAL_CALC_METHOD = "23";


                switch (ACCRUAL_CALC_METHOD)
                {
                    case "1":
                        if (WebCSRPageFactory.WebCSRMasterPage.IsLeapYear(Int32.Parse(dateparam[2])))
                            DIY = "366";
                        else
                            DIY = "365";
                        break;
                    case "11":
                        if (WebCSRPageFactory.WebCSRMasterPage.IsLeapYear(Int32.Parse(dateparam[2])))
                            DIY = "366";
                        else
                            DIY = "365";
                        break;
                    case "21":
                        if (WebCSRPageFactory.WebCSRMasterPage.IsLeapYear(Int32.Parse(dateparam[2])))
                            DIY = "366";
                        else
                            DIY = "365";
                        break;
                    case "3":
                        DIY = "365";
                        break;
                    case "13":
                        DIY = "365";
                        break;
                    case "23":
                        DIY = "365";
                        break;
                }


                double inp1 = 0;
                double inp2 = 0;
                switch (ACCRUAL_CALC_METHOD)
                {

                    case "0":
                        intaccrued = principalAmount * (intRate / 100) / (12 / Int32.Parse(dateparam[0]));
                        break;
                    case "1":
                        intaccrued = principalAmount * (intRate / 100 * 360) / (12 / Int32.Parse(DIY) / Int32.Parse(dateparam[0]));
                        break;
                    case "3":
                        intaccrued = principalAmount * (intRate / 100 * 360) / (12 / Int32.Parse(DIY) / Int32.Parse(dateparam[0]));
                        break;
                    case "10":
                        intaccrued = principalAmount * (intRate / 100) / (Int32.Parse(DIY));
                        break;
                    case "11":
                        intaccrued = (principalAmount * intRate) / (Int32.Parse(DIY) * 100);
                        break;
                    case "13":
                        intaccrued = principalAmount * (intRate / 100) / (Int32.Parse(DIY));
                        break;
                    case "20":
                        inp1 = principalAmount * ((1 + intRate) / 100);
                        inp2 = ((Int32.Parse(numberofDays) / Int32.Parse(DIY)) - principalAmount);
                        intaccrued = Math.Pow(inp1, inp2);
                        break;
                    case "21":
                        inp1 = principalAmount * ((1 + intRate) / 100);
                        inp2 = ((Int32.Parse(numberofDays) / Int32.Parse(DIY)) - principalAmount);
                        intaccrued = Math.Pow(inp1, inp2);
                        break;
                    case "23":
                        inp1 = principalAmount * ((1 + intRate) / 100);
                        inp2 = ((Int32.Parse(numberofDays) / Int32.Parse(DIY)) - principalAmount);
                        intaccrued = Math.Pow(inp1, inp2);
                        break;

                }
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return intaccrued;
        }

        /// <summary>
        /// This method is used to Check Label Values in New Window by Clicking Link in Table.
        /// <param name= "Table"></param> 
        /// <param name= "linkname"></param>
        /// <param name= "Refervalues"></param>
        /// <param name="List<string> LabelNames"></param> 
        /// <param name="List<string> LabelValues"></param>  
        /// <returns></returns>       
        ///  LabelNames.Add("Billing Date:");
        ///  LabelNames.Add("Interest Rate:");
        ///  LabelNames.Add("Minimum Finance Charge:");
        ///  LabelValues.Add("03/30/2015");
        ///  LabelValues.Add("15.00000%");
        ///  LabelValues.Add("0.00");
        /// <example>CheckLabelValuesinNewWindowbyClickingLinkinTable(BillingStatementPage.tblBillingStatement,"03/30/2015","Billing Date;" + FirstBillingDate + ";Due Date;" + FirstDueDate,LabelNames,LabelValues);<example>
        public virtual void CheckLabelValuesinNewWindowbyClickingLinkinTable(string Table, string linkname, string Refervalues, List<string> LabelNames, List<string> LabelValues)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkInTable(Table, linkname, Refervalues);
                for (int i = 0; i < LabelNames.Count; i++)
                {
                    string OutPutValue = GetCellValueByLabel(LabelNames[i]);
                    comparestringvalues(LabelValues[i], OutPutValue);
                }
                WebCSRPageFactory.WebCSRMasterPage.ClickObject("Xpath;//span[contains(@class,'closethick')]");
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to Get Label Values in New Window by Clicking Link in Table.
        /// <param name= "Table"></param> 
        /// <param name= "linkname"></param>
        /// <param name= "Refervalues"></param>
        /// <param name="List<string> LabelNames"></param> 
        /// <returns>List<string></returns>       
        ///  LabelNames.Add("Billing Date:");
        ///  LabelNames.Add("Interest Rate:");
        ///  LabelNames.Add("Minimum Finance Charge:");
        /// <example>GetLabelValuesinNewWindowbyClickingLinkinTable(BillingStatementPage.tblBillingStatement,"03/30/2015","Billing Date;" + FirstBillingDate + ";Due Date;" + FirstDueDate,LabelNames);<example>
        public virtual List<string> GetLabelValuesinNewWindowbyClickingLinkinTable(string Table, string linkname, string Refervalues, List<string> LabelNames)
        {
            List<string> LabelValues = null;
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkInTable(Table, linkname, Refervalues);
                for (int i = 0; i < LabelNames.Count; i++)
                {
                    string OutPutValue = GetCellValueByLabel(LabelNames[i]);
                    LabelValues.Add(LabelNames[i] + "-" + OutPutValue);
                }
                WebCSRPageFactory.WebCSRMasterPage.ClickObject("Xpath;//span[contains(@class,'closethick')]");
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
            return LabelValues;
        }

        /// <summary>
        /// This method is used to Navigate to any edit page by selecting radiobutton in Table.
        /// <param name= "Table"></param> 
        /// <param name= "Refervalues"></param>
        /// <param name= "FieldValues"></param>
        /// <returns></returns> 
        /// FieldValues.Add(AddUnpaidPaymentsPage.txtPaymentRecordDueDate + "|field|03/30/2015");
        /// FieldValues.Add(AddUnpaidPaymentsPage.txtPrincipalInterestUnpaid + "|field|200");
        /// <example>AddPaymentinAddUnpaidPaymentsPage(UnpaidPaymentPage.unpaidtable,"Due Date;" + systemdate3 + ";Total;868.56",FieldValues);<example>
        public virtual void AddPaymentinAddUnpaidPaymentsPage(string Table, string Refervalues, List<string> FieldValues, string message = null)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectRadioButtoninTable(Table, Refervalues);
                WebCSRPageFactory.WebCSRMasterPage.ClickOnAddButton();
                if (message != null)
                    UpdateInformationInWebCSRSpecifiedPage(FieldValues, message);
                else
                    UpdateInformationInWebCSRSpecifiedPage(FieldValues, Data.Get("GLOBAL_INFORMATION_UPDATED"));
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        /// <summary>
        /// This method is used to get last date of the month.
        /// <param name= "Date"></param> 
        /// <returns>string</returns> 
        /// <example>GetMonthLastDate("12/02/2018");<example>
        public virtual string GetMonthLastDate(string Date)
        {
            string Lastdate = null;
            try
            {
                Lastdate = WebCSRPageFactory.WebCSRMasterPage.GetMonthLastDate(Date);
            }
            catch (Exception e) { Report.Info("Exception Logged:" + e); }
            return Lastdate;
        }

        /// <summary>
        /// This method is used to Check Specified Data Available In Table.
        /// </summary>
        /// <param name="sRefValue"></param>
        /// <param name="sTableName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckSpecifiedDataAvailableInTable(Date;10/11/2010;Description;Debit,tableXpath);
        /// </example>
        public virtual void CheckSpecifiedDataAvailableInTable(string sRefValue, string sTableName)
        {
            bool bCheck = false;
            try
            {
                bCheck = WebCSRPageFactory.WebCSRMasterPage.CheckSpecifiedDataAvailableInTable(sRefValue, sTableName);
                if (bCheck)
                    Report.Pass("Specified Data exists in table", "ArtMessage", "True", appHandle);
                else
                    Report.Fail("Specified Data does not exists in table", "ArtMessage", "True", appHandle);

            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to Check Specified Not Data Available In Table.
        /// </summary>
        /// <param name="sRefValue"></param>
        /// <param name="sTableName"></param>
        /// <returns></returns> 
        /// <example>
        /// Application.WebCSR.CheckSpecifiedDataNotAvailableInTable(Date;10/11/2010;Description;Debit,tableXpath);
        /// </example>
        public virtual void CheckSpecifiedDataNotAvailableInTable(string sRefValue, string sTableName)
        {
            bool bCheck = false;
            try
            {
                bCheck = WebCSRPageFactory.WebCSRMasterPage.CheckSpecifiedDataNotAvailableInTable(sRefValue, sTableName);
                if (bCheck)
                    Report.Pass("Specified Data does not exists in table", "ArMessage", "True", appHandle);
                else
                    Report.Fail("Specified Data exists in table", "ArMessage", "True", appHandle);

            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }

        /// <summary>
        /// This method is used to get Specified Data Available In Table in New Window by Clicking Link in Table.
        /// <param name= "LinkTableName"></param> 
        /// <param name= "linkname"></param>
        /// <param name= "slinkRefValue"></param>
        /// <param name= "sTableName"></param> 
        /// <param name= "sRefValue"></param>
        /// <returns>string</returns> 
        /// <example>
        /// string Date = GetTableValueinNewWindowbyClickingLinkinTable(BillingStatementPage.tblBillingStatement, Sysdatem12d, "Billing Date;" + Sysdatem12d + ";Due Date;" + Sysdatem10d,tableXpath, Date;Description;Debit);
        /// </example>
        public virtual string GetTableValueinNewWindowbyClickingLinkinTable(string LinkTableName, string linkname, string slinkRefValue, string sTableName, string sRefValue)
        {
            string val = null;
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkInTable(LinkTableName, linkname, slinkRefValue);
                val = WebCSRPageFactory.WebCSRMasterPage.GetSpecifiedDataAvailableInTable(sTableName, sRefValue);
                if (val != null)
                    Report.Info("Specified Data is fetched from table", "Assage", "True", appHandle);
                else
                    Report.Fail("Specified Reference Values in table or table does not exits", "Assage", "True", appHandle);

                WebCSRPageFactory.WebCSRMasterPage.ClickObject("Xpath;//span[contains(@class,'closethick')]");
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            return val;
        }

        /// <summary>
        /// This method is used to get Next Business Date.
        /// <param name= "Date"></param> 'should be in mm/dd/yyyy formate
        /// <returns>Next Business Day</returns> 
        /// <example>
        /// string outDate = GetNextBusinessDate(Date);
        /// </example>
        public virtual string GetNextBusinessDate(string Date)
        {
            string outdate = null;
            try
            {
                string[] datpar = Date.Split('/');
                int year = Int32.Parse(datpar[2]);
                int month = Int32.Parse(datpar[0]);
                int day = Int32.Parse(datpar[1]);
                DateTime dateval = new DateTime(year, month, day);
                string dayName = dateval.ToString("dddd");
                if (dayName.ToUpper() == "SUNDAY")
                    outdate = CalculateNewDate(Date, "d", 1);
                else if (dayName.ToUpper() == "SATURDAY")
                    outdate = CalculateNewDate(Date, "d", 2);
                else
                    outdate = Date;
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
            return outdate;
        }

        /// <summary>
        /// This method is used to Check Specified Data Available In Table in New Window by Clicking Link in Table.
        /// <param name= "LinkTableName"></param> 
        /// <param name= "linkname"></param>
        /// <param name= "slinkRefValue"></param>
        /// <param name="List<string> TableNameandRefValues"></param>   
        ///  TableNameandRefValues.Add("ColName;This Billing;Principal;2000|"+BillingStatementDetailPage.tblPrincipalBillingStatementDetail"); '(Refrence Values| Table Xpath)
        ///  TableNameandRefValues.Add("Principal;2000;Intrest;200|"+BillingStatementDetailPage.tblPrincipalBillingStatementDetail");
        ///  TableNameandRefValues.Add("Principal;2000;Escrow;0.00|"+BillingStatementDetailPage.tblPrincipalBillingStatementDetail");
        /// <returns></returns> 
        /// <example>
        /// CheckTableValuesinNewWindowbyClickingLinkinTable(BillingStatementPage.tblBillingStatement, Sysdatem12d, "Billing Date;" + Sysdatem12d + ";Due Date;" + Sysdatem10d,TableNameandRefValues);
        /// </example>
        public virtual void CheckTableValuesinNewWindowbyClickingLinkinTable(string LinkTableName, string linkname, string slinkRefValue, List<string> TableNameandRefValues)
        {
            try
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectLinkInTable(LinkTableName, linkname, slinkRefValue);
                for (int i = 0; i < TableNameandRefValues.Count; i++)
                {
                    string[] OutPutValue = TableNameandRefValues[i].Split('|');
                    CheckSpecifiedDataAvailableInTable(OutPutValue[0], OutPutValue[1]);
                }
                WebCSRPageFactory.WebCSRMasterPage.ClickObject("Xpath;//span[contains(@class,'closethick')]");
            }
            catch (Exception e) { Report.Info("Exception logged : " + e); }
        }


        public virtual bool VerifyCustomerIntegrity(string ItemToBeSelected)
        {
            bool Result = false;
            if (WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown(ItemToBeSelected))
            {
                Report.Info(ItemToBeSelected + " is selected .", "gotodropdownvalue", "true", appHandle);
            }

            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
            WebCSRPageFactory.CustomerSearchPage.NavigateToCustomerVerificationPage();
            if (WebCSRPageFactory.CustomerSearchPage.VerifyCustomerInformationIntegrity())
            {
                Result = true;
                Report.Pass("Customer Verification is successfully completed as Message : # Account passes integrity verification without error. # is displayed as expected.", "custintegrity", "true", appHandle);
            }
            else
            {
                Report.Fail("Customer Verification is failed as Message : # Account passes integrity verification without error. # is not displayed as expected.", "custintegrity", "true", appHandle);
            }
            return Result;
        }
        /// <summary>
        /// This method is used to create a Trust Customer. string TrustType can be RT - Revocable Trust OR  IR - Irrevocable Trust .string PersonalCustomerNumber need to be passed as Personal customer .bool AddBeneficiaries need to be true or false .int NumberOfBenefeciaries need to be passed if bool AddBeneficiary is marked as true . string BeneficiaryClassificationType can be NC - Non-Profit or Charity OR I - Individual . string ContigentNonContigentOrderWithHashDelimiter need to passed as Example : Data.Get("Contigent")+"#"+Data.Get("NonContigent")+"#"+Data.Get("Contigent") .Note: Number of Contigent and NonContigent should match with number of beneficiaries.
        /// </summary>
        /// <param name="TrustType"></param>
        /// <param name="PersonalCustomerNumber"></param>
        /// <param name="AddBeneficiaries"></param>
        /// <param name="NumberOfBenefeciaries"></param>
        /// <param name="BeneficiaryClassificationType"></param>
        /// <param name="ContigentNonContigentOrderWithHashDelimiter"></param>
        /// <returns>It returns Trust customer number.</returns>
        public virtual string CreateTrustCustomer(string TrustType, string PersonalCustomerNumber, bool AddBeneficiaries, int NumberOfBenefeciaries = 0, string BeneficiaryClassificationType = "", string ContigentNonContigentOrderWithHashDelimiter = "")
        {
            string TrustCustNo = "";
            string TrustTaxID = "";
            WebCSRPageFactory.CustomerSearchPage.NavigateToCreateTrustCustomerPage();
            if (TrustType.Equals(((string)Data.Get("RT - Revocable Trust"))))
            {
                TrustTaxID = WebCSRPageFactory.CreateTrustCustomerPage.EnterDataForRevocableTrustType(PersonalCustomerNumber);
                Report.Info("Revocable trust data is entered.", "revocabledata", "true", appHandle);
            }
            if (TrustType.Equals(((string)Data.Get("IR - Irrevocable Trust"))))
            {
                TrustTaxID = WebCSRPageFactory.CreateTrustCustomerPage.EnterDataForIrrevocableTrustType(PersonalCustomerNumber);
                Report.Info("Irrevocable trust data is entered.", "revocabledata", "true", appHandle);
            }
            if (AddBeneficiaries)
            {
                WebCSRPageFactory.CreateTrustCustomerPage.EnterBeneficiaryDetails(NumberOfBenefeciaries, BeneficiaryClassificationType, ContigentNonContigentOrderWithHashDelimiter);
                WebCSRPageFactory.CreateTrustCustomerPage.ClickonSubmitbutton();
            }

            WebCSRPageFactory.CreateTrustCustomerPage.ClickonContinuebutton();
            WebCSRPageFactory.CreateTrustCustomerPage.ClickonSubmitbutton();
            if (WebCSRPageFactory.CreateTrustCustomerPage.VerifyTrustCustomerCreationSuccess())
            {
                Report.Pass("Trust Customer application is created successfully", "TrustCustCreate", "true", appHandle);
                if (TrustType.Equals(((string)Data.Get("RT - Revocable Trust"))))
                {
                    TrustCustNo = WebCSRPageFactory.CustomerSearchPage.get_Trust_customer_number(TrustTaxID);
                }
                if (TrustType.Equals(((string)Data.Get("IR - Irrevocable Trust"))))
                {
                    TrustCustNo = WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("GLOBAL_SEARCHTYPE_TAXID"), TrustTaxID);
                }
                if (!string.IsNullOrEmpty(TrustCustNo))
                {
                    Report.Pass("Trust customer number is captured as: " + TrustCustNo, "custpersonal", "true", appHandle);
                }
            }
            else
            {
                Report.Fail("Trust Customer application is not created due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "CreateTrustcustFail", "true", appHandle);
            }
            return TrustCustNo;
        }
        /// <summary>
        /// This method is used to create Saving,Loan,CD,DDA account. 
        /// The method accepts three mandatory arguments and three optional arguments.
        /// PrimaryCustomerNumber : Mandatory argument . This is the customer number for which account will be created.
        /// Relationship : Mandatory argument. Single relationship Or Joint relationship. For joint relationships number of co-owners can be mentioned by Pipe(|) delimiter. Example: Joint|1 or Joint|2
        /// ProductType : Mandatory Argument : Savings or Loan or CD
        /// CustomerNumbersForAdditionalOwnerAddition:Optional Parameter . In case of Joint relationship accounts the customer numbers can be passed. If it is one customer pass it as single customer number.If it is more than one pass with Pipe(|) delimiter.  
        /// numberofAccounts : Optional parameter . By default it will be 1 .If we need to have more than one we need to pass the number.
        /// AccountDetailsWithSemicolonDelimiter- Optional parameter .By default it will be Empty (""). If account detail has to be passed then it has to be passed as .Example: Deposit amount|500.00;payment Frequency|1MAE
        /// </summary>
        /// <param name="PrimaryCustomerNumber"></param>
        /// <param name="Relationship"></param>
        /// <param name="ProductType"></param>
        /// <param name="CustomerNumbersForAdditionalOwnerAddition"></param>
        /// <param name="numberofAccounts"></param>
        /// <param name="AccountDetailsWithSemicolonDelimiter"></param>
        /// <returns>It returns account number. For single relationship it returns account number and </returns>
        /// <example>
        /// <code>
        /// Application.WebCSR.Create_Account("71",Data.Get("GLOBAL_RELATION_SINGLE"),Data.Get("GLOBAL_STAND_CSRPROD_DESC_350")
        /// </code>
        /// </example>
        public virtual string Create_Account(string PrimaryCustomerNumber, string Relationship, string ProductType, string CustomerNumbersForAdditionalOwnerAddition = "", int numberofAccounts = 1, string AccountDetailsWithSemicolonDelimiter = "", bool escrow = false, string EscrowDetailsSemicolonDelimiter = "")
        {
            string AccountNumber = "";
            string temptitle = appHandle.GetTitle();
            string CurrentValue_RealEstate_MortgageLoan = "";
            string temp = "";
            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            else if (temptitle.Contains(Data.Get("Verify Customer"))) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            if (WebCSRPageFactory.CreateAccountPage.VerifyCustomerNumberForAcctCreation(PrimaryCustomerNumber) == false)
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            WebCSRPageFactory.CustomerSearchPage.NavigateToCreateAccountPage();
            Report.Info("Create Account Customer Information page is displayed.", "custinfoacctcreate", "true", appHandle);
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateAccountPage.SelectRelationshipRadiobutton_AccountCreation(Relationship);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.VerifyOwnerPageLoadsAccountCreation();
            WebCSRPageFactory.CreateAccountPage.UpdateOwnerDetails(Relationship, CustomerNumbersForAdditionalOwnerAddition);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.SelectProductAndNumberOfAccounts(ProductType, numberofAccounts);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            if (ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_700")) || ProductType.Equals("CFPB_ESCROW_751"))
            {
                if (string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                 && numberofAccounts == 1)
                {
                    CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    AccountDetailsWithSemicolonDelimiter = Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan;
                }
                else if (numberofAccounts > 1 && string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter))
                {
                    CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan;
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Term"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
                && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Payment Frequency"))
                )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts == 1
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    if (AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount")))
                    {
                        CurrentValue_RealEstate_MortgageLoan = AccountDetailsWithSemicolonDelimiter.Split(new string[] { "Amount|" }, StringSplitOptions.None)[1].Split(';')[0];
                        if (CurrentValue_RealEstate_MortgageLoan.Contains(","))
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Replace(",", "").Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }
                        }
                        else
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                    }
                    else
                    {
                        CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan;
                }
                else if (numberofAccounts > 1
                && AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    if (AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount")))
                    {
                        CurrentValue_RealEstate_MortgageLoan = AccountDetailsWithSemicolonDelimiter.Split(new string[] { "Amount|" }, StringSplitOptions.None)[1].Split(';')[0];
                        if (CurrentValue_RealEstate_MortgageLoan.Contains(","))
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Replace(",", "").Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                        else
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                    }
                    else
                    {
                        CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Replace(Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property"), Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan);
                }
                else if (numberofAccounts == 1
                && AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    if (AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount")))
                    {
                        CurrentValue_RealEstate_MortgageLoan = AccountDetailsWithSemicolonDelimiter.Split(new string[] { "Amount|" }, StringSplitOptions.None)[1].Split(';')[0];
                        if (CurrentValue_RealEstate_MortgageLoan.Contains(","))
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Replace(",", "").Split('.')[0];

                            }

                        }
                        else
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                    }
                    else
                    {
                        CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Replace(Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property"), Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan);
                }
            }
            if (ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"))
            || ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_600"))
            || ProductType.Equals(Data.Get("Commercial Loan 800"))
            || ProductType.Equals(Data.Get("Credit Balance Loan 900")))
            {
                if (string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                  && numberofAccounts == 1)
                {
                    AccountDetailsWithSemicolonDelimiter = Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured");
                }
                else if (numberofAccounts > 1 && string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter))
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Term"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
                && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Payment Frequency"))
                )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts == 1
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured");
                }

            }
            if (ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_350")))
            {
                if (string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && numberofAccounts == 1)
                {
                    AccountDetailsWithSemicolonDelimiter = Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_500") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                }
                else if (numberofAccounts > 1 && string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter))
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_500") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
                && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Opening Deposit"))
                )

                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_500");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Term"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }

            }


            WebCSRPageFactory.CreateAccountPage.EnterAccountDetails(AccountDetailsWithSemicolonDelimiter, numberofAccounts, ProductType);
            if (escrow == true)
            {
                WebCSRPageFactory.AddEscrowDetailsPage.ClickOnIncludeEscorwCheckBox(escrow);
                WebCSRPageFactory.AddEscrowDetailsPage.ClickOnAddButton();
                WebCSRPageFactory.AddEscrowDetailsPage.CalculatePeriodicEscrowPayment(EscrowDetailsSemicolonDelimiter);

            }
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();
            int cnt = appHandle.GetRowCountfromList("Xpath;//*[@class='buttonWrapper']");
            for (int a = 1; a <= cnt; a++)
            {
                temp = temp + appHandle.GetSpecifiedObjectAttribute("Xpath;//*[@class='buttonWrapper']/*[" + a + "]", "value");
            }

            if (temp.Contains("Continue"))
            {
                WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            }
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();


            if (WebCSRPageFactory.CreateAccountPage.VerifyAccountCreationSuccess())
            {
                Report.Pass("Account creation application is successfully processed.", "accountcreationapplication", "true", appHandle);
            }
            else
            {
                Report.Fail("Account creation  application is not created due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "CreateAccountCreationFail", "true", appHandle);
            }
            AccountNumber = WebCSRPageFactory.CreateAccountPage.GetAccountNumbersFromApplicationSuccessPage(numberofAccounts);
            WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber, numberofAccounts);

            return AccountNumber;

        }
        /// <summary>
        /// This method is used to select link in WebCSR menu links by its menu name and Link under menu. For Example Input argument: General AccountServices|Restrictions
        /// </summary>
        /// <param name="sMenuNameLinkNameDelimitedByPipe"></param>
        public virtual void ClickLinkFromMenuItem(string sMenuNameLinkNameDelimitedByPipe)
        {
            WebCSRPageFactory.BankingCenterPage.ClickLinkFromMenuItem(sMenuNameLinkNameDelimitedByPipe);
        }
        public virtual void AddAccountRestrictions(string AccountNumber, string RestrictionType, string Startdate = "", string ExpirationDate = "", string Comment = "")
        {
            if (!appHandle.GetTitle().Contains("Restrictions"))
            {
                this.GetAccount(AccountNumber);
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Restrictions"));
            }
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Restrictions"));
            WebCSRPageFactory.AccountRestrictionPage.SelectAccountfromAccountsDropdown(AccountNumber);
            WebCSRPageFactory.AccountRestrictionPage.ClickOnAddButton();
            WebCSRPageFactory.AccountRestrictionPage.EnterRestrictionDetails(RestrictionType, Startdate, ExpirationDate, Comment);
            Report.Info("Restriction details are entered.", "addrestriction", "true", appHandle);
            WebCSRPageFactory.AccountRestrictionPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.AccountRestrictionPage.VerifyRestrictionCreationSuccessful())
            {
                Report.Pass(RestrictionType + " restriction is added for Account successfully.", "restrictionadded", "true", appHandle);
            }
            else
            {
                Report.Fail("Restriction is not added due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "acctresticrionaddFail", "true", appHandle);
            }
        }
        public virtual bool VerifyAuthorizationMessage(string sMessage)
        {
            bool result = false;
            string smessage1 = sMessage;
            string AuthRunTimeMsg = "";
            string temp = "";
            string[] arr = null;
            if (sMessage.Contains("-"))
            {
                if (char.IsNumber(sMessage.Split('-')[0].Trim(), 1))
                {
                    sMessage = sMessage.Split('-')[1].Trim();
                }
            }
            int Counter = 0;
            if (sMessage.Contains("|"))
            {
                arr = sMessage.Split('|');
                for (int i = 0; i < arr.Length; i++)
                {
                    AuthRunTimeMsg = "XPath;//*[text()='Authorize Each Restriction']/following-sibling::*/descendant::*[contains(text(),'" + arr[i] + "')]";
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(AuthRunTimeMsg))
                    {
                        Counter++;
                        temp = temp + " , " + appHandle.GetObjectText(AuthRunTimeMsg);
                    }
                }
                if (Counter == arr.Length)
                {
                    temp = temp.Substring(3, temp.Length - 3);
                    Report.Pass(temp + " are found in Authorization override page", "authoverridepverification", "true", appHandle);
                }
            }
            else
            {
                AuthRunTimeMsg = "XPath;//*[text()='Authorize Each Restriction']/following-sibling::*/descendant::*[contains(text(),'" + sMessage + "')]";
                if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(AuthRunTimeMsg))
                {
                    result = true;
                    Report.Pass(appHandle.GetObjectText(AuthRunTimeMsg) + " is found in Authorization override page", "authoverridepverification", "true", appHandle);
                }
            }

            return result;
        }

        public virtual void TrasferFundsFundingServices(string sFromAccount, string sToAccount, string sAmount, string sStartDate = null, string sFrequency = null, string sEndDate = null, bool Override = false, string sUSerID = "", string sPassword = "", string OverrideTranMsgs = "")
        {
            int flag = 0;
            int daysdiff = 0;
            this.LoadAccountSummaryPage(sFromAccount);
            if (!appHandle.GetTitle().Contains(Data.Get("Transfer Funds")))
            {
                this.ClickLinkFromMenuItem(Data.Get("Funding Services") + "|" + Data.Get("Transfer Funds"));
            }
            WebCSRPageFactory.FundTransferPage.EnterFundTransferDetails(sFromAccount, sToAccount, sAmount);
            WebCSRPageFactory.FundTransferPage.EnterFundTermDetails(sStartDate, sFrequency, sEndDate);

            if (string.IsNullOrEmpty(sAmount)
             || sAmount.Contains("-"))
            {
                flag = 1;
                WebCSRPageFactory.FundTransferPage.ClickOnSubmitBUtton();
            }
            if (!string.IsNullOrEmpty(sEndDate))
            {
                daysdiff = appHandle.GetDaysDifferenceInTwoDates(sEndDate, this.GetApplicationDate(), "INTERVAL_DAYS");
                if (daysdiff < 1)
                {
                    flag = 1;
                    WebCSRPageFactory.FundTransferPage.ClickOnSubmitBUtton();
                }
            }

            if (flag == 0)
            {
                WebCSRPageFactory.FundTransferPage.ClickOnSubmitBUtton();
                WebCSRPageFactory.FundTransferPage.ClickOnSubmitBUtton();
            }
            if (Override)
            {
                if (!string.IsNullOrEmpty(OverrideTranMsgs))
                {
                    this.VerifyAuthorizationMessage(OverrideTranMsgs);
                }
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.EnterUserCredentials(sUSerID, sPassword);
                Report.Info("User credentials are entered for Authorization override.", "userEntry", "true", appHandle);
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.ClickOnOverrideButton();
                WebCSRPageFactory.FundTransferPage.ClickOnSubmitButton_OverrideTransaction();
            }
            this.VerifyCustomerSearchLinkIsLoaded();
        }

        public virtual void ClickOnAuthorizationCancelButton()
        {
            WebCSRPageFactory.FundTransferPage.ClickOnAuthorizationCancelButton();
        }
        public virtual bool VerifyCustomerSearchLinkIsLoaded()
        {
            return WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
        }
        public virtual void EnterContactInformationInCustomerInformationPage(string HomePhNo = null, string BusinessPhNumber = null, string Extension = null, string FaxNumber = null, string emailId = null)

        {

            WebCSRPageFactory.CustomerInformationPage.EnterContactInformation(HomePhNo, BusinessPhNumber, Extension, FaxNumber, emailId);
        }
        public virtual void EnterServiceInfomationInCustomerInformationPage()
        {
            WebCSRPageFactory.CustomerInformationPage.EnterServicingInformation();
        }
        public virtual bool VerifyEnterContactInfoServiceInfoInCustomerInformation(string HomePhNo = null, string BusinessPhNumber = null, string Extension = null, string FaxNumber = null, string emailId = null)
        {
            bool result = false;
            WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
            this.EnterContactInformationInCustomerInformationPage(HomePhNo, BusinessPhNumber, Extension, FaxNumber, emailId);
            this.EnterServiceInfomationInCustomerInformationPage();
            WebCSRPageFactory.CustomerInformationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.ValidateCustomerInfoUpdateMSG())
            {
                Report.Pass("Customer Information is successfully updated with Message :: " + Data.Get("GLOBAL_CUSTOMER_INFORMATION_UPDATED"));
            }
            else
            {
                Report.Fail("Customer Information is notsuccessfully updated. Please check the input.");
            }
            return result;
        }

        public virtual bool VerifyMailAddrInAccountInformation()
        {
            Application.WebCSR.NavigateToAccountSummaryPage();
            Application.WebCSR.ClickOnTitleTab();
            bool res = false;
            if (WebCSRPageFactory.AccountInformationPage.Validate_MaillingAddr())
            {
                res = true;
            }
            if (res)
            {
                Report.Pass("Validated Mailing address succesfully", "ValidateMailingAddress", "true", appHandle);
            }
            else
            {
                Report.Fail("Not able to validate Mailing Address", "ValidateMailingAddress Fail", "true", appHandle, true);
            }
            return res;
        }

        public virtual void ValidateServiceItemsMessage(string DropDownValuesSeperatedByPipeDelimiter)
        {
            if (WebCSRPageFactory.ServiceItemAssignmentPage.ValidateNoServiceItemsFound(DropDownValuesSeperatedByPipeDelimiter))
            {
                Report.Pass("Validated Service Item Message succesfully", "ValidateServiceItemsMessage", "true", appHandle);
            }
            else
            {
                Report.Fail("Not able to validate Service Item Message", "ValidateServiceItemsMessage Fail", "true", appHandle, true);
            }
        }

        public virtual Boolean NavigateAndValidateCreditLimitLabels(string TitleValue)
        {
            Boolean Check = false;
            WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
            WebCSRPageFactory.CustomerInformationPage.SelectTab(TitleValue);
            WebCSRPageFactory.CustomerInformationPage.SelectSubTab(Data.Get("Customer Limits"));
            if (WebCSRPageFactory.CustomerInformationPage.VerifyLimitGroupHeaderName())
            {
                Report.Pass("Validating CreditLimit Labels", "NavigateAndValidateCreditLimitLabels", "true", appHandle);
            }
            WebCSRPageFactory.CustomerInformationPage.SelectSubTab(Data.Get("Limits List"));
            if (WebCSRPageFactory.CustomerInformationPage.VerifyLimitGroupHeaderName())
            {
                Report.Pass("Validating CreditLimit Labels", "NavigateAndValidateCreditLimitLabels", "true", appHandle);
            }
            else
            {
                Report.Fail("Not able to validate CreditLimit Labels", "NavigateAndValidateCreditLimitLabels Fail", "true", appHandle, true);
            }
            return Check;
        }
        public virtual void VerifyAccountIntegrity(string AccountNumber, string message = "")
        {
            GetAccount(AccountNumber);
            if (appHandle.GetTitle().Contains("Customer Search"))
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Account Verification"));
            WebCSRPageFactory.AccountVerificationPage.SelectAccountFromAccountsDropdown(AccountNumber);
            if (!string.IsNullOrEmpty(message))
            {
                if (WebCSRPageFactory.AccountVerificationPage.VerifyAccountInformationIntegrity(message))
                {
                    Report.Pass(message + " is successfully found. ", "AccountVerificationStatusPass", "true", appHandle);
                }
                else
                {
                    Report.Fail(message + " is not  found. ", "AccountVerificationStatusFail", "true", appHandle, true);
                }


            }
            else
            {
                if (WebCSRPageFactory.AccountVerificationPage.VerifyAccountInformationIntegrity())
                {
                    Report.Pass("Account integrity verification is successfully completed.", "AccountVerificationStatusPass", "true", appHandle);
                }
                else
                {
                    Report.Fail("Account integrity verification is failed", "AccountVerificationStatusFail", "true", appHandle, true);
                }
            }
        }


        public virtual void VerifyAmountFieldsWithInvalidInputTransactionProcessingLoan(string LabelNamePipeLineInputValue, string sMSGTexts)
        {
            string reportingmsg = "";

            WebCSRPageFactory.TransactionProcessingPage.EnterDataInTransactionProcessingLoanAccount(LabelNamePipeLineInputValue);
            WebCSRPageFactory.TransactionProcessingPage.ClickOnSubmitButton();

            if (!sMSGTexts.Contains("|"))
            {
                reportingmsg = sMSGTexts;
            }
            else
            {
                reportingmsg = string.Join(",", sMSGTexts.Split('|'));
            }
            if (WebCSRPageFactory.TransactionProcessingPage.VerifyMessageInTransactionProcessingPage(sMSGTexts))
            {
                Report.Pass(reportingmsg + " is / are displayed as expected.", "passmsg", "true", appHandle);
            }
            else
            {
                Report.Fail(reportingmsg + " is / are not displayed as expected.", "Failmsg", "true", appHandle, true);
            }
        }
        public virtual void VerifyAmountFieldsWithValidInputTransactionProcessingLoan(string LabelNamePipeLineInputValue, string sMSGTexts)
        {
            string reportingmsg = "";

            WebCSRPageFactory.TransactionProcessingPage.EnterDataInTransactionProcessingLoanAccount(LabelNamePipeLineInputValue);
            WebCSRPageFactory.TransactionProcessingPage.ClickOnSubmitButton();

            if (!sMSGTexts.Contains("|"))
            {
                reportingmsg = sMSGTexts;
            }
            else
            {
                reportingmsg = string.Join(",", sMSGTexts.Split('|'));
            }
            if (WebCSRPageFactory.TransactionProcessingPage.VerifyMessageInTransactionProcessingPage(sMSGTexts))
            {
                Report.Pass(reportingmsg + " is / are displayed as expected.", "passmsg", "true", appHandle);
            }
            else
            {
                Report.Fail(reportingmsg + " is / are not displayed as expected.", "Failmsg", "true", appHandle, true);
            }
        }
        public virtual void LoadAccountSummaryPage(string AccountNumber)
        {
            if (appHandle.GetTitle().Contains("Overview") &&
            WebCSRPageFactory.AccountOverviewPage.CheckAccountNumberInAccountOverviewPage(AccountNumber) == true)
            {

                WebCSRPageFactory.AccountOverviewPage.select_account_summary_tab();
            }
            else if (appHandle.GetTitle().Contains("Customer Search"))
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("Account Number"));
                this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_ACCOUNTLIST"));
                WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
                WebCSRPageFactory.AccountOverviewPage.select_account_summary_tab();
            }
            else
            {
                WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
                WebCSRPageFactory.AccountOverviewPage.select_account_summary_tab();
            }
        }

        public virtual void VerifyAccountCreationWithInvalidDataInAccountDetails(string PrimaryCustomerNumber, string Relationship, string ProductType, string CustomerNumbersForAdditionalOwnerAddition = "", int numberofAccounts = 1, string AccountDetailsWithSemicolonDelimiter = "", string sMSGTexts = "")
        {
            string temptitle = appHandle.GetTitle();
            string CurrentValue_RealEstate_MortgageLoan = "";
            string reportingmsg = "";

            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            else if (temptitle.Contains(Data.Get("Verify Customer"))) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            if (WebCSRPageFactory.CreateAccountPage.VerifyCustomerNumberForAcctCreation(PrimaryCustomerNumber) == false)
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            WebCSRPageFactory.CustomerSearchPage.NavigateToCreateAccountPage();
            Report.Info("Create Account Customer Information page is displayed.", "custinfoacctcreate", "true", appHandle);
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateAccountPage.SelectRelationshipRadiobutton_AccountCreation(Relationship);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.VerifyOwnerPageLoadsAccountCreation();
            WebCSRPageFactory.CreateAccountPage.UpdateOwnerDetails(Relationship, CustomerNumbersForAdditionalOwnerAddition);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.SelectProductAndNumberOfAccounts(ProductType, numberofAccounts);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            if (ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_700")))
            {
                if (string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                 && numberofAccounts == 1)
                {
                    CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    AccountDetailsWithSemicolonDelimiter = Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan;
                }
                else if (numberofAccounts > 1 && string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter))
                {
                    CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan;
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Term"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
                && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Payment Frequency"))
                )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts == 1
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    if (AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount")))
                    {
                        CurrentValue_RealEstate_MortgageLoan = AccountDetailsWithSemicolonDelimiter.Split(new string[] { "Amount|" }, StringSplitOptions.None)[1].Split(';')[0];
                        if (CurrentValue_RealEstate_MortgageLoan.Contains(","))
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Replace(",", "").Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                        else
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                    }
                    else
                    {
                        CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan;
                }
                else if (numberofAccounts > 1
                && AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    if (AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount")))
                    {
                        CurrentValue_RealEstate_MortgageLoan = AccountDetailsWithSemicolonDelimiter.Split(new string[] { "Amount|" }, StringSplitOptions.None)[1].Split(';')[0];
                        if (CurrentValue_RealEstate_MortgageLoan.Contains(","))
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Replace(",", "").Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                        else
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                    }
                    else
                    {
                        CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Replace(Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property"), Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan);
                }
                else if (numberofAccounts == 1
                && AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    if (AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount")))
                    {
                        CurrentValue_RealEstate_MortgageLoan = AccountDetailsWithSemicolonDelimiter.Split(new string[] { "Amount|" }, StringSplitOptions.None)[1].Split(';')[0];
                        if (CurrentValue_RealEstate_MortgageLoan.Contains(","))
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Replace(",", "").Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                        else
                        {
                            if (CurrentValue_RealEstate_MortgageLoan.Contains("."))
                            {
                                CurrentValue_RealEstate_MortgageLoan = CurrentValue_RealEstate_MortgageLoan.Split('.')[0];
                                CurrentValue_RealEstate_MortgageLoan = Int32.Parse(CurrentValue_RealEstate_MortgageLoan) * 2 + "";
                            }

                        }
                    }
                    else
                    {
                        CurrentValue_RealEstate_MortgageLoan = Data.Get("GLOBAL_AMOUNT_REQUESTED_20K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Replace(Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property"), Data.Get("Collateral Type") + "|" + Data.Get("10 - Real Estate Property") + "##" + CurrentValue_RealEstate_MortgageLoan);
                }
            }
            if (ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"))
            || ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_600"))
            || ProductType.Equals(Data.Get("Commercial Loan 800"))
            || ProductType.Equals(Data.Get("Credit Balance Loan 900")))
            {
                if (string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                  && numberofAccounts == 1)
                {
                    AccountDetailsWithSemicolonDelimiter = Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured");
                }
                else if (numberofAccounts > 1 && string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter))
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Term"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
                && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Payment Frequency"))
                )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts == 1
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("0 - Unsecured");
                }

            }
            if (ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_350")))
            {


                if (string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && numberofAccounts == 1)
                {
                    AccountDetailsWithSemicolonDelimiter = Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_500") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                }
                else if (numberofAccounts > 1 && string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter))
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_500") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
                && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Opening Deposit"))
                )

                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Opening Deposit") + "|" + Data.Get("GLOBAL_AMOUNT_REQUESTED_500");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Term"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }

            }

            WebCSRPageFactory.CreateAccountPage.EnterAccountDetails(AccountDetailsWithSemicolonDelimiter, numberofAccounts, ProductType);
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();
            if (string.IsNullOrEmpty(sMSGTexts) == false)
            {
                if (!sMSGTexts.Contains("|"))
                {
                    reportingmsg = sMSGTexts;
                }
                else
                {
                    reportingmsg = string.Join(",", sMSGTexts.Split('|'));
                }
                if (WebCSRPageFactory.TransactionProcessingPage.VerifyMessageInTransactionProcessingPage(sMSGTexts))
                {
                    Report.Pass(reportingmsg + " is / are displayed as expected.", "passmsg", "true", appHandle);
                }
                else

                {
                    Report.Fail(reportingmsg + " is / are not displayed as expected.", "Failmsg", "true", appHandle, true);
                }
            }
        }

        public virtual void UpdateAndVerifyTransactionAcceptanceEnrolledForAccountPositivePay(string AccountNumber)
        {
            string TransactionAcceptanceEnrolled_Before_Update = appHandle.GetObjectText("XPath;//*[contains(text(),'Transaction Acceptance Enrolled')]/following-sibling::*");
            Report.Info("Transaction Acceptance Enrolled is captured as : " + TransactionAcceptanceEnrolled_Before_Update, "capture", "true", appHandle);
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Service Management"));
            WebCSRPageFactory.CustomerServicesServiceManagementPage.ClickOnAddButtonForPositivePay(AccountNumber);
            if (WebCSRPageFactory.CustomerServicesServiceManagementPage.VerifyRemoveButtonAfterAddingPositivePay())
            {
                WebCSRPageFactory.CustomerServicesServiceManagementPage.ClickOnRefreshListButton();
            }
            if (WebCSRPageFactory.CustomerServicesServiceManagementPage.VerifyListRefreshSuccess())
            {
                Report.Info("Positive pay Service is added for the account : " + AccountNumber, "servicelistadd", "true", appHandle);
            }
            else
            {
                Report.Fail("Positive pay Service is not added for the account : " + AccountNumber, "servicelistadd", "true", appHandle, true);
            }
            Application.WebCSR.LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            string TransactionAcceptanceEnrolled_After_Update = appHandle.GetObjectText("XPath;//*[contains(text(),'Transaction Acceptance Enrolled')]/following-sibling::*");
            if (TransactionAcceptanceEnrolled_After_Update.Equals(Data.Get("GLOBAL_PERSONAL_CUSTOMER_ALLOW_ONLINE_ACCESS")))
            {
                appHandle.ScrollToObject("XPath;//*[contains(text(),'Transaction Acceptance Enrolled')]/following-sibling::*");
                Report.Info("Transaction Acceptance Enrolled is updated to Yes successfully.", "tranacceptanceenroll", "true", appHandle);
            }
            else
            {
                Report.Fail("Transaction Acceptance Enrolled is not updated to Yes successfully.", "tranacceptanceenrollfail", "true", appHandle, true);
            }
            WebCSRPageFactory.TransactionProcessingPage.EnterTransactionAcceptanceInstructions();
            WebCSRPageFactory.TransactionProcessingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.TransactionProcessingPage.VerifyMessageInTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Transaction processing data is updated successfully.", "transuccess", "true", appHandle);
            }
            else
            {
                Report.Fail("Transaction processing data is not updated successfully.", "transuccessfail", "true", appHandle, true);
            }

        }
        public virtual void UpdateEligibleAsCollateralForCDAccount(string AccountNumber)
        {
            this.LoadAccountSummaryPage(AccountNumber);
            WebCSRPageFactory.AccountInformationPage.SelectEligibleAsCollateralCheckbox();
            WebCSRPageFactory.AccountInformationPage.ClickOnSubmitBUtton();
            if (WebCSRPageFactory.TransactionProcessingPage.VerifyMessageInTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Eligible As Collateral  is updated successfully.", "eligiblestts", "true", appHandle);
            }
            else
            {
                Report.Fail("Eligible As Collateral  is not updated successfully.", "eligiblesttsfail", "true", appHandle, true);
            }

        }
        public virtual string CreateLoanAccountByCollateralTypePledgedAccount(string PrimaryCustomerNumber, string Relationship, string ProductType, string PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter, string CustomerNumbersForAdditionalOwnerAddition = "", int numberofAccounts = 1, string AccountDetailsWithSemicolonDelimiter = "")
        {
            string AccountNumber = "";

            string temptitle = appHandle.GetTitle();

            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            else if (temptitle.Contains(Data.Get("Verify Customer"))) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            if (WebCSRPageFactory.CreateAccountPage.VerifyCustomerNumberForAcctCreation(PrimaryCustomerNumber) == false)
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            WebCSRPageFactory.CustomerSearchPage.NavigateToCreateAccountPage();
            Report.Info("Create Account Customer Information page is displayed.", "custinfoacctcreate", "true", appHandle);
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateAccountPage.SelectRelationshipRadiobutton_AccountCreation(Relationship);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.VerifyOwnerPageLoadsAccountCreation();
            WebCSRPageFactory.CreateAccountPage.UpdateOwnerDetails(Relationship, CustomerNumbersForAdditionalOwnerAddition);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.SelectProductAndNumberOfAccounts(ProductType, numberofAccounts);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            if (ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_700")))
            {
                if (string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                 && numberofAccounts == 1)
                {

                    AccountDetailsWithSemicolonDelimiter = Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter;
                }
                else if (numberofAccounts > 1 && string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter))
                {

                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter;
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Term"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
                && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Payment Frequency"))
                )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter;
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts == 1
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {

                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter;
                }
                else if (numberofAccounts > 1
                && AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Replace(Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts"), Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter);
                }
                else if (numberofAccounts == 1
                && AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Replace(Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts"), Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter);
                }
            }
            if (ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_500"))
            || ProductType.Equals(Data.Get("GLOBAL_STAND_CSRPROD_DESC_600"))
            || ProductType.Equals(Data.Get("Commercial Loan 800"))
            || ProductType.Equals(Data.Get("Credit Balance Loan 900")))
            {
                if (string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                  && numberofAccounts == 1)
                {
                    AccountDetailsWithSemicolonDelimiter = Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter;
                }
                else if (numberofAccounts > 1 && string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter))
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K") + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y") + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE") + ";" + Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter;
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Amount"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Amount") + "|" + Data.Get("GLOBAL_DISBURSEMENT_AMOUNT_10K");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Term"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Term") + "|" + Data.Get("GLOBAL_ACCOUNT_TERM_1Y");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
                && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
                && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Payment Frequency"))
                )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Payment Frequency") + "|" + Data.Get("1MAE");
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts > 1
               && !string.IsNullOrEmpty(AccountDetailsWithSemicolonDelimiter)
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type"))
               )
                {
                    for (int i = 1; i <= numberofAccounts; i++)
                    {
                        AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter;
                    }
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Substring(1, AccountDetailsWithSemicolonDelimiter.Length - 1);
                }
                else if (numberofAccounts == 1
               && !AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter + ";" + Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter;
                }
                else if (numberofAccounts > 1
                                && AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Replace(Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts"), Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter);
                }
                else if (numberofAccounts == 1
                && AccountDetailsWithSemicolonDelimiter.Contains(Data.Get("Collateral Type")))
                {
                    AccountDetailsWithSemicolonDelimiter = AccountDetailsWithSemicolonDelimiter.Replace(Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts"), Data.Get("Collateral Type") + "|" + Data.Get("70 - Pledged Accounts") + "##" + PledgedAccountNumberCustomerNumberAmountWithColumnDelimiter);
                }
            }

            WebCSRPageFactory.CreateAccountPage.EnterAccountDetails(AccountDetailsWithSemicolonDelimiter, numberofAccounts, ProductType);
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();

            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CreateAccountPage.VerifyAccountCreationSuccess())
            {
                Report.Pass("Account creation application is successfully processed.", "accountcreationapplication", "true", appHandle);
            }
            else
            {
                Report.Fail("Account creation  application is not created due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "CreateAccountCreationFail", "true", appHandle);
            }
            AccountNumber = WebCSRPageFactory.CreateAccountPage.GetAccountNumbersFromApplicationSuccessPage(numberofAccounts);
            WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber, numberofAccounts);

            return AccountNumber;
        }
        public virtual string CreatePersonalCustomerByCountryCode(string CountryCode)
        {
            string CustomerNo = "";
            WebCSRPageFactory.WebCSRMasterPage.select_create_personal_customer_link();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_personal_information_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_drivers_license_identification_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_email_and_phone_details();
            switch (CountryCode)
            {
                case "CZ - CZECHIA":
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_home_address_details_Country_CZ("3");
                    break;
                case "TF - FRENCH SOUTHERN TERRITORIES":
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_home_address_details_Country_TF("3");
                    break;
                case "VA - HOLY SEE":
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_home_address_details_Country_VA("3");
                    break;
                case "WF - WALLIS AND FUTUNA":
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_home_address_details_Country_WF("3");
                    break;
                case "MK - NORTH MACEDONIA":
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_home_address_details_Country_MK("3");
                    break;

            }
            WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_mailing_address_same_as_home_address_no();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_mailing_address_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_previous_address_details();

            WebCSRPageFactory.CreatePersonalCustomerPage.enter_online_access_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_security_question_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_telephone_banking_details();
            string sTaxIdValue1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_tax_id_number_field_value();
            WebCSRPageFactory.CreatePersonalCustomerPage.select_continue_button();
            WebCSRPageFactory.CreatePersonalCustomerPage.select_submit_button();

            if (WebCSRPageFactory.CreatePersonalCustomerPage.VerifyPersonalCustomerCreationSuccess())
            {
                Report.Pass("Personal Customer application is created successfully", "PersonalCustCreate", "true", appHandle);

                CustomerNo = WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("GLOBAL_SEARCHTYPE_TAXID"), sTaxIdValue1);
                if (!string.IsNullOrEmpty(CustomerNo))
                {
                    Report.Pass("Personal customer number is captured as: " + CustomerNo, "custpersonal", "true", appHandle);
                }
            }
            else
            {
                Report.Fail("Personal Customer application is not created due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "CreatePersonalcustFail", "true", appHandle, true);
            }



            return CustomerNo;
        }

        public virtual void SelectCustomerVerificationActionVerifyCustomerPage(string strVerificationAction)
        {
            WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)strVerificationAction);
            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
        }
        public virtual bool VerifyHomeAddressCountryCustomerInformation(string sCountryName)
        {
            bool Result = false;
            SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.CustomerInformationPage.VerifyCustomerInformationPageLoads();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            WebCSRPageFactory.CustomerInformationPage.VerifyCustomerInformationPageLoads();
            if (WebCSRPageFactory.AddressPage.VerifyCountryInHomeAddress(sCountryName))
            {
                Report.Pass(sCountryName + " is available in Country dropdown of Home address.", "countryhomeaddress", "true", appHandle);
            }
            else
            {
                Report.Fail(sCountryName + " is not available in Country dropdown of Home address.", "countryhomeaddress", "true", appHandle, true);
            }
            return Result;
        }
        public virtual void VerifyCountryOfResidencyCreateCustomerPage(string CountryNamesWithPipeDelimiter)
        {
            if (appHandle.GetTitle().Contains("Create Personal Customer")) { }
            else
            {
                WebCSRPageFactory.WebCSRMasterPage.select_create_personal_customer_link();
            }
            WebCSRPageFactory.CreatePersonalCustomerPage.VerifyCountryOfResidencyCreateCustomerPage(CountryNamesWithPipeDelimiter);
        }
        public virtual void VerifyCountryofCitizenshipCreateCustomerPage(string CountryNamesWithPipeDelimiter)
        {
            if (appHandle.GetTitle().Contains("Create Personal Customer")) { }
            else
            {
                WebCSRPageFactory.WebCSRMasterPage.select_create_personal_customer_link();
            }
            WebCSRPageFactory.CreatePersonalCustomerPage.VerifyCountryofCitizenshipCreateCustomerPage(CountryNamesWithPipeDelimiter);
        }
        public virtual void VerifyHomeAddressCountryDropdownCreateCustomerPage(string CountryNamesWithPipeDelimiter)
        {
            if (appHandle.GetTitle().Contains("Create Personal Customer")) { }
            else
            {
                WebCSRPageFactory.WebCSRMasterPage.select_create_personal_customer_link();
            }
            WebCSRPageFactory.CreatePersonalCustomerPage.VerifyHomeAddressCountryDropdownCreateCustomerPage(CountryNamesWithPipeDelimiter);
        }
        public virtual void VerifyMailingAddressCountryDropdownCreateCustomerPage(string CountryNamesWithPipeDelimiter)
        {
            if (appHandle.GetTitle().Contains("Create Personal Customer")) { }
            else
            {
                WebCSRPageFactory.WebCSRMasterPage.select_create_personal_customer_link();
            }
            WebCSRPageFactory.CreatePersonalCustomerPage.VerifyMailingAddressCountryDropdownCreateCustomerPage(CountryNamesWithPipeDelimiter);
        }
        public virtual void VerifyCountryofIncorporationDropdownCreateCorporateCustomerPage(string CountryNamesWithPipeDelimiter)
        {
            if (appHandle.GetTitle().Contains("Create Corporate Customer")) { }
            else
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectCorporateCustomerLink();
            }
            WebCSRPageFactory.CreateCorporateCustomerPage.VerifyCountryofIncorporationDropdownCreateCorporateCustomerPage(CountryNamesWithPipeDelimiter);
        }
        public virtual void VerifyPrincipalPlaceofBusinessCountryDropdownCreateCorporateCustomerPage(string CountryNamesWithPipeDelimiter)
        {
            if (appHandle.GetTitle().Contains("Create Corporate Customer")) { }
            else
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectCorporateCustomerLink();
            }
            WebCSRPageFactory.CreateCorporateCustomerPage.VerifyPrincipalPlaceofBusinessCountryDropdownCreateCorporateCustomerPage(CountryNamesWithPipeDelimiter);
        }
        public virtual void VerifyMailingAddressCountryDropdownCreateCorporateCustomerPage(string CountryNamesWithPipeDelimiter)
        {
            if (appHandle.GetTitle().Contains("Create Corporate Customer")) { }
            else
            {
                WebCSRPageFactory.WebCSRMasterPage.SelectCorporateCustomerLink();
            }
            WebCSRPageFactory.CreateCorporateCustomerPage.VerifyMailingAddressCountryDropdownCreateCorporateCustomerPage(CountryNamesWithPipeDelimiter);
        }

        public virtual string CreateCorporateCustomerByCountryCode(string CountryCode)
        {
            string CustNo = "";
            string[] arrOnlineAccessSecurityDetails = null;
            string sSearchvalue = "";
            string sSearchType = "";
            WebCSRPageFactory.WebCSRMasterPage.SelectCorporateCustomerLink();
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterCorporateInformation();
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterEmailAndPhoneDetails();
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddress();
            switch (CountryCode)
            {
                case "CZ - CZECHIA":
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddress_Country_CZ();
                    break;
                case "TF - FRENCH SOUTHERN TERRITORIES":
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddress_Country_TF();
                    break;
                case "VA - HOLY SEE":
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddress_Country_VA();
                    break;
                case "WF - WALLIS AND FUTUNA":
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddress_Country_WF();
                    break;
                case "MK - NORTH MACEDONIA":
                    WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddress_Country_MK();
                    break;

            }
            WebCSRPageFactory.CreateCorporateCustomerPage.SelectAddressSameAsPrincipalAddressRadioButton("yes");
            string sRandomValue = RandomNumberGenerator.Generate();
            sRandomValue = sRandomValue.Substring(0, sRandomValue.Length - 1);
            string sUserID = StartupConfiguration.EnvironmentDetails.UserFirstName;
            sUserID = appHandle.SplitSideString(sUserID.ToUpper(), "LEFT", 4) + sRandomValue;
            string sAllowOnlineAccess = Data.Get("GLOBAL_PERSONAL_CUSTOMER_ALLOW_ONLINE_ACCESS");
            if (sAllowOnlineAccess.ToUpper().Equals("YES"))
            {
                WebCSRPageFactory.CreateCorporateCustomerPage.SelectAllowOnlineAccessRadioButton("yes");

                // To enter Online Access Details
                WebCSRPageFactory.CreateCorporateCustomerPage.EnterOnlineAccessDetails();

                // To get the Temporary Password Action dropdown value 
                string sTemporaryPasswordAction = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_tmporary_password_action_field_value();
                // Get the Value in the User ID Field
                string sWebClientUserID1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_user_id_field_value();

                if (sTemporaryPasswordAction.Equals(Data.Get("GLOBAL_TEMPORARY_PASSWORD_ACTION_RESET")))
                {
                    string sOnlineAccessSecurityDetails = Data.Get("GLOBAL_ONLINESECURITY_DETAILS");
                    arrOnlineAccessSecurityDetails = sOnlineAccessSecurityDetails.Split('_');
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_online_access_security_details(arrOnlineAccessSecurityDetails);
                }
            }
            else
            {
                WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_allow_online_access_no();
            }

            // Enter Security Question details.
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterSecretQuestionDetails();

            // Enter Telephone Banking details.
            WebCSRPageFactory.CreateCorporateCustomerPage.SelectCreateATelePhonebankingPINRadioButton("Yes");
            string sTaxIdValue1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_tax_id_number_field_value();
            WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CreateCorporateCustomerPage.VerifyCorporateCustomerCreationSuccess())
            {
                Report.Info("Corporate Customer application is created successfully", "CorporateCustCreate", "true", appHandle);

                sSearchvalue = sTaxIdValue1;
                sSearchType = Data.Get("GLOBAL_SEARCHTYPE_TAXID");

                CustNo = WebCSRPageFactory.CustomerSearchPage.get_customer_number(sSearchType, sSearchvalue);
                if (!string.IsNullOrEmpty(CustNo))
                {
                    Report.Info("Corporate customer number is captured as: " + CustNo, "custcorp", "true", appHandle);
                }
            }
            else
            {
                Report.Fail("Corporate Customer application is not created due to :" + WebCSRPageFactory.CreateCorporateCustomerPage.GetMessageText(), "CreatecorpcustFail", "true", appHandle, true);
            }

            return CustNo;
        }
        public virtual bool VerifyUpdateAddressByCountryCodeInCustomerInformation(string CountryCode, bool IsHomeAddr = false, bool IsMailAddress = false, bool IsPreviousAddress = false, bool IsSeasonalAddress = false)
        {
            bool Result = false;
            if (appHandle.GetTitle().Contains("Customer Information")) { }
            else
            {
                SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            }
            WebCSRPageFactory.CustomerInformationPage.VerifyCustomerInformationPageLoads();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            WebCSRPageFactory.CustomerInformationPage.VerifyCustomerInformationPageLoads();
            switch (CountryCode)
            {
                case "CZ - CZECHIA":
                    WebCSRPageFactory.AddressPage.VerifyUpdateAddr_CZ(IsHomeAddr, IsMailAddress, IsPreviousAddress, IsSeasonalAddress);
                    {
                        Report.Pass(Data.Get("The address information has been updated.") + "is displayed .", "msgchek", "true", appHandle);
                    }
                    break;
                case "TF - FRENCH SOUTHERN TERRITORIES":
                    WebCSRPageFactory.AddressPage.VerifyUpdateAddr_TF(IsHomeAddr, IsMailAddress, IsPreviousAddress, IsSeasonalAddress);
                    {
                        Report.Pass(Data.Get("The address information has been updated.") + "is displayed .", "msgchek", "true", appHandle);
                    }
                    break;
                case "VA - HOLY SEE":
                    WebCSRPageFactory.AddressPage.VerifyUpdateAddr_VA(IsHomeAddr, IsMailAddress, IsPreviousAddress, IsSeasonalAddress);
                    {
                        Report.Pass(Data.Get("The address information has been updated.") + "is displayed .", "msgchek", "true", appHandle);
                    }
                    {
                        Report.Pass(Data.Get("The address information has been updated.") + "is displayed .", "msgchek", "true", appHandle);
                    }
                    break;
                case "WF - WALLIS AND FUTUNA":
                    WebCSRPageFactory.AddressPage.VerifyUpdateAddr_WF(IsHomeAddr, IsMailAddress, IsPreviousAddress, IsSeasonalAddress);
                    {
                        Report.Pass(Data.Get("The address information has been updated.") + "is displayed .", "msgchek", "true", appHandle);
                    }
                    break;
                case "MK - NORTH MACEDONIA":
                    if (WebCSRPageFactory.AddressPage.VerifyUpdateAddr_MK(IsHomeAddr, IsMailAddress, IsPreviousAddress, IsSeasonalAddress))
                    {
                        Report.Pass(Data.Get("The address information has been updated.") + "is displayed .", "msgchek", "true", appHandle);
                    }
                    break;
            }


            return Result;
        }
        public virtual string AddBeneficiariesForAccount(string AccountNumber, int NumberOfBeneficiaries, string BeneficiaryClassificationType, string Country = "US - UNITED STATES OF AMERICA", int rownumber = 1, string percentage = "", string identificationtype = "", string identificationnumber = "", string issuer = "", string issuedate = "", string expirydate = " ")
        {
            string BeneficiaryID = "";
            string TaxIDIndividual = "";
            get_account(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Beneficiaries"));
            WebCSRPageFactory.BeneficiariesPage.selectAccountFromDropdown(AccountNumber);
            switch (BeneficiaryClassificationType)
            {
                case "I - Individual":
                    TaxIDIndividual = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"), "-");
                    break;

                case "NC - Non-Profit or Charity":

                    break;

                case "O - Other":
                    TaxIDIndividual = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
                    break;

                default:
                    TaxIDIndividual = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"), "-");
                    break;
            }

            if (WebCSRPageFactory.AddBeneficiaryPage.EnterBeneficiaryDetails(NumberOfBeneficiaries, BeneficiaryClassificationType, Country, percentage, identificationtype, identificationnumber, issuer, issuedate, expirydate, TaxIDIndividual))
            {
                BeneficiaryID = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT BENEFICIARYID FROM BENEFICIARYINFO WHERE TAXID = '" + TaxIDIndividual + "'", "BENEFICIARYID");
                Report.Pass("Beneficiaries is / are added for the account : " + AccountNumber, "beneficiaryadd", "true", appHandle);
            }
            else
            {
                Report.Fail(" Beneficiaries is / are not added for the account : " + AccountNumber, "beneficiaryadd", "true", appHandle, true);
            }
            return BeneficiaryID;
        }

        public virtual void VerifyDataInHoldsTable(string AccountNumber, string HoldType, string Amount, string ExpirationDate = "")
        {
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            if (WebCSRPageFactory.HoldsPage.VerifyDataInHoldsTable(AccountNumber, HoldType, Amount, ExpirationDate))
            {
                Report.Pass(HoldType + " for the Account : " + AccountNumber + " for the Amount : " + Amount + " is successfully verified in Holds Table.", "holdstabledata", "true", appHandle);
            }
            else
            {
                Report.Fail(HoldType + " for the Account : " + AccountNumber + " for the Amount : " + Amount + " is not found in Holds table .Hence could not be  verified in Holds Table.", "holdstabledata", "true", appHandle, true);
            }
        }
        public virtual string AddHoldForSpecifiedAccountNumber(string AccountNumber, string HoldType, string Amount, string sHoldCode = "", string ExpirationDate = "", string PercentageOfAccountBalanceHoldPercentage = "", string PercentageOfAccountBalanceAccountNo = "", string PercentageOfAccountBalanceBalanceType = "", string CurrencyCode = "", string HoldStartDate = "")
        {

            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            string TotHoldAmt = WebCSRPageFactory.HoldsPage.AddHoldForSpecifiedAccountNumber(AccountNumber, HoldType, Amount, sHoldCode, ExpirationDate, PercentageOfAccountBalanceHoldPercentage, PercentageOfAccountBalanceAccountNo, PercentageOfAccountBalanceBalanceType, CurrencyCode, HoldStartDate);
            WebCSRPageFactory.HoldsPage.ClickOnSubmitButton();
            if (TotHoldAmt.Any(char.IsLetter)) { }
            else
            {
                TotHoldAmt = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(TotHoldAmt);
            }
            if (HoldType.Contains("-"))
            {
                HoldType = HoldType.Split('-')[1].Trim();
            }
            if (WebCSRPageFactory.HoldsPage.VerifyDataInHoldsTable(AccountNumber, HoldType, TotHoldAmt, ExpirationDate)
                && WebCSRPageFactory.HoldsPage.VerifyMSGInHoldsPage(Data.Get("The hold has been placed.")))
            {

                Report.Pass(Data.Get("The hold has been placed.") + " is successfully verified.", "verifyholdmsg", "true", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("The hold has been placed.") + " is not successfully verified.", "verifyholdmsgfail", "true", appHandle, true);
            }
            return TotHoldAmt;
        }
        public virtual void VerifytransactionErrorMessageInFundsTransfer(string sMessage)
        {
            if (WebCSRPageFactory.FundTransferPage.VerifytransactionErrorMessageInFundsTransfer(sMessage))
            {
                Report.Pass(sMessage + " is displayed successfully.", "transactopmmessage", "true", appHandle);

            }
            else
            {
                Report.Fail(sMessage + " is not displayed successfully.", "transactopmmessagefail", "true", appHandle, true);
            }
        }
        public virtual void VerifySuccessfullTransferFundsMesage()
        {
            if (WebCSRPageFactory.FundTransferPage.VerifySuccessfullTransferFundsMesage())
            {
                Report.Pass(Data.Get("The funds transfer has been completed. The transaction will process on the transaction date listed below.") + " is displayed successfully.", "transactopmmessage", "true", appHandle);

            }
            else
            {
                Report.Fail(Data.Get("The funds transfer has been completed. The transaction will process on the transaction date listed below.") + " is not displayed successfully.", "transactopmmessagefail", "true", appHandle, true);
            }
        }
        public virtual void VerifyInvalidUserOverrideAuthorizationOverridePage(string sUserName, string sPassword)
        {
            WebCSRPageFactory.AuthorizationOverrideRequiredPage.EnterUserCredentials(sUserName, sPassword);
            WebCSRPageFactory.AuthorizationOverrideRequiredPage.ClickOnOverrideButton();

        }

        public virtual void ValidateInvalidPostalCode_Account()
        {
            this.NavigateToAccountSummaryPage();
            Application.WebCSR.ClickOnTitleTab();
            WebCSRPageFactory.AccountInformationPage.ValidatePostalAddressMessage();
        }
        public virtual void AccountClosure(string AccountNumber, string MortgageAccountNumber)
        {
            string MenuSubMenuDelimitedByPipe = Data.Get("TransactionProcessing") + "|" + Data.Get("RevolvingOptions");
            Application.WebCSR.LoadAccountSummaryPage(AccountNumber);
            WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(MenuSubMenuDelimitedByPipe);
            WebCSRPageFactory.AccountInformationPage.NegativeBalanceTransfer(AccountNumber);
            WebCSRPageFactory.AccountInformationPage.ClickSubmitButton();
            if (WebCSRPageFactory.AccountInformationPage.VerifyInformationUpdated())
            {
                Report.Pass("Negative Balance Transfer updated in Revolving Options Successfully", "VerifyInformationUpdated", "true", appHandle);
            }
            else
            {
                Report.Fail("Negative Balance Transfer failed to update in Revolving Options Successfully", "VerifyInformationUpdated", "true", appHandle, true);
            }
            WebCSRPageFactory.AccountInformationPage.SubTabLink(Data.Get("CommitmentProcessing"));
            WebCSRPageFactory.AccountInformationPage.UpdateLoanFrontMoneyAccountNumber(AccountNumber);
            Application.WebCSR.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Account Closure Utility"));
            WebCSRPageFactory.AccountClosureUtilityPage.SelectAccount(AccountNumber, MortgageAccountNumber);

        }

        public virtual string CreateCustomerInvalidAddr(string sCustomerType, string sSearchType, string IdentificationType = null, int intNumberOfYearsAtPresentAddress = 0, bool MailAddrSameAsHomeAddr = true, bool AllowOnlineAccess = true, bool CreateTelephoneBankingPIN = true)
        {
            string Result = "";
            WebCSRPageFactory.WebCSRMasterPage.select_create_personal_customer_link();
            // Enter Personal Information details.
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_personal_information_details();

            // Enter Drivers License details.
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_drivers_license_identification_details();

            // Enter Email and Phone details.
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_email_and_phone_details();

            string NumberOfYearsAtCurrentAddress = Data.Get("GLOBAL_YEAR_AT_ADDRESS_ONE_OR_LESS");
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_home_address_details_invalid(NumberOfYearsAtCurrentAddress);
            WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_mailing_address_same_as_home_address_no();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_mailing_address_details_invalid();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_previous_address_details_invalid();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_online_access_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_allow_online_access_no();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_security_question_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_telephone_banking_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.validate_invalid_postalcode_message();
            Result = this.create_customer(Data.Get("GLOBAL_PERSONAL_CUSTOMER"), Data.Get("GLOBAL_SEARCHTYPE_TAXID"));
            return Result;
        }

        public virtual void NextScheduledPaymentDate(string AccountNumber)
        {
            string ApplicationDate = this.GetApplicationDate();
            LoadAccountSummaryPage(AccountNumber);
            WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Interest") + "|" + Data.Get("Rate Determination"));
            WebCSRPageFactory.AccountInformationPage.InterestUpdate();
            WebCSRPageFactory.AccountInformationPage.SubTabLink(Data.Get("Maturity/Payoff"));
            WebCSRPageFactory.AccountInformationPage.AddMaturityDetails();
            WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Payment") + "|" + Data.Get("Payment Detail"));
            if (WebCSRPageFactory.AccountInformationPage.ValidateScheduledPaymentNextDate(ApplicationDate))
            {
                Report.Pass("Scheduled Payment Next Date is 1 day greater than Application Date", "ValidateScheduledPaymentNextDate", "true", appHandle);
            }
            else
            {
                Report.Fail("Scheduled Payment Next Date is same as Application Date", "ValidateScheduledPaymentNextDate", "true", appHandle, true);
            }
            WebCSRPageFactory.AccountInformationPage.ClickCancelButton();
            this.ClickLinkFromMenuItem(Data.Get("Loan Account Services") + "|" + Data.Get("Loan Corrections"));
            WebCSRPageFactory.LoanCorrectionsPage.SelectAccountFromDropdown(AccountNumber);
            if (WebCSRPageFactory.LoanCorrectionsPage.SelectLoanCorrectionProcess(Data.Get("Scheduled Payment Date Roll") + "|" + Data.Get("Payment Billing Process") + "|" + Data.Get("Payment Change Offset") + "|" + Data.Get("Interest Change Offset") + "|" + Data.Get("Payment Change Date Process") + "|" + Data.Get("Interest Change Date Process")))
            {
                Report.Pass("Loan Correction Process negative validation is successfull", "SelectLoanCorrectionProcess", "true", appHandle);
            }
            else
            {
                Report.Fail("Loan Correction Process negative validation is not successfull", "true", appHandle, true);
            }

        }
        public virtual void VerifyNoAccountTransAccountHistoryTable(string AccountNumber, string sFromDate = "", string sToDate = "")
        {
            WebCSRPageFactory.AccountHistoryPage.EnterDetailsForAccountHistory(AccountNumber, sFromDate, sToDate);
            WebCSRPageFactory.AccountHistoryPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.AccountHistoryPage.VerifyNoAccountTransactionInSearchTable())
            {
                Report.Pass("No account transactions found.  is displayed in Account History Transactions table.", "accounthistorynoacct", "true", appHandle);
            }
            else
            {
                Report.Fail("No account transactions found.  is not displayed in Account History Transactions table.", "accounthistorynoacct", "true", appHandle, true);
            }

        }
        public virtual void VerifyTransactionsInPendingTransfersTable(string sReferenceColumnValues)
        {

            if (Profile7CommonLibrary.VerifyDataInTableByColumnValues(sReferenceColumnValues))
            {
                Report.Pass(string.Join(" , ", sReferenceColumnValues.Split(';')) + " is / are present in Pending Transfers Table.", "tabledata", "true", appHandle);
            }
            else
            {
                Report.Fail(string.Join(" , ", sReferenceColumnValues.Split(';')) + " is / are not present in Pending Transfers Table. Please find the column values.", "tabledatafail", "true", appHandle, true);
            }
        }
        public virtual void VerifyTransactionInTableTransferFundsConfirmationPage(string LabelNamePipeLineLabelValue)
        {
            string msg = "";
            if (LabelNamePipeLineLabelValue.Contains(";"))
            {
                msg = LabelNamePipeLineLabelValue.Replace("|", " = ");
                msg = string.Join(" , ", msg.Split(';'));
            }
            else
            {
                msg = LabelNamePipeLineLabelValue.Replace("|", " = ");
            }
            if (WebCSRPageFactory.FundTransferPage.VerifyTransactionConfirmationTable(LabelNamePipeLineLabelValue))
            {
                Report.Pass(msg + " is / are successfully matched in application.", "tablelabelvalue", "true", appHandle);
            }
            else
            {
                Report.Fail(msg + " is / are not successfully matched in application", "tablelabelvaluefail", "true", appHandle);
            }
        }
        public virtual void VerifyTotalAmountDueInDelinquencyPaymentPerformance(string Amount)
        {
            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists("XPath;//*[contains(text(),'Total Amount Due')]/following-sibling::td['" + Amount + "']"))
            {
                Report.Pass("Total Amount Due in Payment Performance table is displayed as : " + Amount, "totAmountdue", "true", appHandle);
            }
            else
            {
                Report.Fail("Total Amount Due in Payment Performance table is not  displayed as : " + Amount, "totAmountduefail", "true", appHandle, true);
            }
        }

        public virtual void WaitDelinquencyPaymentPerformancePageLoads()
        {
            WebCSRPageFactory.DelinquencyPaymentPerformancePage.WaitDelinquencyPaymentPerformancePageLoads();
        }
        public virtual void UpdateAvailableBalanceCalculationCodeTransactionProcessingPage(string AccountNumber, string itemToBeSelected, string sReconcillationFreq = "", string sOffsetDays = "")
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebCSRPageFactory.TransactionProcessingPage.SelectAvailableBalanceCalculationCode(itemToBeSelected);
            Report.Info("Available Balance Calculation Code in Transaction Processing Page under Account Information is selected as " + itemToBeSelected, "avblcalmethod", "True", appHandle);
            WebCSRPageFactory.TransactionProcessingPage.EnterTransactionAcceptanceInstructions();
            WebCSRPageFactory.TransactionProcessingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.TransactionProcessingPage.VerifyMessageInTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Transaction processing data is updated successfully.", "transuccess", "true", appHandle);
            }
            else
            {
                Report.Fail("Transaction processing data is not updated successfully.", "transuccessfail", "true", appHandle, true);
            }
        }


        public virtual void AddAccountsFromAvailableToSelectedTableInOverdraftProtectionPage(string sSavAcct, string sLoanAcct)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Overdraft Protection"))) { }
            else
            {
                this.ClickLinkFromMenuItem(Data.Get("Deposit Account Services") + "|" + Data.Get("Overdraft Protection"));
            }
            if (WebCSRPageFactory.DepositAccountOverdraftProtectionPage.SelectAccountNumberFromAccountDropdown(sSavAcct))
            {
                Report.Info(sSavAcct + " is selected in Overdraft protection page.", "odpagesavacct", "True", appHandle);
            }
            if (WebCSRPageFactory.DepositAccountOverdraftProtectionPage.MoveAccountFromAvailableAccountsTableTOSelectedAccountsTable(sLoanAcct))
            {
                Report.Info(sLoanAcct + " is selected in available accounts table and added to selected accounts table in Overdraft Protection Page.", "oDProtectionLoanAcctMove", "True", appHandle);
            }
            WebCSRPageFactory.DepositAccountOverdraftProtectionPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositAccountOverdraftProtectionPage.VerifySuccessfulUpdateMessageInOverdraftProtectionPage())
            {
                Report.Pass(Data.Get("GLOBAL_INFORMATION_UPDATED") + " is successdully displayed in Overdraft protection page.", "ODProtectionupdate", "True", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("GLOBAL_INFORMATION_UPDATED") + " is not displayed in Overdraft protection page.", "ODProtectionupdatefail", "True", appHandle, true);
            }


        }

        public virtual void VerifyDatainBalancesDialogInAccountInformation(string AccountNumber, string sLabelNameLabelValuePipeDelimited)
        {

            WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
            WebCSRPageFactory.AccountOverviewPage.ClickOnAggregateAvailableBalance();
            if (WebCSRPageFactory.AccountOverviewPage.VerifyDatainBalancesTable(sLabelNameLabelValuePipeDelimited))
            {

                Report.Pass(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is captured as : " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in  Account Overview - balances dialog box.", "acctoverviwpage", "True", appHandle);

            }
            else
            {
                Report.Fail(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is not captured as : " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in  Account Overview - balances dialog box.", "acctoverviwpage", "True", appHandle, true);

            }
            WebCSRPageFactory.AccountOverviewPage.CloseBalancesDialogBox();
        }
        /// <summary>
        /// To Check / Uncheck Regulation CC Option . CheckBoXOnorOff  : true for Check , CheckBoXOnorOff : false for uncheck
        /// </summary>
        /// <param name="AccountNumber"></param>
        /// <param name="CheckBoXOnorOff"></param>
        public virtual void UpdateRegulationCCOptionInUSRegulatory(string AccountNumber, bool RegulationCCOnorOff = true, string Reporting1099Exemption = "")
        {

            this.LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));
            WebCSRPageFactory.USRegulatoryPage.VerifyUSRegulatoryPageLoads();
            WebCSRPageFactory.USRegulatoryPage.EnterUSRegulatoryPageOption(RegulationCCOnorOff, Reporting1099Exemption);
            WebCSRPageFactory.USRegulatoryPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.USRegulatoryPage.VerifyMessageInUSRegulatoryPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Regulation CC Option in US Regulatory page under Account information is successfully updated.", "REGCCUpdate", "true", appHandle);
            }
            else
            {
                Report.Fail("Regulation CC Option in US Regulatory page under Account information is not successfully updated.", "REGCCUpdatefail", "true", appHandle, true);
            }

        }


        public virtual void UpdateInterestRatesInLoanRateDeterminationPage(string AccountNumber, string InterestRate = "", String AnnualDisClosureRate = "", string EffectiveDisclosureRate = "", string Message = "")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Rate Determination"));
            WebCSRPageFactory.LoanRateDeterminationPage.EnterInterestRates(InterestRate, AnnualDisClosureRate, EffectiveDisclosureRate);
            WebCSRPageFactory.LoanRateDeterminationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.LoanRateDeterminationPage.VerifyMessageInLoanRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")) ||
                WebCSRPageFactory.LoanRateDeterminationPage.VerifyMessageInLoanRateDeterminationPage(Data.Get("Message")))
            {
                Report.Pass("Interest rates are updated in Loan Rate determination page under Account Information | Interest | Rate Determination .", "interestrateupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Interest rates are not updated in Loan Rate determination page under Account Information | Interest | Rate Determination .", "interestrateupdate", "True", appHandle, true);
            }
        }
        public virtual void UpdateLoanMaturityInLoanMaturityPayOffPage(string AccountNumber, string sTerm)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Maturity/Payoff"));
            WebCSRPageFactory.LoanMaturityPayoffPage.EnterPayTerm(sTerm);
            WebCSRPageFactory.LoanMaturityPayoffPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.LoanMaturityPayoffPage.VerifyMessageInLoanMaturityPayoffPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Loan term is updated in Maturity Payoff page under Account Information | Maturity Payoff .", "termupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Loan term is not updated in Loan Maturity Payoff page under Account Information | Maturity Payoff .", "termupdatefail", "True", appHandle, true);
            }
        }
        public virtual void UpdateLoanPaymentCalculationMethod(string AccountNumber, string sMethod)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Payment"), Data.Get("Payment Calculation"));
            WebCSRPageFactory.paymentcalculationpage.SelectPaymentCalculationMethod(sMethod);

            WebCSRPageFactory.paymentcalculationpage.ClickOnSubmitButton();
            if (WebCSRPageFactory.paymentcalculationpage.VerifyMessageInLoanPaymentCalculationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Payment Calculation Method is updated in Payment Calculation page under Account Information | Payment | Payment Calculation .", "paymentcalculationmethodupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Payment Calculation Method is updated in Payment Calculation page under Account Information | Payment | Payment Calculation .", "paymentcalculationmethodupdatefail", "True", appHandle, true);
            }
        }

        public virtual void GenerateLoanAccountServicesProjectedActivityData(string AccountNumber, string Projectedthroughdate)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            ClickLinkFromMenuItem(Data.Get("Loan Account Services") + "|" + Data.Get("Projected Activity"));
            WebCSRPageFactory.LoanAccountServicesProjectedActivityPage.EnterDataToRetrieveProjectedActivity(AccountNumber, Projectedthroughdate);
            Report.Info(AccountNumber + " and " + Projectedthroughdate + " are entered in Loan Account Servies Projected Activity Page.", "accdate", "true", appHandle);
            WebCSRPageFactory.LoanAccountServicesProjectedActivityPage.ClickOnSubmitButton();

        }
        public virtual void VerifyProjectedActivityDetailsByLabelnameLabelValue(string strlabelNamestrLabelvaluePipeDelilimited)
        {
            string message = "";
            if (strlabelNamestrLabelvaluePipeDelilimited.Contains(";"))
            {
                message = (string.Join(" , ", strlabelNamestrLabelvaluePipeDelilimited.Split(';')).Replace("|", " : "));
            }
            else
            {
                message = strlabelNamestrLabelvaluePipeDelilimited.Replace("|", " : ");
            }
            if (WebCSRPageFactory.LoanAccountServicesProjectedActivityPage.VeriyProjectedActivityDetailsByLabelnameLabelValue(strlabelNamestrLabelvaluePipeDelilimited))
            {
                Report.Pass(message + " is displayed in Projected Activity page.", "projactivitydata", "True", appHandle);
            }
            else
            {
                Report.Fail(message + " is not displayed in Projected Activity page.", "projactivitydata", "True", appHandle, true);
            }
        }
        public virtual void UpdateInvestmentSweepInTransactionProcessingInvestmentSweepPage(string AccountNumber, string InvestmentSweepEligibility, string InvestmentSweepType)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Investment Sweep"));
            WebCSRPageFactory.TransactionProcessingPage.SelectInvestmetSweepDetail(InvestmentSweepEligibility, InvestmentSweepType);
            WebCSRPageFactory.TransactionProcessingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.TransactionProcessingPage.VerifyMessageInTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Investment Sweep Eligibility : " + InvestmentSweepEligibility + " and Investment Sweep Type : " + InvestmentSweepType + " for account number : " + AccountNumber + " is successfully updated.", "Investmentsweepupdate", "true", appHandle);
            }
            else
            {
                Report.Fail("Investment Sweep Eligibility : " + InvestmentSweepEligibility + " and Investment Sweep Type : " + InvestmentSweepType + " for account number : " + AccountNumber + " is not successfully updated.", "Investmentsweepupdatefail", "true", appHandle, true);
            }
        }
        public virtual void VerifyProjectedActivityTableDetails(string inputrefcolvalues)
        {
            if (Profile7CommonLibrary.VerifyDataInTableByColumnValues(inputrefcolvalues))
            {
                Report.Pass(inputrefcolvalues.Replace(";", " , ") + " are verified in Projected activity table.", "projactivitydata", "true", appHandle);
            }
            else
            {
                Report.Fail(inputrefcolvalues.Replace(";", " , ") + " are not verified in Projected activity table.", "projactivitydata", "true", appHandle, true);
            }
        }
        public virtual void AddAccountsFromSweepEligibleAccountsTableToSweepAccountsTableInInvestmentSweepPage(string strAccountToBeSelectedFromDropdown, string strAccountTobeSelectedInTable, string SweepPercentage = "")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Investment Sweep"))) { }
            else
            {
                this.ClickLinkFromMenuItem(Data.Get("Deposit Account Services") + "|" + Data.Get("Investment Sweep"));
            }
            if (WebCSRPageFactory.DepositAccountServicesInvestmentSweepPage.SelectAccountNumberFromAccountDropdown(strAccountToBeSelectedFromDropdown))
            {
                Report.Info(strAccountToBeSelectedFromDropdown + " is selected in Investment Sweep page.", "InvestmentSweepAcct1", "True", appHandle);
            }
            if (WebCSRPageFactory.DepositAccountServicesInvestmentSweepPage.MoveAccountFromSweepEligibleAccountsTableToSweepAccountsTable(strAccountTobeSelectedInTable, SweepPercentage))
            {
                Report.Info(strAccountTobeSelectedInTable + " is selected in available accounts table and added to selected accounts table and SweepPercentage is entered in Investment Sweep Page.", "InvestmentSweepAccountMove", "True", appHandle);
            }
            WebCSRPageFactory.DepositAccountServicesInvestmentSweepPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositAccountServicesInvestmentSweepPage.VerifySuccessfulUpdateMessageInInvestmentSweepPage())
            {
                Report.Pass(Data.Get("GLOBAL_INFORMATION_UPDATED") + " is successdully displayed in Investment Sweep page.", "sweepaccountspass", "True", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("GLOBAL_INFORMATION_UPDATED") + " is not displayed in Investment Sweep page.", "sweepaccountsfail", "True", appHandle, true);
            }

        }

        public virtual bool VerifyNoHoldsOnTheAccount(string AccountNumber)
        {
            bool result = false;
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            WebCSRPageFactory.HoldsPage.SelectAccountFromDropdown(AccountNumber);
            if (WebCSRPageFactory.AddHoldPage.VerifyNoHolds())
            {
                result = true;
                Report.Pass("Hold Verification is successfully completed.", "HoldsStatusPass", "true", appHandle);
            }
            else
            {
                Report.Fail("Hold verification is failed", "HoldsStatusFail", "true", appHandle, true);
            }
            return result;
        }
        public virtual string AddDomesticPaymentsCustomerPaymentOrder(string AccountNumber, string InstitutionRountingNumberOrName, string RecipientAccountNumber, string AccountType, string RicipientName, string Amount, bool IspriorityOnorOff, string EffectiveDate = "", string Currency = "", bool IsThisBusinessAccount = false, bool IsHoldAutoPlacedOnOrOFF = false, string EconomicActivityCode = "", string SpecificDescription = "")
        {
            string RoutingNumber = "";
            string InstitutionName = "";
            string temp = "";
            if (InstitutionRountingNumberOrName.Contains("-"))
            {
                RoutingNumber = InstitutionRountingNumberOrName.Split('-')[0].Trim();
                InstitutionName = InstitutionRountingNumberOrName.Split('-')[1].Trim();
            }
            else
            {
                RoutingNumber = InstitutionRountingNumberOrName;
                InstitutionName = InstitutionRountingNumberOrName;
            }
            GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("Payment Services") + "|" + Data.Get("Domestic Payments - Customer"));
            WebCSRPageFactory.DomesticPaymentPage.VerifyDomesticPaymentsCustomerPageLoads();
            WebCSRPageFactory.DomesticPaymentPage.selectAccountFromDropDown(AccountNumber);
            Report.Info(AccountNumber + " is selected in domestic payments customer page.", "selectacct", "true", appHandle);
            WebCSRPageFactory.DomesticPaymentPage.clickonAddButton();
            WebCSRPageFactory.DomesticPaymentAddPage.SelectPaymentTypeFromDropDown(Data.Get("PO - Payment Order"));
            WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.ClickOnSearchInstitutionButton();
            if (RoutingNumber.All(char.IsDigit))
            {
                temp = WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.SearchInstitutionByRoutingNumber(RoutingNumber);
            }
            else
            {
                temp = WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.SearchInstitutionByInstitutionName(InstitutionName);
            }
            WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.EnterPOOrderDeails(RecipientAccountNumber, AccountType, RicipientName, Amount, IspriorityOnorOff, EffectiveDate, Currency, IsThisBusinessAccount, IsHoldAutoPlacedOnOrOFF, EconomicActivityCode, SpecificDescription);
            Report.Info("PO - Payment order details are entered.", "poorderdetail", "True", appHandle);
            WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Data.Get("The order has been added.")))
            {
                Report.Pass("The order has been added. message is displayed and Order details are added in List of Orders.", "POORDERPLACED", "true", appHandle);
            }
            else
            {
                Report.Fail("The order has been added. message is not displayed and Order details are not added in List of Orders.", "POORDERPLACEDFail", "true", appHandle, true);
            }
            return temp;
        }
        public virtual void DeleteDomesticPaymentsCustomerPaymentOrder(string AccountNumber, string UniqueOrderRefValue)
        {
            GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("Payment Services") + "|" + Data.Get("Domestic Payments - Customer"));
            WebCSRPageFactory.DomesticPaymentPage.VerifyDomesticPaymentsCustomerPageLoads();
            WebCSRPageFactory.DomesticPaymentPage.selectAccountFromDropDown(AccountNumber);
            Report.Info(AccountNumber + " is selected in domestic payments customer page.", "selectacct", "true", appHandle);
            WebCSRPageFactory.DomesticPaymentPage.SelectOrderInPayListOrder(UniqueOrderRefValue);
            WebCSRPageFactory.DomesticPaymentPage.ClickOnDeleteButton();
            appHandle.Wait_For_Specified_Time(5);
            appHandle.PerformActionOnAlert(PopUpAction.Verify, Data.Get("Are you sure you want to delete this order?"));
            appHandle.Wait_For_Specified_Time(4);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);

            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Data.Get("The order has been deleted.")))
            {
                Report.Pass("The order has been deleted is displayed.", "deletePayorder", "True", appHandle);
            }
            else
            {
                Report.Pass("The order has been deleted is not displayed.", "deletePayorderfail", "True", appHandle);
            }
        }

        public virtual void EditDomesticPaymentsCustomerPaymentOrder(string AccountNumber, string UniqueOrderRefValue, string ModifyParameter, string Amount = "")
        {
            GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("Payment Services") + "|" + Data.Get("Domestic Payments - Customer"));

            WebCSRPageFactory.DomesticPaymentPage.VerifyDomesticPaymentsCustomerPageLoads();
            WebCSRPageFactory.DomesticPaymentPage.selectAccountFromDropDown(AccountNumber);
            Report.Info(AccountNumber + " is selected in domestic payments customer page.", "selectacct", "true", appHandle);
            WebCSRPageFactory.DomesticPaymentPage.SelectOrderInPayListOrder(UniqueOrderRefValue);
            WebCSRPageFactory.DomesticPaymentPage.ClickOnEditButton();
            switch (ModifyParameter)
            {
                case "Amount":
                    WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.EnterAmountInModifiedOrder(Amount);
                    break;
            }
            Report.Info("PO - Payment order details are entered.", "poorderdetail", "True", appHandle);
            WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Data.Get("The order has been modified.")))

            {
                Report.Pass("The order has been modified. message is displayed and Order details are modified in List of Orders.", "POORDERPLACED", "true", appHandle);
            }
            else
            {
                Report.Fail("The order has been modified. message is not displayed and Order details are not modified in List of Orders.", "POORDERPLACEDFail", "true", appHandle, true);
            }

        }
        public virtual void VerifyLoanAccountInterestCalculationOptions(string strLabelNamePipeDilimtedDropdownValue)
        {
            bool Result = false;
            string msg = "";
            string temp = "";
            strLabelNamePipeDilimtedDropdownValue = strLabelNamePipeDilimtedDropdownValue + ";";

            string[] arr = strLabelNamePipeDilimtedDropdownValue.Split(';');
            if (string.IsNullOrEmpty(arr[1]))
            {
                msg = arr[0].Split('|')[1] + " is found successfully in " + arr[0].Split('|')[0] + " dropdown .";
            }
            else
            {
                for (int b = 0; b < arr.Length - 1; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[1] + " is found successfully in " + arr[b].Split('|')[0] + " dropdown .";
                }
                msg = temp.Substring(3, temp.Length - 3);
            }
            int counter = 0;
            for (int a = 0; a < arr.Length - 1; a++)
            {
                if (Profile7CommonLibrary.VerifyDropdownValueByLabelNameDropdownItemValue(arr[a]))
                {
                    counter++;
                }
                if (counter == arr.Length - 1)
                {
                    Result = true;
                    break;
                }
            }
            if (Result)
            {
                Report.Pass(msg, "dropdownintcalcoption", "True", appHandle);
            }
            else
            {
                Report.Fail(msg, "dropdownintcalcoption", "True", appHandle, true);
            }

        }
        public virtual string EditHoldForSpecifiedAccountNumber(string AccountNumber, string HoldType, string FixedAmount, string AmountToSelectHoldInHoldsTable = "", string sHoldCode = "", string ExpirationDate = "", string PercentageOfAccountBalanceHoldPercentage = "", string PercentageOfAccountBalanceAccountNo = "", string PercentageOfAccountBalanceBalanceType = "")
        {
            if (!appHandle.GetTitle().Contains("Hold"))
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("AccountNumber"));
                WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_ACCOUNTLIST"));
                WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            }
            string TotalHoldAmount = WebCSRPageFactory.HoldsPage.EditHoldForSpecifiedAccountNumber(AccountNumber, HoldType, FixedAmount, AmountToSelectHoldInHoldsTable, sHoldCode, ExpirationDate, PercentageOfAccountBalanceHoldPercentage, PercentageOfAccountBalanceAccountNo, PercentageOfAccountBalanceBalanceType);
            WebCSRPageFactory.HoldsPage.ClickOnSubmitButton();
            if (HoldType.Contains("-"))
            {
                HoldType = HoldType.Split('-')[1].Trim();
            }
            if (WebCSRPageFactory.HoldsPage.VerifyDataInHoldsTable(AccountNumber, HoldType, TotalHoldAmount, ExpirationDate)
                && WebCSRPageFactory.HoldsPage.VerifyMSGInHoldsPage(Data.Get("The hold has been updated.")))
            {
                Report.Pass(Data.Get("The hold has been updated.") + " is successfully verified.", "verifyholdEditmsg", "true", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("The hold has been updated.") + " is not successfully verified.", "verifyholdEditmsgfail", "true", appHandle, true);
            }
            return TotalHoldAmount;
        }
        public virtual string CalculateModifiedPermanentHoldAmountBaseTypeLedger(string sInitialFixedAmount, string sHoldPercentage, string sUpdatedFixedAmount)
        {
            string UpdatedAmount = "";
            double UpdatedAmount1 = Convert.ToDouble(UpdatedAmount);
            UpdatedAmount1 = Convert.ToDouble(sInitialFixedAmount) * Convert.ToDouble(sHoldPercentage);
            UpdatedAmount1 = UpdatedAmount1 / 100;
            UpdatedAmount1 = UpdatedAmount1 + Convert.ToDouble(sUpdatedFixedAmount);
            UpdatedAmount = UpdatedAmount1.ToString();

            return UpdatedAmount;
        }

        public virtual void VerifyDataHoldDetailsPage(string AccountNumber, string sHoldType, string HoldAmount, string sLabelNameLabelValuePipeDelimited, string ExpirationDate = "")
        {
            string msg = "";
            string failmsg = "";
            string temp = "";
            string[] arr = null;
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is found as " + arr[b].Split('|')[1] + " successfully in Hold Details Dialog box .";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is found as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " successfully in Hold Details Dialog box .";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (!appHandle.GetTitle().Contains("Hold"))
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("AccountNumber"));
                WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_ACCOUNTLIST"));
                WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            }
            if (WebCSRPageFactory.HoldsPage.VerifyDataInHoldDetailPage(AccountNumber, sHoldType, HoldAmount, sLabelNameLabelValuePipeDelimited, ExpirationDate))
            {
                Report.Pass(msg, "HoldDetailValidation", "True", appHandle);
            }
            else
            {
                Report.Fail(msg, "HoldDetailValidation", "True", appHandle, true);
            }
            WebCSRPageFactory.HoldsPage.CloseHoldDetailDialog(AccountNumber);
        }

        public virtual void UpdatePayoffDetailsInLoanMaturityPayOffPage(string AccountNumber, string Amount = "", string Term = "", string SmallBalanceCreditThreshold = "")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Maturity/Payoff"));
            WebCSRPageFactory.LoanMaturityPayoffPage.EnterDebitThreshold(Amount, Term);
            WebCSRPageFactory.LoanMaturityPayoffPage.EnterCreditThreshold(SmallBalanceCreditThreshold);
            WebCSRPageFactory.LoanMaturityPayoffPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.LoanMaturityPayoffPage.VerifyMessageInLoanMaturityPayoffPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Debit Threshold Amount is updated in Maturity Payoff page under Account Information | Maturity Payoff .", "DebitThresholdupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Debit Threshold Amount is not updated in Loan Maturity Payoff page under Account Information | Maturity Payoff .", "DebitThresholdupdatefail", "True", appHandle, true);
            }
        }

        public virtual void UpdateRenewalAnalysisInRenewalProcessingPage(string AccountNumber)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Renewal"));
            WebCSRPageFactory.RenewalProcessingPage.UpdateRenewalAnalysis(Data.Get("Do Not Renew"));
            WebCSRPageFactory.RenewalProcessingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.RenewalProcessingPage.VerifySuccessMessage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Renewal Recommendation code is updated in Renewal Processing page under Account Information | Renewal .", "Renewalupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Failed to update Renewal Recommendation code in Renewal Processing page under Account Information | Renewal .", "Renewalupdatefail", "True", appHandle, true);
            }
        }
        public virtual string ValidateActualLoanPayoffAmount(string AccountNumber, string Amount1, string Amount2)
        {
            Application.WebCSR.GetAccount(AccountNumber);
            string data = WebCSRPageFactory.LoanAccountOverviewPage.GetValueForLabel(Data.Get("Net Payoff Amount"));
            string LoanPayoffAmount = WebCSRPageFactory.LoanAccountOverviewPage.CalculateActualLoanPayoffAmount(Amount1, Amount2);
            return LoanPayoffAmount;
        }
        public virtual void ValidateCreditedAmount(string AccountNumber, string CreditedAmount)
        {
            Application.WebCSR.GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Account History"));
            this.NavigateToAccountHistory(AccountNumber);
            if (WebCSRPageFactory.AccountHistoryPage.ValidateCreditedAmount(CreditedAmount))
            {
                Report.Pass("Credited Amount " + CreditedAmount + " is displayed for " + AccountNumber + " under Account Information | Amount History .", "ValidateCreditedAmount", "True", appHandle);
            }
            else
            {
                Report.Fail("Credited Amount " + CreditedAmount + " is not displayed for " + AccountNumber + " under Account Information | Amount History", "ValidateCreditedAmountFail", "True", appHandle, true);
            }
        }
        public virtual void NavigateToAccountHistory(string AccountNumber)
        {
            this.get_account(AccountNumber);
            WebCSRPageFactory.AccountHistoryPage.NavigateToAccountHistoryPage(AccountNumber);
            WebCSRPageFactory.AccountHistoryPage.EnterDetailsForAccountHistory(AccountNumber);
            WebCSRPageFactory.AccountHistoryPage.ClickOnSubmitButton();
        }
        public virtual void VerifyDomesticPaymentsCustomerPaymentOrderCancellationinAccountHistory(string AccountNumber, string LinkName)

        {

            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("Account Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_ACCOUNTLIST"));
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Account History"));
            this.NavigateToAccountHistory(AccountNumber);
            WebCSRPageFactory.CustomerHistoryPage.selectAccountFromDropDown(AccountNumber);
            WebCSRPageFactory.AccountHistoryPage.ClickOnAdvancedSearch();
            WebCSRPageFactory.AccountHistoryPage.SelectNonMonetaryAdvancedSearch();
            WebCSRPageFactory.AccountHistoryPage.ClickOnSubmitButton();
            WebCSRPageFactory.CustomerHistoryPage.ClickonLink(LinkName);
            WebCSRPageFactory.CustomerHistoryPage.ValidateValueofPopupWindow(Data.Get("Description"));
            WebCSRPageFactory.CustomerHistoryPage.ClosePopup();
            Report.Pass("Payment Order Cancellation is verified.", "History", "True", appHandle);
        }

        public virtual void VerifyDomesticPaymentsCustomerPaymentOrder(string AccountNumber, string UniqueOrderRefValue)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("Account Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_ACCOUNTLIST"));
            this.ClickLinkFromMenuItem(Data.Get("Payment Services") + "|" + Data.Get("Domestic Payments - Customer"));
            WebCSRPageFactory.DomesticPaymentPage.VerifyDomesticPaymentsCustomerPageLoads();
            WebCSRPageFactory.DomesticPaymentPage.selectAccountFromDropDown(AccountNumber);
            Report.Info(AccountNumber + " is selected in domestic payments customer page.", "selectacct", "true", appHandle);
            WebCSRPageFactory.DomesticPaymentPage.SelectOrderInPayListOrder(UniqueOrderRefValue);
            Report.Pass("Payment order is Verified", "VerifyDomesticPaymentsCustomerPaymentOrder", "true", appHandle);

        }
        public virtual void CompareReferencealanceAmountWithTotalHold(string TotalHoldAmount, string ReferenceAccount)
        {
            Application.WebCSR.GetAccount(ReferenceAccount);
            if (WebCSRPageFactory.HoldsPage.CompareReferencealanceAmountWithTotalHold(TotalHoldAmount))
            {
                Report.Pass("TotalHold Amount and Available Balance of Reference account are matching.", "CompareReferencealanceAmountWithTotalHold", "true", appHandle);
            }
            else
            {
                Report.Fail("TotalHold Amount and Available Balance of Reference account are not matching.", "CompareReferencealanceAmountWithTotalHold", "true", appHandle, true);
            }
        }

        public virtual void VerifyPermanentHoldInAccountHistory(string AccountNumber, string ApplicationDate)
        {
            if (!appHandle.GetTitle().Contains("Account History"))
            {
                this.GetAccount(AccountNumber);
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Account History"));
            }
            WebCSRPageFactory.AccountHistoryPage.EnterDetailsForAccountHistory(AccountNumber);
            WebCSRPageFactory.AccountHistoryPage.ClickOnAdvancedSearch();
            WebCSRPageFactory.AccountHistoryPage.SelectNonMonetaryAdvancedSearch();
            WebCSRPageFactory.AccountHistoryPage.ClickOnSubmitButton();

            if (Profile7CommonLibrary.VerifyDataInTableByColumnValues(ApplicationDate + ";" + "Permanent hold"))
            {
                string temp = appHandle.GetObjectText("XPath;//*[contains(text(),'" + ApplicationDate + "')]/ancestor::*[1]/descendant::*[contains(text(),'Permanent hold')]/ancestor::*[1]");
                Report.Pass(temp + " Added Permanent old  is successfully verified.", "VerifyPermanentHoldInAccountHistory", "true", appHandle);
            }
            else
            {
                Report.Fail("Not able to fetch Permanent Hold in Account History", "VerifyPermanentHoldInAccountHistory", "true", appHandle, true);
            }
        }

        public virtual string CalculateAccountAvailableBalance(string TotalHoldAmount, string Rate, string RequestedAmount)
        {
            TotalHoldAmount = TotalHoldAmount.Split(' ').FirstOrDefault().Trim();
            double PermanentHoldAmount = Convert.ToDouble(TotalHoldAmount) / Convert.ToDouble(Rate);
            double AvailableBalance = Convert.ToDouble(RequestedAmount) - PermanentHoldAmount;
            string strAvblBal = AvailableBalance.ToString();
            strAvblBal = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(strAvblBal);
            return strAvblBal;
        }
        public virtual string GetAmountOfBalanceHeld(string AccountNumber, string HoldType, string AmountinHoldsTable, string label = "")
        {
            string value = WebCSRPageFactory.HoldsPage.GetAmountOfBalanceHeld(AccountNumber, HoldType, AmountinHoldsTable, Data.Get("Amount of Balance Held:"));
            if (!string.IsNullOrEmpty(value))
            {
                Report.Pass("Amount of Balance Held " + value + " is retrieved.", "GetAmountOfBalanceHeld", "true", appHandle);
            }
            else
            {
                Report.Fail("Not able to fetch Amount of BalanceHeld.", "GetAmountOfBalanceHeld", "true", appHandle, true);
            }
            return value;
        }

        public virtual void NavigatetoInterestAccrualPage()
        {
            WebCSRPageFactory.AccountInformationPage.select_interest_tab();
            // WebCSRPageFactory.LoanInterestTab.select_calculation_options_link();
        }
        public virtual void CalculateHoldAmount(string TotalHoldAmount, string AccountNumber, string globalamnount = "", string HoldType = "", string AmountinHoldsTable = "")
        {
            TotalHoldAmount = TotalHoldAmount.Split(' ')[0].Trim();
            this.GetAccount(AccountNumber);
            string AmountofBalanceHeld = WebCSRPageFactory.DepositAccountOverviewPage.GetValueForLabel(Data.Get("Account Available Balance"));

            Double Value = Convert.ToDouble(AmountofBalanceHeld.Split(' ')[0].Trim()) + Convert.ToDouble(globalamnount);

            string TotalHoldAmount_Account1 = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(Value.ToString());

            if (TotalHoldAmount == TotalHoldAmount_Account1)
            {
                Report.Pass("TotalHold Amount of Account 1 and Account Available Balance of Reference account are matching.", "CalculateHoldAmount", "true", appHandle);
            }
            else
            {
                Report.Fail("TotalHold Amount of Account 1 and Account Available Balance of Reference account are not matching.", "CalculateHoldAmount", "true", appHandle, true);
            }
        }
        public virtual void EnterAccountInformationPaymentPageOption(string AccountNumber, string DisOpt = "", string PostFreq = "", string NegIntPostFreq = " ", string NegIntPostOpt = "")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Overview"))) { }
            else
            {
                WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
            }
            WebCSRPageFactory.AccountOverviewPage.SelectAccountSummaryTab();

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Payment"));
            if (WebCSRPageFactory.DepositPaymentPage.WaitUntilDepositPaymentPageLoad())
            {
                WebCSRPageFactory.DepositPaymentPage.EnterInterestPaymentPageOptions(DisOpt, PostFreq, NegIntPostFreq, NegIntPostOpt);
                appHandle.WaitForSpecifiedTime(5);
                WebCSRPageFactory.DepositPaymentPage.SelectSubmitButton();
                if (WebCSRPageFactory.DepositPaymentPage.VerifyMessageDepositPaymentPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Positive Interest Disbersment Option and Posting Frequency fields are updated in Deposit Interest Payment Page.", "PaymentPageUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Positive Interest Disbersment Option and Posting Frequency fields are not updated in Deposit Interest Payment Page.", "PaymentPageNotUpdated", "True", appHandle, true);
                }

            }
        }
        /// <summary>
        /// This Method is used to enter Accrual Method in Deposit Interest Accrual Page.
        /// </summary>
        /// <param name="AccountNumber"></param>
        /// <param name="AccrMethod"></param>
        public virtual void EnterAccountInformationInterestPageOption(string AccountNumber, string AccrMethod = "", string AccrBase = "", string CompFreq = "", string NegAcrrOpt = "", string MinBalAccr = "", string MinBalAccrOpt = "")
        {
            GetAccount(AccountNumber);
            if (appHandle.GetTitle().Contains(Data.Get("Account Overview"))) { }
            else
            {
                WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
            }
            WebCSRPageFactory.AccountOverviewPage.SelectAccountSummaryTab();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"));
            if (WebCSRPageFactory.DepositInterestAccrualPage.WaitUntilDepositInterestPageLoad())
            {
                WebCSRPageFactory.DepositInterestAccrualPage.EnterInterestAccrualCalculationOptions(AccrMethod, AccrBase, CompFreq, NegAcrrOpt, MinBalAccr, MinBalAccrOpt);
                appHandle.WaitForSpecifiedTime(5);
                WebCSRPageFactory.DepositInterestAccrualPage.SelectSubmitButton();
                if (WebCSRPageFactory.DepositInterestAccrualPage.VerifyMessageDepositInterestPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Accrual Method field is updated in Deposit Interest Page.", "AccrualMethodUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Accrual Method field is not updated in Deposit Interest Page", "AccrualMethodNOtUpdated", "True", appHandle, true);
                }

            }
        }
        public virtual void EnterAccountInformationRateDeterminationPageOption(string AccountNumber = " ", string IntRate = "", string VarInterestIndex = "", string VarChangeFreq = " ", string IndexLastdate = "", string VarRateMatrix = " ")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Overview"))) { }
            else
            {
                WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
            }
            WebCSRPageFactory.AccountOverviewPage.SelectAccountSummaryTab();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Rate Determination"));
            if (WebCSRPageFactory.DepositRateDeterminationPage.WaitUntilDepositInterestPageLoad())
            {
                WebCSRPageFactory.DepositRateDeterminationPage.EnterInterestPageOptions(IntRate, VarInterestIndex, VarChangeFreq, IndexLastdate, VarRateMatrix);
                WebCSRPageFactory.DepositRateDeterminationPage.SelectSubmitButton();
                if (WebCSRPageFactory.DepositRateDeterminationPage.VerifyMessageDepositRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Interest Rate is updated in Deposit Interest Rate Determination Page.", "AccrualMethodUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Interest Rate is not updated in Deposit Interest Rate Determination Page.", "AccrualMethodNOtUpdated", "True", appHandle, true);
                }

            }
        }
        public virtual void VerifyAccruedInterest(string sLabelNameLabelValuePipeDelimited)
        {
            string msg = "";
            string failmsg = "";
            string temp = "";
            string[] arr = null;
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is found as " + arr[b].Split('|')[1] + " successfully in Interest Accrual Page.";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is found as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " successfully in Interest Accrual Page.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebCSRPageFactory.DepositInterestAccrualPage.VerifyTableDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(msg, "InterestAccrualsValidation", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "InterestAccrualsNotValidation", "True", appHandle, true);
            }
        }

        public virtual string CalculatePermanentHoldMultiCurrByExchangeRate(string TotalHoldAmount, string Curr1Rate, string Curr2Rate)
        {
            if (TotalHoldAmount.Contains(" "))
            { TotalHoldAmount = TotalHoldAmount.Split(' ').FirstOrDefault().Trim(); }
            double PermanentHoldAmount = Convert.ToDouble(TotalHoldAmount) * Convert.ToDouble(Curr1Rate);
            PermanentHoldAmount = PermanentHoldAmount / Convert.ToDouble(Curr2Rate);
            string strPermanentHoldAmount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(PermanentHoldAmount.ToString());

            return strPermanentHoldAmount;
        }
        public virtual void VerifyErrorMessageWhilePlacingPermanentHold(string AccountNumber, string ErrorMessageToValidate, string Amount = "", string sHoldCode = "", string ExpirationDate = "", string PercentageOfAccountBalanceHoldPercentage = "", string PercentageOfAccountBalanceAccountNo = "", string PercentageOfAccountBalanceBalanceType = "", string CurrencyCode = "")
        {
            if (appHandle.GetTitle().Contains("Add Hold")
            && Profile7CommonLibrary.VerifyDropdownValueByLabelNameDropdownItemValue(Data.Get("Account Number") + "|" + AccountNumber))
            {
                WebCSRPageFactory.HoldsPage.EnterPHLDDetails(sHoldCode, Amount, PercentageOfAccountBalanceHoldPercentage, PercentageOfAccountBalanceAccountNo, PercentageOfAccountBalanceBalanceType, CurrencyCode, ExpirationDate);
                WebCSRPageFactory.HoldsPage.ClickOnSubmitButton();
                if (WebCSRPageFactory.HoldsPage.VerifyMSGInHoldsPage(ErrorMessageToValidate))
                {
                    Report.Pass(ErrorMessageToValidate + " is displayed successfully", "ErrorPermanentHOld", "True", appHandle);
                }
                else
                {
                    Report.Fail(ErrorMessageToValidate + " is displayed successfully", "ErrorPermanentHOld", "True", appHandle, true);
                }
            }
            else

            {
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
                WebCSRPageFactory.HoldsPage.SelectAccountFromDropdown(AccountNumber);
                WebCSRPageFactory.HoldsPage.ClickOnAddButton();
                WebCSRPageFactory.HoldsPage.EnterPHLDDetails(sHoldCode, Amount, PercentageOfAccountBalanceHoldPercentage, PercentageOfAccountBalanceAccountNo, PercentageOfAccountBalanceBalanceType, CurrencyCode, ExpirationDate);
                WebCSRPageFactory.HoldsPage.ClickOnSubmitButton();
                if (WebCSRPageFactory.HoldsPage.VerifyMSGInHoldsPage(ErrorMessageToValidate))
                {
                    Report.Pass(ErrorMessageToValidate + " is displayed successfully", "ErrorPermanentHOld", "True", appHandle);
                }
                else
                {
                    Report.Fail(ErrorMessageToValidate + " is displayed successfully", "ErrorPermanentHOld", "True", appHandle, true);
                }
            }

        }
        public virtual int GetNumberOfDaysInAMonth(string Date)
        {
            int numberofDays = 0;
            DateTime dt = DateTime.ParseExact(Date, "MM/dd/yyyy", CultureInfo.InvariantCulture);
            numberofDays = DateTime.DaysInMonth(dt.Year, dt.Month);
            return numberofDays;
        }
        /// <summary>
        /// This method is used to calculate accrued interest as per specified accrual method.
        /// accrualMethod :String parameter :  Need to pass accrual method
        /// principalAmount :String parameter :  Pass prinicipal amount
        /// intRate : integer parameter : Interest rate
        /// Date : String parameter : By default it considers systemdate. It supports for date other than system date
        /// numberOfDaysPassed : integer parameter : By default it is 1.
        /// Roundoff: integer parameter : Specify the number after decimal point in calculated accrued interest.
        /// Example : double accruedInt= Application.WebCSR.CalculateAccruedInterestByAccrMethod(Data.Get("GLOBAL_ACCRUAL_CALC_METHOD_01"),Data.Get("GLOBAL_AMOUNT_DEPOSITED_10K"),10,"",1,5);
        /// </summary>
        /// <param name="accrualMethod"></param>
        /// <param name="principalAmount"></param>
        /// <param name="intRate"></param>
        /// <param name="Date"></param>
        /// <param name="numberOfDaysPassed"></param>
        /// <param name="Roundoff"></param>
        /// <returns>Returns accrued interest .</returns>
        public virtual string CalculateAccruedInterestByAccrMethod(string accrualMethod, string principalAmount, string intRate, int numberOfDaysPassed, string Date = "", string DateoFirstDeposit = "", int Roundoff = 5, string AccountNumber = "")
        {
            if(!string.IsNullOrEmpty(AccountNumber))
            {
                LoadAccountSummaryPage(AccountNumber);
                NavigatetoInterestAccrualPage();
            }
            string AccrInterest = "";
            string postfreq = "";
            double AccruedInterest = 0;
            string AFVal = Data.Get("AnnualFactor");
            double AF = Convert.ToDouble(AFVal);
            int numberOfDaysInYear = 0;
            if (string.IsNullOrEmpty(Date))
            {
                Date = GetApplicationDate();
            }
            string yearparam = appHandle.GetDateParameters(Date)[2].Trim();
            if (appHandle.IsLeapYear(Int32.Parse(yearparam)))
            {
                numberOfDaysInYear = 366;
            }
            else
            {
                numberOfDaysInYear = 365;
            }
            int numberofDaysInMonth = GetNumberOfDaysInAMonth(Date);
            if (!string.IsNullOrEmpty(AccountNumber))
            {
                postfreq = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT IPF FROM DEP WHERE CID = '" + AccountNumber + "'", "IPF");
                appHandle.WaitForSpecifiedTime(4);
            }
            switch (accrualMethod)
            {
                case "00 - Standard/Standard  (30/360)":

                    if (postfreq.Equals("1MAE"))
                    {
                        AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                        AccruedInterest = AccruedInterest / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) * AF * Convert.ToDouble(numberofDaysInMonth));
                        AccruedInterest = Math.Round(AccruedInterest, Roundoff);

                    }
                    else
                    {
                        AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                        AccruedInterest = AccruedInterest / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100"));
                        AccruedInterest = AccruedInterest / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_365"));
                        AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    }
                    break;
                case "01 - Standard/Actual    (30/365,6)":
                    AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                    AccruedInterest = AccruedInterest / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) * (Convert.ToDouble(360) / AF / Convert.ToDouble(numberOfDaysInYear) / Convert.ToDouble(numberofDaysInMonth));
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;
                case "03 - Standard/365       (30/365)":
                    AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                    AccruedInterest = AccruedInterest / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) * (Convert.ToDouble(360) / AF / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_365")) / Convert.ToDouble(numberofDaysInMonth));
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;
                case "10 - Actual/Standard    (31/360)":
                    AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                    AccruedInterest = AccruedInterest / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) * Convert.ToDouble(360));
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;
                case "11 - Actual/Actual      (31/365,6)":
                    AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                    AccruedInterest = AccruedInterest / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) / Convert.ToDouble(numberOfDaysInYear);
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;

                case "23 - Continuous/365":
                    AccruedInterest = (Convert.ToDouble(intRate) / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                    AccruedInterest = AccruedInterest * (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_1")) / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_365")));
                    AccruedInterest = Math.Exp(AccruedInterest);
                    AccruedInterest = (Convert.ToDouble(principalAmount) * AccruedInterest) - Convert.ToDouble(principalAmount);
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;

                case "12 - US Leap Year/366":
                    string monthparam = appHandle.GetDateParameters(DateoFirstDeposit)[0].Trim();
                    if (Int32.Parse(monthparam) > 2)
                    {
                        numberOfDaysInYear = 365;
                    }
                    AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate);
                    AccruedInterest = AccruedInterest / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) / Convert.ToDouble(numberOfDaysInYear);
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;

            }
            AccrInterest = AccruedInterest.ToString();
            return AccrInterest;
        }
        public virtual string CalculateAuthorizedNegativeAccrued(string ODLimitAmount, string TermInDays, string interestRate)
        {
            string AuthorizedNegativeaccr = "";
            string term = "";
            int numberOfDaysInYear = 0;
            double AuthorizedNegativeaccrued = 0;
            string Date = GetApplicationDate();

            string yearparam = appHandle.GetDateParameters(Date)[2].Trim();
            if (appHandle.IsLeapYear(Int32.Parse(yearparam)))
            {
                numberOfDaysInYear = 366;
            }
            else
            {
                numberOfDaysInYear = 365;
            }
            for (int i = 0; i < TermInDays.Length; i++)
            {
                if (TermInDays.Substring(i, 1).Any(char.IsNumber))
                {
                    term = term + TermInDays.Substring(i, 1);
                }
            }

            AuthorizedNegativeaccrued = Convert.ToDouble(ODLimitAmount) * Convert.ToDouble(term) * Convert.ToDouble(interestRate);
            AuthorizedNegativeaccrued = AuthorizedNegativeaccrued / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) * Convert.ToDouble(numberOfDaysInYear));
            AuthorizedNegativeaccrued = Math.Round(AuthorizedNegativeaccrued, 5);
            return AuthorizedNegativeaccr = AuthorizedNegativeaccrued.ToString();
        }
        public virtual string CalculateUnAuthorizedNegativeAccrued(string AccruedInterest, string AuthorizedNegativeAccrued)
        {
            string UnAuthAccr = "";
            double UnAuthorizedNegativeAccrued = Convert.ToDouble(AccruedInterest) - Convert.ToDouble(AuthorizedNegativeAccrued);
            return UnAuthAccr = UnAuthorizedNegativeAccrued.ToString();

        }
        public virtual void UpdateLoanInterestCalculationPage(string AccountNumber, string AccruCalcMethod = "")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Calculation Options"));
            WebCSRPageFactory.LoanCalculationOptionsPage.EnterCalculationPageOption(AccruCalcMethod);
            WebCSRPageFactory.LoanCalculationOptionsPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.LoanRateDeterminationPage.VerifyMessageInLoanRateDeterminationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Accrual Calculation Method is updated in Loan Calculation Option page under Account Information | Interest | Calculation Options .", "AccrualMethodUpdated", "True", appHandle);
            }
            else
            {
                Report.Fail("Accrual Calculation Method is not updated in Loan Calculation Option page under Account Information | Interest | Calculation Options .", "AccrualMethodisNotUpdated", "True", appHandle, true);
            }
        }
        public virtual void EnterOverdraftProcessingPageOption(string AccountNumber, string AuthOverLimit, string AuthOverTerm)
        {
            LoadAccountSummaryPage(AccountNumber);


            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Overdraft Processing"));
            if (WebCSRPageFactory.OverdraftProcessingPage.WaitUntilOverdraftProcessingPageloads())
            {
                WebCSRPageFactory.OverdraftProcessingPage.AuthorizedOverdraftOptions(AuthOverLimit, AuthOverTerm);
                WebCSRPageFactory.OverdraftProcessingPage.SelectSubmitButton();
                if (WebCSRPageFactory.OverdraftProcessingPage.VerifyMessageOverdraftProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Authorized Overdraft Limit and Terms are updated in Deposit Interest Payment Page.", "OverdraftProcessingPageUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Authorized Overdraft Limit and Terms are not updated in Deposit Interest Payment Page.", "OverdraftProcessingPageNotUpdated", "True", appHandle, true);
                }

            }
        }

        public virtual void AddNotesToAccount(string accno, string description, string expdate, string note)
        {

            WebCSRPageFactory.LoanAccountOverviewPage.ClickOnNotesLink();
            WebCSRPageFactory.AccountNotesPage.SelectAccount(accno);
            WebCSRPageFactory.AccountNotesPage.ClickOnAddButton();
            bool notesval = WebCSRPageFactory.AccountNotesPage.EnterDetailsOfNotes(description, expdate, note);
            if (notesval)
            {
                Report.Pass("The Notes added to account successfully", "notesaddpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Notes not added to account", "notesaddfail", "True", appHandle);
            }

        }
        public virtual void CloseAccount(string AccountNumber)
        {

            if (WebCSRPageFactory.AccountActivityPage.CloseAccount(AccountNumber))
            {
                Report.Pass("Account Closed Successfully", "CloseAccountSuccess", "true", appHandle);
            }
            else
            {
                Report.Fail("Account is not Closed", "CloseAccountSuccess", "true", appHandle, true);
            }

        }

        public virtual void ChangeProducTypeForAccount(string AccountNumber, string ProductName)
        {
            this.LoadAccountSummaryPage(AccountNumber);
            WebCSRPageFactory.AccountInformationPage.EditGeneralAccountInformation(ProductName);
            WebCSRPageFactory.AccountInformationPage.ClickOnSubmitBUtton();
        }
        public virtual void ValidateErrorMessagebleForProductType(string Message)
        {
            if (WebCSRPageFactory.AccountInformationPage.ValidateValidationMessage(Message))
            {
                Report.Pass("Validation Successful and Product Type not available", "ValidateErrorMessagebleForProductType", "true", appHandle);
            }
            else
            {
                Report.Fail("Not able to validate Validation Message", "ValidateErrorMessagebleForProductTypeFailure", "true", appHandle, true);
            }
        }
        public virtual string CreateRetirementPlanAccount(string PrimaryCustomerNumber, string retirementplanoption, string plandate, string retaccountnumber, string contamount, string conttype, int noOfBenificiary = 0, string BenCustNo = "", string EduIRArelationship = "", string Beneficiaryrelationship = "")
        {
            string AccountNumber = "";
            string appdateminus60Y = CalculateNewDate(plandate, "y", -60).ToString();
            string temptitle = appHandle.GetTitle();
            string CurrentValue_RealEstate_MortgageLoan = "";

            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            else if (temptitle.Contains(Data.Get("Verify Customer"))) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            if (WebCSRPageFactory.CreateAccountPage.VerifyCustomerNumberForAcctCreation(PrimaryCustomerNumber) == false)
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), PrimaryCustomerNumber);
            }
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown(Data.Get("GLOBAL_CREATE_RETIREMENT_ACCOUNT_ITEM"));
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateRetirementAccountPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateRetirementPlanPage.SelectRetirementPlanBasedOnPlanValue(retirementplanoption);
            WebCSRPageFactory.CreateRetirementPlanPage.ClickOnContinue();
            if (retirementplanoption == "Educational IRA Plan")
            {
                WebCSRPageFactory.CreateRetirementPlanPage.ClickOnSearch();
                WebCSRPageFactory.CustomerSearchPage.SearchForBeneficiaryCustomer(Data.Get("Customer Number"), BenCustNo);
                WebCSRPageFactory.CreateRetirementPlanPage.ClickOnSearch();
                WebCSRPageFactory.CreateRetirementPlanPage.ClickOnRadioButton();
            }
            WebCSRPageFactory.CreateRetirementPlanPage.ClickOnContinue();
            WebCSRPageFactory.CreateRetirementPlanPage.EnterDetailsForPlan(plandate, appdateminus60Y, noOfBenificiary, EduIRArelationship, Beneficiaryrelationship);
            WebCSRPageFactory.CreateRetirementPlanPage.ClickOnContinue();
            WebCSRPageFactory.CreateRetirementPlanPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateRetirementAccountPage.SelectRetirementAccount(retaccountnumber);
            WebCSRPageFactory.CreateRetirementAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateRetirementAccountPage.EnterRetireAccountDetails(contamount, conttype);
            WebCSRPageFactory.CreateRetirementAccountPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateRetirementAccountPage.CheckAccountSuccessMsg(Data.Get("GLOBAL_CONFIRMATION_MESSAGE"));
            string retaccount = WebCSRPageFactory.CreateRetirementAccountPage.GetRetirementAccount();
            if (!String.IsNullOrEmpty(retaccount))
            {
                Report.Pass("The Retirement Plan Account is created successfully " + retaccount, "retaccntpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Retirement Plan Account is created successfully " + retaccount, "retaccntFail", "True", appHandle);
            }

            return retaccount;

        }


        public virtual void CheckAccountBalancesAccountInformation(string sLabelNameLabelValuePipeDelimited)
        {
            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is captured successfully as " + arr[b].Split('|')[1] + " in  Account Information page";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is captured successfully as  " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in  Account Information page";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebCSRPageFactory.AccountInformationPage.AccountBalancesAccountInformation(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(msg, "avblbalcheck", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "avblbalcheckfail", "True", appHandle, true);
            }
        }
        public virtual void VerifyAccountOverViewTableByLabelNameValue(string AccountNumber, string sLabelNameLabelValuePipeDelimited)
        {
            string msg = "";
            string failmsg = "";
            string temp = "";
            string[] arr = null;

            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is captured successfully as " + arr[b].Split('|')[1] + " in  Account Overview page";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is captured successfully as  " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in  Account Overview page";
                failmsg = msg.Replace(" is ", " is not ");
            }

            WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
            if (WebCSRPageFactory.LoanAccountOverviewPage.VerifyLoanAccountOverviewValuesBylabelNameLabelValue(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(msg, "acctoverviwpage", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "acctoverviwpagefail", "True", appHandle, true);
            }
        }
        public virtual void UpdateAuthorizedOverdraftInOverdraftProcessing(string Account, string AuthorizeOverdraftLimit, string AuthorizeOverdraftTerm, string TempAuthorizedOverdraftLimitSpread, string TempAuthorizedOverdraftLimitStartDate, string TempAuthorizedOverdraftLimitEndDate)
        {
            LoadAccountSummaryPage(Account);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Overdraft Processing"));
            WebCSRPageFactory.DepositAccountInformationPage.SelectAccountFromAccountsDropdown(Account);
            WebCSRPageFactory.DepositAccountInformationPage.UpdateAuthorizedOverdraftDetails(AuthorizeOverdraftLimit, AuthorizeOverdraftTerm, TempAuthorizedOverdraftLimitSpread, TempAuthorizedOverdraftLimitStartDate, TempAuthorizedOverdraftLimitEndDate);
            WebCSRPageFactory.DepositAccountInformationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositAccountInformationPage.ValidateCustomerInfoUpdateMSG())
            {
                Report.Pass("Authorized Overdraft Details updated successfully", "ValidateCustomerInfoUpdateMSG", "True", appHandle);
            }
            else
            {
                Report.Fail("Authorized Overdraft Details failed to update ", "ValidateCuTomerInfoUpdateMSGfail", "True ", appHandle, true); ;

            }

        }
        public virtual void VerifyTotalAuthorizedOverdraftLimit(string AccountNumber, String sLabelNameLabelValuePipeDelimited)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Overdraft Processing"));
            if (WebCSRPageFactory.DepositAccountInformationPage.VerifyDatainAuthorizedOverdraft(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is captured as : " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in Authorized Overdraft.", "totAuthODLI", "True", appHandle);
            }
            else
            {
                Report.Fail(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is not captured as : " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in  Authorized Overdraft.", "totAuthODLIfail", "True", appHandle, true);
            }
        }
        public virtual void VerifyTemporaryAuthorizedOverdraftLimit(string Account, string LabelNamePipeDelimitedExpectedvalue)
        {
            LoadAccountSummaryPage(Account);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Overdraft Processing"));
            if (WebCSRPageFactory.DepositAccountInformationPage.VerifyFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in Authorized Overdraft.", "totAuthODLI", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in  Authorized Overdraft.", "totAuthODLIfail", "True", appHandle, true);
            }
        }

        public virtual void VerifyAccrualInterest(string Account, string sLabelNameLabelValuePipeDelimited)
        {
            LoadAccountSummaryPage(Account);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Accrual"));
            if (WebCSRPageFactory.DepositInterestAccrualPage.VerifyTableDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is captured as : " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in Deposit Accural Page.", "VerifyAccuralInterest", "True", appHandle);
            }
            else
            {
                Report.Fail(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is not captured as : " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in  Deposit Accural Page.", "VerifyAccuralInterestfail", "True", appHandle, true);
            }
        }

        public virtual void VerifySpecifiedCurrencyCodeExistInPermanentHoldCurrencyCodeDropdown(string AccountNumber, string CurrencyValuePipeDelimited, string Amount = "", string sHoldCode = "", string ExpirationDate = "", string PercentageOfAccountBalanceHoldPercentage = "", string PercentageOfAccountBalanceAccountNo = "", string PercentageOfAccountBalanceBalanceType = "", string CurrencyCode = "")
        {
            string msg = "";

            if (CurrencyValuePipeDelimited.Contains("|"))
            {
                msg = string.Join(" , ", CurrencyValuePipeDelimited.Split('|'));
            }
            else
            {
                msg = CurrencyValuePipeDelimited;
            }
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            WebCSRPageFactory.HoldsPage.SelectAccountFromDropdown(AccountNumber);
            WebCSRPageFactory.HoldsPage.ClickOnAddButton();
            WebCSRPageFactory.HoldsPage.EnterPHLDDetails(sHoldCode, Amount, PercentageOfAccountBalanceHoldPercentage, PercentageOfAccountBalanceAccountNo, PercentageOfAccountBalanceBalanceType, CurrencyCode, ExpirationDate);
            if (WebCSRPageFactory.HoldsPage.VerifySpecifiedCurrencyCodeAvailableInPermanentHoldCurrencyCodeDropdown(CurrencyValuePipeDelimited))
            {
                Report.Pass(msg + " is/are present in Currency Code Dropdown", "currvalue", "True", appHandle);
            }
            else
            {
                Report.Fail(msg + " is/are not present in Currency Code Dropdown", "currvalue", "True", appHandle, true);
            }
        }

        public virtual void VerifyAmountOfBalanceHeldInPermanentHoldsPage(string AccountNumber, string AmountToBeSelectedInHoldsTable, string expectedAmtOfBalHeld)
        {
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            if (WebCSRPageFactory.HoldsPage.VerifyAmountOfBalanceHeldForPHLDHold(AccountNumber, AmountToBeSelectedInHoldsTable, expectedAmtOfBalHeld))
            {
                Report.Pass(expectedAmtOfBalHeld + " is matching with Amount of Balance Held in Permanent holds page successfully.", "amtofbalheldpass", "True", appHandle);
            }
            else
            {
                Report.Fail(expectedAmtOfBalHeld + " is not  matching with Amount of Balance Held in Permanent holds page successfully.", "amtofbalheldpass", "True", appHandle, true);
            }

        }
        public virtual string GetAmountOfBalanceHeldForPHLDHold(string AccountNumber, string AmountToBeSelectedInHoldsTable)
        {
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            string AmountOfBalHeld = WebCSRPageFactory.HoldsPage.GetAmountOfBalanceHeldForPHLDHold(AccountNumber, AmountToBeSelectedInHoldsTable);
            AmountOfBalHeld = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(AmountOfBalHeld);
            Report.Info(AmountOfBalHeld + " is captured successfully.", "AmountOfBalHeld", "True", appHandle);
            return AmountOfBalHeld;
        }
        /// <summary>
        /// This method is used to calculate total hold amount when Fixed amount, AmountOfBalHeld and Hold percentage is known.
        /// Before using this method the arguments needs to be handy.
        /// </summary>
        /// <param name="FixedAmount"></param>
        /// <param name="AmountOfBalHeld"></param>
        /// <param name="HoldPercentage"></param>
        /// <returns>Total hold Amount</returns>
        public virtual string CalculateTotalHoldAmountForPermanentHold(string FixedAmount, string AmountOfBalHeld, string HoldPercentage)
        {
            string totamt = "";
            double result = 0;

            double amt = Convert.ToDouble(AmountOfBalHeld) * ((Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_1")) - Convert.ToDouble(Convert.ToDouble(HoldPercentage) / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")))));
            if (amt == 0)
            {
                result = Convert.ToDouble(FixedAmount) + Convert.ToDouble(AmountOfBalHeld);
            }
            else
            {
                amt = Convert.ToDouble(AmountOfBalHeld) - amt;
                result = Convert.ToDouble(FixedAmount) + amt;
            }
            totamt = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(result.ToString());
            return totamt;
        }

        public virtual void CancelAddHold()
        {
            WebCSRPageFactory.HoldsPage.ClickOnCancelButton();
        }
        /// <summary>
        /// This method is used to validate data in Account history table .
        /// AccountNumber : Mandatory parameter
        /// refColumnValuesSemicolonDelimited : Mandatory parameter . Column values of a particular row can be passed as "02/02/2020;50,000;0.99" . Column values for multiple rows can be passed as : "02/02/2020;50,000;0.99" +"|"+"02/06/2020;60,000;1.99" 
        /// FromDate : Optional parameter
        /// ToDate : OptionalParameter
        /// AdvancedSearchTransactionTypeCriteria : Optional parameter . Can be passed as :  Example : "Non-Monetary" or "Check Number|234343" or "Check Range|300|345"
        /// AdvancedSearchTransactionAmountCriteria : Optional parameter . Can be passed as passed for AdvancedSearchTransactionTypeCriteria
        /// AdvancedTransactionOtherTransactionInformationCriteria: Optional Parameter . Can be passed as passed for AdvancedSearchTransactionTypeCriteria
        /// AdvancedTransactionSortOrder : Optional parameter . Can be passed as passed for AdvancedSearchTransactionTypeCriteria
        /// </summary>
        /// <param name="AccountNumber"></param>
        /// <param name="refColumnValuesSemicolonDelimited"></param>
        /// <param name="FromDate"></param>
        /// <param name="ToDate"></param>
        /// <param name="AdvancedSearchTransactionTypeCriteria"></param>
        /// <param name="AdvancedSearchTransactionAmountCriteria"></param>
        /// <param name="AdvancedTransactionOtherTransactionInformationCriteria"></param>
        /// <param name="AdvancedTransactionSortOrder"></param>
        public virtual void VerifyDataInAccountHistoryTable(string AccountNumber, string refColumnValuesSemicolonDelimited, string FromDate = "", string ToDate = "", string AdvancedSearchTransactionTypeCriteria = "", string AdvancedSearchTransactionAmountCriteria = "", string AdvancedTransactionOtherTransactionInformationCriteria = "", string AdvancedTransactionSortOrder = "")
        {

            if (!appHandle.GetTitle().Contains(Data.Get("Account History")))
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("AccountNumber"));
                WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_ACCOUNTLIST"));
                WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Account History"));
            }
            else
            {
                if (WebCSRPageFactory.AccountHistoryPage.VerifyAccountExistsInAccountDropdown(AccountNumber)) { }
                else
                {
                    WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("AccountNumber"));
                    WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_ACCOUNTLIST"));
                    WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                    this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Account History"));
                }
            }

            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (refColumnValuesSemicolonDelimited.Contains("|"))
            {
                arr = refColumnValuesSemicolonDelimited.Split('|');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split(';')) + " is captured successfully in  Account History table in WebCSR.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", refColumnValuesSemicolonDelimited.Split(';')) + " is captured successfully in  Account History table in WebCSR.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebCSRPageFactory.AccountHistoryPage.VerifyDataInAccountHistory(AccountNumber, refColumnValuesSemicolonDelimited, FromDate, ToDate, AdvancedSearchTransactionTypeCriteria, AdvancedSearchTransactionAmountCriteria, AdvancedTransactionOtherTransactionInformationCriteria, AdvancedTransactionSortOrder))
            {
                Report.Pass(msg, "AccountHistoryCheck", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "AccountHistoryCheck", "True", appHandle, true);
            }
        }
        /// <summary>
        /// To calculate monthly Payment Amount for a Loan account.
        /// </summary>
        /// <param name="DisbursedAmount"></param>
        /// <param name="InterestRate"></param>
        /// <param name="Term"></param>
        /// <returns></returns>
        public virtual string CalculateLoanEMIAmount(string DisbursedAmount, string InterestRate, string Term)
        {
            string LoanEMIAmount = "";
            if (InterestRate.Contains("%"))
            {
                InterestRate = InterestRate.Replace("%", string.Empty);
            }
            if (Term.Contains("Y"))
            {
                Term = Int32.Parse(Term.Split('Y')[0].Trim()) * 12 + "";
            }
            if (Term.Contains("M"))
            {
                Term = Term.Split('M')[0].Trim();
            }
            double intrate = Convert.ToDouble(InterestRate);
            double ratedenominator = Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) * (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_12")));
            intrate = intrate / ratedenominator;
            double disbamt = Convert.ToDouble(DisbursedAmount);
            double nper = Convert.ToDouble(Term);
            double tempAmount = Financial.Pmt(intrate, nper, disbamt);
            LoanEMIAmount = tempAmount.ToString();
            LoanEMIAmount = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(LoanEMIAmount);
            LoanEMIAmount = LoanEMIAmount.Replace("-", string.Empty).Trim();
            return LoanEMIAmount;
        }
        /// <summary>
        /// This method is used to calulate Annual Disclosure Rate for a loan account.
        /// </summary>
        /// <param name="DisbursedAmount"></param>
        /// <param name="InterestRate"></param>
        /// <param name="Term"></param>
        /// <returns></returns>
        public virtual string CalculateAnnualDisclosureRate(string DisbursedAmount, string InterestRate, string Term)
        {
            string AnnualDisclosureRate = "";
            List<double> PaymentList = new List<double>();
            double[] payments = null;
            double AnnualDisRate = 0;
            if (InterestRate.Contains("%"))
            {
                InterestRate = InterestRate.Replace("%", string.Empty);
            }
            string tempTerm = Term;
            if (Term.Contains("Y"))
            {
                Term = Int32.Parse(Term.Split('Y')[0].Trim()) * 12 + "";
            }
            if (Term.Contains("M"))
            {
                Term = Term.Split('M')[0].Trim();
            }
            int numberofPayments = Int32.Parse(Term);
            string LoanEMIAmount = this.CalculateLoanEMIAmount(DisbursedAmount, InterestRate, tempTerm);
            PaymentList.Add(Convert.ToDouble("-" + DisbursedAmount));
            for (int a = 0; a < numberofPayments; a++)
            {
                PaymentList.Add(Convert.ToDouble(LoanEMIAmount));
            }
            payments = PaymentList.ToArray();
            AnnualDisRate = Financial.IRR(ref payments, 0) * (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) * (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_12"))));
            AnnualDisRate = Math.Round(AnnualDisRate, 5);
            AnnualDisclosureRate = AnnualDisRate.ToString();
            return AnnualDisclosureRate;
        }
        public virtual void ReloadWebCSRapplication(string ApplicationName)
        {
            Profile7CommonLibrary.ReloadApplication(Data.Get("WebCSR"));

        }
        public virtual string LoanCalculateAccruedInterestByAccrMethod(string accrualMethod, string principalAmount, int intRate, int numberOfDaysPassed, string Date = "", string DIP = "", string NextDueDate = "", int Roundoff = 5)
        {
            NavigatetoInterestBalancePage();
            string AccrInterest = "";
            double AccruedInterest = 0;
            string AFVal = Data.Get("AnnualFactor");
            double AF = Convert.ToDouble(AFVal);
            int numberOfDaysInYear = 0;
            if (string.IsNullOrEmpty(Date))
            {
                Date = GetApplicationDate();
            }
            string yearparam = appHandle.GetDateParameters(Date)[2].Trim();
            if (appHandle.IsLeapYear(Int32.Parse(yearparam)))
            {
                numberOfDaysInYear = 366;
            }
            else
            {
                numberOfDaysInYear = 365;
            }
            int numberofDaysInMonth = GetNumberOfDaysInAMonth(Date);
            switch (accrualMethod)
            {
                case "03 - Standard/365 (30/365)":
                    AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed) * Convert.ToDouble(360);
                    AccruedInterest = AccruedInterest / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) * AF * Convert.ToDouble(365) * Convert.ToDouble(DIP));
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;
                case "11 - Actual/Actual (31/365,6)":
                    AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                    AccruedInterest = AccruedInterest / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")) * Convert.ToDouble(numberOfDaysInYear));
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;

            }
            AccrInterest = AccruedInterest.ToString();
            return AccrInterest;
        }


        public virtual void UpdateEFDRateChangeOption(string AccountNumber, string EffDate, string fixedRateType, string NewIntRate)
        {
            this.ClickLinkFromMenuItem(Data.Get("Loan Account Services") + "|" + Data.Get("EFD Rate Change"));
            WebCSRPageFactory.AccountVerificationPage.SelectAccountFromAccountsDropdown(AccountNumber);
            WebCSRPageFactory.LoanAccountServicesProjectedActivityPage.EnterEFDRateChangeOption(EffDate, fixedRateType, NewIntRate);
            WebCSRPageFactory.LoanAccountServicesProjectedActivityPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.LoanAccountServicesProjectedActivityPage.VerifyMessageInLoanAccountServicesProjectedActivityPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("EFD rates are updated", "AccountVerificationStatusPass", "true", appHandle);
            }
            else
            {
                Report.Fail("EFD rates are not updated ", "AccountVerificationStatusFail", "true", appHandle, true);
            }

        }
        public virtual string GetTextFromTextFieldByRefLabel(string sLabelName)
        {
            string LabelValue = null;
            try
            {
                string objXpath = WebCSRPageFactory.WebCSRMasterPage.GenerateXpathForTextbox(sLabelName);
                LabelValue = WebCSRPageFactory.WebCSRMasterPage.GetTextBasedOnLabel(objXpath);
                if (LabelValue != null)
                    Report.Info("Successfully fetched the text value", "labelvalue", "False", appHandle);
                else
                    Report.Fail("Failed to fetch the text value", "labelvalue", "True", appHandle);


            }
            catch (Exception e)
            {
                Report.Info("Exception logged : " + e);
            }
            return LabelValue;
        }

        public virtual void VerifyInterestCalOptionCompoundedNextDateFieldVal(string sExpVal)
        {
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Accrual"));
            try
            {
                string ActVal = WebCSRPageFactory.DepositInterestAccrualPage.GetCompoundedNextDateFieldVal();
                if (sExpVal.Equals(ActVal))
                    Report.Pass("Expected value is there in Field", "output", "True", appHandle);
                else
                    Report.Fail("Expected value is not there in Field", "output", "True", appHandle);
            }
            catch (System.Exception e) { Report.Info("Exception Logged:" + e); }
        }

        public virtual void VerifyBorrowerTotalInProjectedActivityDetails()
        {
            string BorrowerTotal = WebCSRPageFactory.LoanAccountServicesProjectedActivityPage.CalculateBorrowerTotal();
            this.VerifyProjectedActivityDetailsByLabelnameLabelValue(Data.Get("Borrower Total") + "|" + BorrowerTotal);
        }
        public virtual void VerifySpecifiedHoldNotPresentInHoldsTable(string AccountNumber, string HoldType, string Amount, string ExpirationDate = "")
        {
            string msg = "Hold details : Amount = " + Amount + " , Hold type = " + HoldType + " , Expiration Date =" + ExpirationDate + " for Account number : " + AccountNumber + " is not found in hold table successfully.";
            string failmsg = msg.Replace("is", "is not ");
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            if (WebCSRPageFactory.HoldsPage.VerifySpecifiedHoldNotPresentInHoldsTable(AccountNumber, HoldType, Amount, ExpirationDate))
            {

                Report.Pass(msg, "holdatanegativetest", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "holdatanegativetestfailed", "True", appHandle, true);
            }
        }
        public virtual void VerifyEligibleforAlertsCheckbox(string CustomerNumber)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.ChecktheAlertCheckboxisEnabled())
            {
                Report.Pass("Eligible for Alerts Checkbox is checked in customer Information", "CustomerInformation", "True", appHandle);

            }
            else
            {
                Report.Fail("Eligible for Alerts Checkbox is not checked in customer Information", "CustomerInformation", "True", appHandle, true);

            }
        }
        public virtual void ModifySeasonalMailingAddressOnTitleAddress(string AccountNumber, string Startdate, string EndDate, string AddressLine1, string AddressLine2, string City, string Country, string State, string Zipcode)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Title/Address"));
            WebCSRPageFactory.LoanTitleAddressPage.SelectAccountFromAccountsDropdown(AccountNumber);
            WebCSRPageFactory.LoanTitleAddressPage.ModifySeasonalMailingAddress(Startdate, EndDate, AddressLine1, AddressLine2, City, Country, State, Zipcode);
            WebCSRPageFactory.LoanTitleAddressPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositAccountInformationPage.ValidateCustomerInfoUpdateMSG())
            {
                Report.Pass("Customer Seasonal Address updated successfully in Loan Title/Address Page", "ValidateCustomerInfoUpdateMSG", "True", appHandle);
            }
            else
            {
                Report.Fail("Customer Seasonal Address failed to update ", "ValidateCuTomerInfoUpdateMSGfail", "True ", appHandle, true); ;

            }


        }
        public virtual void ModifyNonSeasonalMailingAddressOnTitleAddress(string AccountNumber, string AddressLine1, string AddressLine2, string City, string Country, string State, string Zipcode)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Title/Address"));
            WebCSRPageFactory.LoanTitleAddressPage.SelectAccountFromAccountsDropdown(AccountNumber);
            WebCSRPageFactory.LoanTitleAddressPage.ModifyNonSeasonalMailingAddress(AddressLine1, AddressLine2, City, Country, State, Zipcode);
            WebCSRPageFactory.LoanTitleAddressPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.LoanTitleAddressPage.VerifySeasonalAddressErrorMSG())
            {
                Report.Pass(" Error Message for updating NonSeasonal Mailing Address was Verified in Loan Title/Address Page", "VerifySeasonalAddressErrorMSG", "True", appHandle);
            }
            else
            {
                Report.Fail("Error Message Message for updating NonSeasonal Mailing Address was not Verified in Loan Title/Address Page", "VerifySeasonalAddressErrorMSG", "True", appHandle, true);
            }
            WebCSRPageFactory.LoanTitleAddressPage.ClickOnCancelButton();

        }
        public virtual void VerifySeasonalAddressUpdatedonTitleAddressPage(string Account, string LabelNamePipeDelimitedExpectedvalue)
        {
            LoadAccountSummaryPage(Account);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Title/Address"));
            if (WebCSRPageFactory.LoanTitleAddressPage.VerifySeasonalAddressByFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in Mailing Address.", "AccountInformation", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in  Mailing Address.", "AccountInformation", "True", appHandle, true);
            }
        }
        public virtual void VerifyNonSeasonalAddressUpdatedonTitleAddressPage(string Account, string LabelNamePipeDelimitedExpectedvalue)
        {
            LoadAccountSummaryPage(Account);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Title/Address"));
            if (WebCSRPageFactory.LoanTitleAddressPage.VerifyNonSeasonalAddressByFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in Mailing Address.", "AccountInformation", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in  Mailing Address.", "AccountInformation", "True", appHandle, true);
            }
        }

        public virtual void VerifyMailingAddressUpdatedonTitleAddressPage(string Account, string LabelNamePipeDelimitedExpectedvalue)
        {
            LoadAccountSummaryPage(Account);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Title/Address"));
            if (WebCSRPageFactory.LoanTitleAddressPage.VerifyMailingAddressByFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in Mailing Address.", "AccountInformation", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in  Mailing Address.", "AccountInformation", "True", appHandle, true);
            }
        }
        public virtual void SelectSpecifiedTabInAccountInformationPage(string tabname)
        {
            WebCSRPageFactory.AccountInformationPage.SelectTabInAccountInformation(tabname);
        }


        public virtual void UpdateValueOfNegativeAmountBeforeOverdrawn(string value)
        {
            WebCSRPageFactory.AccountInformationPage.SelectSubLinkOfTransactionProcessing("Overdraft Processing");
            bool retval = WebCSRPageFactory.OverdraftProcessingPage.UpdateValueOfNegativeAmountBeforeOverdrawn(value);
            if (retval)
            {
                Report.Pass("The Overdraft value is updated successfully", "odv", "True", appHandle);
            }
            else
            {
                Report.Fail("The Overdraft value is not updated", "odvf", "True", appHandle);

            }

        }

        public virtual void SelectSpecifiedHeaderInDepositAccountOverview(string headername)
        {
            WebCSRPageFactory.DepositAccountOverviewPage.SelectHeaderInDepositAccountOverview(headername);
        }


        public virtual void UpdateValueOfStatementGroupInAccountInformation(string statementgroupval)
        {
            if (WebCSRPageFactory.AccountInformationPage.UpdateStatementGroupVal(statementgroupval))
            {
                Report.Pass("The Statement Group data is updated", "dty", "True", appHandle);
            }
            else
            {
                Report.Fail("The Statement Group data is not updated", "dtf", "True", appHandle);

            }

        }

        public virtual void SelectLeftSideMenuOptionStatementGroups()
        {

            WebCSRPageFactory.AccountOverviewPage.ClickOnStatementGroupLink();

        }

        public virtual void UpdateValueForStatementGroup(string statementgroupval, string frequency, string acc1, string acct2)
        {
            WebCSRPageFactory.StatementGroupPage.SelectStatementGroupFromTable(statementgroupval);
            WebCSRPageFactory.EditSatementGroupPage.EnterDataForFrequency(frequency);
            // WebCSRPageFactory.EditSatementGroupPage.SelectAccountFromTable(acc1); 
            //WebCSRPageFactory.EditSatementGroupPage.SelectAccountFromTable(acc1); 
            WebCSRPageFactory.EditSatementGroupPage.ClickOnSubmit();


        }




        public virtual string GetValueOfInterestFromHistoryTable()
        {
            return WebCSRPageFactory.DepositAccountOverviewPage.GetValueOfInterest();

        }

        public virtual void VerifyValuesInStatementReport(string filenamewithpath, string recordnumbertocheck, string uniquerefval, string checkvaluesseperatedbydelimsemicolon)
        {
            bool resflg = false;
            string[] filedata = File.ReadAllLines(filenamewithpath);
            string[] verval = checkvaluesseperatedbydelimsemicolon.Split(';');
            for (int i = 0; i < filedata.Length; i++)
            {
                string line = filedata[i];
                string recordname = line.Substring(0, 3);
                if (recordname.Equals(recordnumbertocheck) && line.Contains(uniquerefval))
                {
                    for (int j = 0; j < verval.Length; j++)
                    {
                        if (line.Contains(verval[j]))
                        {
                            resflg = true;
                        }
                        else
                        {
                            resflg = false;
                        }
                    }

                    if (resflg == true)
                    {
                        Report.Pass("The Expected values " + checkvaluesseperatedbydelimsemicolon + " Present in extract code", "extp", "True", appHandle);
                    }
                    else
                    {
                        Report.Pass("The Expected values " + checkvaluesseperatedbydelimsemicolon + " not Present in extract code", "extp", "True", appHandle);

                    }

                    break;


                }


            }


        }


        public virtual void SelectAccountClosureUtilityLink()
        {
            WebCSRPageFactory.DepositAccountOverviewPage.ClickOnAccountClosureUtilityLink();
        }

        public virtual void CheckDataInAccountLinkageTable(string accnum, string linkagetypeval)
        {
            WebCSRPageFactory.AccountClosureUtilityPage.CheckDataInAccountLinkageTable(accnum, linkagetypeval);
        }

        public virtual void ClickOnCustomerServicesServiceManagementLink()
        {
            WebCSRPageFactory.AccountOverviewPage.ClickOnCustomerServicesServiceManagmentLink();
        }

        public virtual void PerformOperationsInEstablishedServices()
        {
            WebCSRPageFactory.ServiceManagementPage.PerformOperationsInEstablishedServices();
        }

        public virtual void CheckValueInAccountCloseDropdown(string valuetobechcked)
        {
            if (WebCSRPageFactory.AccountInformationPage.CheckValueInAccountStatusdropdown(valuetobechcked))
            {
                Report.Pass("The Account Status Dropdown has specified value and account is closed", "drp", "True", appHandle);
            }
            else
            {
                Report.Fail("The Account Status Dropdown does not have specified value and account not closed", "drp1", "True", appHandle);
            }
        }


        public virtual void CheckDataNotAvailableInAccountLinkageTable(string accnum, string linkagetypeval)
        {
            if (!WebCSRPageFactory.AccountClosureUtilityPage.CheckDataNotInAccountLinkageTable(accnum, linkagetypeval))
            {
                Report.Pass("The expected message present in account closure utility screen", "sc1", "True", appHandle);
            }
            else
            {
                Report.Fail("The expected message not present in account closure utility screen", "sc12", "True", appHandle);


            }
        }

        public virtual void UpdateMailingAddressOfCustomer(string custid, string address, string city, string state, string country, string zipcode)
        {
            Application.WebCSR.GetCustomer(custid);
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown("Customer Information");
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            Profile7CommonLibrary.SelectTabSubTabInApplication("Address");
            WebCSRPageFactory.AddressPage.SelectValueOfSameAsHomeAddressRadioButton(false);
            WebCSRPageFactory.AddressPage.EnterMailingAddressDetails(address, city, country, state, zipcode);
            WebCSRPageFactory.AddressPage.ClickonSubmitbutton();
            if (WebCSRPageFactory.AddressPage.checkSuccessMessage())
            {
                Report.Pass("The Mailing Address Updated", "mup", "True", appHandle);
            }
            else
            {
                Report.Fail("The Mailing Address not Updated", "mupf", "True", appHandle);

            }





        }

        public virtual string GetCustomerLastNameInNameTab()
        {
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown("Customer Information");
            Application.WebAdmin.ClickonTabinProductPage("Name");
            return WebCSRPageFactory.NameChangePage.GetCustomerastName();
        }

        public virtual string UpdateCustomerTaxID(string CustmerNumber, bool blank = true, bool irrtrustcust = false)
        {
            GetCustomer(CustmerNumber);
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown("Customer Information");
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            string newtaxid = "";
            if (blank == false)
            {
                if (WebCSRPageFactory.CustomerInformationPage.UpdateTaxID(newtaxid))
                {
                    Report.Pass("The customer tax id information field is set as blank", "txp1", "True", appHandle);
                }
            }
            else if (irrtrustcust == true)
            {
                newtaxid = RandomNumberGenerator.GenerateRandomNumberByFormat(Data.Get("GLOBAL_CORPORATE_TAX_ID_FORMAT"), "-");
                if (WebCSRPageFactory.CustomerInformationPage.UpdateTaxID(newtaxid))
                {
                    Report.Pass("The customer tax id information is updated", "txp", "True", appHandle);
                }
                else
                {
                    Report.Fail("The customer tax id information is not updated", "txf", "True", appHandle);
                }
            }
            else
            {
                newtaxid = GenerateTaxId(Data.Get("GLOBAL_BENEFICIARY_TAX_ID_FORMAT"));
                if (WebCSRPageFactory.CustomerInformationPage.UpdateTaxID(newtaxid))
                {
                    Report.Pass("The customer tax id information is updated", "txp", "True", appHandle);
                }
                else
                {
                    Report.Fail("The customer tax id information is not updated", "txf", "True", appHandle);
                }
            }
            return newtaxid;
        }
        public virtual void DeleteSeasonalMailingAddressOnTitleAddress(string AccountNumber, string Startdate = null, string EndDate = null, string AddressLine1 = null, string AddressLine2 = null, string City = null, int Country = 1, int State = 1, string Zipcode = null)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Title/Address"));
            WebCSRPageFactory.LoanTitleAddressPage.SelectAccountFromAccountsDropdown(AccountNumber);
            WebCSRPageFactory.LoanTitleAddressPage.DeleteSeasonalMailingAddress(Startdate, EndDate, AddressLine1, AddressLine2, City, Zipcode);
            WebCSRPageFactory.LoanTitleAddressPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositAccountInformationPage.ValidateCustomerInfoUpdateMSG())
            {
                Report.Pass("Customer Seasonal Address deleted successfully in Loan Title/Address Page", "ValidateCustomerInfoUpdateMSG", "True", appHandle);
            }
            else
            {
                Report.Fail("Customer Seasonal Address failed to delete in Loan Title/Address Page", "ValidateCustomerInfoUpdateMSG", "True ", appHandle, true); ;

            }
        }
        public virtual void AddAlertSetuptoPersonalCustomer(string AccountNumber)
        {
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Service Management"));
            WebCSRPageFactory.CustomerServicesServiceManagementPage.ClickOnAddButton();
            WebCSRPageFactory.CustomerServicesServiceManagementPage.ClickOnRefreshListButton();
            if (WebCSRPageFactory.CustomerServicesServiceManagementPage.VerifyListRefreshSuccess())
            {
                Report.Info("Alert setup is added to PersonalCustomer in ServiceManagement Page", "AddAlertSetuptoPersonalCustomer", "true", appHandle);
            }
            else
            {
                Report.Fail("Alert setup is not added to PersonalCustomer in ServiceManagement Page", "AddAlertSetuptoPersonalCustomer", "true", appHandle, true);
            }
        }

        public virtual void AddAlertOnAlertManagementPage(string AlertType, string Account, string Threshold, string Amount)
        {
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Alert Management"));
            WebCSRPageFactory.CustomerServicesAlertManagementPage.ClickOnAddButton();
            WebCSRPageFactory.CustomerServicesAlertManagementPage.AddAlertToAccount(AlertType, Account, Threshold, Amount);
            WebCSRPageFactory.CustomerServicesAlertManagementPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerServicesAlertManagementPage.VerifyAddAlertSuccessMSG())
            {
                Report.Pass("Alert is  sucessfully added in Aler Management Page.", "AddAlertOnAlertManagementPage", "True", appHandle);
            }
            else
            {
                Report.Fail("Alert is not added to the customer in Alert Management Page.", "AddAlertOnAlertManagementfail", "True", appHandle, true);
            }
        }
        public virtual void VerifyCustomerAlertGenerated(string AccountNumber, string sLabelNameLabelValuePipeDelimited)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("Account Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_ACCOUNTLIST"));
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Alert Management"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Alert Management"), Data.Get("Alert Messages"));
            WebCSRPageFactory.CustomerServicesAlertManagementPage.VerifyTableDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited);
            Report.Pass("Customer Alert is Generated while determining an Overdraft Limit Tolerance alert.", "VerifyCustomerAlertGenerated", "true", appHandle);
        }
        public virtual void UpdateDateOfDeathInCustomerInformation(string AccountNumber, string Date)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("Account Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.CustomerInformationPage.UpdateDateOfDeath(Date);
            WebCSRPageFactory.CustomerInformationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.VerifyCustomerInformationUpdateMsg())
            {
                Report.Pass("Customer Date of Death is updated in Customer information Page.", "CustomerInformationPage", "true", appHandle);

            }
            else
            {
                Report.Fail("Customer Date of Death is not updated in Customer information Page.", "CustomerInformationPagefail", "true", appHandle, true);
            }
        }

        public virtual void UpdatePositiveInterestPostingFrequencyInPaymentPage(string Account, string Frequency)
        {
            LoadAccountSummaryPage(Account);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Payment"));
            WebCSRPageFactory.DepositPaymentPage.UpdatePositiveInterestPostingFrequency(Frequency);
            WebCSRPageFactory.DepositPaymentPage.SelectSubmitButton();
            if (WebCSRPageFactory.DepositPaymentPage.VerifyMessageDepositPaymentPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Payment Frequency was updated successfully in Payment Page", "PositiveInterestPostingFrequencyInPaymentPage", "true", appHandle);
            }
            else
            {
                Report.Fail("The Payment Frequency was not updated successfully in Payment Page", "PositiveInterestPostingFrequencyInPaymentPagefails", "true", appHandle, true);
            }

        }
        public virtual string CreatePersonalCustomerByVaildZipCode(string city, string state, string zipCode)
        {
            string CustomerNo = "";
            WebCSRPageFactory.WebCSRMasterPage.select_create_personal_customer_link();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_personal_information_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_drivers_license_identification_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_email_and_phone_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enterhomeaddressdetailsZipCodeValid(city, state, zipCode);
            WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_mailing_address_same_as_home_address_no();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_mailing_address_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_previous_address_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_online_access_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_security_question_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_telephone_banking_details();
            string sTaxIdValue1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_tax_id_number_field_value();
            WebCSRPageFactory.CreatePersonalCustomerPage.select_continue_button();
            WebCSRPageFactory.CreatePersonalCustomerPage.select_submit_button();

            if (WebCSRPageFactory.CreatePersonalCustomerPage.VerifyPersonalCustomerCreationSuccess())
            {
                Report.Pass("Personal Customer application is created successfully", "PersonalCustCreate", "true", appHandle);

                CustomerNo = WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("GLOBAL_SEARCHTYPE_TAXID"), sTaxIdValue1);
                if (!string.IsNullOrEmpty(CustomerNo))
                {
                    Report.Pass("Personal customer number is captured as: " + CustomerNo, "custpersonal", "true", appHandle);
                }
            }
            else
            {
                Report.Fail("Personal Customer application is not created due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "CreatePersonalcustFail", "true", appHandle, true);
            }



            return CustomerNo;
        }
        public virtual void UpdateZipCodeOfHomeAddressInAddressPage(string Customer, string Zipcode)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(Customer, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            WebCSRPageFactory.CustomerInformationAddressChangePage.UpdateHomeAddressZipCode(Zipcode);
            WebCSRPageFactory.CustomerInformationAddressChangePage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationAddressChangePage.ValidateAddressInfoUpdateMSG())
            {
                Report.Pass("ZipCode is updated in the Address Page.", "AddressChangePage", "true", appHandle);
            }
            else
            {
                Report.Fail("ZipCode was not updated in the Address Page", "AddressChangefails", "true", appHandle, true);
            }

        }
        public virtual void UpdateHomeAddresswithInvaildInAddressPage(string Customer, string Zipcode, string MSG)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(Customer, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            WebCSRPageFactory.CustomerInformationAddressChangePage.UpdateHomeAddressZipCode(Zipcode);
            WebCSRPageFactory.CustomerInformationAddressChangePage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationAddressChangePage.ValidateInvaildZipCodeUpdateMSG(MSG))
            {
                Report.Pass("Error Message for Invaild ZipCode is displayed in Address Page.", "AddressChangePage", "true", appHandle);
            }
            else
            {
                Report.Fail("Error Message for Invaild ZipCode is not displayed in Address Page", "AddressChangefails", "true", appHandle, true);
            }

        }
        public virtual void CreatePersonalCustomerByInVaildZipCode(string InvaildZipCode, string MSG)
        {

            WebCSRPageFactory.WebCSRMasterPage.select_create_personal_customer_link();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_personal_information_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_drivers_license_identification_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_email_and_phone_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_mailing_address_same_as_home_address_yes();
            WebCSRPageFactory.CreatePersonalCustomerPage.enterhomeaddressdetailsZipCodeInValid(InvaildZipCode);
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_previous_address_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_online_access_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_security_question_details();
            WebCSRPageFactory.CreatePersonalCustomerPage.enter_telephone_banking_details();
            string sTaxIdValue1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_tax_id_number_field_value();
            WebCSRPageFactory.CreatePersonalCustomerPage.select_continue_button();
            if (WebCSRPageFactory.CustomerInformationAddressChangePage.ValidateInvaildZipCodeUpdateMSG(MSG))
            {
                Report.Pass("Error Message for Invaild ZipCode is displayed in Create Personal Customer Page.", "CreatePersonalCustomerPage", "true", appHandle);
            }
            else
            {
                Report.Fail("Error Message for Invaild ZipCode is not displayed in Create Personal Customer Page", "CreatePersonalCustomerPagefails", "true", appHandle, true);
            }

        }
        public virtual string CreateCorporateCustomerByZipCode(string city, string state, string zipCode)
        {
            string CustNo = "";
            string[] arrOnlineAccessSecurityDetails = null;
            string sSearchvalue = "";
            string sSearchType = "";
            WebCSRPageFactory.WebCSRMasterPage.SelectCorporateCustomerLink();
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterCorporateInformation();
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterEmailAndPhoneDetails();
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddressByVaildZipCode(city, state, zipCode);
            WebCSRPageFactory.CreateCorporateCustomerPage.SelectAddressSameAsPrincipalAddressRadioButton("yes");
            string sRandomValue = RandomNumberGenerator.Generate();
            sRandomValue = sRandomValue.Substring(0, sRandomValue.Length - 1);
            string sUserID = StartupConfiguration.EnvironmentDetails.UserFirstName;
            sUserID = appHandle.SplitSideString(sUserID.ToUpper(), "LEFT", 4) + sRandomValue;
            string sAllowOnlineAccess = Data.Get("GLOBAL_PERSONAL_CUSTOMER_ALLOW_ONLINE_ACCESS");
            if (sAllowOnlineAccess.ToUpper().Equals("YES"))
            {
                WebCSRPageFactory.CreateCorporateCustomerPage.SelectAllowOnlineAccessRadioButton("yes");

                // To enter Online Access Details
                WebCSRPageFactory.CreateCorporateCustomerPage.EnterOnlineAccessDetails();

                // To get the Temporary Password Action dropdown value 
                string sTemporaryPasswordAction = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_tmporary_password_action_field_value();
                // Get the Value in the User ID Field
                string sWebClientUserID1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_user_id_field_value();

                if (sTemporaryPasswordAction.Equals(Data.Get("GLOBAL_TEMPORARY_PASSWORD_ACTION_RESET")))
                {
                    string sOnlineAccessSecurityDetails = Data.Get("GLOBAL_ONLINESECURITY_DETAILS");
                    arrOnlineAccessSecurityDetails = sOnlineAccessSecurityDetails.Split('_');
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_online_access_security_details(arrOnlineAccessSecurityDetails);
                }
            }
            else
            {
                WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_allow_online_access_no();
            }

            // Enter Security Question details.
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterSecretQuestionDetails();

            // Enter Telephone Banking details.
            WebCSRPageFactory.CreateCorporateCustomerPage.SelectCreateATelePhonebankingPINRadioButton("Yes");
            string sTaxIdValue1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_tax_id_number_field_value();
            WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CreateCorporateCustomerPage.VerifyCorporateCustomerCreationSuccess())
            {
                Report.Info("Corporate Customer application is created successfully", "CorporateCustCreate", "true", appHandle);

                sSearchvalue = sTaxIdValue1;
                sSearchType = Data.Get("GLOBAL_SEARCHTYPE_TAXID");
                CustNo = WebCSRPageFactory.CustomerSearchPage.get_customer_number(sSearchType, sSearchvalue);
                if (!string.IsNullOrEmpty(CustNo))
                {
                    Report.Info("Corporate customer number is captured as: " + CustNo, "custcorp", "true", appHandle);
                }
            }
            else
            {
                Report.Fail("Corporate Customer application is not created due to :" + WebCSRPageFactory.CreateCorporateCustomerPage.GetMessageText(), "CreatecorpcustFail", "true", appHandle, true);
            }

            return CustNo;
        }
        public virtual void NavigatetoInterestBalancePage()
        {
            WebCSRPageFactory.LoanInterestTab.SelectInterestTab();
        }
        public virtual void NavigatetoTransactionProcessingPage()
        {
            WebCSRPageFactory.AccountInformationPage.select_transaction_processing_tab();
            // WebCSRPageFactory.LoanInterestTab.select_calculation_options_link();
        }

        public virtual void EnterCustomerInformationResidencyPageDetails(string CustomerNumber, string ResidencyStatus = " ", string CountryofResidency = "", string CountryofCitizenship = " ", bool W9RequiredONorOFF = false, string W9DateReceived = "", bool SubjtoWitholdingONorOFF = false, string WithholdingReason = "", string CalculationMethod = "")
        {
            string temptitle = appHandle.GetTitle();
            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), CustomerNumber);
            }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), CustomerNumber);
            }

            WebCSRPageFactory.CustomerSearchPage.NavigateToCustomerInformationPage();
            Report.Info("Account Customer Information page is displayed.", "custinfoacctcreate", "true", appHandle);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"));
            if (WebCSRPageFactory.CustomerInformationResidencyPage.WaitUntilCustomerInformationResidencyPageLoad())
            {
                WebCSRPageFactory.CustomerInformationResidencyPage.EnterResidencyInformationDetails(ResidencyStatus, CountryofResidency, CountryofCitizenship, W9RequiredONorOFF, W9DateReceived);
                WebCSRPageFactory.CustomerInformationResidencyPage.EnterInterestWithholdingDetails(SubjtoWitholdingONorOFF, WithholdingReason, CalculationMethod);
                WebCSRPageFactory.CustomerInformationResidencyPage.SelectSubmitButton();
                if (WebCSRPageFactory.CustomerInformationResidencyPage.VerifyMessageAccountInformationResidencyPage(Data.Get("The customer information has been updated.")))
                {
                    Report.Pass("Residency Page Information updated successfully.", "ResidencyPageUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Residency Page Information is not updated successfully.", "ResidencyPageNotUpdated", "True", appHandle, true);
                }

            }
        }
        public virtual void EnterRetirementServicesPlanDistributionPageDetails(string RetirementPlan, bool WitholdingIndicatorONorOFF, string FederalWithholdingPer = "", string StateWithholdingPer = "", string FedWitholdingCalcMethod = "", string FedWitholdingSchedule = "", string FedWitholdingFixedAmt = "", string StatWitholdingCalcMethod = "", string StatWitholdingSchedule = "", string StatWitholdingFixedAmt = "")
        {
            this.ClickLinkFromMenuItem(Data.Get("Retirement Services") + "|" + Data.Get("Plan Information"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Plan Distributions"));
            WebCSRPageFactory.RetairementServicesPage.SelectRetirementPlanDropdown(RetirementPlan);
            WebCSRPageFactory.RetairementServicesPage.EnterWitholdingOptionsDetails(WitholdingIndicatorONorOFF, FederalWithholdingPer, StateWithholdingPer, FedWitholdingCalcMethod, FedWitholdingSchedule, FedWitholdingFixedAmt, StatWitholdingCalcMethod, StatWitholdingSchedule, StatWitholdingFixedAmt);
            WebCSRPageFactory.RetairementServicesPage.SelectSubmitButton();
            if (WebCSRPageFactory.RetairementServicesPage.VerifyMessageAccountInformationResidencyPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Retirement Service plan has been updated ", "RetirementServiceplanStatusPass", "true", appHandle);
            }
            else
            {
                Report.Fail("The Retirement Service plan has not been updated", "RetirementServicePlanStatusFail", "true", appHandle, true);
            }
        }

        public virtual void VerifyWitholdingField(string AccountNumber, string sLabelNameLabelValuePipeDelimited)
        {
            string msg = "";
            string failmsg = "";
            string temp = "";
            string[] arr = null;
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is found as " + arr[b].Split('|')[1] + " successfully in Interest Withholding .";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is found as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " successfully in Interest Withholding.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            }
            if (WebCSRPageFactory.DepositInterestAccrualPage.VerifyTableDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(msg, "WithholdingDetailValidation", "True", appHandle);
            }
            else
            {
                Report.Fail(msg, "WithholdingDetailValidation", "True", appHandle, true);
            }

        }
        public virtual string CalculateSimpleInterest(string principalAmount, string intRate, int Roundoff = 2)
        {
            double Interest = 0;
            string AccrInterest = "";
            Interest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate);
            Interest = Interest / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
            Interest = Math.Round(Interest, Roundoff);
            AccrInterest = Interest.ToString();
            return AccrInterest;
        }
        public virtual void UpdateAccountRelationship(string AccountNumber, string Relationship, string Taxid)
        {

            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Relationships"));
            WebCSRPageFactory.AccontServicesRelationshipsPage.SelectAccountFromAccountsDropdown(AccountNumber);
            WebCSRPageFactory.AccontServicesRelationshipsPage.EditAccountRelationship(Relationship, Taxid);
            WebCSRPageFactory.AccontServicesRelationshipsPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.AccontServicesRelationshipsPage.VerifyMessageAccontServicesRelationshipsPage(Data.Get("The account relationship has been updated.")))
            {
                Report.Pass("Account Relationship page updated Successfully.", "AccountRelationStatusPass", "true", appHandle);
            }
            else
            {
                Report.Fail("Account Relationship page is not updated.", "AccountRelationStatusFail", "true", appHandle, true);
            }

        }
        public virtual void UpdateUSRegulatorySplitReporting(string AccountNumber, bool RegulationCCOnorOff = true, string Reporting1099Exemption = "")
        {

            this.LoadAccountSummaryPage(AccountNumber);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));
            WebCSRPageFactory.USRegulatoryPage.VerifyUSRegulatoryPageLoads();
            WebCSRPageFactory.USRegulatoryPage.EnterUSRegulatoryPageOption(RegulationCCOnorOff, Reporting1099Exemption);
            WebCSRPageFactory.USRegulatoryPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.USRegulatoryPage.VerifyMessageInUSRegulatoryPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Regulation CC Option in US Regulatory page under Account information is successfully updated.", "REGCCUpdate", "true", appHandle);
            }
            else
            {
                Report.Fail("Regulation CC Option in US Regulatory page under Account information is not successfully updated.", "REGCCUpdatefail", "true", appHandle, true);
            }

        }
        public virtual void VerifyDataInUSRegulatorySplitReportingTable(string AccountNumber, string refColumnValuesSemicolonDelimited)
        {

            if (!appHandle.GetTitle().Contains(Data.Get("Split Reporting")))
            {
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Split Reporting"));

            }
            else
            {
                if (WebCSRPageFactory.USRegulatoryPage.VerifyAccountExistsInAccountDropdown(AccountNumber)) { }
                else
                {
                    LoadAccountSummaryPage(AccountNumber);
                    Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"), Data.Get("Split Reporting"));
                }
            }

            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (refColumnValuesSemicolonDelimited.Contains("|"))
            {
                arr = refColumnValuesSemicolonDelimited.Split('|');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split(';')) + " is captured successfully in Split Reporting table in WebCSR.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", refColumnValuesSemicolonDelimited.Split(';')) + " is captured successfully in Split Reporting table in WebCSR.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebCSRPageFactory.USRegulatoryPage.VerifyDataInSplitReporting(AccountNumber, refColumnValuesSemicolonDelimited))
            {
                Report.Pass(msg, "SplitRepotingTableValueChecked", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "SplitRepotingTableValueNotChecked", "True", appHandle, true);
            }
        }
        public virtual string InterestAndWithholdingCalculation(string WitholdingCalcMethod, string Amount, double intRate, int numberOfDaysPassed, string Date = "", int Roundoff = 2, string Account = "", bool IPTY = false)
        {
            string grossincomepaid = "";
            string WithholdingInterest = "";
            int numberOfDaysInYear = 0;
            double InterestPosted = 0;
            double FirstWithholdingAmount = 0;
            double total = 0;
            if (string.IsNullOrEmpty(Date))
            {
                Date = GetApplicationDate();
            }
            string yearparam = appHandle.GetDateParameters(Date)[2].Trim();
            if (appHandle.IsLeapYear(Int32.Parse(yearparam)))
            {
                numberOfDaysInYear = 366;
            }
            else
            {
                numberOfDaysInYear = 365;
            }
            // if(!string.IsNullOrEmpty(WitholdingCalcMethod))
            // {
            //     string stateperc = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT UTBLRSPWSCH.PCT,UTBLRSPWSCH.KEY FROM UTBLWCALC JOIN UTBLRSPWSCH ON UTBLWCALC.WSCH=UTBLRSPWSCH.WSCH WHERE UTBLWCALC.KEY='"+WitholdingCalcMethod+"'","UTBLRSPWSCH.PCT");
            //     appHandle.Wait_For_Specified_Time(4);
            //     string federalperc = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT UTBLWCALC.WPCT,UTBLWCALC.WSCH,UTBLRSPWSCH.KEY,UTBLRSPWSCH.PCT FROM UTBLWCALC JOIN UTBLRSPWSCH ON UTBLWCALC.WSCH=UTBLRSPWSCH.WSCH WHERE UTBLWCALC.KEY='"+WitholdingCalcMethod+"'","UTBLWCALC.WPCT");
            //     total = Convert.ToDouble(federalperc) + Convert.ToDouble(stateperc) ;
            // }
            switch (WitholdingCalcMethod)
            {
                case "US":
                    string stateperc = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT UTBLRSPWSCH.PCT,UTBLRSPWSCH.KEY FROM UTBLWCALC JOIN UTBLRSPWSCH ON UTBLWCALC.WSCH=UTBLRSPWSCH.WSCH WHERE UTBLWCALC.KEY='" + WitholdingCalcMethod + "'", "UTBLRSPWSCH.PCT");
                    appHandle.Wait_For_Specified_Time(4);
                    string federalperc = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT UTBLWCALC.WPCT,UTBLWCALC.WSCH,UTBLRSPWSCH.KEY,UTBLRSPWSCH.PCT FROM UTBLWCALC JOIN UTBLRSPWSCH ON UTBLWCALC.WSCH=UTBLRSPWSCH.WSCH WHERE UTBLWCALC.KEY='" + WitholdingCalcMethod + "'", "UTBLWCALC.WPCT");
                    total = Convert.ToDouble(federalperc) + Convert.ToDouble(stateperc);

                    InterestPosted = Convert.ToDouble(Amount) * Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                    InterestPosted = InterestPosted / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                    InterestPosted = InterestPosted / (Convert.ToDouble(numberOfDaysInYear));
                    FirstWithholdingAmount = InterestPosted * total;
                    FirstWithholdingAmount = FirstWithholdingAmount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                    FirstWithholdingAmount = Math.Round(FirstWithholdingAmount, Roundoff);
                    break;

                case "IN":
                    if (IPTY)
                    {
                        grossincomepaid = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT IPTY FROM DEP WHERE CID = '" + Account + "'", "IPTY");
                    }
                    else
                    {
                        grossincomepaid = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT ITYTD FROM DEP WHERE CID = '" + Account + "'", "ITYTD");
                    }
                    FirstWithholdingAmount = (Convert.ToDouble(intRate) / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100"))));
                    FirstWithholdingAmount = Convert.ToDouble(grossincomepaid) * FirstWithholdingAmount;
                    FirstWithholdingAmount = Math.Round(FirstWithholdingAmount, Roundoff);
                    break;

                case "FR":
                    grossincomepaid = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT ITYTD FROM DEP WHERE CID = '" + Account + "'", "ITYTD");
                    FirstWithholdingAmount = Convert.ToDouble(grossincomepaid) * intRate;
                    FirstWithholdingAmount = FirstWithholdingAmount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));

                    string WAMT = Profile7CommonLibrary.ExtractDataFromDataBase("select Key,WAMT,WPCT from UTBLWCALC where key = 'FR'", "WAMT");
                    if (WAMT != "null")
                    {
                        FirstWithholdingAmount = FirstWithholdingAmount + Convert.ToDouble(WAMT);
                    }
                    FirstWithholdingAmount = Math.Round(FirstWithholdingAmount, Roundoff);
                    break;

                default:

                    FirstWithholdingAmount = (Convert.ToDouble(intRate) / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100"))));
                    FirstWithholdingAmount = Convert.ToDouble(Amount) * FirstWithholdingAmount;
                    FirstWithholdingAmount = Math.Round(FirstWithholdingAmount, Roundoff);
                    break;

            }
            WithholdingInterest = FirstWithholdingAmount.ToString();
            return WithholdingInterest;
        }
        public virtual void UpdateWithholdingPageOptions(string AccountNumber, bool SubjToWithholdingONorOFF, bool AccrWitholdingONorOFF, string CalculationMethod = "", string WitholdingReason = "", string USResidencystatus = "", string Chapter3ExemptionReason = "", string Chapter3Status = "")
        {
            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            }
            WebCSRPageFactory.DepositWithholdingPage.CheckSubjToWithholding(SubjToWithholdingONorOFF);
            WebCSRPageFactory.DepositWithholdingPage.EnterInterestPageOptions(CalculationMethod, WitholdingReason, USResidencystatus, Chapter3ExemptionReason, Chapter3Status);
            WebCSRPageFactory.DepositWithholdingPage.CheckAccruedWitholdingTax(AccrWitholdingONorOFF);
            WebCSRPageFactory.DepositWithholdingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositWithholdingPage.VerifyMessageDepositWitholdingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Subject To Withholding Chekbox and Calculation methods are Selected", "SubjToWithholdingSelected", "True", appHandle);
            }
            else
            {
                Report.Fail("Subject To Withholding Checkbox and Calculation Methods are not Selected", "SubjToWithholdingNotSelected", "True", appHandle, true);
            }

        }

        public virtual void CheckSubjectToWithholding(string AccountNumber, bool SubjToWithholdingONorOFF, string CalculationMethod = "")
        {
            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            }
            WebCSRPageFactory.DepositWithholdingPage.EnterInterestPageOptions(CalculationMethod);
            WebCSRPageFactory.DepositWithholdingPage.CheckSubjToWithholding(SubjToWithholdingONorOFF);
            WebCSRPageFactory.DepositWithholdingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositWithholdingPage.VerifyMessageDepositWitholdingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Subject To Withholding Chekbox and Calculation methods are Selected", "SubjToWithholdingSelected", "True", appHandle);
            }
            else
            {
                Report.Fail("Subject To Withholding Checkbox and Calculation Methods are not Selected", "SubjToWithholdingNotSelected", "True", appHandle, true);
            }

        }
        public virtual void VerifyPaymentPageFieldValue(string AccountNumber, string sLabelNameLabelValuePipeDelimited)
        {
            string msg = "";
            string failmsg = "";
            string temp = "";
            string[] arr = null;
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is found as " + arr[b].Split('|')[1] + " successfully in Interest Accrual Page.";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is found as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " successfully in Interest Accrual Page.";
                failmsg = msg.Replace(" is ", " is not ");
            }
            if (!appHandle.GetTitle().Contains("Payment"))
            {
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Payment"));
            }
            if (WebCSRPageFactory.DepositPaymentPage.VerifyTableDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(msg, "paymentPageValidation", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "PaymentPageNotValidation", "True", appHandle, true);
            }
        }
        public virtual void UpdateCustomerInformationGeneralPageDetails(string CustomerNumber, string taxid)
        {
            string temptitle = appHandle.GetTitle();
            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), CustomerNumber);
            }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), CustomerNumber);
            }

            WebCSRPageFactory.CustomerSearchPage.NavigateToCustomerInformationPage();
            Report.Info("Account Customer Information page is displayed.", "custinfoacctcreate", "true", appHandle);
            if (WebCSRPageFactory.CustomerInformationPage.WaitUntilCustomerInformationPageLoad())
            {
                WebCSRPageFactory.CustomerInformationPage.EnterCustomerInformationDetails(taxid);
                WebCSRPageFactory.CustomerInformationPage.ClickOnSubmitButton();
                if (WebCSRPageFactory.CustomerInformationPage.VerifyMessageCustomerInformationPage(Data.Get("The customer information has been updated.")))
                {
                    Report.Pass("General Page Information updated successfully.", "GeneralPageUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("General Page Information is not updated successfully.", "GeneralPageNotUpdated", "True", appHandle, true);
                }

            }
        }
        public virtual string GetCustomerTaxIDByCustomerNumber(string customerId)
        {
            string taxid = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT TAXID FROM CIF WHERE ACN = '" + customerId + "'", "TAXID");
            appHandle.Wait_For_Specified_Time(4);
            return taxid;

        }
        public virtual string GetCustomerNameByCustomerNumber(string customerId)
        {
            string name = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT NAM FROM CIF WHERE ACN='" + customerId + "'", "NAM");
            appHandle.Wait_For_Specified_Time(4);
            return name;

        }
        public virtual string GetCustomerLastNameByCustomerNumber(string customerId)
        {
            string name = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT LNM FROM CIF WHERE ACN='" + customerId + "'", "LNM");
            appHandle.Wait_For_Specified_Time(4);
            return name;

        }

        public virtual void EnterExceptionProcessingSearchPageDetails(string TransactionSource, string Transactiondate, string Branch, string Status, string CustomerName, string AccountNumber, string value, string ExceptionProcessing)
        {
            this.ClickLinkFromMenuItem(Data.Get("Utilities") + "|" + Data.Get("Exception Processing"));
            WebCSRPageFactory.UtilityExceptionProcessingPage.EnterExceptionProcessingSearchPageDetails(TransactionSource, Transactiondate, Branch, Status, CustomerName);
            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectSubmitButton();
            if (WebCSRPageFactory.UtilityExceptionProcessingPage.VerifyExceptionProcessingStatusBeforeProcessing(CustomerName))
            {
                Report.Info("The exception processing status is captured as Incomplete : 1 .", "incompletestatbefore", "True", appHandle);
            }
            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectReviewButton();
            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectExceptionCheckbox(true);
            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectDecisiondropdown(AccountNumber, value);
            WebCSRPageFactory.UtilityExceptionProcessingPage.ClickOnContinueButton();
            if (WebCSRPageFactory.UtilityExceptionProcessingPage.ExceptionProcessingConfirmation(ExceptionProcessing))
            {
                Report.Info("Reason code has been selected as " + ExceptionProcessing, "exceptionreasoncode", "True", appHandle);
            }

            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectSubmitButton();

            if (WebCSRPageFactory.UtilityExceptionProcessingPage.VerifyExceptionProcessingStatusAfterProcessing(CustomerName))
            {

                Report.Pass("The exception processing status is captured as Incomplete : 0 .Exception  details are processed successfully.", "ExceptionProcessingStatusPass", "true", appHandle);
            }
            else
            {
                Report.Fail("Exception details are not processed successfully", "ExceptionProcessingStatusFail", "true", appHandle, true);
            }

        }
        public virtual void UpdateStatementGroupPage(string StatementGroupNum, string Frequency, string NextDate)
        {

            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Statement Groups"));
            WebCSRPageFactory.StatementGroupPage.SelectStatementGroup(StatementGroupNum);
            WebCSRPageFactory.StatementGroupPage.ClickOnStatementGroupEditButton();
            WebCSRPageFactory.StatementGroupPage.EditStatementGroup(Frequency, NextDate);
            WebCSRPageFactory.StatementGroupPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage(Data.Get("GLOBAL_CONTEXT_STMTGRP_UPDATED_MSG")))
                Report.Pass("Successfully updated the statement group information", "UpdateStatementGroupInformation", "True", appHandle);
            else
                Report.Fail("Failed to update the statement group information", "UpdateStatementGroupInformation", "True", appHandle);
        }
        public virtual void UpdateMailingAddressInAddressPage(string Customer)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(Customer, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            WebCSRPageFactory.CustomerInformationAddressChangePage.UpdateMailingAddressInAddress();
            WebCSRPageFactory.CustomerInformationAddressChangePage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationAddressChangePage.ValidateAddressInfoUpdateMSG())
            {
                Report.Pass("Mailing Address is updated Successfully in Address Page", "AddressChange", "true", appHandle);
            }
            else
            {
                Report.Fail("Mailing Address was not Update in Address Page", "ChangeAddressfails", "true", appHandle, true);
            }

        }
        public virtual void UpdatePreviousAddresswithInvaildZipCodeInAddressPage(string Customer, string ZipCode, string MSG)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(Customer, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            WebCSRPageFactory.CustomerInformationAddressChangePage.UpdatePreviousAddressInAddressPage(ZipCode);
            WebCSRPageFactory.CustomerInformationAddressChangePage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationAddressChangePage.ValidateInvaildZipCodeUpdateMSG(MSG))
            {
                Report.Pass("Error Message for Invaild ZipCode is displayed in Address Page.", "AddressChangePage", "true", appHandle);
            }
            else
            {
                Report.Fail("Error Message for Invaild ZipCode is not displayed in Address Page", "AddressChangefails", "true", appHandle, true);
            }

        }
        public virtual void UpdatePreviousAddresswithVaildZipCodeInAddressPage(string Customer, string ZipCode)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(Customer, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            WebCSRPageFactory.CustomerInformationAddressChangePage.UpdatePreviousAddressInAddressPage(ZipCode);
            WebCSRPageFactory.CustomerInformationAddressChangePage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationAddressChangePage.ValidateAddressInfoUpdateMSG())
            {
                Report.Pass("Previous Address is updated Successfully in Address Page", "AddressChange", "true", appHandle);
            }
            else
            {
                Report.Fail("Previous Address was not Update in Address Page", "ChangeAddressfails", "true", appHandle, true);
            }

        }
        public virtual void UpdateSeasonalAddresswithVaildZipCodeInSeasonalAddressPage(string Customer, string StartDate, string EndDate, string ZipCode)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(Customer, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Seasonal Address"));
            WebCSRPageFactory.CustomerInformationSeasonalAddressPage.UpdateSeasonalAddressInSeasonalAddressPage(StartDate, EndDate, ZipCode);
            WebCSRPageFactory.CustomerInformationSeasonalAddressPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationSeasonalAddressPage.ValidateAddressInfoUpdateMSG())
            {
                Report.Pass("Seasonal Address is updated Successfully in Address Page", "SeasonalAddress", "true", appHandle);
            }
            else
            {
                Report.Fail("Seasonal Address was not Update in Address Page", "SeasonalAddressfails", "true", appHandle, true);
            }

        }
        public virtual void UpdateSeasonalAddresswithInvaildZipCodeInSeasonalAddressPage(string Customer, string StartDate, string EndDate, string ZipCode, string MSG)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(Customer, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Seasonal Address"));
            WebCSRPageFactory.CustomerInformationSeasonalAddressPage.UpdateSeasonalAddressInSeasonalAddressPage(StartDate, EndDate, ZipCode);
            WebCSRPageFactory.CustomerInformationSeasonalAddressPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationAddressChangePage.ValidateInvaildZipCodeUpdateMSG(MSG))
            {
                Report.Pass("Error Message for Invaild ZipCode is displayed in Seasonal Address Page.", "AddressChangePage", "true", appHandle);
            }
            else
            {
                Report.Fail("Error Message for Invaild ZipCode is not displayed in Seasonal Address Page", "AddressChangefails", "true", appHandle, true);
            }

        }
        public virtual void AddBeneficiariesForAccountWithInvaildZipCode(string Customer, string AccountNumber, int NumberOfBeneficiaries, string BeneficiaryClassificationType, string ZipCode, string MSG)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(Customer, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_ACCOUNTLIST"));
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Beneficiaries"));
            WebCSRPageFactory.BeneficiariesPage.selectAccountFromDropdown(AccountNumber);
            WebCSRPageFactory.AddBeneficiaryPage.EnterBeneficiaryDetailswithInvaildZipCode(NumberOfBeneficiaries, BeneficiaryClassificationType, ZipCode);
            if (WebCSRPageFactory.AddBeneficiaryPage.VerifyMSGInBeneficiaryPage(MSG))
            {
                Report.Pass("Error Message for Invaild ZipCode is displayed in Beneficiaries Page.", "beneficiaryadd", "true", appHandle);
            }
            else
            {
                Report.Fail("Error Message for Invaild ZipCode is not displayed in Beneficiaries Page.", "beneficiaryadd", "true", appHandle, true);

            }

        }
        public virtual void AddBeneficiariesForAccountWithvaildZipCode(string Customer, string AccountNumber, int NumberOfBeneficiaries, string BeneficiaryClassificationType, string ZipCode, string MSG)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(Customer, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_ACCOUNTLIST"));
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Beneficiaries"));
            WebCSRPageFactory.BeneficiariesPage.selectAccountFromDropdown(AccountNumber);
            WebCSRPageFactory.AddBeneficiaryPage.EnterBeneficiaryDetailswithInvaildZipCode(NumberOfBeneficiaries, BeneficiaryClassificationType, ZipCode);
            if (WebCSRPageFactory.AddBeneficiaryPage.VerifyMSGInBeneficiaryPage(MSG))
            {
                Report.Pass(" Beneficiary is added successfully in theBeneficiaries Page.", "beneficiaryadd", "true", appHandle);
            }
            else
            {
                Report.Fail("Beneficiary is not added successfully in the Beneficiaries Page.", "beneficiaryadd", "true", appHandle, true);

            }

        }
        public virtual void UpdateDetailsInSCRAPage(string AccountNumber, bool CheckBoXOnorOff, string InterestRate, string StartDate, string EndDate, string ExpirationDate, bool bOverride)
        {
            LoadAccountSummaryPage(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("Loan Account Services") + "|" + Data.Get("Servicemember Protections"));
            WebCSRPageFactory.LoanServicememberProtectionsPage.SelectAccountFromDropdown(AccountNumber);
            WebCSRPageFactory.LoanServicememberProtectionsPage.ClickOnSCRAProtectedCheckBox(CheckBoXOnorOff);
            WebCSRPageFactory.LoanServicememberProtectionsPage.UpdateSCRAInterestRate(InterestRate);
            WebCSRPageFactory.LoanServicememberProtectionsPage.UpdateDutyDates(StartDate, EndDate, ExpirationDate);
            WebCSRPageFactory.LoanServicememberProtectionsPage.ClickOnContinue();
            this.HandleAuthorizationPopupWindow(bOverride);
            WebCSRPageFactory.LoanServicememberProtectionsPage.ClickOnContinue();
            if (WebCSRPageFactory.LoanServicememberProtectionsPage.VerifyMSGInServicememberProtectionsPage())
            {
                Report.Pass("The SCRA Page Details was updated successfully", "ServicememberProtectionsPage", "true", appHandle);

            }
            else
            {
                Report.Fail("The SCRA page details was not updated", "ServicememberProtectionsPagefail", "true", appHandle, true);
            }


        }
        public virtual void VerifySCRAProtectedDetails(string Account, string LabelNamePipeDelimitedExpectedvalue)
        {
            LoadAccountSummaryPage(Account);
            this.ClickLinkFromMenuItem(Data.Get("Loan Account Services") + "|" + Data.Get("Servicemember Protections"));
            WebCSRPageFactory.LoanServicememberProtectionsPage.SelectAccountFromDropdown(Account);
            if (WebCSRPageFactory.LoanServicememberProtectionsPage.VerifyFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in SCRA Page.", "ServicemembersCivilReliefActPage", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in  SCRA Page.", "ServicemembersCivilReliefActPagefail", "True", appHandle, true);
            }

        }
        public virtual void UpdateOverdratOptionInTransactionProcessing(String AccountNumber, string OverdraftOption)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"), Data.Get("Overdraft Processing"));
            WebCSRPageFactory.TransactionProcessingPage.SelectOverdraftOption(OverdraftOption);
            WebCSRPageFactory.TransactionProcessingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.TransactionProcessingPage.VerifySuccessfulUpdateMessageInTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass(Data.Get("GLOBAL_INFORMATION_UPDATED") + " is successdully displayed in Transaction Processing page.", "overdraftoptionspass", "True", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("GLOBAL_INFORMATION_UPDATED") + " is not displayed in Transaction Processing page.", "overdraftoptionfail", "True", appHandle, true);
            }
        }
        public virtual void CheckAccountBalancesAccountInformation(string AccountNumber, string sLabelNameLabelValuePipeDelimited)
        {
            this.LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("General"));
            if (WebCSRPageFactory.AccountInformationPage.AccountBalancesAccountInformation(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is captured as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " .", "avblbalcheck", "True", appHandle);
            }
            else
            {
                Report.Fail(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is not captured as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " .", "avblbalcheck", "True", appHandle, true);
            }
        }
        public virtual void AddDebitAuthorization(string InstitutionName, string AccountNumber, string AccountToDebit)
        {
            LoadAccountSummaryPage(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("Funding Services") + "|" + Data.Get("Debit Authorization"));
            WebCSRPageFactory.DebitAuthorizationPage.ClickOnAddButton();
            WebCSRPageFactory.DebitAuthorizationPage.AddDebitAuthorization(InstitutionName, AccountNumber, AccountToDebit);
            WebCSRPageFactory.DebitAuthorizationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DebitAuthorizationPage.VerifyAddDebitSuccessMSG())
            {
                Report.Pass("DebitAuthorization was Added successfully", "DebitAuthorizationPage", "true", appHandle);
            }
            else
            {
                Report.Fail("Debit Autorization was not added successfully", "DebitAuthorizationPagefails", "true", appHandle, true);

            }


        }
        public virtual string AddDomesticPaymentsCustomerStandingPaymentOrder(string AccountNumber, string PaymentType, string InstitutionRountingNumberOrName, string RecipientAccountNumber, string AccountType, string RicipientName, string Amount, string Msg, string EffectiveDate = "", string Frequency = "", string EndDate = "")
        {
            string RoutingNumber = "";
            string InstitutionName = "";
            string temp = "";
            if (InstitutionRountingNumberOrName.Contains("-"))
            {
                RoutingNumber = InstitutionRountingNumberOrName.Split('-')[0].Trim();
                InstitutionName = InstitutionRountingNumberOrName.Split('-')[1].Trim();
            }
            else
            {
                RoutingNumber = InstitutionRountingNumberOrName;
                InstitutionName = InstitutionRountingNumberOrName;
            }
            GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("Payment Services") + "|" + Data.Get("Domestic Payments - Customer"));
            WebCSRPageFactory.DomesticPaymentPage.VerifyDomesticPaymentsCustomerPageLoads();
            WebCSRPageFactory.DomesticPaymentPage.selectAccountFromDropDown(AccountNumber);
            Report.Info(AccountNumber + " is selected in domestic payments customer page.", "selectacct", "true", appHandle);
            WebCSRPageFactory.DomesticPaymentPage.clickonAddButton();
            WebCSRPageFactory.DomesticPaymentAddPage.SelectPaymentTypeFromDropDown(PaymentType);
            WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.ClickOnSearchInstitutionButton();
            if (RoutingNumber.All(char.IsDigit))
            {
                temp = WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.SearchInstitutionByRoutingNumber(RoutingNumber);
            }
            else
            {
                temp = WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.SearchInstitutionByInstitutionName(InstitutionName);
            }
            WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.EnterSPODetails(RecipientAccountNumber, AccountType, RicipientName, Amount, EffectiveDate, Frequency, EndDate);
            Report.Info("SPO - Payment order details are entered.", "spoorderdetail", "True", appHandle);
            WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Msg))

            {
                Report.Pass(Msg + ". message is displayed ", "SPOORDERPLACED", "true", appHandle);
            }
            else
            {
                Report.Fail(Msg + ".message is not displayed and Order details are not added in List of Orders.", "SPOORDERPLACEDFail", "true", appHandle, true);
            }
            return temp;
        }
        public virtual void VerifyDomesticPaymentsOrderNotGenerated(string AccountNumber, string UniqueOrderRefValue)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("Account Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_ACCOUNTLIST"));
            this.ClickLinkFromMenuItem(Data.Get("Payment Services") + "|" + Data.Get("Domestic Payments - Customer"));
            WebCSRPageFactory.DomesticPaymentPage.VerifyDomesticPaymentsCustomerPageLoads();
            WebCSRPageFactory.DomesticPaymentPage.selectAccountFromDropDown(AccountNumber);
            Report.Info(AccountNumber + " is selected in domestic payments customer page.", "selectacct", "true", appHandle);
            WebCSRPageFactory.DomesticPaymentPage.VerifyPaymentOrderIsNotGenerated(UniqueOrderRefValue);
            Report.Pass("Payment order is Verified as not generated", "VerifyDomesticPaymentsCustomerPaymentOrder", "true", appHandle);

        }

        public virtual string GetCustomerTaxidFromCustomerInformation(string CustomerNo)
        {
            if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"))
             && Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("TableCIF") + "#: " + CustomerNo)) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNo, Data.Get("Customer Number"));
                this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            }
            string Taxid = WebCSRPageFactory.CustomerInformationPage.GetTaxid();
            return Taxid;

        }
        public virtual string GetCustomerNameFromNameTab(string CustomerNo)
        {
            if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"))
            && Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("TableCIF") + "#: " + CustomerNo)) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNo, Data.Get("Customer Number"));
                this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Name"));
            string Name = WebCSRPageFactory.CustomerInformationPage.GetNameOfCustomer();
            return Name;

        }

        public virtual void UpdateDetailsInFATCAPage(string CustomerNo, string Status, string ReportOption, bool CheckBoXOnorOff)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNo, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("FATCA"));
            WebCSRPageFactory.CustomerInformationResidencyPage.UpdateReportingStatus(Status);
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnSubjectToWithholdingCheckBox(CheckBoXOnorOff);
            WebCSRPageFactory.CustomerInformationResidencyPage.WaiverForReporting(ReportOption);
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationResidencyPage.ValidateCustomerInfoUpdateMSG())
            {
                Report.Pass("The FATCA details was updated in FATCA Page", "FATCAPage", "true", appHandle);
            }
            else
            {
                Report.Fail("The FATCA details was not update in FATCA Page", "FATCAPagefails", "true", appHandle, true);

            }

        }
        public virtual void CheckObjectEnabledInCustomerInformation()
        {
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            bool actval = WebCSRPageFactory.CustomerInformationPage.VerifyObjectEnabled();
            if (actval)
            {
                Report.Pass("The BranchOwnership,Cost Center and Homephone are enabled in Customer information page", "custinfopass", "True", appHandle);
            }
            else
            {
                Report.Fail("The BranchOwnership,Cost Center and Homephone are disabled in Customer information page", "custinfofail", "True", appHandle);

            }


        }

        public virtual void CheckObjectExistInCustomerInformation()
        {
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            bool actval = WebCSRPageFactory.CustomerInformationPage.VerifyObjectExist();
            if (actval)
            {
                Report.Pass("The BranchOwnership,Cost Center are exist and Home phone does not exist in Customer information page", "custinnfopass", "True", appHandle);
            }
            else
            {
                Report.Pass("The BranchOwnership,Cost Center does not exist and Home phone does exist in Customer information page", "custinnfopfail", "True", appHandle);

            }


        }
        public virtual string GetExchangeRateByCurrencyCode(string CurrencyCode)
        {
            string exchangerate = "";
            string latesteffdate = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT MAX(EFD) FROM CRCDRATEH WHERE CRCD='" + CurrencyCode.ToUpper() + "'", "MAX_EFD ");
            latesteffdate = "'" + latesteffdate.Split('-')[1] + "/" + latesteffdate.Split('-')[2] + "/" + latesteffdate.Split('-')[0] + "'";
            string SQLQUERY = "SELECT CRCD,MIDRATE,EFD FROM CRCDRATEH WHERE CRCD='" + CurrencyCode.ToUpper() + "' AND EFD=" + latesteffdate;
            exchangerate = Profile7CommonLibrary.ExtractDataFromDataBase(SQLQUERY, "MIDRATE");
            return exchangerate;
        }
        public virtual void UpdateNegativeBalanceOptionLoanTransactionProcessingPage(string AccountNumber, string ItemToBeSelected)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebCSRPageFactory.LoanTransactionProcessingPage.UpdateNegativeBalanceOption(ItemToBeSelected);
            WebCSRPageFactory.LoanTransactionProcessingPage.SelectSubmitButton();
            if (WebCSRPageFactory.LoanTransactionProcessingPage.VerifyMessageLoanTrasactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Negative balance option is updated successfully.", "negativebalanceupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Negative balance option is not updated successfully.", "negativebalanceupdatefail", "True", appHandle, true);
            }
        }
        public virtual void UpdatePreAuthorizedPaymentAllowedInLoanPaymentPaymentApplicationPage(string AccountNumber, bool ONOFF, string NumberofDaystoProject = "")
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Payment"), Data.Get("Payment Application"));
            WebCSRPageFactory.LoanPaymentPaymentApplicationPage.WaitUntilPaymentsPaymentApplicationPageLoads();
            WebCSRPageFactory.LoanPaymentPaymentApplicationPage.SelectPreAuthorizedTransferAllowed(ONOFF, NumberofDaystoProject);
            WebCSRPageFactory.LoanPaymentPaymentApplicationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.LoanPaymentPaymentApplicationPage.VerifyMessageInLoanPaymentsPaymentApplicationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Pre-authorized Payment Allowed is selected successfully.", "PayapplicationUpdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Pre-authorized Payment Allowed is not selected successfully.", "PayapplicationUpdatefail", "True", appHandle, true);
            }
        }

        ////
        public virtual string CalculatePosNegACR(string DepositedAmount, string GlobalValue2, string GlobalValue365, string EXCHANGERATE, int RoundingOff = 2)
        {
            string GlobalYearValue = "";
            string OutputValue = "";
            string yearparam = appHandle.GetDateParameters(GlobalValue365)[2].Trim();
            if (appHandle.IsLeapYear(Int32.Parse(yearparam)))
            {
                GlobalYearValue = "366";
            }
            else
            {
                GlobalYearValue = "365";
            }
            double Value = (Convert.ToDouble(DepositedAmount) * Convert.ToDouble(EXCHANGERATE) * Convert.ToDouble(GlobalValue2)) / Convert.ToDouble(GlobalYearValue);
            Value = Value / 100;
            Value = Math.Round(Value, RoundingOff);
            OutputValue = Value.ToString();
            if (RoundingOff == 2)
            {
                OutputValue = String.Format("{0:0.00}", Value);
            }
            return OutputValue;
        }

        public virtual void ClickOnAccountHistoryTransactionLink(string ColumnValues)
        {
            WebCSRPageFactory.AccountHistoryPage.ClickOnAccountHistoryTransaction(ColumnValues);
        }
        public virtual string UpdateCorporateCustomerTaxID(string CustomerNo, bool blank = true)
        {
            string staxid = "";
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNo, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.CustomerInformationPage.UpdateTaxIdForCorporateCustomer(blank);
            WebCSRPageFactory.CustomerInformationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.ValidateCustomerInfoUpdateMSG())
            {
                Report.Pass("Taxid was updated successfully in Customer Information Page", "CustomerInformationscreen", "True", appHandle);
            }
            else
            {
                Report.Fail("Taxid was updated successfully in Customer Information Page", "CustomerInformationscreen", "True", appHandle, true);

            }
            return staxid;
        }
        public virtual string AddExternalAccountInWebCSR(string accountnumber, string routingnumber, string accounttype)
        {
            GetAccount(accountnumber);
            WebCSRPageFactory.AccountOverviewPage.ClickOnExternalAccountsLink();
            //WebCSRPageFactory.ExternalAccountsPage.ClickOnAddButton();
            return WebCSRPageFactory.ExternalAccountsPage.AddExternalAccount(routingnumber, accounttype);
        }






        public virtual void VerifyPOSNEGACRAmount(string labeltxt, string CalculatedPOSNEGACR, int Roundoff = 2)
        {
            if (WebCSRPageFactory.AccountHistoryPage.VerifyPOSNEGACRAmount(labeltxt, CalculatedPOSNEGACR, Roundoff))
            {
                Report.Pass("Expected value is available in Transaction Detail", "output", "True", appHandle);
            }
            else
            {
                Report.Fail("Expected value is not available in Transaction Detail", "output", "True", appHandle);
            }
        }

        public virtual void VerifyAccruedInterestInInterestAccrual(string AccountNumber, String sLabelNameLabelValuePipeDelimited)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Accrual"));
            if (WebCSRPageFactory.LoanAccountOverviewPage.VerifyLoanAccountOverviewValuesBylabelNameLabelValue(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is captured as : " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in Authorized Overdraft.", "totAuthODLI", "True", appHandle);
            }
            else
            {
                Report.Fail(sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is not captured as : " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " in  Authorized Overdraft.", "totAuthODLIfail", "True", appHandle, true);
            }
        }
        public virtual void NavigateToAccountSummaryInterestPage(string AccountNumber)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Accrual"));
        }
        public virtual void DepositAccountEnterEFDRateChangeOption(string AccountNumber, string EffectiveDate, string InterestRate)
        {
            this.ClickLinkFromMenuItem(Data.Get("Deposit Account Services") + "|" + Data.Get("EFD Rate Change"));
            if (WebCSRPageFactory.DepositAccountEFDRateChangePage.EnterEFDRateChangeOption(AccountNumber, EffectiveDate, InterestRate))
            {
                Report.Pass("Rate Change updated successfully", "EnterEFDRateChangeOption", "true", appHandle);
            }
            else
            {
                Report.Fail("Rate Change not updated successfully", "EnterEFDRateChangeOption Fail", "true", appHandle, true);
            }
        }
        public virtual void CreateStatementGroupPage(string Frequency, string NextDate, string AccountNumber = "", bool Selected = false, bool AccountSummary = false)
        {
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Statement Groups"));
            WebCSRPageFactory.StatementGroupPage.AddStatementGroup(Frequency, NextDate, AccountNumber, Selected, AccountSummary);
            WebCSRPageFactory.StatementGroupPage.ClickOnSubmit();
            if (WebCSRPageFactory.WebCSRMasterPage.CheckSuccessMessage("The statement group has been created."))
                Report.Pass("Successfully created the statement group information", "CreateStatementGroupInformation", "True", appHandle);
            else
                Report.Fail("Failed to create the statement group information", "CreateStatementGroupInformation", "True", appHandle);
        }
        public virtual void UpdateRateDeterminationCreditThreshold(string AccountNumber, string InterestRate)
        {
            LoadAccountSummaryPage(AccountNumber);
            WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Interest") + "|" + Data.Get("Rate Determination"));
            WebCSRPageFactory.AccountInformationPage.InterestUpdate(InterestRate);
            WebCSRPageFactory.LoanMaturityPayoffPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.LoanMaturityPayoffPage.VerifyMessageInLoanMaturityPayoffPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Credit Threshold Amount is updated in Maturity Payoff page under Account Information | Maturity Payoff .", "CreditThresholdupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Credit Threshold Amount is not updated in Loan Maturity Payoff page under Account Information | Maturity Payoff .", "CreditThresholdupdatefail", "True", appHandle, true);
            }
        }

        public virtual string GetNetPayOffAmount(string AccountNumber)
        {
            Application.WebCSR.GetAccount(AccountNumber);
            string data = WebCSRPageFactory.LoanAccountOverviewPage.GetValueForLabel(Data.Get("Net Payoff Amount"));
            return data;
        }
        public virtual void UpdateTermAccountsMaturityDetails(string AccountNumber, string PrincipalMaturityOption, string ExternalPrincipalTransferAccount, string InterestMaturityOption, string InterestTransferAccount)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Term Accounts"), Data.Get("Maturity"));
            WebCSRPageFactory.AccountOverviewPage.UpdateTermAccountsMaturityDetails(PrincipalMaturityOption, ExternalPrincipalTransferAccount, InterestMaturityOption, InterestTransferAccount);
            WebCSRPageFactory.AccountOverviewPage.ClickOnSubmit();
            if (WebCSRPageFactory.AccountOverviewPage.VerifySuccessMessage())
            {
                Report.Pass("Term Account Maturity Details updated successfully", "UpdateTermAccountsMaturityDetails", "true", appHandle);
            }
            else
            {
                Report.Fail("Failed to Update Term Account Maturity Details", "UpdateTermAccountsMaturityDetails", "true", appHandle, true);
            }
        }

        public virtual void UpdateInterestRate(string AccountNumber, string InterestRate)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Interest") + "|" + Data.Get("Rate Determination"));
            WebCSRPageFactory.AccountInformationPage.UpdateInterestRates(InterestRate);
        }
        public virtual void UpdateTransactionProcessingDisbursementSchedule(string PrimaryAccount, string SecondaryAccount, string MaximumNumberOfDisbursements, bool DisbursementScheduleProcessing)
        {
            LoadAccountSummaryPage(PrimaryAccount);
            WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Transaction Processing") + "|" + Data.Get("Disbursement Schedule"));
            WebCSRPageFactory.TransactionProcessingPage.UpdateTransactionProcessingDisbursementSchedule(SecondaryAccount, MaximumNumberOfDisbursements, DisbursementScheduleProcessing);
            WebCSRPageFactory.TransactionProcessingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.TransactionProcessingPage.VerifySuccessfulUpdateMessageInTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Disbursement Schedule updated in Transaction Processing page", "UpdateTransactionProcessingDisbursementSchedule", "True", appHandle);
            }
            else
            {
                Report.Fail("Failed to update Disbursement Schedule in Transaction Processing page", "UpdateTransactionProcessingDisbursementSchedule", "True", appHandle, true);
            }
        }


        public virtual void AddDisbursementSchedule(string AccountNumber, string DisbursementDate, string DisbursementAmount, string DisbursementDescription, bool AutomaticDisbursement)
        {
            LoadAccountSummaryPage(AccountNumber);
            WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Transaction Processing") + "|" + Data.Get("Disbursement Schedule"));
            WebCSRPageFactory.TransactionProcessingPage.AddDisbursementSchedule(DisbursementDate, DisbursementAmount, DisbursementDescription, AutomaticDisbursement);
            WebCSRPageFactory.TransactionProcessingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.TransactionProcessingPage.VerifySuccessfulUpdateMessageInTransactionProcessingPage(Data.Get("GLOBAL_DISBURSEMENT_SCHEDULE_UPDATED")))
            {
                Report.Pass("Disbursement Detail added for Account: " + AccountNumber + " on " + DisbursementDate + " in Transaction Processing page", "AddDisbursementSchedule", "True", appHandle);
            }
            else
            {
                Report.Fail("Failed to create new Disbursement Schedule in Transaction Processing page", "AddDisbursementSchedule", "True", appHandle, true);
            }
        }
        public virtual void NavigateToInterestCalculationpage()
        {
            NavigatetoInterestBalancePage();
            WebCSRPageFactory.LoanCalculationOptionsPage.NavigateToInterestCalculationPage();
        }

        public virtual void VerifylabelValueByLabelName(string sLabelNameLabelValuePipeDelimited)
        {
            string msg = "";
            string failmsg = "";
            string temp = "";
            string[] arr = null;
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is found as " + arr[b].Split('|')[1] + " successfully.";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is found as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " successfully.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebCSRPageFactory.DepositInterestAccrualPage.VerifyTableDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(msg, "passed", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "failed", "True", appHandle, true);
            }

        }


        public virtual void PerformSetupForTestCase(string accountnumber, string latechargemethod, string latechargegracedays, string fixedlatechargeamt)
        {
            Application.WebCSR.GetAccount(accountnumber);
            Application.WebCSR.NavigateToAccountSummaryPage();
            Application.WebCSR.ClickTabInAccountInformationPage("Interest");
            WebCSRPageFactory.WebCSRMasterPage.ClickOnRateDeterminationLink();
            WebCSRPageFactory.AccountInformationPage.UpdateInterestRates("9");
            Application.WebCSR.ClickTabInAccountInformationPage("Delinquency");
            WebCSRPageFactory.WebCSRMasterPage.ClickOnDelinquencyOptionsLink();
            if (WebCSRPageFactory.AccountInformationPage.UpdateValuesOfInDeleinquencyOption(latechargemethod, latechargegracedays, fixedlatechargeamt))
            {
                Report.Pass("The data is updated in Delinquency", "delup", "True", appHandle);
            }
            else
            {
                Report.Fail("The data is not updated in Delinquency", "delupf", "True", appHandle);
            }


        }

        public virtual void CheckDataInAccountHistoryTableBasedOnRefValues(string refvaluesseperatedbydelimsemicolon)
        {
            if (WebCSRPageFactory.DepositAccountOverviewPage.CheckDataInAccountHistoryTableBasedOnRefValues(refvaluesseperatedbydelimsemicolon))
            {
                Report.Pass("The Specified Data available in account history table " + refvaluesseperatedbydelimsemicolon, "dtgb", "True", appHandle);
            }
            else
            {
                Report.Fail("The Specified Data not available in account history table " + refvaluesseperatedbydelimsemicolon, "dtgbf", "True", appHandle);

            }

        }


        public virtual void CheckTableColumNameForAmountsDueperDelinquentPeriod(string lifecolval)
        {
            if (WebCSRPageFactory.AccountInformationPage.CheckTableColumNameForAmountsDueperDelinquentPeriod(lifecolval))
            {
                Report.Pass("The Amount Due per Delinquent Period has expected values", "dop", "True", appHandle);
            }
            else
            {
                Report.Fail("The Amount Due per Delinquent Period has expected values", "dopf", "True", appHandle);
            }
        }


        public virtual string GetCellValueOfLabel(string labelname)
        {
            return WebCSRPageFactory.AccountInformationPage.GetCellValueByLable(labelname);
        }


        public virtual void VerifyValuesInProvisionOrReclassification(string subtoprov, string reclassprocess, string reclassprocifcurrent, string provbal, string provpercen)
        {
            string val1 = GetCellValueOfLabel("Subject to Provision");
            string val2 = GetCellValueOfLabel("Reclassification Processing");
            string val3 = GetCellValueOfLabel("Subject to Reclassification if Current");
            string val4 = GetCellValueOfLabel("Provision Balance");
            string val5 = GetCellValueOfLabel("Provision Percentage");
            if (val1.Equals((subtoprov)) && val2.Equals(reclassprocess) && val3.Equals(reclassprocifcurrent) && val4.Equals(provbal) && val5.Equals(provpercen))
            {
                Report.Pass("The Values matches with data in Provision or Reclassification", "provp", "True", appHandle);

            }
            else
            {
                Report.Fail("The Values not matches with data in Provision or Reclassification", "provf", "True", appHandle);
            }

            WebCSRPageFactory.AccountInformationPage.ClickOnSubmitBUtton();
            if (WebCSRPageFactory.AccountInformationPage.CheckSuccessMessage())
            {
                Report.Pass("The Provisiondetails details submitted successfully", "poyp", "True", appHandle);
            }
            else
            {
                Report.Fail("The Provisiondetails details not submitted", "poyp", "True", appHandle);
            }




        }


        public virtual void UpdateValuesforSetupSOP(string frqval)
        {
            bool val1 = WebCSRPageFactory.AdjustablePaymentCalculationPage.EnterValueForChangeFrequency(frqval);
            ClickTabInAccountInformationPage("General");
            bool val2 = WebCSRPageFactory.AccountInformationPage.SelectCheckboxAccountPurchasedInGeneralTab();

            if (val1 && val2)
            {
                Report.Pass("The Data is eneterd correctly for Generala and Adjustable tab", "adpp", "True", appHandle);
            }
            else
            {
                if (val1 && !val2)
                {
                    Report.Fail("The data is not entered correctly in General tab", "addppf", "True", appHandle);
                }
                else if (!val1 && val2)
                {
                    Report.Fail("The data is not entered correctly in adjustable tab", "addppf1", "True", appHandle);
                }
            }

        }


        public virtual void NavigateToPurchasedImpairedLaon()
        {
            WebCSRPageFactory.AccountInformationPage.NavigateToPurchasedImpairedLaon();

        }


        public virtual string SetupForSOPDP2(string paymentold, string valuestocheckseperatedbydelimpipie)
        {
            WebCSRPageFactory.LoanAccountOverviewPage.ClickOnPaymentSummaryTab();
            WebCSRPageFactory.LoanPaymentTabPage.select_payment_detail_link();
            string paymentNew = WebCSRPageFactory.PaymentDetailPage.GetPIAmountValue();

            double paymentoldnew = Convert.ToDouble(paymentold);
            double paymentNew1 = Convert.ToDouble(paymentNew);

            string Old_Contractually_Required_Payments_Receivable = (paymentoldnew * 7).ToString();
            string New_Contractually_Required_Payments_Receivable = ((paymentNew1 * 6) + (paymentoldnew)).ToString();
            ClickTabInAccountInformationPage("Adjustable Payment/Rate");
            ClickonLink("Rate Changes");
            if (WebCSRPageFactory.LoanRateChangesPage.CheckDataInRateChangeTable(valuestocheckseperatedbydelimpipie))
            {
                Report.Pass("The data present in rate change table", "ratep", "True", appHandle);
            }
            else
            {
                Report.Fail("The data not present in rate change table", "ratef", "True", appHandle);
            }

            return Old_Contractually_Required_Payments_Receivable + ";" + New_Contractually_Required_Payments_Receivable;

        }

        public virtual void AddPurchasedImpairedLoan(string accnum, string CashFlowsExpectedToBeCollected, string InitialInvestment, string SOPEffectiveInterestRate)
        {
            NavigateToPurchasedImpairedLaon();

            if (WebCSRPageFactory.PurchasedImpairedLoanSOP3Page.AddPurchasedImpairedLoan(accnum, CashFlowsExpectedToBeCollected, InitialInvestment, SOPEffectiveInterestRate))
            {
                Report.Pass("Purchased Impaired Loan has been added", "ltp", "True", appHandle);

            }
            else
            {
                Report.Fail("Purchased Impaired Loan not added", "ltpf", "True", appHandle);
            }
        }


        public virtual void SelectCheckboxAccountPurchasedInGeneralTab()
        {
            if (WebCSRPageFactory.AccountInformationPage.SelectCheckboxAccountPurchasedInGeneralTab())
            {
                Report.Pass("The checkbox Account Purchased is selected.", "accheckp", "True", appHandle);
            }
            else
            {
                Report.Fail("The checkbox Account Purchased is not selected.", "accheckf", "True", appHandle);
            }
        }


        public virtual void EditPurchasedLoan(string accnum, string cashflowexpectcollval, string lossincreaseval = "", string lossdecreaseval = "", string effectrate = "")
        {
            NavigateToPurchasedImpairedLaon();
            WebCSRPageFactory.PurchasedImpairedLoanSOP3Page.SelectAccountFromPurchasedtable(accnum);
            WebCSRPageFactory.PurchasedImpairedLoanSOP3Page.ClickEditButton();
            if (WebCSRPageFactory.PurchasedImpairedLoanSOP3Page.EditPurchasedLoan(cashflowexpectcollval, lossincreaseval, lossdecreaseval, effectrate))
            {
                Report.Pass("The purchased loan is edited successfully", "etp", "True", appHandle);
            }
            else
            {
                Report.Fail("The purchased loan is not edited", "etp", "True", appHandle);
            }
        }

        public virtual double RoundOffValue(double inputval, int noofdigit)
        {
            return Math.Round(inputval, noofdigit);
        }

        public virtual void NavigateToEditPagePurchasedImpairedLoan(string accnum)
        {
            WebCSRPageFactory.PurchasedImpairedLoanSOP3Page.SelectAccountFromPurchasedtable("MTGLoan - " + accnum);
            WebCSRPageFactory.PurchasedImpairedLoanSOP3Page.ClickEditButton();
        }

        public virtual void VerifyLabelValueOfLabelName(string labelname, string labelvalue)
        {
            if (GetCellValueOfLabel(labelname).Trim().Equals(labelvalue))
            {
                Report.Pass("Label " + labelname + "has expected label value " + labelvalue, "lnb", "True", appHandle);
            }
            else
            {
                Report.Fail("Label " + labelname + "does not have expected label value " + labelvalue, "lnbf", "True", appHandle);
            }
        }

        public virtual string SelectValueFromBranchOfOwnerShipInGenralTab(int index)
        {
            return WebCSRPageFactory.AccountInformationPage.SelectValueFromBranchOfOwnerShipInGenralTab(index);

        }

        public virtual void UpdateValueOfAccountStatusCodeOverrideInChexSystemDataTab(string value = "")
        {
            WebCSRPageFactory.ChexSystemsDataPage.SelectValueFromAccountStatusCode(value);
            if (WebCSRPageFactory.ChexSystemsDataPage.ClickOnSubmit())
            {
                Report.Pass("The Data of Account Status Code Override is updated with " + value, "abcp", "True", appHandle);

            }
            else
            {
                Report.Fail("The Data of Account Status Code Override is not updated with " + value, "abcf", "True", appHandle);
            }

        }

        public virtual void SetupForChexSystem29(string principalchargeoff, string feechargoffamount, string secclosreason, string tericlosreason)
        {
            if (WebCSRPageFactory.ChexSystemsDataPage.SetupForChexSystem29(principalchargeoff, feechargoffamount, secclosreason, tericlosreason))
            {
                Report.Pass("The Data is setup in Chexsystem Data Tab", "fgb", "True", appHandle);
            }
            else
            {
                Report.Fail("The Data is not setup in Chexsystem Data Tab", "fgb", "True", appHandle);
            }

        }


        public virtual void SetupForChexSystem29DP2(string reasonforchange, string closstatuscodeoveride, string closstatusdate, string settledfullamount)
        {
            if (WebCSRPageFactory.ChexSystemsDataPage.SetupForChexSystem29DP2(reasonforchange, closstatuscodeoveride, closstatusdate, settledfullamount))
            {
                Report.Pass("The Data is setup in Chexsystem Data Tab", "fgbb", "True", appHandle);
            }
            else
            {
                Report.Fail("The Data is not setup in Chexsystem Data Tab", "fgbb", "True", appHandle);
            }
        }

        public virtual void SelectValueFromReasonForRemovalAndSubmit(string val)
        {
            if (WebCSRPageFactory.ChexSystemsDataPage.SelectValueFromReasonForRemovalAndSubmit(val))
            {
                Report.Pass("The Data is setup in Chexsystem Data Tab", "fgbbb", "True", appHandle);

            }
            else
            {
                Report.Fail("The Data is setup in Chexsystem Data Tab", "fgbbb", "True", appHandle);
            }
        }

        public virtual void UpdatePenaltyDetailsForCDAccount(string penaltymet, string redmeth, string penaltyrate, bool checkboxOnAndOffPartialWithdrawal = true)
        {
            if (WebCSRPageFactory.AccountInformationPenaltyPage.UpdatePenaltyDetailsForCDAccount(penaltymet, redmeth, penaltyrate, checkboxOnAndOffPartialWithdrawal))
            {
                Report.Pass("Penalty Data is submitted for CD account", "pop", "True", appHandle);
            }
            else
            {
                Report.Fail("Penalty Data is not submitted for CD account", "pop", "True", appHandle);
            }

        }

        public virtual void SelectValueOfAccrualMethodInInterrestTab(string accmethod)
        {
            if (WebCSRPageFactory.AccountInformationInterestAccrualPage.SelectValueOfAccrualMethod(accmethod))
            {
                Report.Pass("Accrula method details updated in interest tab", "rt", "True", appHandle);
            }
            else
            {
                Report.Fail("Accrula method details not updated in interest tab", "rt", "True", appHandle);
            }

        }

        public virtual void UpdatePenaltyDetailsForCDAccount(string AccountNumber, string penaltymet, string redmeth, string penaltyrate, bool checkboxOnAndOffPartialWithdrawal = true)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Overview"))) { }
            else
            {
                WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
            }
            WebCSRPageFactory.AccountOverviewPage.SelectAccountSummaryTab();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Term Accounts"), Data.Get("Penalty"));
            if (WebCSRPageFactory.AccountInformationPenaltyPage.UpdatePenaltyDetailsForCDAccount(penaltymet, redmeth, penaltyrate, checkboxOnAndOffPartialWithdrawal))
            {
                Report.Pass("Penalty Data is submitted for CD account", "pop", "True", appHandle);
            }
            else
            {
                Report.Fail("Penalty Data is not submitted for CD account", "pop", "True", appHandle);
            }

        }


        public virtual void UpdatePositiveFrequencyInPaymentTab(string AccountNumber, string frqval)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Overview"))) { }
            else
            {
                WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
            }
            WebCSRPageFactory.AccountOverviewPage.SelectAccountSummaryTab();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Payment"));
            WebCSRPageFactory.DepositPaymentPage.UpdatePositiveInterestPostingFrequency(frqval);
            WebCSRPageFactory.DepositPaymentPage.SelectSubmitButton();
            if (WebCSRPageFactory.DepositPaymentPage.CheckSuccessMessage())
            {
                Report.Pass("The positive Frequencg data is updated", "pf", "True", appHandle);
            }
            else
            {
                Report.Fail("The positive Frequencg data is not updated", "pf", "True", appHandle);
            }
        }


        public virtual void UpdateValuesInWithholding(string withholding1042sval, string withholdreason = "", string withholdcalmethod = "", string AccountNumber = "")
        {
            if (!appHandle.GetTitle().Contains(Data.Get("Withholding")))
            {
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            }
            if (WebCSRPageFactory.DepositWithholdingPage.selectvaluefromWithholding1042chapter3status(withholding1042sval, withholdreason, withholdcalmethod))
            {
                Report.Pass("Withholding data is updated successfully", "wup", "True", appHandle);
            }
            else
            {
                Report.Fail("Withholding data is not updated", "wup", "True", appHandle);
            }

        }


        public virtual void SelectSublinkOfTab(string sublinkname)
        {
            WebCSRPageFactory.WebCSRMasterPage.SelectSublinkOfTab(sublinkname);
        }


        public virtual string CalculateAPY(string IR, string interestpaymentfrequencyval, string applicationdate)
        {
            interestpaymentfrequencyval = interestpaymentfrequencyval.ToUpper();
            int CF = 1;
            double IRnew = System.Convert.ToDouble(IR);
            IRnew = IRnew / 100;
            if (interestpaymentfrequencyval.Contains("1MA"))
            {
                CF = 12;
            }
            else if (interestpaymentfrequencyval.Equals("1QA"))
            {
                CF = 4;
            }
            else if (interestpaymentfrequencyval.Equals("1YA"))
            {
                CF = 1;
            }
            else if (interestpaymentfrequencyval.Equals("2YA"))
            {
                CF = 2;
            }
            else if (interestpaymentfrequencyval.Equals("1DA"))
            {
                string year = applicationdate.Split('/')[2];
                if (System.Convert.ToInt32(year) / 4 == 0)
                    CF = 366;
                else
                    CF = 365;
            }


            double AnnualYield = (Math.Pow((1 + IRnew / CF), CF));
            double AnnualYieldnew = (AnnualYield - 1) * 100;
            string AnnualYieldnewfinal = RoundOffValue(AnnualYieldnew, 2).ToString();
            return AnnualYieldnewfinal;
        }


        public virtual void ValidateCustomerHistoryDetailsInPopupWindow(string link, string sLabelNameLabelValuePipeDelimited, string stabledatavaluepipedelimited = "")
        {
            string msg = "";
            string failmsg = "";
            string msg1 = "";
            string failmsg1 = "";
            string temp = "";
            string temp1 = "";
            string[] arr = null;
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {

                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is found as " + arr[b].Split('|')[1] + " successfully in Customer History Window Popup.";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is found as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " successfully in Customer History Window Popup.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (stabledatavaluepipedelimited.Contains(";"))
            {

                arr = stabledatavaluepipedelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp1 = temp1 + " , " + arr[b] + " is found successfully in Customer History Window Popup.";
                }
                msg1 = temp1.Substring(2, temp1.Length - 2);
                failmsg1 = msg1.Replace(" is ", " is not ");
            }
            else
            {
                msg = stabledatavaluepipedelimited.Split(';') + " is found successfully in Customer History Window Popup.";
                failmsg = msg.Replace(" is ", " is not ");
            }
            this.VerifyCustomerHistory(link);
            if (WebCSRPageFactory.CustomerHistoryPage.VerifyTableDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited, stabledatavaluepipedelimited))
            {
                Report.Pass(msg, "Verifypopupwindows", "True", appHandle);
                Report.Pass(msg1, "Verifypopupwindows", "True", appHandle);

            }
            else
            {
                Report.Fail(failmsg, "popupwindowsnotverified", "True", appHandle, true);
                Report.Fail(failmsg1, "popupwindowsnotverified", "True", appHandle, true);
            }
            WebCSRPageFactory.CustomerHistoryPage.ClosePopup();
        }

        public virtual void UpdateAddressInCustomerInformationPage(string CustNo, string city)
        {
            this.GetCustomer(CustNo);
            if (appHandle.GetTitle().Contains("Customer Information")) { }
            else
            {
                SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            }
            WebCSRPageFactory.CustomerInformationPage.VerifyCustomerInformationPageLoads();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            WebCSRPageFactory.CustomerInformationPage.VerifyCustomerInformationPageLoads();
            WebCSRPageFactory.CustomerInformationPage.UpdateAddress(city);
            WebCSRPageFactory.CustomerInformationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.VerifyMessageCustomerInformationPage("The address information has been updated."))
            {
                Report.Pass("The address information has been updated.", "CreditThresholdupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("The address information has not been updated.", "CreditThresholdupdatefail", "True", appHandle, true);
            }

        }
        public virtual void VerifyValuesByLabelNameLabelValueInCustomerInformationPage(string CIF, string sTabName, string LabelNameLabelValuePipeDelimited, string sSubTabName = "")
        {
            if (appHandle.GetTitle().Contains("Customer Information")) { }
            else
            {
                GetCustomer(CIF);
                SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(sTabName, sSubTabName);
            Profile7CommonLibrary.VerifyValueByLabelNameLabelValue(LabelNameLabelValuePipeDelimited);

        }

        public virtual void UpdateCustomerIdentificationDetails(string sPassportNumber, string issuedate, string expdate)
        {
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Identity"), Data.Get("Identification"));
            WebCSRPageFactory.CustomerInformationPage.enter_passport_identification_details(sPassportNumber, issuedate, expdate);
            WebCSRPageFactory.CustomerInformationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.VerifyMessageCustomerInformationPage("The customer identification information has been updated."))
            {
                Report.Pass("The customer identification information has been updated.", "CreditThresholdupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("The customer identification has not been updated.", "CreditThresholdupdatefail", "True", appHandle, true);
            }

        }
        public virtual void UpdateCustomerName(string name)
        {
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Name"));
            WebCSRPageFactory.CustomerInformationPage.UpdateNameInPersonalInfo(name);
            WebCSRPageFactory.CustomerInformationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.VerifyMessageCustomerInformationPage("The customer name information has been updated."))
            {
                Report.Pass("The customer name has been updated.", "CreditThresholdupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("The customer name has not been updated.", "CreditThresholdupdatefail", "True", appHandle, true);
            }

        }
        public virtual void VerifyCustomerVerificationIntegrity()
        {
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Customer Verification"));

            if (WebCSRPageFactory.CustomerSearchPage.VerifyCustomerInformationIntegrity())
            {
                Report.Pass("Customer Integrity is successfully verified. ", "AccountVerificationStatusPass", "true", appHandle);
            }
            else
            {
                Report.Fail("Customer Integrity is successfully verified is not found. ", "AccountVerificationStatusFail", "true", appHandle, true);
            }
        }
        public virtual void VerifyTabsonAccountSummaryPage(string AccountNumber, string reftabnameSemicolonDelimited)
        {
            LoadAccountSummaryPage(AccountNumber);
            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (reftabnameSemicolonDelimited.Contains(";"))
            {
                arr = reftabnameSemicolonDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split(';')) + " tab is present in Account Summary Page.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", reftabnameSemicolonDelimited.Split(';')) + " tab is not present in Account Summary Page.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebCSRPageFactory.AccountHistoryPage.VerifytabsInAccountInformationPage(reftabnameSemicolonDelimited))
            {
                Report.Pass(msg, "AccountSummaryTabFound", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "AccountSummaryTabNotFound", "True", appHandle, true);
            }

        }

        public virtual void VerifyDataInAccountHistoryDetailsPopUp(string AccountNumber, string LinkName, string sLabelNameLabelValuePipeDelimited = "", string stabledatavaluesemicolondelimited = "", string lineno = "")
        {
            VerifyDataInAccountHistoryTable(AccountNumber, LinkName);

            if (!string.IsNullOrEmpty(lineno))
            {
                WebCSRPageFactory.AccountHistoryPage.ClickOnLinkInAccountHistoryTable(LinkName, lineno);
            }
            else
            {
                ClickLoanAccountMaintenanceLink2(LinkName);
            }
            string msg = "";
            string failmsg = "";
            string msg1 = "";
            string failmsg1 = "";
            string temp = "";
            string temp1 = "";
            string[] arr = null;
            if (sLabelNameLabelValuePipeDelimited.Contains(";"))
            {
                arr = sLabelNameLabelValuePipeDelimited.Split(';');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + arr[b].Split('|')[0] + " is found as " + arr[b].Split('|')[1] + " successfully in Customer History Window Popup.";
                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = sLabelNameLabelValuePipeDelimited.Split('|')[0] + " is found as " + sLabelNameLabelValuePipeDelimited.Split('|')[1] + " successfully in Customer History Window Popup.";
                failmsg = msg.Replace(" is ", " is not ");
            }
            if (!string.IsNullOrEmpty(stabledatavaluesemicolondelimited))
            {

                if (stabledatavaluesemicolondelimited.Contains(";"))
                {
                    arr = stabledatavaluesemicolondelimited.Split(';');
                    for (int b = 0; b < arr.Length; b++)
                    {
                        temp1 = temp1 + " , " + arr[b] + " is found successfully in Customer History Window Popup.";
                    }
                    msg1 = temp1.Substring(2, temp1.Length - 2);
                    failmsg1 = msg1.Replace(" is ", " is not ");
                }
                else
                {
                    msg = stabledatavaluesemicolondelimited.Split(';') + " is found successfully in Customer History Window Popup.";
                    failmsg = msg.Replace(" is ", " is not ");
                }
            }
            if (WebCSRPageFactory.CustomerHistoryPage.VerifyTableDataByLabelNameLabelValue(sLabelNameLabelValuePipeDelimited, stabledatavaluesemicolondelimited))
            {
                Report.Pass(msg, "Verifypopupwindows", "True", appHandle);
                if (!string.IsNullOrEmpty(stabledatavaluesemicolondelimited))
                {
                    Report.Pass(msg1, "Verifypopupwindows", "True", appHandle);
                }
            }
            else
            {
                Report.Fail(failmsg, "popupwindowsnotverified", "True", appHandle, true);
                if (!string.IsNullOrEmpty(stabledatavaluesemicolondelimited))
                {
                    Report.Fail(failmsg1, "popupwindowsnotverified", "True", appHandle, true);
                }
            }

            WebCSRPageFactory.AccountHistoryPage.ClosePopup();

        }
        public virtual void UpdateCustomerDetailsVerifyAccountHistoryDetailsPopUp(string UpdateInformation, string UpdateDetails, string AccountNumber1, string LinkName1, string sLabelNameLabelValuePipeDelimited1, string stabledatavaluesemicolondelimited = "")
        {
            if (UpdateInformation.Equals("Customer Code"))
            {
                LoadAccountSummaryPage(AccountNumber1);
                ModifyCustomerCodeOnLoanGeneralPage(Data.Get("Regular Customer"));
                VerifyInformationUpdatedMessage();
            }
            else if (UpdateInformation.Equals("Update Address"))
            {
                LoadAccountSummaryPage(AccountNumber1);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Title/Address"));
                ModifyMailingAddressOnAccountSummaryPage(Data.Get("GLOBAL_ADDRESS2_VALUE"));
                VerifyInformationUpdatedMessage();
            }
            VerifyDataInAccountHistoryDetailsPopUp(AccountNumber1, LinkName1, sLabelNameLabelValuePipeDelimited1, stabledatavaluesemicolondelimited);

        }
        public virtual void SelectAmortizationCalcMethodinPaymentApplicationPage(string AccountNumber, string calculationMethod)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Payment"), Data.Get("Payment Calculation"));
            WebCSRPageFactory.LoanPaymentPaymentApplicationPage.SelectAmortizationCalcMethod(calculationMethod);
            WebCSRPageFactory.LoanPaymentPaymentApplicationPage.ClickOnSubmitButton();
            WebCSRPageFactory.LoanPaymentPaymentApplicationPage.VerifyMessageInLoanPaymentsPaymentApplicationPage("GLOBAL_INFORMATION_UPDATED");
        }

        public virtual bool VerifytabsInAccountInformationPage(string reftabnameSemicolonDelimited)
        {
            bool Result = false;
            int matchCount = 0;
            reftabnameSemicolonDelimited = reftabnameSemicolonDelimited + ";";
            string[] arr1 = reftabnameSemicolonDelimited.Split(';');

            string temp = appHandle.GetObjectText("XPath;//h1[contains(text(),'Account Information')]/ancestor::tbody[1]");
            string[] arr = temp.Split(new string[] { "\r\n" }, StringSplitOptions.None);
            List<string> tabsList = new List<string>();

            for (int a = 0; a < arr.Length - 1; a++)
            {
                for (int b = 0; b < arr1.Length - 1; b++)
                {
                    tabsList.Add(arr[a].Trim());

                    if (arr[a].Contains(arr1[b]))
                    {
                        matchCount++;
                    }
                }
                if (matchCount == arr1.Length - 1)
                {
                    Result = true;
                    break;
                }
            }
            return Result;
        }
        public virtual void EnterNonResidencyCustomerInformationResidencyPageDetails(string CustomerNumber, bool NonresidentONorOFF = false, string ResidencyStatus = " ", string CountryofResidency = "", string CountryofCitizenship = " ", bool W8RequiredONorOFF = true, string w8type = "", string w8datereceived = "", string ReportingChapter3Status = " ", string CalculationMethod = "", bool SubjecttoWithholding = true, string witholdingReason = "")
        {
            string temptitle = appHandle.GetTitle();
            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), CustomerNumber);
            }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), CustomerNumber);
            }

            WebCSRPageFactory.CustomerSearchPage.NavigateToCustomerInformationPage();
            Report.Info("Account Customer Information page is displayed.", "custinfoacctcreate", "true", appHandle);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"));
            if (WebCSRPageFactory.CustomerInformationResidencyPage.WaitUntilCustomerInformationResidencyPageLoad())
            {
                WebCSRPageFactory.CustomerInformationResidencyPage.EnterNonResidenceDetails(NonresidentONorOFF, ResidencyStatus, CountryofResidency, CountryofCitizenship, W8RequiredONorOFF, w8type, w8datereceived, ReportingChapter3Status, CalculationMethod, SubjecttoWithholding, witholdingReason);
                WebCSRPageFactory.CustomerInformationResidencyPage.SelectSubmitButton();
                if (WebCSRPageFactory.CustomerInformationResidencyPage.VerifyMessageAccountInformationResidencyPage(Data.Get("The customer information has been updated.")))
                {
                    Report.Pass("Residency Page Information updated successfully.", "ResidencyPageUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Residency Page Information is not updated successfully.", "ResidencyPageNotUpdated", "True", appHandle, true);
                }

            }
        }

        public virtual void navigatetoWithholdingpage()
        {
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));

        }

        public virtual void UpdateDataInIRS1042SReportingCorrection(string AccountNumber, string taxyear, string date = "", string percentage = "", string countrycode = "")
        {

            if (!appHandle.GetTitle().Contains(Data.Get("IRS 1042-S Reporting Correction")))
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("AccountNumber"));
                WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_ACCOUNTLIST"));
                WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                this.ClickLinkFromMenuItem(Data.Get("Deposit Account Services") + "|" + Data.Get("IRS 1042-S Reporting Correction"));
            }
            else
            {
                if (WebCSRPageFactory.IRS1042SReportingCorrectionPage.VerifyAccountExistsInAccountDropdown(AccountNumber)) { }
                else
                {
                    WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("AccountNumber"));
                    WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_ACCOUNTLIST"));
                    WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                    this.ClickLinkFromMenuItem(Data.Get("Deposit Account Services") + "|" + Data.Get("IRS 1042-S Reporting Correction"));
                }
            }

            WebCSRPageFactory.IRS1042SReportingCorrectionPage.UpdateDataInIRS1042SReportingCorrection(AccountNumber, taxyear, date, percentage, countrycode);
            if (WebCSRPageFactory.IRS1042SReportingCorrectionPage.VerifyMessageInstitutionVariable(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("information is updated in IRS 1042S Reporting Correction Page Successfully", "IRS1042SReportingCorrectionCheck", "True", appHandle);
            }
            else
            {
                Report.Fail("information is notupdated in IRS 1042S Reporting Correction Page", "IRS1042SReportingCorrectionCheck", "True", appHandle, true);
            }
        }
        public virtual void VerifyFeeInTableExceptionProceesingInFeePage(string Account, string sLabelNameLabelValuePipeDelimited, string itempaid = "", string itemreturned = "")
        {
            this.LoadAccountSummaryPage(Account);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Fees"));
            if (WebCSRPageFactory.DepositAccountFeePage.VerifyDataInTableByColumnValues(sLabelNameLabelValuePipeDelimited, itempaid, itemreturned))
            {
                Report.Pass(sLabelNameLabelValuePipeDelimited + ";" + itempaid + ";" + itemreturned + "is Verify in Exception Item Processing table", "Fees", "true", appHandle);
            }
            else
            {
                Report.Fail(sLabelNameLabelValuePipeDelimited + "is not Verify in Exception Item Processing table", "Feesfail", "true", appHandle, true);
            }
        }
        public virtual void VerifyObjectExistInResidencyPage(string CustomerNumber, string w8RecieveDate)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"));
            WebCSRPageFactory.CustomerInformationResidencyPage.VerifyObjectExist();
            WebCSRPageFactory.CustomerInformationResidencyPage.UpdateW8Details(w8RecieveDate);
            WebCSRPageFactory.CustomerInformationResidencyPage.UpdateForeignCorporationDetails();
            Report.Info("The Residency General Page Details are verified successfully", "ResidencyGeneral", "true", appHandle);

        }
        public virtual void VerifyW8BENEDetailsInFACTAPageForCorporate(string CustomerNumber)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("FATCA"));
            WebCSRPageFactory.CustomerInformationResidencyPage.VerifyObjectExistInFATCAPage();
            Report.Info("The Residency FATCA Page Details are verified successfully", "ResidencyFATCA", "true", appHandle);

        }
        public virtual void UpdateFACTADetailsInFATCAPageForCorporate(string CustomerNumber, string W8BeneStatus, string FATCAExcemptionCode, string ClaimDate, string CollectionDate, string VerificationDate)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("FATCA"));
            WebCSRPageFactory.CustomerInformationResidencyPage.UpdateFATCADetailsForCorporate(W8BeneStatus, FATCAExcemptionCode, ClaimDate, CollectionDate, VerificationDate);
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationResidencyPage.VerifyMessageAccountInformationResidencyPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION_UPDATED")))
            {
                Report.Pass("The Residency FATCA Page Details are Updated successfully", "ResidencyFATCA", "true", appHandle);
            }
            else
            {
                Report.Fail("The Residency FATCA Page Details are not Updated successfully", "ResidencyFATCAfail", "true", appHandle, true);
            }

        }
        public virtual void VerifyObjectsOfUSSubstantialOwnerPageForCorporate(string CustomerNumber)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("Substantial U.S. Owners"));
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnAddButtonInSubtantialUSOwnersPage();
            WebCSRPageFactory.CustomerInformationResidencyPage.VerifyObjectExistInUSSubstantialOwnerPage();
            Report.Pass("The Residency Substantial U.S. Owner Page Details are verified successfully", "SubstantialU.S.Owner", "true", appHandle);

        }
        public virtual void UpdateSubstantialUSOwnerForCorporate(string CustomerNumber)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("Substantial U.S. Owners"));
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnAddButtonInSubtantialUSOwnersPage();
            WebCSRPageFactory.CustomerInformationResidencyPage.UpdateUSSubstantialOwnerDetailsForCorporate();
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnSubmitButton();
            Report.Pass("The Residency Substantial U.S. Owner Page Details are Added successfully", "SubstantialU.S.Owners", "true", appHandle);
        }
        public virtual string CreateCorporateCustomerWithCoIAsNonUS(string Country, bool AppliedForONorOFF, string W8Type, string GIINClaimDate, string GIINCollectedDate, string GIINVerificationDate, string GIIN = null)
        {
            string CustNo = "";
            string[] arrOnlineAccessSecurityDetails = null;
            string sSearchvalue = "";
            string sSearchType = "";
            WebCSRPageFactory.WebCSRMasterPage.SelectCorporateCustomerLink();
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterCorporateInformation();
            WebCSRPageFactory.CreateCorporateCustomerPage.SelectCountryOfIncorporationOtherThanUS(Country);
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterEmailAndPhoneDetails();
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterPrincipalAddress();
            WebCSRPageFactory.CreateCorporateCustomerPage.SelectAddressSameAsPrincipalAddressRadioButton("yes");
            string sRandomValue = RandomNumberGenerator.Generate();
            sRandomValue = sRandomValue.Substring(0, sRandomValue.Length - 1);
            string sUserID = StartupConfiguration.EnvironmentDetails.UserFirstName;
            sUserID = appHandle.SplitSideString(sUserID.ToUpper(), "LEFT", 4) + sRandomValue;
            string sAllowOnlineAccess = Data.Get("GLOBAL_PERSONAL_CUSTOMER_ALLOW_ONLINE_ACCESS");
            if (sAllowOnlineAccess.ToUpper().Equals("YES"))
            {
                WebCSRPageFactory.CreateCorporateCustomerPage.SelectAllowOnlineAccessRadioButton("yes");

                // To enter Online Access Details
                WebCSRPageFactory.CreateCorporateCustomerPage.EnterOnlineAccessDetails();

                // To get the Temporary Password Action dropdown value 
                string sTemporaryPasswordAction = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_tmporary_password_action_field_value();
                // Get the Value in the User ID Field
                string sWebClientUserID1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_online_access_user_id_field_value();

                if (sTemporaryPasswordAction.Equals(Data.Get("GLOBAL_TEMPORARY_PASSWORD_ACTION_RESET")))
                {
                    string sOnlineAccessSecurityDetails = Data.Get("GLOBAL_ONLINESECURITY_DETAILS");
                    arrOnlineAccessSecurityDetails = sOnlineAccessSecurityDetails.Split('_');
                    WebCSRPageFactory.CreatePersonalCustomerPage.enter_online_access_security_details(arrOnlineAccessSecurityDetails);
                }
            }
            else
            {
                WebCSRPageFactory.CreatePersonalCustomerPage.set_radio_button_allow_online_access_no();
            }

            // Enter Security Question details.
            WebCSRPageFactory.CreateCorporateCustomerPage.EnterSecretQuestionDetails();

            // Enter Telephone Banking details.
            WebCSRPageFactory.CreateCorporateCustomerPage.SelectCreateATelePhonebankingPINRadioButton("Yes");
            WebCSRPageFactory.CreateCorporateCustomerPage.UpdateW8TypeforCorporate(W8Type);
            if (WebCSRPageFactory.CreateCorporateCustomerPage.GetObjectValueOfW8Type().Equals(Data.Get("GLOBAL_W8TYPE_W8BENE")))
            {

                string sTaxIdValue1 = WebCSRPageFactory.CreatePersonalCustomerPage.get_tax_id_number_field_value();
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnContinueButton();
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnGIINAppliedForCheckBox(AppliedForONorOFF);
                WebCSRPageFactory.CreateCorporateCustomerPage.UpdateW8BENEdetails(GIINClaimDate, GIINCollectedDate, GIINVerificationDate, GIIN);
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnAddButton();
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnSubstantialOwnerAddButton();
                WebCSRPageFactory.CreateCorporateCustomerPage.UpdateDetailsOfSubstantialOwner();
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnSubmitButton();
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnSubmitButton();
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnContinueButton();
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnSubmitButton();
                if (WebCSRPageFactory.CreateCorporateCustomerPage.VerifyCorporateCustomerCreationSuccess())
                {
                    Report.Info("Corporate Customer application is created successfully", "CorporateCustCreate", "true", appHandle);

                    sSearchvalue = sTaxIdValue1;
                    sSearchType = Data.Get("GLOBAL_SEARCHTYPE_TAXID");
                    CustNo = WebCSRPageFactory.CustomerSearchPage.get_customer_number(sSearchType, sSearchvalue);
                    if (!string.IsNullOrEmpty(CustNo))
                    {
                        Report.Info("Corporate customer number is captured as: " + CustNo, "custcorp", "true", appHandle);
                    }
                }
                else
                {
                    Report.Fail("Corporate Customer application is not created due to :" + WebCSRPageFactory.CreateCorporateCustomerPage.GetMessageText(), "CreatecorpcustFail", "true", appHandle, true);
                }
            }
            else
            {
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnContinueButton();
                WebCSRPageFactory.CreateCorporateCustomerPage.VerifyCorporateCustomerVerificationPage();
                Report.Info("Create Corporate Customer Verification is appeared", "CreateCorporateCustomer", "true", appHandle);
                WebCSRPageFactory.CreateCorporateCustomerPage.ClickOnBackButton();
            }

            return CustNo;
        }
        public virtual void VerifyFileCorrectionList(string TypeofCorrections, string FileSeq, string AccountNo, string ReasonforCorrection)
        {
            this.ClickLinkFromMenuItem(Data.Get("IRS Forms") + "|" + Data.Get("Form 8966 Reporting Correction"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("File Corrections"));
            WebCSRPageFactory.Form8966ReportCorrectionPage.EnterFileCorrectionsdetails(TypeofCorrections, FileSeq, AccountNo);
            WebCSRPageFactory.Form8966ReportCorrectionPage.ClickOnSearch();
            WebCSRPageFactory.Form8966ReportCorrectionPage.VerifyDatainTableofCorrections(ReasonforCorrection);
            Report.Info("The File Corrections list page displays the Customer Name, Tax ID, Account Number details along with Reason for Correction dropdown.", "filecorrections", "true", appHandle);

        }
        public virtual void SubmittheCorrectionInFileCorrections(string Account, string ReasonforCorrection, string Msg)
        {
            WebCSRPageFactory.Form8966ReportCorrectionPage.SelectCorrectionFileListOrder(Account);
            WebCSRPageFactory.Form8966ReportCorrectionPage.SelectReasonForCorrection(ReasonforCorrection);
            WebCSRPageFactory.Form8966ReportCorrectionPage.ClickOnSubmit();
            if (WebCSRPageFactory.Form8966ReportCorrectionPage.VerifyMessageInFormCorrectiosPage(Msg))
            {
                Report.Pass("The correction is Submitted successfully.", "FileCorrections", "True", appHandle);
            }
            else
            {
                Report.Fail("The correction was not Submitted successfully.", "FileCorrectionsfails", "True", appHandle, true);

            }
        }

        public virtual void VerifyentriesofFileCorrectionInPayeeReporting(string ReasonforCorrection)
        {
            this.ClickLinkFromMenuItem(Data.Get("IRS Forms") + "|" + Data.Get("Form 8966 Reporting Correction"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Pending Corrections"));
            WebCSRPageFactory.Form8966ReportCorrectionPage.VerifyDatainTableofCorrections(ReasonforCorrection);
            Report.Info("The selected entries in File Corrections page are marked for correction.", "Pendingcorrections", "true", appHandle);

        }
        public virtual string YearBackdatedForAccountOpening(int NoOfYears = 1)
        {
            string Date = this.GetApplicationDate();
            string Year = appHandle.GetDateParameters(Date)[2].Trim();
            double LastYear = 0;
            string BackDatedYear = "";
            LastYear = Convert.ToDouble(Year) - NoOfYears;
            return BackDatedYear = LastYear.ToString();


        }
        public virtual void UpdateWithholdingDetailsinWithholdingPage(string Account, string withholdreason, string calculation, string Chapter4status)
        {
            LoadAccountSummaryPage(Account);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            WebCSRPageFactory.DepositWithholdingPage.UpdateWithholdindDetails(withholdreason, Chapter4status);
            WebCSRPageFactory.DepositWithholdingPage.EnterInterestPageOptions(calculation);
            WebCSRPageFactory.DepositWithholdingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositWithholdingPage.VerifyMessageDepositWitholdingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The withholding details was updated successfully", "withholding", "true", appHandle);

            }
            else
            {
                Report.Fail("The withholding details was not updated successfully", "withholdingfails", "true", appHandle, true);
            }
        }
        public virtual void LoginWebCSRWithNewUserCredential(string UserName, string Branch)
        {
            string pwd = Data.Get("GLOBAL_WEBADMIN_USER_PASSWORD");
            this.Login(UserName, pwd, Branch);
            if (WebCSRPageFactory.LoginPage.VerifyMSGToResetPassword())
            {
                Report.Info(Data.Get("You must change your password before you can proceed. Please choose a new password.") + " is displayed to change password for the new created user.", "newuserpassword", "true", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("You must change your password before you can proceed. Please choose a new password.") + " is not displayed to change password for the new created user.", "newuserpasswordFail", "true", appHandle, true);
            }
            WebCSRPageFactory.LoginPage.enter_reset_password_details(pwd, PWD);
            WebCSRPageFactory.LoginPage.select_submit_button();
            if (WebCSRPageFactory.LoginPage.VerifyResetPasswordMessage())
            {
                Report.Info("Password is  changed successfully.", "Password Reset Success", "true", appHandle);

                WebCSRPageFactory.LoginPage.enter_login_details(UserName, PWD, Branch);
                WebCSRPageFactory.LoginPage.select_submit_button();
                if (WebCSRPageFactory.LoginPage.VerifyCustomerSearchPageLoads())
                {
                    Report.Pass("WebCSR application is Logged in successfully using new user credentials.", "Login Screen", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
                }
                else
                {
                    Report.Fail("WebCSR application is not Logged in successfully using new user credentials.", "Login Screen Fail", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB), true);
                }

            }
            else
            {
                Report.Fail("Password Reset is not successful.", "Password Reset Failed", appHandle, true);
            }

        }
        public virtual void UpdateRegulationCCExceptionCode(string Account, string ExceptionCode)
        {
            this.LoadAccountSummaryPage(Account);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));
            WebCSRPageFactory.USRegulatoryPage.VerifyUSRegulatoryPageLoads();
            WebCSRPageFactory.USRegulatoryPage.UpdateRegulationCCExceptionCode(ExceptionCode);
            WebCSRPageFactory.USRegulatoryPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.USRegulatoryPage.VerifyMessageInUSRegulatoryPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Regulation CC Exception Code in US Regulatory page under Account information is successfully updated.", "REGCCUpdate", "true", appHandle);
            }
            else
            {
                Report.Fail("Regulation CC Exception Code in US Regulatory page under Account information is not successfully updated.", "REGCCUpdatefail", "true", appHandle, true);
            }
        }

        public virtual string AddCardInCardManagementPage(string CardType, string AccountNumber, string AccessOption = "", string EmbossingOption = "", string Amount = "", string ExpDate = "", string cardstatus = "")
        {
            LoadAccountSummaryPage(AccountNumber);
            ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            WebCSRPageFactory.CardManagementPage.selectAccountFromDropDown(AccountNumber);
            WebCSRPageFactory.CardManagementPage.ClickOnAddButton();
            WebCSRPageFactory.CardManagementPage.SelectCardType(CardType);
            Report.Pass("Card type selected ", "CardManagementpage", "true", appHandle);
            string CardNo = WebCSRPageFactory.CardManagementPage.UpdateCardDetails(CardType, AccountNumber, AccessOption, EmbossingOption, Amount, ExpDate, cardstatus);
            Report.Pass("Enter Card Details in Card Management page ", "CardManagementpage1", "true", appHandle);
            WebCSRPageFactory.CardManagementPage.MoveAccountFromAvailableAccountToSelectedAccounts(AccountNumber);
            Report.Pass("Enter Card Details in Card Management page ", "CardManagementpage2", "true", appHandle);
            WebCSRPageFactory.CardManagementPage.ClickOnSubmitButton();
            return CardNo;
        }
        public virtual void DeleteCardInCardManageMentPage(string AccountNumber, string UniqueOrderRefValue)
        {
            GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            WebCSRPageFactory.CardManagementPage.selectAccountFromDropDown(AccountNumber);
            WebCSRPageFactory.CardManagementPage.SelectCardInCardList(UniqueOrderRefValue);
            WebCSRPageFactory.CardManagementPage.ClickOnDeleteButton();
            appHandle.Wait_For_Specified_Time(5);
            appHandle.PerformActionOnAlert(PopUpAction.Verify, Data.Get("Are you sure you want to delete this order?"));
            appHandle.Wait_For_Specified_Time(4);
            appHandle.PerformActionOnAlert(PopUpAction.Accept);

            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Data.Get("The card has been deleted.")))
            {
                Report.Pass("The card has been deleted is displayed.", "deletecard", "True", appHandle);
            }
            else
            {
                Report.Fail("The card has been deleted is not displayed.", "cardlistfail", "True", appHandle);
            }
        }
        public virtual void VerifyCardHistoryInCardHistoryTab(string Account, string card)
        {
            GetAccount(Account);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Card History"));
            WebCSRPageFactory.CardManagementPage.selectAccountFromDropDown(Account);
            WebCSRPageFactory.CardManagementPage.selectCardNumberFromDropDown(card);
            if (WebCSRPageFactory.CardManagementPage.VerifyCardHistory(Account))
            {
                Report.Pass("Card History is Verified in Card History Page", "cardhistory", "true", appHandle);
            }
            else
            {
                Report.Fail("Card History was not Verified in Card History Page", "cardhistoryfails", "true", appHandle);
            }
        }
        public virtual string GetCustomerHomeAddressCityNameFromAddressTabCustomerInformation(string CustomerNo)
        {
            if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"))
             && Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("TableCIF") + "#: " + CustomerNo)) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNo, Data.Get("Customer Number"));
                this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            string CityName = WebCSRPageFactory.AddressPage.GetCityName();
            return CityName;
        }
        public virtual void VerifyW8TypeReflectOnResidencyPage(string CustomerNumber, string w8type)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"));
            if (WebCSRPageFactory.CustomerInformationResidencyPage.VerifyDetailsInResidencyGeneralPage(w8type))
            {
                Report.Pass("W8Ben Type is captured as : " + w8type + " in Residency Page.", "General", "True", appHandle);
            }
            else
            {
                Report.Fail("W8Ben Type is not captured as : " + w8type + " in Residency Page.", "General", "True", appHandle, true);
            }
        }
        public virtual void VerifyFATCADetailsReflectonFATCAPage(string CustomerNumber, string LabelNamePipeDelimitedExpectedvalue)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("FATCA"));
            if (WebCSRPageFactory.CustomerInformationResidencyPage.VerifyFATCADetailsyFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in FATCA Page.", "FATCA", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + "  in FATCA Page.", "FATCA", "True", appHandle, true);
            }
        }
        public virtual void VerifySubstantialUSOwnerDetailsReflectonSubstantialUSOwnerPage(string CustomerNumber, string UniqueOrderRefValue, string LabelNamePipeDelimitedExpectedvalue)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("Substantial U.S. Owners"));
            WebCSRPageFactory.CustomerInformationResidencyPage.SelectOwnersInOwnerList(UniqueOrderRefValue);
            //WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnEditButton();
            if (WebCSRPageFactory.CustomerInformationResidencyPage.VerifySubstantialOwnerDetailsyFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in Substantial US Owner Page.", "SubstantialUSOwner", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + "  in Substantial US Owner Page.", "SubstantialUSOwnerfail", "True", appHandle, true);
            }
        }
        public virtual void VerifyFATCADetailsReflectonDepositWithholdingPage(string Account, string LabelNamePipeDelimitedExpectedvalue)
        {
            LoadAccountSummaryPage(Account);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            if (WebCSRPageFactory.DepositWithholdingPage.VerifyFATCAWithholdingDetailsyFieldValuesByLabelNameFieldValue(LabelNamePipeDelimitedExpectedvalue))
            {
                Report.Pass(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + " in FATCA Page.", "FATCA", "True", appHandle);
            }
            else
            {
                Report.Fail(LabelNamePipeDelimitedExpectedvalue.Split('|')[0] + " is not captured as : " + LabelNamePipeDelimitedExpectedvalue.Split('|')[1] + "  in FATCA Page.", "FATCA", "True", appHandle, true);
            }
        }
        public virtual void UpdateAccrWithholdingTaxIndexInWithholdingPage(string Account, string WithholdingTaxIndex, string TaxRate = "")
        {
            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(Account);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            }
            WebCSRPageFactory.DepositWithholdingPage.UpdateAccrWithholdingTaxIndexandRate(WithholdingTaxIndex, TaxRate);
            WebCSRPageFactory.DepositWithholdingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositWithholdingPage.VerifyMessageDepositWitholdingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Subject To Withholding Chekbox and Calculation methods are Selected", "SubjToWithholdingSelected", "True", appHandle);
            }
            else
            {
                Report.Fail("Subject To Withholding Checkbox and Calculation Methods are not Selected", "SubjToWithholdingNotSelected", "True", appHandle, true);
            }

        }
        public virtual void ToVerifyWithholdingIsNotEnabled(string AccountNumber)
        {
            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            }
            WebCSRPageFactory.DepositWithholdingPage.ToCheckTheStatusofWithholdingCheckBox();
            Report.Pass("Withholding Option is Verified in the Withholding Page", "Withholding", "true", appHandle);

        }
        public virtual void VerifyErrorMsgForWithholdingNotEnabled(string Account, bool AccrWitholdingONorOFF, string WithholdingTaxIndex, string TaxRate = "")
        {
            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(Account);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            }
            WebCSRPageFactory.DepositWithholdingPage.CheckAccruedWitholdingTax(AccrWitholdingONorOFF);
            WebCSRPageFactory.DepositWithholdingPage.UpdateAccrWithholdingTaxIndexandRate(WithholdingTaxIndex, TaxRate);
            WebCSRPageFactory.DepositWithholdingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositWithholdingPage.VerifyMessageDepositWitholdingPage(Data.Get("Withholding Msg")))
            {
                Report.Pass("The system not allow users to enable Accrued withholding option (AWTP) for an account when backup withholding option is not enabled was verified", "SubjToWithholdingSelected", "True", appHandle);
            }
            else
            {
                Report.Fail("The system not allow users to enable Accrued withholding option (AWTP) for an account when backup withholding option is not enabled was not Verified", "SubjToWithholdingNotSelected", "True", appHandle, true);
            }

        }
        public virtual void SelectWithholdingandUpdateTheDetails(string Account, bool SubjToWithholdingONorOFF, string WitholdingReason, string Chapter4status, String WithholdingTaxIndex, string TaxRate)
        {
            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(Account);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            }
            WebCSRPageFactory.DepositWithholdingPage.CheckSubjToWithholding(SubjToWithholdingONorOFF);
            WebCSRPageFactory.DepositWithholdingPage.UpdateWithholdindDetails(WitholdingReason, Chapter4status);
            WebCSRPageFactory.DepositWithholdingPage.UpdateAccrWithholdingTaxIndexandRate(WithholdingTaxIndex, TaxRate);
            WebCSRPageFactory.DepositWithholdingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.DepositWithholdingPage.VerifyMessageDepositWitholdingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Withholding informations Updated after Accrued withholding option (AWTP) and backup withholding option are Selected", "SubjToWithholdingSelected", "True", appHandle);
            }
            else
            {
                Report.Fail("Withholding informations Updated after Accrued withholding option (AWTP) and backup withholding option are not Selected", "SubjToWithholdingNotSelected", "True", appHandle, true);
            }

        }
        public virtual string GetAggregateAvailableBalanceFromAccountSummary(string AccountNumber)
        {
            LoadAccountSummaryPage(AccountNumber);
            string data = WebCSRPageFactory.DepositAccountOverviewPage.GetValueForLabel(Data.Get("Aggregate Available Balance"));
            return data;
        }
        public virtual string GetValueofFATCAWithholdingFromWithholdingPage(string AccountNumber)
        {
            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Withholding"));
            }
            string data = WebCSRPageFactory.DepositWithholdingPage.GetValueForLabelForFATCAWithholding(Data.Get("Withholding Current Tax Year"));
            return data;
        }
        public virtual void ToCheckGIINIsDisabledAndAppliedForisChecked(string CustomerNo)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNo, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("FATCA"));
            WebCSRPageFactory.CustomerInformationResidencyPage.ToCheckGIINIsDisabledAndAppliedForisChecked();
            Report.Info("The GIIN text Field and Applied For Checkbox is Verified in FATCA Page", "FATCA", "true", appHandle);

        }
        public virtual void UpdateServiceFeePlanInDepositAccountFeePage(string Account, string FeePlan, string FeeFrequency, string Feeoption)
        {
            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(Account);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Fees"));
            }
            WebCSRPageFactory.DepositAccountFeePage.UpdateFeePlan(FeePlan);
            WebCSRPageFactory.DepositAccountFeePage.UpdateServiceFeeOption(FeeFrequency, Feeoption);
            WebCSRPageFactory.DepositAccountFeePage.ClickOnSubmit();
            if (WebCSRPageFactory.DepositAccountFeePage.VerifyMessageDepositFeePage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Fee Plan was Updated successfully In Deposit Fee Page", "FeePage", "true", appHandle);

            }
            else
            {
                Report.Fail("The Fee Plan was not Updated successfully In Deposit Fee Page", "FeePagefail", "true", appHandle, true);
            }
        }
        public virtual void VerifyNoOfInitialDaysInInterestBalancePage(string Account, string sLabelNameLabelValuePipeDelimited)
        {
            this.LoadAccountSummaryPage(Account);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"));
            if (WebCSRPageFactory.LoanInterestTab.VerifyLoanBalanceValuesBylabelNameLabelValue(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(sLabelNameLabelValuePipeDelimited + "is Verified in Balance Page", "Balance", "true", appHandle);
            }
            else
            {
                Report.Fail(sLabelNameLabelValuePipeDelimited + "is not Verified in Balance Page", "Balancefail", "true", appHandle, true);
            }


        }
        public virtual void VerifyInterestCalculationOptionInInterimInterest(string Account, string InterestOption)
        {
            this.LoadAccountSummaryPage(Account);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Calculation Options"));
            if (WebCSRPageFactory.LoanInterestTab.VerifyDetailsInInterestCalcualtionOption(InterestOption))
            {
                Report.Pass("Interest Calculation Option is Verified in Calculation Options Page", "CalculationOptions", "true", appHandle);
            }
            else
            {
                Report.Fail("Interest Calculation Option is  not Verified in Calculation Options Page", "CalculationOptionsfails", "true", appHandle, true);
            }


        }
        public virtual void VerifyBilledInterestInBillingStatementPage(string Account, string Date, string sLabelNameLabelValuePipeDelimited)
        {
            this.LoadAccountSummaryPage(Account);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Payment"), Data.Get("Billing Statement"));
            WebCSRPageFactory.BillingStatementPage.ClickOnBillinDateLink(Date);
            if (WebCSRPageFactory.BillingStatementDetailPage.VerifyBillInterestDataInTableByColumnValues(sLabelNameLabelValuePipeDelimited))
            {
                Report.Pass(sLabelNameLabelValuePipeDelimited + "is Verify in Billing Statement Detail table", "BillingStatementDetail", "true", appHandle);
            }
            else
            {
                Report.Fail(sLabelNameLabelValuePipeDelimited + "is not Verify in Billing Statement Detail table", "BillingStatementDetailfail", "true", appHandle, true);
            }

        }
        public virtual void AddCardMemberInformation(string AccountNumber, string CardNumber, string MemberStatus, string Members, string OrderDate, string IssueDate)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Member Information"));
            WebCSRPageFactory.CardManagementPage.EnterMemberInformation(AccountNumber, CardNumber, MemberStatus, Members, OrderDate, IssueDate);
            WebCSRPageFactory.CardManagementPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CardManagementPage.VerifyMessageInCardManagementPage(Data.Get("GLOBAL_CARDMEMBER_ADD")))
            {
                Report.Pass("New card member is successfully added.", "AddCardMemberPass", "true", appHandle);
            }
            else
            {
                Report.Fail("Add new card member is failed", "AddCardMemberFail", "true", appHandle, true);
            }
        }
        public virtual void AddCardNotes(string AccountNumber, string CardNumber, string Description, string ExpDate, string Note)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Card Notes"));
            WebCSRPageFactory.CardManagementPage.EnterCardNotes(AccountNumber, CardNumber, Description, ExpDate, Note);
            WebCSRPageFactory.CardManagementPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CardManagementPage.VerifyMessageInCardManagementPage(Data.Get("GLOBAL_CARDNOTES_ADD")))
            {
                Report.Pass("Card Notes is successfully added.", "AddCardNotePass", "true", appHandle);
            }
            else
            {
                Report.Fail("Failed to add Card Notes", "AddCardNoteFail", "true", appHandle, true);
            }
        }
        public virtual void VerifyCardStatusInCardManageMentPage(string AccountNumber, string UniqueOrderRefValue, string Status)
        {
            GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            WebCSRPageFactory.CardManagementPage.selectAccountFromDropDown(AccountNumber);
            WebCSRPageFactory.CardManagementPage.SelectCardInCardList(UniqueOrderRefValue);
            WebCSRPageFactory.CardManagementPage.ClickOnEditButton();
            if (WebCSRPageFactory.CardManagementPage.VerifyCardStatus(Status))
            {
                Report.Pass("Card Status was verified successfully in Card Management Page", "CardManagement", "true", appHandle);

            }
            else
            {
                Report.Fail("Card Status was not Verified Successfully in Card Management Page", "CardManagementfail", "true", appHandle, true);

            }
        }
        public virtual void VerifyCardisGeneratedAutomaticallyInCardManagement(string Account, string UniqueOrderRefValue)
        {
            GetAccount(Account);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            WebCSRPageFactory.CardManagementPage.selectAccountFromDropDown(Account);
            WebCSRPageFactory.CardManagementPage.SelectCardInCardList(UniqueOrderRefValue);
            Report.Pass("Card generated is Verfied in Card Management Page", "CardManagement", "true", appHandle);

        }
        public virtual void VerifyContributionFieldsDisplayedInRetirementTransactionCorrectionsPage(string AccountNumber, string TransactionSEQ)
        {
            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.CheckRetirementTransactionCorrectionPageLoaded())
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyAccountNumberInAccountsDropdown(AccountNumber))
                {
                    if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyTransactionSequenceInHistorySequenceDropdown(TransactionSEQ))
                    { }
                    else
                    {
                        WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                    }
                }
            }
            else
            {

                get_account(AccountNumber);
                WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Retirement Services") + "|" + Data.Get("Transaction Corrections"));
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.WaitRetirementTransactionCorrectionPageLoads())
                {
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectAccountNumber(AccountNumber);
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                }
            }


            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyContributionFieldsExitInRetirementTransactionPage())
            {
                Report.Pass("Contribution Transactions details : Reason Code , Amount , Military Zone Code , Military Year Of Service , Contribution for Year are displayed in Retirement Transaction Corrections page.", "contricode", "True", appHandle);
            }
            else
            {
                Report.Fail("Contribution Transactions details : Reason Code , Amount , Military Zone Code , Military Year Of Service , Contribution for Year are not displayed in Retirement Transaction Corrections page.", "contricode", "True", appHandle);
            }

        }
        public virtual bool SelectReasonCodeInRetireTransactionCorrectionPage(string AccountNumber, string TransactionSEQ, string ReasonCode)
        {
            bool Result = false;
            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.CheckRetirementTransactionCorrectionPageLoaded())
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyAccountNumberInAccountsDropdown(AccountNumber))
                {
                    if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyTransactionSequenceInHistorySequenceDropdown(TransactionSEQ))
                    { }
                    else
                    {
                        WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                    }
                }
            }
            else
            {
                get_account(AccountNumber);
                WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Retirement Services") + "|" + Data.Get("Transaction Corrections"));
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.WaitRetirementTransactionCorrectionPageLoads())
                {
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectAccountNumber(AccountNumber);
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                }
            }

            Result = WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectReasonCode(ReasonCode);
            return Result;


        }
        public virtual void VerifyMilitaryCombactZoneFromUTBLMCZCInRetireTransactionCorrectionPage(string AccountNumber, string TransactionSEQ, string MILITARYZONECODE, string MILITARYZONEDESC)
        {

            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.CheckRetirementTransactionCorrectionPageLoaded())
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyAccountNumberInAccountsDropdown(AccountNumber))
                {
                    if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyTransactionSequenceInHistorySequenceDropdown(TransactionSEQ))
                    { }
                    else
                    {
                        WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                    }
                }
            }
            else
            {
                get_account(AccountNumber);
                WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Retirement Services") + "|" + Data.Get("Transaction Corrections"));
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.WaitRetirementTransactionCorrectionPageLoads())
                {
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectAccountNumber(AccountNumber);
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                }
            }

            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectReasonCode(Data.Get("117 - Military Contribution")))
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyMilitaryZoneCodeDropdownEnabled())
                {
                    Report.Pass("Military Zone Code is enabled when Reason code is selected as " + Data.Get("117 - Military Contribution"), "miltenable", "True", appHandle);
                }
                else
                {
                    Report.Fail("Military Zone Code is not enabled when Reason code is  selected as " + Data.Get("117 - Military Contribution"), "miltenable", "True", appHandle);
                }
            }


            int n = 0;
            if (MILITARYZONECODE.Contains("|"))
            {
                n = MILITARYZONECODE.Split('|').Length;

                for (int a = 0; a <= n - 1; a++)
                {
                    if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyMilitaryZoneCode(MILITARYZONECODE.Split('|')[a] + " - " + MILITARYZONEDESC.Split('|')[a]))
                    {
                        Report.Pass(MILITARYZONECODE.Split('|')[a] + " - " + MILITARYZONEDESC.Split('|')[a] + " is available in Military ZOne Code dropdown", "milt", "True", appHandle);
                    }
                    else
                    {
                        Report.Fail(MILITARYZONECODE.Split('|')[a] + " - " + MILITARYZONEDESC.Split('|')[a] + " is not available in Military ZOne Code dropdown", "milt", "True", appHandle);
                    }

                }
            }
            else
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyMilitaryZoneCode(MILITARYZONECODE + " - " + MILITARYZONEDESC))
                {
                    Report.Pass(MILITARYZONECODE + " - " + MILITARYZONEDESC + " is available in Military ZOne Code dropdown", "milt", "True", appHandle);
                }
                else
                {
                    Report.Fail(MILITARYZONECODE + " - " + MILITARYZONEDESC + " is not available in Military ZOne Code dropdown", "miltfail", "True", appHandle);
                }
            }

        }
        public virtual void VerifyContributionForYearEnabledForReasonCode120(string AccountNumber, string TransactionSEQ)
        {
            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.CheckRetirementTransactionCorrectionPageLoaded())
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyAccountNumberInAccountsDropdown(AccountNumber))
                {
                    if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyTransactionSequenceInHistorySequenceDropdown(TransactionSEQ))
                    { }
                    else
                    {
                        WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                    }
                }
            }
            else
            {
                get_account(AccountNumber);
                WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Retirement Services") + "|" + Data.Get("Transaction Corrections"));
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.WaitRetirementTransactionCorrectionPageLoads())
                {
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectAccountNumber(AccountNumber);
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                }
            }


            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectReasonCode(Data.Get("120 - Postponed Contribution")))
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyContributionYearFieldEnabled())
                {
                    Report.Pass("Contribution Code field is enabled when Reason code is selected as " + Data.Get("120 - Postponed Contribution"), "ContributionCodeEnable", "True", appHandle);
                }
                else
                {
                    Report.Fail("Contribution Code field is not enabled when Reason code is  selected as " + Data.Get("120 - Postponed Contribution"), "ContributionCodeEnableFail", "True", appHandle);
                }
            }
        }
        public virtual void VerifyDefaultStartDateOfHoldAsSystemDate(string AccountNumber)
        {
            get_account(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Holds"));
            WebCSRPageFactory.HoldsPage.SelectAccountFromDropdown(AccountNumber);
            WebCSRPageFactory.HoldsPage.ClickOnAddButton();
            if (WebCSRPageFactory.HoldsPage.VerifyDefaultHoldStartDateAsSystemDate())
            {
                Report.Pass("Default Start Date of Hold is found as system date.", "defaultdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Default Start Date of Hold is not found as system date.", "defaultdatefail", "True", appHandle);
            }

        }
        public virtual void CheckHoldAmtMoreThanAvailableBalAmount(string AccountNumber)
        {
            if (!WebCSRPageFactory.AccountOverviewPage.CheckAccountNumberInAccountOverviewPage(AccountNumber))
            {
                GetAccount(AccountNumber);
            }

            string avbl = WebCSRPageFactory.AccountOverviewPage.GetAvailableBal(AccountNumber);
            string holdamt = WebCSRPageFactory.AccountOverviewPage.GetHoldAmt(AccountNumber);
            if (WebCSRPageFactory.AccountOverviewPage.CheckHoldAmtMoreThanAvailableBalAmount(AccountNumber))
            {
                Report.Pass("Available balance is captured as : " + avbl + " and Holds amount is captured as " + holdamt + " . Hold amount is more than available amount.", "valcomp", "True", appHandle);
            }
            else
            {
                Report.Fail("Available balance is captured as : " + avbl + " and Holds amount is captured as " + holdamt + " . Hold amount is less than available amount.", "valcompfail", "True", appHandle);
            }
        }
        public virtual void DeleteHoldForSpecifiedAccountnumber(string AccountNumber, string HoldType, string AmountToBeSelectedInHoldsTable = "", string ExpirationDate = "")
        {
            WebCSRPageFactory.HoldsPage.DeleteHoldForSpecifiedAccountnumber(AccountNumber, HoldType, AmountToBeSelectedInHoldsTable, ExpirationDate);
            if (WebCSRPageFactory.HoldsPage.VerifyMSGInHoldsPage(Data.Get("The hold has been deleted."))
            && VerifyNoHoldsOnTheAccount(AccountNumber))
            {
                Report.Pass("Hold Type : " + HoldType + " of Amount : " + AmountToBeSelectedInHoldsTable + " is deleted from Holds Table.", "deleteholds", "True", appHandle);
            }
            else
            {
                Report.Fail("Hold Type : " + HoldType + " of Amount : " + AmountToBeSelectedInHoldsTable + " is not deleted from Holds Table.", "deleteholdsFail", "True", appHandle);
            }
        }
        public virtual string GetCustomerHomeAddressStreetNameFromAddressTabCustomerInformation(string CustomerNo)
        {
            if (Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"))
             && Profile7CommonLibrary.CheckTextAvailableInPage(Data.Get("TableCIF") + "#: " + CustomerNo)) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNo, Data.Get("Customer Number"));
                this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Address"));
            string StreetName = WebCSRPageFactory.AddressPage.GetStreetName();
            return StreetName;
        }
        public virtual void UpdateRetirementServicesPlanDistributionPageDetails(string RetirementPlan, string FederalWithholdingPer, string StateID)
        {
            this.ClickLinkFromMenuItem(Data.Get("Retirement Services") + "|" + Data.Get("Plan Information"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Plan Distributions"));
            WebCSRPageFactory.RetairementServicesPage.SelectRetirementPlanDropdown(RetirementPlan);
            WebCSRPageFactory.RetairementServicesPage.UpdateWitholdingOptionsDetails(FederalWithholdingPer, StateID);
            WebCSRPageFactory.RetairementServicesPage.SelectSubmitButton();
            if (WebCSRPageFactory.RetairementServicesPage.VerifyMessageAccountInformationResidencyPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Retirement Service plan has been updated ", "RetirementServiceplanStatusPass", "true", appHandle);
            }
            else
            {
                Report.Fail("The Retirement Service plan has not been updated", "RetirementServicePlanStatusFail", "true", appHandle, true);
            }

        }
        public virtual void AddStopsForSpecifiedAccountNumber(string AccountNumber, string StopType, string stopaction, string stopreason, string ExpirationDate = "", string Amount = "", bool Override = false, string sUSerID = "", string sPassword = "", string OverrideTranMsgs = "", string DebitCreditIndicator = "", string CompanyNumber = "")
        {
            this.LoadAccountSummaryPage(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Stops"));
            WebCSRPageFactory.StopsPage.AddStopsForSpecifiedAccountNumber(AccountNumber, StopType, stopaction, stopreason, ExpirationDate, Amount, CompanyNumber, DebitCreditIndicator);
            WebCSRPageFactory.StopsPage.ClickOnSubmitButton();
            if (Override)
            {
                if (!string.IsNullOrEmpty(OverrideTranMsgs))
                {
                    this.VerifyAuthorizationMessage(OverrideTranMsgs);
                }
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.EnterUserCredentials(sUSerID, sPassword);
                Report.Info("User credentials are entered for Authorization override.", "userEntry", "true", appHandle);
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.ClickOnOverrideButton();
                WebCSRPageFactory.FundTransferPage.ClickOnSubmitButton_OverrideTransaction();
            }
            if (WebCSRPageFactory.HoldsPage.VerifyMSGInHoldsPage(Data.Get("The stop has been placed.")))
            {

                Report.Pass(Data.Get("The stop has been placed.") + " is successfully verified.", "verifyholdmsg", "true", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("The stop has been placed.") + " is not successfully verified.", "verifyholdmsgfail", "true", appHandle, true);
            }
        }

        public virtual void AddRecordInTransactionDetailsTableInRetirementTransactionCorrectionsPage(string AccountNumber, string TransactionSEQ, string ColumnNameColumnValuePipeDelimited, string RowNumber, bool isJointCIF = false)
        {
            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.CheckRetirementTransactionCorrectionPageLoaded())
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyAccountNumberInAccountsDropdown(AccountNumber))
                {
                    if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyTransactionSequenceInHistorySequenceDropdown(TransactionSEQ))
                    { }
                    else
                    {
                        WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                    }
                }
            }
            else
            {
                get_account(AccountNumber, isJointCIF);
                WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Retirement Services") + "|" + Data.Get("Transaction Corrections"));
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.WaitRetirementTransactionCorrectionPageLoads())
                {
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectAccountNumber(AccountNumber);
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                }
            }

            WebCSRPageFactory.RetirementTransactionCorrectionsPage.ClickOnAddButton();
            WebCSRPageFactory.RetirementTransactionCorrectionsPage.EnterDataInTransactionDetailsTableByRowNumber(ColumnNameColumnValuePipeDelimited, RowNumber);
            Report.Pass("Data entered in Transaction Correction page successfully.", "trndetail", "True", appHandle);
        }
        public virtual void UpdateRecordInTransactionDetailsTableInRetirementTransactionCorrectionsPage(string AccountNumber, string TransactionSEQ, string ColumnNameColumnValuePipeDelimited, string RowNumber, bool isJointCIF = false)
        {
            get_account(AccountNumber, isJointCIF);
            WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Retirement Services") + "|" + Data.Get("Transaction Corrections"));
            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.WaitRetirementTransactionCorrectionPageLoads())
            {
                WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectAccountNumber(AccountNumber);
                WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
            }

            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.EnterDataInTransactionDetailsTableByRowNumber(ColumnNameColumnValuePipeDelimited, RowNumber))
            {
                Report.Pass("Details are entered in transaction details table in Retirement transactions correction page.", "trndetail", "True", appHandle);
            }
            else
            {
                Report.Fail("Details are not entered in transaction details table in Retirement transactions correction page.", "trndetail", "True", appHandle);
            }

        }

        public virtual void DeleteRecordsOfTransactionTableEnabledInRetirementTransactionCorrectionsPageByRowNumber(string AccountNumber, string TransactionSEQ, string ColumnNameColumnValuePipeDelimited, string RowNumbersTobeDeletedPipeDelimited)
        {
            int initalrowcount = WebCSRPageFactory.RetirementTransactionCorrectionsPage.GetNumberOfRowsInTransactionDetailsTable();
            RowNumbersTobeDeletedPipeDelimited = RowNumbersTobeDeletedPipeDelimited + "|";
            string[] arr = RowNumbersTobeDeletedPipeDelimited.Split('|');
            string msg = "";
            for (int a = 0; a < arr.Length - 1; a++)
            {
                msg = msg + " , " + arr[a];
                UpdateRecordInTransactionDetailsTableInRetirementTransactionCorrectionsPage(AccountNumber, TransactionSEQ, "Delete|ON", arr[a]);
            }
            msg = msg.Substring(2, msg.Length - 2).Trim();
            WebCSRPageFactory.RetirementTransactionCorrectionsPage.ClickOnSubmitButton();
            VerifyInformationUpdatedMessage();
            int rowcountPostDelete = WebCSRPageFactory.RetirementTransactionCorrectionsPage.GetNumberOfRowsInTransactionDetailsTable();
            if (initalrowcount > rowcountPostDelete)
            {
                Report.Pass("Records in row " + msg + " are deleted as respective Delete checkboxes are selected and Submit button in clicked.", "deleterecords", "True", appHandle);
            }
            else
            {
                Report.Fail("Records in row " + msg + " are not deleted as respective Delete checkboxes are selected and Submit button in clicked.", "deleterecordsfail", "True", appHandle);
            }

        }

        public virtual void SelectRecordInRetirementTransactionCorrectionsPageByRowNumber(string AccountNumber, string TransactionSEQ, string ColumnNameColumnValuePipeDelimited, string RowNumbersTobeDeletedPipeDelimited)
        {
            int initalrowcount = WebCSRPageFactory.RetirementTransactionCorrectionsPage.GetNumberOfRowsInTransactionDetailsTable();
            RowNumbersTobeDeletedPipeDelimited = RowNumbersTobeDeletedPipeDelimited + "|";
            string[] arr = RowNumbersTobeDeletedPipeDelimited.Split('|');
            string msg = "";
            for (int a = 0; a < arr.Length - 1; a++)
            {
                msg = msg + " , " + arr[a];
                UpdateRecordInTransactionDetailsTableInRetirementTransactionCorrectionsPage(AccountNumber, TransactionSEQ, "Delete|ON", arr[a]);
            }
            msg = msg.Substring(2, msg.Length - 2).Trim();
        }
        public virtual void VerifyCellsOfTransactionTableEnabledInRetirementTransactionCorrectionsPage(string ReasonCode, string ColumnNamesToBeVerifiedPipeDelimited, string RowNumber)
        {
            string msg = "";
            ColumnNamesToBeVerifiedPipeDelimited = ColumnNamesToBeVerifiedPipeDelimited + "|";
            string[] arr = ColumnNamesToBeVerifiedPipeDelimited.Split('|');
            for (int a = 0; a < arr.Length - 1; a++)
            {
                msg = msg + " , " + arr[a] + " cells are  enabled for the specified Reason code " + ReasonCode + " in the Row number " + RowNumber;
            }
            msg = msg.Substring(2, msg.Length - 2).Trim();
            string failmsg = msg.Replace("are", "are not");
            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyCellsOfTransactionTableEnabledSpecifiedReasonCodeByRowNumber(ReasonCode, ColumnNamesToBeVerifiedPipeDelimited, RowNumber))
            {
                Report.Pass(msg, "cellvalisationenabled", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "cellvalisationenabled", "True", appHandle);
            }
        }
        public virtual void VerifyCellsOfTransactionTableDisabledInRetirementTransactionCorrectionsPage(string ReasonCode, string ColumnNamesToBeVerifiedPipeDelimited, string RowNumber)
        {
            string msg = "";
            ColumnNamesToBeVerifiedPipeDelimited = ColumnNamesToBeVerifiedPipeDelimited + "|";
            string[] arr = ColumnNamesToBeVerifiedPipeDelimited.Split('|');
            for (int a = 0; a < arr.Length - 1; a++)
            {
                msg = msg + " , " + arr[a] + " cells are  disabled for the specified Reason code " + ReasonCode + " in the Row number " + RowNumber;
            }
            msg = msg.Substring(2, msg.Length - 2).Trim();

            string failmsg = msg.Replace("are", "are not");
            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyCellsOfTransactionTableEnabledSpecifiedReasonCodeByRowNumber(ReasonCode, ColumnNamesToBeVerifiedPipeDelimited, RowNumber) == false)
            {
                Report.Pass(msg, "cellvalisationdisabled", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "cellvalisationdisabled", "True", appHandle);
            }

        }
        public virtual void VerifyDistributionFieldsDisplayedInRetirementTransactionCorrectionsPage(string AccountNumber, string TransactionSEQ)
        {
            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.CheckRetirementTransactionCorrectionPageLoaded())
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyAccountNumberInAccountsDropdown(AccountNumber))
                {
                    if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyTransactionSequenceInHistorySequenceDropdown(TransactionSEQ))
                    { }
                    else
                    {
                        WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                    }
                }
            }
            else
            {
                get_account(AccountNumber);
                WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Retirement Services") + "|" + Data.Get("Transaction Corrections"));
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.WaitRetirementTransactionCorrectionPageLoads())
                {
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectAccountNumber(AccountNumber);
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                }
            }

            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyDistributionFieldsExitInRetirementTransactionPage())
            {
                Report.Pass("Distribution Transactions details : Reason Code , Amount , Federal Withholding , State Withholding  are displayed in Retirement Transaction Corrections page.", "contricode", "True", appHandle);
            }
            else
            {
                Report.Fail("Distribution Transactions details : Reason Code , Amount , Federal Withholding , State Withholding  are not displayed in Retirement Transaction Corrections page.", "contricode", "True", appHandle);
            }
        }

        public virtual void VerifyTotalAmountInTransactionDetailTable(string AccountNumber, string TransactionSEQ, string ExpectedTotalAmt)
        {
            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.CheckRetirementTransactionCorrectionPageLoaded())
            {
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyAccountNumberInAccountsDropdown(AccountNumber))
                {
                    if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyTransactionSequenceInHistorySequenceDropdown(TransactionSEQ))
                    { }
                    else
                    {
                        WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                    }
                }
            }
            else
            {
                get_account(AccountNumber);
                WebCSRPageFactory.AccountInformationPage.ClickOnMenuAndSubMenu(Data.Get("Retirement Services") + "|" + Data.Get("Transaction Corrections"));
                if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.WaitRetirementTransactionCorrectionPageLoads())
                {
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectAccountNumber(AccountNumber);
                    WebCSRPageFactory.RetirementTransactionCorrectionsPage.SelectHistorySequence(TransactionSEQ);
                }
            }


            if (WebCSRPageFactory.RetirementTransactionCorrectionsPage.VerifyTotalAmountInTransactionDetailTable(ExpectedTotalAmt))
            {
                Report.Pass("The total amount is successfully verified as : " + ExpectedTotalAmt + " for the account number : " + AccountNumber + " and Transaction Sequence : " + TransactionSEQ, "totamtretcorr", "True", appHandle);
            }
            else
            {
                Report.Fail("The total amount is successfully verified as : " + ExpectedTotalAmt + " for the account number : " + AccountNumber + " and Transaction Sequence :" + TransactionSEQ, "totamtretcorr", "True", appHandle);
            }
        }
        public virtual void ClickOnSubmitButtonInRetirementTransactionCorrectionPage()
        {
            WebCSRPageFactory.RetirementTransactionCorrectionsPage.ClickOnSubmitButton();
            VerifyInformationUpdatedMessage();
        }


        public virtual void UpdateCustomerMaritalStatus(string maritalstatus)
        {
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown("Customer Information");
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            WebCSRPageFactory.CustomerInformationPage.UpdateMaritalStatus(maritalstatus);
            WebCSRPageFactory.CustomerInformationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.CheckSuccessMessage())
            {
                Report.Pass("The Marital Status has been updated for customer", "mrt", "True", appHandle);
            }
            else
            {
                Report.Fail("The Marital Status has not been updated for customer", "mrt", "True", appHandle);
            }
        }


        public virtual void AddBeneficiaryToTrustCustomer(string custnumber, string classificationtype, bool invalidforFDICinsurance, bool NonContingent, string percenatgeval)
        {
            GetCustomer(custnumber);
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown("Customer Information");
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CreateTrustCustomerPage.AddBeneficiaryToTrustCustomer(classificationtype, invalidforFDICinsurance, NonContingent, percenatgeval))
            {
                Report.Pass("Beneficiary has been added to Trust customer " + custnumber, "benadd", "True", appHandle);
            }
            else
            {
                Report.Fail("Beneficiary has not been added to Trust customer " + custnumber, "benadd", "True", appHandle);
            }

        }


        public virtual string Create_trust_account(string custnum, string reltionship, string trustprodtype, string openingdeposit, string openingdate = "")
        {
            string trustaccnum = "";
            GetCustomer(custnum);
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown("Customer Information");
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            ClickonLink(Data.Get("LinkCreateTrustAccount"));
            trustaccnum = WebCSRPageFactory.CreateTrustAccountPage.create_trust_account(reltionship, trustprodtype, openingdeposit, openingdate);
            if (!string.IsNullOrEmpty(trustaccnum))
            {
                Report.Pass("Trust account is created successfully for customer " + custnum, "acctru", "True", appHandle);
            }
            else
            {
                Report.Fail("Trust account creation is failed for customer " + custnum, "acctru", "True", appHandle);
            }
            return trustaccnum;
        }



        public virtual void UpdateCalculationOptionsInLoanInterestCalculationOptionsPage(string AccountNumber, string MinBalanceToAccrue = "", String InterestCalculationPeriodFrequency = "")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Calculation Options"));
            WebCSRPageFactory.LoanCalculationOptionsPage.EnterCalculationOptions(MinBalanceToAccrue, InterestCalculationPeriodFrequency);
            WebCSRPageFactory.LoanCalculationOptionsPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.LoanCalculationOptionsPage.VerifyMessageInLoanCalculationOptionPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Calculation options are updated in Loan Calculation Options page under Account Information | Interest | Calculation Options .", "calculationoptionsupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Calculation options are not updated in Loan Calculation Options page under Account Information | Interest | Calculation Options .", "interestrateupdate", "True", appHandle, true);
            }
        }

        public virtual void VerifyAnnualDisclosureRateSpecifiedAccount(string AccountNumber, string CalcAPRY)
        {
            bool APRY;
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Rate Determination"));
            APRY = WebCSRPageFactory.LoanRateDeterminationPage.VerifyAnnualDisclosurate(CalcAPRY);
            if (APRY)
            {
                Report.Pass("Annual Disclosure Rate is calculated correctly.", "VerifyAPRY", "True", appHandle);
            }
            else
            {
                Report.Fail("Annual Disclosure Rate is not calculated correctly.", "VerifyAPRY", "True", appHandle, true);
            }

        }
        public virtual void VerifyAnnualYieldSpecifiedAccount(string AccountNumber, string AnnualYield)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Rate Determination"));
            bool AY1 = WebCSRPageFactory.DepositRateDeterminationPage.VerifyAnnualYield(AnnualYield);

            if (AY1)
            {
                Report.Pass("Annual Yield is calculated correctly.", "VerifyAPRY", "True", appHandle);
            }
            else
            {
                Report.Fail("Annual Yield is not calculated correctly.", "VerifyAPRY", "True", appHandle, true);
            }

        }
        public virtual void EnterAccountInformationMaturityPageOption(string AccountNumber, string sTerm = "", string prinMaturityOption = "")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Term Accounts"));
            WebCSRPageFactory.MaturityPage.EnterMaturityOptions(sTerm, prinMaturityOption);
            WebCSRPageFactory.MaturityPage.ClickonSubmitbutton();
            if (WebCSRPageFactory.MaturityPage.VerifyMessageInMaturityPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Maturity and Renewal Information is updated in Deposit Maturity page under Account Information | Maturity.", "termupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("Maturity and Renewal Information is not updated in Deposit Maturity page under Account Information | Maturity.", "termupdatefail", "True", appHandle, true);
            }
        }
        public virtual string CreateEducationRetirementPlanAccount(string ResponsibleIndCustomerNumber, string dob, string ChildorBeneficiaryCustomer, string plandate, string retaccountnumber, string contamount, string conttype)
        {
            string temptitle = appHandle.GetTitle();

            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), ResponsibleIndCustomerNumber);
            }
            else if (temptitle.Contains(Data.Get("Verify Customer"))) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), ResponsibleIndCustomerNumber);
            }
            if (WebCSRPageFactory.CreateAccountPage.VerifyCustomerNumberForAcctCreation(ResponsibleIndCustomerNumber) == false)
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), ResponsibleIndCustomerNumber);
            }
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown(Data.Get("GLOBAL_CREATE_RETIREMENT_ACCOUNT_ITEM"));
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateRetirementAccountPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateRetirementPlanPage.SelectRetirementPlanBasedOnPlanValue(Data.Get("Educational IRA Plan"));
            WebCSRPageFactory.CreateRetirementPlanPage.ClickOnContinue();
            WebCSRPageFactory.CreateRetirementPlanPage.ClickOnContinue();
            WebCSRPageFactory.CreateRetirementPlanPage.EnterDetailsForPlan(plandate, dob);
            WebCSRPageFactory.CreateRetirementPlanPage.ClickOnContinue();
            WebCSRPageFactory.CreateRetirementPlanPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateRetirementAccountPage.SelectRetirementAccount(retaccountnumber);
            WebCSRPageFactory.CreateRetirementAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateRetirementAccountPage.EnterRetireAccountDetails(contamount, conttype);
            WebCSRPageFactory.CreateRetirementAccountPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateRetirementAccountPage.CheckAccountSuccessMsg(Data.Get("GLOBAL_CONFIRMATION_MESSAGE"));
            string retaccount = WebCSRPageFactory.CreateRetirementAccountPage.GetRetirementAccount();
            if (!String.IsNullOrEmpty(retaccount))
            {
                Report.Pass("The Retirement Plan Account is created successfully " + retaccount, "retaccntpass", "True", appHandle);
            }
            else
            {
                Report.Fail("The Retirement Plan Account is created successfully " + retaccount, "retaccntFail", "True", appHandle);
            }

            return retaccount;

        }

        public virtual void EnterDetailsForServiceFeePage(string feeplan, string feefrequency, string feeoption, string atmposval)
        {
            if (WebCSRPageFactory.DepositProductServiceFeesPage.EnterDetailsForServiceFeePage(feeplan, feefrequency, feeoption, atmposval))
            {
                Report.Pass("Service Fee page data entered", "rg", "True", appHandle);
            }
            else
            {
                Report.Fail("Service Fee page data not entered", "rg", "True", appHandle);
            }

        }

        public virtual void EnterDataForRegDDAndRCEReportingCategory(string Acc, bool regddval, string RCEreportingval)
        {
            GetAccount(Acc);
            NavigateToAccountSummaryPage();
            Application.WebAdmin.ClickonTabinProductPage("U.S. Regulatory");
            if (WebCSRPageFactory.USRegulatoryPage.EnterDataForRegDDAndRCEReportingCategory(regddval, RCEreportingval))
            {
                Report.Pass("Data Entered for RegDD checkbox and RCE dropdown reporting", "regcc", "True", appHandle);
            }
            else
            {
                Report.Fail("Data not Entered for RegDD checkbox and RCE dropdown reporting", "regcc", "True", appHandle);
            }
        }

        public virtual void UpdateDOB(string dobval)
        {
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown("Customer Information");
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.UpdateDOB(dobval))
            {
                Report.Pass("the DOB value is updated", "dobn", "True", appHandle);
            }
            else
            {
                Report.Fail("the DOB value is not updated", "dobn", "True", appHandle);
            }
        }
        public virtual string CalculateWithholdingAmount(string AccruedInterest, string WithHoldingTaxInterest)
        {
            string WithholdingAmt = "";
            double WithholdAmount = 0;
            WithholdAmount = (Convert.ToDouble(WithHoldingTaxInterest) / 100) * Convert.ToDouble(AccruedInterest);
            double Amt = Math.Round(WithholdAmount, 2);
            return WithholdingAmt = Amt.ToString();
        }
        public virtual void UpdateTermAccountsMaturityDetailsForInteralAcc(string AccountNumber, string PrincipalMaturityOption, string InternalPrincipalTransferAccount, string InterestMaturityOption, string InterestTransferAccount)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Term Accounts"), Data.Get("Maturity"));
            WebCSRPageFactory.MaturityPage.MaturityOptionforInternalAcc(PrincipalMaturityOption, InternalPrincipalTransferAccount, InterestMaturityOption, InterestTransferAccount);
            WebCSRPageFactory.MaturityPage.ClickOnSubmit();
            if (WebCSRPageFactory.MaturityPage.VerifySuccessMessage())
            {
                Report.Pass("Term Account Maturity Details updated successfully", "UpdateTermAccountsMaturityDetails", "true", appHandle);
            }
            else
            {
                Report.Fail("Failed to Update Term Account Maturity Details", "UpdateTermAccountsMaturityDetails", "true", appHandle, true);
            }
        }
        public virtual void UpdateSubjecttoWitholdingForCorporateInFATCAPage(string CustomerNo, bool CheckBoXOnorOff, string chapter4104sStatus)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNo, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("FATCA"));
            WebCSRPageFactory.CustomerInformationResidencyPage.UpdateSubjecttoWithholdingForCorporate(CheckBoXOnorOff, chapter4104sStatus);
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationResidencyPage.ValidateCustomerInfoUpdateMSG())
            {
                Report.Pass("The Withholding details was updated in FATCA Page", "FATCAPage", "true", appHandle);
            }
            else
            {
                Report.Fail("The Withholding details was not update in FATCA Page", "FATCAPagefails", "true", appHandle, true);

            }

        }
        public virtual void UpdateFACTADetailsInFATCAPageForCorporate(string CustomerNumber, string W8BeneStatus, string FATCAExcemptionCode, string GIIN, string ClaimDate, string CollectionDate, string VerificationDate)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNumber, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("FATCA"));
            WebCSRPageFactory.CustomerInformationResidencyPage.UpdateFATCADetailsForCorporate(W8BeneStatus, FATCAExcemptionCode, GIIN, ClaimDate, CollectionDate, VerificationDate);
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationResidencyPage.VerifyMessageAccountInformationResidencyPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION_UPDATED")))
            {
                Report.Pass("The Residency FATCA Page Details are Updated successfully", "ResidencyFATCA", "true", appHandle);
            }
            else
            {
                Report.Fail("The Residency FATCA Page Details are not Updated successfully", "ResidencyFATCAfail", "true", appHandle, true);
            }

        }
        public virtual void UpdateAppiledForGIINForCorporateInFATCAPage(string CustomerNo, bool CheckBoXOnorOff)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(CustomerNo, Data.Get("Customer Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Residency"), Data.Get("FATCA"));
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnAppliedForGIINCheckBox(CheckBoXOnorOff);
            WebCSRPageFactory.CustomerInformationResidencyPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationResidencyPage.ValidateCustomerInfoUpdateMSG())
            {
                Report.Pass("The Appiled For GIIN is selected in FATCA Page", "FATCAPage", "true", appHandle);
            }
            else
            {
                Report.Fail("The Appiled For GIIN is  not selected in FATCA Page", "FATCAPagefails", "true", appHandle, true);

            }

        }
        public virtual void UpdateAccountRelationshiptoJoint(string AccountNumber, string Relationship, string NoofCust, string PrimaryCustomerno, string SecondaryCustomer1no, string SecondaryCust2No, string PrimaryOwnerPer, string SecondaryOwnerPer, string PrimaryOwnerStartDate)
        {

            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Relationships"));
            WebCSRPageFactory.AccontServicesRelationshipsPage.SelectAccountFromAccountsDropdown(AccountNumber);
            WebCSRPageFactory.AccontServicesRelationshipsPage.EditAccountRelationshiptojoint(Relationship, NoofCust, PrimaryCustomerno, SecondaryCustomer1no, SecondaryCust2No, PrimaryOwnerPer, SecondaryOwnerPer, PrimaryOwnerStartDate);
            WebCSRPageFactory.AccontServicesRelationshipsPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.AccontServicesRelationshipsPage.VerifyMessageAccontServicesRelationshipsPage(Data.Get("The account relationship has been updated.")))
            {
                Report.Pass("Account Relationship is update to joint in Edit Account Relationship page updated Successfully.", "AccountRelationStatusPass", "true", appHandle);
            }
            else
            {
                Report.Fail("Account Relationship page is not updated.", "AccountRelationStatusFail", "true", appHandle, true);
            }

        }
        public virtual void AddCourtesyOverdraftServiceForAccount(string AccountNumber)
        {
            LoadAccountSummaryPage(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Service Management"));
            WebCSRPageFactory.CustomerServicesServiceManagementPage.ClickOnAddButtonForCourtesyOverdraft(AccountNumber);
            WebCSRPageFactory.CustomerServicesServiceManagementPage.ClickonTermsandConditionCheckbox(AccountNumber);
            WebCSRPageFactory.CustomerServicesServiceManagementPage.ClickOnRefreshListButton();
            if (WebCSRPageFactory.CustomerServicesServiceManagementPage.VerifyListRefreshSuccess())
            {
                Report.Info("Courtesy Overdraft Service is added for the account : " + AccountNumber, "servicelistadd", "true", appHandle);
            }
            else
            {
                Report.Fail("Courtesy Overdraft Service is not added for the account : " + AccountNumber, "servicelistadd", "true", appHandle, true);
            }
        }
        public virtual void UpdateServiceFeePlanandOptionInDepositAccountFeePage(string Account, string FeePlan, string Feeoption, string FeeFrequency = "")
        {
            if (!appHandle.GetTitle().Contains("Withholding"))
            {
                LoadAccountSummaryPage(Account);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Fees"));
            }
            WebCSRPageFactory.DepositAccountFeePage.UpdateFeePlan(FeePlan);
            WebCSRPageFactory.DepositAccountFeePage.UpdateServiceFeeOption(Feeoption, FeeFrequency);
            WebCSRPageFactory.DepositAccountFeePage.ClickOnSubmit();
            if (WebCSRPageFactory.DepositAccountFeePage.VerifyMessageDepositFeePage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Fee Plan was Updated successfully In Deposit Fee Page", "FeePage", "true", appHandle);

            }
            else
            {
                Report.Fail("The Fee Plan was not Updated successfully In Deposit Fee Page", "FeePagefail", "true", appHandle, true);
            }
        }
        public virtual void UpdateTransactionRestrictionsMinimunBalanceInTransactionProcessingPage(string AccountNumber, string MinBalance)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Transaction Processing"));
            WebCSRPageFactory.TransactionProcessingPage.UpdateMinimumBalaceinTransactionRestri(MinBalance);
            WebCSRPageFactory.TransactionProcessingPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.TransactionProcessingPage.VerifyMessageInTransactionProcessingPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("Transaction processing data is updated successfully.", "transuccess", "true", appHandle);
            }
            else
            {
                Report.Fail("Transaction processing data is not updated successfully.", "transuccessfail", "true", appHandle, true);
            }
        }
        public virtual void EnterExceptionProcessingSearchPageDetails(string CustomerNumber, string Transactiondate, string Branch, string Status, string Customer, string AccountNumber, string value, string ExceptionProcessing, string Fee)
        {
            string temptitle = appHandle.GetTitle();
            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), CustomerNumber);
            }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), CustomerNumber);
            }
            this.ClickLinkFromMenuItem(Data.Get("Utilities") + "|" + Data.Get("Exception Processing"));
            WebCSRPageFactory.UtilityExceptionProcessingPage.EnterExceptionProcessingSearchPageDetails(Transactiondate, Branch, Status, Customer);
            Report.Pass("Transaction Date:" + Transactiondate + ", Transaction Source: ACH Clearing, Status: Incomplete and Customer:<CIF> " + Customer + ". are selected", "ExceptionProcessingStatusPass", "true", appHandle);
            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectSubmitButton();
            Report.Pass("Review Exception Processing Result page", "ExceptionProcessingStatusPass1", "true", appHandle);
            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectReviewButton();
            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectExceptionCheckbox(true);
            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectDecisiondropdown(AccountNumber, value);
            Report.Pass("Select pay from decission dropdown", "ExceptionProcessingStatusPass2", "true", appHandle);
            WebCSRPageFactory.UtilityExceptionProcessingPage.ClickOnContinueButton();
            WebCSRPageFactory.UtilityExceptionProcessingPage.ExceptionProcessingConfirmation(ExceptionProcessing, Fee);
            Report.Pass("Select pay reason " + ExceptionProcessing + "and Pay fee action " + Fee + "from dropdown and click submit ", "ExceptionProcessingStatusPass3", "true", appHandle);
            WebCSRPageFactory.UtilityExceptionProcessingPage.SelectSubmitButton();
            Report.Pass(" verify that system process the exception item without any errors", "ExceptionProcessingStatusPass4", "true", appHandle);

        }
        public virtual string GetLoanAccuredInterestFromInsterestBalances(string AccountNumber)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Balances"));
            string data = WebCSRPageFactory.LoanInterestTab.GetValueForLabel(Data.Get("Interest Paid Life of Loan"));
            return data;
        }
        public virtual string GetBalanceFromAccountSummary(string AccountNumber)
        {
            this.get_account(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Balances"));
            string data = WebCSRPageFactory.DepositAccountOverviewPage.GetValueForLabel(Data.Get("Interest Paid Life of Loan"));
            return data;
        }
        public virtual string AddBeneficiariesForTrustCustomer(string CustomerNo, string BeneficiaryClassificationType, string Percentage, bool FDICONorOFF, bool NonContingentCheckBoxONOFF)
        {
            string BeneficiaryID = "";
            GetCustomer(CustomerNo);
            WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Beneficiaries"));
            string TaxIDIndividual = WebCSRPageFactory.AddBeneficiaryPage.EnterBeneficiaryDetailsforTrustCustomer(BeneficiaryClassificationType, Percentage, FDICONorOFF, NonContingentCheckBoxONOFF);
            if (WebCSRPageFactory.AddBeneficiaryPage.VerifyMSGInBeneficiaryPage("The beneficiary has been added.") ||
            WebCSRPageFactory.AddBeneficiaryPage.VerifyMSGInBeneficiaryPage("The trust customer beneficiary has been added.") ||
            WebCSRPageFactory.AddBeneficiaryPage.VerifyMSGInBeneficiaryPage("Total beneficiary percentage for the Primary beneficiaries is not equal to 100%."))
            {
                BeneficiaryID = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT BENEFICIARYID FROM BENEFICIARYINFO WHERE TAXID = '" + TaxIDIndividual + "'", "BENEFICIARYID");
                Report.Pass("Beneficiaries is / are added for the customer : " + CustomerNo, "beneficiaryadd", "true", appHandle);

            }
            else
            {
                Report.Fail(" Beneficiaries is / are not added for the customer : " + CustomerNo, "beneficiaryadd", "true", appHandle, true);
            }
            return BeneficiaryID;
        }
        public virtual string CreateTrustAccount(string TrustCustomerNo, string Relationship, string ProductType, string CustomerNumbersForAdditionalOwnerAddition = "", int numberofAccounts = 1, string AccountDetailsWithSemicolonDelimiter = "")
        {
            string AccountNumber = "";
            string temptitle = appHandle.GetTitle();

            WebCSRPageFactory.CustomerSearchPage.WaitUntilCustomerSearchLinkIsLoaded();
            if (temptitle.Contains(Data.Get("Customer Search")))
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), TrustCustomerNo);
            }
            else if (temptitle.Contains(Data.Get("Verify Customer"))) { }
            else
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), TrustCustomerNo);
            }
            if (WebCSRPageFactory.CreateAccountPage.VerifyCustomerNumberForAcctCreation(TrustCustomerNo) == false)
            {
                WebCSRPageFactory.CustomerSearchPage.get_customer_number(Data.Get("Customer Number"), TrustCustomerNo);
            }
            WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.VerifyCustomerPage.ClickOnSubmitButton();
            WebCSRPageFactory.WebCSRMasterPage.NavigateToCreateTrustAccountPage();
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateAccountPage.SelectRelationshipRadiobutton_AccountCreation(Relationship);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.SelectProductAndNumberOfAccounts(ProductType, numberofAccounts);
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.EnterAccountDetails(AccountDetailsWithSemicolonDelimiter, numberofAccounts, ProductType);
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();
            WebCSRPageFactory.CreateAccountPage.ClickOnContinueButton();
            WebCSRPageFactory.CreateAccountPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CreateAccountPage.VerifyAccountCreationSuccess())
            {
                Report.Pass("Account creation application is successfully processed.", "accountcreationapplication", "true", appHandle);
            }
            else
            {
                Report.Fail("Account creation  application is not created due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "CreateAccountCreationFail", "true", appHandle);
            }
            AccountNumber = WebCSRPageFactory.CreateAccountPage.GetAccountNumbersFromApplicationSuccessPage(numberofAccounts);
            WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber, numberofAccounts);
            return AccountNumber;
        }
        public virtual string GetBeneficiaryFirstName(string CustomerNo, string BeneID, string AccountNumber = "", bool IsGeneralAccountServicesBeneficiaries = false, bool IsJointAccount = false)
        {
            if (IsGeneralAccountServicesBeneficiaries)
            {
                get_account(AccountNumber, IsJointAccount);
                WebCSRPageFactory.BeneficiariesPage.selectAccountFromDropdown(AccountNumber);
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Beneficiaries"));
            }
            else
            {
                this.GetCustomer(CustomerNo);
                WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
                WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Beneficiaries"));
            }
            string FirstName = WebCSRPageFactory.AddBeneficiaryPage.GetFirstNameofBeneficiary(BeneID);
            return FirstName;
        }

        public virtual string GetBeneficiaryEntityName(string CustomerNo, string BeneID, string AccountNumber = "", bool IsGeneralAccountServicesBeneficiaries = false, bool IsJointAccount = false)
        {
            if (IsGeneralAccountServicesBeneficiaries)
            {
                get_account(AccountNumber, IsJointAccount);
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Beneficiaries"));
                WebCSRPageFactory.BeneficiariesPage.selectAccountFromDropdown(AccountNumber);
            }
            else
            {
                this.GetCustomer(CustomerNo);
                WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
                WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Beneficiaries"));
            }
            string EntityName = WebCSRPageFactory.AddBeneficiaryPage.GetEntityNameofBeneficiary(BeneID);
            return EntityName;
        }
        public virtual string GetBeneficiaryLastName(string CustomerNo, string BeneID, string AccountNumber = "", bool IsGeneralAccountServicesBeneficiaries = false, bool IsJointAccount = false)
        {
            if (IsGeneralAccountServicesBeneficiaries)
            {
                get_account(AccountNumber, IsJointAccount);
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Beneficiaries"));
                WebCSRPageFactory.BeneficiariesPage.selectAccountFromDropdown(AccountNumber);
            }
            else
            {
                this.GetCustomer(CustomerNo);
                WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
                WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Beneficiaries"));
            }

            string LastName = WebCSRPageFactory.AddBeneficiaryPage.GetLastNameofBeneficiary(BeneID);
            return LastName;

        }
        public virtual string GetBeneficiaryTaxid(string CustomerNo, string BeneID)
        {
            this.GetCustomer(CustomerNo);
            WebCSRPageFactory.CustomerSearchPage.SelectGoToDropdown((string)Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
            this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Beneficiaries"));
            string Taxid = WebCSRPageFactory.AddBeneficiaryPage.GetFirstNameofBeneficiary(BeneID);
            return Taxid;
        }
        public virtual void VerifyBeneficiarySummarytable(string AccountNo, string LabelNamePipeLineLabelValue)
        {
            string msg = "";
            if (LabelNamePipeLineLabelValue.Contains(";"))
            {
                msg = LabelNamePipeLineLabelValue.Replace("|", " = ");
                msg = string.Join(" , ", msg.Split(';'));
            }
            else
            {
                msg = LabelNamePipeLineLabelValue.Replace("|", " = ");
            }
            if (WebCSRPageFactory.FDIC370InformationPage.VerifyDataInBeneficiarysummary(LabelNamePipeLineLabelValue))
            {
                Report.Pass(msg + " is / are successfully matched in application.", "tablelabelvalue", "true", appHandle);
            }
            else
            {
                Report.Fail(msg + " is / are not successfully matched in application", "tablelabelvaluefail", "true", appHandle);
            }
        }
        public virtual string GetBeneficiaryIDfromBeneficiaryListPage(string CustomerNo, int Rowno, string AccountNumber = "", bool IsGeneralAccountServicesBeneficiaries = false, bool IsJointAccount = false)
        {
            string BeneficiaryID = "";

            if (IsGeneralAccountServicesBeneficiaries)
            {
                get_account(AccountNumber, IsJointAccount);
                LoadAccountSummaryPage(AccountNumber);
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Beneficiaries"));
            }
            else
            {
                this.GetCustomer(CustomerNo);
                WebCSRPageFactory.VerifyCustomerPage.SelectValueFromVerificationDropdown(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
                WebCSRPageFactory.CustomerSearchPage.ClickOnSubmitButton();
                this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Beneficiaries"));
            }

            BeneficiaryID = WebCSRPageFactory.AddBeneficiaryPage.GetBeneficiaryID(Rowno);
            return BeneficiaryID;
        }
        public virtual void VerifyInsuranceSummarytable(string AccountNo, string LabelNamePipeLineLabelValue)
        {
            string msg = "";
            if (LabelNamePipeLineLabelValue.Contains(";"))
            {
                msg = LabelNamePipeLineLabelValue.Replace("|", " = ");
                msg = string.Join(" , ", msg.Split(';'));
            }
            else
            {
                msg = LabelNamePipeLineLabelValue.Replace("|", " = ");
            }
            if (WebCSRPageFactory.FDIC370InformationPage.VerifyDataInInsurancesummary(LabelNamePipeLineLabelValue))
            {
                Report.Pass(msg + " is / are successfully matched in application.", "tablelabelvalue", "true", appHandle);
            }
            else
            {
                Report.Fail(msg + " is / are not successfully matched in application", "tablelabelvaluefail", "true", appHandle);
            }
        }


        public virtual void VerifyDataIBalanceViolationFeesTable(string AccountNumber, string refColumnValuesSemicolonDelimited)
        {

            if (!appHandle.GetTitle().Contains(Data.Get("Fees")))
            {
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Fees"));

            }
            else
            {
                if (WebCSRPageFactory.USRegulatoryPage.VerifyAccountExistsInAccountDropdown(AccountNumber)) { }
                else
                {
                    LoadAccountSummaryPage(AccountNumber);
                    Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Fees"));
                }
            }

            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (refColumnValuesSemicolonDelimited.Contains("|"))
            {
                arr = refColumnValuesSemicolonDelimited.Split('|');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split(';')) + " is captured successfully in Balance Violation Fee table in WebCSR.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", refColumnValuesSemicolonDelimited.Split(';')) + " is captured successfully in Balance Violation fee table in WebCSR.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebCSRPageFactory.AccountInformationFeesPage.VerifyDataInBalanceViolationFee(AccountNumber, refColumnValuesSemicolonDelimited))
            {
                Report.Pass(msg, "BalanceViolationFeeTableValueChecked", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "BalanceViolationFeeTableValueNotChecked", "True", appHandle, true);
            }
        }

        public virtual string AddCardInCardManagementPagewithInvalidCardType(string CardType, string AccountNumber, string AccessOption = "", string EmbossingOption = "", string Amount = "", string ExpDate = "", string cardstatus = "")
        {
            LoadAccountSummaryPage(AccountNumber);
            ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            WebCSRPageFactory.CardManagementPage.selectAccountFromDropDown(AccountNumber);
            WebCSRPageFactory.CardManagementPage.ClickOnAddButton();
            WebCSRPageFactory.CardManagementPage.SelectCardType(CardType);
            string CardNo = WebCSRPageFactory.CardManagementPage.UpdateCardDetails(CardType, AccountNumber, AccessOption, EmbossingOption, Amount, ExpDate, cardstatus);
            WebCSRPageFactory.CardManagementPage.MoveAccountFromAvailableAccountToSelectedAccounts(AccountNumber);
            WebCSRPageFactory.CardManagementPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CardManagementPage.VerifyMessageInCardManagementPage("BIN required to generate card number"))
            {
                Report.Pass("BIN required to generate card number", "CardNotAddedWhenBINIsEmpty", "True", appHandle);
            }
            else
            {
                Report.Fail("Card Created without BIN Number", "BalanceViolationFeeTableValueNotChecked", "True", appHandle, true);
            }
            return CardNo;
        }

        public virtual void VerifyMessageInCardManagementPage(string msg)
        {
            if (WebCSRPageFactory.CardManagementPage.VerifyMessageInCardManagementPage(msg))
            {
                Report.Pass(msg, "ErrorMessegeDisplayed", "True", appHandle);
            }
            else
            {
                Report.Fail("Error Messege is not Displayed in CardBin Page. ", "ErrorMessegeNotDisplayed", "True", appHandle, true);
            }
        }
        public virtual void SelectCardFromCardManagement(string CardType, string AccountNumber)
        {
            LoadAccountSummaryPage(AccountNumber);
            ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            WebCSRPageFactory.CardManagementPage.selectAccountFromDropDown(AccountNumber);
            WebCSRPageFactory.CardManagementPage.ClickOnAddButton();
            WebCSRPageFactory.CardManagementPage.SelectCardType(CardType);
        }


        public virtual void ReplaceCardInCardManageMentPage(string AccountNumber, string UniqueOrderRefValue, bool issuereplace)
        {
            GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Card Management"));
            WebCSRPageFactory.CardManagementPage.selectAccountFromDropDown(AccountNumber);
            WebCSRPageFactory.CardManagementPage.SelectCardInCardList(UniqueOrderRefValue);
            WebCSRPageFactory.CardManagementPage.ClickOnEditButton();
            WebCSRPageFactory.CardManagementPage.SelectIssueReplacementOption(issuereplace);
            WebCSRPageFactory.CardManagementPage.ClickOnSubmitButton();

            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Data.Get("The information has been updated.")))
            {
                Report.Pass("The card has been replaced and added to yhe list. ", "deletecard", "True", appHandle);
            }
            else
            {
                Report.Fail("The card has not been replaced", "cardlistfail", "True", appHandle);
            }
        }
        public virtual void VerifyDepositInterestRate(string AccountNumber, string IntRate)
        {
            Application.WebCSR.LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Rate Determination"));
            if (WebCSRPageFactory.DepositRateDeterminationPage.WaitUntilDepositInterestPageLoad())
            {
                this.CheckExpectedValueinEditField(DepositRateDeterminationPage.txtRateDeterminationInterestRate, IntRate);
            }
        }
        public virtual void VerifyLoanInterestRate(string AccountNumber, string IntRate)
        {
            Application.WebCSR.LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Rate Determination"));
            if (WebCSRPageFactory.LoanRateDeterminationPage.WaitUntilLoanInterestPageLoad())
            {
                this.CheckExpectedValueinEditField(LoanRateDeterminationPage.txtInterestRate, IntRate);
            }
        }


        public virtual string EditPaymentListActionTableValue(string AccountNo, string date)
        {
            LoadAccountSummaryPage(AccountNo);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Payment"));
            WebCSRPageFactory.PaymentSnapshotPage.SelectTableValue(date);
            string principle = Application.WebCSR.GetCellValueOfLabel("Unpaid Payment Amount");
            WebCSRPageFactory.PaymentSnapshotPage.ClickOnCancel();
            return principle;
        }


        public virtual string CalculateLoanAccruedInterestByAccrMethod(string accrualMethod, string principalAmount, string intRate, int numberOfDaysPassed, string Date = "", string DateFirstDisbursed = "", int Roundoff = 5, string AccountNumber = "")
        {
            string AccrInterest = "";
            string postfreq = "";
            double AccruedInterest = 0;
            string AFVal = Data.Get("AnnualFactor");
            double AF = Convert.ToDouble(AFVal);
            int numberOfDaysInYear = 0;
            if (string.IsNullOrEmpty(Date))
            {
                Date = GetApplicationDate();
            }
            string yearparam = appHandle.GetDateParameters(Date)[2].Trim();
            if (appHandle.IsLeapYear(Int32.Parse(yearparam)))
            {
                numberOfDaysInYear = 366;
            }
            else
            {
                numberOfDaysInYear = 365;
            }
            int numberofDaysInMonth = GetNumberOfDaysInAMonth(Date);

            switch (accrualMethod)
            {
                case "00 - Standard/Standard  (30/360)":

                    AccruedInterest = Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                    AccruedInterest = AccruedInterest / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100"));
                    AccruedInterest = AccruedInterest / Convert.ToDouble(numberOfDaysInYear);
                    AccruedInterest = AccruedInterest + Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_1"));
                    AccruedInterest = AccruedInterest * Convert.ToDouble(principalAmount);
                    AccruedInterest = AccruedInterest - Convert.ToDouble(principalAmount);
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;

                case "11 - Actual/Actual      (31/365,6)":

                    AccruedInterest = Convert.ToDouble(intRate) * Convert.ToDouble(numberOfDaysPassed);
                    AccruedInterest = AccruedInterest / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100"));
                    AccruedInterest = AccruedInterest / Convert.ToDouble(numberOfDaysInYear);
                    AccruedInterest = AccruedInterest + Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_1"));
                    AccruedInterest = AccruedInterest * Convert.ToDouble(principalAmount);
                    AccruedInterest = AccruedInterest - Convert.ToDouble(principalAmount);
                    AccruedInterest = Math.Round(AccruedInterest, Roundoff);
                    break;

            }
            AccrInterest = AccruedInterest.ToString();
            return AccrInterest;
        }
        public virtual void VerifyInterestIndexSummaryTable(string refColumnValuesSemicolonDelimited, string index, string FromDate, string ToDate)
        {
            if (!appHandle.GetTitle().Contains(Data.Get("Interest Index Summary")))
            {
                ClickLinkFromMenuItem(Data.Get("Utilities") + "|" + Data.Get("Interest Index Summary"));
            }

            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (refColumnValuesSemicolonDelimited.Contains("|"))
            {
                arr = refColumnValuesSemicolonDelimited.Split('|');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split(';')) + " is captured successfully in  Interest Index Summary table in WebCSR.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", refColumnValuesSemicolonDelimited.Split(';')) + " is captured successfully in  Interest Index Summary table in WebCSR.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebCSRPageFactory.UtilitiesInterestIndexSummaryPage.VerifyDataInInterestIndexSummary(refColumnValuesSemicolonDelimited, index, FromDate, ToDate))
            {
                Report.Pass(msg, "InterestIndexSummaryCheck", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "InterestIndexSummaryCheck", "True", appHandle, true);
            }
        }
        public virtual void UpdateRetirementPlanOption(string RetirementPlan, bool FilecompleteONorOFF = false)
        {
            this.ClickLinkFromMenuItem(Data.Get("Retirement Services") + "|" + Data.Get("Plan Information"));
            WebCSRPageFactory.RetairementServicesPage.SelectRetirementPlan(RetirementPlan);
            WebCSRPageFactory.RetairementServicesPage.EnterDetailsWitholdingOptions(FilecompleteONorOFF);
            WebCSRPageFactory.RetairementServicesPage.SelectSubmitButton();
            if (WebCSRPageFactory.RetairementServicesPage.VerifyMessageAccountInformationResidencyPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The Retirement Option page has been updated ", "RetirementServiceplanStatusPass", "true", appHandle);
            }
            else
            {
                Report.Fail("The Retirement Option page has not been updated", "RetirementServicePlanStatusFail", "true", appHandle, true);
            }

        }

        public virtual string CalculateWithholdingAmountforIRAAcc(string AccountNumber, string DistributionAmountPipeDelimited = "", string scheduleRate = "")
        {
            double FederalWHamount = 0;
            double NewAmount = 0;
            string WHAmt = "";
            string[] Amt = DistributionAmountPipeDelimited.Split('|');
            for (int a = 0; a <= Amt.Length - 1; a++)
            {
                string RPASEQ = Profile7CommonLibrary.ExtractDataFromDataBase("select RPASEQ FROM DEP WHERE CID ='" + AccountNumber + "'", "RPASEQ");
                string ACN = Profile7CommonLibrary.ExtractDataFromDataBase("Select ACN FROM DEP WHERE CID = '" + AccountNumber + "'", "ACN");
                string RSPWSCH = Profile7CommonLibrary.ExtractDataFromDataBase("select RSPWSCH from IRATYPE where RPASEQ ='" + RPASEQ + "' and ACN ='" + ACN + "'", "RSPWSCH");
                string WTHAMT = Profile7CommonLibrary.ExtractDataFromDataBase("select WTHAMT from IRATYPE where RPASEQ ='" + RPASEQ + "' and ACN ='" + ACN + "'", "WTHAMT");
                string WTHPCT = Profile7CommonLibrary.ExtractDataFromDataBase("select WTHPCT from IRATYPE where RPASEQ ='" + RPASEQ + "' and ACN ='" + ACN + "'", "WTHPCT");
                if (RSPWSCH == "null" && WTHAMT == "null" && WTHPCT == "null")
                {
                    string RSPWCALC = Profile7CommonLibrary.ExtractDataFromDataBase("select RSPWCALC from IRATYPE where RPASEQ ='" + RPASEQ + "' and ACN ='" + ACN + "'", "RSPWCALC");
                    string WPCT = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT WPCT FROM UTBLWCALC  WHERE UTBLWCALC.KEY='" + RSPWCALC + "'", "WPCT");

                    FederalWHamount = Convert.ToDouble(Amt[a]) * Convert.ToDouble(WPCT);
                    FederalWHamount = FederalWHamount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                }
                else if (WTHAMT == "null" && RSPWSCH == "null" && WTHPCT != "null")
                {
                    string AMTREQUESTED = Profile7CommonLibrary.ExtractDataFromDataBase("select AMTREQUESTED,FEDWHAMT,FEDWHPCT from EFTRSPSDSIGN where CID = '" + AccountNumber + "'", "AMTREQUESTED");
                    string FEDWHAMT = Profile7CommonLibrary.ExtractDataFromDataBase("select AMTREQUESTED,FEDWHAMT,FEDWHPCT from EFTRSPSDSIGN where CID = '" + AccountNumber + "'", "FEDWHAMT");
                    string FEDWHPCT = Profile7CommonLibrary.ExtractDataFromDataBase("select AMTREQUESTED,FEDWHAMT,FEDWHPCT from EFTRSPSDSIGN where CID = '" + AccountNumber + "'", "FEDWHPCT");

                    FederalWHamount = Convert.ToDouble(AMTREQUESTED) * Convert.ToDouble(FEDWHPCT);
                    FederalWHamount = FederalWHamount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                    FederalWHamount = FederalWHamount + Convert.ToDouble(FEDWHAMT);
                }
                else if (RSPWSCH != "null" && WTHAMT == "null" && WTHPCT != "null")
                {
                    FederalWHamount = Convert.ToDouble(WTHPCT) + Convert.ToDouble(RSPWSCH);
                    FederalWHamount = FederalWHamount * Convert.ToDouble(Amt[a]);
                    FederalWHamount = FederalWHamount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));

                }
                else if (RSPWSCH == "null" && WTHAMT != "null" && WTHPCT != "null")
                {
                    FederalWHamount = Convert.ToDouble(WTHPCT) * Convert.ToDouble(Amt[a]);
                    FederalWHamount = FederalWHamount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                    FederalWHamount = FederalWHamount + Convert.ToDouble(WTHAMT);

                }
                else
                {
                    if (!string.IsNullOrEmpty(scheduleRate))
                    {
                        FederalWHamount = Convert.ToDouble(WTHPCT) + Convert.ToDouble(scheduleRate);

                    }
                    else
                    {
                        FederalWHamount = Convert.ToDouble(WTHPCT) + Convert.ToDouble(RSPWSCH);
                    }
                    FederalWHamount = FederalWHamount * Convert.ToDouble(Amt[a]);
                    FederalWHamount = FederalWHamount / (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
                    FederalWHamount = FederalWHamount + Convert.ToDouble(WTHAMT);
                }

                NewAmount = NewAmount + FederalWHamount;
                NewAmount = Math.Round(NewAmount, 2);
                WHAmt = Convert.ToString(NewAmount);
            }
            return WHAmt;
        }

        public virtual string CalculateWithholdingPercentageforIRAAcc(string withholdingAmt, string TotalDistributionAmount)
        {
            double withHoldingpercentage = Convert.ToDouble(withholdingAmt) / (Convert.ToDouble(TotalDistributionAmount));
            withHoldingpercentage = withHoldingpercentage * (Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100")));
            withHoldingpercentage = Math.Round(withHoldingpercentage, 2);
            return Convert.ToString(withHoldingpercentage);
        }

        public virtual void UpdateIRAMoneyMovement(string IRAccount, string plantype, bool radio, string Account, string Amouttype, string Amount, string distributioncode, string date, string FedWithholdingPer = "", string FedWithholdingFixedAmt = "")
        {
            this.ClickLinkFromMenuItem(Data.Get("Retirement Services") + "|" + Data.Get("IRA Money Movement"));
            WebCSRPageFactory.IRAMoneyMovementPage.SelectIRAMoneyMovemnetAccount(IRAccount, plantype);
            WebCSRPageFactory.IRAMoneyMovementPage.EnterRecepientAccountDetails(radio, Account, Amouttype, Amount, distributioncode, date, FedWithholdingPer, FedWithholdingFixedAmt);
            Report.Pass("Enter IRA Money Movement Details for " + IRAccount + " Account", "IRAmoneyMovementStatusPass1", "true", appHandle);
            WebCSRPageFactory.IRAMoneyMovementPage.SelectContinueButton();
            Report.Pass("Verify details for " + IRAccount + " Account.", "IRAmoneyMovementStatusPass2", "true", appHandle);
            WebCSRPageFactory.IRAMoneyMovementPage.SelectSubmitButton();

            if (date == GetApplicationDate())
            {
                string msg = Data.Get("IRAMessage");
                msg = appHandle.ReplaceString(msg, "$", ",");
                if (WebCSRPageFactory.IRAMoneyMovementPage.VerifyMessageAccountInformationResidencyPage(msg))
                {
                    Report.Pass("IRA Money Movement Successfully on same date", "IRAmoneyMovementStatusPass", "true", appHandle);
                }
                else
                {
                    Report.Fail("IRA Money Movement is not done on same date", "IRAmoneyMovementStatusFail", "true", appHandle);
                }
            }
            else
            {
                if (WebCSRPageFactory.IRAMoneyMovementPage.VerifyMessageAccountInformationResidencyPage("The order has been added."))
                {
                    Report.Pass("The order has been added for T+1 date", "IRAmoneyMovementStatusPass", "true", appHandle);
                }
                else
                {
                    Report.Fail("The order has not been added.", "IRAmoneyMovementStatusFail", "true", appHandle);
                }
            }
        }
        public virtual void UpdateInterestRateInRateDetermination(string AccountNumber, string intrate)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Overview"))) { }
            else
            {
                WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
            }
            WebCSRPageFactory.AccountOverviewPage.SelectAccountSummaryTab();
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Rate Determination"));
            if (WebCSRPageFactory.DepositRateDeterminationPage.EnterValueOfInterestRate(intrate))
            {
                Report.Pass("Interest Rate is updated", "bh", "True", appHandle);
            }
            else
            {
                Report.Fail("Interest Rate is not updated", "bh", "True", appHandle);
            }

        }

        public virtual string GetDataFromAccountHistoryPopupWidowByLabelName(string AccountNumber, string linkname, string labelname, string lineno)
        {
            VerifyDataInAccountHistoryTable(AccountNumber, linkname);
            string labelvalue = WebCSRPageFactory.AccountHistoryPage.GetLabelValue(labelname, lineno);
            WebCSRPageFactory.AccountHistoryPage.ClosePopup();
            return labelvalue;

        }

        public virtual void UpdateFDIC370Page(string AccountNumber, string ORCode, bool isjoint = false)
        {
            get_account(AccountNumber, isjoint);
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("FDIC 370"));
            WebCSRPageFactory.FDIC370InformationPage.EnterFDIC370PageDetails(ORCode);
            if (WebCSRPageFactory.FDIC370InformationPage.VerifyMessageInFDIC370Page(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The information has been updated.", "FDIC370pageUpdated", "true", appHandle);
            }
            else
            {
                Report.Fail("The information has not been updated.", "FDIC370pagenotUpdated", "true", appHandle, true);
            }
        }

        public virtual void VerifyDataInFDIC370InsuranceSummaryTable(string AccountNumber, string refColumnValuesSemicolonDelimited, bool isJoin = false)
        {
            if (!appHandle.GetTitle().Contains(Data.Get("FDIC 370")))
            {

                get_account(AccountNumber, isJoin);
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("FDIC 370"));

            }
            else
            {
                if (WebCSRPageFactory.USRegulatoryPage.VerifyAccountExistsInAccountDropdown(AccountNumber)) { }
                else
                {
                    LoadAccountSummaryPage(AccountNumber);
                    Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("FDIC 370"));
                }
            }

            string temp = "";
            string[] arr = null;
            string msg = "", failmsg = "";
            if (refColumnValuesSemicolonDelimited.Contains("|"))
            {
                arr = refColumnValuesSemicolonDelimited.Split('|');
                for (int b = 0; b < arr.Length; b++)
                {
                    temp = temp + " , " + string.Join(" , ", arr[b].Split(';')) + " is captured successfully in FDIC370 Reporting table in WebCSR.";

                }
                msg = temp.Substring(3, temp.Length - 3);
                failmsg = msg.Replace(" is ", " is not ");
            }
            else
            {
                msg = string.Join(" , ", refColumnValuesSemicolonDelimited.Split(';')) + " is captured successfully in FDIC370 table in WebCSR.";
                failmsg = msg.Replace(" is ", " is not ");
            }

            if (WebCSRPageFactory.FDIC370Page.VerifyDataInFDIC370Reporting(AccountNumber, refColumnValuesSemicolonDelimited))
            {
                Report.Pass(msg, "FDIC370TableValueChecked", "True", appHandle);
            }
            else
            {
                Report.Fail(failmsg, "FDIC370TableValueNotChecked", "True", appHandle, true);
            }
        }


        public virtual void VerifyDataInUSRegulatoryPage(string AccountNumber, string labelname, string verificationvalue)
        {
            LoadAccountSummaryPage(AccountNumber);
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("U.S. Regulatory"));
            if (WebCSRPageFactory.USRegulatoryPage.VerifyRegulationCCExceptionCodeStatus(labelname, verificationvalue))
            {
                Report.Pass(verificationvalue + " verified successfully in U.S. Regulatory page", "VerifiedDataSuccessfully", "True", appHandle);
            }
            else
            {
                Report.Fail(verificationvalue + " is not present in U.S. Regulatory page", "FailedtoVerifyData", "True", appHandle, true);
            }

        }

        public virtual void VerifyDataInLoanFeePlansPage(string AccountNumber)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication("Loan Fees", "Loan Fee Plans");

            int count = WebCSRPageFactory.LoanFeePage.CountFee();
            if (count == 1)
            {
                Report.Pass("Verify that account is linked to the single Loan Fee plan.", "singleLoanfee", "True", appHandle);
            }
            else if (count > 1)
            {
                Report.Pass("Verify that account is linked to the multiple Loan Fee plan.", "multipleLoanfee", "True", appHandle);
            }
            else
            {
                Report.Fail("Account is not linked to any of the LOan fee plan", "LoanFeeisnotlinked", "True", appHandle, true);
            }
        }


        public virtual void VerifyBillDatesinPaymentSnapshotPage(string AccountNumber)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }


            Profile7CommonLibrary.SelectTabSubTabInApplication("Payment");

            string SCHNUM = Profile7CommonLibrary.ExtractDataFromDataBase("select SCHNUM from LN where CID = '" + AccountNumber + "'", "SCHNUM");
            string TJD = Profile7CommonLibrary.ExtractDataFromDataBase("SELECT TJD FROM CUVAR", "TJD");
            string CDPD = Profile7CommonLibrary.ExtractDataFromDataBase("select CID,CDPD from LNBIL1 where CID = '" + AccountNumber + "' ORDER BY CDPD DESC", "CDPD");

            int TotalBillcount = WebCSRPageFactory.LoanFeePage.CountFee();

            if (appHandle.IsDateGreater(CDPD, TJD) == true && TotalBillcount > Convert.ToInt32(SCHNUM))
            {
                Report.Info("Out of" + TotalBillcount + "," + SCHNUM + "th bill is current bill," + TotalBillcount + "th bill is future date bill", true);
                Report.Pass("Future date" + CDPD + " Bill is added to account", "singleLoanfee", "True", appHandle);
            }
            else
            {
                Report.Info("Out of" + TotalBillcount + "," + SCHNUM + "th bill is current bill," + TotalBillcount + "th bill is current date bill", true);
                Report.Pass("No Future date Bill is added to account", "singleLoanfee", "True", appHandle);
            }
            string TDUE = Profile7CommonLibrary.ExtractDataFromDataBase("select TDUE,LCHG,MCND,TOTVATDUE,UNAPF from LN where CID = '" + AccountNumber + "'", "TDUE");
            string LCHG = Profile7CommonLibrary.ExtractDataFromDataBase("select TDUE,LCHG,MCND,TOTVATDUE,UNAPF from LN where CID = '" + AccountNumber + "'", "LCHG");
            string MCND = Profile7CommonLibrary.ExtractDataFromDataBase("select TDUE,LCHG,MCND,TOTVATDUE,UNAPF from LN where CID = '" + AccountNumber + "'", "MCND");
            string TOTVATDUE = Profile7CommonLibrary.ExtractDataFromDataBase("select TDUE,LCHG,MCND,TOTVATDUE,UNAPF from LN where CID = '" + AccountNumber + "'", "TOTVATDUE");
            string UNAPF = Profile7CommonLibrary.ExtractDataFromDataBase("select TDUE,LCHG,MCND,TOTVATDUE,UNAPF from LN where CID = '" + AccountNumber + "'", "UNAPF");
            double GTDUE = 0;
            if (TOTVATDUE == "null" && UNAPF == "null")
            {
                GTDUE = Convert.ToDouble(TDUE) + Convert.ToDouble(LCHG) + Convert.ToDouble(MCND);
            }
            else if (TOTVATDUE != "null" && UNAPF == "null")
            {
                GTDUE = Convert.ToDouble(TDUE) + Convert.ToDouble(LCHG) + Convert.ToDouble(MCND) + Convert.ToDouble(TOTVATDUE);
            }
            else
            {
                GTDUE = Convert.ToDouble(TDUE) + Convert.ToDouble(LCHG) + Convert.ToDouble(MCND) + Convert.ToDouble(TOTVATDUE) + Convert.ToDouble(UNAPF);
            }

            string SystemGTDUE = Profile7CommonLibrary.ExtractDataFromDataBase("Select GTDUE FROM LN WHERE CID ='" + AccountNumber + "'", "GTDUE");

            if (SystemGTDUE == GTDUE.ToString())
            {
                Report.Info("Grand Total Due =" + GTDUE + " is calculated correctly.", true);
            }

            WebCSRPageFactory.LoanFeePage.selectdatafromPaymentListTable(AccountNumber);
            WebCSRPageFactory.LoanFeePage.ClickOnEditButton();
            Report.Pass("Verify data in Payment Snapshot page.", "paysnap", "True", appHandle);

        }

        public virtual void AddIntermediateBill(string AccountNumber, string date, string interest = "", string loanfee = "", string principle = "")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication("Payment");
            WebCSRPageFactory.PaymentSnapshotPage.AddPaymentSnapshot(date, interest, loanfee, principle);
            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Data.Get("The information has been updated.")))
            {
                WebCSRPageFactory.PaymentSnapshotPage.selectfullysatisfiedCheckbox();
                Report.Pass("Intermediate Bill has been added to payment list.", "deletecard", "True", appHandle);
            }
            else
            {
                Report.Fail("Intermediate Bill has not been added to Payment list.", "cardlistfail", "True", appHandle);
            }
        }

        public virtual void VerifyTotalDueAmtForLoanAccount(string AccountNumber)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication("Payment");
            string GTDUE = Profile7CommonLibrary.ExtractDataFromDataBase("Select GTDUE FROM LN WHERE CID ='" + AccountNumber + "'", "GTDUE");

            if (GTDUE == "0.00")
            {
                Report.Pass("There are no due pending for the account", "deletecard", "True", appHandle);
            }
            else
            {
                Report.Fail("Total due amount to the account = " + GTDUE, "cardlistfail", "True", appHandle);
            }
        }


        // This will be always calculate the new date for Thursday.
        public virtual string CalculateNewDate()
        {
            string date = Profile7CommonLibrary.GetApplicationDate();
            int y = Convert.ToInt32(date.Split('/')[2]);
            int d = Convert.ToInt32(date.Split('/')[1]);
            int m = Convert.ToInt32(date.Split('/')[0]);

            DateTime dob = new DateTime(y, m, d);
            DayOfWeek weekday = dob.DayOfWeek;
            d.ToString("MMM");
            string newdate = "";
            switch (weekday.ToString())
            {
                case "Monday":
                    newdate = appHandle.CalculateNewDate(date, "D", -4);
                    break;
                case "Tuesday":
                    newdate = appHandle.CalculateNewDate(date, "D", -5);
                    break;
                case "Wednesay":
                    newdate = appHandle.CalculateNewDate(date, "D", -6);
                    break;
                case "Thursday":
                    newdate = appHandle.CalculateNewDate(date, "D", -7);
                    break;
                case "Friday":
                    newdate = appHandle.CalculateNewDate(date, "D", -1);
                    break;
                case "Saturday":
                    newdate = appHandle.CalculateNewDate(date, "D", -2);
                    break;
                case "Sunday":
                    newdate = appHandle.CalculateNewDate(date, "D", -3);
                    break;
                default:
                    break;
            }
            return newdate;
        }

        public virtual void AddCustomerRestrictions(string AccountNumber, string RestrictionType, string IRAAccount = "", string Startdate = "", string ExpirationDate = "", string Comment = "")
        {
            GetAccount(AccountNumber);
            if (!appHandle.GetTitle().Contains("Restrictions"))
            {

                this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Restrictions"));
            }
            WebCSRPageFactory.CustomerRestrictionPage.ClickOnAddButton();
            WebCSRPageFactory.CustomerRestrictionPage.EnterCustomerRestrictionDetails(RestrictionType, AccountNumber, IRAAccount, Startdate, ExpirationDate, Comment);
            Report.Info("Restriction details are entered.", "addrestriction", "true", appHandle);
            WebCSRPageFactory.CustomerRestrictionPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.AccountRestrictionPage.VerifyRestrictionCreationSuccessful())
            {
                Report.Pass(RestrictionType + " restriction is added for customer successfully.", "restrictionadded", "true", appHandle);
            }
            else
            {
                Report.Fail("Restriction is not added due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "acctresticrionaddFail", "true", appHandle);
            }
        }
        public virtual void DeleteSystematicBill(string AccountNumber, string date)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication("Payment");
            WebCSRPageFactory.PaymentSnapshotPage.DeleteBill(date);
            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Data.Get("The unpaid payment record has been deleted.")))
            {
                Report.Pass("Intermediate Bill has been deleted from payment list.", "billdeleted", "True", appHandle);
            }
            else
            {
                Report.Fail("Intermediate Bill has not been deleted from Payment list.", "billisNotDeleted", "True", appHandle);
            }
        }

        public virtual void UpdateIntermediateBill(string AccountNumber, string date, string interest = "", string loanfee = "", string principle = "")
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication("Payment");
            WebCSRPageFactory.PaymentSnapshotPage.ModifyExistingBill(date, interest, loanfee, principle);
            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The information has been updated", "billdeleted", "True", appHandle);
            }
            else
            {
                Report.Fail("The information has not been updated.", "billisNotDeleted", "True", appHandle);
            }
        }

        public virtual void UpdatePaymentDetailsPage(string AccountNumber, string paymentFrequency)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(AccountNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication("Payment", "Payment Detail");
            WebCSRPageFactory.PaymentDetailPage.UpdatePaymentDetails(paymentFrequency);
            if (WebCSRPageFactory.DomesticPaymentAddPaymentOrderPage.VerifyMessageInPaymentOrderPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("The information has been updated", "paymentdetailsupdated", "True", appHandle);
            }
            else
            {
                Report.Fail("The information has not been updated.", "paymentdetailsNotupdated", "True", appHandle);
            }
        }
        public virtual void VerifyPendingReasonDropdownInFDIC370Page(string AccountNumber, string drpPendingReasonValue, bool isJoint = false)
        {
            if (!appHandle.GetTitle().Contains(Data.Get("FDIC 370")))
            {

                get_account(AccountNumber, isJoint);
                LoadAccountSummaryPage(AccountNumber);
                Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("FDIC 370"));

            }
            else
            {
                if (WebCSRPageFactory.USRegulatoryPage.VerifyAccountExistsInAccountDropdown(AccountNumber)) { }
                else
                {
                    LoadAccountSummaryPage(AccountNumber);
                    Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("FDIC 370"));
                }
            }

            if (WebCSRPageFactory.FDIC370InformationPage.VerifyDataInFDIC370PendingReasonDropDown(drpPendingReasonValue))
            {
                Report.Pass("The expected value " + drpPendingReasonValue + " found in Pending Reason dropdown.", "FDIC370PendingReason", "True", appHandle);
            }
            else
            {
                Report.Fail("The expected value " + drpPendingReasonValue + " not found in Pending Reason dropdown.", "FDIC370PendingReason", "True", appHandle, true);
            }
        }
        public virtual void checkAccountAvailableBalanceFieldValue(string AccountNumber, string sAvailableBalanceAmount)
        {
            WebCSRPageFactory.CustomerSearchPage.SearchCustomer(AccountNumber, Data.Get("Account Number"));
            this.SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_ACCOUNTLIST"));
            WebCSRPageFactory.CreateAccountPage.LoadAccountSummary(AccountNumber);
            string DEP_BALAVL = WebCSRPageFactory.DepositAccountOverviewPage.getAccountAvailableBalanceFieldValue();
            if (sAvailableBalanceAmount.Equals(DEP_BALAVL))
            {
                Report.Pass("The label - <Available Balance> has the expected value - <" + sAvailableBalanceAmount + ">", "DepositAccountOverview_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Available Balance> does not have the expected value - <" + sAvailableBalanceAmount + ">", "DepositAccountOverview_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }
           

        public virtual void checkAccountPermanentHoldFieldValue(string AccountNumber, string holdamount)
        {
            string DEP_BALAVL = WebCSRPageFactory.DepositAccountOverviewPage.getAccountPermanentHoldFieldValue();

            if (holdamount.Equals(DEP_BALAVL))
            {
                Report.Pass("The label - <Permanent Hold> has the expected value - <" + holdamount + ">", "DepositAccountOverview_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("The label - <Permanent Hold> does not have the expected value - <" + holdamount + ">", "DepositAccountOverview_Page", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }

        public virtual void AddCustomerRestrictions(string AccountNumber, string RestrictionType, string customerNo, string IRAAccount = "", string Startdate = "", string ExpirationDate = "", string Comment = "")
        {
            if (!appHandle.GetTitle().Contains("Restrictions"))
            {
                Application.WebCSR.GetCustomer(customerNo);
                Application.WebCSR.select_submit_button();
                this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Restrictions"));
            }
            WebCSRPageFactory.CustomerRestrictionPage.ClickOnAddButton();
            WebCSRPageFactory.CustomerRestrictionPage.EnterCustomerRestrictionDetails(RestrictionType, AccountNumber, IRAAccount, Startdate, ExpirationDate, Comment);
            Report.Info("Restriction details are entered.", "addrestriction", "true", appHandle);
            WebCSRPageFactory.CustomerRestrictionPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.AccountRestrictionPage.VerifyRestrictionCreationSuccessful())
            {
                Report.Pass(RestrictionType + " restriction is added for customer successfully.", "restrictionadded", "true", appHandle);
            }
            else
            {
                Report.Fail("Restriction is not added due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "acctresticrionaddFail", "true", appHandle);
            }
        }
        public virtual void DeleteCustomerRestrictions(string AccountNumber, string RestrictionType, string CIF)
        {
            if (!appHandle.GetTitle().Contains("Restrictions"))
            {
                Application.WebCSR.GetCustomer(CIF);
                Application.WebCSR.select_submit_button();
                this.ClickLinkFromMenuItem(Data.Get("Customer Services") + "|" + Data.Get("Restrictions"));
            }

            WebCSRPageFactory.CustomerRestrictionPage.DeleteCustomerRestrction(CIF, RestrictionType);
            appHandle.WaitForSpecifiedTime(5);

            if (WebCSRPageFactory.CustomerRestrictionPage.VerifyRestrictionDeletionSuccessful())
            {
                Report.Pass(RestrictionType + " restriction is deleted for customer successfully.", "restrictiondeleted", "true", appHandle);
            }
            else
            {
                Report.Fail("Restriction is not deleted due to :" + WebCSRPageFactory.CreatePersonalCustomerPage.GetMessageText(), "DeleteCustomerRestrction", "true", appHandle);
            }
        }

        public virtual void checkTextNotExistsInTable(string referenceValue)
        {
            bool blnExists = WebCSRPageFactory.AccountHistoryPage.check_text_exists_in_table(referenceValue);
            if (!blnExists)
            {
                Report.Pass("Specified Data: " + referenceValue + " is not Available in table.", "AccountHistoryPage.", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
            else
            {
                Report.Fail("Specified Data: " + referenceValue + " is Available in table.", "AccountHistoryPage.", "True", ApplicationHandlerFactory.GetApplication(ApplicationType.WEB));
            }
        }


        //created this BF for PDOC-16753 Validation
        public virtual string CalculateAccruedInterest(string AccountNumber, string principalAmount, string intRate, int numberOfDaysPassed, int Roundoff = 5)
        {
            LoadAccountSummaryPage(AccountNumber);
            NavigatetoInterestAccrualPage();
            string Date = Profile7CommonLibrary.GetApplicationDate();
            string AccrInterest = "";
            double AccruedInterest = 0;
            string AFVal = Data.Get("AnnualFactor");
            double AF = Convert.ToDouble(AFVal);
            int numberOfDaysInYear = 0;
            if (string.IsNullOrEmpty(Date))
            {
                Date = GetApplicationDate();
            }
            string yearparam = appHandle.GetDateParameters(Date)[2].Trim();
            if (appHandle.IsLeapYear(Int32.Parse(yearparam)))
            {
                numberOfDaysInYear = 366;
            }
            else
            {
                numberOfDaysInYear = 365;
            }
            int numberofDaysInMonth = GetNumberOfDaysInAMonth(Date);
            AccruedInterest = Convert.ToDouble(principalAmount) * Convert.ToDouble(intRate);
            AccruedInterest = AccruedInterest / numberOfDaysInYear;
            AccruedInterest = AccruedInterest / Convert.ToDouble((string)Data.Get("GLOBAL_VALUE_100"));
            AccruedInterest = Math.Round(AccruedInterest, Roundoff);
            AccruedInterest = AccruedInterest * numberOfDaysPassed;
            AccrInterest = AccruedInterest.ToString();
            return AccrInterest;
        }
        
        public virtual void DeleteStopsForSpecifiedAccountNumber(string AccountNumber, string date, bool Override = false, string OverrideTranMsgs = "")
        {
            GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Stops"));
            WebCSRPageFactory.StopsPage.SelectAccountFromDropdown(AccountNumber);
            WebCSRPageFactory.StopsPage.DeleteStopsFromTable(date);
            if (Override)
            {
                if (!string.IsNullOrEmpty(OverrideTranMsgs))
                {
                    this.VerifyAuthorizationMessage(OverrideTranMsgs);
                }
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.EnterUserCredentials();
                Report.Info("User credentials are entered for Authorization override.", "userEntry", "true", appHandle);
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.ClickOnOverrideButton();
                appHandle.SwitchTo(SwitchInto.ALERT);
                appHandle.Wait_For_Specified_Time(3);
                appHandle.PerformActionOnAlert(PopUpAction.Accept);
                appHandle.SwitchTo(SwitchInto.DEFAULT);
            }
            if (WebCSRPageFactory.HoldsPage.VerifyMSGInHoldsPage(Data.Get("The stop has been deleted.")))
            {

                Report.Pass(Data.Get("The stop has been deleted.") + " is successfully verified.", "verifyholdmsg", "true", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("The stop has been deleted.") + " is not successfully verified.", "verifyholdmsgfail", "true", appHandle, true);
            }

        }
        public virtual void DeleteBeneficiaryForSpecifiedAccountNumber(string AccountNumber, string BeneficiaryID, bool Override = false, string OverrideTranMsgs = "")
        {
            GetAccount(AccountNumber);
            this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Beneficiaries"));
            WebCSRPageFactory.BeneficiariesPage.selectAccountFromDropdown(AccountNumber);
            WebCSRPageFactory.AddBeneficiaryPage.DeleteBeneficiaryForSpecifiedAccountnumber(BeneficiaryID);
            WebCSRPageFactory.WebCSRMasterPage.ClickOnDeleteButton();
            if (Override)
            {
                if (!string.IsNullOrEmpty(OverrideTranMsgs))
                {
                    this.VerifyAuthorizationMessage(OverrideTranMsgs);
                }
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.EnterUserCredentials();
                Report.Info("User credentials are entered for Authorization override.", "userEntry", "true", appHandle);
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.ClickOnOverrideButton();
                appHandle.SwitchTo(SwitchInto.ALERT);
                appHandle.Wait_For_Specified_Time(3);
                appHandle.PerformActionOnAlert(PopUpAction.Accept);
                appHandle.SwitchTo(SwitchInto.DEFAULT);

            }
            if (WebCSRPageFactory.HoldsPage.VerifyMSGInHoldsPage(Data.Get("The beneficiary has been deleted.")))
            {

                Report.Pass(Data.Get("The beneficiary has been deleted.") + " is successfully verified.", "verifyholdmsg", "true", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("The beneficiary has been deleted.") + " is not successfully verified.", "verifyholdmsgfail", "true", appHandle, true);
            }

        }

        public virtual void DeleteRestrictionsForSpecifiedAccountNumber(string AccountNumber, string date, bool Override = false, string OverrideTranMsgs = "")
        {
            if (!appHandle.GetTitle().Contains("Restrictions"))
            {
                this.GetAccount(AccountNumber);
                this.ClickLinkFromMenuItem(Data.Get("General Account Services") + "|" + Data.Get("Restrictions"));
            }
            WebCSRPageFactory.AccountRestrictionPage.SelectAccountfromAccountsDropdown(AccountNumber);
            WebCSRPageFactory.AccountRestrictionPage.DeleteRestrictionFromTable(date);
            if (Override)
            {
                if (!string.IsNullOrEmpty(OverrideTranMsgs))
                {
                    this.VerifyAuthorizationMessage(OverrideTranMsgs);
                }
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.EnterUserCredentials();
                Report.Info("User credentials are entered for Authorization override.", "userEntry", "true", appHandle);
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.ClickOnOverrideButton();
                appHandle.SwitchTo(SwitchInto.ALERT);
                appHandle.Wait_For_Specified_Time(3);
                appHandle.PerformActionOnAlert(PopUpAction.Accept);
                appHandle.SwitchTo(SwitchInto.DEFAULT);
            }
            if (WebCSRPageFactory.HoldsPage.VerifyMSGInHoldsPage(Data.Get("The restriction has been deleted.")))
            {

                Report.Pass(Data.Get("The restriction has been deleted.") + " is successfully verified.", "verifyholdmsg", "true", appHandle);
            }
            else
            {
                Report.Fail(Data.Get("The restriction has been deleted.") + " is not successfully verified.", "verifyholdmsgfail", "true", appHandle, true);
            }

        }

        public virtual void EnterLoanAccountServicesPaymentChangePageOptions(string Acc = " ", string Pymntfqcng = " ", string IntCollMthd = " ", string Msg = "", bool Override = false, string sUSerID = "", string sPassword = "", string OverrideTranMsgs = "")
        {

            WebCSRPageFactory.LoanAccountServicesPaymentChangePage.EnterPaymentChangePageOptions(Acc, Pymntfqcng, IntCollMthd);
            appHandle.WaitForSpecifiedTime(5);
            WebCSRPageFactory.LoanAccountServicesPaymentChangePage.SelectSubmitButton();

            if (!string.IsNullOrEmpty(Msg))
            {


                if (WebCSRPageFactory.LoanAccountServicesPaymentChangePage.VerifyMessagePaymentChangePage(Msg))
                {
                    Report.Pass("Loan Payment Change Page Details are updated sucessfully.", "LoanPaymentChangeUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Loan Payment Change Page Details are failed to update.", "LoanPaymentChangeNotUpdated", "True", appHandle, true);
                }
            }

            if (Override)
            {
                if (!string.IsNullOrEmpty(OverrideTranMsgs))
                {
                    this.VerifyAuthorizationMessage(OverrideTranMsgs);
                }
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.EnterUserCredentials(sUSerID, sPassword);
                Report.Info("User credentials are entered for Authorization override.", "userEntry", "true", appHandle);
                WebCSRPageFactory.AuthorizationOverrideRequiredPage.ClickOnOverrideButton();
                WebCSRPageFactory.FundTransferPage.ClickOnSubmitButton_OverrideTransaction();
            }

        }

        public virtual void EnterLoanAccountServicesLoanCalculatorPageOptions(string Type = " ", string Dismntdt = " ", string PymtFqy = " ", string FirstScheduledPymnt = "", string LnAmt = "", string IntRate = "", string Payment = "", string Message = "")
        {

            WebCSRPageFactory.LoanCalculatorPage.SelectLoanCalculatorLink();
            WebCSRPageFactory.LoanCalculatorPage.EnterLoanCalculatorPageOptions(Type, Dismntdt, PymtFqy, FirstScheduledPymnt, LnAmt, IntRate, Payment);
            appHandle.WaitForSpecifiedTime(5);
            WebCSRPageFactory.LoanCalculatorPage.SelectSubmitButton();

            if (!string.IsNullOrEmpty(Message))
            {


                if (WebCSRPageFactory.LoanCalculatorPage.VerifyMessageLoanCalculatorPage(Message))
                {
                    Report.Pass("Loan Payment Change Page Details are updated sucessfully.", "LoanPaymentChangeUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Loan Payment Change Page Details are failed to update.", "LoanPaymentChangeNotUpdated", "True", appHandle, true);
                }
            }
        }

        public virtual void VerifyLoanCalculatorAmortizationTerm(string AmortizationTerm)
        {

            if (WebCSRPageFactory.LoanCalculatorPage.VerifyAmortizationTerm(AmortizationTerm))
            {
                Report.Pass("Amortization Term is displayed corrcetly.", "VerifyAmtTerm", "True", appHandle);
            }
            else
            {
                Report.Fail("Amortization Term is not displayed corrcetly.", "VerifyAmtTerm", "True", appHandle, true);
            }
        }


        public virtual void EnterAccountInformationDelinquencyNonaccrualPageOptions(string Commtprc = "", string Msg = "")
        {

            WebCSRPageFactory.DelinquencyNonaccrualPage.EnterDelinquencyNonaccrualPageOptions(Commtprc);
            appHandle.WaitForSpecifiedTime(5);
            WebCSRPageFactory.DelinquencyNonaccrualPage.SelectSubmitButton();
            if (!string.IsNullOrEmpty(Msg))
            {
                if (WebCSRPageFactory.DelinquencyNonaccrualPage.VerifyMessageDepositPaymentPage(Msg))
                {
                    Report.Pass("Delinquency Nonaccrual Page Details are updated sucessfully.", "NonaccrualPageUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Delinquency Nonaccrual Page Details are failed to update.", "NonaccrualPageNotUpdated", "True", appHandle, true);
                }
            }
        }

        public virtual void EnterAccountInformationLoanCommitmentProcessingPageOptions(string NonAccuralopt = "", string Msg = "")
        {

            WebCSRPageFactory.LoanCommitmentProcessingPage.EnterLoanCommitmentProcessingPageOptions(NonAccuralopt);
            appHandle.WaitForSpecifiedTime(5);
            WebCSRPageFactory.LoanCommitmentProcessingPage.SelectSubmitButton();
            if (!string.IsNullOrEmpty(Msg))
            {

                if (WebCSRPageFactory.LoanCommitmentProcessingPage.VerifyMessageLoanCommitmentProcessingPage(Msg))
                {
                    Report.Pass("Loan Commitment Processing Page Details are updated sucessfully.", "LoanCommitmentProcessingPageUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Loan Commitment Processing Page Details are failed to update.", "LoanCommitmentProcessingPageNotUpdated", "True", appHandle, true);
                }
            }
        }
        public virtual void EnterLoanAccountServicesEFDRateChangePageOptions(string Account = " ", string EffectiveDate = " ", string InterestIndex = " ", string InterestChangeFrequency = "", string RateChangeMethod = "", string Message = "")
        {
            WebCSRPageFactory.EFDRateChangePage.SelectLoanEFDRateChangeLink();
            WebCSRPageFactory.EFDRateChangePage.EnterLoanEFDRateChangePageOptions(Account, EffectiveDate, InterestIndex, InterestChangeFrequency, RateChangeMethod, Message);
            appHandle.WaitForSpecifiedTime(5);
            WebCSRPageFactory.EFDRateChangePage.SelectSubmitButton();

            if (!string.IsNullOrEmpty(Message))
            {


                if (WebCSRPageFactory.EFDRateChangePage.VerifyMessageLoanEFDRateChange(Message))
                {
                    Report.Pass("Loan EFD Rate Change Page Details are updated sucessfully.", "LoanEFDRateChangePageUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Loan EFD Rate Change Page Details are failed to update.", "LoanEFDRateChangePageNotUpdated", "True", appHandle, true);
                }
            }

        }

        public virtual void VerifyCustomerShortNameUpdatedonLoanAccountTitleAddressPage(string AccountNumber, string CustomerShortNamelabel, string CustomerShortName, string Message = "")
        {
            LoadAccountSummaryPage(AccountNumber);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Title/Address"));
            if (!string.IsNullOrEmpty(CustomerShortNamelabel))
            {
                Profile7CommonLibrary.VerifyValueByLabelNameLabelValue(CustomerShortNamelabel);
            }
            WebCSRPageFactory.LoanTitleAddressPage.EnterCustomerShortName(CustomerShortName);

            WebCSRPageFactory.LoanTitleAddressPage.ClickOnSubmitButton();
            if (!string.IsNullOrEmpty(Message))
            {
                if (WebCSRPageFactory.LoanTitleAddressPage.VerifyMessageTitleAddressPage(Message))
                {
                    Report.Pass("Customer Short Name is updated sucessfully.", "LoanTitleAddressUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Customer Short Name is failed to update.", "LoanTitleAddressNotUpdated", "True", appHandle, true);
                }
            }
        }

             
        public virtual void VerifyCustomerShortNameUpdatedonDepositAccountTitleAddressPage(string AccountNumber, string CustomerShortNamelabel, string CustomerShortName, string Message = "")
        {
            get_account(AccountNumber);

            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Title/Address"));
            if (!string.IsNullOrEmpty(CustomerShortNamelabel))
            {
                Profile7CommonLibrary.VerifyValueByLabelNameLabelValue(CustomerShortNamelabel);
            }
            WebCSRPageFactory.DepositTitleAddressPage.EnterCustomerShortName(CustomerShortName);

            WebCSRPageFactory.DepositTitleAddressPage.ClickOnSubmitButton();

            if (!string.IsNullOrEmpty(Message))
            {

                if (WebCSRPageFactory.DepositTitleAddressPage.VerifyMessageTitleAddressPage(Message))
                {
                    Report.Pass("Customer Short Name is updated sucessfully.", "DepositTitleAddressUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Customer Short Name is failed to update.", "DepositTitleAddressNotUpdated", "True", appHandle, true);
                }
            }
        }

        public virtual void UpdateUseridInCustomerInformationPage(string customerno, string CustUserid)
        {
            GetCustomer(customerno);
            SelectCustomerVerificationActionVerifyCustomerPage(Data.Get("GLOBAL_CUSTOMER_INFORMATION"));
            Profile7CommonLibrary.SelectTabSubTabInApplication("Security");
            WebCSRPageFactory.CustomerInformationPage.VerifyCustomerInformationPageLoads();            
            WebCSRPageFactory.CustomerInformationPage.UpdateCustUserid(CustUserid);
            WebCSRPageFactory.CustomerInformationPage.ClickOnSubmitButton();
            if (WebCSRPageFactory.CustomerInformationPage.VerifyMessageCustomerInformationPage("User ID is already in use."))
            {
                Report.Pass("Verify that Error 'User ID is already in use' is displayed when tried to update Customer-Userid field , which is of another customer", "CreditThresholdupdate", "True", appHandle);
            }                
            else if(WebCSRPageFactory.CustomerInformationPage.VerifyMessageCustomerInformationPage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
            {
                Report.Pass("User Id field is updated successfully.", "CreditThresholdupdate", "True", appHandle);
            }
            else
            {
                Report.Fail("User id field is not updated.", "CreditThresholdupdate", "True", appHandle,true);
            }
            
        }
        public virtual string GetCustomerID(string customerno)
        {
            string userid = Profile7CommonLibrary.ExtractDataFromDataBase("select USERID1 from CIFAUTH where ACN = '" + customerno + "'", "USERID1");
            appHandle.Wait_For_Specified_Time(4);
            return userid;
        }
        public virtual void UpdateLoanCapitalizationPageOption(string lAcctNumber, string sLabelNameLabelValuePipeDelimited)
        {
            if (appHandle.GetTitle().Contains(Data.Get("Account Information"))) { }
            else
            {
                LoadAccountSummaryPage(lAcctNumber);
            }
            Profile7CommonLibrary.SelectTabSubTabInApplication(Data.Get("Interest"), Data.Get("Capitalization"));
            if (WebCSRPageFactory.LoanCapitalizationPage.WaitUntilLoanCapitalizationPageLoad())
			{
                WebCSRPageFactory.LoanCapitalizationPage.EnterValuesForCapitalizationPageField(sLabelNameLabelValuePipeDelimited);
                
                if (WebCSRPageFactory.LoanCapitalizationPage.VerifyMessageInCapitalizationPagePage(Data.Get("GLOBAL_INFORMATION_UPDATED")))
                {
                    Report.Pass("Capitalization fields are updated in Interest Capitalization Page.", "CapitalizationFieldsUpdated", "True", appHandle);
                }
                else
                {
                    Report.Fail("Capitalization fields are not updated in Interest Capitalization Page.", "CapitalizationFieldsNotUpdated", "True", appHandle, true);
                }
			}
        }  



    }
        }
        

    
    
