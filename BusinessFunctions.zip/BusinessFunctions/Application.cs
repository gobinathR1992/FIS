﻿using System.Diagnostics;
using GTS_OSAF.Config;
using Profile7Automation.BusinessFunctions.Applications;
using Spring.Aop.Framework;
using Profile7Automation.BusinessFunctions.Applications;

namespace Profile7Automation.BusinessFunctions
{
    [DebuggerStepThrough] 
    class Application
    {

        public static WebAdmin WebAdmin { get => (WebAdmin)ClassRegister.Get(typeof(WebAdmin)); }
        public static Teller Teller { get => (Teller)ClassRegister.Get(typeof(Teller)); }
      
        public static WebCSR WebCSR { get => (WebCSR)ClassRegister.Get(typeof(WebCSR)); }
       // public static ProfileHost ProfileHost { get => (ProfileHost)ClassRegister.Get(typeof(ProfileHost)); }
       


    }
}
