using System;
using System.Diagnostics;
using System.Threading;
using GTS_OSAF.CoreLibs;
using GTS_OSAF.HelperLibs.DataAdapter;
//using GTS_OSAF.CoreLibs.Web;
using GTS_OSAF.Util;
using OpenQA.Selenium;
using System.Linq;
using System.IO;
using GTS_OSAF;
using System.Collections.Generic;
using GTS_OSAF.HelperLibs.Reporter;
using Profile7Automation.ObjectFactory.WebAdmin.Pages;
using System.Globalization;
using System.Xml;
using Profile7Automation.BusinessFunctions;
using Profile7Automation.Libraries.Util;


namespace Profile7Automation.Libraries.Util
{
    public class Profile7CommonLibrary
    {
       // static HostApplication oHost = ApplicationHandlerFactory.GetApplication(ApplicationType.HOST);
        static string UID = StartupConfiguration.EnvironmentDetails.GLOBAL_USERID;
        static string PWD = StartupConfiguration.EnvironmentDetails.GLOBAL_PASSWORD;
        static string SQLPath = StartupConfiguration.EnvironmentDetails.SQLPath;
        static WindowsApplication WindowHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.Windows);
        private static WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
        static SSHApplication WinSCPHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.SECURESHELL);
        static string nnnn = appHandle.CreateRamdomData(FieldType.NUMERIC, 1111, 9999) + "";
        static string strHostName = StartupConfiguration.EnvironmentDetails.RemoteServerName;
        static string DBURL = StartupConfiguration.EnvironmentDetails.DBURL;
        private static string SysDate = GetApplicationDate();
        public static bool WaitForSpecifiedObjectExists(string objectName, int strCounter = 60)
        {
            bool Result = false;
            int counter = 0;
            int MaxTimeInSeconds = 5000;

            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            do
            {
                appHandle.UpdateSyncInApplicaion(false, false);
                if (appHandle.IsObjectEnabled(objectName))
                {
                    Result = true;
                    appHandle.WaitUntilElementVisible(objectName, MaxTimeInSeconds);
                    appHandle.WaitUntilElementClickable(objectName, MaxTimeInSeconds);
                    break;
                }
                else
                {
                    appHandle.Wait_For_Specified_Time(1);
                    counter++;
                }
            }
            while ((appHandle.IsObjectExists(objectName) == true) || (counter != strCounter));

            return Result;

        }
        public static void KillProcessByProcessName(string ProcessName)
        {
            try
            {
                appHandle.CloseAllBrowser();
            }
            catch (Exception e) { }


        }
        public static string GetApplicationURL()
        {
            string url = "";
            IWebDriver CurrentDriver = (IWebDriver)appHandle.GetWebDriver();

            url = CurrentDriver.Url.Trim();


            return url;
        }
        public static void SelectDropdownSpecifiedRow(string sDropdownObject, int rownumber)
        {
            appHandle.SelectDropdownValueByIndex(sDropdownObject, rownumber);
        }
        /// <summary>
        /// This returns past date or future date based on  provided date ,dateformat, number of days/years/months .
        /// </summary>
        /// <param name="sInputDate"></param>
        /// <param name="sDateParameter"></param>
        /// <param name="sNumber"></param>
        /// <returns></returns>
        public static string CalculateBackOrFutureDateFromApplication(string sInputDate, string sDateParameter, int sNumber)
        {
            return appHandle.CalculateNewDate(sInputDate, sInputDate, sNumber);
        }
        public static string GenerateRandomNumberSpecifiedFormat(string sInputformat, string sDelimiter)
        {
            return RandomNumberGenerator.GenerateRandomNumberByFormat(sInputformat, sDelimiter);
        }
        public static bool CheckEditLength(string objField, int expectedlength)
        {
            bool Result = false;
            Result = appHandle.CheckFieldLength(objField, expectedlength);
            return Result;
        }
        public static bool CheckRadiobuttonSelected(string objName)
        {
            return appHandle.CheckRadiobuttonSelected(objName);
        }
        public static bool CheckDropdownSpecifiedValueExistsTrue(string sDropdownObject, string sSpecifiedValue)
        {
            return appHandle.CheckSelectedValueExistsInDropdown(sDropdownObject, sSpecifiedValue);
        }
        public static bool CheckDropdownValueExistsFalse(string sDropdownObject, string sSpecifiedValue)
        {
            bool Result = false;
            if (appHandle.CheckSelectedValueExistsInDropdown(sDropdownObject, sSpecifiedValue) == false)
            {
                Result = true;

            }
            return Result;
        }
        public static bool CheckSpecifiedTextNotExistsInTable(string sTableObj, string sSpecifiedText)
        {
            bool Result = false;
            if (appHandle.CheckTextExistsInTable(sTableObj, sSpecifiedText) == false)
            {
                Result = true;
            }
            return Result;
        }
        public static bool VerifyWindowObjectExists(string sWindowObj, int strCounter = 100)
        {
            bool Result = false;
            int counter = 0;
            do
            {
                if (WindowHandle.IsObjectExists(sWindowObj)
                && WindowHandle.IsObjectEnabled(sWindowObj))
                {
                    Result = true;
                    break;
                }
                else
                {
                    counter++;
                }
            }
            while (counter != strCounter);
            return Result;
        }
        /// <summary>
        /// This method is used to click on tab  and sub tab by Main Tab Name and Sub Tab name. Default value of SubTab is "" as in few cases it is not required to select sub tab. 
        /// This can be used in WebCSR, WebAdmin.
        /// Example:
        /// Profile7CommonLibrary.SelectTabSubTabInApplication("Transaction Processing","Commitment Processing");
        /// </summary>
        /// <param name="sMainTabInput"></param>
        /// <param name="sSubTabInput"></param>
        public static void SelectTabSubTabInApplication(string sMainTabInput, string sSubTabInput = "")
        {
            string RunTimeMainTabObj = "XPath;//table[contains(@class,'tab')]/descendant::td[text()='" + sMainTabInput + "']";
            string RunTimeSubTabObj = RunTimeMainTabObj + "/ancestor::tr/following-sibling::tr/descendant::*[@class='tabSub'][text()='" + sSubTabInput + "']";
            string MainTabStatus = appHandle.GetSpecifiedObjectAttribute(RunTimeMainTabObj + "/ancestor::table[1]", "class");

            if (MainTabStatus.Equals(Data.Get("tabSelected")))
            {
                if (string.IsNullOrEmpty(sSubTabInput) == false)
                {
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeSubTabObj);
                    appHandle.ClickObjectViaJavaScript(RunTimeSubTabObj);
                }
            }
            else
            {
                Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeMainTabObj);
                appHandle.ClickObjectViaJavaScript(RunTimeMainTabObj);
                if (string.IsNullOrEmpty(sSubTabInput) == false)
                {
                    Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeSubTabObj);
                    appHandle.ClickObjectViaJavaScript(RunTimeSubTabObj);
                }
            }

        }
        public static bool VerifyTableDataByLableNameLabelValue(string tableObj, string LabelNameLableValuePipeDelimited)
        {
            string tempstat = "";
            int passcount = 0;
            bool Result = false;
            string LabelName = "";
            string LabelValue = "";
            string temp = "";
            string[] arr = null;
            if (LabelNameLableValuePipeDelimited.Contains(":")) { LabelNameLableValuePipeDelimited = LabelNameLableValuePipeDelimited.Replace(":", string.Empty); }
            int rowscount = appHandle.GetRowCountfromList(tableObj);
            LabelNameLableValuePipeDelimited = LabelNameLableValuePipeDelimited + ";";
            arr = LabelNameLableValuePipeDelimited.Split(';');

            for (int i = 0; i < arr.Length - 1; i++)
            {
                LabelName = arr[i].Split('|')[0];
                LabelValue = arr[i].Split('|')[1];

                for (int j = 1; j <= rowscount; j++)
                {
                    if (tempstat.Equals(LabelName + "-Done"))
                    {
                        tempstat = "";
                        break;
                    }
                    temp = appHandle.GetObjectText(tableObj + "/tr[" + j + "]");
                    if (temp.Contains(LabelName) && temp.Contains(LabelValue))
                    {
                        string[] newarr = temp.Split(new string[] { "\r\n" }, StringSplitOptions.None);
                        for (int k = 0; k < newarr.Length; k++)
                        {
                            if (newarr[k].Trim().Contains(":"))
                            {
                                if (newarr[k].Trim().Split(':')[0].Contains(LabelName.Trim())
                                && newarr[k].Trim().Split(':')[1].Contains(LabelValue.Trim()))
                                {
                                    Result = true;
                                    passcount++;
                                    tempstat = LabelName + "-Done";
                                    break;
                                }
                            }

                        }

                    }
                    if (passcount == arr.Length - 1)
                    {
                        break;
                    }
                }
            }

            return Result;
        }
        public static bool VerifyDataInTableByColumnValues(string sColumnValues, int CounterToCheckUntilElementFound = 60)

        {
            bool Result = false;
            string RunTimeTableObjSpecifiedValue = "";
            string[] ColValArr = sColumnValues.Split(new string[] { ";" }, StringSplitOptions.None);
            for (int b = 0; b < ColValArr.Length; b++)
            {
                RunTimeTableObjSpecifiedValue = RunTimeTableObjSpecifiedValue + "*[contains(text(),'" + ColValArr[b] + "')]/ancestor::tr[1]/descendant::";
            }
            RunTimeTableObjSpecifiedValue = "XPath;//" + RunTimeTableObjSpecifiedValue.Substring(0, RunTimeTableObjSpecifiedValue.Length - 1);
            RunTimeTableObjSpecifiedValue = RunTimeTableObjSpecifiedValue.Substring(0, (RunTimeTableObjSpecifiedValue.Length - "/descendant::".Length));
            RunTimeTableObjSpecifiedValue = RunTimeTableObjSpecifiedValue + "]";
            if (WaitForSpecifiedObjectExists(RunTimeTableObjSpecifiedValue, CounterToCheckUntilElementFound))
            {
                appHandle.ScrollToObject(RunTimeTableObjSpecifiedValue);
                Result = true;


            }
            return Result;
        }


        public static string ConvertNumberToCurrencyByCommaFormat(string sInputNumber)
        {
            string Out = "";
            Out = Convert.ToDecimal(sInputNumber).ToString("#,##0.00") + "";
            return Out;
        }
        /// <summary>
        /// Verify selected Dropdown value by label name.It is applicable for WebCSR and WebAdmin .
        /// </summary>
        /// <param name="LabelNameDropdownValuePipeDelimited"></param>
        /// <returns>true or false</returns>
        public static bool VerifyDropdownValueByLabelNameDropdownItemValue(string LabelNameDropdownValuePipeDelimited)
        {
            bool Result = false;
            int MatchCount = 0;

            LabelNameDropdownValuePipeDelimited = LabelNameDropdownValuePipeDelimited + ";";
            string[] arr = LabelNameDropdownValuePipeDelimited.Split(';');
            for (int a = 0; a < arr.Length - 1; a++)
            {
                string LabelName = arr[a].Split('|')[0];
                string DropdownItemValue = arr[a].Split('|')[1];
                string RunTimeDropdownObj = "XPath;//*[contains(text(),'" + LabelName + "')]/following-sibling::*/descendant::select[1]";
                if (WaitForSpecifiedObjectExists(RunTimeDropdownObj))
                {

                    if (appHandle.GetDropdownSelectedValue(RunTimeDropdownObj).Contains(DropdownItemValue))
                    {
                        MatchCount++;
                    }
                }
                if (MatchCount == arr.Length - 1)
                {
                    Result = true;
                    break;
                }
            }

            return Result;
        }
        public static bool WaitForWindowObjectByText(string strText, int Counter = 500)
        {
            bool Result = false;
            if (VerifyWindowObjectExists("ClassName=Static;Text=" + strText, Counter))
            {
                Result = true;
            }

            return Result;
        }

        public static void EnterDataByLabelNameLabelValue(string strLabelNamePipeDelimitedLabelValue)
        {
            string tagname = "";
            strLabelNamePipeDelimitedLabelValue = strLabelNamePipeDelimitedLabelValue + ";";
            string[] arr = strLabelNamePipeDelimitedLabelValue.Split(';');
            for (int a = 0; a < arr.Length - 1; a++)
            {
                string LabelName = arr[a].Split('|')[0];
                string LabelValue = arr[a].Split('|')[1];
                string RunTimeObj = "XPath;//*[contains(text(),'" + LabelName + "')]/ancestor::*[1]/following-sibling::*/*[1]";
                if (WaitForSpecifiedObjectExists(RunTimeObj))
                {
                    try
                    {
                        IWebElement obj = (IWebElement)appHandle.FindElement(RunTimeObj);
                        tagname = obj.TagName;
                        if (tagname.Trim().ToUpper().Equals("SELECT"))
                        {
                            if (LabelValue == "")
                            {
                                appHandle.SelectDropdownSpecifiedValue(RunTimeObj, LabelValue);
                            }
                            else
                            {
                                appHandle.SelectDropdownSpecifiedValueByPartialText(RunTimeObj, LabelValue);
                            }
                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            if (LabelValue.Equals("ON"))
                            {
                                if (appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                }
                            }
                            else
                            {
                                if (!appHandle.CheckCheckBoxChecked(RunTimeObj)) { }
                                else
                                {
                                    appHandle.ClickObjectViaJavaScript(RunTimeObj);
                                }
                            }

                        }
                        if (tagname.Trim().ToUpper().Equals("INPUT")
                        && !appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                        {
                            appHandle.Set_field_value(RunTimeObj, LabelValue);
                        }
                    }
                    catch (Exception e) { }
                }
            }
        }

        public static string ExtractDataFromDataBase(string SQLQuery, string ExpectedColumnName, int RowNumber = 1)
        {
            string output = "";
            int RefColNumber = 0;
            int colSize = 0;
            string[] arr1 = null;
            string[,] CSVFileData = null;
            CreateSQLConfigPropertiesFile(SQLQuery);
            bool ExecutionStatus = ExecuteJARFIle();
            if (ExecutionStatus)
            {
                string[] ALlLines = File.ReadAllLines(SQLPath + "\\SQLResult.csv");

                int rowSize = ALlLines.Length;
                if (ALlLines[0].Contains(","))
                {
                    arr1 = ALlLines[0].Split(',');
                    colSize = arr1.Length;
                    for (int a = 0; a < arr1.Length; a++)
                    {
                        if (arr1[a].Trim().Equals(ExpectedColumnName))
                        {
                            RefColNumber = a;
                            break;
                        }
                    }
                }
                else
                {
                    colSize = 0;
                }
                CSVFileData = new string[rowSize, colSize];

                for (int b = 0; b < rowSize; b++)
                {
                    if (colSize >= 1)
                    {
                        for (int c = 0; c < colSize; c++)
                        {
                            if (!ALlLines[b].Contains(","))
                            {
                                CSVFileData[b, c] = string.Empty;
                            }
                            else
                            {
                                CSVFileData[b, c] = ALlLines[b].Split(',')[c].Trim();

                            }
                        }
                    }
                    else
                    {
                        output = ALlLines[RowNumber + 1].Trim();
                        break;
                    }

                }
                if (ALlLines[0].Contains(","))
                {
                    output = CSVFileData[RowNumber + 1, RefColNumber].Trim();

                }

            }

            return output;
        }
        public static void CreateSQLConfigPropertiesFile(string sSQLQuery)
        {
            Report.Info("Inside db method....");
            string Line1 = "#Query Configuration";
            string Line2 = "execute.query.string= " + sSQLQuery;
            Report.Info("Query...." +sSQLQuery);
            string Line3 = "#Output";
            string Line4 = "query.output.result.display.consol=false";
            string Line5 = "query.output.result.file.name=" + "SQLResult.csv";
            string Line6 = "query.output.result.out.file.name=" + "Data_Const_Temp.txt";
            string Line7 = "query.output.result.max= 150";
            string Line8 = "#DB Configuration";
            string Line9 = "database.driver.class=" + "fisglobal.jdbc.driver.ScDriver";
            string Line10 = "database.user.name=" + "1";
            string Line11 = "database.user.password=" + "xxxx";
            string Line12 = "database.URL=" + "Test-upgrade-Islamic";
            string paths = System.IO.Path.GetTempPath();
            string sPropertiesFilePath = SQLPath;
            if (File.Exists(sPropertiesFilePath + "\\Config.properties"))
            {
                for (int i = 1; i < 500; i++)
                {
                    try
                    {
                        File.Delete(sPropertiesFilePath + "\\Config.properties");
                        if (!File.Exists(sPropertiesFilePath + "\\Config.properties")) { break; }
                    }
                    catch (Exception e) { }
                }
            }
            string[] lines = { Line1, Line2, Line3, Line4, Line5, Line6, Line7, Line8, Line9, Line10, Line11, Line12 };
            StreamWriter OutputFile = new StreamWriter(sPropertiesFilePath + "\\Config.properties");
            foreach (string line in lines)
            {
                OutputFile.WriteLine(line);
            }
            OutputFile.Close();
        }
        private static bool ExecuteJARFIle()
        {
            string temp = "";
            if (File.Exists(SQLPath + "\\Data_Const_Temp.txt"))
            {
                for (int i = 1; i < 500; i++)
                {
                    try
                    {
                        File.Delete(SQLPath + "\\Data_Const_Temp.txt");
                        if (!File.Exists(SQLPath + "\\Data_Const_Temp.txt")) { break; }
                    }
                    catch (Exception e) { }
                }
            }
            if (File.Exists(SQLPath + "\\jdbc_debug.jrnl"))
            {
                for (int i = 1; i < 500; i++)
                {
                    try
                    {
                        File.Delete(SQLPath + "\\jdbc_debug.jrnl");
                        if (!File.Exists(SQLPath + "\\jdbc_debug.jrnl")) { break; }
                    }
                    catch (Exception e) { }
                }
            }
            if (File.Exists(SQLPath + "\\jdbc_error.log"))
            {
                for (int i = 1; i < 500; i++)
                {
                    try
                    {
                        File.Delete(SQLPath + "\\jdbc_error.log");
                        if (!File.Exists(SQLPath + "\\jdbc_error.log")) { break; }
                    }
                    catch (Exception e) { }
                }
            }
            if (File.Exists(SQLPath + "\\SQLResult.csv"))
            {
                for (int i = 1; i < 500; i++)
                {
                    try
                    {
                        File.Delete(SQLPath + "\\SQLResult.csv");
                        if (!File.Exists(SQLPath + "\\SQLResult.csv")) { break; }
                    }
                    catch (Exception e) { }
                }
            }

            bool Result = false;
            var startInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true,
            };
            var process = new Process { StartInfo = startInfo };
            process.Start();
            process.StandardInput.WriteLine("cd /d " + Path.GetFullPath(SQLPath));
            process.StandardInput.WriteLine(" java -jar SqlJar.jar");
            process.Close();
            for (int a = 1; a <= 500; a++)
            {
                try
                {
                    if (new FileInfo(SQLPath + "\\Data_Const_Temp.txt").Length >= 1)
                    {
                        temp = File.ReadAllText(SQLPath + "\\Data_Const_Temp.txt");
                        if (temp.Contains("SQL_DATARETRIEVED = \"" + "True" + "\""))
                        {
                            Result = true;
                            break;
                        }
                    }
                }
                catch (Exception e) { };

            }
            return Result;
        }
        public static string GetApplicationDate()
        {
            string Dateval = "";
            Dateval = ExtractDataFromDataBase("SELECT TJD FROM CUVAR", "TJD");
            Dateval = Dateval.Split('-')[1] + "/" + Dateval.Split('-')[2] + "/" + Dateval.Split('-')[0];
            return Dateval;
        }
        internal static string AddLeadingSpacesForSpecificLength(string InputString, int SpecifiedLength)
        {
            string Result = "";
            int strLen = InputString.Length;
            int diffLen = SpecifiedLength - strLen;
            if (diffLen != 0)
            {
                for (int i = 1; i <= diffLen; i++)
                {
                    Result = Result + " ";
                }
            }
            return Result = InputString + Result;
        }
        internal static string AddTrailerZerosForSpecifiedLength(string InputString, int SpecifiedLength)
        {
            string Result = "";
            if (InputString.Contains("."))
            {
                InputString = InputString.Replace(".", string.Empty);
            }
            int strLen = InputString.Length;
            int diffLen = SpecifiedLength - strLen;
            if (diffLen != 0)
            {
                for (int i = 1; i <= diffLen; i++)
                {
                    Result = Result + "0";
                }
            }
            return Result = Result + InputString;
        }
        internal static string CreateBlankStringSpecifiedLength(int SpecifiedLength)
        {
            string Result = "";
            for (int i = 1; i <= SpecifiedLength; i++)
            {
                Result = Result + " ";
            }

            return Result;
        }
        internal static string CreateZEROStringSpecifiedLength(int SpecifiedLength)
        {
            string Result = "";
            for (int i = 1; i <= SpecifiedLength; i++)
            {
                Result = Result + "0";
            }

            return Result;
        }
        internal static string GetDateInYYMMDDFormat(string InputDate)
        {
            appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);

            string TempDate = appHandle.ConvertDateInGivenFormat(InputDate, "s");
            string[] TempDateArr = TempDate.Split('T');
            TempDate = TempDateArr[0].Trim();
            TempDate = TempDate.Replace("-", "");
            TempDate = TempDate.Substring(2, TempDate.Length - 2);
            return TempDate;
        }
        
       
       
        public static bool VerifyFederalWithHoldingExtract(string ExtractFileWithPath, string UniqueReferenceValues, string ExpectedValuePositionRange, string ExpectedDataToBeValidated)
        {
            bool Result = false;
            if (ExpectedDataToBeValidated.Contains("."))
            {
                ExpectedDataToBeValidated = ExpectedDataToBeValidated.Replace(".", string.Empty);
            }
            Result = VerifyDataPresentInFileByPosition(ExtractFileWithPath, UniqueReferenceValues, ExpectedValuePositionRange, ExpectedDataToBeValidated);

            return Result;
        }
        public static bool VerifyDataInFileByVerificationValues(string Filenamewithpath, string verificationvalues)
        {

            bool fileexistflg = false, foundflg = false, Result = false;

            int flagFound = 0;
            string temptext = "";
            string[] filedataarray = null;
            string[] refdataarray = null;
            if (verificationvalues.Contains(";"))
            {
                refdataarray = verificationvalues.Split(';');
            }
            else
            {
                refdataarray = new string[1];
                refdataarray[0] = verificationvalues;
            }
            if (refdataarray.Length == 1)
            {
                temptext = refdataarray[0];
            }
            else
            {
                temptext = string.Join(",", refdataarray);
            }
            if (File.Exists(Filenamewithpath))
            {
                fileexistflg = true;
            }
            else
            {
                Report.Fail("The File is not present in specified path " + Filenamewithpath);
            }

            if (fileexistflg)
            {
                try
                {
                    filedataarray = File.ReadAllLines(Filenamewithpath);
                    for (int i = 0; i < filedataarray.Length; i++)
                    {
                        string line = filedataarray[i];

                        for (int j = 0; j < refdataarray.Length; j++)
                        {
                            if (line.Contains(refdataarray[j]))
                            {
                                foundflg = true;
                                flagFound++;
                            }
                            else
                            {
                                foundflg = false;

                            }
                        }
                        if (flagFound == refdataarray.Length) { break; }
                        else
                        {
                            flagFound = 0;
                        }


                    }

                    if (foundflg == true && flagFound == refdataarray.Length)
                    {
                        Result = true;
                        Report.Pass("The File contains the specified reference values : " + temptext, true);
                    }
                    else
                    {
                        Result = false;
                        Report.Fail("The File does not contain the specified reference values: " + temptext, true);
                    }

                }
                catch (Exception e)
                {
                    Report.Info("Exception message is captured as: " + e.Message);

                }
            }
            return Result;
        }
        public static bool VerifyIfDataNotPresentInFile(string Filenamewithpath, string verificationvalues)
        {
            bool Result = false;
            if (VerifyDataInFileByVerificationValues(Filenamewithpath, verificationvalues) == false)
            {
                Report.Pass(verificationvalues + " - Expected data is/are not present in the specified file .", true);
            }
            return Result;
        }
        internal static int GetMatchingLineNumberInFileSpecifiedData(string Filenamewithpath, string RefValues)
        {
            int LineNumber = 0;
            bool fileexistflg = false;

            int flagFound = 0;
            string temptext = "";
            string[] filedataarray = null;
            string[] refdataarray = null;
            if (RefValues.Contains(";"))
            {
                refdataarray = RefValues.Split(';');
            }
            else
            {
                refdataarray = new string[1];
                refdataarray[0] = RefValues;
            }
            if (refdataarray.Length == 1)
            {
                temptext = refdataarray[0];
            }
            else
            {
                temptext = string.Join(",", refdataarray);
            }
            if (File.Exists(Filenamewithpath))
            {
                fileexistflg = true;
            }
            else
            {
                Report.Fail("The File is not present in specified path " + Filenamewithpath);
            }
            if (fileexistflg)
            {
                try
                {
                    filedataarray = File.ReadAllLines(Filenamewithpath);
                    for (int i = 0; i < filedataarray.Length; i++)
                    {
                        string line = filedataarray[i];

                        for (int j = 0; j < refdataarray.Length; j++)
                        {
                            if (line.Contains(refdataarray[j]))
                            {
                                flagFound++;
                            }
                        }
                        if (flagFound == refdataarray.Length)
                        {
                            LineNumber = i;
                            break;
                        }
                        else
                        {
                            flagFound = 0;
                        }

                    }

                }
                catch (Exception e)
                {
                    Report.Info("Exception message is captured as: " + e.Message);

                }
            }

            return LineNumber;
        }
        public static bool VerifyDataPresentInFileByPosition(string Filenamewithpath, string UniqueReferenceValues, string ExpectedValuePositionRange, string ExpectedDataToBeValidated)
        {

            int LineNumber = GetMatchingLineNumberInFileSpecifiedData(Filenamewithpath, UniqueReferenceValues + ";" + ExpectedDataToBeValidated);
            bool foundflg = false;
            bool Result = false;

            string[] filedataarray = null;
            string[] refdataarray = UniqueReferenceValues.Split(';');
            int flagFound = 0;
            filedataarray = File.ReadAllLines(Filenamewithpath);

            string line = filedataarray[LineNumber];
            for (int j = 0; j < refdataarray.Length; j++)
            {
                if (line.Contains(refdataarray[j]))
                {
                    foundflg = true;
                    flagFound++;
                }
                else
                {
                    foundflg = false;
                }

            }

            if (foundflg == true && flagFound == refdataarray.Length)
            {
                if (ExpectedValuePositionRange.Contains("-"))
                {
                    int startpos = Int32.Parse(ExpectedValuePositionRange.Split('-')[0]) - 1; ;
                    int endpos = Int32.Parse(ExpectedValuePositionRange.Split('-')[1]) - 1; ;
                    int numofchar = endpos - startpos;
                    string actualdata = line.Substring(startpos, numofchar);
                    if (actualdata.Contains(ExpectedDataToBeValidated))
                    {
                        Report.Pass(ExpectedDataToBeValidated + " is present in the file at Line Number : " + LineNumber + " with respect to reference parameters : " + UniqueReferenceValues + " within specified position range " + ExpectedValuePositionRange, true);
                        Result = true;
                    }
                    else
                    {
                        Report.Fail(ExpectedDataToBeValidated + " is not present in the file at Line Number : " + LineNumber + " with respect to reference parameters : " + UniqueReferenceValues + " within specified position range " + ExpectedValuePositionRange, true);
                        Result = false;
                    }
                }
            }
            return Result;
        }
        public static bool VerifyIfDataNotPresentInFileByPosition(string Filenamewithpath, string UniqueReferenceValues, string ExpectedValuePositionRange, string ExpectedDataToBeValidated)
        {
            bool Result = false;
            if (VerifyDataPresentInFileByPosition(Filenamewithpath, UniqueReferenceValues, ExpectedValuePositionRange, ExpectedDataToBeValidated) == false)
            {
                Result = true;
                Report.Pass(ExpectedDataToBeValidated + " - Expected data is/are not present in the file for the mentioned positions.", true);
            }
            return Result;
        }
        public static void ReloadApplication(string applicationname)
        {
            appHandle.CloseAllBrowser();
            string buttonAdvanced = "XPath;//button[@id='details-button']";
            string linkProceed = "XPath;//a[@id='proceed-link']";

            string directory = StartupConfiguration.EnvironmentDetails.HostDirectory;

            string webcsrurl = "https://web1.fisdev.local/WebCSR-" + directory + "/login.do?reload=true";
            string webadminurl = "https://web1.fisdev.local/WebAdmin-" + directory + "/login.do?reload=true";

            string editbox = "XPath;//input[@name='userName']";
            string msgobj = "XPath;//*[contains(text(),'The application cache has been reloaded (QA mode).')]";
            string msg = "The application cache has been reloaded (QA mode).";

            applicationname = applicationname.ToLower();
            if (applicationname.Equals("webcsr"))
            {


                appHandle.LaunchApplication(webcsrurl, "chrome");

                if (appHandle.IsObjectExists(buttonAdvanced))
                {
                    appHandle.ClickObjectViaJavaScript(buttonAdvanced);
                    WaitForSpecifiedObjectExists(linkProceed);
                    appHandle.ClickObjectViaJavaScript(linkProceed);

                }

                WaitForSpecifiedObjectExists(editbox);
                string actmsg = appHandle.GetObjectText(msgobj);
                if (actmsg.Equals(msg))
                {
                    Report.Pass("The Application " + applicationname + " is reloaded successfully", "reloadpass", "True", appHandle);
                }
                else
                {
                    Report.Fail("The Application " + applicationname + " is not reloaded successfully", "reloadfail", "True", appHandle);

                }

            }
            else
            {
                appHandle.LaunchApplication(webadminurl, "chrome");

                if (appHandle.IsObjectExists(buttonAdvanced))
                {
                    appHandle.ClickObjectViaJavaScript(buttonAdvanced);
                    WaitForSpecifiedObjectExists(linkProceed);
                    appHandle.ClickObjectViaJavaScript(linkProceed);

                }

                WaitForSpecifiedObjectExists(editbox);
                string actmsg = appHandle.GetObjectText(msgobj);
                if (actmsg.Equals(msg))
                {
                    Report.Pass("The Application " + applicationname + " is reloaded successfully", "reloadpass", "True", appHandle);
                }
                else
                {
                    Report.Fail("The Application " + applicationname + " is not reloaded successfully", "reloadfail", "True", appHandle);

                }



            }

            appHandle.CloseAllBrowser();
        }

        public static void LaunchProfileApplication(string applicationame)
        {
            string dropdownbranch = "XPath;//select[@name='branchCode']";
            string txtpassword = "XPath;//input[@name='password']";

            string directory = StartupConfiguration.EnvironmentDetails.HostDirectory;
            string webcsrurl = "https://web1.fisdev.local/WebCSR-" + directory + "/login.do?";
            string webadminurl = "https://web1.fisdev.local/WebAdmin-" + directory + "/login.do?";

            applicationame = applicationame.ToLower();
            if (applicationame.Equals("webadmin"))
            {
                appHandle.LaunchApplication(webadminurl, "chrome");
                if (appHandle.GetTitle().Equals("Privacy error"))
                {
                    WebAdminPageFactory.WebAdminLoginPage.OverComeAdvancedBrowserConn();

                }
                WaitForSpecifiedObjectExists(txtpassword);

                if (appHandle.IsObjectExists(txtpassword))
                {
                    Report.Pass("The WebAdmin application is invoked successfully", "ty2", "True", appHandle);
                }
                else
                {
                    Report.Fail("The WebAdmin application is not invoked", "ty3", "True", appHandle);

                }
            }
            else
            {
                appHandle.LaunchApplication(webcsrurl, "chrome");
                WaitForSpecifiedObjectExists(dropdownbranch);
                if (appHandle.IsObjectExists(dropdownbranch))
                {
                    Report.Pass("The WebCSR application is invoked successfully", "ty", "True", appHandle);
                }
                else
                {
                    Report.Fail("The WebCSR application is not invoked", "ty1", "True", appHandle);

                }

            }

        }

       
        


        
        public static bool CheckTextAvailableInPage(string ExpectedText)
        {
            bool Result = false;
            if (appHandle.GetObjectText("XPath;//*[@class='main']").Contains(ExpectedText))
            {
                Result = true;
            }
            return Result;
        }
        public static string GetTagNameBySpecifiedObjectReference(string sInputObjectRef)
        {
            string tagname = "";
            IWebElement obj = (IWebElement)appHandle.FindElement(sInputObjectRef);
            tagname = obj.TagName;

            return tagname;
        }
        /// <summary>
        /// This method is used to validate data in WebCSR , WebAdmin pages by label name , label value.
        /// Using this method Dropdown values , text box values , checkbox checked , checkbox unchecked , label names in the page, headers in the page can be validated.
        /// 
        /// For label name validation just pass label name as input. Multiple label names can be sent . Multiple label names has to be sent as Label1;Label2;Label3
        /// Same is applicable for headers.
        /// For Single value validation data has to be passed as labelname1|labelvalue1 .
        /// For multiple label value validation data has to be passed as labelname1|labelvalue1;labelname2|labelvalue2
        /// </summary>
        /// <param name="LabelNameLabelValuePipeDelimited"></param>
        /// <returns></returns>
        public static bool VerifyValueByLabelNameLabelValue(string LabelNameLabelValuePipeDelimited)
        {
            bool Result = false;
            string LabelName = "";
            string LabelValue = "";
            string RunTimeObj = "";
            string tagname = "";
            int matchcount = 0;
            string temp = "";
            LabelNameLabelValuePipeDelimited = LabelNameLabelValuePipeDelimited + ";";
            string[] arr = LabelNameLabelValuePipeDelimited.Split(';');
            for (int i = 0; i < arr.Length - 1; i++)
            {

                if (arr[i].Contains("|"))
                {
                    LabelName = arr[i].Split('|')[0].Trim();
                    LabelValue = arr[i].Split('|')[1].Trim();
                    RunTimeObj = "XPath;//*[contains(text(),'" + LabelName + ":')]/ancestor::*[1]/following-sibling::*/*[1]";

                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeObj))
                    {
                        try
                        {
                            tagname = Profile7CommonLibrary.GetTagNameBySpecifiedObjectReference(RunTimeObj);
                            if (tagname.Trim().ToUpper().Equals("SELECT"))
                            {
                                if (appHandle.CheckSelectedValueExistsInDropdown(RunTimeObj, LabelValue))
                                {
                                    appHandle.SelectDropdownSpecifiedValueByPartialText(RunTimeObj, LabelValue);
                                    if (appHandle.CheckValueInDropdown(RunTimeObj, LabelValue))
                                    {
                                        appHandle.ScrollToObject(RunTimeObj);
                                        Report.Pass(LabelValue + " is existing in " + LabelName + " dropdown.", "DropdownvalCheck", "True", appHandle);
                                        Result = true;
                                    }
                                    else
                                    {
                                        appHandle.ScrollToObject(RunTimeObj);
                                        Report.Fail(LabelValue + " is not existing in " + LabelName + " dropdown.", "DropdownvalCheckFail", "True", appHandle);
                                    }
                                }
                            }
                            if (tagname.Trim().ToUpper().Equals("INPUT")
                        && !appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                            {
                                if (appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "value").Contains(LabelValue))
                                {
                                    appHandle.ScrollToObject(RunTimeObj);
                                    Report.Pass(LabelValue + " is present in " + LabelName + " text box.", "TextFieldvalCheck", "True", appHandle);
                                    Result = true;
                                }
                                else
                                {
                                    appHandle.ScrollToObject(RunTimeObj);
                                    Report.Fail(LabelValue + " is not present in " + LabelName + " text box.", "TextFieldvalCheckFail", "True", appHandle);
                                }
                            }
                            if (tagname.Trim().ToUpper().Equals("INPUT")
                                                    && appHandle.GetSpecifiedObjectAttribute(RunTimeObj, "type").Trim().ToUpper().Equals("CHECKBOX"))
                            {
                                if (LabelValue.Equals("ON"))
                                {
                                    if (appHandle.CheckCheckBoxChecked(RunTimeObj))
                                    {
                                        appHandle.ScrollToObject(RunTimeObj);
                                        Report.Pass(LabelName + " checkbox is checked.", "Checkboxvalidation", "True", appHandle);
                                        Result = true;
                                    }
                                    else
                                    {
                                        appHandle.ScrollToObject(RunTimeObj);
                                        Report.Fail(LabelName + " checkbox is not checked.", "CheckboxvalidationFail", "True", appHandle);
                                    }

                                }
                                else
                                {
                                    if (!appHandle.CheckCheckBoxChecked(RunTimeObj))
                                    {
                                        appHandle.ScrollToObject(RunTimeObj);
                                        Report.Pass(LabelName + " checkbox is not checked.", "Checkboxvalidation", "True", appHandle);
                                        Result = true;
                                    }
                                    else
                                    {
                                        appHandle.ScrollToObject(RunTimeObj);
                                        Report.Fail(LabelName + " checkbox is  checked.", "CheckboxvalidationFail", "True", appHandle);
                                    }

                                }

                            }
                        }
                        catch (Exception e) { }
                    }
                }
                else
                {
                    LabelName = arr[i];
                    RunTimeObj = "XPath;//*[contains(text(),'" + LabelName + "')]";

                    tagname = Profile7CommonLibrary.GetTagNameBySpecifiedObjectReference(RunTimeObj);
                    if (tagname.ToUpper().Equals("H2"))
                    {
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeObj))
                        {
                            matchcount++;
                            temp = temp + " , " + LabelName;
                        }
                    }
                    else if (tagname.ToUpper().Equals("H1"))
                    {
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeObj))
                        {
                            matchcount++;
                            temp = temp + " , " + LabelName;
                        }
                    }
                    else
                    {
                        RunTimeObj = "XPath;//*[contains(text(),'" + LabelName + ":')]";
                        tagname = Profile7CommonLibrary.GetTagNameBySpecifiedObjectReference(RunTimeObj);
                        if (tagname.ToUpper().Equals("LABEL"))
                        {
                            if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeObj))
                            {
                                matchcount++;
                                temp = temp + " , " + LabelName;
                            }
                            
                        }
                        
                        else if (tagname.ToUpper().Equals("TD"))
                        {
                        if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeObj))
                           {
                            matchcount++;
                            temp = temp + " , " + LabelName;
                           }
                        }

                    }

                    if (matchcount == arr.Length - 1)
                    {
                        temp = temp.Substring(3, temp.Length - 3);
                        Report.Pass(temp + " is / are present in the page.", "labelname", "True", appHandle);
                        Result = true;
                    }
                    else
                    {
                        temp = temp.Substring(3, temp.Length - 3);
                        Report.Fail("Please check application page . One or any of labelname " + temp + " is / are present in the page.", "labelname", "True", appHandle);
                    }

                }
            }
            return Result;
        }

        public static string GetMonthName(int monthnumber)
        {
            DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
            return dtfi.GetMonthName(monthnumber);
        }
        public static bool VerifyDropdownSpecifiedValueExists(string LabelNameLabelValuePipeDelimited)
        {
            bool Result = false;
            string LabelName = "";
            string LabelValue = "";
            string RunTimeObj = "";


            LabelNameLabelValuePipeDelimited = LabelNameLabelValuePipeDelimited + ";";
            string[] arr = LabelNameLabelValuePipeDelimited.Split(';');
            for (int i = 0; i < arr.Length - 1; i++)
            {
                if (arr[i].Contains("|"))
                {
                    LabelName = arr[i].Split('|')[0].Trim();
                    LabelValue = arr[i].Split('|')[1].Trim();
                    RunTimeObj = "XPath;//*[contains(text(),'" + LabelName + ":')]/following-sibling::*/descendant::select[1]";
                    int totalcount = appHandle.GetDropdownContentsCount(RunTimeObj);
                    if (Profile7CommonLibrary.WaitForSpecifiedObjectExists(RunTimeObj))
                    {
                        if (appHandle.VerifyDropdownSpecifiedValueExists(RunTimeObj, LabelValue))
                        {
                            appHandle.ScrollToObject(RunTimeObj);
                            Report.Pass(LabelValue + " is existing in " + LabelName + " dropdown.", "DropdownvalCheck", "True", appHandle);
                            Result = true;
                        }
                        else
                        {
                            appHandle.ScrollToObject(RunTimeObj);
                            Report.Pass(LabelValue + " is not existing in " + LabelName + " dropdown.", "DropdownvalCheckFail", "True", appHandle);
                        }

                    }

                }
            }
            return Result;
        }
        public static bool VerifyLabelValueByLabelNameInPopUp(string LabelNameLableValuePipeDelimited)
        {
            return VerifyTableDataByLableNameLabelValue("XPath;//*[contains(@class,'ui-dialog ui-widget')]/descendant::*/*[@class='contentTable']/tbody", LabelNameLableValuePipeDelimited);
        }
        public static bool WaitUntilWindowLoads(string WindowProcessSemicolonWindowName)
        {
            int n = 1;
            bool flag = false;
            do
            {
                flag = WindowHandle.Launch_Application(WindowProcessSemicolonWindowName, n, false, true);
                n++;
            }
            while (flag == false);
            return flag;
        }
        public static bool VerifyFilePresentInRemoteDirectory(string strFilename, string strRemotePath = "")
        {
            bool Result = false;
            if (string.IsNullOrEmpty(strRemotePath))
            {
                strRemotePath = Data.Get("remotepath");
            }
            WinSCPHandle.OpenSession(strHostName);
          //  WinSCPHandle.setTransferOption();
            if (WinSCPHandle.checkFileExistsInSpool(strFilename, strRemotePath))
            {
                Result = true;
                Report.Pass(strFilename + " is present in " + strRemotePath + " .", true);
            }
            else
            {
                Report.Fail(strFilename + " is not present in " + strRemotePath + " .", true);
            }
            return Result;
        }
        public static void CompareTwoFilesData(string File1WithPath, string File2WithPath)
        {
            string filename1 = Path.GetFileName(File1WithPath);
            string filename2 = Path.GetFileName(File2WithPath);
            if (File.Exists(File1WithPath) && File.Exists(File2WithPath))
            {
                try
                {
                    if (FileEquals(File1WithPath, File2WithPath))
                    {
                        Report.Pass(filename1 + " and " + filename2 + " data are matching.", true);
                    }
                    else
                    {
                        Report.Fail(filename1 + " and " + filename2 + " data are not matching.", "True");
                    }
                }
                catch (Exception e) { };
            }
            else
            {
                Report.Fail("Please check the file paths.", "True", appHandle);
            }
        }
        public static bool FileEquals(string path1, string path2)
        {
            byte[] file1 = File.ReadAllBytes(path1);
            byte[] file2 = File.ReadAllBytes(path2);
            if (file1.Length == file2.Length)
            {
                for (int i = 0; i < file1.Length; i++)
                {
                    if (file1[i] != file2[i])
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }
      /*  public static bool WaitForTextOnScreen(string text)
        {
            bool bFindText = false;
            do
            {
                try
                {
              //    bFindText = oHost.Find_string(text);
                }
                catch (Exception e) { };
            }
            while (bFindText == false);
            return bFindText;
        }*/
        internal static string AddTrailingSpacesForSpecificLength(string InputString, int SpecifiedLength)
        {
            string Result = "";
            int strLen = InputString.Length;
            int diffLen = SpecifiedLength - strLen;
            if (diffLen != 0)
            {
                for (int i = 1; i <= diffLen; i++)
                {
                    Result = Result + " ";
                }
            }
            return Result = Result + InputString;
        }
        /// <summary>
        /// This method is used to create I40642 Payer A file.
        /// </summary>
        /// <param name="ApplicationDate"></param>
        /// <param name="numberOfMissingIncorrectTINWithPlayerB"></param>
        /// <param name="NumberOfMissingTINInRecordB_BWHTINSTATUS1"></param>
        /// <param name="NumberOfNotCurrentlyUsedTINRecordB_BWHTINSTATUS2"></param>
        /// <param name="numberofIncorrectNameOrTINRecordB_BWHTINSTATUS3"></param>
        /// <param name="PathForTheFileToBeSaved"></param>
        /// <returns></returns>
        
        /// <summary>
        /// This method is to create input records for creating I40642RecordPayerB file.
        /// TaxID : It can be valid or invalid tax id .
        /// AccountNumber : Account number of the customer
        /// MissingTIN : Boolean parameter. If we are passing missing TIN it has to be true else false
        /// NotCurrentlyIssuedTIN :Boolean parameter. If we are passing not currently issued TIN it has to be true else false
        /// InCorrectNameOrTIN : Boolean parameter. If we are passing incorrect TIN or incorrect CustomerName it has to be true else false
        /// DocType :Optional parameter .By default Form1099-INT is used. Example :Data.Get("Form1099-INT") . It will fetch 92 from testdata file. Depend on the requirement necessary value can be used from test data file.
        /// TINIndicatorEIN : Boolean parameter. If TIN is EIN type it has to be true else false
        /// TINIndicatorSSN : Boolean parameter. If TIN is SSN type it has to be true else false
        /// </summary>
        /// <param name="TaxID"></param>
        /// <param name="AccountNumber"></param>
        /// <param name="CustomerName"></param>
        /// <param name="MissingTIN"></param>
        /// <param name="NotCurrentlyIssuedTIN"></param>
        /// <param name="InCorrectNameOrTIN"></param>
        /// <param name="DocType"></param>
        /// <param name="TINIndicatorEIN"></param>
        /// <param name="TINIndicatorSSN"></param>
        /// <returns></returns>
        public static string CreateI40642RecordPayerBFile(string TaxID, string AccountNumber, string CustomerName = "", bool MissingTIN = false, bool NotCurrentlyIssuedTIN = false, bool InCorrectNameOrTIN = false, string DocType = "", bool TINIndicatorEIN = false, bool TINIndicatorSSN = false)
        {
            string temp = "", customerFirstName = "", customerLastName = "";
            string Custnumber = ExtractDataFromDataBase("SELECT ACN FROM ACN WHERE CID='" + AccountNumber + "'", "ACN");
            string SQL = "SELECT FNAME,LNM,TAXID,MAD1,MCITY,MSTATE,MZIP from cif where acn='" + Custnumber + "'";
            if (!string.IsNullOrEmpty(CustomerName))
            {
                customerFirstName = CustomerName.Split(' ')[0].Trim();
                customerLastName = CustomerName.Split(' ')[1].Trim();
            }
            else
            {
                customerFirstName = ExtractDataFromDataBase(SQL, "FNAME");
                customerLastName = ExtractDataFromDataBase(SQL, "LNM");
            }
            string StreetName = ExtractDataFromDataBase(SQL, "MAD1");
            string CityName = ExtractDataFromDataBase(SQL, "MCITY");
            string State = ExtractDataFromDataBase(SQL, "MSTATE");
            string ZIP = ExtractDataFromDataBase(SQL, "MZIP");
            string RecordType = Data.Get("B");
            string PipeCode = Data.Get("PipeCode");
            string TINIndicator = "";
            if (TINIndicatorEIN)
            {
                TINIndicator = Data.Get("GLOBAL_VALUE_1");
            }
            if (TINIndicatorSSN)
            {
                TINIndicator = Data.Get("GLOBAL_VALUE_2");
            }
            if (string.IsNullOrEmpty(TINIndicator))
            {
                TINIndicator = Data.Get("GLOBAL_VALUE-ZERO");
            }
            if (TaxID.Contains("-"))
            {
                TaxID = TaxID.Replace("-", string.Empty);
            }
            string TIN = TaxID;
            string BWHTINSTATUS = "";

            if (MissingTIN)
            {
                BWHTINSTATUS = Data.Get("GLOBAL_VALUE_1");
            }
            if (NotCurrentlyIssuedTIN)
            {
                BWHTINSTATUS = Data.Get("GLOBAL_VALUE_2");
            }
            if (InCorrectNameOrTIN)
            {
                BWHTINSTATUS = Data.Get("GLOBAL_VALUE_3");
            }
            string TransmitterControlCode = appHandle.CreateRamdomData(FieldType.NUMERIC, 11111, 99999, 5) + "";
            if (string.IsNullOrEmpty(DocType))
            {
                DocType = Data.Get("Form1099-INT");
            }
            if (AccountNumber.Length == 20) { }
            else if (AccountNumber.Equals(AddTrailingSpacesForSpecificLength(AccountNumber, 20))) { }
            else
            {
                AccountNumber = AddTrailingSpacesForSpecificLength(AccountNumber, 20);
            }

            string NameLine1 = AddTrailingSpacesForSpecificLength(customerFirstName, 40);
            string NameLine2 = AddLeadingSpacesForSpecificLength(customerLastName, 40);
            string StreetAddr = AddTrailingSpacesForSpecificLength(StreetName, 30);
            string City = AddTrailingSpacesForSpecificLength(CityName, 30);
            string PayerOfficeCode = AddTrailingSpacesForSpecificLength("", 4);
            string Sequence = appHandle.CreateRamdomData(FieldType.NUMERIC, 11111111, 99999999, 8) + "";
            temp = RecordType + PipeCode + TaxID + PipeCode + BWHTINSTATUS + PipeCode + TransmitterControlCode + PipeCode + DocType + PipeCode + AccountNumber + PipeCode + NameLine1 + PipeCode + NameLine2 + PipeCode + StreetAddr + PipeCode + City + PipeCode + State + PipeCode + ZIP + PipeCode + TINIndicator + PipeCode + PayerOfficeCode + PipeCode + Sequence;
            return temp;
        }
        public static string GetTransactionSequenceNumber(string AccountNumber, string TransactionCode, string Amount)
        {
            if (Amount.Contains("."))
            {
                Amount = Amount.Split('.')[0].Trim();
            }
            string SQLQUERY = "SELECT TSEQ,ETC,TAMT FROM HIST WHERE CID='" + AccountNumber + "' AND TAMT like '" + Amount + "%' AND ETC='" + TransactionCode + "'";
            return ExtractDataFromDataBase(SQLQUERY, "TSEQ");
        }
        public static void ExecuteSQLQueryUsingSQLJAR(string SQLQuery)
        {
            CreateSQLConfigPropertiesFile(SQLQuery);
            bool ExecutionStatus = ExecuteJARFIle();
        }
        public static string CreateIRSTAPELOGFileName(string ApplicationDate)
        {
            string FileName = "";
            FileName = Data.Get("IRSDATA") + "-" + appHandle.GetDateParameters(ApplicationDate)[0] + appHandle.GetDateParameters(ApplicationDate)[1] + ".LOG";


            return FileName;
        }
        public static string GenerateIRSDATALogExceptionMessage(string AccountNumber)
        {
            return "Skipped TAX1042 record for account " + AccountNumber + ", nonresident IN, withholding percentage 22, income code 29, and sequence 1";
        }
        /// <summary>
        /// This method is created for I40642 Payer B file. The input record for this method can be referred to CreateI40642RecordPayerBFile method in Profile7CommonLibrary . 
        /// If single record is needed CreateI40642RecordPayerBFile can be called for one row data before executing this method.
        /// If multiple records are needed then CreateI40642RecordPayerBFile can be called multiple times as per number of records before executing this method. The multiple strings can be saved with pipe demlimiter and can be passed as an input.
        /// PathForTheFileToBeSaved by default it will create local path under WorkSpace\Profile7Automation\TestData\FileTransfer\Local_To_Remote\TestCaseName\
        /// </summary>
        /// <param name="inputRecord"></param>
        /// <param name="PathForTheFileToBeSaved"></param>
        
        /// <summary>
        /// This method is used to create I40642 Payer C file .
        /// The inputs for this method depends on the data added in Payer B file.
        /// NumberOfMissingOrIncorrectTIN : Number of documents passed in Payer B file
        /// numberOfBWHTINSTATUS1OfPayerBRecord : Number passed in BWH TIN STATUS 1 in payer B file
        /// numberOfBWHTINSTATUS2OfPayerBRecord : Number passed in BWH TIN STATUS 2 in payer B file
        /// numberOfBWHTINSTATUS3OfPayerBRecord : Number passed in BWH TIN STATUS 3 in payer B file
        /// PathForTheFileToBeSaved: Where the file has to be stored . This is an optional parameter. By default file is created in framework workspace under Testdata/FileTransfer
        /// </summary>
        /// <param name="NumberOfMissingOrIncorrectTIN"></param>
        /// <param name="numberOfBWHTINSTATUS1OfPayerBRecord"></param>
        /// <param name="numberOfBWHTINSTATUS2OfPayerBRecord"></param>
        /// <param name="numberOfBWHTINSTATUS3OfPayerBRecord"></param>
        /// <param name="PathForTheFileToBeSaved"></param>
        /// <returns></returns>
        public static string CreateI40642PayerCFile(string NumberOfMissingOrIncorrectTIN, string numberOfBWHTINSTATUS1OfPayerBRecord, string numberOfBWHTINSTATUS2OfPayerBRecord, string numberOfBWHTINSTATUS3OfPayerBRecord, string PathForTheFileToBeSaved = "")
        {
            if (string.IsNullOrEmpty(PathForTheFileToBeSaved))
            {
          //      PathForTheFileToBeSaved = GetLocalFolderPath("outgoing");
            }
            string FileNameWithPath = PathForTheFileToBeSaved + "\\" + Data.Get("I40642") + "." + Data.Get("UC") + nnnn + ".txt";
            string RecordType = Data.Get("C");
            string PipeCode = Data.Get("PipeCode");
            NumberOfMissingOrIncorrectTIN = AddTrailerZerosForSpecifiedLength(NumberOfMissingOrIncorrectTIN, 8);
            numberOfBWHTINSTATUS1OfPayerBRecord = AddTrailerZerosForSpecifiedLength(numberOfBWHTINSTATUS1OfPayerBRecord, 8);
            numberOfBWHTINSTATUS2OfPayerBRecord = AddTrailerZerosForSpecifiedLength(numberOfBWHTINSTATUS2OfPayerBRecord, 8);
            numberOfBWHTINSTATUS3OfPayerBRecord = AddTrailerZerosForSpecifiedLength(numberOfBWHTINSTATUS3OfPayerBRecord, 8);
            string temp = RecordType + PipeCode + NumberOfMissingOrIncorrectTIN + PipeCode + numberOfBWHTINSTATUS1OfPayerBRecord + PipeCode + numberOfBWHTINSTATUS2OfPayerBRecord + PipeCode + numberOfBWHTINSTATUS3OfPayerBRecord;

            if (File.Exists(FileNameWithPath))
            {
                for (int i = 1; i < 500; i++)
                {
                    try
                    {
                        File.Delete(FileNameWithPath);
                        if (!File.Exists(FileNameWithPath)) { break; }
                    }
                    catch (Exception e) { }
                }
            }

            StreamWriter streamwriter = File.CreateText(FileNameWithPath);
            streamwriter.WriteLine(temp);

            streamwriter.Close();
            if (File.Exists(FileNameWithPath))
            {
                Report.Info(GetFileNameForTheSpecifiedPath(FileNameWithPath) + " is created .");
            }
            return FileNameWithPath;
        }
        /// <summary>
        /// This method is used to fetch the exchange rate for the specified currency
        /// </summary>
        /// <param name="CurrencyCode"></param>
        /// <returns></returns>
        public static string GetExchangeRateForSpecifiedCurrency(string CurrencyCode)
        {
            string effectivedate = ExtractDataFromDataBase("SELECT MAX(EFD) FROM CRCDRATEH WHERE CRCD='" + CurrencyCode + "'", "MAX_EFD");
            effectivedate = effectivedate.Split('-')[1] + "/" + effectivedate.Split('-')[2] + "/" + effectivedate.Split('-')[0];
            string EXCHGRATE = ExtractDataFromDataBase("SELECT MIDRATE FROM CRCDRATEH WHERE CRCD='" + CurrencyCode + "' AND EFD='" + effectivedate + "'", "MIDRATE");
            EXCHGRATE = Profile7CommonLibrary.ConvertNumberToCurrencyByCommaFormat(EXCHGRATE);
            return EXCHGRATE;
        }
        /// <summary>
        /// This method is used to get the file name with extension  for the specified path.
        /// </summary>
        /// <param name="FileNameWithPath"></param>
        /// <returns></returns>
        public static string GetFileNameForTheSpecifiedPath(string FileNameWithPath)
        {
            string FileName = "";
            FileName = Path.GetFileName(FileNameWithPath);
            return FileName;
        }
        /// <summary>
        /// This method is used to get directoryname for the specified file with path
        /// Example: Input:  "C://Test//Test1//abc.txt"
        /// Output will be "C://Test//Test1"
        /// </summary>
        /// <param name="FileNameWithPath"></param>
        /// <returns></returns>
        public static string GetDirectoryNameForTheSpecifiedFileWithPath(string FileNameWithPath)
        {
            string DirectoryName = "";
            DirectoryName = Path.GetDirectoryName(FileNameWithPath);
            return DirectoryName;
        }

        
      /*  public static string GetRemoteToLocalPath()
        {
            //return GetLocalFolderPath("incoming");
        }
        public static string GetLocalToRemotePath()
        {
           // return GetLocalFolderPath("outgoing");
        }
        public static string GenerateBackSlashCharacter()
        {
            int i = '\\';
            char j = (char)i;
            return j.ToString();
        }*/
        /*public static string GenerateLetterStmtSTMTCMBFileName(string ApplicationDate = "")
        {
            string Result = "";
            if (string.IsNullOrEmpty(ApplicationDate))
            {
                ApplicationDate = SysDate;
            }
            string datepart = appHandle.GetDateParameters(ApplicationDate)[1];
            string monthpart = appHandle.GetDateParameters(ApplicationDate)[0];
            string Yearpart = appHandle.GetDateParameters(ApplicationDate)[2];
            Yearpart = Yearpart.Substring(2, 2);
            Result = "FIS_LETSTMT_STMTCMB_" + monthpart + datepart + Yearpart + ".EXT";
            return Result;
        }*/
       
        public static string GetAddendaRecordType799(string OriginalEntryTraceNumber, string OriginalRecDFIIdentification, string ReasonCode = "", string DateOfDeath = "", string TraceNumber = "")
        {
            WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
            string OutRecord = "";
            string AddendaRecordInitial = Data.Get("AddendaRecordInitial");
            string AddendaRecordType = Data.Get("GLOBAL_VALUE_99");
            if (string.IsNullOrEmpty(ReasonCode))
            {
                ReasonCode = "R03";//NO ACCOUNT/UNABLE TO LOCATE ACCOUNT
            }
            if (ReasonCode.Equals("R14")
            || ReasonCode.Equals("R15")) { }
            else
            {
                DateOfDeath = AddTrailingSpacesForSpecificLength(string.Empty, 6);
            }
            string AddendaInformation = AddTrailingSpacesForSpecificLength(string.Empty, 44);

            OutRecord = AddendaRecordInitial + AddendaRecordType + ReasonCode + OriginalEntryTraceNumber + DateOfDeath + OriginalRecDFIIdentification + AddendaInformation + TraceNumber;
            return OutRecord;
        }
        public static string GetApplicationTime()
        {
            string Timeval = "";
            Timeval = ExtractDataFromDataBase("SELECT PROFTIME FROM CUVAR", "PROFTIME");
            return Timeval;
        }

    }
}