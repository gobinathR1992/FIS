﻿using System;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF;

namespace Profile7Automation.Util
{
    public class BaseURLGenerator
    {
        public static string  Generate(String applicationName)
        {
            string baseURL;
           // String webServerName =StartupConfiguration.EnvironmentDetails.ApplicationServerName;
            //String hostDirectory = StartupConfiguration.EnvironmentDetails.HostDirectory;
            //baseURL = "https://" + webServerName + ".atldev.com/" + applicationName + "-" + hostDirectory + "/";
           // baseURL = "https://" + webServerName + ".fisdev.local/" + applicationName + "-" + hostDirectory + "/";
           // baseURL="http://vlmaznbpdev1ci.fisdev.local:8083/WebCSR";
           baseURL= "http://vlmazndpdev2ci.fisdev.local:8082/WebCSR";
          // http://vlmaznbpdiscov3.fisdev.local:8081/WebAdmin-v76apac
           
            //string ApplicationServerName = Data.Get("");
           //string ApplicationName =StartupConfiguration.EnvironmentDetails.ApplicationServerName;
            // if (applicationName.ToUpper().Equals("PROFTELLER"))
            //     baseURL += "app/teller.jnlp";
            // if (applicationName.ToUpper().Equals("WEBCLIENT"))
            //     baseURL = "https://webclient.fnis.com/WebClient-v742qaaxpintix";
            //return baseURL;
           applicationName = applicationName.ToUpper();
            switch (applicationName)
            {

                case "PROFTELLER":
                {
                     baseURL += "app/teller.jnlp";
                     break;
                }
                case "WEBCLIENT":
                {
                    return baseURL;
                }
                case "WEBCSR":
                {
                    return baseURL;
                }
                 case "WEBADMIN":
                {
                    return baseURL;
                }
                
            }
            return baseURL;
        }
       

    }
}
