using GTS_OSAF.CoreLibs;
using OpenQA.Selenium;
using NLog;
using System.Text.RegularExpressions;
using GTS_CORE.CoreLibs;
using System;
using GTS_OSAF.HelperLibs.DataAdapter;
using GTS_OSAF.HelperLibs.Reporter;


namespace Profile7Automation.Libraries.Helper
{
    public static class ExtendedClass
    {
                private static Logger logger = LogManager.GetCurrentClassLogger();

        public static void ClickOnVisibleElement(this WebApplication webApplication, string objectName)
        {
            string[] objArr = objectName.Split(';');
            IWebDriver driver = (IWebDriver)webApplication.GetWebDriver();
            IWebElement webelement = null;
            dynamic elements = driver.FindElements(By.XPath(objArr[1]));

            foreach (IWebElement element in elements)
            {
                if (element.Displayed) // correct method: isDisplayed()
                    webelement = element;
            }
            webelement.Click();

        }

        /// <summary>
        /// To get cell value by object reference.
        /// </summary>
        /// <param name="sobjectName"></param>
        /// <returns>Inside label text</returns>
        /// <example><code>
        /// string sobjectName="XPath;.//*[text()='Tax ID Number:')]/following-sibling::*[1]"
        /// string sLabelText= GetCellValueByObject(objectName)
        /// </code></example>
        public static string GetCellValueByObject(this WebApplication webApp, string sobjectName)
        {
            try
            {
                string[] objArr = sobjectName.Split(';');
                IWebDriver driver = (IWebDriver)webApp.GetWebDriver();
                string strActualValue = null;
                IWebElement webele = (IWebElement)webApp.FindElement(sobjectName);
                webApp.GetObjectText(sobjectName);
                return strActualValue;

            }
            catch (NoSuchElementException e)
            {
                logger.Error("Exception Logged:  " + e);
            }
            return null;
        }

        /// <summary>
        /// To check cell value by object reference.
        /// </summary>
        /// <param name="sobjectName"></param>
        /// <returns>Inside label text</returns>
        /// <example><code>
        /// string sobjectName="XPath;//*[contains(text(),'Tax ID Number:')]/following-sibling::dd"
        /// string sLabelText= GetCellValueByLabel(objectName)
        /// </code></example>
        public static string CheckCellValueByObject(this WebApplication webApp, ILayoutTestingLibrary GUIValidation, string sobjectName, string expected, ReportAs oReportAs = ReportAs.PassOrFail)
        {
            try
            {
                string[] objArr = sobjectName.Split(';');
                IWebDriver driver = (IWebDriver)webApp.GetWebDriver();
                string strActualValue = null;
                IWebElement webele = (IWebElement)webApp.FindElement(sobjectName);
                webApp.GetObjectText(sobjectName);

                bool bResult = (strActualValue.Trim().Equals(expected.Trim()));

                string sMsgToShowOnPass = "'" + expected + "' value matches" + strActualValue;
                string sMsgToShowOnFail = "'" + expected + "' value doesnot match" + strActualValue;
                webApp.AppendToReport(bResult, oReportAs, sMsgToShowOnPass, sMsgToShowOnFail);

            }
            catch (NoSuchElementException e)
            {
                logger.Error("Exception Logged:  " + e);
            }
            return null;
        }


        public static string GetChar(this WebApplication webApp, string schar, string schartype)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(schar))
                    return string.Empty;
                var number = Regex.Match(schar, @"\d+");
                var alpha = Regex.Match(schar, @"[a-zA-Z]");
                var specialchar = Regex.Match(schar, @"[^a-zA-Z0-9_]+");
                if (number != null)
                    return number.Value;
                if (alpha != null)
                    return alpha.Value;
                if (specialchar != null)
                    return specialchar.Value;
                else
                {
                    return string.Empty;
                }

            }
            catch (Exception e)
            {

                logger.Error("Exception Logged:  " + e);
            }
            return null;
        }

        ///  </summary>
        ///  This function is used to calculate the EMI (Monthly Payment Amount) for the specified Loan Amount, Interest Rate and Term.
        /// </summary>
        /// <param name= "Loan Amount"></param>
        ///<param name= "Interest Rate"></param>  
        ///<param name= "Term"></param>
        /// <returns></returns> 
        /// <example>
        /// Example: EMICalculation(100000,10,60);
        ///appHandle.CalculateEMI(LoanAmount,IntRate,Term);
        /// </example>

        public static string CalculateEMI(this WebApplication webApp, string LoanAmount, string IntRate, string Term)
        {
            double IntRateResult;
            double LoanAmountResult;
            double TermResult;
            double EmiPayment;
            string EmiPaymentFinal = null;

            try
            {
                WebApplication appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                appHandle = ApplicationHandlerFactory.GetApplication(ApplicationType.WEB);
                IWebDriver driver = (IWebDriver)webApp.GetWebDriver();
                IntRateResult = Convert.ToDouble(IntRate);
                LoanAmountResult = Convert.ToDouble(LoanAmount);
                TermResult = Convert.ToDouble(Term);

                if (IntRateResult > 1)
                {
                    IntRateResult = (IntRateResult) / 100;
                }
                EmiPayment = (LoanAmountResult * Math.Pow((IntRateResult / 12) + 1,
                   (TermResult)) * IntRateResult / 12) / (Math.Pow(IntRateResult / 12 + 1, (TermResult)) - 1);
                EmiPaymentFinal = (appHandle.RoundOffValue(EmiPayment, 0)).ToString();
            }
            catch (Exception e) { Report.Info("Exception logged :" + e); }
            return EmiPaymentFinal;
        }


    }
}